"""Seal the report-only Standards packet; no project execution."""
from pathlib import Path
import hashlib,json
OUT=Path(__file__).resolve().parent
sha=lambda raw:hashlib.sha256(raw).hexdigest()
assert not (OUT/'manifest.json').exists()
result=json.loads((OUT/'result.json').read_bytes())
assert result['status']=='PASS_SAVED_REPORT_STANDARDS' and result['check_count']==309 and result['remaining_blockers']==[]
receipt={k:result[k] for k in ['status','source','base','authoring_source','check_count','figures','copied_figure_files','embedded_images','embedded_downloads','data_files','parameter_rows','registered_runs','registered_seconds','independence_units','actual_browser_QA','QA_scope','remaining_blockers','meaningful_smell_findings','reviewer_activity']}
receipt.update(schema='aegisdc-independent-report-standards-v1',scientific_source_inputs=33)
(OUT/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
files=[]
for path in sorted(OUT.iterdir()):
    if path.is_file() and path.name not in {'manifest.json','seal-verification.json'}:
        raw=path.read_bytes();files.append({'path':path.name,'sha256':sha(raw),'bytes':len(raw)})
manifest={'schema':'aegisdc-independent-review-manifest-v1','source':result['source'],'scientific_cutoff':result['base'],'files':files,'excluded':['manifest.json (self)','seal-verification.json (post-seal proof)','runtime caches (none declared)']}
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
for row in json.loads((OUT/'manifest.json').read_bytes())['files']:
    raw=(OUT/row['path']).read_bytes();assert sha(raw)==row['sha256'] and len(raw)==row['bytes']
proof={'status':'PASS','manifest_sha256':sha((OUT/'manifest.json').read_bytes()),'fresh_read_artifacts':len(files),'reviewer_project_calls':0,'actual_browser_QA':False}
(OUT/'seal-verification.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf-8')
print(json.dumps(proof))
