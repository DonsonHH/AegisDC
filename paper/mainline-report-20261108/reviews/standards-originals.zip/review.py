"""Saved report provenance/content audit only; never call its builder/verifier."""
from pathlib import Path,PurePosixPath
from html.parser import HTMLParser
from urllib.parse import unquote,urlsplit
import ast,base64,csv,hashlib,io,json,math,re,subprocess

ROOT=Path(r"C:\Users\Donson\Documents\ChatGPT\Renly")
OUT=Path(__file__).resolve().parent
SOURCE='85d5ea8a55306337be650cfe19ef4ee5f6b20137'
BASE='2ba22965119615b157bb7f3a302875bf05e4989b'
FIRST='3fdf9405'
PAPER='paper/mainline-report-20261108/'
checks=[]
def ck(ok,label):
    checks.append({'label':label,'passed':bool(ok)});assert ok,label
def sha(raw):return hashlib.sha256(raw).hexdigest()
def git(*a):return subprocess.check_output(['git','-C',str(ROOT),*a])
def fetch(rev,paths):
    paths=list(dict.fromkeys(paths));raw=subprocess.check_output(['git','-C',str(ROOT),'cat-file','--batch'],input=''.join(rev+':'+p+'\n' for p in paths).encode())
    result={};offset=0
    for p in paths:
        end=raw.index(b'\n',offset);header=raw[offset:end].split();assert header[1]==b'blob',(rev,p,header)
        size=int(header[2]);offset=end+1;result[p]=raw[offset:offset+size];offset+=size+1
    assert offset==len(raw);return result
def blob(rev,p):return fetch(rev,[p])[p]
def doc(p):return json.loads(saved[PAPER+p])
def same(a,b):return math.isclose(a,b,abs_tol=1e-12,rel_tol=1e-12)

names=[p.decode() for p in git('ls-tree','-r','-z','--name-only',SOURCE,'--',PAPER).split(b'\0') if p]
saved=fetch(SOURCE,names);manifest=doc('source-manifest.json');author=manifest['authoring_source']
ck(manifest['scientific_cutoff']==BASE and len(manifest['inputs'])==33,'exact scientific cutoff and33 actual source inputs')
sources=fetch(BASE,manifest['inputs'])
source_records=[]
for p,row in manifest['inputs'].items():
    raw=sources[p]
    ck(sha(raw)==row['sha256'] and len(raw)==row['bytes'] and blob(SOURCE,p)==raw and (ROOT/p).read_bytes()==raw,'original scientific input raw/base/current identity '+p)
    source_records.append({'path':p,'sha256':sha(raw),'bytes':len(raw)})
for p,h in manifest['tools'].items():ck(sha(saved[p])==h and blob(author,p)==saved[p] and (ROOT/p).read_bytes()==saved[p],'actual author tool/content identity '+p)
ck(not git('diff','--name-only',BASE,SOURCE,'--','src','scripts','configs').strip(),'all286 executable source/config files unchanged by report task')
for p in ['tools/build.py','tools/verify.py']:
    tree=ast.parse(saved[PAPER+p]);mods={n.module.split('.')[0] for n in ast.walk(tree) if isinstance(n,ast.ImportFrom) and n.module}|{a.name.split('.')[0] for n in ast.walk(tree) if isinstance(n,ast.Import) for a in n.names}
    ck(mods<=set('argparse base64 csv hashlib html io json pathlib re subprocess sys traceback zipfile'.split()),'report tool imports only standard libraries '+p)

html_name=next(p for p in names if p.endswith('.html'));html=saved[html_name].decode();md=saved[PAPER+'report.md'].decode();content=saved[PAPER+'content.md'].decode();css=saved[PAPER+'tools/report.css'].decode()
for number,revision in [(1,FIRST),(2,SOURCE)]:
    prefix=PAPER+f'builds/build-{number:02}.';start=json.loads(saved[prefix+'start.json']);end=json.loads(saved[prefix+'terminal.json'])
    ck(start['source']==end['source'] and start['scientific_cutoff']==BASE and end['status']=='PASS_SAVED_REPORT_BUILD','unique historical/current build source '+str(number))
    ck(start['tool_sha256']==sha(blob(start['source'],PAPER+'tools/build.py')) and start['content_sha256']==sha(blob(start['source'],PAPER+'content.md')),'frozen actual build inputs '+str(number))
    ck(sha(blob(revision,html_name))==end['html_sha256'] and sha(blob(revision,PAPER+'report.md'))==end['markdown_sha256'],'original/current HTML+MD output identities preserved in Git '+str(number))
    ck(end['figures']==8 and end['downloads']==6 and end['new_physical_calls']==end['new_inference']==end['new_trials']==0,'saved-only build charge/classification '+str(number))
original_content=blob(FIRST,PAPER+'content.md').decode()
expected_content=original_content.replace('原定180次比较全部完成。','原定180次注册运行全部完成。').replace('移动、等待、测量和处置都占用真实仿真时间；','移动、等待、测量与处置按仿真时钟占用资源，期间设施继续运行；')
ck(content==expected_content,'build02 only two declared prose clarifications; original build retained')

copies={'primary.json':'evidence/mainline/research/34-paired-analysis/results.json','ablation.json':'evidence/mainline/research/35-ablation/results.json','robustness.json':'evidence/mainline/research/36-robustness/analysis-01/results.json','robustness-paired.csv':'evidence/mainline/research/36-robustness/analysis-01/paired.csv','model-parameters.csv':'paper/mentor-review-20261108/model-parameters.csv','metric-coverage.json':'evidence/mainline/engineering/pre36-readout/readout-01/metric-coverage.json'}
for dest,p in copies.items():ck(saved[PAPER+'data/'+dest]==sources[p],'data download is byte-identical source '+dest)
ck(len([n for n in names if n.startswith(PAPER+'data/')])==6,'exactly six data files')
model=json.loads(sources['configs/full-facility-mainline-reserve-v6.json']);parameters={p['id']:p for p in model['parameters']}
params=list(csv.DictReader(io.StringIO(saved[PAPER+'data/model-parameters.csv'].decode('utf-8-sig'))))
ck(len(params)==len(parameters)==113 and {r['id'] for r in params}==set(parameters),'113 unique original parameter identities')
for row in params:
    p=parameters[row['id']];ck(json.loads(row['value'])==p['value'] and row['unit']==p['unit'],'parameter value/SI unit '+row['id'])
facts=doc('facts.json');primary=doc('data/primary.json');ablation=doc('data/ablation.json');robust=doc('data/robustness.json');protocol=json.loads(sources['docs/mainline/30-comparison-protocol-v1.json'])
phases=[('开发','31-development','development',36,6,6),('主要确认','33-confirmation','confirmation',96,16,6),('机制消融','35-ablation','ablation',32,8,4),('稳健性','36-robustness','robustness',16,8,2)]
for row,(label,folder,phase,runs,worlds,arms) in zip(facts['phases'],phases,strict=True):
    receipt=json.loads(sources['evidence/mainline/research/'+folder+'/capture-01/receipt.json'])
    ck(row==dict(label=label,**receipt['total']) and row['completed']==row['started']==runs and row['failed']==row['interrupted']==row['unrun']==0,'complete phase counts from original accepted receipt '+phase)
    ck(len(protocol['phases'][phase]['worlds'])==worlds and len(protocol['phases'][phase]['arms'])==arms and worlds*arms==runs,'distinct planned world/arm denominator '+phase)
ck(facts['total_runs']==sum(p['completed'] for p in facts['phases'])==180 and facts['total_simulated_s']==sum(p['charged_simulated_s'] for p in facts['phases'])==1800,'four-phase180/1800 totals')
ck(all(facts['primary'][k]==primary[k] for k in facts['primary']) and primary['status']=='NO_PRACTICAL_GAIN' and primary['planned_denominator']==16 and primary['mean_service_delta_s']==.03515625 and protocol['comparison']['minimum_worthwhile_gain_s']==.25,'primary quantities/16 units and original category unchanged')
ck(facts['ablation_summary']==ablation['summary'] and facts['robustness_paired']==robust['paired'] and same(facts['robustness_mean'],-.084375) and robust['contrast_blocks']==4,'all3 mask contrasts/8 robust outcomes and4-block scope retained')
ck((facts['domain_count'],facts['entity_count'],facts['parameter_count'])==(len(model['domains']),len(model['entities']),len(model['parameters']))==(8,45,113),'model scale matches original source')
ck(facts['formal_closure']=='NOT_EVALUATED' and facts['generic_false_miss_rates']=='NOT_OPERATIONALIZED' and facts['prevention']=='NOT_TESTED' and facts['AI_RSI']=='NOT_MEASURED','unmeasured endpoints never upgraded to zero or benefit')
coverage=doc('data/metric-coverage.json');ck(len(coverage)==18 and [r['metric'] for r in coverage]==protocol['comparison']['report_separately'],'complete original18-metric status disclosure')
summary=json.loads(sources['evidence/mainline/engineering/pre36-readout/readout-01/method-summary.json']);confirm={r['arm']:r for r in summary if r['phase']=='confirmation'}
ck(confirm['evidence_consistent_contingent']['historical_named_threshold_findings']==9 and confirm['one_observation_lookahead']['historical_named_threshold_findings']==12 and all(r['endpoint_current_named_threshold_findings']==0 for r in confirm.values()),'historical9/12 findings and endpoint expiry kept distinct')

class Page(HTMLParser):
    def __init__(self):
        super().__init__();self.images=[];self.downloads=[];self.links=[];self.ids=[];self.scripts=0;self.h1=0;self.h2=0;self.tables=[];self.table=None;self.row=None;self.cell=None;self.styles=[];self.in_style=False;self.viewport=None;self.lang=None
    def handle_starttag(self,tag,attrs):
        a=dict(attrs)
        if 'id' in a:self.ids.append(a['id'])
        if tag=='html':self.lang=a.get('lang')
        if tag=='meta' and a.get('name')=='viewport':self.viewport=a.get('content')
        if tag=='h1':self.h1+=1
        if tag=='h2':self.h2+=1
        if tag=='script':self.scripts+=1
        if tag=='style':self.in_style=True
        if tag=='img':self.images.append(a)
        if tag=='a':
            self.links.append(a.get('href',''))
            if 'download' in a:self.downloads.append(a)
        if tag=='table':self.table=[]
        if tag=='tr':self.row=[]
        if tag in {'td','th'}:self.cell=[]
    def handle_data(self,data):
        if self.in_style:self.styles.append(data)
        if self.cell is not None:self.cell.append(data)
    def handle_endtag(self,tag):
        if tag=='style':self.in_style=False
        if tag in {'td','th'}:self.row.append(''.join(self.cell));self.cell=None
        if tag=='tr' and self.table is not None:self.table.append(self.row);self.row=None
        if tag=='table':self.tables.append(self.table);self.table=None
page=Page();page.feed(html)
ck(page.lang=='zh-CN' and page.viewport=='width=device-width,initial-scale=1' and page.h1==1 and page.h2==6 and page.scripts==0,'static HTML document/viewport/headings and no runtime script')
ck(len(page.images)==8 and len(page.downloads)==22 and len(page.ids)==len(set(page.ids)) and '{{' not in html and '{{' not in md,'eight images/22 downloads/unique anchors/no unresolved placeholders')
figures=doc('figure-sources.json');ck(len(figures)==8 and [r['number'] for r in figures]==list(range(1,9)),'ordered eight source-preserving figures')
download_bytes={n.rsplit('/',1)[1]:raw for n,raw in saved.items() if n.startswith(PAPER+'data/') or n.startswith(PAPER+'figures/')}
for figure,image in zip(figures,page.images,strict=True):
    stem=f"{figure['number']:02}-{figure['id']}"
    for extension,digest in [('png',figure['png_sha256']),('svg',figure['svg_sha256'])]:
        raw=saved[PAPER+'figures/'+stem+'.'+extension]
        ck(sha(raw)==digest and raw==sources[figure['input']+'.'+extension],'copied original figure bytes '+stem+'.'+extension)
    ck(image.get('alt')==figure['caption'] and image['src'].startswith('data:image/png;base64,') and base64.b64decode(image['src'].split(',',1)[1],validate=True)==saved[PAPER+'figures/'+stem+'.png'],'ordered embedded PNG/alt identity '+stem)
ck(len({a['download'] for a in page.downloads})==22 and {a['download'] for a in page.downloads}==set(download_bytes),'every copied figure/data file downloadable exactly once')
for a in page.downloads:ck(a['href'].startswith('data:') and base64.b64decode(a['href'].split(',',1)[1],validate=True)==download_bytes[a['download']],'download original bytes '+a['download'])
tree={n.decode() for n in git('ls-tree','-r','-z','--name-only',SOURCE).split(b'\0') if n}
def resolve(href):
    part=urlsplit(href);ck(not part.scheme and not part.netloc,'no external page resource dependency '+href)
    joined=PurePosixPath(PAPER)/unquote(part.path);stack=[]
    for p in joined.parts:
        if p=='..':stack.pop()
        elif p!='.':stack.append(p)
    return '/'.join(stack)
for href in page.links:
    if href.startswith('data:'):continue
    if href.startswith('#'):ck(href[1:] in page.ids,'HTML anchor resolves '+href)
    else:ck(resolve(href) in tree,'HTML repository source link resolves '+href)
for href in re.findall(r'!?\[[^\]]*\]\(([^)]+)\)',md):ck(resolve(href) in tree,'Markdown copied/source link resolves '+href)
tables=[];current_table=[]
for line in md.splitlines()+['']:
    if line.startswith('|'):
        cells=[c.strip() for c in line.strip('|').split('|')]
        if not all(re.fullmatch(r'[-: ]+',c) for c in cells):current_table.append(cells)
    elif current_table:tables.append(current_table);current_table=[]
ck(len(tables)==7 and tables==page.tables,'all seven HTML/Markdown tables have identical values/units/N/NA')
for phrase in ['NO_PRACTICAL_GAIN','0.03515625','−0.084375','4个区组','100秒','8.5秒','closure_program=None','未测','未标定','1秒','60/120秒','180次指注册设施运行']:
    ck(phrase in md and phrase in html,'HTML/Markdown evidence/scope statement retained '+phrase)
ck(''.join(page.styles)==css and '@media(max-width:640px)' in css and '@media(min-width:1600px)' in css and 'grid-template-columns:1fr' in css and '.figure-scroll{overflow-x:auto' in css and 'table{border-collapse:collapse;width:100%;min-width:540px' in css,'exact static responsive CSS:mobile grid/scroll tables+figures andlarge screens')
readme=saved[PAPER+'README.md'].decode();plan=json.loads(blob(SOURCE,'docs/mainline/37-report-plan.json'))
ck('不冒称新的浏览器手机/大屏实测' in readme and 'No browser launch or policy bypass' in plan['browser_limit'],'no new browser/mobile visual QA claim')
audit={'status':'PASS_SAVED_REPORT_STANDARDS','source':SOURCE,'base':BASE,'authoring_source':author,'check_count':len(checks),'checks':checks,'source_inputs':source_records,'figures':8,'copied_figure_files':16,'embedded_images':8,'embedded_downloads':22,'data_files':6,'parameter_rows':113,'registered_runs':180,'registered_seconds':1800,'independence_units':{'primary_worlds':16,'ablation_worlds':8,'robustness_blocks':4,'robustness_worlds':8},'actual_browser_QA':False,'QA_scope':'Immutable original bytes, arithmetic, embedded downloads, links, HTML/MD tables and static CSS only. No new rendering or browser session.','remaining_blockers':[],'meaningful_smell_findings':[],'reviewer_activity':{'tests':0,'original_builder':0,'original_verifier':0,'models':0,'plant':0,'selectors':0,'inference':0,'nonce':0,'browser':0,'project_imports':0,'tracked_edits':0}}
(OUT/'result.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:audit[k] for k in ['status','source','check_count','figures','embedded_downloads','data_files','parameter_rows','registered_runs','registered_seconds','remaining_blockers','actual_browser_QA','reviewer_activity']}))
