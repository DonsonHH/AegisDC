"""Independent report facts/bytes review; no builder, checker, browser or models."""
import base64
import csv
from datetime import datetime,timezone
import hashlib
from html.parser import HTMLParser
import io
import json
import math
from pathlib import Path
import re
import subprocess
import traceback

ROOT=Path('C:/Users/Donson/Documents/ChatGPT/Renly')
OUT=Path(__file__).resolve().parent
PIN='85d5ea8a55306337be650cfe19ef4ee5f6b20137'
BASE='2ba22965119615b157bb7f3a302875bf05e4989b'
PREFIX='paper/mainline-report-20261108/'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
git=lambda *args:subprocess.check_output(['git',*args],cwd=ROOT)
hashes={};cache={}

def blob(path,source=PIN):
    key=source+':'+path
    if key not in cache:cache[key]=git('show',key)
    raw=cache[key];hashes[key]=dict(sha256=sha(raw),bytes=len(raw))
    return raw

def read(path,source=PIN):return json.loads(blob(path,source))

def save(name,data):
    with (OUT/name).open('x',encoding='utf-8',newline='\n') as stream:
        stream.write(json.dumps(data,ensure_ascii=False,indent=2,allow_nan=False)+'\n')

class Page(HTMLParser):
    def __init__(self):
        super().__init__();self.images=[];self.downloads=[];self.links=[];self.ids=[];self.count=Counter()
    def handle_starttag(self,tag,attributes):
        attributes=dict(attributes);self.count[tag]+=1
        if 'id' in attributes:self.ids.append(attributes['id'])
        if tag=='img':self.images.append(attributes)
        if tag=='a':
            self.links.append(attributes.get('href',''))
            if 'download' in attributes:self.downloads.append(attributes)

from collections import Counter
save('start.json',dict(source=PIN,scientific_cutoff=BASE,started_utc=datetime.now(timezone.utc).isoformat(),
    scope='STATIC_REPORT_FACTS_AND_GIT_BYTES_ONLY'))
try:
    manifest=read(PREFIX+'source-manifest.json');facts=read(PREFIX+'facts.json')
    assert manifest['scientific_cutoff']==facts['source_cutoff']==BASE
    assert len(manifest['inputs'])==33
    for path,entry in manifest['inputs'].items():
        raw=blob(path,BASE)
        assert sha(raw)==entry['sha256'] and len(raw)==entry['bytes'],path
        assert blob(path)==raw,path
    for path,value in manifest['tools'].items():
        assert sha(blob(path))==sha(blob(path,manifest['authoring_source']))==value
    primary=read('evidence/mainline/research/34-paired-analysis/results.json',BASE)
    ablation=read('evidence/mainline/research/35-ablation/results.json',BASE)
    robust=read('evidence/mainline/research/36-robustness/analysis-01/results.json',BASE)
    protocol=read('docs/mainline/30-comparison-protocol-v1.json',BASE)
    model=read('configs/full-facility-mainline-reserve-v6.json',BASE)
    assert facts['primary']=={key:primary[key] for key in facts['primary']}
    assert facts['primary']['planned_denominator']==16
    assert facts['primary']['status']=='NO_PRACTICAL_GAIN' and primary['mean_service_delta_s']==.03515625<protocol['comparison']['minimum_worthwhile_gain_s']==.25
    assert (primary['mean_extra_paid_person_s'],primary['mean_extra_travel_person_s'],primary['mean_extra_tool_occupation_s'])==(-.96875,-.25,-.609375)
    assert primary['hard_violations']==[]
    assert primary['leave_one_family_out_mean_delta_s']['misleading-report']==-.0625
    assert facts['ablation_summary']==ablation['summary']
    for key,delta,cost in [('without_nonfixed_context',.0732421875,-1.375),('without_dependency_context',-.0146484375,5.09375),('without_joint_crew_planning',-.0146484375,4.15625)]:
        assert math.isclose(ablation['summary'][key]['mask_minus_full_deficit_s'],delta,abs_tol=1e-12)
        assert ablation['summary'][key]['full_minus_mask_paid_person_s']==cost
    assert facts['robustness_paired']==robust['paired'] and facts['robustness_mean']==robust['mean_over_eight_designed_worlds_service_delta_s']
    assert robust['contrast_blocks']==4 and robust['worlds']==8 and robust['runs']==16
    assert math.isclose(facts['robustness_mean'],-.084375,abs_tol=1e-12)
    for row,(label,folder) in zip(facts['phases'],[('开发','31-development'),('主要确认','33-confirmation'),('机制消融','35-ablation'),('稳健性','36-robustness')]):
        original=read('evidence/mainline/research/'+folder+'/capture-01/receipt.json',BASE)
        assert row==dict(label=label,**original['total'])
    assert facts['total_runs']==sum(row['completed'] for row in facts['phases'])==180
    assert facts['total_simulated_s']==sum(row['charged_simulated_s'] for row in facts['phases'])==1800
    assert facts['domain_count']==len(model['domains'])==8
    assert facts['entity_count']==len(model['entities'])==45
    assert facts['parameter_count']==len(model['parameters'])==113
    for key,value in [('formal_closure','NOT_EVALUATED'),('generic_false_miss_rates','NOT_OPERATIONALIZED'),('prevention','NOT_TESTED'),('AI_RSI','NOT_MEASURED')]:assert facts[key]==value
    figure_index=read(PREFIX+'figure-sources.json');assert len(figure_index)==8
    for index,row in enumerate(figure_index,1):
        assert row['number']==index
        stem=f"{index:02}-{row['id']}"
        for extension in ('png','svg'):
            raw=blob(row['input']+'.'+extension,BASE)
            assert sha(raw)==row[extension+'_sha256'] and blob(PREFIX+'figures/'+stem+'.'+extension)==raw
    download_sources={
        'primary.json':'evidence/mainline/research/34-paired-analysis/results.json',
        'ablation.json':'evidence/mainline/research/35-ablation/results.json',
        'robustness.json':'evidence/mainline/research/36-robustness/analysis-01/results.json',
        'robustness-paired.csv':'evidence/mainline/research/36-robustness/analysis-01/paired.csv',
        'model-parameters.csv':'paper/mentor-review-20261108/model-parameters.csv',
        'metric-coverage.json':'evidence/mainline/engineering/pre36-readout/readout-01/metric-coverage.json'}
    for name,path in download_sources.items():assert blob(PREFIX+'data/'+name)==blob(path,BASE)
    parameters=list(csv.DictReader(io.StringIO(blob(PREFIX+'data/model-parameters.csv').decode('utf-8-sig'))))
    assert len(parameters)==113 and len(read(PREFIX+'data/metric-coverage.json'))==18
    text=blob(PREFIX+'report.md').decode();content=blob(PREFIX+'content.md').decode()
    for line in content.splitlines():
        if line and '{{' not in line:assert line in text,line
    assert '{{' not in text
    for row in figure_index:assert f"图{row['number']}　{row['caption']}" in text
    assert '100秒有限工程价值演算' in text and '不计入180次方法比较' in text
    assert '4秒自动恢复' in text and '清滤在6秒完成' in text and '8.5秒验证关闭' in text
    assert '人工编制的两个任务选项' in text and '未验证全场任务自主发现或最佳团队分配' in text
    assert '这里没有把全部物理时间常数同比缩放' in text
    assert '主要确认中，候选有9条、主要参照有12条' in text and '终点时它们均已过期' in text
    assert '实际处置容量仍为0.75' in text and '未替代原16工况主要结果' in text
    assert '没有测量证据验证关闭' in text and '不能填成零' in text and 'AI/RSI增量尚未试验' in text
    tables=[];current=[]
    for line in text.splitlines()+['']:
        if line.startswith('|'):
            cells=[cell.strip() for cell in line.strip('|').split('|')]
            if not all(re.fullmatch(r'[-: ]+',cell) for cell in cells):current.append(cells)
        elif current:tables.append(current);current=[]
    assert len(tables)==7
    assert tables[2][1:]==[
        ['服务缺额：参照−候选','0.03515625 秒','未达0.25秒门槛'],
        ['人工：候选−参照','-0.96875 人秒','平均减少；不等同服务增益'],
        ['行走 / 工具：候选−参照','-0.25 人秒 / -0.609375 工具秒','量纲分列，不混成总分'],
        ['实际硬约束违反','0','针对本次已记录规则，不作现场安全保证']]
    assert tables[3][1:]==[['屏蔽非固定线索','+0.073242','-1.37500'],['屏蔽依赖关系/后果','-0.014648','+5.09375'],['屏蔽联合团队选项','-0.014648','+4.15625']]
    assert [row[1] for row in tables[4][1:]]==['0.000 → -0.300','0.000 → 0.000','-0.375 → 0.000','0.000 → 0.000']
    page_raw=blob(PREFIX+'AegisDC-会后研究报告.html');page_text=page_raw.decode();page=Page();page.feed(page_text)
    assert len(page.images)==8 and len(page.downloads)==22 and page.count['script']==0
    assert page.count['h1']==1 and page.count['h2']==6 and page.count['details']==1
    assert len(page.ids)==len(set(page.ids))
    for image,row in zip(page.images,figure_index):
        assert image['alt']==row['caption'] and image['src'].startswith('data:image/png;base64,')
        assert sha(base64.b64decode(image['src'].split(',',1)[1],validate=True))==row['png_sha256']
    exported={Path(path).name:sha(raw) for (key,raw) in cache.items()
        for path in [key.split(':',1)[1]] if path.startswith(PREFIX+'figures/') or path.startswith(PREFIX+'data/')}
    assert len({row['download'] for row in page.downloads})==22
    for item in page.downloads:
        assert sha(base64.b64decode(item['href'].split(',',1)[1],validate=True))==exported[item['download']]
    for link in page.links:
        if link.startswith('#'):assert link[1:] in page.ids
    assert '@media(max-width:640px)' in page_text and '@media(min-width:1600px)' in page_text
    terminal=read(PREFIX+'builds/build-02.terminal.json')
    assert terminal['source']==manifest['authoring_source'] and terminal['status']=='PASS_SAVED_REPORT_BUILD'
    assert terminal['html_sha256']==sha(page_raw) and terminal['markdown_sha256']==sha(blob(PREFIX+'report.md'))
    assert not git('diff','--name-only',BASE,PIN,'--','paper/mentor-review-20261108','evidence/mainline/research','docs/meetings','src','configs').strip()
    save('static-facts-and-delivery.json',dict(source=PIN,scientific_cutoff=BASE,authoring_source=manifest['authoring_source'],
        source_inputs=33,source_figures=8,figure_files=16,data_downloads=6,embedded_images=8,embedded_downloads=22,
        parameter_rows=113,metric_states=18,registered_runs=180,registered_simulated_s=1800,
        phase_counts=facts['phases'],primary=facts['primary'],ablation_summary=facts['ablation_summary'],
        robustness_worlds=8,robustness_blocks=4,robustness_mean=facts['robustness_mean'],
        caption_review='All8 captions match reused source images and their finite engineering/research scope. Value100s and loop4/6/8.5s are explicitly separated from registered trials.',
        scope_review='Eight-domain synthetic model and two manually curated task options are distinct. No site calibration, generic fault/miss/prevention, formal comparison closure, or AI/RSI increment is claimed measured.',
        generated_tables=tables,actual_browser_QA=False,new_visual_QA=False,
        verification_scope='Independent static facts, hashes, tables, original-byte copies and HTML embedding; no project builder/checker or browser invoked.'))
    save('source-and-evidence-hashes.json',hashes)
    save('findings.json',dict(source=PIN,findings=[],unresolved=0))
    save('receipt.json',dict(status='PASS_SPEC_BASELINE_REPORT_STATIC_REVIEW',source=PIN,scientific_cutoff=BASE,
        source_inputs=33,figures=8,downloads=22,data_downloads=6,parameter_rows=113,unresolved=0,
        actual_browser_QA=False,project_calls=0,tests=0,builder_calls=0,checker_calls=0,model_calls=0,
        selector_calls=0,nonce_file_reads=0,new_trials=0))
    report='''Spec：PASS，固定85d5ea8a，无未决阻塞。

报告清楚区分八域合成模型、两个预编任务选项、工程100秒价值例/4–6–8.5秒闭环与180次注册比较。主要16单位的0.03515625＜0.25秒、成本量纲、35屏蔽方向、36四区组−0.084375秒及真实.75/预测变化均准确，负结果、R6未测、未标定和AI未测保持。

33来源绑定2ba22965；8图/16PNG-SVG、6数据下载、113参数与7张表均吻合。HTML内嵌8图和22下载字节正确；原报告与科学原件未改。未做浏览器或新视觉实测，不以排版替代科学成果。本次零项目、构建器、检查器、模型、nonce或试验调用。仍需新Git交付复核。
'''
    assert len(report)<400
    with (OUT/'report.md').open('x',encoding='utf-8',newline='\n') as stream:stream.write(report)
except BaseException as error:
    with (OUT/'error.txt').open('x',encoding='utf-8',newline='\n') as stream:stream.write(traceback.format_exc())
    save('failure.json',dict(source=PIN,error_type=type(error).__name__,message=str(error),project_calls=0))
    raise
finally:
    manifest=dict(schema='aegisdc-independent-spec-report37-review-v1',source=PIN,
        artifacts={path.name:dict(sha256=sha(path.read_bytes()),bytes=path.stat().st_size)
            for path in sorted(OUT.iterdir()) if path.is_file() and path.name!='manifest.json'},excluded=['Self-hash','Runtime caches'])
    save('manifest.json',manifest)
print(json.dumps(dict(status='PASS',source=PIN,artifacts=len(manifest['artifacts']),
    manifest_sha256=sha((OUT/'manifest.json').read_bytes()),project_calls=0)))
