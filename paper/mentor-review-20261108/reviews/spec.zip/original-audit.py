"""Report-only Spec evidence audit at fixed f492; stdlib and saved Git blobs only."""
import base64
import csv
import hashlib
from html.parser import HTMLParser
import io
import json
import math
import subprocess
from pathlib import Path

REPO=Path('C:/Users/Donson/Documents/ChatGPT/Renly')
OUT=Path(__file__).resolve().parent
BASE='435727e7b517f86077aca97ba143d9752c7385f0'
CANDIDATE='f4922567918eb79b75ffd449b695f0ea050da0e1'
ROOT='paper/mentor-review-20261108/'
def git(*a):return subprocess.check_output(['git',*a],cwd=REPO)
def blob(ref,path):return git('cat-file','blob',ref+':'+path)
def obj(ref,path):return json.loads(blob(ref,path))
def sha(raw):return hashlib.sha256(raw).hexdigest()
def batch(ref,names):
    names=sorted(names);offset=0;result={}
    raw=subprocess.check_output(['git','cat-file','--batch'],cwd=REPO,input=''.join(ref+':'+n+'\n' for n in names).encode())
    for n in names:
        end=raw.index(b'\n',offset);h=raw[offset:end].split();assert len(h)==3 and h[1]==b'blob'
        start=end+1;size=int(h[2]);result[n]=raw[start:start+size];offset=start+size+1
    assert offset==len(raw);return result
m=obj(CANDIDATE,ROOT+'report-manifest.json')
sources=batch(BASE,m['source_files']);current=batch(CANDIDATE,m['source_files'])
assert all(sha(sources[n])==item['sha256'] and len(sources[n])==item['bytes'] and current[n]==sources[n]
           for n,item in m['source_files'].items())
model=json.loads(sources['configs/full-facility-mainline-reserve-v6.json'])
assert (len(model['domains']),len(model['entities']),len(model['parameters']))==(8,45,113)
assert {k:len(v) for k,v in model['graphs'].items()}==dict(physical=43,functional=23,control_information=20,access=5)
rows=list(csv.DictReader(io.StringIO(blob(CANDIDATE,ROOT+'model-parameters.csv').decode('utf-8-sig'),newline='')))
parameters={p['id']:p for p in model['parameters']};assert len(rows)==len(parameters)==113
for row in rows:
    p=parameters[row['id']]
    assert json.loads(row['value'])==p['value'] and row['unit']==p['unit']
    assert row['basis']==p['basis'] and row['source_note']==p['source_note']
value=json.loads(sources['evidence/mainline/engineering/20-action-value/capture-01/check-results.json'])
expected={'0':[(0,0),(20,20),(2,12)],'1/4':[(25,0),(20,20),(12.5,15.5)],'9/10':[(90,0),(20,20),(39.8,24.6)]}
for prior,values in expected.items():
    case=next(c for c in value['independent_cases'] if c['prior_fault']==prior)
    alts=case['result']['question_values'][0]['alternatives']
    assert [(a['expected']['service_deficit_time_s']['value'],a['expected']['person_s']['value']) for a in alts]==values
primary=json.loads(sources['evidence/mainline/research/34-paired-analysis/results.json'])
assert primary['planned_denominator']==primary['completed_primary_pairs']==16 and primary['status']=='NO_PRACTICAL_GAIN'
assert primary['mean_service_delta_s']==.03515625 and primary['mean_extra_paid_person_s']==-.96875
assert primary['mean_extra_travel_person_s']==-.25 and primary['mean_extra_tool_occupation_s']==-.609375
assert len(primary['identified_world_ids'])==12
ablation=json.loads(sources['evidence/mainline/research/35-ablation/results.json'])
assert ablation['planned_worlds']==8 and ablation['completed_runs']==32
assert ablation['summary']['without_nonfixed_context']['full_minus_mask_paid_person_s']==-1.375
assert ablation['summary']['without_dependency_context']['full_minus_mask_paid_person_s']==5.09375
assert ablation['summary']['without_joint_crew_planning']['full_minus_mask_paid_person_s']==4.15625
progress=json.loads(sources['docs/mainline/progress.json'])
assert progress['research_trials']['attempts']==164
assert m['registered_runs_before']==m['registered_runs_after']==164 and m['full_research_goal']=='INCOMPLETE'
assert all(m[k]==0 for k in ['new_physical_calls','new_selector_calls','new_inference_calls','new_research_trials'])
for f in m['figures']:
    assert sha(blob(CANDIDATE,ROOT+f['path']))==f['sha256']
    assert sha(blob(CANDIDATE,ROOT+f['path'].replace('.png','.svg')))==f['svg_sha256']
    if not f['source_path'].startswith('@'):assert sha(sources[f['source_path']])==f['sha256']
html_path=ROOT+'AegisDC-导师研究报告.html';html=blob(CANDIDATE,html_path)
assert sha(html)==m['html_sha256']
class Downloads(HTMLParser):
    def __init__(self):super().__init__();self.files={}
    def handle_starttag(self,tag,attrs):
        a=dict(attrs)
        if tag=='a' and a.get('download') and a.get('href','').startswith('data:'):
            head,data=a['href'].split(',',1);assert ';base64' in head
            self.files[a['download']]=base64.b64decode(data)
d=Downloads();d.feed(html.decode())
assert all(item['name'] in d.files and sha(d.files[item['name']])==item['sha256'] and len(d.files[item['name']])==item['bytes'] for item in m['downloads'])
claims=obj(CANDIDATE,ROOT+'claims.json');assert all(set(c['sources'])<=set(m['source_index']) for c in claims)
report=blob(CANDIDATE,ROOT+'report.md').decode()
findings=[dict(id='F1',priority='P2',path=ROOT+'report.md',lines=[132,258],
    requirement='Explicit model assumptions, timing and actual comparison scope',
    issue='Baseline inspection30s is shown without explaining registered1s work and1/2s routes inside10s compressed synthetic windows.',
    source='docs/mainline/30-comparison-protocol-v1.json:registration_limits.temporal_scope and prepared confirmation-01 input model.parameters'),
    dict(id='F2',priority='P2',path=ROOT+'report.md',lines=[180,199],
    requirement='Risk and VOI worked example',
    issue='Alternatives table states final expected totals but omits observation law and branch/time arithmetic needed to reproduce12.5s and15.5person-s.',
    source='S04 independent_cases[prior_fault=1/4].result.question_values[0].alternatives[inspect_then_act].branches')]
receipt=dict(status='FINDINGS_2_ORIGINAL_CANDIDATE',base=BASE,candidate=CANDIDATE,findings=findings,
    verified_source_files=len(sources),verified_figures=len(m['figures']),verified_embedded_downloads=len(m['downloads']),
    checked_scope=['8 domains/45 entities/113 parameters/91 relations','SI physical and service equations',
      'record arrival/provenance and private-truth boundary','actual inspection/action/closure separation',
      'independent primary and mechanism negative results','AI/RSI deferred and164 unchanged registered runs'],
    reviewer_tests=0,reviewer_plant_calls=0,reviewer_selectors=0,reviewer_inference_calls=0,reviewer_seed_reads=0,reviewer_new_experiments=0)
with (OUT/'original-receipt.json').open('x',encoding='utf-8') as f:json.dump(receipt,f,indent=2);f.write('\n')
print(json.dumps({k:v for k,v in receipt.items() if k not in ['findings','checked_scope']}))
