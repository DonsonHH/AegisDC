# Spec review — original mentor report

Base `435727e7b517f86077aca97ba143d9752c7385f0`; candidate `f4922567918eb79b75ffd449b695f0ea050da0e1`.

**Two P2 findings; both accepted for correction by root.**

1. **Explain the compressed timing override** (`paper/mentor-review-20261108/report.md:132`, `:258`). The baseline parameter table shows30s inspection, while the registered ten-second comparisons use1s work and1/2s routes. The report does not distinguish these configurations or state the frozen protocol's prohibition on transferring compressed times to field inspection durations. Add the actual timing inputs and synthetic-window limitation beside the comparison and baseline table. Sources: original V6 parameters; saved confirmation-01 input; `30-comparison-protocol-v1.json:registration_limits.temporal_scope`.

2. **Complete the numeric VOI example** (`report.md:180–199`). The formula and alternatives table supply final25/20/12.5s and0/20/15.5person-s totals without the observation law, report branches or action times needed to reproduce them. The saved S04 case already contains positive probability0.275, negative0.725, positive posterior0.7272727 and action10→30s. Show the corresponding TP/FN/FP/TN loss arithmetic and10+0.275×20 person-time sum, preserving predicted/actual and cost-unit distinctions. This requires no new inference.

Otherwise the report now substantively presents the mentor requirements: complete eight-domain facility and four relations, physical/service equations and SI units, source/assumption/site-data distinctions, timed/provenance-bound evidence, qualified actual work/action and evidence-verified closure, complete independent negative comparisons, and deferred AI/RSI status. No factual upgrade of synthetic evidence, causal benefit, field calibration or total research completion was found.

Saved-record verification passed50 source-file identities, model inventory8/45/113/91, all three VOI prior tables, current primary/mechanism numbers,15 figure identities and23 embedded downloadable originals. The two new PNGs and original desktop-equation/phone-value screenshots were actually inspected; those observations refer to f492 only. Registered runs remain164.

This review used static/saved-record arithmetic only: zero tests, plant, selectors, inference, seeds, model calls, captures or new experiments; no tracked edit. Original findings are retained pending a separate narrow correction review.
