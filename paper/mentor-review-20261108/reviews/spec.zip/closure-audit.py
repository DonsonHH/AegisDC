"""Narrow static closure of two prose findings; no browser or science execution."""
import hashlib
import json
import math
import subprocess
from pathlib import Path

REPO=Path('C:/Users/Donson/Documents/ChatGPT/Renly');OUT=Path(__file__).resolve().parent
OLD='f4922567918eb79b75ffd449b695f0ea050da0e1';NEW='212dbfca087bce33409996157443efaa860ca577'
BASE='435727e7b517f86077aca97ba143d9752c7385f0';ROOT='paper/mentor-review-20261108/'
def git(*a):return subprocess.check_output(['git',*a],cwd=REPO)
def blob(ref,path):return git('cat-file','blob',ref+':'+path)
def read(ref,path):return json.loads(blob(ref,path))
def sha(raw):return hashlib.sha256(raw).hexdigest()
text=blob(NEW,ROOT+'report.md').decode();m=read(NEW,ROOT+'report-manifest.json');old=read(OLD,ROOT+'report-manifest.json')
assert git('diff','--name-only',OLD,NEW,'src','configs','evidence','docs')==b''
assert all(m['source_files'][p]==v for p,v in old['source_files'].items())
assert set(m['source_files'])-set(old['source_files'])=={'docs/mainline/30-comparison-protocol-v1.json'}
new_source='docs/mainline/30-comparison-protocol-v1.json'
assert sha(blob(BASE,new_source))==m['source_files'][new_source]['sha256']
assert m['source_commit']==BASE and m['figures']==old['figures'] and m['downloads']==old['downloads']
assert m['source_index']['S21']['path']==new_source
assert sha(blob(NEW,ROOT+'AegisDC-导师研究报告.html'))==m['html_sha256']
for token in ['下表是基准V6配置','基准检查时间 | 30','基准短路径时间 | 60','基准长路径时间 | 120',
    '检查/专业作业1秒，短/长行走1/2秒','压缩合成时间','不能换算成现场巡检周期或真实节省时长',
    '注册输入把专业工作设为1秒','不能直接解释为现场工时或真实运维周期']:
    assert token in text,token
input_path='evidence/mainline/research/32-confirmation-freeze/prepared-02/inputs/confirmation-01/evidence_consistent_contingent.json'
document=read(BASE,input_path);p={r['id']:r['value'] for r in document['model']['parameters']}
assert [p[k] for k in ['inspection_time','walk_short','walk_long']]==[1,1,2] and document['duration_s']==10
assert 'compressed synthetic' in read(BASE,new_source)['registration_limits']['temporal_scope']
for token in ['检查灵敏度为0.8、假阳性率为0.1','0.25×0.8＋0.75×0.1=0.275','0.2/0.275=8/11',
    '0.25×0.8=0.20','0.25×0.2=0.05','0.75×0.1=0.075','0.75×0.9=0.675',
    '0.20×30＋0.05×100＋0.075×20=12.5秒','10＋0.275×20=15.5人秒','20−12.5=7.5秒',
    '未使用现场校准概率','独立方法比较仍按第4章评价']:
    assert token in text,token
witness=read(BASE,'evidence/mainline/engineering/20-action-value/capture-01/check-results.json')
case=next(c for c in witness['independent_cases'] if c['prior_fault']=='1/4')
inspect=next(a for a in case['result']['question_values'][0]['alternatives'] if a['kind']=='inspect_then_act')
positive=next(b for b in inspect['branches'] if b['report']=='positive')
assert positive['probability']==.275 and positive['action_started_at_s']==10 and positive['action_completed_at_s']==30
assert math.isclose(positive['posterior_outcomes']['cooling-limited'],8/11,rel_tol=0,abs_tol=1e-15)
assert math.fsum([.2,.05,.075,.675])==1 and math.fsum([.2*30,.05*100,.075*20])==inspect['expected']['service_deficit_time_s']['value']==12.5
assert 10+.275*20==inspect['expected']['person_s']['value']==15.5
qa=read(NEW,ROOT+'qa/revision-check.json')
assert qa['original_browser_qa_commit']==OLD and qa['original_html_sha256']==old['html_sha256']
assert qa['current_html_sha256']==m['html_sha256'] and qa['new_browser_execution'] is False
assert all(v=='BYTE_IDENTICAL' for v in qa['unchanged_components'].values())
assert m['registered_runs_before']==m['registered_runs_after']==164 and m['full_research_goal']=='INCOMPLETE'
assert all(m[k]==0 for k in ['new_physical_calls','new_selector_calls','new_inference_calls','new_research_trials'])
assert 'NO_PRACTICAL_GAIN' in text and '第36—42项' in text and '当前按需核查主线中的智能体/RSI增量仍须独立评价' in text
result=dict(status='PASS_SPEC_0_UNRESOLVED',original_candidate=OLD,candidate=NEW,source_cutoff=BASE,
    original_findings=2,resolved_findings=['F1: base and compressed timing clearly separated','F2: saved finite VOI branches and arithmetic fully shown'],
    unresolved_findings=[],source_files=51,figures=15,embedded_downloads=23,registered_runs=164,
    visual_scope='Originalf492 figures/QA screenshots inspected earlier;212 added prose/table checked statically; no new browser claim',
    new_tests=0,new_plant_calls=0,new_selectors=0,new_inference=0,new_seed_reads=0,new_model_calls=0,new_captures=0,new_experiments=0)
with (OUT/'closure-receipt.json').open('x',encoding='utf-8') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps(result))
