"""Immutable mentor-report Standards review; parsing and saved arithmetic only."""
import ast
import base64
import csv
from hashlib import sha256
from html.parser import HTMLParser
import importlib.util
from io import StringIO
import json
from pathlib import Path
import re

OUT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('immutable_git_helpers',OUT.parent/'32-standards-review-01'/'review.py')
r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r)
r.ROOT=Path(r'C:\Users\Donson\Documents\ChatGPT\Renly')
BASE='435727e7b517f86077aca97ba143d9752c7385f0'
CANDIDATE='f4922567918eb79b75ffd449b695f0ea050da0e1'
PACKAGE='paper/mentor-review-20261108'
HTML=PACKAGE+'/AegisDC-导师研究报告.html'
blob=lambda p,rev=CANDIDATE:r.blob(p,rev)
doc=lambda p,rev=CANDIDATE:r.doc(p,rev)
check=r.check
norm=lambda s:re.sub(r'\s+','',s).replace('**','').replace('`','')


class ReportParser(HTMLParser):
    def __init__(self):
        super().__init__();self.images=[];self.downloads=[];self.ids=[];self.anchors=[];self.remote=[];self.math_count=0
        self.headings=[];self.tables=[];self._heading=None;self._table=None;self._row=None;self._cell=None;self.text=[]
    def handle_starttag(self,tag,attrs):
        a=dict(attrs)
        if 'id' in a:self.ids.append(a['id'])
        if tag=='img' and a.get('src'):self.images.append(a)
        if tag=='a':
            if 'download' in a:self.downloads.append(a)
            if a.get('href','').startswith('#'):self.anchors.append(a['href'][1:])
        if tag in ('script','link','iframe') and (a.get('src') or a.get('rel')=='stylesheet'):self.remote.append(a)
        if tag=='math':self.math_count+=1
        if tag in ('h2','h3'):self._heading=[tag,[]]
        if tag=='table':self._table=[]
        if tag=='tr' and self._table is not None:self._row=[]
        if tag in ('th','td') and self._row is not None:self._cell=[]
    def handle_data(self,data):
        self.text.append(data)
        if self._heading is not None:self._heading[1].append(data)
        if self._cell is not None:self._cell.append(data)
    def handle_endtag(self,tag):
        if self._heading is not None and tag==self._heading[0]:
            self.headings.append((tag,''.join(self._heading[1])));self._heading=None
        if tag in ('th','td') and self._cell is not None:self._row.append(''.join(self._cell));self._cell=None
        if tag=='tr' and self._row is not None:self._table.append(self._row);self._row=None
        if tag=='table' and self._table is not None:self.tables.append(self._table);self._table=None


def payload(uri):
    kind,body=uri.split(',',1)
    if not kind.startswith('data:') or not kind.endswith(';base64'):raise AssertionError('Unexpected non-base64 offline payload')
    return base64.b64decode(body,validate=True)


def main():
    check(r.git('rev-parse','HEAD').decode().strip()==CANDIDATE,'Exact candidate HEAD at review start')
    check(r.git('rev-list','--count',BASE+'..'+CANDIDATE).decode().strip()=='1' and r.git('merge-base',BASE,CANDIDATE).decode().strip()==BASE,'Single bounded report commit against exact source cutoff')
    paths=r.tree(CANDIDATE,PACKAGE);r.fetch(CANDIDATE,paths)
    check(all((r.ROOT/p).read_bytes()==blob(p) for p in paths),'All mentor report working files equal immutable candidate',files=len(paths))
    for tree in ('src','configs','evidence','docs/mainline'):
        check(r.git('rev-parse',BASE+':'+tree)==r.git('rev-parse',CANDIDATE+':'+tree),'Original models, inputs, runs and mainline records unchanged '+tree)
    progress=doc('docs/mainline/progress.json')
    check(progress['research_trials']['attempts']==progress['research_trials']['completed']==164 and progress['research_trials']['robustness']['attempts']==0 and progress['research_execution_status']=='awaiting_user_review_at_checkpoint35','164 original runs retained;36 not started and execution still awaits user review')
    manifest=doc(PACKAGE+'/report-manifest.json')
    check(manifest['source_commit']==BASE and manifest['registered_runs_before']==manifest['registered_runs_after']==164 and manifest['new_physical_calls']==manifest['new_selector_calls']==manifest['new_inference_calls']==manifest['new_research_trials']==0 and manifest['field_calibration']=='PENDING' and manifest['full_research_goal']=='INCOMPLETE','Report manifest preserves existing-only research and incomplete-goal scope')
    source_files=manifest['source_files'];r.fetch(BASE,source_files)
    check(all(sha256(blob(p,BASE)).hexdigest()==v['sha256'] and len(blob(p,BASE))==v['bytes'] and blob(p,BASE)==blob(p) for p,v in source_files.items()),'Every declared source file matches cutoff Git bytes, length and SHA',sources=len(source_files))
    check(manifest['authoring_sha256']==sha256(blob('scripts/build_mentor_report.py')).hexdigest() and manifest['figure_authoring_sha256']==sha256(blob('scripts/render_mentor_report_figures.py')).hexdigest(),'Exact committed authoring tools match manifest identities')
    html=blob(HTML).decode();markdown=blob(PACKAGE+'/report.md').decode();parsed=ReportParser();parsed.feed(html)
    check(sha256(blob(HTML)).hexdigest()==manifest['html_sha256'],'Offline HTML bytes match manifest')
    check(not parsed.remote and len(parsed.images)==15 and parsed.math_count==8 and len(parsed.downloads)==23,'Self-contained15 images8 MathML equations23 downloads and no remote runtime')
    check(len(parsed.ids)==len(set(parsed.ids)) and set(parsed.anchors)<=set(parsed.ids),'All in-document anchors resolve to unique identities')
    figures=manifest['figures']
    check(len(figures)==15 and [f['number'] for f in figures]==list(range(1,16)),'All15 declared figures retained in fixed order')
    for f,img in zip(figures,parsed.images):
        png=blob(PACKAGE+'/'+f['path']);svgpath=str(Path(f['path']).with_suffix('.svg')).replace('\\','/');svg=blob(PACKAGE+'/'+svgpath)
        check(sha256(png).hexdigest()==f['sha256']==sha256(payload(img['src'])).hexdigest() and sha256(svg).hexdigest()==f['svg_sha256'],'Embedded PNG and downloadable SVG match declared local figure '+f['key'])
        check(f['title'] in markdown and f['caption'] in markdown and f['caption'] in html,'HTML/Markdown preserve same figure title and interpretation '+f['key'])
        if not f['source_path'].startswith('@'):
            check(png==blob(f['source_path'],BASE) and any(v['sha256']==f['svg_sha256'] and p.endswith('.svg') for p,v in source_files.items()),'Original accepted figure byte identities retained '+f['key'])
    downloads={x['download']:payload(x['href']) for x in parsed.downloads}
    check(len(downloads)==len(parsed.downloads)==len(manifest['downloads'])==23,'All23 offline payloads retain unique declared names')
    for d in manifest['downloads']:
        check(sha256(downloads[d['name']]).hexdigest()==d['sha256'] and len(downloads[d['name']])==d['bytes'],'Offline download exact SHA and byte length '+d['name'])
    model=doc('configs/full-facility-mainline-reserve-v6.json',BASE)
    check(len(model['domains'])==8 and len(model['entities'])==45 and len(model['parameters'])==113 and {k:len(v) for k,v in model['graphs'].items()}==dict(physical=43,functional=23,control_information=20,access=5),'Facility inventory and four relation counts reflect actual saved V6')
    check(downloads['V6-完整配置.json']==blob('configs/full-facility-mainline-reserve-v6.json',BASE) and downloads['V6-113参数.csv']==blob(PACKAGE+'/model-parameters.csv'),'Offline full model and companion parameter CSV preserve exact data identity')
    parameters=list(csv.DictReader(StringIO(downloads['V6-113参数.csv'].decode('utf-8-sig'))))
    check(len(parameters)==113 and [p['id'] for p in parameters]==[p['id'] for p in model['parameters']] and all(float(p['value'])==m['value'] and p['unit']==m['unit'] and json.loads(p['valid_range'])==m['valid_range'] and p['basis']==m['basis'] and p['source_note']==m['source_note'] for p,m in zip(parameters,model['parameters'])),'All113 downloadable parameters preserve value, SI units, range and provenance')
    entities=list(csv.DictReader(StringIO(downloads['V6-45实体.csv'].decode('utf-8-sig'))))
    check(entities==[{k:str(e[k]) for k in ('id','domain','kind','label')} for e in model['entities']],'All45 downloadable entity identities match V6')
    edges=list(csv.DictReader(StringIO(downloads['V6-四类关系.csv'].decode('utf-8-sig'))))
    check(edges==[dict(graph=g,**{k:str(e[k]) for k in ('id','from','to','kind')}) for g,rows in model['graphs'].items() for e in rows],'All91 downloadable edges preserve graph and shared endpoints')
    for name,path in [('paired-worlds.csv','evidence/mainline/research/34-paired-analysis/paired-worlds.csv'),('method-summary.csv','evidence/mainline/research/34-paired-analysis/method-summary.csv'),('paired-mask-effects.csv','evidence/mainline/research/35-ablation/paired-mask-effects.csv'),('arm-summary.csv','evidence/mainline/research/35-ablation/arm-summary.csv')]:
        check(downloads[name]==blob(path,BASE),'Original registered result download unchanged '+name)
    headings=[('h'+str(len(m.group(1))),m.group(2)) for line in markdown.splitlines() if (m:=re.match(r'^(#{2,3}) (.+)$',line))]
    check([(tag,norm(v)) for tag,v in parsed.headings]==[(tag,norm(v)) for tag,v in headings],'HTML and Markdown chapter/subchapter structure identical')
    md_tables=[];table=[]
    for line in markdown.splitlines()+['']:
        if line.startswith('| '):
            if not re.match(r'^\|\s*---',line):table.append([v.strip() for v in line.strip('|').split('|')])
        elif table:md_tables.append(table);table=[]
    html_tables=[t for t in parsed.tables if t[0]!=['参数ID','值','单位','范围','依据']]
    check([[[norm(c) for c in row] for row in t] for t in html_tables]==[[[norm(c) for c in row] for row in t] for t in md_tables],'All narrative numeric tables agree between HTML and Markdown')
    check(markdown.count('$$')==16,'Markdown retains all eight displayed equation blocks')
    index=manifest['source_index']
    check(len(index)==20 and all(v['path'] in source_files and ('source-'+key) in parsed.ids and source_files[v['path']]['sha256'] in markdown for key,v in index.items()),'All20 source references retain exact path/hash and HTML/Markdown anchors')
    claims=doc(PACKAGE+'/claims.json')
    check(len(claims)==5 and all(set(x['sources'])<=set(index) for x in claims),'All five main claims bind declared original evidence')
    figure_source=doc(PACKAGE+'/figures/figure-sources.json')
    check(figure_source['source_commit']==BASE and all(sha256(blob(p,BASE)).hexdigest()==v for p,v in figure_source['sources'].items()),'Two new explanatory figures use exact existing source records')
    check(len(figure_source['physical_edge_ids_in_diagram'])==len(set(figure_source['physical_edge_ids_in_diagram']))==21 and set(figure_source['physical_edge_ids_in_diagram'])<={x['id'] for x in model['graphs']['physical']},'New connection diagram uses only21 declared existing physical edges and identifies its selected scope')
    witness=doc('evidence/mainline/engineering/20-action-value/capture-01/check-results.json',BASE)
    example=next(c for c in witness['independent_cases'] if c['prior_fault']=='1/4')['result']['question_values'][0]['alternatives']
    check([(x['kind'],x['expected']['service_deficit_time_s']['value'],x['expected']['person_s']['value']) for x in example]==[('defer',25,0),('direct_intervention',20,20),('inspect_then_act',12.5,15.5)],'Worked risk chart values copied from archived100-second law, not a new inference')
    qa=doc(PACKAGE+'/qa/responsive-qa.json');visual=doc(PACKAGE+'/qa/visual-review.json')
    check(qa['status']=='PASS_MENTOR_REPORT_THREE_VIEWPORTS' and qa['javascript_errors']==[] and {q['viewport'] for q in qa['results']}=={412,1440,1920},'Existing browser QA records three viewports without errors; browser suite not rerun')
    check(all(sha256(blob(PACKAGE+'/qa/'+name)).hexdigest()==value for name,value in visual['screenshots'].items()),'Existing visual-review screenshot identities exact')
    for tool in ('scripts/build_mentor_report.py','scripts/render_mentor_report_figures.py'):
        module=ast.parse(blob(tool).decode());imports={n.module or '' for n in ast.walk(module) if isinstance(n,ast.ImportFrom)}|{v.name for n in ast.walk(module) if isinstance(n,ast.Import) for v in n.names}
        check(not any(x.startswith(('aegis_dc','patrol_rsi','torch','tensorflow','openai')) for x in imports),'Authoring tool imports no experiment/model implementation '+tool)
        calls=[n for n in ast.walk(module) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and isinstance(n.func.value,ast.Name) and n.func.value.id=='subprocess']
        check(all(n.func.attr=='check_output' and isinstance(n.args[0],ast.List) and [e.value for e in n.args[0].elts[:2]]==['git','show'] for n in calls),'Authoring subprocesses are immutable Git reads only '+tool)
    check(all(x in markdown for x in ('NO_PRACTICAL_GAIN','0.03515625','−0.96875','不是总体置信区间','注册研究共164次','第36—42项','当前按需核查主线中的智能体/RSI增量仍须独立评价')),'Primary negative conclusion, fixed count and untested future scope remain explicit')
    check(r.git('rev-parse','HEAD').decode().strip()==CANDIDATE,'Exact candidate HEAD unchanged at review completion')
    result=dict(status='PASS_BOUNDED_MENTOR_REPORT_STANDARDS',axis='Standards',base=BASE,candidate=CANDIDATE,hard_findings=[],heuristic_suggestions=[],checks=r.checks,actually_viewed_new_figures=['mentor-facility-systems.png','mentor-value-frozen.png'],scope=dict(physical_calls=0,selector_calls=0,inference_calls=0,nonce_reads=0,seed_derivations=0,tests=0,browser_suite_runs=0,project_code_imports=0,tracked_edits=0),reviewed_delivery_sha256={p:sha256(blob(p)).hexdigest() for p in sorted(paths)})
    (OUT/'report.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:v for k,v in result.items() if k not in ('checks','reviewed_delivery_sha256')},ensure_ascii=False));print('Bounded saved/static checks:',len(r.checks))


if __name__=='__main__':main()
