"""Narrow saved/static closure of mentor report prose; no browser or model calls."""
from fractions import Fraction
from hashlib import sha256
import importlib.util
import json
from pathlib import Path
import re

OUT=Path(__file__).resolve().parent
previous=OUT.parent/'mentor-standards-review-01'/'review.py'
spec=importlib.util.spec_from_file_location('original_report_review',previous)
old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)
r=old.r
INITIAL='f4922567918eb79b75ffd449b695f0ea050da0e1'
CANDIDATE='212dbfca087bce33409996157443efaa860ca577'
BASE=old.BASE;PACKAGE=old.PACKAGE;HTML=old.HTML
blob=lambda p,rev=CANDIDATE:r.blob(p,rev)
doc=lambda p,rev=CANDIDATE:r.doc(p,rev)
check=r.check


def main():
    check(r.git('rev-parse',CANDIDATE).decode().strip()==CANDIDATE,'Exact immutable corrective candidate resolved')
    check(r.git('merge-base','--is-ancestor',INITIAL,CANDIDATE)==b'','Original reviewed report retained as immutable ancestor')
    for path in ('src','configs','evidence','docs/mainline',PACKAGE+'/figures'):
        check(r.git('rev-parse',INITIAL+':'+path)==r.git('rev-parse',CANDIDATE+':'+path),'Original research/model/source/figure subtree unchanged '+path)
    paths=r.tree(CANDIDATE,PACKAGE);r.fetch(CANDIDATE,paths)
    check(PACKAGE+'/qa/revision-check.json' in paths and PACKAGE+'/report.md' in paths,'Corrective report blobs read from fixed Git candidate only; concurrent working files excluded')
    before=blob(HTML,INITIAL).decode();after=blob(HTML).decode();first=old.ReportParser();first.feed(before);current=old.ReportParser();current.feed(after)
    for tag in ('style','script','math'):
        check(re.findall(r'<'+tag+r'\b[^>]*>.*?</'+tag+r'>',before,re.S)==re.findall(r'<'+tag+r'\b[^>]*>.*?</'+tag+r'>',after,re.S),'Original rendered component byte-identical '+tag)
    check(first.images==current.images and first.downloads==current.downloads and len(current.images)==15 and len(current.downloads)==23 and current.math_count==8,'All15 embedded images23 downloads8 equations unchanged')
    manifest=doc(PACKAGE+'/report-manifest.json');prior=doc(PACKAGE+'/report-manifest.json',INITIAL)
    check(manifest['source_commit']==BASE and manifest['html_sha256']==sha256(blob(HTML)).hexdigest() and manifest['authoring_sha256']==sha256(blob('scripts/build_mentor_report.py')).hexdigest(),'Updated HTML and authoring manifest exactly bound')
    check(manifest['figures']==prior['figures'] and manifest['downloads']==prior['downloads'],'All original figure and data identities preserved')
    check(len(manifest['source_index'])==21 and set(manifest['source_index'])-set(prior['source_index'])=={'S21'} and manifest['source_index']['S21']['path']=='docs/mainline/30-comparison-protocol-v1.json','Only explicit compressed-time protocol source added')
    check(all(sha256(blob(p,BASE)).hexdigest()==v['sha256'] and len(blob(p,BASE))==v['bytes'] and blob(p,BASE)==blob(p) for p,v in manifest['source_files'].items()),'All21-citation source bindings retain cutoff evidence bytes')
    revision=doc(PACKAGE+'/qa/revision-check.json')
    check(revision['original_browser_qa_commit']==INITIAL and revision['original_html_sha256']==sha256(blob(HTML,INITIAL)).hexdigest() and revision['current_html_sha256']==sha256(blob(HTML)).hexdigest() and revision['new_browser_execution'] is False,'Revision honestly separates old browser QA from new static-only correction')
    check(all(v=='BYTE_IDENTICAL' for v in revision['unchanged_components'].values()) and revision['new_research_trials']==revision['new_physical_calls']==revision['new_selector_calls']==revision['new_inference_calls']==0,'Static revision states unchanged presentation components and no added science calls')
    old_qa=r.tree(INITIAL,PACKAGE+'/qa')
    check(all(blob(p,INITIAL)==blob(p) for p in old_qa),'Original browser QA, screenshots and build failure history retained unchanged')
    markdown=blob(PACKAGE+'/report.md').decode()
    model=doc('configs/full-facility-mainline-reserve-v6.json',BASE);params={x['id']:x['value'] for x in model['parameters']}
    check(params['inspection_time']==30 and params['walk_short']==60 and params['walk_long']==120,'New baseline timing rows match actual V6 values')
    check(all(text in markdown and text in after for text in ('基准检查时间','基准短路径时间','基准长路径时间','检查/专业作业1秒，短/长行走1/2秒','评价窗为10秒','不能换算成现场巡检周期或真实节省时长','第3章100秒有限决策树算例分别定义')),'HTML and Markdown distinguish baseline, registered compressed and100-second law times')
    check('Ten-second compressed synthetic engineering windows use positive 1 s professional work and 1/2 s routes' in json.dumps(doc('docs/mainline/30-comparison-protocol-v1.json',BASE)),'Compressed timing is an existing protocol statement')
    probabilities=[Fraction(1,4)*Fraction(4,5),Fraction(1,4)*Fraction(1,5),Fraction(3,4)*Fraction(1,10),Fraction(3,4)*Fraction(9,10)]
    deficits=[30,100,20,0]
    check(probabilities==[Fraction(1,5),Fraction(1,20),Fraction(3,40),Fraction(27,40)] and sum(probabilities)==1 and sum(p*d for p,d in zip(probabilities,deficits))==Fraction(25,2),'Four declared saved-law branches have exact unit mass and12.5-second weighted deficit')
    positive=probabilities[0]+probabilities[2]
    check(positive==Fraction(11,40) and probabilities[0]/positive==Fraction(8,11) and 10+positive*20==Fraction(31,2),'Printed positive probability/posterior and15.5-person-second arithmetic exact')
    witness=doc('evidence/mainline/engineering/20-action-value/capture-01/check-results.json',BASE)
    alternatives=next(x for x in witness['independent_cases'] if x['prior_fault']=='1/4')['result']['question_values'][0]['alternatives']
    check([(x['expected']['service_deficit_time_s']['value'],x['expected']['person_s']['value']) for x in alternatives]==[(25,0),(20,20),(12.5,15.5)],'New derivation closes onto existing stored alternatives without a model call')
    check(all(text in markdown and text in after for text in ('0.25×0.8=0.20','0.25×0.2=0.05','0.75×0.1=0.075','0.75×0.9=0.675','10＋0.275×20=15.5人秒','未使用现场校准概率')),'Both deliverables retain all four branches, separate personnel quantity and synthetic-law scope')
    md_tables=[];table=[]
    for line in markdown.splitlines()+['']:
        if line.startswith('| '):
            if not re.match(r'^\|\s*---',line):table.append([v.strip() for v in line.strip('|').split('|')])
        elif table:md_tables.append(table);table=[]
    html_tables=[t for t in current.tables if t[0]!=['参数ID','值','单位','范围','依据']]
    check([[[old.norm(c) for c in row] for row in t] for t in html_tables]==[[[old.norm(c) for c in row] for row in t] for t in md_tables],'All corrected numeric tables agree in HTML and Markdown')
    progress=doc('docs/mainline/progress.json')
    check(progress['research_trials']['attempts']==164 and progress['research_trials']['robustness']['attempts']==0 and manifest['new_research_trials']==manifest['new_inference_calls']==0,'Original164 runs and zero robustness/new inference retained')
    check('NO_PRACTICAL_GAIN' in markdown and manifest['full_research_goal']=='INCOMPLETE','Original primary negative result and unfinished goal unchanged')
    check(r.git('rev-parse',CANDIDATE).decode().strip()==CANDIDATE,'Reviewed corrective commit identity unchanged on completion')
    result=dict(status='PASS_NARROW_MENTOR_STANDARDS_CLOSURE',axis='Standards',initial_candidate=INITIAL,candidate=CANDIDATE,base_source=BASE,hard_findings=[],heuristic_suggestions=[],closed_spec_prose_items=['Explicit baseline/registered/witness time scopes.','Four saved-law probability branches and separate exact SI arithmetic.'],checks=r.checks,scope=dict(physical_calls=0,selector_calls=0,inference_calls=0,seed_derivations=0,nonce_reads=0,tests=0,browser_runs=0,project_code_imports=0,tracked_edits=0),qa_boundary='Browser QA is retained only for f492; current212 correction received static closure, no browser fallback.')
    (OUT/'report.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:v for k,v in result.items() if k!='checks'},ensure_ascii=False));print('Focused saved/static checks:',len(r.checks))


if __name__=='__main__':main()
