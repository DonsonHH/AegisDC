"""Bind a report-only delivery and preserve independent reviews; no science calls."""
import hashlib,json,subprocess,zipfile
from pathlib import Path
root=Path(__file__).resolve().parents[1];out=root/'paper/mentor-review-20261108'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()=='212dbfca087bce33409996157443efaa860ca577'
assert not (out/'delivery-manifest.json').exists()
sha=lambda b:hashlib.sha256(b).hexdigest()
archives={}
def archive(relative,members):
    path=root/relative;path.parent.mkdir(parents=True,exist_ok=True);record={}
    with zipfile.ZipFile(path,'x',zipfile.ZIP_DEFLATED) as z:
        for name,p in members:
            raw=p.read_bytes();info=zipfile.ZipInfo(name,date_time=(2026,11,8,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED
            z.writestr(info,raw);record[name]=dict(sha256=sha(raw),bytes=len(raw))
    archives[relative]=record
review_sources=[('spec','.work/mentor-spec-review-01','final-report.md'),('standards-original','.work/mentor-standards-review-01','standards-review.md'),('standards-closure','.work/mentor-standards-closure-01','standards-review.md')]
for name,directory,report in review_sources:
    base=root/directory
    members=[(p.relative_to(base).as_posix(),p) for p in sorted(base.rglob('*')) if p.is_file() and '__pycache__' not in p.parts and p.suffix not in ['.pyc','.pyo']]
    assert members and (base/report).is_file()
    archive('paper/mentor-review-20261108/reviews/'+name+'.zip',members)
    target=out/'reviews'/('spec.md' if name=='spec' else name+'.md')
    with target.open('xb') as f:f.write((base/report).read_bytes())
tools=['scripts/build_mentor_report.py','scripts/render_mentor_report_figures.py','scripts/check_mentor_report.mjs','scripts/verify_mentor_report.py','.work/seal_mentor_report_delivery.py']
archive('paper/mentor-review-20261108/authoring-originals.zip',[(p,root/p) for p in tools])
files=[p for p in out.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix not in ['.pyc','.pyo']]
files += [root/p for p in tools if not p.startswith('.work/')]
files += [root/'README.md',root/'.gitattributes']
artifacts={p.relative_to(root).as_posix():dict(sha256=sha(p.read_bytes()),bytes=p.stat().st_size) for p in sorted(files)}
record=dict(schema='aegisdc-mentor-report-delivery-v1',data_source='435727e7b517f86077aca97ba143d9752c7385f0',reviewed_report_content='212dbfca087bce33409996157443efaa860ca577',spec_original_findings=2,spec_unresolved=0,standards_initial_checks=161,standards_closure_checks=149,standards_unresolved=0,artifacts=artifacts,archives=archives,excluded=['Self-hash of this manifest','Automatic Python/browser/runtime caches'],registered_research_runs=164,new_research_trials=0,new_physical_calls=0,new_selector_calls=0,new_inference_calls=0,research_goal='INCOMPLETE_PAUSED_FOR_REVIEW',publication_scope='Report-only delivery. Core/runtime/config/tests/workflow unchanged from successful435727e7; commit requests skip-ci so publication does not start numerical regression. Report data, browser reading controls atf492, static212text closure and fresh exact delivery are verified separately.',browser_opening='Automatic local file opening blocked by browser protocol policy. No workaround attempted; HTML is delivered as a file and GitHub Markdown supplies a safer static reading surface.')
with (out/'delivery-manifest.json').open('x',encoding='utf-8',newline='\n') as f:f.write(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(status='SEALED_EXISTING_EVIDENCE_REPORT',artifacts=len(artifacts),archives={p:len(m) for p,m in archives.items()},unresolved_findings=0,new_trials=0)))
