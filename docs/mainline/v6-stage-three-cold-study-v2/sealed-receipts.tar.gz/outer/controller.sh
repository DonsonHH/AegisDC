#!/bin/bash
set -uo pipefail
umask 077
cd '/share/home/renly/renly-patrol-rsi/mainline/V6-cold-launch-release-v1/source'
set -C
set +e
/share/home/renly/miniconda3/bin/python -I -B /share/home/renly/renly-patrol-rsi/mainline/V6-cold-launch-release-v1/source/scripts/cold3_study_launch.py start --manifest-sha 491043eac0c2441623e9666f8eb249fd7ba43d564c99160e458de5bd9ebfac5b --approval-revision be0fe1a92437510cb24234579982212b0f4c7fd3 > '/share/home/renly/renly-patrol-rsi/mainline/V6-cold-study-v2-controller-be0fe1a9/stdout.log' 2> '/share/home/renly/renly-patrol-rsi/mainline/V6-cold-study-v2-controller-be0fe1a9/stderr.log'
rc=$?
printf '%s\n' "$rc" > '/share/home/renly/renly-patrol-rsi/mainline/V6-cold-study-v2-controller-be0fe1a9/exit.pending'
ln '/share/home/renly/renly-patrol-rsi/mainline/V6-cold-study-v2-controller-be0fe1a9/exit.pending' '/share/home/renly/renly-patrol-rsi/mainline/V6-cold-study-v2-controller-be0fe1a9/exit.status'
exit "$rc"
