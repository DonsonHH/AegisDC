"""Preserve a reviewer prose correction and bind the final metadata-only review."""
import hashlib
import json
from pathlib import Path
import subprocess

ROOT=Path('C:/Users/Donson/Documents/ChatGPT/Renly')
OUT=Path(__file__).resolve().parent
PIN='c7fa51b111ad1ae73e02ce67eea2e59bd5e0e146'
BASE='2dfe5537e4f95fa605f325b060ef32223dafb4f6'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
git=lambda *args:subprocess.check_output(['git',*args],cwd=ROOT)
hashes={}

def read(path):
    raw=git('show',PIN+':'+path)
    hashes[path]=dict(sha256=sha(raw),bytes=len(raw))
    return raw.decode()

def save(name,data):
    with (OUT/name).open('x',encoding='utf-8',newline='\n') as stream:
        stream.write(json.dumps(data,ensure_ascii=False,indent=2,allow_nan=False)+'\n')

original=(OUT/'report.md').read_text(encoding='utf-8')
old='Issued tasks, completions and arrived inspection reports each total 104.'
new='There are 104 issued inspection tasks and timing rows, 103 completed inspections and 103 arrived reports. The remaining task was rejected before any sample/report; its metadata is explicitly null with a reason.'
assert old in original
with (OUT/'report-final.md').open('x',encoding='utf-8',newline='\n') as stream:
    stream.write(original.replace(old,new))
save('reviewer-prose-correction.json',dict(classification='ADDITIVE_REVIEWER_PROSE_CORRECTION',
    original_report_sha256=sha((OUT/'report.md').read_bytes()),
    original_manifest_sha256=sha((OUT/'manifest.json').read_bytes()),
    original_statement=old,corrected_statement=new,
    scope='The independent facts JSON and every source/output assertion already used the correct counts. The saved readout is correct; preserve the initial reviewer prose and use report-final.md.',
    new_project_calls=0))

report=read('docs/mainline/audits/20261108-pre36/audit-report.md')
classification=json.loads(read('docs/mainline/audits/20261108-pre36/classification-corrections.json'))
helper=read('tests/historical_research_checkout.py')
runner=read('scripts/check_historical_ci_contracts.py')
plan=json.loads(read('docs/mainline/audits/20261108-pre36/historical-ci-plan.json'))
tests={path:read(path) for path in ('tests/test_registered_development.py',
    'tests/test_confirmation_freeze.py','tests/test_ablation_masks.py')}
read('scripts/seal_pre36_audit.py')
assert "HISTORICAL_SOURCE='"+BASE+"'" in helper
assert "'core.autocrlf=false','worktree','add','--detach'" in helper
assert "if actual!=HISTORICAL_SOURCE:raise AssertionError" in helper
assert "['git','worktree','remove',str(checkout)]" in helper
assert all('with historical_checkout() as historical:' in text and 'cwd=historical' in text for text in tests.values())
assert 'test_old_lock_refuses_changed_live_source' in tests['tests/test_registered_development.py']
assert 'Frozen protocol, source or working bytes differ' in tests['tests/test_registered_development.py']
assert not git('diff','--name-only',BASE,PIN,'--','docs/mainline/30-comparison-protocol-v1.json',
    'docs/mainline/evidence/30-confirmation-execution-lock.json',
    'docs/mainline/evidence/30-ablation-execution-lock.json',
    'scripts/registered_development.py','scripts/prepare_confirmation.py','scripts/prepare_ablation.py').strip()
assert plan['historical_source']==BASE
assert classification['closure_api_account']['instrumented_in_process_total']==37
assert classification['closure_api_account']['saved_cli_subprocess_invocations']==1
assert classification['closure_api_account']['derived_all_process_closure_assessments']==38
assert classification['fixture_guard_classification']['supplement']=='POST_EXECUTION_SAVED_GIT_IDENTITY_CHECK_ONLY'
assert classification['historical_ci']['finite_public_mask_selector_calls']==1
assert classification['registered_research_trials_before']==classification['registered_research_trials_after']==164
assert '部分覆盖' in report and '误报/漏报缺冻结真值或机会分母' in report
assert 'NO_PRACTICAL_GAIN' in report and '0.03515625' in report
facts=json.loads((OUT/'independent-readout-facts.json').read_bytes())
assert (facts['issued_inspections'],facts['completed_inspections'],facts['arrived_feedback'])==(104,103,103)
groups={row['arm']:row for row in facts['method_denominators'] if row['phase']=='confirmation'}
assert groups['evidence_consistent_contingent']['completed_inspections']==9
assert groups['one_observation_lookahead']['completed_inspections']==12
assert groups['evidence_consistent_contingent']['issue_to_report_mean_s']==groups['one_observation_lookahead']['issue_to_report_mean_s']==1.75
save('historical-cli-and-final-report-static-review.json',dict(source=PIN,status='PASS',
    report='R6 explicitly partial; unmeasured false/missed-report truth, prevention and registered closure remain limitations. 9/12 completed-report counts, expiry and compressed 1.75s timing reconcile with independent saved readout.',
    historical_helper='Three old positive CLI contracts use a verified detached exact 2dfe checkout with LF bytes; a new live-source negative test retains the old lock refusal. No original runner, protocol or execution lock is relaxed.',
    accounting='37 instrumented parent closure calls plus one saved CLI child =38 derived. Two omitted fixtures remain post-execution identity evidence only. One saved historical public-mask selector is separately declared.',
    file_hashes=hashes,reviewer_project_calls=0,reviewer_tests=0,reviewer_selector_calls=0,
    scope='Static source and already saved arithmetic only; no historical checkout or test helper was invoked by this reviewer.'))
manifest=dict(schema='aegisdc-independent-spec-final-readout-review-v1',
    readout_source='db33b76c133f0cce12c9a6d197971882e9108376',metadata_review_source=PIN,
    authoritative_report='report-final.md',original_review_preserved=True,
    artifacts={path.name:dict(sha256=sha(path.read_bytes()),bytes=path.stat().st_size)
        for path in sorted(OUT.iterdir()) if path.is_file() and path.name!='final-manifest.json'},
    excluded=['Self-hash','Runtime caches'])
save('final-manifest.json',manifest)
print(json.dumps(dict(status='PASS',artifacts=len(manifest['artifacts']),
    final_manifest_sha256=sha((OUT/'final-manifest.json').read_bytes()),project_calls=0)))
