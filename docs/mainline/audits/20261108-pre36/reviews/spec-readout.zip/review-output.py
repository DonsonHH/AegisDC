"""Independently audit committed descriptive readouts from saved native records."""
import csv
from collections import Counter, defaultdict
from datetime import datetime, timezone
from fractions import Fraction
import hashlib
import io
import json
import math
from pathlib import Path
import subprocess
import traceback
import zipfile

ROOT = Path('C:/Users/Donson/Documents/ChatGPT/Renly')
OUT = Path(__file__).resolve().parent
PIN = 'db33b76c133f0cce12c9a6d197971882e9108376'
AUTHOR = '1e07b3beca467f5ad0e67ff2ac9455a9454e8ffd'
DATA = '2dfe5537e4f95fa605f325b060ef32223dafb4f6'
PREFIX = 'evidence/mainline/engineering/pre36-readout/readout-01/'
PLAN = 'docs/mainline/audits/20261108-pre36/saved-readout-plan.json'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
hashes = {}


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)


def committed(path, revision=PIN):
    raw = git('show', revision + ':' + path)
    hashes[revision + ':' + path] = dict(sha256=sha(raw), bytes=len(raw))
    return raw


def save(name, value):
    with (OUT/name).open('x', encoding='utf-8', newline='\n') as stream:
        stream.write(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False)+'\n')


def close(left, right):
    assert math.isclose(left, right, rel_tol=0, abs_tol=1e-8), (left, right)


def csv_matches(raw, records):
    assert b'\r\n' not in raw
    reader = csv.DictReader(io.StringIO(raw.decode('utf-8-sig')))
    assert reader.fieldnames == list(records[0])
    expected = [{key: '' if value is None else json.dumps(value, ensure_ascii=False, sort_keys=True)
        if isinstance(value, (dict, list)) else str(value) for key, value in row.items()} for row in records]
    assert list(reader) == expected


save('start.json', dict(source=PIN, author_source=AUTHOR, original_data_source=DATA,
     started_utc=datetime.now(timezone.utc).isoformat(), scope='SAVED_BLOBS_AND_ARITHMETIC_ONLY'))
try:
    original_manifest = json.loads(committed(PREFIX+'manifest.json'))
    delivered = {}
    for name, entry in original_manifest['artifacts'].items():
        raw = committed(PREFIX+name)
        assert sha(raw) == entry['sha256'] and len(raw) == entry['bytes'], name
        delivered[name] = raw
    assert len(delivered) == 11
    start = json.loads(delivered['start.json'])
    receipt = json.loads(delivered['receipt.json'])
    journal = [json.loads(line) for line in delivered['attempts.jsonl'].decode().splitlines()]
    assert [line['event'] for line in journal] == ['STARTED', 'COMPLETED']
    assert journal[0] == start and journal[1]['source'] == AUTHOR
    assert start['source'] == receipt['source'] == AUTHOR
    assert start['data_source'] == receipt['data_source'] == DATA
    assert receipt['status'] == 'PASS_SAVED_ONLY_READOUT_COMPLETION'
    assert receipt['runs'] == receipt['archives'] == receipt['registered_runs'] == 164
    for field in ('new_physical_calls', 'new_selector_calls', 'new_inference_calls', 'new_research_trials'):
        assert receipt[field] == 0
    plan_raw = committed(PLAN, AUTHOR)
    tool_raw = committed('scripts/complete_registered_readout.py', AUTHOR)
    assert sha(plan_raw) == start['plan_sha256'] and sha(tool_raw) == start['tool_sha256']
    assert tool_raw == committed('scripts/complete_registered_readout.py', 'df05d4403571dec278036ecbaa22564c2b08c9fd')
    plan = json.loads(plan_raw)
    declared = json.loads(delivered['input-manifest.json'])
    assert declared['data_source'] == DATA
    tree = {}
    for line in git('ls-tree', '-r', '-z', DATA).split(b'\0'):
        if line:
            header, path = line.split(b'\t', 1)
            _, kind, git_blob = header.split()
            if kind == b'blob': tree[path.decode()] = git_blob.decode()
    saved = {}
    for path, entry in declared['files'].items():
        raw = (ROOT/path).read_bytes()
        actual_blob = hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
        assert tree[path] == entry['git_blob'] == actual_blob, path
        assert sha(raw) == entry['sha256'] and len(raw) == entry['bytes'], path
        saved[path] = raw
        hashes[DATA+':'+path] = dict(sha256=sha(raw), bytes=len(raw), git_blob=actual_blob)
    assert len(saved) == 658
    protocol = json.loads(saved['docs/mainline/30-comparison-protocol-v1.json'])
    primary = json.loads(saved['evidence/mainline/research/34-paired-analysis/results.json'])
    rows = json.loads(delivered['run-readout.json'])
    timing = json.loads(delivered['inspection-timing.json'])
    summaries = json.loads(delivered['method-summary.json'])
    coverage = json.loads(delivered['metric-coverage.json'])
    assert len(rows) == 164 and len(timing) == receipt['inspection_timing_rows'] == 104
    for name, values in [('run-readout', rows), ('inspection-timing', timing), ('method-summary', summaries)]:
        csv_matches(delivered[name+'.csv'], values)
    assert [row['metric'] for row in coverage] == protocol['comparison']['report_separately']
    assert len(coverage) == receipt['promised_metrics'] == 18
    timing_by_key = {}
    for row in timing:
        key = (row['phase'], row['world_id'], row['arm'], row['task_id'])
        assert key not in timing_by_key
        timing_by_key[key] = row
    expected_files = {'docs/mainline/30-comparison-protocol-v1.json',
                      'evidence/mainline/research/34-paired-analysis/results.json'}
    expected_timing = {}
    independent_rows = []
    phase_counts = Counter()
    provenance_issues = 0
    seen_runs = set()
    confirmed = {'CONFIRMED_AT_OR_ABOVE_THRESHOLD', 'CONFIRMED_BELOW_THRESHOLD'}
    for exported in rows:
        phase, world, arm = (exported[key] for key in ('phase', 'world_id', 'arm'))
        key = (phase, world, arm)
        assert key not in seen_runs
        seen_runs.add(key); phase_counts[phase] += 1
        archive = exported['archive']
        parent = archive.rsplit('/', 1)[0]+'/'
        for name in ('start.json', 'terminal.json', 'audit.json', 'originals.zip'):
            expected_files.add(parent+name)
        began = json.loads(saved[parent+'start.json'])
        terminal = json.loads(saved[parent+'terminal.json'])
        audit = json.loads(saved[parent+'audit.json'])
        assert terminal['status'] == 'COMPLETED' and terminal['physical_returned'] is True
        assert not audit['hard_violations']
        for name in ('start.json', 'audit.json', 'originals.zip'):
            assert sha(saved[parent+name]) == terminal['artifacts'][name]
        with zipfile.ZipFile(io.BytesIO(saved[archive])) as z:
            assert sorted(z.namelist()) == sorted(['scenario.json', 'run.json', 'private-state.jsonl', 'balances.jsonl'])
            native_raw = z.read('run.json')
        entry = declared['native_members'][archive]['run.json']
        assert entry == dict(sha256=sha(native_raw), bytes=len(native_raw))
        native = json.loads(native_raw)
        assert (began['world_id'], began['arm']) == (world, arm)
        assert native['code_identity']['git_commit'] == began['source'] == terminal['source'] == exported['execution_source']
        assert native['inputs']['dispatch_program']['closure_program'] is None
        duration = began['duration_s']
        snapshot = native['inspection_public_snapshot']
        assert snapshot['as_of_s'] == duration
        tasks = {task['id']: task for task in native['work_records']}
        assert len(tasks) == len(native['work_records'])
        bindings = {binding['task_id']: binding for binding in native['inspection_public_models']['bindings']}
        models = {row['model']['id']: row for row in native['inspection_public_models']['nonfixed_profile']['models']}
        action_bindings = {binding['task_id']: binding for binding in native['inputs']['intervention_program']['bindings']}
        records = {record['id']: record for record in snapshot['records']}
        samples = {event['task_id']: event for event in native['inspection_private_audit']['events'] if 'record_id' in event}
        feedback = native['inspection_public_feedback']
        findings = Counter()
        feedback_tasks = {}
        for finding in feedback:
            task_id = finding['task_id']
            assert task_id not in feedback_tasks
            feedback_tasks[task_id] = finding
            record = records[finding['record_id']]
            binding = bindings[task_id]; task = tasks[task_id]; sample = samples[task_id]
            model = models[binding['model_id']]
            assert task['status'] == 'completed'
            assert task['issued_at_s'] <= task['work_started_at_s'] <= task['completed_at_s']
            assert finding['observed_at_s'] == task['completed_at_s'] == sample['source_sample_at_s']
            assert finding['record_id'] == binding['record_id'] == sample['record_id']
            assert finding['arrived_at_s'] == finding['observed_at_s']+binding['arrival_latency_s'] <= duration
            assert finding['valid_until_s'] == finding['observed_at_s']+binding['validity_s']
            assert finding['provenance'] == binding['provenance']
            for field in ('source_id', 'target_id', 'observable_id'):
                assert finding[field] == record[field] == model[field]
            for field in ('observed_at_s', 'arrived_at_s', 'valid_until_s', 'provenance'):
                assert finding[field] == record[field]
            assert finding['scope'] == 'NAMED_SIGNAL_THRESHOLD_ONLY_NOT_FAULT_DIAGNOSIS'
            assert finding['additional_evidence_factor'] is False
            expected_finding = 'UNCONFIRMED'
            if model['model']['kind'] == 'numeric' and record['quality']['status'] == 'bounded':
                value, error, threshold = map(Fraction, (record['value'], record['quality']['error_bound'], binding['confirmation_threshold']))
                if value-error >= threshold: expected_finding = 'CONFIRMED_AT_OR_ABOVE_THRESHOLD'
                elif value+error < threshold: expected_finding = 'CONFIRMED_BELOW_THRESHOLD'
            availability = ('missing' if record['value'] is None else 'expired'
                if record['valid_until_s'] is not None and duration >= record['valid_until_s'] else 'current')
            assert finding['confirmation'] == expected_finding
            assert finding['availability'] == record['availability'] == availability
            assert finding['current_confirmation'] is (availability == 'current' and expected_finding in confirmed)
            findings[expected_finding] += 1
        for task_id in sorted(set(tasks) & set(bindings)):
            task, binding = tasks[task_id], bindings[task_id]
            sample, finding = samples.get(task_id, {}), feedback_tasks.get(task_id)
            item = dict(phase=phase, world_id=world, arm=arm, task_id=task_id,
                task_status=task['status'], issued_at_s=task['issued_at_s'], site_arrival_at_s=task.get('arrived_at_s'),
                work_started_at_s=task.get('work_started_at_s'), completed_at_s=task.get('completed_at_s'),
                sampled_at_s=sample.get('source_sample_at_s'), record_id=sample.get('record_id'),
                public_report_arrived_at_s=finding['arrived_at_s'] if finding else None,
                source_id=finding['source_id'] if finding else None, target_id=finding['target_id'] if finding else None,
                observable_id=finding['observable_id'] if finding else None, provenance=finding['provenance'] if finding else None,
                valid_until_s=finding['valid_until_s'] if finding else None,
                confirmation_scope=finding['scope'] if finding else None,
                additional_evidence_factor=finding['additional_evidence_factor'] if finding else None,
                report_metadata_status='ARRIVED_NATIVE_FEEDBACK' if finding else 'NO_ARRIVED_REPORT_METADATA',
                historical_named_signal_finding=finding['confirmation'] if finding else None,
                endpoint_availability=finding['availability'] if finding else None,
                endpoint_current_confirmation=finding['current_confirmation'] if finding else None,
                observation_status='PUBLIC_REPORT_ARRIVED' if finding else 'SAMPLED_NOT_PUBLICLY_ARRIVED' if sample else 'NO_SAMPLE',
                issue_to_report_s=finding['arrived_at_s']-task['issued_at_s'] if finding else None,
                sample_to_report_s=finding['arrived_at_s']-finding['observed_at_s'] if finding else None)
            expected_timing[key+(task_id,)] = item
        totals = audit['totals']
        close(totals['demand_service_unit_s']-totals['delivered_service_unit_s'], totals['unserved_service_unit_s'])
        close(totals['paid_person_s'], math.fsum(totals[name] for name in ('worker_travel_person_s','worker_work_person_s','worker_wait_person_s')))
        for name, value in totals.items(): assert exported[name] == value
        completed_inspections = sum(task['status']=='completed' for task_id, task in tasks.items() if task_id in bindings)
        completed_interventions = sum(task['status']=='completed' for task_id, task in tasks.items() if task_id in action_bindings)
        assert (completed_inspections, completed_interventions) == (audit['completed_inspections'], audit['completed_interventions'])
        statuses = Counter(task['status'] for task in tasks.values())
        expected = dict(phase=phase, world_id=world, family=began['family'], arm=arm, original_index=began['index'],
            execution_source=began['source'], archive=archive, duration_s=duration, **totals,
            completed_inspections=completed_inspections, completed_interventions=completed_interventions,
            issued_inspection_tasks=len(set(tasks) & set(bindings)), task_dispositions=dict(statuses),
            aborted_or_rejected_tasks=statuses['aborted']+statuses['rejected'],
            nonterminal_tasks=sum(count for status,count in statuses.items() if status not in ('completed','aborted','rejected')),
            arrived_inspection_feedback=len(feedback), source_record_binding_checks_passed=len(feedback),
            historical_named_threshold_findings=None if snapshot['provenance_issues'] else sum(findings[enum] for enum in confirmed),
            current_named_threshold_findings=None if snapshot['provenance_issues'] else sum(finding['current_confirmation'] for finding in feedback),
            threshold_findings=dict(findings), unconfirmed_named_signal_readings=findings['UNCONFIRMED'],
            provenance_status='ISSUE_TIMING_NOT_INFERRED_FROM_FINAL_SNAPSHOT' if snapshot['provenance_issues'] else 'MATCHED_NATIVE_TASK_RECORD_SCOPE')
        provenance_issues += bool(snapshot['provenance_issues'])
        quality = Counter(('BOUND_CONTAINS_SIGNAL' if event['declared_bound_contains_signal'] else 'BOUND_FAILED')
            for event in native['inspection_private_audit']['events'] if 'declared_bound_contains_signal' in event)
        computation = native['policy_computation_audit']; model_counts = Counter()
        for entry in computation:
            assert entry['scope'] == 'DIAGNOSTIC_WALL_TIME_ONLY_NOT_PHYSICAL_TIME_OR_POLICY_INPUT'
            for name, value in entry['model_evaluations'].items():
                assert type(value) is int and value >= 0
                model_counts[name] += value
        structure = native.get('ablation_execution_audit')
        structural_count = structure['schema_component_identity_validations'] if structure is not None else None
        assert (phase == 'ablation') is (structure is not None)
        applied = [event for event in native['intervention_private_audit']['events'] if event['outcome']=='APPLIED']
        assert len(applied) == len(audit['applied_effects'])
        expected.update(numeric_bound_diagnostic=dict(quality), selector_instants=len(computation),
            model_evaluations=dict(model_counts), schema_component_identity_validations=structural_count,
            structural_check_status='NATIVE_SEPARATE_COUNTER' if structure is not None else 'NOT_INSTRUMENTED_IN_ORIGINAL',
            selector_wall_seconds=math.fsum(entry['elapsed_ns'] for entry in computation)/1e9,
            applied_effects=len(applied), arrived_applied_feedback=sum(entry['outcome']=='APPLIED' for entry in native['intervention_public_feedback']),
            verified_closure='NOT_EVALUATED_WITHOUT_POST_ACTION_PROTOCOL', generic_fault_confirmation='NOT_OPERATIONALIZED',
            misleading_report_truth='NOT_OPERATIONALIZED_NO_CUE_TRUTH_MAPPING',
            missed_distinguishable_reports='NOT_OPERATIONALIZED_NO_OPPORTUNITY_DENOMINATOR',
            pre_failure_detection='NOT_TESTED_NO_FROZEN_PRECURSOR_ENDPOINT')
        assert exported == expected, key
        independent_rows.append(expected)
    assert set(saved) == expected_files
    assert set(declared['native_members']) == {row['archive'] for row in rows}
    assert expected_timing == timing_by_key
    assert phase_counts == Counter(development=36, confirmation=96, ablation=32)
    grouped = defaultdict(list)
    for row in independent_rows: grouped[(row['phase'],row['arm'])].append(row)
    expected_summaries = []
    for (phase,arm), group in sorted(grouped.items()):
        selected = [row for key,row in expected_timing.items() if key[0] == phase and key[2] == arm and row['public_report_arrived_at_s'] is not None]
        maybe_sum = lambda name: sum(row[name] for row in group) if all(row[name] is not None for row in group) else None
        expected_summaries.append(dict(phase=phase, arm=arm, worlds=len(group),
            completed_inspections=sum(row['completed_inspections'] for row in group),
            issued_inspection_tasks=sum(row['issued_inspection_tasks'] for row in group),
            arrived_inspection_feedback=sum(row['arrived_inspection_feedback'] for row in group),
            historical_named_threshold_findings=maybe_sum('historical_named_threshold_findings'),
            endpoint_current_named_threshold_findings=maybe_sum('current_named_threshold_findings'),
            unconfirmed_readings=sum(row['unconfirmed_named_signal_readings'] for row in group),
            applied_effects=sum(row['applied_effects'] for row in group), verified_closure='NOT_EVALUATED',
            issue_to_report_mean_s=math.fsum(row['issue_to_report_s'] for row in selected)/len(selected) if selected else None,
            issue_to_report_denominator=len(selected), timing_scope='DESCRIPTIVE_AMONG_SELECTED_ARRIVED_TASKS_NOT_CAUSAL_OR_FIELD_TIME'))
    assert summaries == expected_summaries
    for dataset in plan['datasets']:
        phase_rows = [row for row in rows if row['phase']==dataset['phase']]
        worlds = {row['world_id'] for row in phase_rows}
        arms = {row['arm'] for row in phase_rows}
        assert len(worlds) == dataset['independent_worlds']
        assert all({row['arm'] for row in phase_rows if row['world_id']==world} == arms for world in worlds)
    pairs = defaultdict(dict)
    for row in rows:
        if row['phase']=='confirmation': pairs[row['world_id']][row['arm']] = row
    delta = sum((Fraction(group['one_observation_lookahead']['service_deficit_time_s'])-
                 Fraction(group['evidence_consistent_contingent']['service_deficit_time_s']) for group in pairs.values()), Fraction()) / len(pairs)
    assert len(pairs) == 16 and float(delta) == primary['mean_service_delta_s'] == receipt['primary_mean_service_delta_s'] == .03515625
    assert primary['status'] == receipt['primary_status'] == 'NO_PRACTICAL_GAIN'
    special = {'provenance_valid_confirmation':'MEASURED_NAMED_SIGNAL_SCOPE_ONLY',
        'misleading_reports_by_declared_world_truth':'NOT_OPERATIONALIZED',
        'missed_distinguishable_reports':'NOT_OPERATIONALIZED',
        'actual_effect_vs_public_verified_closure':'EFFECT_MEASURED_CLOSURE_NOT_EVALUATED'}
    for metric in coverage:
        assert metric['status'] == special.get(metric['metric'],'MEASURED_FROM_ORIGINAL_ACCOUNT_OR_FEEDBACK')
        assert metric['reason']
    mapping = {row['metric']: dict(status=row['status'], reason=row['reason']) for row in coverage}
    mapping['offered_service_unit_s']['native_field'] = 'demand_service_unit_s'
    mapping['unconfirmed_or_aborted_work']['native_fields'] = ['task_dispositions','aborted_or_rejected_tasks','nonterminal_tasks','unconfirmed_named_signal_readings']
    mapping['selector_and_model_evaluations']['native_fields'] = ['selector_instants','model_evaluations','schema_component_identity_validations','structural_check_status']
    mapping['wall_compute_time']['native_field'] = 'selector_wall_seconds'
    facts = dict(source=PIN, author_source=AUTHOR, data_source=DATA, original_inputs=658,
        archives=164, saved_run_members_read=164, phase_counts=dict(phase_counts),
        timing_rows=len(timing), issued_inspections=sum(row['issued_inspection_tasks'] for row in rows),
        completed_inspections=sum(row['completed_inspections'] for row in rows),
        arrived_feedback=sum(row['arrived_inspection_feedback'] for row in rows),
        historical_named_threshold_findings=sum(row['historical_named_threshold_findings'] for row in rows),
        endpoint_current_named_threshold_findings=sum(row['current_named_threshold_findings'] for row in rows),
        unconfirmed_named_signal_readings=sum(row['unconfirmed_named_signal_readings'] for row in rows),
        provenance_issue_runs=provenance_issues, structural_counter_present_runs=sum(row['schema_component_identity_validations'] is not None for row in rows),
        structural_counter_not_instrumented_runs=sum(row['schema_component_identity_validations'] is None for row in rows),
        closure_not_evaluated_runs=164, primary_independent_worlds=16, primary_delta_fraction=str(delta),
        primary_delta_s=float(delta), primary_status=primary['status'], method_denominators=expected_summaries,
        scope='Descriptive selected-task named-signal readout; not generic fault confirmation, missed fault, sitewide prevention, causal timing, field calibration or population inference.')
    save('independent-readout-facts.json', facts)
    save('promised-metric-map.json', mapping)
    save('source-and-input-hashes.json', hashes)
    save('findings.json', dict(source=PIN, findings=[], unresolved=0))
    save('receipt.json', dict(status='PASS_SAVED_READOUT_SPEC_REVIEW', source=PIN,
        author_source=AUTHOR, data_source=DATA, artifacts_verified=12, original_inputs_verified=658,
        archive_run_members_read=164, inspection_timing_rows_verified=104, promised_metrics=18,
        unresolved_findings=0, project_calls=0, test_calls=0, plant_calls=0, selector_calls=0,
        inference_calls=0, unrun_seed_or_nonce_file_reads=0, registered_research_trials=0))
    report = f'''Spec saved-readout review: PASS at {PIN}.

All 658 declared original inputs match pinned 2dfe Git blobs and SHA-256 identities. All 164 source archives and run members, start/terminal/audit bindings, 164 exported rows and 104 timing/provenance rows reconcile independently. CSV and JSON match. The 18 promised metric labels each have a measured or explicit NA status, with offered service mapped to native demand_service_unit_s.

Issued tasks, completions and arrived inspection reports each total {facts['issued_inspections']}. Historical named-threshold findings total {facts['historical_named_threshold_findings']}; endpoint-current findings total {facts['endpoint_current_named_threshold_findings']}. Findings were independently checked against the recorded measurement bounds and declared threshold, not inferred fault truth. Report arrival and expiry remain separate; source, target, observable, provenance, scope and validity match the native records. Method denominators and descriptive timing means reconcile.

Structural validation counters are present in 32 ablation records and explicitly not instrumented in 132 development/confirmation records. They remain separate from model-evaluation counters and diagnostic wall time. APPLIED actions do not count as risk closure: all 164 original closure programs are null and closure remains NOT_EVALUATED.

Generic fault confirmation, misleading-cue truth, missed distinguishable reports and pre-failure benefit remain unmeasured. Those design/coverage limits cannot be read as zero or successful. The unchanged primary uses 16 paired worlds: +0.03515625 s, NO_PRACTICAL_GAIN. This completes the bounded reporting omission; it does not establish all R6 aims or scientific gain. No exporter, project code, test, physical model, selector, inference, RNG or unrun nonce was executed/read by this review.
'''
    with (OUT/'report.md').open('x',encoding='utf-8',newline='\n') as stream: stream.write(report)
except BaseException as error:
    with (OUT/'error.txt').open('x',encoding='utf-8',newline='\n') as stream: stream.write(traceback.format_exc())
    save('failure.json', dict(source=PIN, error_type=type(error).__name__, message=str(error), project_calls=0))
    raise
finally:
    manifest = dict(schema='aegisdc-independent-spec-saved-readout-artifacts-v1', source=PIN,
        artifacts={path.name:dict(sha256=sha(path.read_bytes()),bytes=path.stat().st_size)
            for path in sorted(OUT.iterdir()) if path.is_file() and path.name!='manifest.json'},
        excluded=['Self-hash','Runtime caches'])
    save('manifest.json',manifest)
print(json.dumps(dict(status='PASS',source=PIN,manifest_sha256=sha((OUT/'manifest.json').read_bytes()),
    inputs=658,archives=164,timing_rows=104,project_calls=0)))
