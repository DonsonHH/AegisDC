"""Review immutable historical-CI sources and saved attempts; execute no tests."""
from pathlib import Path
import ast
import hashlib
import json
import re
import subprocess

ROOT=Path(r"C:\Users\Donson\Documents\ChatGPT\Renly")
OUT=Path(__file__).resolve().parent
DATA="db33b76c133f0cce12c9a6d197971882e9108376"
OLD="2dfe5537e4f95fa605f325b060ef32223dafb4f6"
RED="7761c3da4bb2c6882d8a2319c0ed0fd0a9a79acb"
GREEN="1e07b3beca467f5ad0e67ff2ac9455a9454e8ffd"
checks=[]
def ck(ok,label):
    checks.append({"label":label,"passed":bool(ok)});assert ok,label
def git(*args):return subprocess.check_output(["git","-C",str(ROOT),*args])
def fetch(rev,paths):
    paths=list(dict.fromkeys(paths));raw=subprocess.check_output(["git","-C",str(ROOT),"cat-file","--batch"],input="".join(rev+":"+p+"\n" for p in paths).encode())
    result={};offset=0
    for p in paths:
        end=raw.index(b"\n",offset);header=raw[offset:end].split();assert header[1]==b"blob",(rev,p,header)
        size=int(header[2]);offset=end+1;result[p]=raw[offset:offset+size];offset+=size+1
    assert offset==len(raw);return result
def blob(rev,p):return fetch(rev,[p])[p]
def sha(v):return hashlib.sha256(v).hexdigest()

helper=blob(GREEN,"tests/historical_research_checkout.py").decode()
ck("HISTORICAL_SOURCE='"+OLD+"'" in helper,"historical checkout pinned to exact approved old commit")
ck("TemporaryDirectory(prefix='aegisdc-historical-ci-')" in helper,"dedicated temporary checkout root")
ck("'core.autocrlf=false','worktree','add','--detach','--quiet'" in helper,"detached LF worktree creation")
ck("if actual!=HISTORICAL_SOURCE:raise AssertionError" in helper,"checkout HEAD identity checked")
ck("finally:" in helper and "['git','worktree','remove',str(checkout)]" in helper and "--force" not in helper,"non-force cleanup in finally")
test_paths=["tests/test_registered_development.py","tests/test_confirmation_freeze.py","tests/test_ablation_masks.py"]
sources=fetch(GREEN,test_paths)
for p,raw in sources.items():
    text=raw.decode();ast.parse(text)
    ck("with historical_checkout() as historical:" in text and "cwd=historical" in text,"old positive CLI runs in exact checkout "+p)
    ck("sys.executable,'-B','-X','utf8'" in text,"child bytecode disabled "+p)
dev=sources[test_paths[0]].decode()
ck("def test_old_lock_refuses_changed_live_source" in dev and "Frozen protocol, source or working bytes differ" in dev,"live corrected source retains explicit old-lock rejection check")
workflow=blob(DATA,".github/workflows/acceptance.yml").decode()
ck("fetch-depth: 0" in workflow,"CI fetches required historical commit instead of shallow-only checkout")
prep=blob(OLD,"scripts/prepare_comparison_worlds.py").decode()
ck("sys.path.insert(0,str(ROOT/'src'))" in prep,"historical public world/mask imports prioritize own old source")
ck("from prepare_comparison_worlds import" in blob(OLD,"scripts/prepare_ablation.py").decode(),"historical mask transitively uses historical source path")

attempts=[]
for phase,revision,tests,failures,selectors in [("red",RED,3,3,0),("green",GREEN,4,0,1)]:
    prefix="evidence/mainline/engineering/pre36-historical-ci/"+phase+"-01/"
    saved=fetch(DATA,[prefix+n for n in ["start.json","receipt.json","tests.log"]])
    start=json.loads(saved[prefix+"start.json"]);receipt=json.loads(saved[prefix+"receipt.json"]);log=saved[prefix+"tests.log"].decode()
    ck(start["source"]==receipt["source"]==revision and start["phase"]==receipt["phase"]==phase,phase+" exact execution source")
    pins=start["source_sha256"]
    expected={p for p in git("ls-tree","-r","--name-only",revision,"--","src","configs","scripts","tests").decode().splitlines() if p.endswith((".py",".json"))}
    ck(set(pins)==expected,phase+" all declared code/config/test guard paths")
    originals=fetch(revision,pins)
    for p,h in pins.items():ck(sha(originals[p])==h,phase+" exact working-byte pin "+p)
    ck(receipt["tests"]==tests and receipt["failures"]==failures and receipt["errors"]==receipt["skipped"]==0,phase+" original suite counts")
    ck(f"Ran {tests} tests" in log and len(re.findall(r"^test_.* \.\.\. ",log,re.M))==tests,phase+" every original test listed")
    ck(("FAILED (failures=3)" in log) if phase=="red" else log.rstrip().endswith("OK"),phase+" saved raw failure/pass retained")
    ck(receipt["selector_calls"]==selectors and receipt["physical_calls"]==receipt["nonce_reads"]==receipt["registered_research_trials"]==0,phase+" separate engineering selector charge")
    ck(receipt["historical_source"]==OLD and receipt["source_guard"]=="PASS",phase+" original provenance receipt")
    attempts.append({"phase":phase,"source":revision,"tests":tests,"failures":failures,"selector_calls":selectors,"guarded_files":len(pins),"artifacts":[{"path":p,"sha256":sha(v),"bytes":len(v)} for p,v in saved.items()]})

plan="docs/mainline/audits/20261108-pre36/historical-ci-plan.json"
ck(blob(RED,plan)==blob(GREEN,plan)==blob(DATA,plan),"historical compatibility plan frozen before red")
ck(git("diff","--name-only",RED,GREEN,"--","src","configs","scripts").strip()==b"","CI correction changes tests/helper only; original runtime/locks untouched")
result={"status":"PASS_SAVED_HISTORICAL_CI_REVIEW","source":GREEN,"data":DATA,"historical_source":OLD,"checks":checks,"check_count":len(checks),"attempts":attempts,"source_of_call_accounting":"Historical audit_masks contains one explicit choose=True fixture; saved green receipt declares this engineering selector once, outside research budget.","reviewer_calls":{"tests":0,"plant":0,"selectors":0,"rng":0,"nonce":0,"project_imports":0,"tracked_edits":0}}
(OUT/"historical-ci-result.json").write_text(json.dumps(result,indent=2)+"\n",encoding="utf-8")
print(json.dumps({"status":result["status"],"checks":len(checks),"original_red_failures":3,"original_green_tests":4,"saved_engineering_selectors":1,"new_project_calls":0}))
