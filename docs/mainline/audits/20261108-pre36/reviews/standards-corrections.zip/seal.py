"""Seal the additive saved-review packet and verify original audit immutability."""
from pathlib import Path
import hashlib
import json
import subprocess

ROOT=Path(r"C:\Users\Donson\Documents\ChatGPT\Renly")
OUT=Path(__file__).resolve().parent
ORIGINAL=OUT.parent/"pre36-standards-audit-01"
sha=lambda raw:hashlib.sha256(raw).hexdigest()
git=lambda *a:subprocess.check_output(["git","-C",str(ROOT),*a])
assert not (OUT/"manifest.json").exists(),"Never overwrite a sealed review packet"
original_manifest=json.loads((ORIGINAL/"manifest.json").read_bytes())
assert sha((ORIGINAL/"manifest.json").read_bytes())=="ccff693c4641e2acdd3abbe3f6dfbba5e652c262e9f62c3a116c7ea71488417d"
for row in original_manifest["files"]:
    data=(ORIGINAL/row["path"]).read_bytes()
    assert len(data)==row["bytes"] and sha(data)==row["sha256"],row["path"]
a02=json.loads((OUT/"a02-result.json").read_bytes())
ci=json.loads((OUT/"historical-ci-result.json").read_bytes())
readout=json.loads((OUT/"readout-result.json").read_bytes())
assert a02["check_count"]==572 and ci["check_count"]==722 and readout["check_count"]==8968
classification_source=git("rev-parse","c7fa51b1").decode().strip()
classification_path="docs/mainline/audits/20261108-pre36/classification-corrections.json"
classification_bytes=git("show",classification_source+":"+classification_path)
classification=json.loads(classification_bytes)
assert classification["closure_api_account"]["instrumented_in_process_total"]==37
assert classification["closure_api_account"]["derived_all_process_closure_assessments"]==38
assert classification["closure_api_account"]["saved_cli_subprocess_invocations"]==1
assert set(classification["fixture_guard_classification"]["omitted_from_original_guard"])=={r["path"] for r in a02["post_execution_fixture_identities"]}
assert classification["fixture_guard_classification"]["supplement"]=="POST_EXECUTION_SAVED_GIT_IDENTITY_CHECK_ONLY"
assert classification["registered_research_trials_before"]==classification["registered_research_trials_after"]==164
assert classification["new_registered_research_trials"]==0
assert not git("diff","--name-only","548e42551d151b8bb58bd732eb048020710e4a19",classification_source,"--","evidence/mainline/engineering/pre36-closure-review").strip()
assert git("show",classification_source+":src/aegis_dc/verified_closure.py")==git("show","62affc55f7c3f08366fb241faa21560c94f1965c:src/aegis_dc/verified_closure.py")
receipt={
    "schema":"aegisdc-pre36-independent-standards-corrections-receipt-v1",
    "status":"PASS_DECLARED_CORRECTION_AND_SAVED_REPORT_SCOPE",
    "original_audit_source":"2dfe5537e4f95fa605f325b060ef32223dafb4f6",
    "closure_correction":"62affc55f7c3f08366fb241faa21560c94f1965c",
    "historical_ci_and_readout_author":"1e07b3beca467f5ad0e67ff2ac9455a9454e8ffd",
    "saved_data_delivery":"db33b76c133f0cce12c9a6d197971882e9108376",
    "classification_metadata":classification_source,
    "classification_sha256":sha(classification_bytes),
    "checks":{"closure_source_and_saved_records":572,"historical_ci_source_and_saved_records":722,"readout_identity_and_value_reconciliation":8968,"total":10262},
    "original_audit_packet_unchanged":True,
    "closure_api_counts":{"instrumented_parent":37,"saved_cli_child":1,"derived_all_process":38},
    "unrecorded_fixture_guard":"Two fixture identities checked only after execution; never claimed as original contemporaneous guards.",
    "registered_originals":{"runs":164,"new_research_runs":0,"independent_worlds":{"development":6,"confirmation":16,"ablation":8}},
    "primary":{"category":"NO_PRACTICAL_GAIN","mean_service_delta_s":0.03515625,"unchanged":True},
    "remaining_correction_specific_blockers":[],
    "prospective_gate":"Before36 actual execution freeze new exact runtime/complete working inputs; retain old-lock rejection and all declared model/site/endpoint limits.",
    "reviewer_activity":{"tests":0,"physical_runs":0,"selectors":0,"inference":0,"training":0,"rng":0,"nonce_reads":0,"captures":0,"project_imports":0,"tracked_edits":0}
}
(OUT/"receipt.json").write_text(json.dumps(receipt,indent=2)+"\n",encoding="utf-8")
(OUT/"lookup-notes.json").write_text(json.dumps({"non_project_read_lookup": [{"attempted_path":"docs/mainline/audits/20261108-pre36/historical-ci-engineering-plan.json","result":"Git path absent; exact documented path found by tree listing is historical-ci-plan.json","project_or_research_calls":0}],"note":"Retains the one path lookup error; no test, export or capture was repeated."},indent=2)+"\n",encoding="utf-8")
files=[]
for path in sorted(OUT.iterdir()):
    if path.is_file() and path.name not in {"manifest.json","seal-verification.json"}:
        raw=path.read_bytes();files.append({"path":path.name,"bytes":len(raw),"sha256":sha(raw)})
manifest={"schema":"aegisdc-independent-review-manifest-v1","source_scope":{"original_audit":receipt["original_audit_source"],"correction":receipt["closure_correction"],"data":receipt["saved_data_delivery"],"classification":classification_source},"files":files,"external_dependencies":[],"excluded":["manifest.json (self)","seal-verification.json (post-seal verification)","runtime caches (none declared)"]}
(OUT/"manifest.json").write_text(json.dumps(manifest,indent=2)+"\n",encoding="utf-8")
for row in json.loads((OUT/"manifest.json").read_bytes())["files"]:
    data=(OUT/row["path"]).read_bytes();assert len(data)==row["bytes"] and sha(data)==row["sha256"],row["path"]
proof={"status":"PASS","fresh_read_artifacts":len(files),"manifest_sha256":sha((OUT/"manifest.json").read_bytes()),"original_manifest_sha256":sha((ORIGINAL/"manifest.json").read_bytes()),"reviewer_project_calls":0}
(OUT/"seal-verification.json").write_text(json.dumps(proof,indent=2)+"\n",encoding="utf-8")
print(json.dumps(proof))
