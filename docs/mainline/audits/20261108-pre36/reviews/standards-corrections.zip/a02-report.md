# A02 correction: source and preserved engineering evidence

Source correction **PASS** at `62affc55f7c3f08366fb241faa21560c94f1965c`, with two additive accounting classifications required below. This does not replace the issue found at fixed source `2dfe5537e4f95fa605f325b060ef32223dafb4f6` or authorize a36 run.

`verified_closure.py::_review_frame` rebuilds a genuine review-time EvidenceLedger snapshot from every already public raw record. The ledger recomputes observation/arrival eligibility, age, expiry, copy provenance, conflicts and current identities. The dossier only limits positive support after adverse/conflict/provenance rejection, so an unlisted adverse record known at review cannot be erased. Later counterevidence does not rewrite history but still blocks the separately required current check. Public-frame validation and authorization at both review/current clocks remain mandatory; a false-alarm disposition makes no physical restoration claim.

All three literal regression cases were frozen before red and unchanged through green. Original red3/2 failures, green3/0 and compatibility14/0 are preserved at their exact execution commits. The reviewer verified572 saved/static source, pin, log and provenance checks, without executing project code. Existing configs and all earlier evidence remain unchanged.

Two precise evidence boundaries must be retained in additive metadata, without rewriting the originals or repeating work:

- The two fixture JSONs read by the suite were not included in the original before/after input guard. Their Git bytes match the baseline, red, corrected and delivery revisions; this is **POST_EXECUTION_SAVED_IDENTITY_CHECK**, not a contemporaneous execution guard. Exact paths, SHA256 and sizes are in `a02-result.json`.
- Original receipts counted37 instrumented calls in the parent process. Compatibility also completed one CLI child process whose `main()` calls the same API once. The all-process finite closure API total is **38**; physical, selector and registered-research calls remain zero for these closure suites.

The behavioral correction removes A02's implementation defect within its bounded engineering scope. Historical CI compatibility, secondary readout and prospective36 source/working-input freezing remain separate gates. The original input-guard omission prevents claiming full contemporaneous input-byte proof; it does not justify rerunning the37 parent calls or relabelling post-execution checks as original guards.
