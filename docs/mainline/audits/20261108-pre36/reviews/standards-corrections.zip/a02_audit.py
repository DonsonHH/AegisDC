"""Saved Git/AST checks only. This file never imports or calls project code."""
from pathlib import Path
import ast
import hashlib
import json
import re
import subprocess

ROOT = Path(r"C:\Users\Donson\Documents\ChatGPT\Renly")
OUT = Path(__file__).resolve().parent
BASE = "2dfe5537e4f95fa605f325b060ef32223dafb4f6"
DELIVERY = "548e42551d151b8bb58bd732eb048020710e4a19"
FIX = "62affc55f7c3f08366fb241faa21560c94f1965c"
RED = "7b0f72fca7ede08b4876b41db3a081d25892b0d5"
PLAN = "docs/mainline/audits/20261108-pre36/closure-review-engineering-plan.json"
TEST = "tests/test_pre36_closure_review_time.py"
DRIVER = "scripts/check_closure_review_time.py"
RUNTIME = "src/aegis_dc/verified_closure.py"
FIXTURES = ["evidence/mainline/engineering/18-beliefs/capture-01/cli-frame.json", "evidence/mainline/engineering/23-interventions/reference/filter-later-inspection.json"]
checks = []
def check(condition, label):
    checks.append({"label": label, "passed": bool(condition)})
    assert condition, label
def sha(data):
    return hashlib.sha256(data).hexdigest()
def git(*args):
    return subprocess.check_output(["git", "-C", str(ROOT), *args])
def fetch(rev, paths):
    paths = list(dict.fromkeys(paths))
    raw = subprocess.check_output(
        ["git", "-C", str(ROOT), "cat-file", "--batch"],
        input="".join(rev+":"+p+"\n" for p in paths).encode())
    result = {}; cursor = 0
    for path in paths:
        end = raw.index(b"\n", cursor); header = raw[cursor:end].split(); cursor = end+1
        assert header[1] == b"blob", (rev, path, header)
        size = int(header[2]); result[path] = raw[cursor:cursor+size]; cursor += size+1
    assert cursor == len(raw)
    return result
def blob(rev, path):
    return fetch(rev, [path])[path]
def function(text, name):
    node = next(n for n in ast.walk(ast.parse(text)) if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)) and n.name == name)
    return "\n".join(text.splitlines()[node.lineno-1:node.end_lineno]), node.lineno

check(git("diff", "--name-only", FIX+"^", FIX).decode().splitlines() == [RUNTIME], "correction commit modifies exactly closure module")
check(git("show", RED+":"+RUNTIME) == git("show", BASE+":"+RUNTIME), "red source retains original implementation")
check(blob(RED, TEST) == blob(FIX, TEST) == blob(DELIVERY, TEST), "literal test source frozen before red and unchanged")
check(blob(RED, PLAN) == blob(FIX, PLAN) == blob(DELIVERY, PLAN), "engineering plan unchanged across attempts")
check(blob(RED, DRIVER) == blob(FIX, DRIVER), "attempt runner frozen across red/green")
check(git("diff", "--name-only", BASE, DELIVERY, "--", "configs").strip() == b"", "all original configs unchanged")
original_edits = git("diff", "--name-status", BASE, DELIVERY, "--", "evidence").decode().splitlines()
check(all(r.startswith("A\t") and r.split("\t",1)[1].startswith("evidence/mainline/engineering/pre36-") for r in original_edits), "all prior evidence originals unchanged; only additive pre36 engineering evidence")

text = blob(FIX, RUNTIME).decode()
prior, prior_line = function(text, "_review_frame")
criterion, check_line = function(text, "_check")
assess, assess_line = function(text, "assess_closure")
review, review_line = function(text, "_reviews")
ledger = blob(FIX, "src/aegis_dc/evidence_ledger.py").decode()
snapshot, snapshot_line = function(ledger, "snapshot")
check("for row in evidence['records']" in prior and "for key in RECORD_FIELDS" in prior and "support_ids" not in prior, "complete received raw record history reconstructed before support selection")
check("prior['as_of_s']=review_time" in prior and "EvidenceLedger(document).snapshot(review_time)" in prior, "frame/evidence clocks rebuilt at review instant")
check("record['arrived_at_s'] > as_of_s or record['observed_at_s'] > as_of_s" in snapshot, "historical snapshot excludes future observation and arrival")
check("_copy_relations(rows)" in snapshot and "conflicts=_conflicts(rows)" in snapshot and "current_record_ids=" in snapshot, "expiry, correlations, provenance, conflict/current sets rebuilt by existing ledger")
support_gate = criterion.index("if support_ids is not None")
check(criterion.index("issues.append(row['id'])") < support_gate and criterion.index("if low<Fraction") < support_gate, "out-of-dossier adverse values remain blockers before positive support filter")
check("support_ids=ids" in assess and "current_checks=[_check(frame" in assess, "historical dossier and independent current checks remain separate")
check("if all(c['passed'] for c in evidence_checks) and all(c['passed'] for c in current_checks)" in assess, "both clocks mandatory for reviewed disposition")
check("grant['starts_at_s']<=row['observed_at_s']<grant['expires_at_s']" in review and "grant['starts_at_s']<=frame['as_of_s']<grant['expires_at_s']" in review, "review grant checked at observation and current decision time")
check("frame=validate_current_frame(frame)" in assess, "public frame validation unchanged")
check("risk_closed=status=='VERIFIED_CLOSED'" in text and "physical_restoration_claim=False" in text, "false alarm does not claim physical restoration")

records = []
for phase, source, tests, failures, calls in [("red", RED, 3, 2, 3), ("green", FIX, 3, 0, 3), ("compatibility", FIX, 14, 0, 31)]:
    prefix = "evidence/mainline/engineering/pre36-closure-review/"+phase+"-01/"
    saved = fetch(DELIVERY, [prefix+name for name in ["start.json", "receipt.json", "tests.log"]])
    start = json.loads(saved[prefix+"start.json"]); receipt = json.loads(saved[prefix+"receipt.json"])
    log = saved[prefix+"tests.log"].decode(); pins = start["source_sha256"]
    check(start["source"] == receipt["source"] == source and start["phase"] == receipt["phase"] == phase, phase+" exact source/phase identity")
    expected = {p for p in git("ls-tree", "-r", "--name-only", source, "--", "src", "configs", "tests").decode().splitlines() if p.endswith((".py", ".json"))}
    expected |= {DRIVER, PLAN}
    check(set(pins) == expected, phase+" complete declared source/config/test/runner/plan guard set")
    source_blobs = fetch(source, pins)
    for p, digest in pins.items():
        check(sha(source_blobs[p]) == digest, phase+" recorded source pin "+p)
    check(receipt["tests"] == tests and receipt["failures"] == failures and receipt["errors"] == receipt["skipped"] == 0, phase+" saved counts agree with declared attempt")
    check(f"Ran {tests} tests" in log and len(re.findall(r"^test_.* \.\.\. ", log, re.M)) == tests, phase+" raw suite lists every executed test")
    check(("FAILED (failures=2)" in log) if phase == "red" else log.rstrip().endswith("OK"), phase+" original raw terminal result retained")
    check(receipt["closure_assessment_calls"] == calls and receipt["source_guard"] == "PASS", phase+" instrumented API/guard value retained")
    check(all(receipt[k] == 0 for k in ["physical_calls", "selector_calls", "training_llm_calls", "random_or_nonce_reads", "registered_research_trials"]), phase+" no research/physical/selector/RNG charge claimed")
    records.append({"phase":phase,"source":source,"guarded_files":len(pins),"in_process_closure_calls":calls,"tests":tests,"failures":failures,"artifacts":[{"path":p,"sha256":sha(v),"bytes":len(v)} for p,v in saved.items()]})

fixture_identities = []
for p in FIXTURES:
    values = {rev:blob(rev, p) for rev in [BASE, RED, FIX, DELIVERY]}
    check(len({sha(v) for v in values.values()}) == 1, "post-execution fixture Git identity unchanged "+p)
    check(all(p not in json.loads(blob(DELIVERY,"evidence/mainline/engineering/pre36-closure-review/"+phase+"-01/start.json"))["source_sha256"] for phase in ["red","green","compatibility"]), "fixture absence from original runtime guards explicitly classified "+p)
    fixture_identities.append({"path":p,"sha256":sha(values[BASE]),"bytes":len(values[BASE]),"checked_commits":[BASE,RED,FIX,DELIVERY],"execution_guard":"NOT_IN_ORIGINAL_EXECUTION_GUARD","review_check":"POST_EXECUTION_SAVED_IDENTITY_CHECK"})

old_tests = blob(FIX, "tests/test_verified_closure.py").decode()
cli_test, cli_line = function(old_tests, "test_cli_assesses_only_the_declared_public_frame_and_closed_program")
main, main_line = function(text, "main")
check(cli_test.count("subprocess.run(") == 1 and "'-m','aegis_dc.verified_closure'" in cli_test, "compatibility includes one actual CLI subprocess outside parent monkey counter")
check("assess_closure(" in main, "CLI main adds one uninstrumented child closure assessment")
result = {
    "schema":"aegisdc-pre36-a02-independent-standards-v1",
    "status":"SOURCE_CORRECTION_PASS_WITH_ADDITIVE_ACCOUNTING_CLASSIFICATIONS",
    "source":FIX,"delivery":DELIVERY,"original_audit_source":BASE,
    "checks":checks,"check_count":len(checks),"attempts":records,"post_execution_fixture_identities":fixture_identities,
    "call_classification":{"original_receipt_parent_process_total":37,"additional_saved_cli_subprocess_calls":1,"all_process_closure_assessment_calls":38,"rule":"Do not overwrite original counters; distinguish parent instrumentation from total saved API work."},
    "source_references":{"review_frame":prior_line,"check":check_line,"assess_closure":assess_line,"reviews":review_line,"ledger_snapshot":snapshot_line,"cli_test":cli_line,"cli_main":main_line},
    "no_new_calls":{"tests":0,"plant":0,"selectors":0,"inference":0,"rng":0,"nonce_reads":0,"project_imports":0,"tracked_edits":0},
    "remaining_gate":"Historical CI compatibility and secondary saved readout reviewed separately; any36 execution still requires prospective exact source freeze/bridge."
}
(OUT/"a02-result.json").write_text(json.dumps(result,indent=2,ensure_ascii=False)+"\n",encoding="utf-8")
print(json.dumps({"status":result["status"],"checks":len(checks),"attempts":len(records),"parent_closure_calls":37,"all_process_closure_calls":38,"fixture_guard_limitations":len(fixture_identities),"new_project_calls":0}))
