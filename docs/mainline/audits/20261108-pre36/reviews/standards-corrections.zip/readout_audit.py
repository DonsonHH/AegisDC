"""Independently reconcile saved readout tables with immutable original bytes."""
from pathlib import Path
from collections import Counter, defaultdict
import ast
import csv
import hashlib
import io
import json
import math
import subprocess
import zipfile

ROOT=Path(r"C:\Users\Donson\Documents\ChatGPT\Renly")
OUT=Path(__file__).resolve().parent
DATA="db33b76c133f0cce12c9a6d197971882e9108376"
AUTHOR="1e07b3beca467f5ad0e67ff2ac9455a9454e8ffd"
OLD="2dfe5537e4f95fa605f325b060ef32223dafb4f6"
PREFIX="evidence/mainline/engineering/pre36-readout/readout-01/"
TOOL="scripts/complete_registered_readout.py"
PLAN="docs/mainline/audits/20261108-pre36/saved-readout-plan.json"
checks=[]
def ck(ok,label):
    checks.append({"label":label,"passed":bool(ok)});assert ok,label
def sha(v):return hashlib.sha256(v).hexdigest()
def git(*a):return subprocess.check_output(["git","-C",str(ROOT),*a])
def fetch(rev,paths):
    paths=list(dict.fromkeys(paths));raw=subprocess.check_output(["git","-C",str(ROOT),"cat-file","--batch"],input="".join(rev+":"+p+"\n" for p in paths).encode())
    result={};offset=0
    for p in paths:
        end=raw.index(b"\n",offset);header=raw[offset:end].split();assert header[1]==b"blob",(rev,p,header)
        size=int(header[2]);offset=end+1;result[p]=raw[offset:offset+size];offset+=size+1
    assert offset==len(raw);return result
def blob(rev,p):return fetch(rev,[p])[p]
def close(a,b):return math.isclose(a,b,rel_tol=0,abs_tol=1e-8)
def tree(rev):
    return {p.decode():h.split()[2].decode() for item in git("ls-tree","-r","-z",rev).split(b"\0") if item for h,p in [item.split(b"\t",1)]}

paths=git("ls-tree","-r","--name-only",DATA,"--",PREFIX).decode().splitlines()
saved=fetch(DATA,paths);byname={p[len(PREFIX):]:v for p,v in saved.items()}
manifest=json.loads(byname["manifest.json"])
ck(set(byname)==set(manifest["artifacts"])|{"manifest.json"},"complete durable saved-readout delivery set")
for name,row in manifest["artifacts"].items():
    ck(sha(byname[name])==row["sha256"] and len(byname[name])==row["bytes"],"saved manifest/Git artifact identity "+name)
start=json.loads(byname["start.json"]);receipt=json.loads(byname["receipt.json"])
journal=[json.loads(line) for line in byname["attempts.jsonl"].splitlines()]
ck([r["event"] for r in journal]==["STARTED","COMPLETED"] and journal[0]==start,"one unique saved-only lifecycle; no retry/failure masking")
ck(all(journal[1][k]==v for k,v in receipt.items()),"terminal saved-only receipt matches journal")
ck(start["source"]==receipt["source"]==AUTHOR and start["data_source"]==receipt["data_source"]==OLD,"actual author and original data sources separated")
tool=blob(AUTHOR,TOOL);planbytes=blob(AUTHOR,PLAN);plan=json.loads(planbytes)
ck(sha(tool)==start["tool_sha256"] and sha(planbytes)==start["plan_sha256"],"source/plan frozen before one saved extraction")
ck(tool==blob(DATA,TOOL) and planbytes==blob(DATA,PLAN),"delivered tool/plan exact to author source")
modules={n.module.split('.')[0] for n in ast.walk(ast.parse(tool)) if isinstance(n,ast.ImportFrom) and n.module}
modules|={a.name.split('.')[0] for n in ast.walk(ast.parse(tool)) if isinstance(n,ast.Import) for a in n.names}
ck(modules<=set("argparse collections datetime csv hashlib io json math pathlib subprocess sys traceback zipfile".split()),"exporter imports only declared standard library")
ck(b"read_original" in tool and b"Original differs from pinned Git blob" in tool and b"exist_ok=False" in tool,"exact original-byte checks and unique output retained")

inputs=json.loads(byname["input-manifest.json"])
ck(inputs["data_source"]==OLD,"input manifest uses approved fixed original source")
oldtree=tree(OLD);newtree=tree(DATA)
originals=fetch(OLD,inputs["files"])
for p,row in inputs["files"].items():
    raw=originals[p];gitblob=hashlib.sha1(b"blob "+str(len(raw)).encode()+b"\0"+raw).hexdigest()
    ck(len(raw)==row["bytes"] and sha(raw)==row["sha256"] and gitblob==row["git_blob"]==oldtree[p]==newtree[p],"original input/hash/source unchanged "+p)

rows=json.loads(byname["run-readout.json"]);timing=json.loads(byname["inspection-timing.json"])
summaries=json.loads(byname["method-summary.json"]);coverage=json.loads(byname["metric-coverage.json"])
ck(len(rows)==164 and len(timing)==104 and len(coverage)==18,"all run/timing/metric denominators")
rowkey=lambda r:(r["phase"],r["world_id"],r["arm"])
index={rowkey(r):r for r in rows};timemap={(rowkey(t),t["task_id"]):t for t in timing}
ck(len(index)==164 and len(timemap)==104,"unique per-run and per-task output identities")
timing_seen=set();worlds=defaultdict(set);arms=defaultdict(Counter);model_totals=Counter();feedback_totals=Counter();all_sources=set();native_checks=[]
confirmed={"CONFIRMED_AT_OR_ABOVE_THRESHOLD","CONFIRMED_BELOW_THRESHOLD"}
for row in rows:
    key=rowkey(row);phase,world,arm=key;worlds[phase].add(world);arms[phase][arm]+=1
    archive=row["archive"];parent=archive.rsplit('/',1)[0]+'/'
    began=json.loads(originals[parent+"start.json"]);terminal=json.loads(originals[parent+"terminal.json"]);audit=json.loads(originals[parent+"audit.json"])
    ck(key==(phase,began["world_id"],began["arm"]) and row["family"]==began["family"] and row["original_index"]==began["index"],"run identity "+str(key))
    ck(terminal["status"]=="COMPLETED" and terminal["physical_returned"] is True and not audit["hard_violations"],"original completed/no-violation status "+str(key))
    for name in ["start.json","audit.json","originals.zip"]:ck(sha(originals[parent+name])==terminal["artifacts"][name],"original terminal hash "+parent+name)
    with zipfile.ZipFile(io.BytesIO(originals[archive])) as z:
        ck(set(z.namelist())=={"scenario.json","run.json","private-state.jsonl","balances.jsonl"},"native archive set "+archive)
        nativebytes=z.read("run.json");native=json.loads(nativebytes)
    member=inputs["native_members"][archive]["run.json"]
    ck(sha(nativebytes)==member["sha256"] and len(nativebytes)==member["bytes"],"native run member pin "+archive)
    ck(row["execution_source"]==native["code_identity"]["git_commit"]==began["source"]==terminal["source"],"actual execution identity "+str(key));all_sources.add(began["source"])
    ck(row["duration_s"]==began["duration_s"]==10 and native["inputs"]["dispatch_program"]["closure_program"] is None,"original duration/disabled closure "+str(key))
    for name,value in audit["totals"].items():ck(row[name]==value,"separate original account "+str(key)+" "+name)
    ck(close(row["demand_service_unit_s"]-row["delivered_service_unit_s"],row["unserved_service_unit_s"]),"service quantity conservation "+str(key))
    ck(close(row["paid_person_s"],math.fsum(row[k] for k in ["worker_travel_person_s","worker_work_person_s","worker_wait_person_s"])),"paid labor does not add access checks twice "+str(key))
    tasks={t["id"]:t for t in native["work_records"]};bindings={t["task_id"]:t for t in native["inspection_public_models"]["bindings"]}
    events={e["task_id"]:e for e in native["inspection_private_audit"]["events"] if "record_id" in e}
    reports=native["inspection_public_feedback"];feedback={(f["task_id"],f["record_id"]):f for f in reports};bytask={f["task_id"]:f for f in reports}
    ck(len(feedback)==len(reports)==len(bytask),"native report task/record uniqueness "+str(key))
    snapshot=native["inspection_public_snapshot"];records={r["id"]:r for r in snapshot["records"]};findings=Counter(f["confirmation"] for f in reports)
    ck(row["arrived_inspection_feedback"]==row["source_record_binding_checks_passed"]==len(reports),"arrived binding denominator "+str(key))
    ck(row["threshold_findings"]==dict(findings) and row["unconfirmed_named_signal_readings"]==findings["UNCONFIRMED"],"threshold categories separated from generic fault "+str(key))
    ck(row["historical_named_threshold_findings"]==(None if snapshot["provenance_issues"] else sum(findings[k] for k in confirmed)) and row["current_named_threshold_findings"]==(None if snapshot["provenance_issues"] else sum(f["current_confirmation"] for f in reports)),"historical/current confirmation quantities "+str(key))
    for f in reports:
        task=tasks[f["task_id"]];r=records[f["record_id"]];e=events[f["task_id"]]
        ck(task["status"]=="completed" and task["completed_at_s"]==f["observed_at_s"]==e["source_sample_at_s"] and f["arrived_at_s"]<=10,"actual sample and public arrival clocks "+str(key)+" "+f["task_id"])
        ck(all(f[k]==r[k] for k in ["source_id","target_id","observable_id","provenance","observed_at_s","arrived_at_s","valid_until_s"]) and f["record_id"]==bindings[f["task_id"]]["record_id"]==e["record_id"],"source/task/record/provenance bindings "+str(key)+" "+f["task_id"])
        ck(f["scope"]=="NAMED_SIGNAL_THRESHOLD_ONLY_NOT_FAULT_DIAGNOSIS" and f["additional_evidence_factor"] is False,"no feedback-as-extra-evidence or generic diagnosis "+str(key)+" "+f["task_id"])
        ck(f["current_confirmation"]==(r["availability"]=="current" and f["confirmation"]!="UNCONFIRMED"),"endpoint current flag "+str(key)+" "+f["task_id"])
    for taskid,task in tasks.items():
        if taskid not in bindings:continue
        t=timemap[(key,taskid)];timing_seen.add((key,taskid));f=bytask.get(taskid);e=events.get(taskid,{})
        expected={"task_status":task["status"],"issued_at_s":task.get("issued_at_s"),"site_arrival_at_s":task.get("arrived_at_s"),"work_started_at_s":task.get("work_started_at_s"),"completed_at_s":task.get("completed_at_s"),"sampled_at_s":e.get("source_sample_at_s"),"record_id":e.get("record_id"),"public_report_arrived_at_s":f["arrived_at_s"] if f else None}
        ck(all(t[k]==v for k,v in expected.items()),"all task time fields from actual native record "+str(key)+" "+taskid)
        report_fields={"source_id":"source_id","target_id":"target_id","observable_id":"observable_id","provenance":"provenance","valid_until_s":"valid_until_s","confirmation_scope":"scope","additional_evidence_factor":"additional_evidence_factor","historical_named_signal_finding":"confirmation","endpoint_availability":"availability","endpoint_current_confirmation":"current_confirmation"}
        ck(all(t[k]==(f[v] if f else None) for k,v in report_fields.items()),"all timing report metadata/native missingness "+str(key)+" "+taskid)
        ck(t["issue_to_report_s"]==(f["arrived_at_s"]-task["issued_at_s"] if f else None) and t["sample_to_report_s"]==(f["arrived_at_s"]-f["observed_at_s"] if f else None),"delays measured only for arrived reports "+str(key)+" "+taskid)
        ck(t["observation_status"]==("PUBLIC_REPORT_ARRIVED" if f else "SAMPLED_NOT_PUBLICLY_ARRIVED" if e else "NO_SAMPLE"),"pending inspection is not a fabricated zero delay "+str(key)+" "+taskid)
    dispositions=Counter(t["status"] for t in tasks.values())
    ck(row["task_dispositions"]==dict(dispositions) and row["aborted_or_rejected_tasks"]==sum(dispositions[k] for k in ["aborted","rejected"]) and row["nonterminal_tasks"]==sum(v for k,v in dispositions.items() if k not in {"completed","aborted","rejected"}),"work lifecycle separate from unconfirmed readings "+str(key))
    ck(row["issued_inspection_tasks"]==sum(taskid in bindings for taskid in tasks) and row["completed_inspections"]==audit["completed_inspections"] and row["completed_interventions"]==audit["completed_interventions"],"inspection/intervention completion denominator "+str(key))
    computations=native["policy_computation_audit"];counts=Counter()
    for c in computations:
        ck(c["scope"]=="DIAGNOSTIC_WALL_TIME_ONLY_NOT_PHYSICAL_TIME_OR_POLICY_INPUT","computation remains diagnostic "+str(key))
        counts.update(c["model_evaluations"])
    ck(row["model_evaluations"]==dict(counts) and row["selector_instants"]==len(computations) and close(row["selector_wall_seconds"],math.fsum(c["elapsed_ns"] for c in computations)/1e9),"separate selector/model/wall accounting "+str(key));model_totals.update(counts)
    structure=native.get("ablation_execution_audit")
    ck(row["schema_component_identity_validations"]==(structure["schema_component_identity_validations"] if structure else None),"missing historical structural instrumentation is NA "+str(key))
    applied=[e for e in native["intervention_private_audit"]["events"] if e["outcome"]=="APPLIED"]
    ck(row["applied_effects"]==len(applied)==len(audit["applied_effects"]) and row["arrived_applied_feedback"]==sum(f["outcome"]=="APPLIED" for f in native["intervention_public_feedback"]),"actual effects versus arrived action feedback "+str(key))
    ck(row["verified_closure"]=="NOT_EVALUATED_WITHOUT_POST_ACTION_PROTOCOL" and row["generic_fault_confirmation"]=="NOT_OPERATIONALIZED" and row["missed_distinguishable_reports"]=="NOT_OPERATIONALIZED_NO_OPPORTUNITY_DENOMINATOR" and row["pre_failure_detection"]=="NOT_TESTED_NO_FROZEN_PRECURSOR_ENDPOINT","unmeasured endpoints explicitly unavailable, never zero "+str(key))
    feedback_totals.update(findings)

ck(set(timemap)==timing_seen,"every timing row reconciled; no added or omitted tasks")
ck({k:len(v) for k,v in worlds.items()}=={"development":6,"confirmation":16,"ablation":8},"independent units by phase are worlds, not run rows")
ck(all(len(v)==(4 if k=="ablation" else 6) for k,v in arms.items()),"all preregistered arms retained")
ck(set(inputs["native_members"])=={r["archive"] for r in rows},"all164 original native members represented exactly")

protocol=json.loads(originals["docs/mainline/30-comparison-protocol-v1.json"])
ck([r["metric"] for r in coverage]==protocol["comparison"]["report_separately"],"all18 promised metrics retain original roster/order")
cov={r["metric"]:r for r in coverage}
ck(cov["provenance_valid_confirmation"]["status"]=="MEASURED_NAMED_SIGNAL_SCOPE_ONLY" and cov["misleading_reports_by_declared_world_truth"]["status"]==cov["missed_distinguishable_reports"]["status"]=="NOT_OPERATIONALIZED" and cov["actual_effect_vs_public_verified_closure"]["status"]=="EFFECT_MEASURED_CLOSURE_NOT_EVALUATED","four original missing categories explicitly resolved or scoped NA")
groups=defaultdict(list)
for r in rows:groups[(r["phase"],r["arm"])].append(r)
ck(len(summaries)==len(groups)==16,"all16 method/phase summaries")
for s in summaries:
    group=groups[(s["phase"],s["arm"])];selected=[t for t in timing if t["phase"]==s["phase"] and t["arm"]==s["arm"] and t["public_report_arrived_at_s"] is not None]
    ck(s["worlds"]==len(group) and s["issue_to_report_denominator"]==len(selected),"summary independent units and arrived-only denominator "+str((s["phase"],s["arm"])))
    for field in ["completed_inspections","issued_inspection_tasks","arrived_inspection_feedback","historical_named_threshold_findings","applied_effects"]:
        expect=sum(r[field] for r in group) if all(r[field] is not None for r in group) else None
        ck(s[field]==expect,"summary total "+str((s["phase"],s["arm"]))+" "+field)
    expected=math.fsum(t["issue_to_report_s"] for t in selected)/len(selected) if selected else None
    ck(s["issue_to_report_mean_s"]==expected and s["timing_scope"]=="DESCRIPTIVE_AMONG_SELECTED_ARRIVED_TASKS_NOT_CAUSAL_OR_FIELD_TIME" and s["verified_closure"]=="NOT_EVALUATED","conditional timing and closure scope "+str((s["phase"],s["arm"])))

primary=json.loads(originals["evidence/mainline/research/34-paired-analysis/results.json"])
deltas=[index[("confirmation",w,"one_observation_lookahead")]["service_deficit_time_s"]-index[("confirmation",w,"evidence_consistent_contingent")]["service_deficit_time_s"] for w in sorted(worlds["confirmation"])]
ck(len(deltas)==16 and math.fsum(deltas)/16==primary["mean_service_delta_s"]==receipt["primary_mean_service_delta_s"]==0.03515625 and primary["status"]==receipt["primary_status"]=="NO_PRACTICAL_GAIN","original16-pair primary arithmetic and negative category unchanged")
for name,data in [("run-readout",rows),("inspection-timing",timing),("method-summary",summaries)]:
    csvrows=list(csv.DictReader(io.StringIO(byname[name+".csv"].decode("utf-8-sig"))))
    ck(len(csvrows)==len(data),"CSV full row count "+name)
    for savedrow,row in zip(csvrows,data,strict=True):
        expected={k:"" if v is None else json.dumps(v,ensure_ascii=False,sort_keys=True) if isinstance(v,(dict,list)) else str(v) for k,v in row.items()}
        ck(savedrow==expected,"CSV typed JSON/number/NA correspondence "+name+" "+str(row.get("world_id",row.get("arm"))))
ck(all(receipt[k]==0 for k in ["new_physical_calls","new_selector_calls","new_inference_calls","new_research_trials"]),"saved-only exporter no new research or project calls")
result={"status":"PASS_SAVED_READOUT_AND_ACCOUNTING","author_source":AUTHOR,"data_delivery":DATA,"original_data_source":OLD,"check_count":len(checks),"checks":checks,"input_files":len(originals),"runs":len(rows),"archives":len(inputs["native_members"]),"inspection_timing_rows":len(timing),"arrived_threshold_feedback":dict(feedback_totals),"worlds":{k:len(v) for k,v in worlds.items()},"phase_arm_counts":{k:dict(v) for k,v in arms.items()},"model_evaluations":dict(model_totals),"actual_execution_sources":sorted(all_sources),"primary_result":"NO_PRACTICAL_GAIN","primary_mean_service_delta_s":0.03515625,"claim_scope":"Post-hoc descriptive completion; generic fault, misleading-report truth, missed opportunities, pre-failure detection and verified closure remain explicitly not operationalized or not evaluated.","reviewer_calls":{"tests":0,"plant":0,"selectors":0,"rng":0,"nonce":0,"project_imports":0,"tracked_edits":0}}
(OUT/"readout-result.json").write_text(json.dumps(result,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
print(json.dumps({k:v for k,v in result.items() if k not in {"checks","phase_arm_counts","actual_execution_sources"}}))
