"""Static source and saved-log review only; never import or run project code."""
import ast
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path('C:/Users/Donson/Documents/ChatGPT/Renly')
OUT = Path(__file__).resolve().parent
INITIAL = '548e42551d151b8bb58bd732eb048020710e4a19'
FINAL = 'df05d4403571dec278036ecbaa22564c2b08c9fd'
COMPATIBLE = '1e07b3beca467f5ad0e67ff2ac9455a9454e8ffd'
FIX = '62affc55f7c3f08366fb241faa21560c94f1965c'
DATA = '2dfe5537e4f95fa605f325b060ef32223dafb4f6'
PLAN_PATH = 'docs/mainline/audits/20261108-pre36/saved-readout-plan.json'
EXPORTER = 'scripts/complete_registered_readout.py'
CLOSURE = 'src/aegis_dc/verified_closure.py'
TESTS = 'tests/test_pre36_closure_review_time.py'
hashes = {}


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def blob(source, path):
    raw = git('show', source + ':' + path)
    hashes[source + ':' + path] = {'sha256': digest(raw), 'bytes': len(raw)}
    return raw


def save(name, value):
    with (OUT / name).open('x', encoding='utf-8', newline='\n') as stream:
        stream.write(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n')


def verify_batch(source, expected):
    """Check stored engineering source guards against Git blobs, without imports."""
    paths = list(expected)
    refs = ''.join(source + ':' + path + '\n' for path in paths).encode()
    output = subprocess.check_output(['git', 'cat-file', '--batch'], input=refs, cwd=ROOT)
    offset = 0
    for path in paths:
        end = output.index(b'\n', offset)
        header = output[offset:end].split()
        assert len(header) == 3 and header[1] == b'blob', (source, path, header)
        length = int(header[2])
        raw = output[end + 1:end + 1 + length]
        assert digest(raw) == expected[path], (source, path)
        offset = end + 2 + length
    assert offset == len(output)
    return len(paths)


start = dict(started_utc=datetime.now(timezone.utc).isoformat(), initial=INITIAL, candidate=FINAL,
             compatible_metadata_revision=COMPATIBLE, scope='STATIC_AND_SAVED_RECORDS_ONLY')
save('start.json', start)
main_manifest = ROOT / '.work/pre36-spec-audit-01/manifest.json'
main_manifest_hash = digest(main_manifest.read_bytes())
assert main_manifest_hash == '9eed8f9a2133e5a6f03e50c6db3fa47c81ad979dbddc192f9ceedb8cf6d82e83'

old_exporter = blob(INITIAL, EXPORTER).decode()
new_exporter = blob(FINAL, EXPORTER).decode()
assert blob(COMPATIBLE, EXPORTER).decode() == new_exporter
assert blob(FINAL, PLAN_PATH) == blob('4073b619', PLAN_PATH)
assert blob(FINAL, CLOSURE) == blob(FIX, CLOSURE) == blob(COMPATIBLE, CLOSURE)
assert blob(FINAL, TESTS) == blob(FIX, TESTS)
blob(FINAL, 'src/aegis_dc/evidence_ledger.py')
blob(FINAL, 'src/aegis_dc/workforce_dispatch.py')
blob(FINAL, 'tests/test_verified_closure.py')
blob(FINAL, 'scripts/check_closure_review_time.py')
blob(FINAL, 'docs/mainline/audits/20261108-pre36/closure-review-engineering-plan.json')
plan = json.loads(blob(FINAL, PLAN_PATH))
assert plan['source'] == DATA
assert [(r['phase'], r['expected_runs'], r['independent_worlds']) for r in plan['datasets']] == [
    ('development', 36, 6), ('confirmation', 96, 16), ('ablation', 32, 8)]
original_paths = [r['capture'] for r in plan['datasets']] + [
    'docs/mainline/30-comparison-protocol-v1.json',
    'evidence/mainline/research/34-paired-analysis/results.json']
assert not git('diff', '--name-only', DATA, FINAL, '--', *original_paths).strip()
imports = sorted({alias.name for node in ast.walk(ast.parse(new_exporter))
                  if isinstance(node, ast.Import) for alias in node.names} |
                 {node.module for node in ast.walk(ast.parse(new_exporter)) if isinstance(node, ast.ImportFrom)})
assert not any(name.startswith(('aegis_dc', 'patrol_rsi', 'torch', 'numpy', 'random', 'secrets')) for name in imports)
assert 'subprocess.check_output([\'git\',*a]' in new_exporter
assert "extrasaction='raise'" in new_exporter
assert 'issued_inspection_tasks=sum(task_id in bindings for task_id in tasks)' in new_exporter
assert "issued_inspection_tasks=sum(r['issued_inspection_tasks'] for r in group)" in new_exporter
for field in ('source_id', 'target_id', 'observable_id', 'provenance', 'valid_until_s'):
    assert field + "=f['" + field + "'] if f else None" in new_exporter
assert "confirmation_scope=f['scope'] if f else None" in new_exporter
assert "additional_evidence_factor=f['additional_evidence_factor'] if f else None" in new_exporter
assert "report_metadata_status='ARRIVED_NATIVE_FEEDBACK' if f else 'NO_ARRIVED_REPORT_METADATA'" in new_exporter
assert "structural_checks=structure['schema_component_identity_validations'] if structure is not None else None" in new_exporter
assert "structural_check_status='NATIVE_SEPARATE_COUNTER' if structure is not None else 'NOT_INSTRUMENTED_IN_ORIGINAL'" in new_exporter
assert 'issued_inspection_tasks=' not in old_exporter
assert 'report_metadata_status=' not in old_exporter
assert 'structural_check_status=' not in old_exporter

diff = git('diff', INITIAL, FINAL, '--', EXPORTER).decode()
with (OUT / 'exporter-correction.diff').open('x', encoding='utf-8', newline='\n') as stream:
    stream.write(diff)

engineering = []
for phase, directory, tests, failures, calls in (
    ('red', 'red-01', 3, 2, 3), ('green', 'green-01', 3, 0, 3),
    ('compatibility', 'compatibility-01', 14, 0, 31)):
    prefix = 'evidence/mainline/engineering/pre36-closure-review/' + directory + '/'
    began = json.loads(blob(FINAL, prefix + 'start.json'))
    receipt = json.loads(blob(FINAL, prefix + 'receipt.json'))
    log = blob(FINAL, prefix + 'tests.log').decode()
    assert began['source'] == receipt['source']
    assert (receipt['tests'], receipt['failures'], receipt['errors'], receipt['skipped']) == (tests, failures, 0, 0)
    assert receipt['closure_assessment_calls'] == calls and receipt['source_guard'] == 'PASS'
    for key in ('physical_calls', 'selector_calls', 'training_llm_calls', 'random_or_nonce_reads', 'registered_research_trials'):
        assert receipt[key] == 0
    assert ('FAILED (failures=2)' in log) if phase == 'red' else ('\nOK\n' in log)
    count = verify_batch(receipt['source'], began['source_sha256'])
    engineering.append(dict(phase=phase, source=receipt['source'], tests=tests,
                            assertion_failures=failures, errors=0, skipped=0,
                            recorded_parent_instrumented_closure_calls=calls,
                            pinned_source_blobs_verified=count, raw_log_path=prefix + 'tests.log'))

fixture_identity = []
for path in ('evidence/mainline/engineering/18-beliefs/capture-01/cli-frame.json',
             'evidence/mainline/engineering/23-interventions/reference/filter-later-inspection.json'):
    fixed = blob(FIX, path)
    assert blob('7b0f72fca7ede08b4876b41db3a081d25892b0d5', path) == fixed == blob(FINAL, path)
    assert (ROOT / path).read_bytes() == fixed
    fixture_identity.append(dict(path=path, sha256=digest(fixed),
        classification='POST_EXECUTION_SAVED_IDENTITY_NOT_CONTEMPORANEOUS_INPUT_GUARD'))
cli_test = blob(FIX, 'tests/test_verified_closure.py').decode()
assert "'-m','aegis_dc.verified_closure'" in cli_test
assert 'self.assertEqual(result.returncode,0,result.stderr)' in cli_test

initial_findings = [
    dict(id='PREFLIGHT-01', status_at_initial='OPEN', status_at_final='CLOSED',
         requirement='Plan explicitly shows arrived feedback and issued inspection-task denominators.',
         finding='548 exported completed/arrived counts but omitted issued inspection-task counts.',
         correction='df05 uses actual issued work_records intersected with inspection bindings, and sums that per method.'),
    dict(id='PREFLIGHT-02', status_at_initial='OPEN', status_at_final='CLOSED',
         requirement='Plan provenance/timing table preserves source, target, observable, clocks and provenance; no inferred diagnosis.',
         finding='548 checked provenance internally but did not export the source/target/observable/provenance/validity/scope fields.',
         correction='df05 exports native arrived-feedback metadata; no arrived feedback yields explicit nulls and a reason/status.'),
    dict(id='PREFLIGHT-03', status_at_initial='OPEN', status_at_final='CLOSED',
         requirement='Plan keeps original model-evaluation counters and structural checks separate.',
         finding='548 omitted native ablation schema_component_identity_validations.',
         correction='df05 exports the native value; absent original instrumentation is null with NOT_INSTRUMENTED_IN_ORIGINAL.')]
save('initial-548-findings.json', dict(source=INITIAL, findings=initial_findings))
save('engineering-record-review.json', dict(source=FINAL, correction_source=FIX,
      engineering=engineering, independently_executed_calls=0,
      literal_cases=[
          dict(case='Support valid at review, expired now; separate fresh current evidence',
               expected='Review checks pass, current checks pass; FALSE_ALARM_REVIEWED but risk_closed=false.'),
          dict(case='Omitted adverse evidence was current at review, expired now',
               expected='Review fails despite current pass; omitted dossier item cannot erase counterevidence.'),
          dict(case='Adverse evidence arrives after review and remains current now',
               expected='Historical review passes; current check fails and question/risk remain open.')],
      source_review='Historical EvidenceLedger snapshot rebuilds availability/conflicts/provenance at review time. The support whitelist is applied only after adverse/invalid checks; current checks remain unrestricted.',
      accounting=dict(parent_instrumented_calls=37, additional_saved_cli_child_call=1,
                      derived_total_calls=38, basis='31 parent compatibility calls plus one successful saved CLI child process; red and green each add three parent calls.'),
      fixture_identity=fixture_identity,
      limits='No project code or tests executed by reviewer. Saved calls are finite closure/risk/belief engineering calculations, not plant or research runs.'))
save('source-and-evidence-hashes.json', dict(blobs=hashes, preserved_main_audit_manifest_sha256=main_manifest_hash))
save('receipt.json', dict(status='PASS_NARROW_SPEC_PREEXEC_AND_A02_SAVED_REVIEW', source=FINAL,
      initial_source=INITIAL, compatible_metadata_revision=COMPATIBLE, correction_source=FIX,
      preserved_original_findings=3, unresolved_findings=0,
      exporter_permission='Parent may execute the frozen saved-only extraction once in its unique directory; saved output still requires independent review.',
      A02='PASS_STATIC_AND_SAVED_LITERAL_CASES',
      generic_fault_miss_prevention_endpoints='Remain explicitly NOT_OPERATIONALIZED/NOT_TESTED; not zero or successful.',
      original_primary_and_registered_data='UNCHANGED_NO_PRACTICAL_GAIN_AND_164_EXISTING_RUNS',
      reviewer_project_calls=0, reviewer_test_calls=0, reviewer_plant_calls=0,
      reviewer_selector_calls=0, reviewer_inference_calls=0, reviewer_rng_or_nonce_reads=0,
      reviewer_new_research_trials=0))
report = '''Spec narrow correction review: PASS at df05d4403571dec278036ecbaa22564c2b08c9fd.

The original 548e4255 preflight findings are preserved separately. All three are closed: issued inspection-task counts and method denominators are explicit; arrived-report provenance, validity and named-threshold scope are exported with null/status for absent arrivals; native structural validation counters remain separate from model evaluations, with absent original instrumentation marked NA. CSV raises on extra fields. The exporter imports only standard-library code and invokes only Git metadata commands. Its clean/pinned-source, native hash, unique-output and failure-record gates remain intact. The parent may execute the frozen saved-only extraction once; outputs are not yet independently accepted.

A02 also passes static and saved-record review. EvidenceLedger rebuilds the historical snapshot at review time. The dossier whitelist limits positive support after all adverse/invalid checks, so it cannot hide contemporaneous counterevidence; the independent current check remains mandatory. Three literal cases cover support valid then but expired now, omitted counterevidence valid then but expired now, and later counterevidence that blocks the current question. Original red has 2 assertion failures and 0 errors; corrected green passes 3 tests; compatibility passes 14 tests. The receipts count 37 parent-instrumented finite closure calls; a successful saved CLI child adds 1, giving derived total 38. All recorded source-guard blobs match Git. Two fixture files omitted from those guards match original/current saved Git identities; that post-execution identity check cannot prove contemporaneous guarding. This limited evidence and independent source/contract reasoning support the finite API correction, not a scientific gain.

The corrected exporter/plan/closure blobs are unchanged in metadata revision 1e07b3be. The original 164 runs, NO_PRACTICAL_GAIN primary and original audit packet remain unchanged. Generic fault confirmation, missed-report truth and pre-failure benefit remain unmeasured design/coverage limits. No project code, test, model, selector, RNG, nonce or physical call was executed by this reviewer.
'''
with (OUT / 'report.md').open('x', encoding='utf-8', newline='\n') as stream:
    stream.write(report)
save('manifest.json', dict(schema='aegisdc-independent-spec-review-artifacts-v1', source=FINAL,
     artifacts={p.name: dict(sha256=digest(p.read_bytes()), bytes=p.stat().st_size)
                for p in sorted(OUT.iterdir()) if p.is_file() and p.name != 'manifest.json'},
     excluded=['Self-hash', 'Runtime caches']))
print(json.dumps(dict(status='PASS', source=FINAL, artifacts=len(list(OUT.iterdir())),
      manifest_sha256=digest((OUT / 'manifest.json').read_bytes()),
      guard_blobs=[r['pinned_source_blobs_verified'] for r in engineering],
      reviewer_project_calls=0)))
