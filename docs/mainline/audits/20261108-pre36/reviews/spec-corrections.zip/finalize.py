"""Seal the closed stdout log without changing the original review manifest."""
import hashlib
import json
from pathlib import Path

out = Path(__file__).resolve().parent
sha = lambda raw: hashlib.sha256(raw).hexdigest()
correction = dict(
    classification='REVIEW_MANIFEST_FINAL_LOG_CLOSURE',
    reason='The original manifest was written before review-attempt-01.log received its final stdout line. Preserve that manifest and bind the now-closed log in final-manifest.json.',
    original_manifest_sha256=sha((out/'manifest.json').read_bytes()),
    author_project_calls=0)
with (out/'manifest-closure-note.json').open('x', encoding='utf-8', newline='\n') as stream:
    stream.write(json.dumps(correction, indent=2)+'\n')
manifest = dict(schema='aegisdc-independent-spec-final-artifacts-v1',
    source='df05d4403571dec278036ecbaa22564c2b08c9fd',
    artifacts={p.name:dict(sha256=sha(p.read_bytes()), bytes=p.stat().st_size)
        for p in sorted(out.iterdir()) if p.is_file() and p.name!='final-manifest.json'},
    excluded=['Self-hash', 'Runtime caches'])
with (out/'final-manifest.json').open('x', encoding='utf-8', newline='\n') as stream:
    stream.write(json.dumps(manifest, indent=2)+'\n')
print(json.dumps(dict(status='PASS', artifacts=len(manifest['artifacts']),
                     final_manifest_sha256=sha((out/'final-manifest.json').read_bytes()))))
