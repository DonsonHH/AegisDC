# F02 — explicit accounting missing for registered secondary reporting categories

Audited source: `2dfe5537e4f95fa605f325b060ef32223dafb4f6`. `docs/mainline/30-comparison-protocol-v1.json:414–417` requires separate reporting of `provenance_valid_confirmation`, `misleading_reports_by_declared_world_truth`, `missed_distinguishable_reports`, and `actual_effect_vs_public_verified_closure`.

The committed31/34/35 result/readout artifacts and current analyzers do not provide an explicit consolidated outcome or `NOT_EVALUATED` accounting for all four categories. Some underlying quantities are present: original per-run audits retain inspection/intervention counts, and `development_run_evidence.py` explicitly says verified closure is not evaluated without a post-action protocol. Saved records contain the actual inspection feedback, truth snapshots, dispositions and model-evaluation counters. Their existence is not the same as delivering every promised report category.

This is a reporting/definition gap in the meeting's R6 business-value and R7 traceability coverage, separate from the valid primary service/cost arithmetic. It does not invalidate the164 unique executions or change `NO_PRACTICAL_GAIN`. A completeness claim should provide an explicit saved-only secondary ledger, with evidence pointers and independent units, before treating this requirement as closed.

Where the original protocol did not define a reproducible counterfactual missed-report denominator or truth rule, do not create a new success metric after seeing outcomes and do not make new selector/sensor draws. Record `NOT_EVALUATED`/`UNDEFINED_BY_FROZEN_PROTOCOL` and its reason. Actual effect, task-level confirmation and evidence-verified closure must remain distinct; closure-disabled runs are not zero proven closure events.

Root has prepared a separate saved readout exporter for independent review; it has not been executed as part of this reviewer audit. A later corrective ledger supplements, rather than overwrites, the original2dfe report and native records. This observation is not a Fowler heuristic or an allegation that source data are missing.
