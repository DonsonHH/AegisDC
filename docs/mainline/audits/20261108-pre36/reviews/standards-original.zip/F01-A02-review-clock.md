# F01 / root A02 — historical false-alarm review uses the current snapshot clock

Audited source: `2dfe5537e4f95fa605f325b060ef32223dafb4f6`. File: `src/aegis_dc/verified_closure.py`, the `prior=deepcopy(frame)` block inside `assess_closure` (approximately lines214–230).

The code says the reviewer could use only records available at their review time. It filters dossier record identities and their observed/arrival times, but retains the current `as_of_s`, evidence clock, `age_s`, `availability` and `provenance_issues`. `_check` skips records whose retained availability is `expired`. The resulting `review_checks` can therefore fail for records that were valid when the authorized review was made.

This can affect the final result, not only a diagnostic: suppose old dossier samples were observed at1s/2s, arrived by2.1s and valid until3.5s. An authorized review at2.5s could use both. At the current5s decision they are expired, while independent fresh samples at4s/4.7s, valid until9s, satisfy the unchanged current criteria. The implementation's copied historical frame still marks old dossier samples expired, so `evidence_checks` fail even though correctly reconstructed review-time checks and independently required `current_checks` should both pass. The final authorized `FALSE_ALARM_REVIEWED` disposition may incorrectly remain open.

This is a conservative refusal/clock-provenance defect, not an unsafe closure or a Fowler smell. It conflicts with the documented time/evidence contract in `AGENTS.md`, the specification's record-time requirement and the function's own historical-review comment. It is a real implementation discrepancy in resolved ticket24. Root independently vetted the source finding and records it as A02.

Registered31–35 inputs use `closure_program=None`; this issue does not change their executed outcomes or the primary negative result. Before proceeding36, root will retain the original source/captures, define a bounded public-API engineering correction scope, rebuild a genuine review-time snapshot through the existing ledger semantics, preserve all current checks, and provide an explicit prospective source freeze/bridge. No original hash may be waived or rewritten.

The temporal example above is a static analytic explanation, not a newly executed fixture. Reviewer tests, inference, plant, selector, RNG, nonce and capture calls remain zero.
