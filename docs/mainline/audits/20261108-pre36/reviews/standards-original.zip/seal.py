"""Seal a saved-only reviewer packet without importing project code."""
from pathlib import Path
import hashlib
import json
import subprocess

ROOT = Path(r"C:\Users\Donson\Documents\ChatGPT\Renly")
OUT = ROOT / ".work/pre36-standards-audit-01"
SOURCE = "2dfe5537e4f95fa605f325b060ef32223dafb4f6"
BASE = "8e32a8075fb86de0818f8149d4e47cdae3170ad9"
META = "ff70946dccbb3dbc4c0cf5be3b82618267956cb7"
HELPER = OUT.parent / "32-standards-review-01/review.py"

def digest(data):
    return hashlib.sha256(data).hexdigest()

def git(*args):
    return subprocess.check_output(["git", "-C", str(ROOT), *args]).decode("utf-8").strip()

assert not (OUT / "manifest.json").exists(), "Never overwrite a sealed review."
assert git("rev-parse", SOURCE + "^{tree}") == "172ecc5214622f575abd9098dd83139718b9778f"
assert git("diff", "--name-only", SOURCE, META, "--", "src", "configs", "scripts", "tests", "evidence") == ""
summary = json.loads((OUT / "audit-01.log").read_text(encoding="utf-8").strip())
assert summary["checks"] == 888 and summary["registered_attempts"] == 164
assert "Supplement saved checks: 182" in (OUT / "supplement-01.log").read_text(encoding="utf-8")
assert digest(HELPER.read_bytes()) == "3517002d3010d02d55ef4e77382044f7ee75913c9621dffbf88d7f9b8c8c0f56"
receipt = {
    "schema": "aegisdc-independent-standards-audit-receipt-v1",
    "status": "ISSUES_FOUND_AT_FIXED_SOURCE",
    "source": SOURCE,
    "approved_baseline": BASE,
    "inventory_metadata": META,
    "tickets_covered": 35,
    "saved_and_static_checks": {"main": 888, "supplement": 182, "total": 1070},
    "engineering_originals": {"receipts": 11, "actual_runs": 38},
    "registered_originals": {"runs": 164, "native_members": 656, "physical_seconds": 1640, "returned_decisions": 1640},
    "findings": [
        {"id": "F01", "root_id": "A02", "ticket": "24", "disposition": "CONFIRMED_REVIEW_CLOCK_REFUSAL_REQUIRES_SEPARATE_CORRECTION_AND_PROSPECTIVE_FREEZE"},
        {"id": "F02", "ticket_scope": ["30", "34"], "disposition": "SECONDARY_REPORT_COMPLETENESS_REQUIRES_SAVED_READOUT_OR_EXPLICIT_NON_EVALUATION"},
    ],
    "primary_and_original_registered_outcomes": "UNCHANGED_BY_AUDIT",
    "reviewer_activity": {"tests": 0, "physical_runs": 0, "selectors": 0, "inference": 0, "training": 0, "rng": 0, "nonce_reads": 0, "captures": 0, "project_imports": 0, "tracked_edits": 0},
    "corrections_policy": "Do not overwrite this fixed-source packet; review fixes in an additive packet.",
}
(OUT / "receipt.json").write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
files = []
for path in sorted(OUT.iterdir()):
    if path.is_file() and path.name not in {"manifest.json", "seal-verification.json"}:
        data = path.read_bytes()
        files.append({"path": path.name, "bytes": len(data), "sha256": digest(data)})
manifest = {
    "schema": "aegisdc-independent-review-manifest-v1",
    "source": SOURCE,
    "files": files,
    "external_reviewer_dependency": {"path": "../32-standards-review-01/review.py", "bytes": HELPER.stat().st_size, "sha256": digest(HELPER.read_bytes()), "delivery_identity": "evidence/mainline/engineering/32-execution-freeze/support/manifest.json:integration/32-standards-review-01/review.py"},
    "excluded": ["manifest.json (self)", "seal-verification.json (post-seal receipt)", "runtime caches (none declared)"],
}
(OUT / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
saved = json.loads((OUT / "manifest.json").read_bytes())
for row in saved["files"]:
    data = (OUT / row["path"]).read_bytes()
    assert len(data) == row["bytes"] and digest(data) == row["sha256"], row["path"]
proof = {"status": "PASS", "source": SOURCE, "manifest_sha256": digest((OUT / "manifest.json").read_bytes()), "fresh_read_artifacts": len(files), "external_dependency_sha256": digest(HELPER.read_bytes()), "no_new_project_calls": True}
(OUT / "seal-verification.json").write_text(json.dumps(proof, indent=2) + "\n", encoding="utf-8")
print(json.dumps(proof))
