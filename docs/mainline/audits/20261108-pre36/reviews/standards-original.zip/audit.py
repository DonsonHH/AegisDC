"""Substantive saved/source Standards audit through35; no project-code imports."""
import ast
from collections import Counter
from hashlib import sha256
import importlib.util
from io import BytesIO
import json
from math import fsum,isclose,isfinite
from pathlib import Path
import re
from zipfile import ZipFile

OUT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('git_helpers',OUT.parent/'32-standards-review-01'/'review.py')
r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r)
r.ROOT=Path(r'C:\Users\Donson\Documents\ChatGPT\Renly')
SOURCE='2dfe5537e4f95fa605f325b060ef32223dafb4f6'
BASE='8e32a8075fb86de0818f8149d4e47cdae3170ad9'
META='ff70946dccbb3dbc4c0cf5be3b82618267956cb7'
blob=lambda p,rev=SOURCE:r.blob(p,rev)
doc=lambda p,rev=SOURCE:r.doc(p,rev)
checks=[];evidence=[];raw_runs=[];registered=[]


def check(ok,label,**details):
    if not ok:raise AssertionError(label)
    checks.append(dict(check=label,status='PASS',**details))


def parse_lines(raw):return [json.loads(line) for line in raw.splitlines()]
def same(a,b):return isclose(a,b,abs_tol=1e-8,rel_tol=1e-12)


def flatten_pins(value):
    result={}
    if type(value) is dict:
        for key,v in value.items():
            if type(v) is str and re.fullmatch('[0-9a-f]{64}',v) and key.startswith(('src/','scripts/','configs/','docs/','evidence/','.scratch/')):result[key]=v
            elif type(v) is dict:result.update(flatten_pins(v))
    return result


def receipt(path):
    data=doc(path);folder=path.rsplit('/',1)[0];artifacts=data.get('artifacts',{})
    check(bool(artifacts), 'Receipt has declared original artifacts '+path)
    expected={folder+'/'+name for name in artifacts};r.fetch(SOURCE,expected)
    check(all(sha256(blob(folder+'/'+name)).hexdigest()==h for name,h in artifacts.items()),'Every declared original artifact matches receipt '+path,files=len(artifacts))
    commit=data.get('execution_commit',data.get('source'))
    pins={}
    for key in ('pinned','runtime_sources','authoring_verification_tools','frozen_inputs','pinned_tools','execution_inputs'):pins.update(flatten_pins(data.get(key,{})))
    if pins:
        check(type(commit) is str and len(commit)==40,'Original receipt has immutable execution source '+path)
        r.fetch(commit,pins)
        check(all(sha256(blob(p,commit)).hexdigest()==h for p,h in pins.items()),'Recorded source/tool/input bytes match actual historical commit '+path,source=commit,pins=len(pins))
    evidence.append(dict(path=path,sha256=sha256(blob(path)).hexdigest(),original_artifacts=len(artifacts),execution_source=commit,source_pins=len(pins)))
    return data


def raw_run(path):
    folder=path.rsplit('/',1)[0];run=doc(path);scenario=doc(folder+'/scenario.json')
    required={folder+'/'+p for p in ('scenario.json','run.json','private-state.jsonl','balances.jsonl')};r.fetch(SOURCE,required)
    check(all(sha256(blob(folder+'/'+p)).hexdigest()==v['sha256'] for p,v in run['artifacts'].items()),'Raw returned member hashes exact '+folder)
    identity=run['code_identity'];r.fetch(identity['git_commit'],identity['files'])
    check(identity['implementation_has_changes'] is False and all(sha256(blob(p,identity['git_commit'])).hexdigest()==h for p,h in identity['files'].items()),'Raw physical runtime bytes match execution commit '+folder)
    trace=parse_lines(blob(folder+'/private-state.jsonl'));balances=parse_lines(blob(folder+'/balances.jsonl'))
    check(len(trace)==len(balances)+1 and trace[0]['time_s']==0 and trace[-1]['time_s']==run['inputs']['duration_s'],'Whole actual horizon has contiguous state/balance denominator '+folder)
    params={p['id']:p['value'] for p in scenario['parameters']};domains={d['id'] for d in scenario['domains']}
    check(len(domains)==8 and all(set(t['domains'])==domains for t in trace),'All eight domains have actual state at every saved point '+folder)
    step=run['inputs']['maximum_step_s'];max_energy=max_mass=0.0
    for left,right,b in zip(trace[:-1],trace[1:],balances):
        dt=right['time_s']-left['time_s'];service=left['domains']['it_service']
        if not (dt>0 and dt<=step+1e-8 and b['start_s']==left['time_s'] and b['end_s']==right['time_s']):raise AssertionError('Raw interval gap '+folder)
        demand=service['demand'];delivery=service['delivered']
        if not (0<=delivery<=demand and delivery<=min(service['capacities'].values())+1e-8 and same(b['demand_service_unit_s'],demand*dt) and same(b['delivered_service_unit_s'],delivery*dt) and same(b['service_deficit_time_s'],(demand-delivery)/demand*dt if demand else 0)):raise AssertionError('Joint service arithmetic '+folder)
        energy=fsum(b['storage_after_J'].values())-fsum(b['storage_before_J'].values())-(b['boundary_input_J']-b['boundary_output_J'])
        tolerance=params['energy_absolute_tolerance']+params['balance_relative_tolerance']*(abs(b['boundary_input_J'])+abs(b['boundary_output_J']))
        if abs(energy)>tolerance*1.01:raise AssertionError('Boundary/storage energy closure '+folder)
        max_energy=max(max_energy,abs(energy))
        for row in b['mass_accounts_kg'].values():
            residual=fsum([row['before_kg'],row['in_kg'],-row['out_kg'],-row['after_kg']]);max_mass=max(max_mass,abs(residual))
            if abs(residual)>params['mass_absolute_tolerance']:raise AssertionError('Actual mass closure '+folder)
        if min(b['capacity_slack_W'].values()) < -1e-6:raise AssertionError('Actual capacity breach '+folder)
        if 'heat_transfers_W' in b:
            heat=b['heat_transfers_W'];power=left['domains']['power']['actual_powers_W']['compute']
            if not same(b['component_energy_rates_W']['solid']+heat['solid_to_coolant']+heat['solid_to_room'],power):raise AssertionError('Heat is not actual executed compute power '+folder)
    check(all(same(fsum(b[k] for b in balances),run['summary'][k]) for k in ('demand_service_unit_s','delivered_service_unit_s','service_deficit_time_s','worker_travel_person_s','worker_work_person_s','tool_occupation_tool_s')),'Independent service/work totals reproduce saved interval rows '+folder)
    check(run['state_visibility']=='PRIVATE_PLANT_EVALUATOR_ONLY' and run['field_calibration']=='PENDING','Original actual states and calibration limits explicit '+folder)
    raw_runs.append(dict(path=path,execution_source=identity['git_commit'],points=len(trace),intervals=len(balances),duration_s=run['inputs']['duration_s'],maximum_independent_energy_residual_J=max_energy,maximum_independent_mass_residual_kg=max_mass,summary={k:run['summary'][k] for k in ('demand_service_unit_s','delivered_service_unit_s','service_deficit_time_s')}))
    return run


def source_contract(path,name,needles):
    raw=blob(path).decode();module=ast.parse(raw)
    candidates=[n for n in ast.walk(module) if isinstance(n,(ast.ClassDef,ast.FunctionDef,ast.AsyncFunctionDef)) and n.name==name]
    check(bool(candidates),'Actual implementation surface exists '+path+':'+name)
    node=candidates[0];body=ast.unparse(node)
    check(all(n in body for n in needles),'Actual implementation preserves declared boundary '+path+':'+name)
    return dict(path=path,symbol=name,line=node.lineno,sha256=sha256(blob(path)).hexdigest())


def main():
    check(r.git('rev-parse',SOURCE).decode().strip()==SOURCE and r.git('merge-base','--is-ancestor',BASE,SOURCE)==b'','Exact substantive source and approved-baseline ancestry guarded')
    check(not r.git('diff','--name-only',SOURCE,META,'--','src','configs','scripts','tests','evidence').strip(),'New audit metadata does not change audited implementation/evidence')
    inv=doc('docs/mainline/audits/20261108-pre36/ticket-inventory.json',META)
    check(inv['source']==SOURCE and inv['source_tree']==r.git('rev-parse',SOURCE+'^{tree}').decode().strip(),'Inventory bound to exact substantive source tree')
    check([t['ticket'] for t in inv['tickets']]==[f'{i:02}' for i in range(1,36)],'All35 tickets covered exactly once')
    for t in inv['tickets']:
        check(t['status']=='resolved' and sha256(blob(t['path'])).hexdigest()==t['ticket_sha256'] and doc(t['authority'])['status']=='ACCEPTED','Ticket/source/authority pointer identity only '+t['ticket'])
    model=doc('configs/full-facility-mainline-reserve-v6.json');ids={x['id'] for x in model['entities']}
    check(len(model['domains'])==8 and len(ids)==45 and len(model['parameters'])==113 and all(e['from'] in ids and e['to'] in ids for rows in model['graphs'].values() for e in rows),'Current shared entity identities close all four facility graphs')
    surfaces=[]
    specs=[('scenario.py','validate_scenario',['_parameters','_graphs']),('plant.py','_Plant',["actual['compute'] - solid_coolant - solid_air","delivery = min(p['service_demand']","Mass conservation residual","Energy conservation residual"]),('policy_execution.py','PolicySession',["submissions=[]","self.catalog_program","self._frame(time_s, inspections)","choose_work(frame"]),('decision_view.py','validate_current_frame',["expected = EvidenceLedger(received).snapshot(frame['as_of_s'])","_same_json(expected, presented)"]),('evidence_ledger.py','EvidenceLedger',["record['arrived_at_s'] > as_of_s","as_of_s >= record['valid_until_s']","independence='NOT_ESTABLISHED'"]),('belief.py','_eligible_records',['_copy_disposition','expired_before_arrival']),('belief.py','_choose_records',['shared_provenance','dependence_not_modeled']),('risk_scenarios.py','_catalog_for_frame',['UNMODELED','unmodeled causes cannot receive zero-mass substitutes']),('workforce_dispatch.py','CrewWorkforce',["frame['as_of_s'] == self.last_time","frame['nominal_knowledge'] == self.nominal","self.tools[t]['reserved_by']","if job['target'] in blocked"]),('inspection_execution.py','InspectionSession',['completed_at_s','minimum_work_s','snapshot','arrival_latency_s']),('intervention_execution.py','InterventionSession',["type(workforce) is CrewWorkforce","actual_work_not_completed","risk_closed=False"]),('verified_closure.py','assess_closure',['VERIFIED_CLOSED','SYMPTOM_RETREATED_PENDING_VERIFICATION','RISK_ACCEPTED','ESCALATED','FALSE_ALARM_REVIEWED']),('policy_budget.py','AdmissionBudget',['remaining','COMMON_CUMULATIVE_BUDGET_EXHAUSTED','terminal_report_refund=False']),('dispatch_policy.py','choose_work',['generated_tour=False','execution_permission=False']),('parameter_domain.py','prepare_domain_case',['ADMITTED_INITIALIZATION_NOT_TRAJECTORY_QUALIFIED',"scenario['graphs'] == reference['baseline']['graphs']"])]
    for file,name,needles in specs:surfaces.append(source_contract('src/aegis_dc/'+file,name,needles))
    # Declare the actual saved-record set before verifying its artifact hashes.
    receipts=['evidence/mainline/engineering/11-coupled/fixtures-b135ecff-01/receipt.json','evidence/mainline/engineering/15-truth/capture-01/receipt.json','evidence/mainline/engineering/18-beliefs/capture-01/receipt.json','evidence/mainline/engineering/21-workforce/capture-01/receipt.json','evidence/mainline/engineering/21-workforce/safety-closure-01/receipt.json','evidence/mainline/engineering/22-inspections/capture-01/receipt.json','evidence/mainline/engineering/23-interventions/capture-01/receipt.json','evidence/mainline/engineering/24-closure/capture-01/receipt.json','evidence/mainline/engineering/24-closure/capture-02/receipt.json','evidence/mainline/engineering/29-uncertainty-domain/prepared-01/receipt.json','evidence/mainline/engineering/29-uncertainty-domain/capture-01/receipt.json']
    raw_prefixes=['evidence/mainline/engineering/11-coupled/fixtures-b135ecff-01','evidence/mainline/engineering/15-truth/capture-01/audit/private-worlds','evidence/mainline/engineering/22-inspections/capture-01','evidence/mainline/engineering/23-interventions/capture-01','evidence/mainline/engineering/29-uncertainty-domain/capture-01']
    run_paths=sorted(p for prefix in raw_prefixes for p in r.tree(SOURCE,prefix) if p.endswith('/run.json'))
    (OUT/'declared-record-set.json').write_text(json.dumps(dict(source=SOURCE,receipts=receipts,raw_runs=run_paths,registered_phases=['31-development','33-confirmation','35-ablation'],interpretation='Full declared artifact SHA/source checks plus independent actual balance/public-clock/lifecycle arithmetic; no acceptance receipt alone is treated as behavioral proof.'),indent=2)+'\n',encoding='utf-8')
    for path in receipts:receipt(path)
    for path in run_paths:raw_run(path)
    # Saved hidden-world pair: different physical outcomes, byte-equal allowed inputs.
    prefix='evidence/mainline/engineering/15-truth/capture-01/audit'
    world_a=doc(prefix+'/private-worlds/A/run.json');world_b=doc(prefix+'/private-worlds/B/run.json')
    check(world_a['summary']['delivered_service_unit_s']!=world_b['summary']['delivered_service_unit_s'],'Truth-isolation witnesses contain genuinely different physical outcomes')
    frame_count=0
    for stream in ('common','open','closed'):
        a=doc(prefix+'/evaluator-traces/A/'+stream+'/private-decision-trace.json')['steps'];b=doc(prefix+'/evaluator-traces/B/'+stream+'/private-decision-trace.json')['steps']
        check([s['frame'] for s in a]==[s['frame'] for s in b] and [s['options'] for s in a]==[s['options'] for s in b],'Different hidden worlds have identical current allowed frames/consumer outputs '+stream)
        for step in a+b:
            frame=step['frame'];check(all(row['observed_at_s']<=row['arrived_at_s']<=frame['as_of_s'] for row in frame['evidence']['records']) and step['options']['execution_permission'] is False,'Saved evidence clocks and no physical permission in public view')
            frame_count+=1
    closure='evidence/mainline/engineering/24-closure/capture-02'
    expected={'action-only':'ACTION_COMPLETED_PENDING_VERIFICATION','condition-only':'SYMPTOM_RETREATED_PENDING_VERIFICATION','verified':'VERIFIED_CLOSED','false-alarm':'FALSE_ALARM_REVIEWED','false-alarm-adverse':'OPEN_UNCONFIRMED','risk-accepted':'RISK_ACCEPTED','escalated':'ESCALATED'}
    closure_states={}
    for case,status in expected.items():
        result=doc(closure+'/'+case+'/result.json');q=result['questions'][0]
        check(q['status']==status and q['risk_closed']==(status=='VERIFIED_CLOSED') and result['execution_permission'] is False,'Saved action/recovery/review disposition is distinct '+case)
        closure_states[case]=q['status']
    numeric=doc('evidence/mainline/engineering/12-numerical/final-entry-01/summary.json')
    check(len(numeric['cases'])==11 and 'Not a conservative bound' in numeric['metric_semantics'],'Numerical evidence retains finite qualification and no universal true-error claim')
    calibration=doc('evidence/mainline/engineering/18-beliefs/capture-01/calibration.json')
    check(calibration['atom_count']==64 and calibration['normalization']=='1' and calibration['classification']=='EXACT_SYNTHETIC_GENERATOR_ONLY','Belief calibration is a finite64-atom law, explicitly not field calibration')
    # All164 registered lifecycles, sources and native archives; no repeated execution.
    for phase,n in [('31-development',36),('33-confirmation',96),('35-ablation',32)]:
        root='evidence/mainline/research/'+phase+'/capture-01';data=doc(root+'/receipt.json');batch=doc(root+'/batch.json');rows=parse_lines(blob(root+'/attempts.jsonl'))
        files=r.tree(SOURCE,root);r.fetch(SOURCE,files)
        check({p[len(root)+1:] for p in files}==set(data['artifacts'])|{'receipt.json'} and all(sha256(blob(root+'/'+p)).hexdigest()==h for p,h in data['artifacts'].items()),'Whole registered durable original set exact '+phase,files=len(files))
        source=batch['execution_commit'];r.fetch(source,batch['pins'])
        check(all(sha256(blob(p,source)).hexdigest()==h for p,h in batch['pins'].items()),'Actual registered source/input/tool pins exact '+phase,pins=len(batch['pins']))
        check(len(rows)==n*2 and len(batch['slots'])==n and data['status']=='PASS' and data['source_unchanged'] is True and data['automatic_retries']==0,'Full completed unique lifecycle denominator '+phase)
        for i,slot in enumerate(batch['slots']):
            start,terminal=rows[2*i:2*i+2];case=root+f"/{slot['index']:02}-{slot['world_id']}-{slot['arm']}"
            check({k:v for k,v in start.items() if k!='recorded_at_utc'}==doc(case+'/start.json') and {k:v for k,v in terminal.items() if k!='recorded_at_utc'}==doc(case+'/terminal.json') and all(start[k]==terminal[k]==v for k,v in slot.items()) and start['source']==terminal['source']==source and start['status']=='STARTED' and terminal['status']=='COMPLETED' and terminal['physical_call_started'] is True and terminal['physical_returned'] is True,'Original per-slot charge/terminal/source record '+phase+'/'+str(slot['index']))
            original=doc(case+'/originals.json');raw=blob(case+'/originals.zip')
            check(sha256(raw).hexdigest()==original['archive_sha256'],'Every registered native archive matches original SHA '+phase+'/'+str(slot['index']))
            with ZipFile(BytesIO(raw)) as z:
                names=z.namelist()
                check(len(names)==len(set(names))==4 and set(names)==set(original['members']) and all(sha256(z.read(p)).hexdigest()==h for p,h in original['members'].items()),'Every native member remains byte-exact '+phase+'/'+str(slot['index']))
        expected_total=dict(started=n,completed=n,failed=0,interrupted=0,unrun=0,charged_simulated_s=n*10,charged_scheduled_decisions=n*10,returned_decisions=n*10)
        check(data['total']==expected_total,'Independent registered budget arithmetic '+phase)
        registered.append(dict(phase=phase,source=source,attempts=n,journal_rows=len(rows),simulated_seconds=n*10,native_archives=n,native_members=n*4))
    outcome=doc('evidence/mainline/research/34-paired-analysis/results.json');ablation=doc('evidence/mainline/research/35-ablation/results.json');progress=doc('docs/mainline/progress.json')
    check(outcome['planned_denominator']==outcome['completed_primary_pairs']==16 and len(outcome['pairs'])==16 and outcome['status']=='NO_PRACTICAL_GAIN' and same(outcome['mean_service_delta_s'],fsum(p['service_delta_s'] for p in outcome['pairs'])/16),'Complete16-world mean and negative primary result reproduce saved pairs')
    check(ablation['planned_worlds']==8 and len(ablation['pairs'])==24 and ablation['completed_runs']==32 and ablation['primary_confirmation_result_unchanged']=='NO_PRACTICAL_GAIN','Eight-world mechanism interpretation does not inflate32 trajectories or change primary result')
    check(progress['research_trials']['attempts']==164 and progress['research_trials']['robustness']['attempts']==0 and progress['research_trials']['charged_s']==1640,'Global164 attempts1640 seconds and no36 run')
    check(r.git('rev-parse','pre-meeting-20261103^{}').decode().strip()=='076d9aa15c5bc99a5b7985f296e15543b7b0f3d7','Original pre-meeting archive commit identity preserved')
    # Independent static witness for F01/A02: expired-now != valid-at-review.
    closure_source=blob('src/aegis_dc/verified_closure.py').decode()
    start=closure_source.index('prior=deepcopy(frame)');end=closure_source.index('current_checks=',start);block=closure_source[start:end]
    check("prior['as_of_s']" not in block and "['availability']" not in block and "['provenance_issues']" not in block,'F01 confirmed: historical review copy never rebuilds time-derived evidence metadata')
    (OUT/'source-map.json').write_text(json.dumps(surfaces,indent=2)+'\n',encoding='utf-8')
    result=dict(status='ISSUE_FOUND_AT_FIXED_SOURCE',axis='Standards',source=SOURCE,approved_baseline=BASE,metadata=META,scope='Substantive01-35 source and saved evidence audit, not receipt-only acceptance',checks=checks,source_surfaces=surfaces,verified_receipts=evidence,raw_actual_runs=raw_runs,registered_phases=registered,public_truth_isolation_frames=frame_count,closure_saved_states=closure_states,findings=[dict(id='F01',root_id='A02',priority='P2',ticket='24',path='src/aegis_dc/verified_closure.py',line=closure_source[:start].count('\n')+1,kind='REAL_CONSERVATIVE_REVIEW_TIME_REFUSAL',hard_contract='Historical authorized review must use its own arrived evidence clock; current checks must independently remain mandatory.',registered31_35_impact='NONE: closure_program=None',blocks36='Pending root-vetted correction engineering evidence and explicit prospective source bridge; no hash waiver.')],optional_heuristics=[],no_calls=dict(tests=0,plant=0,selector=0,inference=0,training=0,RNG=0,nonce=0,new_capture=0,project_code_imports=0,tracked_edits=0))
    (OUT/'audit-result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(dict(status=result['status'],checks=len(checks),receipts=len(evidence),raw_actual_runs=len(raw_runs),registered_attempts=sum(p['attempts'] for p in registered),native_members=sum(p['native_members'] for p in registered),findings=result['findings'],no_calls=result['no_calls']),ensure_ascii=False))


if __name__=='__main__':main()
