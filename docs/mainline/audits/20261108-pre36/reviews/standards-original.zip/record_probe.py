import importlib.util,json
from pathlib import Path
out=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('inventory',out/'inventory_probe.py')
# Load only this audit's helper definitions via its immutable dependency.
spec=importlib.util.spec_from_file_location('git_helpers',out.parent/'32-standards-review-01'/'review.py')
r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r)
r.ROOT=Path(r'C:\Users\Donson\Documents\ChatGPT\Renly');rev='2dfe5537e4f95fa605f325b060ef32223dafb4f6'
prefixes=['evidence/mainline/engineering/11-coupled/fixtures-b135ecff-01','evidence/mainline/engineering/15-truth/capture-01','evidence/mainline/engineering/18-beliefs/capture-01','evidence/mainline/engineering/22-inspections/capture-01','evidence/mainline/engineering/23-interventions','evidence/mainline/engineering/24-closure','evidence/mainline/engineering/29-parameter-domain']
for prefix in prefixes:
    files=r.tree(rev,prefix)
    selected=sorted(p for p in files if p.rsplit('/',1)[-1] in {'receipt.json','check-results.json','outcomes.json','manifest.json','cases.json','run.json'})
    print(prefix,'FILES',len(files))
    for p in selected[:24]:
        d=r.doc(p,rev)
        print(json.dumps(dict(path=p,keys=list(d)[:12] if type(d) is dict else 'LIST'),ensure_ascii=False))
