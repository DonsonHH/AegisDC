"""Focused supplemental saved checks: typed crews and closure-disabled registered inputs."""
from collections import Counter
from io import BytesIO
import importlib.util
import json
from pathlib import Path
from zipfile import ZipFile
OUT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('source_audit',OUT/'audit.py')
a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a)
doc,blob,check=a.doc,a.blob,a.check


def main():
    typed=[]
    for case in ('capture-01','safety-closure-01'):
        prefix='evidence/mainline/engineering/21-workforce/'+case
        run=a.raw_run(prefix+'/run.json');trace=a.parse_lines(blob(prefix+'/private-state.jsonl'))
        for point in trace:
            people=point['domains']['people_tools_work'];active=set(people['active_requests'])
            if active&set(people['queued_requests']):raise AssertionError('Task active and queued')
            for worker,state in people['workers'].items():
                if state['request_id'] is not None and state['request_id'] not in active:raise AssertionError('Worker lacks unique active task')
                if state['status']=='working' and (state['location_id'] is None or state['location_id'] in point['domains']['space_access']['blocked_location_ids']):raise AssertionError('Actual work under blocked access')
            if any(v['reserved_by'] is not None and v['reserved_by'] not in active for v in people['tools'].values()):raise AssertionError('Tool reservation outside active task')
        totals=run['summary']
        check(a.same(totals['worker_wait_person_s'],sum(totals[k] for k in ('access_check_person_s','rendezvous_wait_person_s','queue_wait_person_s'))),'Typed worker waiting subledger is not double-counted '+case)
        typed.append(dict(case=case,work_records=run['work_records'],summary={k:totals[k] for k in ('worker_travel_person_s','worker_work_person_s','worker_wait_person_s','access_check_person_s','rendezvous_wait_person_s','queue_wait_person_s')}))
    normal=typed[0]['summary']
    check(normal['worker_travel_person_s']==60 and normal['worker_work_person_s']==60 and normal['worker_wait_person_s']==62 and normal['access_check_person_s']==2,'Canonical two-specialist reference independently reproduces60 travel60 work62wait with checks included')
    check(any(w['completed_at_s']==91 and w['work_started_at_s']==61 for w in typed[0]['work_records'] if w['status']=='completed'),'Actual typed crew starts61s and completes91s')
    closure_free=0;models=Counter();native_model_counter=set()
    for phase in ('31-development','33-confirmation','35-ablation'):
        root='evidence/mainline/research/'+phase+'/capture-01'
        for slot in doc(root+'/batch.json')['slots']:
            folder=root+f"/{slot['index']:02}-{slot['world_id']}-{slot['arm']}"
            with ZipFile(BytesIO(blob(folder+'/originals.zip'))) as z:run=json.loads(z.read('run.json'))
            program=run['inputs']['dispatch_program']
            check(program['closure_program'] is None,'Actual registered input disables C24 closure '+phase+'/'+str(slot['index']))
            closure_free+=1;native_model_counter.add(run['model_calls'])
            for item in run['policy_computation_audit']:models.update(item['model_evaluations'])
    check(closure_free==164 and models['action_value']>0,'All164 actual inputs confirm A02 cannot affect original registered outcomes; finite model evaluations still executed')
    # Actual variations in the canonical same-facility episode, beyond domain labels.
    root='evidence/mainline/engineering/11-coupled/fixtures-b135ecff-01/combined-episode-CLI'
    states=[p['domains'] for p in a.parse_lines(blob(root+'/private-state.jsonl'))]
    ranges=lambda xs:[min(xs),max(xs)]
    behavior=dict(power_actual_compute_W=ranges([s['power']['actual_powers_W']['compute'] for s in states]),backup_ups_energy_J=ranges([s['backup']['ups_energy_J'] for s in states]),backup_generator_modes=sorted({s['backup']['reserve_states']['generator']['mode'] for s in states}),lake_flow_m3_s=ranges([s['facility_cooling']['lake_pump']['volume_flow_m3_s'] for s in states]),equipment_temperature_K=ranges([s['equipment_environment']['solid_temperature_K'] for s in states]),service_delivered=ranges([s['it_service']['delivered'] for s in states]),control_compute_permitted=sorted({s['control_monitoring']['compute_permitted'] for s in states}),floor_mass_kg=ranges([s['space_access']['floor_water_mass_kg'] for s in states]),access_blocked=sorted({bool(s['space_access']['blocked_location_ids']) for s in states}),worker_states=sorted({w['status'] for s in states for w in s['people_tools_work']['workers'].values()}))
    check(all(behavior[k][0]<behavior[k][1] for k in ('power_actual_compute_W','backup_ups_energy_J','lake_flow_m3_s','equipment_temperature_K','service_delivered','floor_mass_kg')) and len(behavior['backup_generator_modes'])>1 and behavior['control_compute_permitted']==[False,True] and behavior['access_blocked']==[False,True] and 'working' in behavior['worker_states'],'Same episode exhibits actual eight-domain power/reserve/flow/thermal/service/control/access/work changes')
    result=dict(status='PASS_SAVED_SUPPLEMENT_NO_NEW_CALLS',source=a.SOURCE,checks=a.checks,raw_runs=a.raw_runs,typed_crews=typed,registered_closure_free_runs=closure_free,registered_finite_model_evaluations=dict(models),native_legacy_model_counter_values=sorted(native_model_counter),same_facility_actual_behavior=behavior,scope=dict(tests=0,plant=0,selector=0,inference=0,training=0,RNG=0,nonce=0,new_capture=0,project_code_imports=0,tracked_edits=0))
    (OUT/'supplement-result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:v for k,v in result.items() if k not in ('checks','raw_runs','typed_crews')},ensure_ascii=False));print('Supplement saved checks:',len(a.checks))


if __name__=='__main__':main()
