"""Source-pinned audit inventory extraction, never a research runtime import."""
from hashlib import sha256
import importlib.util
import json
from pathlib import Path
OUT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('git_helpers',OUT.parent/'32-standards-review-01'/'review.py')
r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r)
r.ROOT=Path(r'C:\Users\Donson\Documents\ChatGPT\Renly')
SOURCE='2dfe5537e4f95fa605f325b060ef32223dafb4f6'
META='ff70946dccbb3dbc4c0cf5be3b82618267956cb7'
inv=r.doc('docs/mainline/audits/20261108-pre36/ticket-inventory.json',META)
assert inv['source']==SOURCE and inv['source_tree']==r.git('rev-parse',SOURCE+'^{tree}').decode().strip()
rows=[]
for t in inv['tickets']:
    authority=r.doc(t['authority'],SOURCE)
    assert sha256(r.blob(t['path'],SOURCE)).hexdigest()==t['ticket_sha256']
    rows.append(dict(ticket=t['ticket'],title=t['title'],ticket_path=t['path'],authority=t['authority'],authority_keys=list(authority),source_fields={k:v for k,v in authority.items() if type(v) in (str,int) and (k in ('status','actual_root_source','source_commit','accepted_candidate','execution_source','data_delivery','scope','package','packet','originals','manifest','receipt','protocol','evidence','numerical_summary') or ('source' in k or 'path' in k))}))
(OUT/'inventory-summary.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
for row in rows: print(json.dumps(row,ensure_ascii=False))
