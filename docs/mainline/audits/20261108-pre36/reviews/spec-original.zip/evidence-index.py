"""Bind exact per-ticket saved evidence locations to the fixed audited source."""
import hashlib
import json
import subprocess
from pathlib import Path
ROOT=Path('C:/Users/Donson/Documents/ChatGPT/Renly');OUT=Path(__file__).resolve().parent
SOURCE='2dfe5537e4f95fa605f325b060ef32223dafb4f6'
E='evidence/mainline/engineering/';R='evidence/mainline/research/'
index={
'01':['docs/MAINLINE.md','.scratch/full-facility-mainline/spec.md','docs/adr/0003-complete-facility-mainline.md'],
'02':['configs/full-facility-mainline-reserve-v6.json'],
'03':[E+'03-healthy-site/normal-37432b25/run.json'],
'04':[E+'11-coupled/fixtures-b135ecff-01/independent-checks.json','docs/mainline/power-verification.md'],
'05':[E+'11-coupled/fixtures-b135ecff-01/independent-checks.json','docs/mainline/water-verification.md'],
'06':['configs/materials/reference-r134a-saturation.json','docs/mainline/phase-domain.md'],
'07':[E+'21-workforce/safety-closure-01/run.json','docs/mainline/environment-verification.md'],
'08':[E+'11-coupled/fixtures-b135ecff-01/independent-checks.json'],
'09':[E+'11-coupled/fixtures-b135ecff-01/independent-checks.json'],
'10':[E+'23-interventions/capture-01/backup-request/run.json',E+'11-coupled/fixtures-b135ecff-01/independent-checks.json'],
'11':[E+'11-coupled/fixtures-b135ecff-01/independent-checks.json'],
'12':[E+'12-numerical/capture-04/assessment.json',E+'12-numerical/capture-04/runs-index.json',E+'12-numerical/capture-01/capture-status.json'],
'13':[E+'13-replay/capture-01/causal-baseline/request.json',E+'13-replay/capture-01/causal-baseline/trajectory/run.json',E+'13-replay/capture-01/causal-command/trajectory/run.json'],
'14':[E+'14-evidence/capture-01/cli/public/snapshot.json'],
'15':[E+'15-truth/capture-01/audit/evaluator-traces/A/common/private-decision-trace.json',E+'15-truth/capture-01/audit/evaluator-traces/B/common/private-decision-trace.json'],
'16':[E+'16-sensors/capture-01/independent-checks.json',E+'16-sensors/capture-01/cli-primary/public-model.json'],
'17':[E+'17-nonfixed/capture-01/cli/before-arrival/public-snapshot.json',E+'17-nonfixed/capture-01/cli/arrived/public-snapshot.json'],
'18':[E+'18-beliefs/capture-01/calibration.json',E+'18-beliefs/capture-01/archived-trajectory.json'],
'19':[E+'19-risk-scenarios/capture-01/check-results.json',E+'26-candidate/reference/online-baseline-inspect.json'],
'20':[E+'20-action-value/capture-01/check-results.json'],
'21':[E+'21-workforce/capture-01/run.json',E+'21-workforce/safety-closure-01/run.json'],
'22':[E+'22-inspections/capture-01/public-before-completion.json',E+'22-inspections/capture-01/public-before-arrival.json',E+'22-inspections/capture-01/public-at-arrival.json'],
'23':[E+'23-interventions/capture-01/expired-authority/run.json',E+'23-interventions/capture-01/compute-power/run.json',E+'23-interventions/capture-01/backup-request/run.json'],
'24':[E+'24-closure/capture-01/action-only/result.json',E+'24-closure/capture-01/condition-only/result.json',E+'24-closure/capture-01/verified/result.json'],
'25':[E+'25-baselines/capture-01/no-human/run.json',E+'25-baselines/capture-01/fifo/run.json','docs/mainline/25-policy-execution.md'],
'26':[E+'26-candidate/capture-20261107-02/exact-baseline/decision.json',E+'26-candidate/capture-20261107-02/exact-candidate/decision.json',E+'26-candidate/capture-20261107-02/nonadaptive-candidate/decision.json'],
'27':[E+'27-full-loop/capture-20261107-02/original/trajectory/run.json'],
'28':[E+'28-negative-controls/capture-20261107-04/false_report/trajectory/run.json','docs/mainline/28-negative-controls-contract.md'],
'29':['configs/full-facility-parameter-domain-v1.json',E+'29-uncertainty-domain/reference/v6-parameter-inventory-v1.json'],
'30':['docs/mainline/30-comparison-protocol-v1.json','docs/mainline/evidence/30-protocol-lock.json'],
'31':[R+'31-development/results.json',R+'31-development/capture-01/batch.json',R+'31-development/capture-01/receipt.json'],
'32':[R+'32-confirmation-freeze/prepared-01/receipt.json',R+'32-confirmation-freeze/prepared-02/receipt.json','docs/mainline/evidence/30-confirmation-execution-lock.json'],
'33':[R+'33-confirmation/capture-01/batch.json',R+'33-confirmation/capture-01/receipt.json',R+'33-confirmation/capture-01/attempts.jsonl'],
'34':[R+'34-paired-analysis/results.json',R+'34-paired-analysis/verified-facts.json'],
'35':[R+'35-ablation/results.json',R+'35-ablation/capture-01/batch.json',R+'35-ablation/capture-01/receipt.json','docs/mainline/evidence/30-ablation-execution-lock.json'],
}
paths=sorted({p for values in index.values() for p in values})
raw=subprocess.check_output(['git','cat-file','--batch'],cwd=ROOT,input=''.join(SOURCE+':'+p+'\n' for p in paths).encode())
offset=0;blobs={}
for path in paths:
    end=raw.index(b'\n',offset);h=raw[offset:end].split();assert len(h)==3 and h[1]==b'blob',path
    start=end+1;size=int(h[2]);blobs[path]=raw[start:start+size];offset=start+size+1
assert offset==len(raw)
output={ticket:[dict(path=p,sha256=hashlib.sha256(blobs[p]).hexdigest(),bytes=len(blobs[p])) for p in values] for ticket,values in index.items()}
with (OUT/'ticket-evidence-index.json').open('x',encoding='utf-8') as f:json.dump(dict(source=SOURCE,tickets=output),f,indent=2);f.write('\n')
plan_ref='4073b619'
plan_path='docs/mainline/audits/20261108-pre36/saved-readout-plan.json'
plan_raw=subprocess.check_output(['git','cat-file','blob',plan_ref+':'+plan_path],cwd=ROOT)
review=dict(status='PASS_SEMANTICS_FOR_SAVED_ONLY_COMPLETION',plan_commit=plan_ref,plan_path=plan_path,
    plan_sha256=hashlib.sha256(plan_raw).hexdigest(),finding_alias='F1 in Spec audit = A01 in root audit',
    closure_rule='Complete measured/NA disclosure can close reporting blocker; undefined generic fault/prevention endpoints remain design/coverage limits.',
    ticket36='Scientifically permissible as original finiteV6 robustness comparison only after confirmed implementation checks and reporting disclosure close; no wholeR6/field/autonomous-discovery claim.',
    safeguards=['All164 runs, no exclusions','Historical/current named signal findings and denominators separate','No manual vibration truth from healthy-family labels',
      'No false negative from absent inspection','Effects separate from closureNA','Timeliness is not pre-failure benefit','PrimaryNO_PRACTICAL_GAIN and frozen budgets preserved'],
    new_project_calls=0,new_tests=0,new_plant_calls=0,new_selectors=0,new_inference=0,new_rng_calls=0,nonce_file_reads=0)
with (OUT/'readout-plan-semantic-review.json').open('x',encoding='utf-8') as f:json.dump(review,f,indent=2);f.write('\n')
print(json.dumps(dict(status='PASS_EXACT_EVIDENCE_INDEX',tickets=len(index),unique_saved_paths=len(paths),readout_plan='PASS_SEMANTICS')))
