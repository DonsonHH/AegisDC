"""Substantive01–35 audit: source text and saved artifacts only, no project imports."""
import ast
import hashlib
import io
import json
import math
import subprocess
import zipfile
from pathlib import Path

ROOT=Path('C:/Users/Donson/Documents/ChatGPT/Renly');OUT=Path(__file__).resolve().parent
SOURCE='2dfe5537e4f95fa605f325b060ef32223dafb4f6'
BASE='8e32a8075fb86de0818f8149d4e47cdae3170ad9'
AUDIT_METADATA='ff70946dccbb3dbc4c0cf5be3b82618267956cb7'
used={};observations=[]
def git(*a):return subprocess.check_output(['git',*a],cwd=ROOT)
def sha(raw):return hashlib.sha256(raw).hexdigest()
def raw(path):
    value=git('cat-file','blob',SOURCE+':'+path);used[path]=sha(value);return value
def read(path):return json.loads(raw(path))
def note(key,value):observations.append(dict(key=key,value=value))
subprocess.run(['git','merge-base','--is-ancestor',BASE,SOURCE],cwd=ROOT,check=True)
inventory=json.loads((ROOT/'docs/mainline/audits/20261108-pre36/ticket-inventory.json').read_bytes())
assert inventory['source']==SOURCE and inventory['source_tree']==git('rev-parse',SOURCE+'^{tree}').decode().strip()
assert len(inventory['tickets'])==35
for row in inventory['tickets']:assert sha(raw(row['path']))==row['ticket_sha256']
for p in ['docs/meetings/2026-11-03-research-reset.md','docs/MAINLINE.md','.scratch/full-facility-mainline/spec.md','docs/adr/0003-complete-facility-mainline.md','GLOSSARY.md']:
    raw(p)
log=git('log','--oneline',BASE+'..'+SOURCE)
changes=git('diff','--name-status',BASE+'...'+SOURCE,'--','src','configs','tests','scripts')
with (OUT/'commit-log.txt').open('xb') as f:f.write(log)
with (OUT/'scoped-change-list.txt').open('xb') as f:f.write(changes)

# Inspect the actual closed public boundaries, rather than acceptance labels.
modules=['scenario','runtime_contract','plant','power','heat_transfer','thermodynamics','refrigerant_initialization','water_envelope','environment','local_control','reserve','replay','replay_format',
    'evidence_ledger','decision_view','sensor_channels','live_sensor_execution','nonfixed_evidence','belief','risk_scenarios','action_value',
    'workforce','workforce_dispatch','inspection_execution','intervention_execution','verified_closure','policy_execution','dispatch_policy',
    'policy_budget','risk_condition_policy','lookahead_policy','evidence_projection','parameter_domain']
code={name:raw('src/aegis_dc/'+name+'.py').decode() for name in modules}
assert 'no voltage, reactive power' in code['power'].lower()
assert 'cable/transformer loss' in code['power']
assert 'if record[\'arrived_at_s\'] > as_of_s or record[\'observed_at_s\'] > as_of_s' in code['evidence_ledger']
assert "type(workforce) is CrewWorkforce" in code['inspection_execution'] and "type(workforce) is CrewWorkforce" in code['intervention_execution']
assert "risk_closed=False" in code['intervention_execution'] and "status='VERIFIED_CLOSED'" in code['verified_closure']
tree=ast.parse(code['decision_view'])
frame_fields=next(ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='FRAME_FIELDS' for t in n.targets))
assert frame_fields=={'schema','plan_id','facility_id','time_unit','as_of_s','nominal_knowledge','evidence','requests'}
note('public_boundary','Closed nominal/evidence/request frame; actual plant/worker internals absent. PolicySession passes only arrived records and task-local public feedback.')

model=read('configs/full-facility-mainline-reserve-v6.json')
assert len(model['domains'])==8 and len(model['entities'])==45 and len(model['parameters'])==113
assert {k:len(v) for k,v in model['graphs'].items()}==dict(physical=43,functional=23,control_information=20,access=5)
assert all(p['basis'] in {'synthetic_assumption','derived_reference','published_reference'} for p in model['parameters'])
note('facility_inventory',dict(domains=8,entities=45,parameters=113,relations=91,bases=dict((basis,sum(p['basis']==basis for p in model['parameters'])) for basis in {p['basis'] for p in model['parameters']})))
normal=read('evidence/mainline/engineering/03-healthy-site/normal-37432b25/run.json')
assert normal['summary']['demand_service_unit_s']==normal['summary']['delivered_service_unit_s']==600
assert normal['summary']['service_deficit_time_s']==0 and not normal['work_records']
assert normal['model_calls']==normal['training_calls']==0
note('healthy_and_default_no_tour',dict(duration_s=600,delivered=600,work_records=0,scope='Versioned original healthy v2 witness; not relabeled as later V6.'))
coupled=read('evidence/mainline/engineering/11-coupled/fixtures-b135ecff-01/independent-checks.json')
assert all(k in coupled for k in ['normal-600s','shared-AC-capacity','shared-rectifier-capacity','internal-valve-phase','joint-compute-network-storage','bias-link-power-latch','personnel-resource-conflicts','room-thermal-work-limit','finite-generator-hand'])
note('coupled_witness_families',list(coupled))

snapshot=read('evidence/mainline/engineering/14-evidence/capture-01/cli/public/snapshot.json')
assert all(r['observed_at_s']<=r['arrived_at_s']<=snapshot['as_of_s'] for r in snapshot['records'])
assert next(r for r in snapshot['records'] if r['id']=='human-false')['value'] is False
assert snapshot['independence']=='NOT_ESTABLISHED'
a=read('evidence/mainline/engineering/15-truth/capture-01/audit/evaluator-traces/A/common/private-decision-trace.json')
b=read('evidence/mainline/engineering/15-truth/capture-01/audit/evaluator-traces/B/common/private-decision-trace.json')
assert [r['frame'] for r in a['steps']]==[r['frame'] for r in b['steps']]
note('hidden_world_public_noninterference',dict(saved_equal_frame_ticks=[r['frame']['as_of_s'] for r in a['steps']],scope='Saved A/B preparation boundary plus current online-source trace; not an arbitrary-policy theorem.'))
sensors=read('evidence/mainline/engineering/16-sensors/capture-01/independent-checks.json')
note('sparse_sensor_saved_checks',{k:sensors[k] for k in ['configured_targets','missing_not_zero','one_ULP_future_hidden','private_future_payload_noninterference']})
before=read('evidence/mainline/engineering/17-nonfixed/capture-01/cli/before-arrival/public-snapshot.json')
after=read('evidence/mainline/engineering/17-nonfixed/capture-01/cli/arrived/public-snapshot.json')
assert before['as_of_s']<98==after['as_of_s']
assert not {'completed-numeric','detector-false-alarm','detector-miss'}&{r['id'] for r in before['records']}
assert {'completed-numeric','detector-false-alarm','detector-miss'}<={r['id'] for r in after['records']}
note('nonfixed_arrival_gate',dict(before=before['as_of_s'],arrival=98,named_signal_fixture_false_alarm_and_miss=True))
cal=read('evidence/mainline/engineering/18-beliefs/capture-01/calibration.json')
assert cal['classification']=='EXACT_SYNTHETIC_GENERATOR_ONLY' and cal['atom_count']==64 and cal['normalization']=='1'
assert cal['max_absolute_error']==0
note('belief_calibration_scope',dict(atoms=64,scope=cal['classification'],site_calibration=False))
risk=read('evidence/mainline/engineering/19-risk-scenarios/capture-01/check-results.json')
assert risk['maximum_absolute_error']==0 and risk['expected_full_horizon']['deficit_time_s']=='15877/16480'
reference=read('evidence/mainline/engineering/26-candidate/reference/online-baseline-inspect.json')
questions=reference['dispatch_program']['policy_program']['options']['catalog']['questions']
assert len(questions)==8 and sum(q['quantification']=='UNMODELED' for q in questions)==6
note('risk_completeness',dict(template_questions=8,unmodeled=6,unknown_not_zero=True,joint_service_loss='Joint outcomes + union of time windows; no component double-count'))
voi=read('evidence/mainline/engineering/20-action-value/capture-01/check-results.json')
case=next(c for c in voi['independent_cases'] if c['prior_fault']=='1/4')
alts=case['result']['question_values'][0]['alternatives']
assert [(x['expected']['service_deficit_time_s']['value'],x['expected']['person_s']['value']) for x in alts]==[(25,0),(20,20),(12.5,15.5)]
note('finite_action_value',dict(prior='1/4',defer=[25,0],direct=[20,20],inspect_then_act=[12.5,15.5],scope='Predicted finite law; no physical benefit inferred'))

crew=read('evidence/mainline/engineering/21-workforce/capture-01/run.json')
assert crew['work_records'][0]['work_started_at_s']==61 and crew['work_records'][0]['completed_at_s']==91
abort=read('evidence/mainline/engineering/21-workforce/safety-closure-01/run.json')
assert abort['work_records'][0]['status']=='aborted' and abort['summary']['worker_work_person_s']==0
note('actual_crew',dict(team_start_s=61,team_completion_s=91,team_work_person_s=crew['summary']['worker_work_person_s'],safety_case='aborted_before_professional_work'))
snaps=[read('evidence/mainline/engineering/22-inspections/capture-01/'+n+'.json') for n in ['public-before-completion','public-before-arrival','public-at-arrival']]
assert [len(d['records']) for d in snaps]==[0,0,1]
assert snaps[-1]['records'][0]['observed_at_s']==2.25 and snaps[-1]['records'][0]['arrived_at_s']==2.75
note('actual_measurement_gate',dict(early_record_counts=[0,0],sample_s=2.25,arrival_s=2.75,named_signal_only=True))
action=read('evidence/mainline/engineering/24-closure/capture-01/action-only/result.json')
condition=read('evidence/mainline/engineering/24-closure/capture-01/condition-only/result.json')
verified=read('evidence/mainline/engineering/24-closure/capture-01/verified/result.json')
assert action['questions'][0]['status']=='ACTION_COMPLETED_PENDING_VERIFICATION'
assert condition['questions'][0]['status']=='SYMPTOM_RETREATED_PENDING_VERIFICATION'
assert verified['questions'][0]['status']=='VERIFIED_CLOSED' and verified['questions'][0]['risk_closed'] is True
note('closure_states',dict(action=action['questions'][0]['status'],condition=condition['questions'][0]['status'],verified=verified['questions'][0]['status'],scope='Declared sampled criteria; no physical-restoration claim from assessment alone'))

plan=read('docs/mainline/30-comparison-protocol-v1.json')
development=read('evidence/mainline/research/31-development/results.json')
primary=read('evidence/mainline/research/34-paired-analysis/results.json')
ablation=read('evidence/mainline/research/35-ablation/results.json')
assert math.isclose(development['primary_mean_delta_service_s'],-1/24,abs_tol=1e-8)
assert primary['planned_denominator']==16 and primary['status']=='NO_PRACTICAL_GAIN' and primary['mean_service_delta_s']==.03515625
assert primary['mean_extra_paid_person_s']==-.96875 and len(primary['identified_world_ids'])==12
assert ablation['planned_worlds']==8 and ablation['completed_runs']==32
assert ablation['primary_confirmation_result_unchanged']=='NO_PRACTICAL_GAIN'
note('independent_effect_results',dict(development_worlds=6,primary_worlds=16,ablation_worlds=8,registered_runs=164,primary_delta_s=.03515625,primary_result='NO_PRACTICAL_GAIN',secondary_means=ablation['summary']))
compiler=raw('scripts/prepare_comparison_worlds.py').decode()
conf_analyzer=raw('scripts/analyze_registered_confirmation.py').decode()
abl_analyzer=raw('scripts/analyze_registered_ablation.py').decode()
for p in ['scripts/development_journal.py','scripts/registered_development.py','scripts/registered_confirmation.py','scripts/registered_ablation.py','scripts/comparison_release.py','scripts/ablation_planner.py','scripts/ablation_run_evidence.py']:
    raw(p)
input_doc=read('evidence/mainline/research/32-confirmation-freeze/prepared-02/inputs/confirmation-01/evidence_consistent_contingent.json')
assert len(input_doc['dispatch_program']['policy_program']['candidates'])==2
assert len(input_doc['dispatch_program']['policy_program']['options']['catalog']['questions'])==1
note('finite_decision_scope',dict(candidate_tasks=2,network_case_questions=1,physical_domains=len(input_doc['model']['domains']),limitation='Not autonomous sitewide problem discovery or optimal multi-crew scheduling'))
report_fields=plan['comparison']['report_separately']
assert all(k in report_fields for k in ['provenance_valid_confirmation','misleading_reports_by_declared_world_truth','missed_distinguishable_reports'])
assert not any(k in conf_analyzer or k in abl_analyzer for k in ['provenance_valid_confirmation','misleading_reports_by_declared_world_truth','missed_distinguishable_reports'])
assert 'NOT_EVALUATED_WITHOUT_POST_ACTION_PROTOCOL' in raw('scripts/development_run_evidence.py').decode()
with zipfile.ZipFile(io.BytesIO(raw('evidence/mainline/research/33-confirmation/capture-01/06-confirmation-01-evidence_consistent_contingent/originals.zip'))) as archive:
    original_run=json.loads(archive.read('run.json'))
feedback=original_run['inspection_public_feedback']
assert feedback and feedback[0]['scope']=='NAMED_SIGNAL_THRESHOLD_ONLY_NOT_FAULT_DIAGNOSIS'
assert feedback[0]['additional_evidence_factor'] is False
note('available_frozen_confirmation_contract',[{k:r[k] for k in ['task_id','record_id','observed_at_s','arrived_at_s','valid_until_s','confirmation','availability','current_confirmation','scope','additional_evidence_factor']} for r in feedback])

# A substantive matrix: source and saved behavior, not resolved/CI as proof.
rows=[]
def row(n,requirements,behavior,interfaces,witness,limitation='',gap=False):
    inv=inventory['tickets'][n-1]
    interfaces=['src/aegis_dc/'+p if '/' not in p.split(':')[0] and p.split(':')[0].endswith('.py') else p for p in interfaces]
    rows.append(dict(ticket=f'{n:02}',title=inv['title'].removeprefix('# '),meeting_requirements=requirements,
        implementation=behavior,source_interfaces=interfaces,saved_behavior=witness,
        assessment='PARTIAL_REPORTING_GAP_F1' if gap else 'CONSISTENT_WITH_DECLARED_FINITE_SCOPE',
        limitations=limitation,finding_ids=['F1'] if gap else [],requires_new_science_to_close=False))
row(1,['R1','R3','R5','R7'],'Single synthetic full-facility goal;42 dependent tickets, conditionalAI/RSI and incomplete overall goal.',
    ['docs/MAINLINE.md','docs/adr/0003-complete-facility-mainline.md','.scratch/full-facility-mainline/spec.md'],['35 source-pinned ticket criteria;164 phase attempts;36+ unstarted'])
row(2,['R2','R3','R7'],'Closed loader validates eight domains, typed shared identities/four graphs, SI/ranges/provenance and unknown site gaps.',
    ['scenario.py:validate_scenario/load_scenario','runtime_contract.py'],['V6 inventory8/45/113/91 directly counted'],'Structural validation alone is not a dynamics proof.')
row(3,['R1','R3','R4'],'Coupled plant uses actual power/heat/service; default empty work list produces no automatic tour.',
    ['plant.py:simulate_scenario/point/integrate/snapshot','workforce.py'],['Original600s healthy run: demand=delivered600, zero work and zero deficit'],'Originalv2 witness retains its own version; later V6 coupling checked separately.')
row(4,['R3','R4'],'Capacity-limited power allocation, prioritized protected loads, finite reserve inventory and explicit conversion losses.',
    ['power.py:allocate_power/allocate_reserve_power'],['11 coupled sharedAC/rectifier/distribution cases'],'Ideal aggregateMV/LV boundary; no separate voltage, transformer-loss or branch-protection model. Allowed explicit fidelity limit.')
row(5,['R3','R4'],'Paid hydraulic/valve operating points and HX heat exchange feed the same plant.',
    ['heat_transfer.py','plant.py:point/integrate'],['11 internal-valve/phase and capacity cases; saved mass/energy accounts'],'Fixed supported topology and declared lumped model; not a general site hydraulic network.')
row(6,['R3','R4','R7'],'ReferenceR134a fixed-volume M/U phase state, EOS-domain failure and condenser coupling.',
    ['thermodynamics.py:SaturationTable','refrigerant_initialization.py','plant.py'],['Numerical/phase saved witnesses and frozen reference table'],'Actual site working fluid unknown; no site-fluid inference or arbitrary-domain error theorem.')
row(7,['R3','R4','R6'],'Room heat/water/temperature conditions block access and can stop actual crew work.',
    ['environment.py','plant.py:update_room_work_access','workforce_dispatch.py'],['21 safety-closure actual abort;11 room/gate counterexamples'])
row(8,['R3','R4','R6'],'Delivered service is constrained jointly; external demand remains even during protection/derating.',
    ['power.py','plant.py:point/integrate'],['Healthy demand=delivered; registered saved trace/ledger independently reconciled'],'Normalized service capacity; no MW-to-FLOP/s claim.')
row(9,['R2','R3','R4'],'Local samples/control/protection advance independently of dispatch and can react before people.',
    ['local_control.py','plant.py:sample_control'],['11 bias/link/latch and invalid-flow cases'],'Local instrumentation permission does not become dispatch-wide observability.')
row(10,['R3','R4','R6'],'UPS, starter/fuel, maintenance and switching/backup-cooling delays affect actual protected supply.',
    ['reserve.py','power.py','plant.py:update_reserves'],['11 finite-generator case;23 backup-request native case'],'Only declared protected loads; no equipment-count availability estimate.')
row(11,['R3','R4'],'Integrated eight-domain event/capacity/crew counterexamples retain one facility and shared bottlenecks.',
    ['plant.py','runtime_contract.py'],['14 named coupled saved cases including resource conflicts, room, control and shared capacity'],'Finite engineering scope, not field validation.')
row(12,['R4','R7'],'Analytic/reference and refinement witnesses plus explicit domain failures; oldNO-GO preserved.',
    ['thermodynamics.py','heat_transfer.py','plant.py'],['12 final assessment/refinement artifacts and original failed captures'],'Frozen5/4/2 ladders and named cases; no universal trajectory error bound.')
row(13,['R4','R7'],'Recorded input/source/interpreter binding, unique outputs, effective horizon/step and balance-axis integrity.',
    ['replay.py:run_recorded/read_attempt/replay_attempt','replay_format.py'],['13 causal baseline/command and lifecycle originals'],'Replay of a world does not add an independent statistical unit.')
row(14,['R2','R7'],'Arrived snapshots retain missing/expired/conflicting/copy/provenance distinctions.',
    ['evidence_ledger.py:validate_ledger/EvidenceLedger.snapshot'],['14 snapshot: negativehuman report remainsFalse; future records absent; independence not presumed'])
row(15,['R1','R2','R7'],'Closed public frame excludes backend objects; online policy receives arrived evidence and task-local feedback.',
    ['decision_view.py:DecisionGateway/validate_current_frame','policy_execution.py:_frame/process'],['SavedA/B common public frames equal despite different private worlds'],'Finite noninterference witnesses; no hostile-host security guarantee.')
row(16,['R2','R7'],'Sparse enabled channels carry public observation law and private realization separately.',
    ['sensor_channels.py','live_sensor_execution.py'],['16 saved future-hidden, missing-not-zero and bias/noninterference checks'],'Coverage is declared; uninstrumented assets do not obtain synthetic full-state arrays.')
row(17,['R2','R6','R7'],'History/manual/work-order claims and typed saved-signal observations retain original time/provenance; numeric and binary errors explicit.',
    ['nonfixed_evidence.py:NonfixedEvidenceProducer/NonfixedSession'],['At97.999 three pending handheld records absent; at98 numeric/false-alarm/miss records present'],'Binary fixture errors are signal-law examples, not field alarm rates or formal-study generic fault labels.')
row(18,['R2','R4','R7'],'Finite belief filtering handles age, correlation, duplicate channels, model conflicts and unknowns without repair actions.',
    ['belief.py:infer_belief/exact_belief_context'],['64-atom exact synthetic calibration; normalized law and declared wrong comparators'],'Synthetic calibration only; not empirical site priors/performance.')
row(19,['R1','R4'],'Risk questions have scenarios, windows, joint service consequences, options and explicit unknown probability/consequence.',
    ['risk_scenarios.py:assess_risks'],['Saved joint witness matches15877/16480s; template8 questions with6UNMODELED'],'Unmodeled domains retain gaps/bounds; not full calibrated facility failure prediction.')
row(20,['R1','R4','R6'],'Defer/direct/inspect-then-act share information/model and full branch resource commitments; information itself changes no plant.',
    ['action_value.py:assess_action_value'],['Saved prior1/4 alternatives25/20/12.5s and0/20/15.5person-s'],'Finite predictive law, not actual or field effect.')
row(21,['R1','R3','R6'],'Actual typed multi-role crew travel, queue/rendezvous, qualification/tool/access and resource occupation.',
    ['workforce_dispatch.py:CrewWorkforce/prepare_work'],['Team starts61/completes91;60workperson-s; actual safety case aborted before work'],'Personnel are domain actors, not LLM agents; not optimal global crew assignment.')
row(22,['R2','R6','R7'],'Measurements require current actual completion, work duration, named tool/qualification and signal scope; reports delayed.',
    ['inspection_execution.py:InspectionSession'],['Saved public counts0/0/1 around2.25completion and2.75arrival'],'Confirmation is named-signal threshold only; not a fault diagnosis or risk closure.')
row(23,['R1','R4','R6'],'Four named authorized operations apply once after actual completion; expiry/abort yields no effect; demand retained.',
    ['intervention_execution.py:prepare_intervention/InterventionSession','plant.py:event order'],['23 network/filter/compute/backup and authority-negative originals'],'Lumped parameter effect is not verified physical repair.')
row(24,['R2','R6','R7'],'Action completion, symptom retreat, verified closure, false-alarm review, escalation and risk acceptance are distinct.',
    ['verified_closure.py:assess_closure/_check'],['Saved action-only pending, condition-only symptom, verifiedclosed cases'],'Declared sampled criteria only; formal31–35 deliberately have no post-action closure protocol.')
row(25,['R1','R4','R6'],'No-human, due-check, FIFO, risk-condition and near-problem lookahead use shared public action/permission boundary.',
    ['dispatch_policy.py:choose_work','policy_execution.py'],['25 saved no-human/FIFO and explicit periodic/risk/closure cases'],'Periodic is a comparator; it is not the default task definition or a one-factor intervention contrast.')
row(26,['R1','R2','R4'],'Candidate changes prospective report interpretation under the declared updater, allowing defer/direct/inspection.',
    ['lookahead_policy.py','evidence_projection.py'],['26 exact/nonadaptive/informative saved decision cases; later primary has12identifiable worlds'],'Curated finite candidate tasks; not autonomous sitewide discovery or new general optimization algorithm.')
row(27,['R1','R3','R6'],'One same-facility replay couples exogenous load/maintenance/fault, protection, work/action and later closure.',
    ['policy_execution.py','plant.py','verified_closure.py'],['27 actual timeline:4automatic service recovery,6cleaning,8.5arrived-evidence closure'],'Engineering demonstration and original replay failures stay separate from research units.')
row(28,['R1','R6','R7'],'Normal/false cue/automatic recovery/too-late intervention retain real costs and failure/no-benefit traces.',
    ['inspection_execution.py','intervention_execution.py','verified_closure.py'],['28 frozen four negative-control trajectories'],'Selected engineering controls do not estimate general false-alarm or miss rates.')
row(29,['R3','R4','R7'],'Parameter provenance and coupled admissibility separate scalar ranges, named joint points and site gaps.',
    ['parameter_domain.py','water_envelope.py','refrigerant_initialization.py'],['113parameter inventory and eight33s finite joint trajectories'],'106synthetic assumptions/7derivations; four site gaps retained; not a Cartesian or field-qualified domain.')
row(30,['R4','R6','R7'],'Primary criteria/units/pairing/methods/budgets/source/nonces/failure rules frozen before runs.',
    ['docs/mainline/30-comparison-protocol-v1.json','scripts/comparison_release.py'],['Original protocol/source lock and held-phase input release gates'],
    'Several promised secondary endpoints lack operational definitions or an explicit published status; seeF1.',True)
row(31,['R1','R6','R7'],'36 unique development runs retain resources, opportunity/choice diagnostics and negative mean; held conditions not used for tuning.',
    ['scripts/registered_development.py','scripts/development_journal.py','scripts/analyze_registered_development.py'],['Saved6world primary mean−1/24s,36/360/360 ledger'],
    'Development output reports work counts but not generic confirmation/miss endpoints;F1 crosses subsequent reporting.',True)
row(32,['R6','R7'],'Input/source/interpreter/cache and exact durable artifact lifecycle frozen, including original preparation failure.',
    ['scripts/prepare_confirmation.py','scripts/comparison_release.py'],['96input hashes; fixed64 interface and two hydraulic corrections recorded before any confirmation outcome'],'Old failures and superseded prospective locks retain their actual source.')
row(33,['R6','R7'],'96 original starts billed before calls, fixed matched inputs/order and source, exact raw archives and no retries.',
    ['scripts/registered_confirmation.py','scripts/development_journal.py'],['96completed/960s/960decisions native capture; data/source identities and frozen input parity'],'No raw-frame inflation of independent16world denominator.')
row(34,['R6','R7'],'Fixed16world primary/cost/stratum/missing-outcome arithmetic and all six methods published without upgrading negative result.',
    ['scripts/analyze_registered_confirmation.py','scripts/summarize_comparison_facts.py'],['Primary+.03515625s, paid−.96875; nohuman/candidate mean3.8125;NO_PRACTICAL_GAIN'],
    'Promised confirmation/report-error/completion-status readout omitted or left implicit;F1 must be closed before36.',True)
row(35,['R2','R4','R6','R7'],'Original three planner masks preserve byte-identical actual inputs; private nominal mapping keeps typed executor gates.',
    ['scripts/ablation_planner.py','scripts/ablation_run_evidence.py','scripts/registered_ablation.py'],['8worlds/32runs,128native members,56submission mappings and independent24contrasts'],
    'Dependency is bundled consequence/edge knowledge; team availability is not optimal assignment. Secondary readout remainsF1.',True)
assert len(rows)==35 and len({r['ticket'] for r in rows})==35
findings=[dict(id='F1',priority='P2',meeting_requirements=['R6','R7'],tickets=['30','31','34','35'],blocks_36=True,
    title='Frozen secondary outcome/readout promises are not completed or explicitly classified',
    source_refs=['docs/MAINLINE.md: scientific constraint2','docs/mainline/30-comparison-protocol-v1.json:409-417',
      'scripts/analyze_registered_confirmation.py:58-59','scripts/analyze_registered_ablation.py:47-53','scripts/development_run_evidence.py:278-283'],
    actual='34/35 results export service/cost/work/counter diagnostics, but no separately published confirmation/misleading/missed statuses and no distinction of measured signal findings from generic risk confirmation.',
    consequence='Cannot claim all promised business-value outcomes were evaluated. Primary16world result is still valid and negative; no rerun or retuning is warranted.',
    resolution='Before36, add a separately versioned saved-only metric-status/readout with exact frozen definitions or NOT_OPERATIONALIZED/NOT_EVALUATED reasons. Report existing threshold feedback/timing only within its named-signal contract. Preserve all original records and primary criteria.')]
endpoint_mapping=[
 dict(endpoint='completed_inspections / completed_interventions',frozen_support='development_run_evidence.py:278-281: bound inspection task ids and status==completed; raw work records',classification='DEFINED_AND_DERIVABLE',gap='31 publishes counts;34/35 retain raw work dispositions but omit separate counts'),
 dict(endpoint='unconfirmed_or_aborted_work',frozen_support='work_records statuses and inspection_public_feedback.confirmation enums',classification='PARTLY_DEFINED',gap='Abort/reject/task completion can be counted. Generic unconfirmed-risk denominator is not defined; keep task and signal meanings separate.'),
 dict(endpoint='provenance_valid_confirmation',frozen_support='InspectionSession.feedback:record_id/provenance/confirmation/observed-arrived-valid_until; public_feedback adds availability/current_confirmation',classification='SPECIFIC_SIGNAL_CONTRACT_AVAILABLE_GENERIC_RISK_UNDEFINED',gap='Historical threshold finding and endpoint-current threshold finding are distinct. Neither is a confirmed fault or risk closure.'),
 dict(endpoint='misleading_reports_by_declared_world_truth',frozen_support='17binary private latent_signal_above_threshold is defined; formal numeric flow has bound-contains-signal but manual vibration cue has no actual vibration truth',classification='NOT_OPERATIONALIZED_FOR_FORMAL_GENERIC_REPORTS',gap='Do not infer a false cue merely from a healthy-filter/family name or from an uninspected asset.'),
 dict(endpoint='missed_distinguishable_reports',frozen_support='No frozen opportunity universe, detectability decision or denominator in30.metric_definition',classification='NOT_OPERATIONALIZED',gap='No inspection/report is not itself a false negative; no counterfactual instrument draw or risk diagnosis may be invented.'),
 dict(endpoint='actual_effect_vs_public_verified_closure',frozen_support='Actual APPLIED/NO_EFFECT events; feedback risk_closed=False; closure_program=None; audit.verified_closure explicit NOT_EVALUATED_WITHOUT_POST_ACTION_PROTOCOL',classification='EFFECT_MEASURABLE_CLOSURE_NOT_EVALUATED',gap='Publish explicitNA for risk closure, rather than0 verified outcomes or a repair claim.'),
 dict(endpoint='earlier detection / pre-failure prevention',frozen_support='Issued/arrived/work/sample/report times are recorded. No frozen pre-failure truth/onset/diagnosis endpoint in31–35',classification='GLOBAL_R6_SCOPE_NOT_OPERATIONALIZED_PRE35',gap='Can add labeled descriptive timeliness; cannot call it early-warning/prevention gain. Absence alone is not a separate pre35 implementation failure.')]
result=dict(status='SUBSTANTIVE_AUDIT_PARTIAL_R6_BLOCKS36',audited_source=SOURCE,audited_tree=inventory['source_tree'],baseline=BASE,
    metadata_revision=AUDIT_METADATA,meeting_requirements=['R1','R2','R3','R4','R5','R6','R7'],ticket_count=35,findings=findings,
    allowed_limits=['Ideal aggregateMV/LV electrical boundary; separate transformer/branch detail not claimed',
      'Unknown real-site fluid/topology/parameters and synthetic probabilities explicitly allowed',
      'Finite curated task/catalog scope, not sitewide autonomous discovery or optimal crews',
      'Numerical/engineering witnesses do not establish a universal error/field theorem'],
    future_not_pre35_failures=['36robustness','37final synthesis/reproduction','38AI/RSI eligibility','39-42conditional increments/final goal audit'],
    negative_results_preserved=dict(primary='NO_PRACTICAL_GAIN',delta_s=.03515625,registered_runs=164),
    new_project_calls=0,new_tests=0,new_plant_calls=0,new_selectors=0,new_inference=0,new_training=0,new_rng_calls=0,nonce_file_reads=0,new_experiments=0)
for name,value in [('ticket-matrix.json',rows),('endpoint-status-analysis.json',endpoint_mapping),('observations.json',observations),('findings.json',findings),('receipt.json',result),('source-and-evidence-hashes.json',used)]:
    with (OUT/name).open('x',encoding='utf-8') as f:json.dump(value,f,indent=2,ensure_ascii=False);f.write('\n')
with (OUT/'ticket-matrix.md').open('x',encoding='utf-8') as f:
    f.write('# 01–35 substantive evidence matrix\n\nAudited source `'+SOURCE+'`; accepted labels/CI are not used as substantive proof.\n\n')
    for row in rows:
        f.write('## '+row['ticket']+' '+row['title']+'\n\n')
        f.write('Meeting: '+', '.join(row['meeting_requirements'])+'. Assessment: '+row['assessment']+'.\n\n')
        f.write(row['implementation']+'\n\nSource: '+'; '.join(row['source_interfaces'])+'\n\nSaved behavior: '+'; '.join(row['saved_behavior'])+'\n\n')
        if row['limitations']:f.write('Limit/gap: '+row['limitations']+'\n\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['findings','allowed_limits','future_not_pre35_failures','meeting_requirements']},ensure_ascii=False))
