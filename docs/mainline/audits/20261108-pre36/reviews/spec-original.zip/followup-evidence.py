"""Additional substantive saved-case observations; no runtime/model execution."""
import json
import re
import subprocess
from pathlib import Path
ROOT=Path('C:/Users/Donson/Documents/ChatGPT/Renly');OUT=Path(__file__).resolve().parent
REF='2dfe5537e4f95fa605f325b060ef32223dafb4f6';E='evidence/mainline/engineering/'
def raw(p):return subprocess.check_output(['git','cat-file','blob',REF+':'+p],cwd=ROOT)
def read(p):return json.loads(raw(p))
result={}
ticket_paths=subprocess.check_output(['git','ls-tree','-r','--name-only',REF,'.scratch/full-facility-mainline/issues'],cwd=ROOT).decode().splitlines()
graph={}
for p in ticket_paths:
    match=re.search(r'/([0-9]{2})-[^/]+\.md$',p)
    if not match:continue
    text=raw(p).decode();line=next(x for x in text.splitlines() if x.startswith('**Blocked by:**'))
    graph[match[1]]=set(re.findall(r'(?<!\d)[0-9]{2}(?!\d)',line))
assert len(graph)==42 and all(dep in graph for deps in graph.values() for dep in deps)
def visit(node,active,done):
    assert node not in active,'Cycle'
    if node in done:return
    active.add(node)
    for dep in graph[node]:visit(dep,active,done)
    active.remove(node);done.add(node)
done=set()
for node in graph:visit(node,set(),done)
result['ticket_graph']=dict(count=42,no_cycles=True,all_references_bound=True)
expired=read(E+'23-interventions/capture-01/expired-authority/run.json')
backup=read(E+'23-interventions/capture-01/backup-request/run.json')
compute=read(E+'23-interventions/capture-01/compute-power/run.json')
assert all(r['outcome']=='NO_EFFECT' for r in expired['intervention_private_audit']['events'])
assert backup['summary']['backup_fan_energy_J']==5000
assert compute['summary']['demand_service_unit_s']==3
result['intervention_cases']=dict(expired=[dict(task_id=r['task_id'],outcome=r['outcome'],reason=r['reason']) for r in expired['intervention_private_audit']['events']],
    backup_fan_energy_J=backup['summary']['backup_fan_energy_J'],compute_offered_demand_preserved=compute['summary']['demand_service_unit_s'])
nohuman=read(E+'25-baselines/capture-01/no-human/run.json');fifo=read(E+'25-baselines/capture-01/fifo/run.json')
assert not nohuman['work_records'] and all(d['choice']['chosen_candidate_id'] is None for d in nohuman['policy_public_decisions'])
result['baseline_behaviors']=dict(nohuman_tasks=0,fifo_tasks=[dict(id=r['id'],status=r['status']) for r in fifo['work_records']])
choices={name:read(E+'26-candidate/capture-20261107-02/'+name+'/decision.json') for name in ['exact-baseline','exact-candidate','nonadaptive-candidate']}
result['finite_candidate_choices']={name:{k:obj[k] for k in ['chosen_candidate_id','reason','policy'] if k in obj} for name,obj in choices.items()}
loop=read(E+'27-full-loop/capture-20261107-02/original/trajectory/run.json')
assert loop['summary']['demand_service_unit_s']==9.75 and loop['summary']['delivered_service_unit_s']==7.75 and loop['summary']['service_deficit_time_s']==2
result['coupled_loop']=dict(demand=9.75,delivered=7.75,deficit_s=2,work=[dict(id=w['id'],status=w['status'],completed_at_s=w.get('completed_at_s')) for w in loop['work_records']],
    closure=[dict(time_s=d['frame']['as_of_s'],states=[q['status'] for q in d['choice'].get('question_lifecycle',{}).get('questions',[])]) for d in loop.get('policy_public_decisions',[])])
negative=read(E+'28-negative-controls/capture-20261107-04/false_report/trajectory/run.json')
assert negative['summary']['service_deficit_time_s']==0 and negative['summary']['worker_work_person_s']>0
result['false_report_engineering_control']=dict(deficit_s=negative['summary']['service_deficit_time_s'],paid_work_person_s=negative['summary']['worker_work_person_s'],
    scope='Named negative-control engineering case only; not a generic formal-study false-alarm estimator')
inventory=read(E+'29-uncertainty-domain/reference/v6-parameter-inventory-v1.json')
result['parameter_inventory_fields']=list(inventory)
result['scope']=dict(source=REF,new_project_calls=0,new_tests=0,new_plant_calls=0,new_selectors=0,new_inference=0,new_training=0,new_rng_calls=0,nonce_file_reads=0)
with (OUT/'followup-observations.json').open('x',encoding='utf-8') as f:json.dump(result,f,indent=2,ensure_ascii=False);f.write('\n')
print(json.dumps(result,ensure_ascii=False))
