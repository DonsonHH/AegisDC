"""Frozen718 interval closure plus independent age counterexample.

No plant/worker/observation generation, model or full-suite execution.
"""
from copy import deepcopy
from fractions import Fraction
import hashlib
import json
import math
import os
from pathlib import Path
import subprocess
import sys

HERE=Path(__file__).resolve().parent
FROZEN=HERE/'frozen-source'
OLD=Path(r'C:/Users/Donson/AppData/Local/Temp/aegisdc-review-14-source-spec-attachments')
sys.path.insert(0,str(FROZEN/'src'))
from aegis_dc.evidence_ledger import EvidenceLedger

red=json.loads((OLD/'declared-bound-precision-red-01.json').read_text(encoding='utf-8'))
int_input=red['integer_float_idempotence_probe']['integer_bound_input']
float_input=red['integer_float_idempotence_probe']['float_bound_input']
int_view=EvidenceLedger(int_input).snapshot(0)
float_view=EvidenceLedger(float_input).snapshot(0)
assert int_input==float_input and int_view==float_view
assert len(int_view['conflicts'])==1
tiny_input=red['binary_float_probe']['input']
tiny_view=EvidenceLedger(tiny_input).snapshot(0)
assert len(tiny_view['conflicts'])==1
again=json.loads((OLD/'declared-bound-idempotence-red-02.json').read_text(encoding='utf-8'))
ledger=EvidenceLedger(again['input']);before=ledger.snapshot(0)
before_bytes=json.dumps(before,sort_keys=True)
assert ledger.ingest(again['ingested_record'])=='ALREADY_PRESENT'
assert json.dumps(ledger.snapshot(0),sort_keys=True)==before_bytes
dup=deepcopy(again['input']);dup['records'].append(again['ingested_record'])
assert json.dumps(EvidenceLedger(dup).snapshot(0),sort_keys=True)==before_bytes

checks={}
def pair(a,ea,b,eb):
    doc=deepcopy(int_input)
    for row,value,error in zip(doc['records'],(a,b),(ea,eb)):
        row['value']=value;row['quality']['error_bound']=error
    return doc
def check(name,doc,count,kind='disjoint_declared_bounds',cut=0):
    snapshot=EvidenceLedger(doc).snapshot(cut)
    assert len(snapshot['conflicts'])==count,(name,snapshot)
    if count:assert snapshot['conflicts'][0]['kind']==kind
    json.dumps(snapshot,allow_nan=False)
    checks[name]=dict(status='PASS',input=doc,as_of_s=cut,snapshot=snapshot)

u=math.ulp(1.)
check('exact_touching_binary_bounds',pair(1.,u/2,1.+u,u/2),0)
check('exact_overlapping_binary_bounds',pair(1.,3*u/4,1.+u,3*u/4),0)
check('positive_eighth_ULP_gap',pair(1.,u/8,1.+u,3*u/4),1)
check('positive_eighth_ULP_gap_roles_reversed',pair(1.+u,3*u/4,1.,u/8),1)
b=math.nextafter(-1.,math.inf);un=b+1.
check('negative_values_positive_declared_gap',pair(-1.,un/8,b,3*un/4),1)
check('minimum_subnormal_zero_bound',pair(0.,0.,math.nextafter(0.,math.inf),0.),1)
check('negative_zero_same_declared_point',pair(-0.,0,0.,0.),0)
doc=pair(1.,0,2.,0);doc['records'][0]['quality']=dict(status='unknown',error_bound=None,note='Unknown calibration stays unknown.')
check('unknown_quality_is_reported_difference',doc,1,'different_reported_values')
doc=pair(1.,0,2.,0);doc['records'][1].update(observed_at_s=1,arrived_at_s=1)
check('different_observation_epoch_is_not_conflict',doc,0,cut=1)
doc=pair(1.,0,2.,0);doc['records'][1]['arrived_at_s']=2
check('future_declared_gap_not_visible',doc,0,cut=math.nextafter(2,-math.inf))
check('same_gap_visible_exactly_on_arrival',doc,1,cut=2)
doc=pair(1.,0,2.,0);doc['records'][1]['value']=None;doc['records'][1]['quality']=dict(status='unknown',error_bound=None,note='Missing value has no bound.')
check('missing_value_does_not_become_interval',doc,0)

# Root observed this second hunk first. Independently rerun its exact inputs at
# frozen718; do not reuse its result as the expected production answer.
root_probe=json.loads((HERE/'root-age-original-probe-01.json').read_text(encoding='utf-8'))
assert root_probe['source_pin']=='7183714334154dbb0d00f06f647ed51931e24416'
time_docs=root_probe['inputs'];cut=root_probe['as_of_s']
assert time_docs[0]==time_docs[1]
ages=[EvidenceLedger(doc).snapshot(cut) for doc in time_docs]
int_age=ages[0]['records'][0]['age_s'];float_age=ages[1]['records'][0]['age_s']
assert cut==2**53+1
assert int_age==cut and float_age!=cut and ages[0]!=ages[1]
age_counterexample=dict(source='Root first discovery, Spec independently replayed exact inputs',
                        inputs=time_docs,as_of_s=cut,snapshots=ages,
                        mathematically_expected_age=cut,integer_encoded_age=int_age,float_encoded_age=float_age,
                        expected='Equal decoded numeric timestamp meaning must preserve the same observation age and detached decision view.',
                        classification='NEW_TIME_AGE_P2_SEPARATE_FROM_CLOSED_INTERVAL_P2')

env=dict(os.environ,PYTHONPATH=str(FROZEN/'src'),PYTHONDONTWRITEBYTECODE='1')
cmd=[sys.executable,'-B','-X','utf8','-m','unittest','discover','-s','tests','-p','test_evidence*.py','-v']
done=subprocess.run(cmd,cwd=FROZEN,env=env,text=True,capture_output=True)
assert done.returncode==0,done.stderr
# This isolated scope contains precisely ledger12+precision3. Legacy evidence
# integrity tests copy the whole historic evidence tree and are not repeated.
assert 'Ran 15 tests' in done.stderr
(HERE/'target-tests.log').write_text(done.stderr,encoding='utf-8',newline='\n')
guard=json.loads((HERE/'source-guard-before.json').read_text(encoding='utf-8'))
after={name:hashlib.sha256((FROZEN/name).read_bytes()).hexdigest() for name in guard['executed_source_files']}
assert after==guard['executed_source_files']
writer=Path(r'C:/Users/Donson/Documents/ChatGPT/Renly/.work/worktrees/full-site-14')
author_after={name:hashlib.sha256((writer/name).read_bytes()).hexdigest() for name in guard['executed_source_files']}
record=dict(pin=guard['pin'],original_interval_finding=dict(status='CLOSED',original_mathematical_cases_replayed=2,equal_numeric_ingest_and_initial_duplicates_preserve_first_encoding=True,corrected_integer_snapshot=int_view,corrected_float_snapshot=float_view,corrected_tiny_gap_snapshot=tiny_view),
            independent_boundary_checks=checks,new_age_counterexample=age_counterexample,
            target_tests=dict(command=cmd,run=15,exit_code=done.returncode,scope='Only ledger12+precision3, no legacy raw-tree copying/full suite'),
            actual_executed_source_guard='PASS',executed_source_files=len(after),executed_source_after=after,
            author_source_after=author_after,
            author_authorized_later_changes={name:h for name,h in author_after.items() if h!=guard['author_files_at_start'][name]},
            guard_note='Tests run on exact Git718 copies; author is concurrently repairing the independent age hunk and visual source. No author mutation or false current-head acceptance is claimed.',
            physics_runs=0,full_suite_runs=0,model_calls=0,training_calls=0)
with (HERE/'interval-closure-and-age-red-01.json').open('x',encoding='utf-8',newline='\n') as stream:stream.write(json.dumps(record,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
print(json.dumps(dict(original_interval_finding='CLOSED',new_age_finding='OPEN',independent_boundary_checks=len(checks),author_targets=15,executed_source_guard='PASS',source_files=len(after),age_integer=int_age,age_float=float_age,physics_runs=0,full_suite_runs=0)))
