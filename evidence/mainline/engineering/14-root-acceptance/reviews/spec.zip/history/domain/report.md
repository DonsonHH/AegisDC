# Ticket 14 source28 closures and domain-admission finding

固定 `28e8756d1014646952efb3661d323a68b68bd3ef`，不覆盖 a9/718 两份历史报告。原两类 Spec P2 现分别为：**区间/重入已关闭，时间年龄已关闭**。根视觉 finding 另计。

原两数学区间反例及等值重入原样输入通过；Root 原 age 输入也已独立重放，两种等价时刻编码现均返回精确整数 `9007199254740993`，快照相同。执行的 25 个冻结文件与 Git28、前后字节守卫通过；没有物理、模型或全套运行。

**新增 P2：quality 端点域的准入仍随等价数字表示而变。** 此 hunk 由根先发现、Spec 用根原输入独立确认。合同要求等价 JSON 数字意义及闭合有界质量，但 `_record` 在精确冲突比较之前仍以原生 `value ± error` 调用 `_finite`。

令 `x=int(sys.float_info.max)-1`、误差界 `2**970`。只将该误差界从整数改为与之相等的 float，文档 `== True`，前者接受、后者因浮点双重舍入而以“Upper declared bound”拒绝。该问题在准入阶段，不表示已修复的精确冲突比较再次错误。

应对已解码数值先精确构造端点，再按明确一致的支持域判断；接受或拒绝必须一致，不能扩大误差界或舍改输入。现有 source28 capture 保持原身份，后续修订另行验收。根原探针 SHA：`8076db10ffb49177245fadb89e61b392aa1f7aaae9f3a384da448de49752c4ac`。

此中间版本的累计数值 Spec 状态：**旧 2 已闭，新 1 未闭**；不是正式票 14、M3 或整体研究完成。原样输入、准入结果及执行源守卫保存在 `aegisdc-review-14-final-source-spec-closure-attachments/two-closures-and-domain-red-01.json`。
