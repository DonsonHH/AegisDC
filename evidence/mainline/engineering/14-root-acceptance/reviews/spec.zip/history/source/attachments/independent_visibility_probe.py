"""Independent literal evidence timelines, provenance twins and atomicity.

No private plant, numerical run, posterior, worker execution or full suite.
"""
from copy import deepcopy
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import sys

HERE=Path(__file__).resolve().parent
FROZEN=HERE/'frozen-source'
sys.path.insert(0,str(FROZEN/'src'))
from aegis_dc.evidence_ledger import EvidenceLedger,validate_ledger


def document():
    return dict(schema='aegisdc-evidence-ledger-v1',id='public-literal-ledger',
        facility_id='synthetic-literal',basis='synthetic_assumption',time_unit='s',entity_ids=['pump-A'],
        observables=[dict(id='offset',quantity='temperature_offset',value_type='number',unit='K'),
                     dict(id='switch',quantity='binary',value_type='boolean',unit='1'),
                     dict(id='annotation',quantity='category',value_type='text',unit='1')],
        sources=[dict(id=s,kind=k,basis='synthetic_assumption',target_ids=['pump-A'],
                      observable_ids=['offset','switch','annotation'],dependency_group=None,
                      source_note='Independent static literal registry.')
                 for s,k in [('meter','fixed_sensor'),('ticket','work_order'),('person','human_report')]],records=[])


def row(name,value=10,observed=0,arrived=0,until=None,source='meter',observable='offset',
        origin=None,parent=None,quality=None):
    if quality is None:
        quality=dict(status='bounded',error_bound=.25,note='Hand-declared finite absolute bound.') if value is not None and observable=='offset' else dict(status='unknown',error_bound=None,note='No established calibration.')
    return dict(id=name,source_id=source,target_id='pump-A',observable_id=observable,
                unit='K' if observable=='offset' else '1',value=value,observed_at_s=observed,
                arrived_at_s=arrived,valid_until_s=until,quality=quality,
                provenance=dict(origin_id=origin or 'reported-'+name,copied_from_record_id=parent))


checks={}
def passed(name,**evidence):checks[name]=dict(status='PASS',**evidence)
def current(doc,when):return EvidenceLedger(doc).snapshot(when)
def rejected(name,doc):
    try:EvidenceLedger(doc)
    except ValueError as error:passed(name,error=str(error));return
    raise AssertionError(name+' unexpectedly accepted')


d=document();d['records']=[row('r',observed=9,arrived=10,until=12)]
assert current(d,math.nextafter(10,-math.inf))['records']==[]
assert current(d,10)['current_record_ids']==['r']
assert current(d,math.nextafter(12,-math.inf))['current_record_ids']==['r']
assert current(d,12)['records'][0]['availability']=='expired'
passed('strict_one_ULP_arrival_and_exclusive_expiry')
d=document();d['records']=[row('old',observed=-50,arrived=4,until=-1)]
s=current(d,4);assert s['current_record_ids']==[] and s['records'][0]['age_s']==54 and s['records'][0]['availability']=='expired'
passed('negative_history_late_arrival_keeps_old_age',snapshot=s)
d=document();d['records']=[row('bad',observed=1,arrived=0)];rejected('observation_after_arrival_rejected',d)
d=document();d['records']=[row('bad',until=0)];rejected('expiry_not_after_observation_rejected',d)

d=document();d['records']=[row('zero',0),row('negative',-2),row('false',False,observable='switch'),
                           row('missing',None),row('text-zero','0',observable='annotation')]
s=current(d,0);assert set(s['current_record_ids'])=={'zero','negative','false','text-zero'}
assert next(r for r in s['records'] if r['id']=='missing')['quality']['status']=='unknown'
assert next(r for r in s['records'] if r['id']=='false')['value'] is False
passed('zero_negative_false_text_and_missing_are_distinct',snapshot=s)

# All public static fields and arrived records are identical. The private queue
# varies in count, source, content, missingness and its internal copy cycle.
base=document();base['records']=[row('visible',12,observed=-5,arrived=-1,source='ticket',origin='carried-claim',parent='pending-X')]
hidden=deepcopy(base);hidden['records'] += [row('pending-X',999,observed=20,arrived=50,origin='private-X',parent='pending-Y'),row('pending-Y',-999,observed=30,arrived=60,origin='private-Y',parent='pending-X')]
changed=deepcopy(hidden);changed['records'][1]=row('pending-X',None,observed=21,arrived=55,source='person',origin='different-private',parent='pending-Z');changed['records'].pop()
for cut in (0,49,math.nextafter(50,-math.inf)):
    assert current(base,cut)==current(hidden,cut)==current(changed,cut)
passed('hidden_queue_count_payload_source_missing_and_cycle_do_not_affect_view',snapshot=current(hidden,0))

d=document();d['records']=[row('copy-A',source='ticket',origin='carried',parent='external-alarm'),row('copy-B',source='ticket',arrived=1,origin='carried',parent='external-alarm')]
s=current(d,1);assert s['provenance_issues']==[] and s['independence']=='NOT_ESTABLISHED'
assert any(g['kind']=='reported_copy_reference' and g['record_ids']==['copy-A','copy-B'] for g in s['correlation_groups'])
with_alarm=deepcopy(d);with_alarm['records'].append(row('external-alarm',99,observed=1,arrived=30,origin='unarrived-different'))
assert current(with_alarm,1)==s
passed('carried_origin_and_shared_external_reference_without_private_lookup',snapshot=s)
d=document();d['records']=[row('child',source='ticket',origin='claim-A',parent='parent'),row('parent',arrived=2,origin='claim-B')]
assert current(d,math.nextafter(2,-math.inf))['provenance_issues']==[]
s=current(d,2);assert s['provenance_issues']==[dict(kind='copy_origin_mismatch',record_ids=['child','parent'])]
assert any(g['kind']=='visible_copy_link' and g['record_ids']==['child','parent'] for g in s['correlation_groups'])
passed('visible_mismatched_origin_preserves_copy_link_without_trusted_root',snapshot=s)
d=document();d['records']=[row('A',arrived=1,origin='same',parent='B'),row('B',arrived=2,origin='same',parent='C'),row('C',arrived=3,origin='same',parent='A'),row('tail',arrived=4,origin='same',parent='B')]
assert current(d,math.nextafter(3,-math.inf))['provenance_issues']==[]
s=current(d,4);assert s['provenance_issues']==[dict(kind='visible_copy_cycle',record_ids=['A','B','C'])]
passed('only_completely_visible_cycle_is_reported_and_tail_is_not_cycle_member',snapshot=s)

d=document();d['records']=[row('a',10,until=3,quality=dict(status='bounded',error_bound=1,note='Exact literal interval.')),row('b',13,until=3,quality=dict(status='bounded',error_bound=.5,note='Exact literal interval.'))]
assert len(current(d,0)['conflicts'])==1
s=current(d,4);assert s['current_record_ids']==[] and len(s['conflicts'])==1
passed('expired_discrepancy_retained_as_audit_not_current_value',snapshot=s)
d['records'][1]['value']=12;d['records'][1]['quality']['error_bound']=1
assert current(d,0)['conflicts']==[]
passed('ordinary_touching_closed_bounds_are_not_conflicts')
d['records'][1].update(value=99,observed_at_s=1,arrived_at_s=1)
assert current(d,2)['conflicts']==[]
passed('sequential_observations_are_not_same_epoch_contradictions')
d=document();d['records']=[row('a',1,quality=dict(status='unknown',error_bound=None,note='Unknown instrument quality.')),row('b',2)]
s=current(d,0);assert s['conflicts'][0]['kind']=='different_reported_values'
assert s['records'][0]['quality']['error_bound'] is None
passed('unknown_quality_has_no_invented_bound_or_truth',snapshot=s)

d=document();d['records']=[row('a',1)];ledger=EvidenceLedger(d);before=ledger.snapshot(0)
same=deepcopy(d['records'][0]);same['value']=1.0;assert ledger.ingest(same)=='ALREADY_PRESENT' and ledger.snapshot(0)==before
different=deepcopy(d['records'][0]);different['value']=2
try:ledger.ingest(different)
except ValueError:pass
else:raise AssertionError('Conflicting duplicate accepted')
assert ledger.snapshot(0)==before
invalid=deepcopy(d['records'][0]);invalid['id']='bad';invalid['unit']='W'
try:ledger.ingest(invalid)
except ValueError:pass
else:raise AssertionError('Invalid unit accepted')
assert ledger.snapshot(0)==before
passed('ordinary_numeric_idempotence_and_invalid_ingest_atomicity')
added=row('new',2,arrived=1);assert ledger.ingest(added)=='ADDED';added['quality']['status']='broken';d['records'][0]['value']=-900
snap=ledger.snapshot(1);snap['records'][0]['value']=-700;snap['static_knowledge']['sources'][0]['target_ids'].clear()
assert sorted(r['value'] for r in ledger.snapshot(1)['records'])==[1.,2]
passed('input_ingest_and_snapshot_nested_values_are_detached')

executed=[]
class Forbidden:
    def __deepcopy__(self,memo):executed.append('executed');return 1
d=document();d['records']=[row('bad',Forbidden())];rejected('custom_object_rejected_before_copy_hook',d);assert not executed
d=document();d['records']=[row('cyclic')];d['records'][0]['value']=d;rejected('python_cycle_rejected_before_deepcopy',d)
for name,mutate in [('unknown_schema',lambda d:d.update(schema='future-v9')),
                    ('private_field',lambda d:d.update(private_truth=1)),
                    ('numeric_boolean',lambda d:d['records'][0].update(observable_id='switch',unit='1',value=0)),
                    ('unknown_source',lambda d:d['records'][0].update(source_id='private-source'))]:
    d=document();d['records']=[row('r')];mutate(d);rejected(name,d)

# The authoring tool must be a function of PUBLIC identity, not private runtime
# quantities. Run it on two private temp copies with identical IDs only.
spec=importlib.util.spec_from_file_location('frozen_fixture_builder',FROZEN/'scripts/build_evidence_fixture.py')
builder=importlib.util.module_from_spec(spec);spec.loader.exec_module(builder)
v6=json.loads((FROZEN/'configs/full-facility-mainline-reserve-v6.json').read_text(encoding='utf-8'))
outputs=[]
for suffix in ('A','B'):
    temp=HERE/('identity-twin-'+suffix);(temp/'configs').mkdir(parents=True,exist_ok=False)
    private=deepcopy(v6)
    if suffix=='B':
        for parameter in private['parameters']:
            if parameter['id']=='service_demand':parameter['value']=.9
            if parameter['id']=='local_temperature_bias':parameter['value']=-1
        private['runtime']['closed_location_ids']=['loc_it']
    (temp/'configs/full-facility-mainline-reserve-v6.json').write_text(json.dumps(private),encoding='utf-8')
    builder.ROOT=temp;outputs.append(builder.build())
assert outputs[0]==outputs[1]==json.loads((FROZEN/'configs/full-facility-evidence-v1.json').read_text(encoding='utf-8'))
passed('fixture_builder_uses_identity_only_not_private_parameters_or_runtime',entities=len(outputs[0]['entity_ids']),sources=len(outputs[0]['sources']))

guard=json.loads((HERE/'source-guard-before.json').read_text(encoding='utf-8'));writer=Path(r'C:/Users/Donson/Documents/ChatGPT/Renly/.work/worktrees/full-site-14')
after={name:hashlib.sha256((writer/name).read_bytes()).hexdigest() for name in guard['files']}
assert after==guard['files']
result=dict(status='PASS',pin=guard['pin'],independent_checks=len(checks),checks=checks,
            source_guard='PASS',guarded_files=len(after),actual_source_after=after,
            precision_finding='Separate confirmed arithmetic/idempotence red probes retained; these positive/negative availability checks do not close that finding.',
            physics_runs=0,full_suite_runs=0,model_calls=0,training_calls=0)
with (HERE/'independent-visibility-probe-01.json').open('x',encoding='utf-8',newline='\n') as stream:stream.write(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(status='PASS',independent_checks=len(checks),source_guard='PASS',guarded_files=len(after),physics_runs=0,full_suite_runs=0)))
