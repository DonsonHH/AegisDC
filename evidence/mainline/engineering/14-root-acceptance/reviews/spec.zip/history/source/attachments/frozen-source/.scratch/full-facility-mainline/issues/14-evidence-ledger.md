# 14: 接收有到达时间和共同来源的记录

**What to build:** 调度侧可接收资产、历史、测点、人工及现场证据，并区分观察时刻、到达时刻、误差和同源关系。

**Blocked by:** 12, 13

**Status:** claimed

**Milestone:** M3

- [ ] 未来、未到达和缺测记录不参与当前决策。
- [ ] 告警复制工单保留根来源，不自动当两条独立证据。
- [ ] 证据过期和来源冲突可见，未知质量不变成确定真值。

## Context

Read the fixed mainline, accepted scope ADR, specification, predecessor evidence and current progress. Work at the declared public interface. The scope remains one complete facility.

Read `docs/mainline/information-boundary.md` before defining dispatch-facing records. Evidence availability, candidate masks and execution feedback share the same information boundary; the private plant may enforce safety without exposing undeclared instantaneous observations.

## Evidence

Owner: `mainline_14_evidence`, branch `donson/mainline-14-evidence`, worktree
`.work/worktrees/full-site-14`, base `04e976c7934b4b2d54aa73794fe520482524be64`.
Implementation and root acceptance pending. The authorized public seams are the
closed evidence loader/ledger, explicit as-of snapshot, and CLI. The existing
hour-based foundation prototype and private V6 plant are preserved.
