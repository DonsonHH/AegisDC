"""Limited current delivery/literal readback; no old capture or full reruns."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

HERE=Path(__file__).resolve().parent
ROOT=Path(r'C:/Users/Donson/Documents/ChatGPT/Renly/.work/worktrees/full-site-14')
sys.path.insert(0,str(HERE/'frozen-source/src'))
from aegis_dc.evidence_ledger import EvidenceLedger

PIN='f9450246347e08dabfe9b40709e12da115a4de59'
DELIVERY='4b1997b72ada11f3ae518db25c552c65d51e72a4'
CANDIDATE='65eddd6908510371a6fcc913742b6c4197114270'
BASE=ROOT/'evidence/mainline/engineering/14-evidence'
FOLDER=BASE/'capture-03-admission'
def load(path):return json.loads(path.read_text(encoding='utf-8'))
def sha(raw):return hashlib.sha256(raw).hexdigest()
def git_bytes(commit,name):return subprocess.check_output(['git','show',commit+':'+name],cwd=ROOT)

index=load(ROOT/'docs/mainline/evidence/14.json')
for relative in ['docs/mainline/evidence/14.json','evidence/mainline/engineering/14-evidence/CURRENT.md']:
    assert (ROOT/relative).read_bytes()==git_bytes(CANDIDATE,relative)
assert index['status']=='IMPLEMENTED_PENDING_ROOT_ACCEPTANCE'
assert index['root_acceptance']=='PENDING' and index['overall_goal']=='ACTIVE'
assert index['execution_commit']==PIN and index['delivery_commit']==DELIVERY
assert index['latest_target_check']['run']==index['latest_target_check']['passed']==20
assert index['latest_target_check']['skipped']==0
assert index['full_regression']['historical_execution_commit']=='3c4e964061a77ddbd43f7ca0fee78f6aa9087c50'
assert index['full_regression']['historical_tests_run']==371
assert index['full_regression']['historical_tests_executed']==369
assert index['full_regression']['historical_optional_Torch_skips']==2

receipt=load(FOLDER/'receipt.json');declaration=load(FOLDER/'declaration.json')
assert receipt['execution_commit']==PIN
assert receipt['engineering_capture']=='PASS'
assert receipt['delivery_gate']=='PENDING_COMMIT_AND_FRESH_CHECKOUT'
assert receipt['full_regression_executions']==0
assert receipt['latest_full_regression']=='ROOT_INTEGRATION_REQUIRED'
assert receipt['target_tests']==20 and receipt['target_exit']==0
assert receipt['preserved_prior_originals']==43 and receipt['previous_corrected_source_entries']==200
assert all(receipt[k]==0 for k in ['registered_research_trials','model_calls','training_calls'])
names=set(declaration['declared_artifacts'])
assert len(names)==9 and names==set(receipt['artifacts'])
actual={p.relative_to(FOLDER).as_posix() for p in FOLDER.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix not in {'.pyc','.pyo'}}
assert actual==names|{'receipt.json'}
artifact_hashes={}
for name in sorted(actual):
    raw=(FOLDER/name).read_bytes();relative=(FOLDER/name).relative_to(ROOT).as_posix()
    assert raw==git_bytes(DELIVERY,relative)
    if name!='receipt.json':
        identity=receipt['artifacts'][name]
        expected=identity['sha256'] if isinstance(identity,dict) else identity
        assert sha(raw)==expected
    artifact_hashes[name]=sha(raw)
assert (FOLDER/'capture-failure.txt').read_bytes()==b''
assert 'Ran 20 tests' in (FOLDER/'target.stderr.txt').read_text(encoding='utf-8')
assert (FOLDER/'target.stderr.txt').read_text(encoding='utf-8').strip().endswith('OK')

runbook=load(FOLDER/'runbook-copy.json')
assert runbook['expected_load_status_each']=='ACCEPTED'
assert runbook['expected_target_tests']==20 and runbook['full_regression_executions']==0
outcomes=load(FOLDER/'outcomes.json')
assert outcomes['status']=='PASS' and outcomes['input_numeric_content_equal'] is True
assert outcomes['load_status']=={'integer':'ACCEPTED','floating':'ACCEPTED'}
assert outcomes['input_values_and_error_bounds_modified'] is False
inputs={name:load(FOLDER/('input-'+name+'.json')) for name in ['integer','floating']}
assert inputs['integer']==inputs['floating']
assert inputs['integer']['records'][0]['value']==int(sys.float_info.max)-1
assert inputs['integer']['records'][0]['quality']['error_bound']==2**970
for name,document in inputs.items():
    expected=outcomes['snapshots'][name]
    snapshot=EvidenceLedger(document).snapshot(expected['as_of_s'])
    assert snapshot==expected
    assert snapshot['records'][0]['value']==document['records'][0]['value']
    assert snapshot['records'][0]['quality']['error_bound']==document['records'][0]['quality']['error_bound']

fresh_path=BASE/'delivery-4b1997b7-fresh-01.json';fresh=load(fresh_path)
assert fresh_path.read_bytes()==git_bytes(CANDIDATE,fresh_path.relative_to(ROOT).as_posix())
assert fresh['status']=='PASS' and fresh['execution_commit']==PIN and fresh['delivery_commit']==DELIVERY
assert fresh['durable_artifacts']==9 and fresh['terminal_receipts']==1
assert fresh['target_tests']==20 and fresh['admission_encodings_accepted']==2
assert fresh['preserved_prior_originals']==43 and fresh['previous_corrected_source_entries']==200
assert (fresh['pinned_runtime_sources'],fresh['pinned_tools'],fresh['pinned_inputs'])==(50,116,38)
assert fresh['full_regression_rerun'] is False and fresh['physics_rerun'] is False
assert fresh['runtime_caches_required']==0
figure_hashes={}
for name,expected in index['root_visual_review']['current_figure_inputs_sha256'].items():
    path=BASE/'capture-02-correction/figures'/name
    assert sha(path.read_bytes())==expected
    figure_hashes[name]=expected
assert index['root_visual_review']['original_visual_findings']==1
assert index['root_visual_review']['closed']==1 and index['root_visual_review']['open']==0
assert index['root_visual_review']['browser_visual_qa'] is False

guard=load(HERE/'source-guard-before.json')
assert all(sha((ROOT/name).read_bytes())==expected for name,expected in guard['files'].items())
result=dict(status='PASS_LIMITED_CURRENT_DELIVERY_READBACK',pin=PIN,delivery=DELIVERY,candidate=CANDIDATE,
            current_durable_artifacts=9,terminal_receipts=1,artifact_hashes=artifact_hashes,
            independent_current_admission_literals_replayed=2,
            initial_pending_terminal_receipt_preserved=True,separate_fresh_proof_sha256=sha(fresh_path.read_bytes()),
            fresh_proof_attribution=dict(prior_originals=43,prior_corrected_source_entries=200,pinned_runtime=50,pinned_tools=116,pinned_inputs=38),
            prior_packages_or_200_entries_not_reprocessed=True,
            original_full_attribution=dict(execution='3c4e964061a77ddbd43f7ca0fee78f6aa9087c50',run=371,executed=369,optional_skips=2),
            current_full='ROOT_INTEGRATION_REQUIRED',root_visual_figure_bytes_unchanged=figure_hashes,
            root_visual_review_not_reclassified_as_Spec=True,
            source_guard='PASS',source_files=25,physics_runs=0,full_suite_runs=0,author_targets_repeated=0,
            full_ticket_root_acceptance_claimed=False)
with (HERE/'limited-delivery-readback-01.json').open('x',encoding='utf-8',newline='\n') as stream:stream.write(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(status=result['status'],current_durables=9,terminal=1,literals_replayed=2,source_guard='PASS',old_packages_reprocessed=False,physics_runs=0,full_suite_runs=0)))
