"""Only necessary independent closures for the three numeric Spec hunks."""
from copy import deepcopy
import hashlib
import json
import math
from pathlib import Path
import sys

HERE=Path(__file__).resolve().parent
FROZEN=HERE/'frozen-source'
sys.path.insert(0,str(FROZEN/'src'))
from aegis_dc.evidence_ledger import EvidenceLedger

EARLY=Path(r'C:/Users/Donson/AppData/Local/Temp/aegisdc-review-14-source-spec-attachments')
MIDDLE=Path(r'C:/Users/Donson/AppData/Local/Temp/aegisdc-review-14-precision-spec-attachments')
DOMAIN=Path(r'C:/Users/Donson/AppData/Local/Temp/aegisdc-review-14-final-source-spec-closure-attachments')
originals=HERE/'original-inputs';originals.mkdir(exist_ok=False)
def original(path):
    raw=path.read_bytes();(originals/path.name).write_bytes(raw)
    return json.loads(raw)
checks={}
def passed(name,**data):checks[name]=dict(status='PASS',**data)

r=original(EARLY/'declared-bound-precision-red-01.json')
int_input=r['integer_float_idempotence_probe']['integer_bound_input']
float_input=r['integer_float_idempotence_probe']['float_bound_input']
int_view=EvidenceLedger(int_input).snapshot(0);float_view=EvidenceLedger(float_input).snapshot(0)
assert int_input==float_input and int_view==float_view and len(int_view['conflicts'])==1
passed('original_integer_float_bound_conflict',integer_snapshot=int_view,float_snapshot=float_view)
small=EvidenceLedger(r['binary_float_probe']['input']).snapshot(0)
assert len(small['conflicts'])==1
passed('original_exact_positive_gap',snapshot=small,independent_gap='1/2^55')

again=original(EARLY/'declared-bound-idempotence-red-02.json')
ledger=EvidenceLedger(again['input']);before=json.dumps(ledger.snapshot(0),sort_keys=True)
assert ledger.ingest(again['ingested_record'])=='ALREADY_PRESENT'
assert json.dumps(ledger.snapshot(0),sort_keys=True)==before
dup=deepcopy(again['input']);dup['records'].append(again['ingested_record'])
assert json.dumps(EvidenceLedger(dup).snapshot(0),sort_keys=True)==before
passed('original_equal_ingest_and_initial_duplicates_keep_first_encoding')

age=original(MIDDLE/'root-age-original-probe-01.json')
age_views=[EvidenceLedger(doc).snapshot(age['as_of_s']) for doc in age['inputs']]
assert age_views[0]==age_views[1]
assert age_views[0]['records'][0]['age_s']==age['as_of_s']==2**53+1
assert type(age_views[0]['records'][0]['age_s']) is int
passed('original_equal_time_encodings_keep_exact_large_age',snapshots=age_views)

domain=original(DOMAIN/'root-domain-original-probe-01.json')
domain_views=[]
for doc in domain['inputs']:
    untouched=deepcopy(doc)
    cut=max(row['arrived_at_s'] for row in doc['records'])
    view=EvidenceLedger(doc).snapshot(cut)
    assert doc==untouched
    assert view['records'][0]['value']==doc['records'][0]['value']
    assert type(view['records'][0]['value']) is type(doc['records'][0]['value'])
    assert view['records'][0]['quality']['error_bound']==doc['records'][0]['quality']['error_bound']
    assert type(view['records'][0]['quality']['error_bound']) is type(doc['records'][0]['quality']['error_bound'])
    json.dumps(view,allow_nan=False)
    domain_views.append(view)
assert domain_views[0]==domain_views[1]
passed('original_equal_endpoint_domain_inputs_both_accepted_without_widening',snapshots=domain_views)

# Reuse the independently specified touching/overlap/negative/subnormal/future
# cases from the immutable718 probe, not a recoded endpoint comparator.
edges=json.loads((MIDDLE/'interval-closure-and-age-red-01.json').read_text(encoding='utf-8'))['independent_boundary_checks']
for name,row in edges.items():
    view=EvidenceLedger(row['input']).snapshot(row['as_of_s'])
    assert view==row['snapshot'],name
    passed('interval_boundary_'+name,snapshot=view)

template=age['inputs'][0]
def time_doc(observed,arrived=None,until=None):
    doc=deepcopy(template)
    doc['records'][0].update(observed_at_s=observed,arrived_at_s=observed if arrived is None else arrived,valid_until_s=until)
    return doc

fraction_views=[EvidenceLedger(time_doc(observed)).snapshot(.25) for observed in (-3,-3.)]
assert fraction_views[0]==fraction_views[1]
assert fraction_views[0]['records'][0]['age_s']==3.25
assert type(fraction_views[0]['records'][0]['age_s']) is float
passed('fractional_age_equal_timestamp_encodings',snapshots=fraction_views)
binary=EvidenceLedger(time_doc(.1)).snapshot(.3)['records'][0]['age_s']
assert binary.hex()=='0x1.9999999999999p-3'
passed('decoded_binary_fraction_age_rounds_once',age_s=binary,hex=binary.hex(),expected_hex='0x1.9999999999999p-3')

overflow=[]
for observed in (-(2**1023),float(-(2**1023))):
    ledger=EvidenceLedger(time_doc(observed,arrived=0))
    try:ledger.snapshot(2**1023)
    except ValueError as error:overflow.append(str(error))
    else:raise AssertionError('Unsupported derived age accepted')
    assert ledger.snapshot(0)['records'][0]['age_s']==2**1023
passed('age_output_domain_refusal_is_consistent_and_read_only',errors=overflow)

d=time_doc(9,arrived=10,until=12);ledger=EvidenceLedger(d)
assert ledger.snapshot(math.nextafter(10,-math.inf))['records']==[]
assert ledger.snapshot(10)['current_record_ids']==[d['records'][0]['id']]
assert ledger.snapshot(math.nextafter(12,-math.inf))['current_record_ids']==[d['records'][0]['id']]
assert ledger.snapshot(12)['records'][0]['availability']=='expired'
late=EvidenceLedger(time_doc(-50,arrived=4,until=-1)).snapshot(4)
assert late['records'][0]['age_s']==54 and late['current_record_ids']==[]
passed('strict_time_selection_expiry_and_late_age_preserved')

maximum=int(sys.float_info.max);half=2**970
for name,value,expected in [('positive_above_overflow_midpoint',maximum+1,'REFUSED'),
                            ('negative_below_overflow_midpoint',-maximum-1,'REFUSED'),
                            ('negative_finite_side_of_overflow_midpoint',-maximum+1,'ACCEPTED'),
                            ('largest_finite_zero_bound',maximum,'ACCEPTED')]:
    outcomes=[]
    for error in ((0,0.) if name=='largest_finite_zero_bound' else (half,float(half))):
        doc=deepcopy(domain['inputs'][0]);doc['records'][0]['value']=value
        doc['records'][0]['quality']['error_bound']=error
        try:result=EvidenceLedger(doc).snapshot(max(row['arrived_at_s'] for row in doc['records']))
        except ValueError:outcomes.append('REFUSED')
        else:
            outcomes.append('ACCEPTED')
            assert result['records'][0]['value']==value
            assert result['records'][0]['quality']['error_bound']==error
    assert outcomes==[expected,expected],(name,outcomes)
    passed('endpoint_domain_'+name,outcomes=outcomes,expected=expected)

missing=time_doc(0);missing['records'][0].update(value=None,quality=dict(status='unknown',error_bound=None,note='Missing remains unknown.'))
s=EvidenceLedger(missing).snapshot(0)
assert s['current_record_ids']==[] and s['records'][0]['availability']=='missing'
assert s['records'][0]['quality']['error_bound'] is None and s['independence']=='NOT_ESTABLISHED'
passed('missing_unknown_quality_not_promoted',snapshot=s)

executed=[]
class ForbiddenFloat(float):
    def as_integer_ratio(self):executed.append('ratio hook');return 1,1
    def __deepcopy__(self,memo):executed.append('copy hook');return 1.
bad=time_doc(0);bad['records'][0]['value']=ForbiddenFloat(1.)
try:EvidenceLedger(bad)
except ValueError:pass
else:raise AssertionError('Custom numeric object accepted')
try:EvidenceLedger(time_doc(0)).snapshot(ForbiddenFloat(1.))
except ValueError:pass
else:raise AssertionError('Custom numeric time accepted')
assert executed==[]
passed('new_rational_paths_do_not_execute_custom_numeric_hooks')

guard=json.loads((HERE/'source-guard-before.json').read_text(encoding='utf-8'))
executed_after={name:hashlib.sha256((FROZEN/name).read_bytes()).hexdigest() for name in guard['files']}
assert executed_after==guard['files']
writer=Path(r'C:/Users/Donson/Documents/ChatGPT/Renly/.work/worktrees/full-site-14')
live_after={name:hashlib.sha256((writer/name).read_bytes()).hexdigest() for name in guard['files']}
assert live_after==guard['files']
record=dict(pin=guard['pin'],status='THREE_SPEC_FINDINGS_CLOSED_NO_NEW_FINDINGS',
            closed_findings=['disjoint_bound_precision_and_equal_ingest','equal_numeric_timestamp_age','equal_endpoint_domain_admission'],
            open_findings=0,new_findings=0,root_visual_finding_in_scope=False,
            independent_checks=len(checks),checks=checks,actual_executed_source_guard='PASS',live_core_source_guard='PASS',
            source_files=len(guard['files']),source_after=live_after,
            author_targets_repeated=0,old_capture_packages_repeated=0,physics_runs=0,full_suite_runs=0,model_calls=0,training_calls=0,
            formal_capture_or_full_ticket_acceptance_claimed=False)
with (HERE/'combined-closure-probe-01.json').open('x',encoding='utf-8',newline='\n') as stream:stream.write(json.dumps(record,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
print(json.dumps(dict(status=record['status'],independent_checks=len(checks),closed_findings=3,open_findings=0,new_findings=0,source_files=25,execution_and_live_source_guard='PASS',physics_runs=0,full_suite_runs=0)))
