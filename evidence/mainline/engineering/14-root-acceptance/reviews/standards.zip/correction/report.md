# Ticket 14 — correction Standards review

固定源码：`28e8756d1014646952efb3661d323a68b68bd3ef`；修正比较起点 a9。**新增硬规范发现 0；Fowler 判断性发现 0。** 原 a9 源码报告保留。

按 `AGENTS.md` 的源码身份、耐久原件和阶段边界，以及 `14-evidence-contract.md` 检查：区间比较使用解码后有限 int／binary64 的 `Fraction` 精确值，不重新解释十进制文本、不扩大误差界。等值 ID 保留 first accepted 编码，`ALREADY_PRESENT` 不更换状态。age 精确作差，整数结果保留 int，非整数只转换一次 binary64，越出有限输出域拒绝；选择／过期判断不使用舍入后的 age。Fraction 仅用于内部计算，未进入 public JSON。

- 仅执行新增精度／age 的 5 个公共目标，全部通过、零跳过；未重旧 12、legacy 2 或整套／物理。
- 13 件被读源码／合同／工具／日志与固定 Git 字节一致，测试及收尾前后 SHA 守卫通过。完整 a9→28 格式检查退出 0、输出 0 B。
- 原 capture01 的 26 件耐久产物＋收据，逐字匹配 `442983e6` 原交付；原 371／369 全检仍只属于 `3c4e9640`。四份新 red／green 日志及精确叶 CRLF 分类保留，没有回写原结果。
- correction writer／verifier 的冻结与历史 Git 核对逻辑已源码检查：旧来源在原提交核验，新源另列，不把旧全检追认为新全检；实际 capture02／fresh 产物仍另审。Root 图像 finding 与版本 2 视觉接受属另一范围。

早期 718 目标预检曾在执行前正确发现正在授权修改的 ledger／tests，已留存为 **0 执行的 preflight refusal**，不算测试失败或 718 通过。此报告仅限稳定 28 的修正源码与原件保留，不构成整票／M3 接受。

证据：`aegisdc-review-14-correction-standards-attachments/` 中的前后字节收据、5 目标日志、原件核对、preflight refusal 和空格式日志。
