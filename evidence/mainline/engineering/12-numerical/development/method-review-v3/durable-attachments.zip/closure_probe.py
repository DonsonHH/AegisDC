"""Independent frozen-reader closure; no plant import, physics or full suite."""
from copy import deepcopy
import hashlib
import io
import json
import math
from pathlib import Path
import sys
import unittest

HERE = Path(__file__).resolve().parent
SNAPSHOT = HERE / 'frozen-snapshot'
OLD = Path(r'C:/Users/Donson/AppData/Local/Temp/aegisdc-review-12-method-spec-attachments')
WRITER = Path(r'C:/Users/Donson/Documents/ChatGPT/Renly/.work/worktrees/full-site-12')
sys.path[:0] = [str(SNAPSHOT / 'scripts'), str(SNAPSHOT / 'tests')]
import numerical_refinement_checks as v2
import numerical_alignment_v3 as v3
import test_numerical_alignment as old_targets
import test_numerical_alignment_amplitudes as new_targets

LIMITS = dict(temperature_K=.05, pressure_Pa=1000, heat_W=25000,
              service_deficit_time_s=.001, unserved_service_unit_s=.001,
              resource_time_s=.001, switch_time_s=.001)
U = math.ulp(1.)
results = {}


def frozen_json(name, expected):
    raw = (OLD / name).read_bytes()
    assert hashlib.sha256(raw).hexdigest() == expected
    target = HERE / 'original-probe-copies' / name
    target.parent.mkdir(exist_ok=True)
    target.write_bytes(raw)
    return json.loads(raw)


def input_bytes(a, b):
    return json.dumps([a, b], sort_keys=True, allow_nan=False)


def check(name, a, b, *, lower_bound=None, expected_pass=None, previous=None, factor=1):
    before = input_bytes(a, b)
    baseline = v2.epoch_compare(a, b, LIMITS, factor=factor)
    if previous is not None:
        assert baseline == previous, (name, 'Original v2 result did not reproduce')
    current = v3.epoch_compare(a, b, LIMITS, factor=factor)
    assert input_bytes(a, b) == before, (name, 'Reader mutated inputs')
    assert all(current['maximum_absolute_series_error'][key] >= value
               for key, value in baseline['maximum_absolute_series_error'].items()), name
    assert current['amplitude_guard']['previous_epoch_error_lower_bound'] == baseline['maximum_absolute_series_error'], name
    for key in baseline:
        if key not in ('comparison_method', 'maximum_absolute_series_error', 'within_predeclared_limits'):
            assert current[key] == baseline[key], (name, 'Changed inherited gate or provenance', key)
    if not baseline['within_predeclared_limits']:
        assert not current['within_predeclared_limits'], name
    if lower_bound is not None:
        key = next(iter(a['series']))
        assert current['maximum_absolute_series_error'][key] >= lower_bound, (name, lower_bound, current)
    if expected_pass is not None:
        assert current['within_predeclared_limits'] is expected_pass, (name, current)
    expected_coverage = {(label, t, row['actual_time_s'] if label == 'actual' else row['reference_time_s'])
                         for row in current['alignment']['windows']
                         for t in row['excluded_union_times_s'] for label in ('actual', 'reference')}
    actual_coverage = {(row['trajectory'], row['time_s'], row['own_event_time_s'])
                       for row in current['amplitude_guard']['closed_interval_checks']}
    assert actual_coverage == expected_coverage, (name, 'Closed-interval coverage differs')
    results[name] = dict(status='PASS', factor=factor,
                        independently_expected_lower_bound=lower_bound, expected_gate=expected_pass,
                        actual=a, reference=b, baseline_v2=baseline, corrected_v3=current)


first = frozen_json('independent-reader-probe-01.json', '00f25c08278ac23cb822954cef19c4645550a255d1b3fb04b5a701352459d493')
continuous = frozen_json('continuous-excursion-probe-01.json', '20c4741ad2346b4528a5764a0d4b3a576590ada3e908feae89f21b5e67b3fc2e')
closed = frozen_json('closed-endpoint-and-pressure-probes-01.json', '1ef4ea4fd1f35dc73d7410e136bb0f4e450dbe5835fdcbac219610f2db3f4ba4')
row = first['interior_excursion_diagnostic']
check('original_1_open_heat_peak', row['actual'], row['reference'], lower_bound=3e6, expected_pass=False, previous=row['comparison'])
check('original_2_continuous_K_peak', continuous['actual'], continuous['reference'], lower_bound=.1, expected_pass=False, previous=continuous['comparison'])
for name, minimum in [('pressure_open_interval_peak', 2000.), ('heat_cross_endpoint_holds_outside_window', 3e6), ('temperature_cross_endpoint_persists_outside_window', .1)]:
    row = closed['probes'][name]
    check('original_' + name, row['actual'], row['reference'], lower_bound=minimum, expected_pass=False, previous=row['comparison'])


def trace(times, values, key='condenser_W', event_time=1., identity=None, metric=None):
    return dict(times=times, series={key: values},
                events=[] if event_time is None else [dict(identity=identity or ['reserve_transition', 'ups', 'supplying'], time_s=event_time)],
                metrics=metric or {'service_deficit_time_s': 0.}, literal_checks_pass=True)


# Ordinary repeated post-event rows have the same declared amplitude, so an
# extra integration row alone is not a reason to manufacture an error.
a = trace([0., 1., 1.+4*U, 1.+8*U, 3.], [0., 2e6, 2e6, 2e6, 2e6])
b = trace([0., 1.+8*U, 3.], [0., 2e6, 2e6], event_time=1.+8*U)
check('constant_repeat_rows_are_valid', a, b, expected_pass=True)
assert results['constant_repeat_rows_are_valid']['corrected_v3']['maximum_absolute_series_error']['condenser_W'] == 0.
check('constant_repeat_rows_reversed', b, a, expected_pass=True)

# Independent range arguments: the unperturbed opposite heat trace has only
# 0/2 MW values. An excursion to +5 or -3 MW differs from EVERY such value by
# at least 3 MW, regardless of any permitted time pairing. The constant K/Pa
# opposites similarly force .1 K / 2000 Pa amplitude error.
for key, start, post, peak, minimum in [('condenser_W', 0., 2e6, 5e6, 3e6),
                                     ('condenser_W_negative', 0., 2e6, -3e6, 3e6),
                                     ('room_K', 300., 300., 300.1, .1),
                                     ('pressure_Pa', 1e6, 1e6, 1002000., 2000.)]:
    actual_key = 'condenser_W' if key.endswith('_negative') else key
    for placement in ('interior', 'high_endpoint'):
        times = [0., 1., 1.+4*U, 1.+8*U, 3.] if placement == 'interior' else [0., 1., 1.+8*U, 3.]
        values = [start, post, peak, post, post] if placement == 'interior' else [start, post, peak, post]
        perturbed = trace(times, values, actual_key)
        reference = trace([0., 1.+8*U, 3.], [start, post, post], actual_key, 1.+8*U)
        check(key + '_' + placement, perturbed, reference, lower_bound=minimum, expected_pass=False)
        check(key + '_' + placement + '_roles_reversed', reference, perturbed, lower_bound=minimum, expected_pass=False)

# The candidate and quarter-limit reference test retain different bounds.
candidate = trace([0., 1., 3.], [7000., 7000., 7000.], event_time=None)
reference = trace([0., 1., 3.], [0., 0., 0.], event_time=None)
check('7kW_candidate_under_25kW', candidate, reference, lower_bound=7000., expected_pass=True)
check('7kW_reference_over_6250W', candidate, reference, lower_bound=7000., expected_pass=False, factor=.25)

# Gate dimensions remain independent: zero value error cannot excuse a real
# late event or a changed exogenous value/identity.
check('real_two_ms_time_error_rejected',
      trace([0.,1.,3.], [0.,0.,0.]), trace([0.,1.002,3.], [0.,0.,0.], event_time=1.002), expected_pass=False)
check('changed_exogenous_value_identity_rejected',
      trace([0.,1.,3.], [0.,0.,0.], identity=['exogenous_boundary_input','grid_capacity',0]),
      trace([0.,1.,3.], [0.,0.,0.], identity=['exogenous_boundary_input','grid_capacity',1]), expected_pass=False)
check('resource_error_rejected_with_equal_series',
      trace([0.,1.,3.], [0.,0.,0.], metric={'worker_work_person_s':1.}),
      trace([0.,1.,3.], [0.,0.,0.], metric={'worker_work_person_s':1.002}), expected_pass=False)

# Run the original seven exact author tests through the NEW entry point in this
# isolated process; no test file or frozen original is edited.
old_targets.epoch_compare = v3.epoch_compare
suite = unittest.TestSuite([unittest.defaultTestLoader.loadTestsFromModule(old_targets),
                           unittest.defaultTestLoader.loadTestsFromModule(new_targets)])
log = io.StringIO()
test_result = unittest.TextTestRunner(stream=log, verbosity=2).run(suite)
assert test_result.wasSuccessful() and test_result.testsRun == 16 and not test_result.skipped
(HERE / 'target-tests.log').write_text(log.getvalue(), encoding='utf-8', newline='\n')

guard = json.loads((HERE / 'source-guard-before.json').read_text(encoding='utf-8'))
after = {name: hashlib.sha256((WRITER / name).read_bytes()).hexdigest() for name in guard['files']}
assert all(after[name] == row['sha256'] for name, row in guard['files'].items())
record = dict(scope='FINITE_FROZEN_READER_SPEC_FINDING_CLOSURE_ONLY',
              method_pin=guard['method_pin'], algorithm_commit=guard['algorithm_commit'],
              caller_capture_commit=guard['caller_capture_commit'],
              original_finding='8588_non_event_amplitude_and_high_endpoint_loss', finding_status='CLOSED', new_findings=0,
              original_counterexamples_replayed_verbatim=5, independent_cases=len(results), results=results,
              author_target_tests=dict(run=test_result.testsRun, failures=len(test_result.failures), errors=len(test_result.errors), skipped=len(test_result.skipped),
                                       original_seven_redirect='In-memory binding to numerical_alignment_v3.epoch_compare; frozen test bytes unchanged'),
              limits=LIMITS, source_guard='PASS', guarded_source_files=len(after), actual_source_after=after,
              actual_inputs_mutated=False, physics_runs=0, full_suite_runs=0, research_trials=0,
              numerical_qualification_accepted=False, python=dict(executable=sys.executable,version=sys.version))
with (HERE / 'closure-probe-01.json').open('x',encoding='utf-8',newline='\n') as stream:
    stream.write(json.dumps(record,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
print(json.dumps(dict(original_finding='CLOSED',new_findings=0,original_counterexamples=5,independent_cases=len(results),author_targets=16,source_guard='PASS',physics_runs=0,full_suite_runs=0)))
