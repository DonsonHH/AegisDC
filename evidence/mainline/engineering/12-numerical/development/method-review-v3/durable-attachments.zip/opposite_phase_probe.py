"""Requested metric-boundary clarification, frozen readers only."""
import hashlib
import json
import math
from pathlib import Path
import sys

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'frozen-snapshot/scripts'))
from numerical_alignment_v3 import epoch_compare

u=math.ulp(1.)
ta,tb,mid=1.,1.+8*u,1.+4*u
times=[0.,ta,mid,tb,3.]
identity=['reserve_transition','ups','supplying']
actual=dict(times=times,series={'room_K':[301.,301.,301.04,301.,301.]},
            events=[dict(identity=identity,time_s=ta)],metrics={'service_deficit_time_s':0.},literal_checks_pass=True)
reference=dict(times=times,series={'room_K':[301.,301.,300.96,301.,301.]},
               events=[dict(identity=identity,time_s=tb)],metrics={'service_deficit_time_s':0.},literal_checks_pass=True)
limits=dict(temperature_K=.05,pressure_Pa=1000,heat_W=25000,
            service_deficit_time_s=.001,unserved_service_unit_s=.001,resource_time_s=.001,switch_time_s=.001)
result=epoch_compare(actual,reference,limits)
assert abs(result['maximum_absolute_series_error']['room_K']-.04)<1e-12
assert abs(result['raw_causal']['maximum_absolute_series_error']['room_K']-.08)<1e-12
assert result['within_predeclared_limits'] and not result['raw_causal']['within_predeclared_limits']
assert ta<mid<tb
guard=json.loads((HERE/'source-guard-before.json').read_text(encoding='utf-8'))
writer=Path(r'C:/Users/Donson/Documents/ChatGPT/Renly/.work/worktrees/full-site-12')
assert all(hashlib.sha256((writer/name).read_bytes()).hexdigest()==row['sha256'] for name,row in guard['files'].items())
record=dict(scope='METRIC_SEMANTICS_CLARIFICATION_NOT_PHYSICS_OR_NEW_FINDING',
            method_pin=guard['method_pin'],actual=actual,reference=reference,limits=limits,comparison=result,
            judgment='No new finding under the explicitly declared event-side anchor diagnostic. It is not a pointwise raw envelope.',
            reason='At mid, actual is AFTER its own event while reference is BEFORE its own event. The declared diagnostic compares each against the opposite matching phase limit (301 K), so both .04 K excursions are retained. Raw simultaneous .08 K is reported separately and fails its raw check. Event-order-consistent anchor pairing can cover the pre-reference leg at actual left anchor, then actual post leg at reference right anchor; it is not a claim of a computed general retiming metric.',
            reporting_requirement='Call the bound an event-side-anchor error, retain raw and actual timing separately, and do not state that all same-clock or unsaved continuous errors are below .05 K.',
            source_guard='PASS',guarded_source_files=len(guard['files']),physics_runs=0,full_suite_runs=0,research_trials=0)
with (HERE/'opposite-phase-raw-gap-01.json').open('x',encoding='utf-8',newline='\n') as stream:
    stream.write(json.dumps(record,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
print(json.dumps(dict(epoch_K=result['maximum_absolute_series_error']['room_K'],raw_K=result['raw_causal']['maximum_absolute_series_error']['room_K'],new_finding=False,source_guard='PASS')))
