"""Preserve reviewed evidence-closure acceptance, including both formal captures."""
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import zipfile
ROOT=Path(__file__).resolve().parents[1];WORK=ROOT/'.work'
SOURCE='2b8d224a6d6605b2898117438573d738dae28023'
PACKET=Path('evidence/mainline/engineering/24-root-acceptance')
RAW=ROOT/'runs/mainline-M4-24-root-acceptance-20261105-01'
def read(p):return json.loads(p.read_bytes())
def sha(p):return sha256(p.read_bytes()).hexdigest()
def git(*a):return subprocess.check_output(['git',*a],cwd=ROOT)
def write(p,value,new=True):
    p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('x' if new else 'w',encoding='utf-8',newline='\n') as f:f.write(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
def main():
    assert git('rev-parse','HEAD').decode().strip()==SOURCE and not git('status','--porcelain')
    summary=read(RAW/'summary.json');guard=read(RAW/'source-guard.json');tests=summary['tests']
    assert summary['overall']=='PASS' and tests['run']==tests['executed']>501
    assert tests['failures']==tests['errors']==tests['skipped']==0 and summary['verified_original_files']==20
    assert guard['source_commit_before']==SOURCE and guard['sources_unchanged'] and guard['head_unchanged']
    spec=read(WORK/'24-spec-saved-final-02/correction-saved-01/review.json');std=read(WORK/'24-standards-saved-final-02/review.json')
    assert spec['status']==std['status']=='PASS' and spec['unresolved_findings']==std['unresolved_findings']==0
    assert spec['checks_passed']==1267 and std['checks_passed']==453
    assert read(WORK/'24-visual-qa-02/visual-review.json')['open_findings']==0
    packet=ROOT/PACKET;assert not packet.exists()
    copies={'raw/'+n:RAW/n for n in ('summary.json','tests.log','evidence.json','source-guard.json')};visuals={}
    for stem in ('closure-lifecycle','closure-boundary'):
        png=WORK/'24-visual-qa-02'/(stem+'.png');svg=png.with_suffix('.svg')
        source='evidence/mainline/engineering/24-closure/capture-02/'+svg.name;assert sha(svg)==sha(ROOT/source)
        name='figures/'+png.name;copies[name]=png;visuals[name]=dict(svg=source,svg_sha256=sha(svg),png_sha256=sha(png))
    reviews={}
    for folder in ('24-spec-final-01','24-standards-final-01','24-spec-saved-final-02','24-standards-saved-final-02'):
        for p in (WORK/folder).rglob('*'):
            if p.is_file() and '__pycache__' not in p.parts and p.suffix not in {'.pyc','.pyo'}:
                reviews[folder+'/'+p.relative_to(WORK/folder).as_posix()]=p
    support={n:WORK/n for n in ('run_24_root_acceptance.py','build_24_root_packet.py','24-author-fresh-proof-01.log',
        '24-correction-fresh-proof-01.log','24-standards-metadata-final-01.json','24-status-preservation-01.json')}
    for n in ('01','02'):support['visual-review-'+n+'.json']=WORK/('24-visual-qa-'+n)/'visual-review.json'
    declared=sorted(set(copies)|{'.gitattributes','README.md','declaration.json','source-manifest.json','archive-members.json','reviews.zip','support.zip','verify_packet.py'})
    write(packet/'declaration.json',dict(artifacts=declared,terminal_receipt='receipt.json'))
    for n,p in copies.items():q=packet/n;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(p.read_bytes())
    attrs=['# Preserve exact native originals; retain all other whitespace checks.']
    for n,p in copies.items():
        if n.startswith('raw/') and b'\r\n' in p.read_bytes():attrs.append(n+' -text whitespace=blank-at-eol,blank-at-eof,space-before-tab,cr-at-eol')
    (packet/'.gitattributes').write_text('\n'.join(attrs)+'\n',encoding='utf-8',newline='\n')
    archives={}
    for name,members in (('reviews.zip',reviews),('support.zip',support)):
        archives[name]={}
        with zipfile.ZipFile(packet/name,'x',zipfile.ZIP_DEFLATED) as z:
            for n,p in sorted(members.items()):
                raw=p.read_bytes();z.writestr(n,raw);archives[name][n]=dict(sha256=sha256(raw).hexdigest(),bytes=len(raw))
    write(packet/'archive-members.json',archives)
    capture='evidence/mainline/engineering/24-closure/capture-02/receipt.json'
    author=dict(execution='78922bcb3cc290c924987c495118775827dd1c3b',data_delivery='cf90d9f5459eeea10cf9c4b767a6dfc6077bdcf1',
        candidate='5d95456f4f761f3aafe92746477d016e654ba140',capture=capture,capture_sha256=sha(ROOT/capture))
    previous=dict(execution='6ff98fb1644463b24f76eb28864ab374cf0f06cc',data_delivery='52ef152eb8e1e517e2a46e12f029ad464d618f0e',
        capture='evidence/mainline/engineering/24-closure/capture-01/receipt.json',assessment_calls=15,
        original_independent_saved_checks=1044,original_acceptance_gap='SPEC24-FINAL-01 trace incompleteness; corrected separately, never overwritten')
    write(packet/'source-manifest.json',dict(tested_source=SOURCE,author=author,previous_author=previous,visuals=visuals,
        reviews=dict(standards_findings=0,spec_findings=0,independent_assertions=1267,standards_saved_checks=453,
            spec_report_sha256=sha(WORK/'24-spec-saved-final-02/correction-saved-01/SPEC.md'),standards_report_sha256=sha(WORK/'24-standards-saved-final-02/report.md')),
        independent_history=dict(initial_invalid_fixture_rejections=12,corrected_protocol_calls=9,corrected_cases_passed=5,corrected_counterexamples=4,
            invalid_original_files=133,corrected_original_files=36),formal_assessment_calls=30,new_physical_runs=0,registered_research_trials=0))
    (packet/'verify_packet.py').write_bytes((WORK/'24-verify_packet.py').read_bytes())
    text=f'''# 第24项根验收：基于证据的恢复核验和问题关闭

集成执行源`{SOURCE}`通过{tests['executed']}项完整回归，全部执行，零失败、零错误、零跳过。20份历史原件与{len(guard['actual_sources'])}个Python/JSON源码身份通过守卫。独立Spec1267项、Standards453项保存复核通过，两轴无未解决发现。

![关闭状态与有限证据](figures/closure-lifecycle.png)

处置完成本身不会关闭问题；有限采样规则要求处置后状态和服务记录、真实样本及时间跨度。当前跨来源反证、复制、未来、未知质量和冲突复核不能补成恢复。有时限授权的风险接受、升级、误报复核与恢复核验分别表示。实际第23项5.25秒采样、5.75秒到达的手持读数保持原身份，单次局部观察且没有服务记录时继续开放。

![公开证据边界与核验](figures/closure-boundary.png)

原15次证据评估通过原冻结状态检查，但独立最终审查发现否决轨迹遗漏。原6ff执行、52ef交付、1044项审阅及P2保持原样；显式修订协议下新15次评估补齐失败检查、阻断记录、观察/到达/有效期与来源。累计30次正式证据评估、零物理重跑。原12次独立无效夹具拒绝及修订9次中的4个反例也完整保留，未把它们记成全通过。

修订包20产物加收据、60运行源/4工具/152输入在干净新检出中逐项核对，包含原包全部21文件及原协议。两版图均实际渲染查看，未声称浏览器验收。41份原生CRLF开发日志只添加逐路径格式分类，字节未改。

- [根摘要](raw/summary.json)、[完整日志](raw/tests.log)、[源码守卫](raw/source-guard.json)
- [全部独立审阅与原反例](reviews.zip)、[新检出和图像复核](support.zip)
- [候选原件与两版捕获](../24-closure/README.md)、[显式修订](../../../../docs/mainline/24-closure-correction-01.md)
- [权威](../../../../docs/mainline/evidence/24-root.json)、[清单](declaration.json)、[收据](receipt.json)

本封存提交的新检出运行verify_packet.py --delivery-commit COMMIT --output OUTSIDE_CHECKOUT.json只复核保存证据。第24项接受后当前主票25，M4还需透明策略、候选方法和完整闭环负例。注册效果试验、LLM及训练调用均为零；现场校准和策略/AI/RSI收益仍待独立研究，完整42票目标持续active。
'''
    (packet/'README.md').write_text(text,encoding='utf-8',newline='\n')
    assert {p.relative_to(packet).as_posix() for p in packet.rglob('*') if p.is_file()}==set(declared)
    write(packet/'receipt.json',dict(schema='aegisdc-ticket24-root-packet-v1',tested_source=SOURCE,delivery_gate='PENDING_COMMIT_AND_FRESH_CHECKOUT',
        artifacts={n:sha(packet/n) for n in declared},root_tests=tests,independent_assertions=1267,standards_checks=453,historical_originals=20,
        new_full_regressions=0,new_physical_runs=0,registered_research_trials=0,llm_calls=0,training_calls=0))
    write(ROOT/'docs/mainline/evidence/24-root.json',dict(schema='aegisdc-ticket-root-acceptance-v1',ticket='24',status='ACCEPTED',actual_root_source=SOURCE,
        root_tests=tests,packet=PACKET.as_posix(),packet_receipt_sha256=sha(packet/'receipt.json'),author=author,previous_author=previous,
        independent_assertions=1267,standards_checks=453,standards_findings=0,spec_findings=0,field_calibration='PENDING',registered_research_trials=0,
        llm_calls=0,training_calls=0,overall_goal='ACTIVE'))
    p=ROOT/'.scratch/full-facility-mainline/issues/24-verified-closure.md';s=p.read_text(encoding='utf-8');assert '**Status:** claimed' in s
    s=s.replace('**Status:** claimed','**Status:** resolved',1).replace('- [ ]','- [x]')
    s+='\nRoot acceptance: `docs/mainline/evidence/24-root.json`; source `'+SOURCE+'`, '+str(tests['executed'])+' executed checks/zero skips, Spec1267 and Standards453 saved checks. Both formal captures and all original review failures preserved.\n';p.write_text(s,encoding='utf-8',newline='\n')
    p=ROOT/'docs/mainline/progress.json';v=read(p);assert v['current_ticket']=='24';v['current_ticket']='25'
    v['active_implementations']=[x for x in v['active_implementations'] if x['ticket']!='24']
    m=next(x for x in v['milestones'] if x['id']=='M4');m['acceptance_evidence'].append('docs/mainline/evidence/24-root.json')
    m['progress_scope']='21personnel,22inspection,23intervention and24evidence closure accepted;25-28transparent policies and full-loop M4 gates remain.'
    v['liveness_refresh']='Reviewed24 accepted after integrated checks. Primary25 ready, no assigned implementation yet.';write(p,v,False)
    p=ROOT/'docs/current-research.json';v=read(p);v.update(current_primary_ticket='25',current_primary_ticket_assigned=False,active_tickets=[],next_ready_unassigned=['25'],
        implementation='Tickets01–24 accepted. Primary25transparent baselines ready; M4 and entire research goal remain active.')
    v['runtime_verification_documents'].append((PACKET/'README.md').as_posix());write(p,v,False)
    for name in ('docs/MAINLINE.md','docs/NEXT.md'):
        p=ROOT/name;s=p.read_text(encoding='utf-8').replace('当前主票24','第24票已接受，当前主票25')
        s+='\n证据核验关闭24通过[根验收、状态图与边界架构](../evidence/mainline/engineering/24-root-acceptance/README.md)。当前25准备透明策略对照，M4及整体研究目标仍active。\n';p.write_text(s,encoding='utf-8',newline='\n')
    print(json.dumps(dict(packet=PACKET.as_posix(),artifacts=len(declared),archive_members=sum(map(len,archives.values())),tests=tests,guarded_files=len(guard['actual_sources'])),ensure_ascii=False))
if __name__=='__main__':main()
