# Standards — ticket24 original core

Scope: immutable diff 61257dd8766c0173e1c10c42c9cb53d973626fe3...e99073f271fb2531cdaec37bf29eb552d5864962; static committed bytes only. No tests, probes, physics, inference, capture or regression executed. Root owns acceptance. Later fixes require separate supplements.

## Documented-standard findings

**P2 — Disputed categorical reports can close a question** (src/aegis_dc/verified_closure.py:80–86). The hunk accepts reported, current, original records but never checks evidence.conflicts or provenance_issues. A current authorized ACCEPT_RISK at time4 plus a same-channel/time KEEP_OPEN original creates a declared ledger conflict; KEEP_OPEN is skipped while ACCEPT_RISK still closes the question. A copy-origin dispute can likewise leave its participating original usable. This conflicts with “Current validity and conflicting/missing evidence affect the current lifecycle state” (docs/mainline/24-closure-contract.md:5) and shared-provenance handling (AGENTS.md:11). Exclude disputed review records before disposition selection.

**P2 — A selected reading can ignore its declared conflicting counterpart** (verified_closure.py:118–124). The hunk filters to source_ids before requiring the entire conflict pair to belong to current_ids. Add another declared current flow source reporting .01 against selected verify-flow-5=.09 at time5: the public snapshot reports disjoint bounds, but closure can retain the selected positive. This violates the contract's “contradictory records cannot satisfy a restoration check” (:11). Inspect current conflicting evidence across the declared target/observable while counting positives only from permitted sources.

**P2 — Action reports have no declared task/operation authority binding** (verified_closure.py:100–114,154). “operation_id” is only nonempty text matching another caller string; invented operation/task IDs can accompany APPLIED and satisfy closure. The contract describes an “authorized action outcome” (:7), while the spec separates action permissions (spec.md:60). Bind reports to a validated public named-operation declaration; no plant query is needed. Root's later1eac correction is outside this original pin.

## Judgment-call smell

**Possible Duplicated Code:** identical VERIFICATION_RECORD_AVAILABLE dictionaries occur at162–164 and187–189. Generate unique supporting-record trace entries once after false-alarm support is finalized. This is a maintainability heuristic, not a hard standard violation.

Frozen formal delivery is absent from this pin. These findings neither resolve ticket24 nor determine scientific gain.
