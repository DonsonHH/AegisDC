"""Independent saved-byte audit only; never imports or calls AegisDC."""
from hashlib import sha256
from pathlib import Path
import json
import subprocess
from datetime import datetime,timezone

REPO=Path('C:/Users/Donson/.codex/worktrees/mainline23-intervention/Renly')
OUT=Path(__file__).resolve().parent
OLD=Path('C:/Users/Donson/Documents/ChatGPT/Renly/.work/24-spec-final-01')
SOURCE='6ff98fb1644463b24f76eb28864ab374cf0f06cc'
DELIVERY='52ef152eb8e1e517e2a46e12f029ad464d618f0e'
PACKAGE='evidence/mainline/engineering/24-closure'
CAPTURE=PACKAGE+'/capture-01'
PROTOCOL='docs/mainline/24-closure-engineering-protocol.json'
checks=[]
def require(ok,name):
    checks.append(dict(name=name,passed=bool(ok)))
    if not ok:raise ValueError(name)
def digest(raw):return sha256(raw).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=REPO)
def read(path):return json.loads(path.read_bytes())
def write(path,value):
    with path.open('x',encoding='utf-8',newline='\n') as stream:stream.write(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
def blobs(revision,paths):
    paths=sorted(set(paths));raw=subprocess.check_output(['git','cat-file','--batch'],cwd=REPO,
        input=''.join(revision+':'+p+'\n' for p in paths).encode())
    result={};offset=0
    for path in paths:
        end=raw.index(b'\n',offset);header=raw[offset:end].split()
        require(len(header)==3 and header[1]==b'blob','Git blob exists '+revision[:8]+' '+path)
        start=end+1;size=int(header[2]);result[path]=raw[start:start+size];offset=start+size+1
    require(offset==len(raw),'Git batch complete '+revision[:8]);return result
def main():
    protocol=read(REPO/PROTOCOL);receipt=read(REPO/CAPTURE/'receipt.json')
    require(receipt['execution_commit']==SOURCE and receipt['status']=='PASS' and receipt['source_head_and_bytes_unchanged'],'original capture source and success')
    require(receipt['assessment_attempts']==receipt['completed']==15 and receipt['expected_rejections']==2
        and receipt['failures']==receipt['physical_runs']==receipt['registered_research_trials']==0,'accounted calls and zero physical/research')
    require(protocol['declared_assessment_calls']==15 and protocol['physical_runs']==protocol['llm_calls']==protocol['training_calls']==0,'protocol call scope')
    expected={'verified':'VERIFIED_CLOSED','action-only':'ACTION_COMPLETED_PENDING_VERIFICATION',
        'condition-only':'SYMPTOM_RETREATED_PENDING_VERIFICATION','expired':'ACTION_COMPLETED_PENDING_VERIFICATION',
        'same-origin':'ACTION_COMPLETED_PENDING_VERIFICATION','cross-source-conflict':'ACTION_COMPLETED_PENDING_VERIFICATION',
        'risk-accepted':'RISK_ACCEPTED','risk-acceptance-expired':'SYMPTOM_RETREATED_PENDING_VERIFICATION','escalated':'ESCALATED',
        'false-alarm':'FALSE_ALARM_REVIEWED','false-alarm-adverse':'OPEN_UNCONFIRMED','fresh-after-expiry':'VERIFIED_CLOSED',
        'fabricated-operation':'REJECTED','expired-action-grant':'REJECTED','actual23-inspection-incomplete':'ACTION_COMPLETED_PENDING_VERIFICATION'}
    require({c['id']:c['expected']['status'] for c in protocol['cases']}==expected,'literal lifecycle table matches frozen protocol')
    declared=set(protocol['durable_root'])|{c['id']+'/'+n for c in protocol['cases'] for n in protocol['durable_case']}
    require(len(declared)==20 and set(receipt['artifacts'])==declared,'declared20 artifacts')
    actual={p.relative_to(REPO/CAPTURE).as_posix() for p in (REPO/CAPTURE).rglob('*') if p.is_file()}
    require(actual==declared|{'receipt.json'},'exact21 durable files without caches')
    delivered=blobs(DELIVERY,[CAPTURE+'/'+n for n in actual])
    for name in actual:
        raw=(REPO/CAPTURE/name).read_bytes();require(raw==delivered[CAPTURE+'/'+name],'committed original '+name)
        if name!='receipt.json':require(digest(raw)==receipt['artifacts'][name],'receipt digest '+name)
    pin_names={n for group in receipt['pinned'].values() for n in group}
    source_blobs=blobs(SOURCE,pin_names);delivery_blobs=blobs(DELIVERY,pin_names)
    for role,group in receipt['pinned'].items():
        for name,wanted in group.items():
            require(digest(source_blobs[name])==wanted==digest(delivery_blobs[name]),'execution/delivery '+role+' '+name)
    tree=git('ls-tree','-r','-z','--name-only',SOURCE,'src','configs',PACKAGE+'/development',PACKAGE+'/reference',
        'evidence/mainline/engineering/23-interventions/capture-01','evidence/mainline/engineering/23-interventions/reference').decode().strip('\0').split('\0')
    independent_membership=dict(runtime={n for n in tree if n.startswith('src/') and n.endswith('.py')},
        tools={'scripts/closure_delivery.py','scripts/inspection_delivery.py','scripts/prepare_closure_inputs.py'},
        inputs={PROTOCOL,'docs/mainline/24-closure-contract.md','tests/test_verified_closure.py',
            *[n for n in tree if n.startswith(PACKAGE+'/') or n.startswith('configs/full-facility') or n.startswith('evidence/mainline/engineering/23-interventions/')]})
    for role,paths in independent_membership.items():require(paths==set(receipt['pinned'][role]),'complete declared pin membership '+role)
    ledger=[json.loads(line) for line in (REPO/CAPTURE/'attempts.jsonl').read_text(encoding='utf-8').splitlines()]
    require(len(ledger)==30,'30 ordered ledger rows')
    cases={}
    for index,case in enumerate(protocol['cases']):
        pair=ledger[index*2:index*2+2]
        require([r['status'] for r in pair]==['STARTED','COMPLETED'] and all(r['case']==case['id'] and r['execution_commit']==SOURCE for r in pair),'single accounted case '+case['id'])
        inputs=json.loads(source_blobs[case['input']]);result=read(REPO/CAPTURE/case['id']/'result.json')
        require(result.get('status',result.get('questions',[{}])[0].get('status'))==expected[case['id']],'saved expected lifecycle '+case['id'])
        if expected[case['id']]=='REJECTED':
            require(result['error_type']=='ValueError' and case['expected']['error_contains'] in result['error'],'semantic rejection '+case['id']);cases[case['id']]=result;continue
        frame=inputs['frame'];question=result['questions'][0];visible={r['id']:r for r in frame['evidence']['records']}
        require(result['facility_id']==frame['facility_id'] and result['as_of_s']==frame['as_of_s'],'frame identity '+case['id'])
        require(question['question_closed']==(question['status'] in {'VERIFIED_CLOSED','RISK_ACCEPTED','FALSE_ALARM_REVIEWED'})
            and question['risk_closed']==(question['status']=='VERIFIED_CLOSED'),'separate closure semantics '+case['id'])
        require(not question['physical_restoration_claim'] and not result['execution_permission'] and result['physical_actions']==[],'no physical claim '+case['id'])
        require(len(result['unevaluated_question_ids'])==7 and question['scope']=='DECLARED_FINITE_SAMPLED_CRITERIA_ONLY','finite scope remains '+case['id'])
        for row in frame['evidence']['records']:
            require(row['observed_at_s']<=row['arrived_at_s']<=frame['as_of_s'],'only arrived input '+case['id']+'/'+row['id'])
        for record_id in question['supporting_record_ids']:
            row=visible[record_id];require(row['availability']=='current' and row['quality']['status']=='bounded','current bounded support '+case['id']+'/'+record_id)
        for event in question['trace']:
            require(event['observed_at_s']<=event['arrived_at_s']<=frame['as_of_s'],'available event trace '+case['id'])
            if 'record_id' in event:
                row=visible[event['record_id']];require(all(row[k]==event[k] for k in ('observed_at_s','arrived_at_s','valid_until_s','provenance')),'trace retained identity '+case['id']+'/'+row['id'])
        cases[case['id']]=dict(status=question['status'],supporting_ids=question['supporting_record_ids'],checks=question['checks'],trace=question['trace'])
    original23=read(REPO/'evidence/mainline/engineering/23-interventions/capture-01/filter-later-inspection/run.json')
    actualcase=read(REPO/PACKAGE/'reference/actual23-inspection-incomplete.json')
    row=actualcase['frame']['evidence']['records'][0];original=original23['inspection_public_snapshot']['records'][0]
    require(row==original,'actual23record copied exactly without new reading')
    require((row['observed_at_s'],row['arrived_at_s'])==(5.25,5.75),'actual23measurement times')
    require(actualcase['program']['intervention_feedback']==original23['intervention_public_feedback'],'actual23feedback original')
    q=cases['actual23-inspection-incomplete'];require(q['supporting_ids']==['post-clean-flow'] and q['checks'][0]['genuine_sample_count']==1
        and q['checks'][1]['genuine_sample_count']==0,'actual incomplete cannot close')
    originals={}
    for dirname in ('','correction-01'):
        folder=OLD/dirname;manifest=read(folder/'delivery-manifest.json');count=0
        for item in manifest['files']:
            raw=(folder/item['path']).read_bytes();require(digest(raw)==item['sha256'] and len(raw)==item['bytes'],'preserved prior '+dirname+'/'+item['path']);count+=1
        originals[dirname or 'invalid-fixture-original']=count
    # These are observations of already-produced output, not fresh assessments.
    bad=read(REPO/CAPTURE/'false-alarm-adverse/result.json')['questions'][0]
    finding=dict(id='SPEC24-FINAL-01',severity='P2',file='src/aegis_dc/verified_closure.py',line=224,
        requirement='.scratch/full-facility-mainline/issues/24-verified-closure.md:15 closure trace includes event times and evidence used',
        summary='Unsuccessful false-alarm verification discards the decisive evidence and checks',
        saved_case='false-alarm-adverse',saved_status=bad['status'],saved_trace_record_ids=[e.get('record_id') for e in bad['trace']],
        decisive_untraced_record='fixed-adverse-5',checks_omitted=bad['checks']==[],
        resolution='Retain review criterion evaluations and blocking evidence identities/times for unsuccessful review dispositions; preserve the original capture.')
    review=dict(schema='aegisdc-independent-ticket24-spec-saved-review-v2',status='CHANGES_REQUIRED',unresolved_findings=1,
        source=SOURCE,data_delivery=DELIVERY,checks_passed=len(checks),checks=checks,findings=[finding],
        pin_counts={k:len(v) for k,v in receipt['pinned'].items()},durable_artifacts=20,terminal_receipts=1,
        formal_assessments=15,new_assessments=0,new_tests=0,new_physics=0,new_inference=0,
        prior_files_preserved=originals,case_summaries=cases,reviewed_utc=datetime.now(timezone.utc).isoformat())
    write(OUT/'review.json',review)
    write(OUT/'source-pins.json',dict(source=SOURCE,data_delivery=DELIVERY,pinned=receipt['pinned']))
    report='''# Ticket24 final saved SPEC review

CHANGES_REQUIRED for execution6ff98fb1 and data52ef152e. One P2 remains: `verified_closure.py:224-226` computes false-alarm dossier/current checks but discards them when verification fails. The frozen `false-alarm-adverse` result is OPEN_UNCONFIRMED with empty checks/supporting IDs and a trace containing only review-disposition; decisive fixed-adverse-5 and its observation/arrival times are absent. Ticket24 requires the closed-loop trace to retain event times and evidence used. Retain unsuccessful review checks and blocking record identities/times; keep the original capture unchanged.

The independent saved-byte audit verifies all20durable artifacts plus receipt,30ordered ledger rows,15assessment outcomes including the two intended semantic rejections, and execution/delivery runtime/tool/input pins. Current action-only, insufficient, expiry, same-origin, cross-source, risk acceptance/escalation, false-alarm and renewed-window outcomes match the frozen table. The actual23handheld reading remains exactly the original5.25s observation/5.75s arrival; one sample and no service evidence cannot close the question. No private truth is consumed and no physical restoration or research gain is claimed.

The original12invalid-registry attempts and corrected9independent calls, including prior counterexamples, are preserved and hash-verified. This review ran zero assessments, probes, tests, physics or inference. Fresh checkout, rendered figures, integrated regression, acceptance and publication remain parent-owned gates. Overall research goal remains active.
'''
    (OUT/'SPEC.md').write_text(report,encoding='utf-8',newline='\n')
    manifest={p.name:dict(sha256=digest(p.read_bytes()),bytes=p.stat().st_size) for p in OUT.iterdir() if p.is_file()}
    write(OUT/'delivery-manifest.json',dict(files=manifest,source=SOURCE,data_delivery=DELIVERY))
    print(json.dumps(dict(status=review['status'],checks_passed=len(checks),pin_counts=review['pin_counts'],unresolved_findings=1,prior_files_preserved=originals,new_assessments=0)))
if __name__=='__main__':main()
