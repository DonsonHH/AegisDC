"""Independent saved-byte audit only; never imports or calls AegisDC."""
from hashlib import sha256
from pathlib import Path
import json
import subprocess
from datetime import datetime,timezone

REPO=Path('C:/Users/Donson/.codex/worktrees/mainline23-intervention/Renly')
OUT=Path(__file__).resolve().parent
OLD=Path('C:/Users/Donson/Documents/ChatGPT/Renly/.work/24-spec-final-01')
SOURCE='78922bcb3cc290c924987c495118775827dd1c3b'
DELIVERY='cf90d9f5459eeea10cf9c4b767a6dfc6077bdcf1'
PACKAGE='evidence/mainline/engineering/24-closure'
CAPTURE=PACKAGE+'/capture-02'
PROTOCOL='docs/mainline/24-closure-correction-01-protocol.json'
checks=[]
def require(ok,name):
    checks.append(dict(name=name,passed=bool(ok)))
    if not ok:raise ValueError(name)
def digest(raw):return sha256(raw).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=REPO)
def read(path):return json.loads(path.read_bytes())
def write(path,value):
    with path.open('x',encoding='utf-8',newline='\n') as stream:stream.write(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
def blobs(revision,paths):
    paths=sorted(set(paths));raw=subprocess.check_output(['git','cat-file','--batch'],cwd=REPO,
        input=''.join(revision+':'+p+'\n' for p in paths).encode())
    result={};offset=0
    for path in paths:
        end=raw.index(b'\n',offset);header=raw[offset:end].split()
        require(len(header)==3 and header[1]==b'blob','Git blob exists '+revision[:8]+' '+path)
        start=end+1;size=int(header[2]);result[path]=raw[start:start+size];offset=start+size+1
    require(offset==len(raw),'Git batch complete '+revision[:8]);return result
def main():
    protocol=read(REPO/PROTOCOL);receipt=read(REPO/CAPTURE/'receipt.json')
    require(receipt['execution_commit']==SOURCE and receipt['status']=='PASS' and receipt['source_head_and_bytes_unchanged'],'original capture source and success')
    require(receipt['assessment_attempts']==receipt['completed']==15 and receipt['expected_rejections']==2
        and receipt['failures']==receipt['physical_runs']==receipt['registered_research_trials']==0,'accounted calls and zero physical/research')
    require(protocol['declared_assessment_calls']==15 and protocol['physical_runs']==protocol['llm_calls']==protocol['training_calls']==0,'protocol call scope')
    expected={'verified':'VERIFIED_CLOSED','action-only':'ACTION_COMPLETED_PENDING_VERIFICATION',
        'condition-only':'SYMPTOM_RETREATED_PENDING_VERIFICATION','expired':'ACTION_COMPLETED_PENDING_VERIFICATION',
        'same-origin':'ACTION_COMPLETED_PENDING_VERIFICATION','cross-source-conflict':'ACTION_COMPLETED_PENDING_VERIFICATION',
        'risk-accepted':'RISK_ACCEPTED','risk-acceptance-expired':'SYMPTOM_RETREATED_PENDING_VERIFICATION','escalated':'ESCALATED',
        'false-alarm':'FALSE_ALARM_REVIEWED','false-alarm-adverse':'OPEN_UNCONFIRMED','fresh-after-expiry':'VERIFIED_CLOSED',
        'fabricated-operation':'REJECTED','expired-action-grant':'REJECTED','actual23-inspection-incomplete':'ACTION_COMPLETED_PENDING_VERIFICATION'}
    require({c['id']:c['expected']['status'] for c in protocol['cases']}==expected,'literal lifecycle table matches frozen protocol')
    declared=set(protocol['durable_root'])|{c['id']+'/'+n for c in protocol['cases'] for n in protocol['durable_case']}
    require(len(declared)==20 and set(receipt['artifacts'])==declared,'declared20 artifacts')
    actual={p.relative_to(REPO/CAPTURE).as_posix() for p in (REPO/CAPTURE).rglob('*') if p.is_file()}
    require(actual==declared|{'receipt.json'},'exact21 durable files without caches')
    delivered=blobs(DELIVERY,[CAPTURE+'/'+n for n in actual])
    for name in actual:
        raw=(REPO/CAPTURE/name).read_bytes();require(raw==delivered[CAPTURE+'/'+name],'committed original '+name)
        if name!='receipt.json':require(digest(raw)==receipt['artifacts'][name],'receipt digest '+name)
    pin_names={n for group in receipt['pinned'].values() for n in group}
    source_blobs=blobs(SOURCE,pin_names);delivery_blobs=blobs(DELIVERY,pin_names)
    for role,group in receipt['pinned'].items():
        for name,wanted in group.items():
            require(digest(source_blobs[name])==wanted==digest(delivery_blobs[name]),'execution/delivery '+role+' '+name)
    tree=git('ls-tree','-r','-z','--name-only',SOURCE,'src','configs',PACKAGE+'/development',PACKAGE+'/reference',
        'evidence/mainline/engineering/23-interventions/capture-01','evidence/mainline/engineering/23-interventions/reference').decode().strip('\0').split('\0')
    independent_membership=dict(runtime={n for n in tree if n.startswith('src/') and n.endswith('.py')},
        tools={'scripts/closure_delivery.py','scripts/closure_correction_delivery.py','scripts/inspection_delivery.py','scripts/prepare_closure_inputs.py'},
        inputs={PROTOCOL,'docs/mainline/24-closure-contract.md','tests/test_verified_closure.py',*protocol['preserved_inputs'],
            *[n for n in tree if n.startswith(PACKAGE+'/') or n.startswith('configs/full-facility') or n.startswith('evidence/mainline/engineering/23-interventions/')]})
    for role,paths in independent_membership.items():require(paths==set(receipt['pinned'][role]),'complete declared pin membership '+role)
    ledger=[json.loads(line) for line in (REPO/CAPTURE/'attempts.jsonl').read_text(encoding='utf-8').splitlines()]
    require(len(ledger)==30,'30 ordered ledger rows')
    cases={}
    for index,case in enumerate(protocol['cases']):
        pair=ledger[index*2:index*2+2]
        require([r['status'] for r in pair]==['STARTED','COMPLETED'] and all(r['case']==case['id'] and r['execution_commit']==SOURCE for r in pair),'single accounted case '+case['id'])
        inputs=json.loads(source_blobs[case['input']]);result=read(REPO/CAPTURE/case['id']/'result.json')
        require(result.get('status',result.get('questions',[{}])[0].get('status'))==expected[case['id']],'saved expected lifecycle '+case['id'])
        if expected[case['id']]=='REJECTED':
            require(result['error_type']=='ValueError' and case['expected']['error_contains'] in result['error'],'semantic rejection '+case['id']);cases[case['id']]=result;continue
        frame=inputs['frame'];question=result['questions'][0];visible={r['id']:r for r in frame['evidence']['records']}
        require(result['facility_id']==frame['facility_id'] and result['as_of_s']==frame['as_of_s'],'frame identity '+case['id'])
        require(question['question_closed']==(question['status'] in {'VERIFIED_CLOSED','RISK_ACCEPTED','FALSE_ALARM_REVIEWED'})
            and question['risk_closed']==(question['status']=='VERIFIED_CLOSED'),'separate closure semantics '+case['id'])
        require(not question['physical_restoration_claim'] and not result['execution_permission'] and result['physical_actions']==[],'no physical claim '+case['id'])
        require(len(result['unevaluated_question_ids'])==7 and question['scope']=='DECLARED_FINITE_SAMPLED_CRITERIA_ONLY','finite scope remains '+case['id'])
        for row in frame['evidence']['records']:
            require(row['observed_at_s']<=row['arrived_at_s']<=frame['as_of_s'],'only arrived input '+case['id']+'/'+row['id'])
        for record_id in question['supporting_record_ids']:
            row=visible[record_id];require(row['availability']=='current' and row['quality']['status']=='bounded','current bounded support '+case['id']+'/'+record_id)
        for event in question['trace']:
            require(event['observed_at_s']<=event['arrived_at_s']<=frame['as_of_s'],'available event trace '+case['id'])
            if 'record_id' in event:
                row=visible[event['record_id']];require(all(row[k]==event[k] for k in ('observed_at_s','arrived_at_s','valid_until_s','provenance')),'trace retained identity '+case['id']+'/'+row['id'])
        cases[case['id']]=dict(status=question['status'],supporting_ids=question['supporting_record_ids'],checks=question['checks'],trace=question['trace'])
    original23=read(REPO/'evidence/mainline/engineering/23-interventions/capture-01/filter-later-inspection/run.json')
    actualcase=read(REPO/PACKAGE/'reference/actual23-inspection-incomplete.json')
    row=actualcase['frame']['evidence']['records'][0];original=original23['inspection_public_snapshot']['records'][0]
    require(row==original,'actual23record copied exactly without new reading')
    require((row['observed_at_s'],row['arrived_at_s'])==(5.25,5.75),'actual23measurement times')
    require(actualcase['program']['intervention_feedback']==original23['intervention_public_feedback'],'actual23feedback original')
    q=cases['actual23-inspection-incomplete'];require(q['supporting_ids']==['post-clean-flow'] and q['checks'][0]['genuine_sample_count']==1
        and q['checks'][1]['genuine_sample_count']==0,'actual incomplete cannot close')
    originals={}
    for dirname in ('','correction-01'):
        folder=OLD/dirname;manifest=read(folder/'delivery-manifest.json');count=0
        for item in manifest['files']:
            raw=(folder/item['path']).read_bytes();require(digest(raw)==item['sha256'] and len(raw)==item['bytes'],'preserved prior '+dirname+'/'+item['path']);count+=1
        originals[dirname or 'invalid-fixture-original']=count
    # Read saved originals only; no call to the application or author verifier.
    original_capture=REPO/PACKAGE/'capture-01'
    original_receipt=read(original_capture/'receipt.json')
    original_names=set(original_receipt['artifacts'])|{'receipt.json'}
    original_git=blobs('52ef152eb8e1e517e2a46e12f029ad464d618f0e',[PACKAGE+'/capture-01/'+n for n in original_names])
    for name in original_names:
        raw=(original_capture/name).read_bytes();require(raw==original_git[PACKAGE+'/capture-01/'+name],'original formal capture preserved '+name)
    require(original_receipt['assessment_attempts']+receipt['assessment_attempts']==protocol['cumulative_formal_assessment_calls']==30,'explicit cumulative30formal assessments')
    require(protocol['prior_execution']==original_receipt['execution_commit'] and protocol['prior_delivery']=='52ef152eb8e1e517e2a46e12f029ad464d618f0e','preserved prior identity')
    for case in protocol['cases']:
        result=read(REPO/CAPTURE/case['id']/'result.json');oldresult=read(original_capture/case['id']/'result.json')
        if expected[case['id']]=='REJECTED':
            require(result==oldresult,'same semantic rejection '+case['id']);continue
        q=result['questions'][0];oldq=oldresult['questions'][0]
        require(all(q[k]==oldq[k] for k in ('status','risk_closed','question_closed','supporting_record_ids')),'criterion status unaffected '+case['id'])
        evaluated=q['checks']+[item for ev in q['review_evaluations'] for key in ('review_checks','current_checks') for item in ev[key]]
        blocked={n for c in evaluated for n in c['insufficient_record_ids']}
        considered=blocked|set(q['supporting_record_ids'])|{n for c in evaluated for n in c['supporting_record_ids']}
        trace={ev['record_id']:ev for ev in q['trace'] if ev['event'] in {'VERIFICATION_RECORD_AVAILABLE','VERIFICATION_RECORD_BLOCKED'}}
        require(set(q['blocking_record_ids'])==blocked and set(trace)==considered,'complete evidence retention '+case['id'])
        for identifier in considered:require(trace[identifier]['event']==('VERIFICATION_RECORD_BLOCKED' if identifier in blocked else 'VERIFICATION_RECORD_AVAILABLE'),'correct event disposition '+case['id']+'/'+identifier)
    for name in ('false-alarm-adverse','cross-source-conflict'):
        q=read(REPO/CAPTURE/name/'result.json')['questions'][0]
        blocked=next(e for e in q['trace'] if e.get('record_id')=='fixed-adverse-5')
        require(blocked['event']=='VERIFICATION_RECORD_BLOCKED' and blocked['observed_at_s']==5 and blocked['arrived_at_s']==5.5 and blocked['valid_until_s']==10,'literal decisive blocker '+name)
        require(blocked['provenance']=={'origin_id':'fixed-adverse-origin','copied_from_record_id':None},'literal blocker origin '+name)
    fa=read(REPO/CAPTURE/'false-alarm-adverse/result.json')['questions'][0]
    ev=fa['review_evaluations'][0]
    require(ev['review_record_id']=='review-disposition' and ev['passed'] is False and ev['reason']=='CRITERIA_INCOMPLETE_OR_CONTRADICTED','failedFAevaluation retained')
    require(all(c['passed'] for c in ev['review_checks']) and [c['passed'] for c in ev['current_checks']]==[False,True],'dossier pass versus current contradiction explicit')
    require(fa['status']=='OPEN_UNCONFIRMED' and fa['risk_closed'] is False and fa['question_closed'] is False,'failedFAremainsopen')
    preserved_review={}
    for directory in (OUT.parent,OUT.parent/'static-correction-01',OUT.parent/'correction-preflight-01'):
        manifest=read(directory/'delivery-manifest.json');items=manifest['files'];count=0
        for name,item in items.items():
            raw=(directory/name).read_bytes();require(digest(raw)==item['sha256'] and len(raw)==item['bytes'],'preserved earlier final review '+directory.name+'/'+name);count+=1
        preserved_review[directory.name]=count
    review=dict(schema='aegisdc-independent-ticket24-spec-saved-correction-review-v1',status='PASS',unresolved_findings=0,
        source=SOURCE,data_delivery=DELIVERY,checks_passed=len(checks),checks=checks,findings=[],resolved_findings=['SPEC24-FINAL-01'],
        pin_counts={k:len(v) for k,v in receipt['pinned'].items()},durable_artifacts=20,terminal_receipts=1,
        correction_assessments=15,cumulative_formal_assessments=30,new_assessments=0,new_tests=0,new_physics=0,new_inference=0,
        prior_files_preserved=originals,prior_final_review_files_preserved=preserved_review,case_summaries=cases,reviewed_utc=datetime.now(timezone.utc).isoformat())
    write(OUT/'review.json',review)
    write(OUT/'source-pins.json',dict(source=SOURCE,data_delivery=DELIVERY,pinned=receipt['pinned']))
    report="""# Ticket24 correction final saved SPEC review

PASS for correction execution78922bcb and deliverycf90d9f5. Unresolved findings:0. SPEC24-FINAL-01 is resolved in separately frozen capture-02: the failed false-alarm review retains its review/current criterion results and reason, and decisive fixed-adverse-5 is a blocking trace event with observation5s, arrival5.5s, validity10s and original provenance. Ordinary cross-source blockers and all considered evidence receive the same trace coverage. The unsuccessful review remains OPEN_UNCONFIRMED; no evidence upgrade or private-state access was introduced.

The independent saved-byte audit covers20durable artifacts plus receipt,30ordered ledger rows,15correction outcomes including two semantic rejections, and all60runtime/4tool/152input pins against execution/delivery Git blobs. Statuses and supported evidence remain consistent with the original15case protocol. The actual23handheld record is still the exact5.25s observation/5.75s arrival; a single reading with no service confirmation remains incomplete.

Original capture-01, its1044-check review and P2, the prior133invalid-fixture files and36corrected-independent-review files remain unchanged. The explicit protocol accounts for30cumulative formal assessments, zero physical runs and no automatic retries. This final review ran zero assessments, probes, tests, physics or inference. Fresh-checkout/visual proof, integrated full regression, acceptance and publication remain parent-owned gates. The complete research goal stays active.
"""
    (OUT/'SPEC.md').write_text(report,encoding='utf-8',newline='\n')
    manifest={p.name:dict(sha256=digest(p.read_bytes()),bytes=p.stat().st_size) for p in OUT.iterdir() if p.is_file()}
    write(OUT/'delivery-manifest.json',dict(files=manifest,source=SOURCE,data_delivery=DELIVERY))
    print(json.dumps(dict(status=review['status'],checks_passed=len(checks),pin_counts=review['pin_counts'],unresolved_findings=0,prior_files_preserved=originals,new_assessments=0)))
if __name__=='__main__':main()
