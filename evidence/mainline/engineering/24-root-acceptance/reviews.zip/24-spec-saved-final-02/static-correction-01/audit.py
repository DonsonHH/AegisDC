"""Static correction readback; no application execution."""
from hashlib import sha256
from pathlib import Path
import json
import subprocess
ROOT=Path('C:/Users/Donson/.codex/worktrees/mainline23-intervention/Renly')
OUT=Path(__file__).resolve().parent;ORIGINAL=OUT.parent
SOURCE='af6012ba37265ff5e7be08e6e8e7f7a4e08a6c20'
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT)
def digest(raw):return sha256(raw).hexdigest()
def write(path,value):
    with path.open('x',encoding='utf-8',newline='\n') as stream:stream.write(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
original=json.loads((ORIGINAL/'delivery-manifest.json').read_bytes())
for name,item in original['files'].items():
    raw=(ORIGINAL/name).read_bytes();assert digest(raw)==item['sha256'] and len(raw)==item['bytes']
diff=git('diff','6ff98fb1644463b24f76eb28864ab374cf0f06cc',SOURCE,'--','src/aegis_dc/verified_closure.py','tests/test_verified_closure.py')
(OUT/'correction.diff').write_bytes(diff)
files={}
for name in ('src/aegis_dc/verified_closure.py','tests/test_verified_closure.py'):
    raw=git('cat-file','blob',SOURCE+':'+name);path=OUT/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(raw)
    files[name]=dict(sha256=digest(raw),bytes=len(raw),git_blob=git('rev-parse',SOURCE+':'+name).decode().strip())
report=dict(status='STATIC_CORRECTION_PASS_SAVED_RESULT_PENDING',source=SOURCE,finding='SPEC24-FINAL-01',
    original_review='../review.json',original_files_preserved=len(original['files']),new_assessments=0,new_tests=0,new_physics=0,new_inference=0,
    checks=['Unsuccessful false-alarm review exposes passed/reason and both review/current check lists',
        'Blocking IDs are retained separately from supporting IDs',
        'Trace includes all current criterion blockers and considered supporting records with original epochs/provenance',
        'Failed checks cannot upgrade risk/question closure status','No private plant access introduced','Duplicate trace assembly unified'],files=files)
write(OUT/'review.json',report)
(OUT/'SPEC.md').write_text('''# Static correction of SPEC24-FINAL-01

PASS at af6012ba for the reviewed source correction. False-alarm verification now retains each unsuccessful review evaluation and its review/current criteria. All blocking record identities are retained and traced with original observation, arrival, validity and provenance. The unified trace assembly distinguishes blockers from considered supporting records without declaring those checks successful. Decision gates, closure statuses and private-state boundaries remain unchanged.

The original6ff/52efreview,1044saved checks and P2 remain immutable. This supplement runs zero assessments, tests, physics or inference. Final closure of the finding awaits the separately frozen capture-02 saved result and delivery identity.
''',encoding='utf-8',newline='\n')
write(OUT/'delivery-manifest.json',dict(source=SOURCE,files={p.relative_to(OUT).as_posix():dict(sha256=digest(p.read_bytes()),bytes=p.stat().st_size) for p in OUT.rglob('*') if p.is_file()}))
print(json.dumps(dict(status=report['status'],original_files_preserved=report['original_files_preserved'],new_assessments=0)))
