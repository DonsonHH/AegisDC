"""Independent committed-byte audit only; never import assessed project code."""
from pathlib import Path
from hashlib import sha256
import json
import subprocess

ROOT=Path('C:/Users/Donson/.codex/worktrees/mainline23-intervention/Renly')
OUT=Path(__file__).resolve().parent
WORK=OUT.parent.parent
SOURCE='78922bcb3cc290c924987c495118775827dd1c3b'
DELIVERY='cf90d9f5459eeea10cf9c4b767a6dfc6077bdcf1'
BASE='61257dd8766c0173e1c10c42c9cb53d973626fe3'
PACKAGE='evidence/mainline/engineering/24-closure'
CAPTURE=PACKAGE+'/capture-02'
PROTOCOL='docs/mainline/24-closure-correction-01-protocol.json'

def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT)
def sha(raw):return sha256(raw).hexdigest()
def write(name,value):
    raw=value if isinstance(value,bytes) else (json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode()
    target=OUT/name;target.parent.mkdir(exist_ok=True,parents=True)
    with target.open('xb') as stream:stream.write(raw)
def blobs(revision,names):
    names=sorted(set(names));raw=subprocess.check_output(['git','cat-file','--batch'],cwd=ROOT,
        input=''.join(revision+':'+n+'\n' for n in names).encode())
    result={};offset=0
    for name in names:
        end=raw.index(b'\n',offset);header=raw[offset:end].split()
        assert len(header)==3 and header[1]==b'blob',name
        start=end+1;size=int(header[2]);result[name]=raw[start:start+size];offset=start+size+1
    assert offset==len(raw)
    return result

checks=[]
def check(name,condition,actual=None):
    checks.append(dict(name=name,passed=bool(condition),actual=actual));assert condition,name

receipt=json.loads(blobs(DELIVERY,[CAPTURE+'/receipt.json'])[CAPTURE+'/receipt.json'])
protocol=json.loads(blobs(SOURCE,[PROTOCOL])[PROTOCOL])
declared=set(protocol['durable_root'])|{c['id']+'/'+n for c in protocol['cases'] for n in protocol['durable_case']}
check('receipt status/source',receipt['status']=='PASS' and receipt['execution_commit']==SOURCE and receipt['source_head_and_bytes_unchanged'])
check('attempt accounting',receipt['assessment_attempts']==receipt['completed']==15 and receipt['expected_rejections']==2 and receipt['failures']==0)
check('engineering scope',receipt['physical_runs']==receipt['registered_research_trials']==0 and receipt['field_calibration']=='PENDING' and receipt['global_regression_gate']=='PENDING_ROOT_INTEGRATED_FULL')
check('declared durable count',len(declared)==20,len(declared))
check('receipt durable membership',set(receipt['artifacts'])==declared)
entries=git('ls-tree','-rz','--name-only',DELIVERY,CAPTURE).decode().strip('\0').split('\0')
check('committed durable membership',set(entries)=={CAPTURE+'/'+n for n in declared|{'receipt.json'}})
check('cache exclusion',all('__pycache__' not in n and not n.endswith(('.pyc','.pyo')) for n in entries))
raw_outputs=blobs(DELIVERY,entries);artifact_hashes={}
for name in sorted(declared|{'receipt.json'}):
    raw=raw_outputs[CAPTURE+'/'+name];h=sha(raw)
    if name!='receipt.json':check('receipt artifact '+name,h==receipt['artifacts'][name])
    artifact_hashes[name]=dict(sha256=h,bytes=len(raw))
ledger=[json.loads(line) for line in raw_outputs[CAPTURE+'/attempts.jsonl'].decode().splitlines()]
check('ledger rows',len(ledger)==30,len(ledger))
pin_names=git('ls-tree','-rz','--name-only',SOURCE,'src','configs',PACKAGE+'/development',PACKAGE+'/reference',
    'evidence/mainline/engineering/23-interventions/capture-01','evidence/mainline/engineering/23-interventions/reference').decode().strip('\0').split('\0')
memberships=dict(runtime={n for n in pin_names if n.startswith('src/') and n.endswith('.py')},
    tools={protocol['authoring_tool'],protocol['helper_tool'],protocol['input_preparation_tool'],*protocol['additional_tools']},
    inputs={PROTOCOL,protocol['contract'],protocol['input_fixture'],*protocol['preserved_inputs']}|{n for n in pin_names if n.startswith(PACKAGE+'/')
        or n.startswith('configs/full-facility') or n.startswith('evidence/mainline/engineering/23-interventions/')})
all_names=set().union(*memberships.values());source_blobs=blobs(SOURCE,all_names);delivery_blobs=blobs(DELIVERY,all_names)
pins={}
for role,names in memberships.items():
    check('pin membership '+role,set(receipt['pinned'][role])==names,len(names));pins[role]={}
    for name in sorted(names):
        raw=source_blobs[name];h=sha(raw)
        check('execution delivery pin '+role+'/'+name,h==receipt['pinned'][role][name] and raw==delivery_blobs[name])
        pins[role][name]=dict(sha256=h,bytes=len(raw))
for i,case in enumerate(protocol['cases']):
    pair=ledger[2*i:2*i+2]
    check('ordered attempt '+case['id'],[r['status'] for r in pair]==['STARTED','COMPLETED'] and all(r['case']==case['id'] and r['execution_commit']==SOURCE for r in pair))
    inp=json.loads(source_blobs[case['input']]);result=json.loads(raw_outputs[CAPTURE+'/'+case['id']+'/result.json']);expected=case['expected']
    if expected['status']=='REJECTED':
        check('semantic rejection '+case['id'],result['status']=='REJECTED' and result['error_type']=='ValueError' and expected['error_contains'] in result['error']);continue
    question=result['questions'][0];frame=inp['frame'];visible={r['id']:r for r in frame['evidence']['records']}
    check('frozen expected lifecycle '+case['id'],all(question[k]==v for k,v in expected.items()))
    check('public output scope '+case['id'],result['facility_id']==frame['facility_id'] and result['as_of_s']==frame['as_of_s'] and not result['execution_permission'] and result['physical_actions']==[] and not question['physical_restoration_claim'])
    check('support availability '+case['id'],all(n in visible and visible[n]['availability']=='current' and visible[n]['arrived_at_s']<=frame['as_of_s'] for n in question['supporting_record_ids']))
    check('trace timing '+case['id'],all(e['observed_at_s']<=e['arrived_at_s']<=frame['as_of_s'] for e in question['trace']))
    check('trace original identities '+case['id'],all(all(e[k]==visible[e['record_id']][k] for k in ('observed_at_s','arrived_at_s','valid_until_s','provenance')) for e in question['trace'] if 'record_id' in e))
actual=json.loads(source_blobs[PACKAGE+'/reference/actual23-inspection-incomplete.json'])
upstream=json.loads(source_blobs['evidence/mainline/engineering/23-interventions/capture-01/filter-later-inspection/run.json'])
record=upstream['inspection_public_snapshot']['records'][0];received=actual['frame']['evidence']['records']
check('exact actual23record reuse',len(received)==1 and all(received[0][k]==record[k] for k in record))
check('exact actual23feedback reuse',actual['program']['intervention_feedback']==upstream['intervention_public_feedback'])
check('actual23record times',received[0]['observed_at_s']==5.25 and received[0]['arrived_at_s']==5.75)
export_names=['AGENTS.md','GLOSSARY.md','docs/MAINLINE.md','docs/mainline/progress.json','docs/agents/issue-tracker.md','docs/agents/domain.md','docs/agents/triage-labels.md','docs/adr/0002-sparse-evidence-not-sensor-free.md','docs/adr/0003-complete-facility-mainline.md','docs/mainline/information-boundary.md','docs/mainline/24-closure-contract.md',PROTOCOL,'src/aegis_dc/verified_closure.py','scripts/closure_delivery.py','scripts/closure_correction_delivery.py','scripts/prepare_closure_inputs.py','scripts/inspection_delivery.py']
for name,raw in blobs(DELIVERY,export_names).items():write('export/'+name,raw)
write('review.diff',git('diff','--no-ext-diff',BASE+'...'+DELIVERY));write('commits.txt',git('log','--oneline',BASE+'..'+DELIVERY))
prior_before=json.loads((OUT.parent/'original-review-before.json').read_bytes())
prior_after={p.name:sha(p.read_bytes()) for p in (WORK/'24-standards-final-01').iterdir() if p.is_file()}
check('prior reviews unchanged',prior_before==prior_after)
write('original-review-after.json',prior_after)
audit=dict(schema='aegisdc-ticket24-independent-standards-saved-audit-v1',execution_source=SOURCE,data_delivery=DELIVERY,
    all_checks_passed=True,checks_passed=len(checks),checks=checks,pin_counts={k:len(v) for k,v in pins.items()},pins=pins,
    durable_output_count=20,terminal_receipts=1,artifact_hashes=artifact_hashes,ledger_rows=30,formal_assessment_calls=15,expected_rejections=2,
    new_assessments=0,new_tests=0,new_physical_runs=0,new_inference=0,new_capture=0,new_full_regressions=0,correction=True,cumulative_formal_assessment_calls=30,
    original_review_files_preserved=len(prior_before),live_checkout_rule='Mutable author checkout is not an immutable delivery authority; compare exact SOURCE and DELIVERY Git blobs')
write('saved-byte-audit.json',audit)
print(json.dumps(dict(checks_passed=len(checks),pins=audit['pin_counts'],outputs=21,prior_review_files_preserved=len(prior_before),new_assessments=0)))
