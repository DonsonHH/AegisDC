from pathlib import Path
from copy import deepcopy
import json,hashlib,sys,datetime,traceback,subprocess
OUT=Path(__file__).resolve().parent;EX=OUT.parent/'export';sys.path.insert(0,str(EX/'src'))
from aegis_dc.decision_view import DecisionGateway
from aegis_dc.verified_closure import assess_closure
def dump(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2,allow_nan=False)+chr(10),encoding='utf-8')
def record(ident,source,target,obs,value,time,unit='1',quality='bounded',expires=20,arrival=None,origin=None,copy=None):
 return dict(id=ident,source_id=source,target_id=target,observable_id=obs,unit=unit,value=value,observed_at_s=time,arrived_at_s=time+.25 if arrival is None else arrival,valid_until_s=expires,quality=dict(status=quality,error_bound=0 if quality=='bounded' else None,note='Independent finite evidence-only review fixture.'),provenance=dict(origin_id=origin or ident,copied_from_record_id=copy))
def fixture():
 accepted=json.loads((EX/'evidence/mainline/engineering/18-beliefs/capture-01/cli-frame.json').read_bytes());n=accepted['nominal_knowledge'];st=accepted['evidence']['static_knowledge']
 ledger=dict(schema='aegisdc-evidence-ledger-v1',id=accepted['evidence']['ledger_id'],facility_id=accepted['facility_id'],basis='synthetic_assumption',time_unit='s',**deepcopy(st),records=[])
 ledger['observables'].extend([dict(id='spec24-service',quantity='service_capacity',value_type='number',unit='1'),dict(id='spec24-review',quantity='category',value_type='text',unit='1')])
 for ident,target,obs,kind in [('spec24-meter','intake_pump','flow','handheld'),('spec24-service-channel','critical_service','spec24-service','control_record'),('spec24-reviewer','intake_pump','spec24-review','human_report')]:ledger['sources'].append(dict(id=ident,kind=kind,basis='synthetic_assumption',target_ids=[target],observable_ids=[obs],dependency_group=None,source_note='Independent synthetic declared channel.'))
 for t in (6,8):ledger['records'] += [record('flow-'+str(t),'spec24-meter','intake_pump','flow',.09,t,'m3/s'),record('service-'+str(t),'spec24-service-channel','critical_service','spec24-service',1,t)]
 catalog=json.loads((EX/'configs/full-facility-risk-scenarios-v1.json').read_bytes());belief=json.loads((EX/'configs/full-facility-belief-model-v1.json').read_bytes())
 profile=dict(schema='aegisdc-closure-profile-v1',id='spec24-closure',facility_id=accepted['facility_id'],nominal_knowledge_id=n['id'],risk_catalog_id=catalog['id'],basis='synthetic_assumption',time_unit='s',source_note='Independent finite sampled verification assumptions.',rules=[dict(id='spec24-rule',question_id='cooling',opened_at_s=0,task_id='spec24-task',operation_id='spec24-clean',minimum_span_s=2,required_samples=2,checks=[dict(id='condition',role='condition',target_id='intake_pump',observable_id='flow',source_ids=['spec24-meter'],accepted_interval=[.08,.12]),dict(id='service',role='service',target_id='critical_service',observable_id='spec24-service',source_ids=['spec24-service-channel'],accepted_interval=[1,1])])],review_channels=[],authorizations=[],false_alarm_reviews=[])
 program=dict(schema='aegisdc-closure-program-v1',profile=profile,risk_catalog=catalog,belief_model=belief,intervention_feedback=[dict(task_id='spec24-task',operation_id='spec24-clean',source_id='intervention-execution-report',observed_at_s=4,arrived_at_s=4.5,outcome='APPLIED',reason=None,origin_id='intervention:spec24-task',coverage='THIS_AUTHORIZED_TASK_ONLY',risk_closed=False)])
 return accepted,n,ledger,program
def add_review(ledger,p,value='ACCEPT_RISK',expires=20):
 ledger['records'].append(record('review','spec24-reviewer','intake_pump','spec24-review',value,9,quality='reported',arrival=9.5))
 p['profile']['review_channels']=[dict(id='review-channel',question_id='cooling',source_id='spec24-reviewer',target_id='intake_pump',observable_id='spec24-review',authorization_id='authority')]
 p['profile']['authorizations']=[dict(id='authority',source_id='spec24-reviewer',question_ids=['cooling'],dispositions=['ACCEPT_RISK','FALSE_ALARM','ESCALATE'],starts_at_s=0,expires_at_s=expires,basis='synthetic_assumption',source_note='Independent synthetic finite authority.')]
 if value=='FALSE_ALARM':p['profile']['false_alarm_reviews']=[dict(review_record_id='review',question_id='cooling',supporting_record_ids=['flow-6','flow-8','service-6','service-8'],rationale='Independent explicit review of the original suspicion against listed condition and service observations.')]
def main():
 protocol=json.loads((OUT/'protocol.json').read_bytes());assert hashlib.sha256((OUT/'protocol.json').read_bytes()).hexdigest()==(OUT/'protocol.sha256').read_text().split()[0]
 manifest=json.loads((OUT.parent/'source-manifest.json').read_bytes())
 for row in manifest['files']:assert hashlib.sha256((EX/row['path']).read_bytes()).hexdigest()==row['sha256']
 ledgerfile=OUT/'attempts.jsonl';assert not ledgerfile.exists();results=[]
 for case in protocol['cases']:
  ident=case['id'];accepted,nominal,ledger,p=fixture();asof=10
  if ident=='action-only':ledger['records']=[]
  elif ident=='condition-only':ledger['records']=[r for r in ledger['records'] if r['source_id']=='spec24-meter']
  elif ident in {'cross-source-conflict','false-alarm-cross-source-conflict'}:ledger['records'].append(record('fixed-adverse','point_flow','intake_pump','flow',.01,8,'m3/s'))
  elif ident=='review-conflict':
   add_review(ledger,p);ledger['records'].append(record('review-rejection','spec24-reviewer','intake_pump','spec24-review','REJECT_RISK',9,quality='reported',arrival=9.5))
  elif ident=='review-provenance-mismatch':
   add_review(ledger,p);r=next(r for r in ledger['records'] if r['id']=='review');r['provenance'].update(copied_from_record_id='review-parent',origin_id='mismatch-origin');ledger['records'].append(record('review-parent','spec24-reviewer','intake_pump','spec24-review','ACCEPT_RISK',8.5,quality='reported',origin='original-review-origin'))
   ledger['records'][-1]['provenance']['copied_from_record_id']='missing-root'
  elif ident=='authority-exact-expiry':add_review(ledger,p,expires=10)
  elif ident=='same-instant-two-origins':
   for r in ledger['records']:
    if r['observed_at_s']==8:r.update(observed_at_s=6,arrived_at_s=6.25)
  elif ident=='fabricated-operation':p['profile']['rules'][0]['operation_id']='made-up-write-actual-state';p['intervention_feedback'][0]['operation_id']='made-up-write-actual-state'
  if ident in {'false-alarm-valid','false-alarm-cross-source-conflict','pre-review-expired-support'}:
   p['intervention_feedback']=[];add_review(ledger,p,'FALSE_ALARM')
   if ident=='pre-review-expired-support':
    for r in ledger['records']:
     if r['id'].startswith(('flow-','service-')):r['valid_until_s']=8.75
  plan=dict(schema='aegisdc-public-preparation-plan-v1',id='spec24-plan',basis='synthetic_assumption',time_unit='s',decision_times_s=[asof],requests=accepted['requests']);frame=DecisionGateway(nominal,ledger,plan).next_frame()
  folder=OUT/'runs'/ident;folder.mkdir(parents=True,exist_ok=False);dump(folder/'inputs.json',dict(frame=frame,program=p,ledger=ledger));before=deepcopy((frame,p))
  with ledgerfile.open('a',encoding='utf-8') as f:f.write(json.dumps(dict(id=ident,status='STARTED',at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat()))+chr(10));f.flush()
  try:
   output=assess_closure(frame,p);dump(folder/'raw-result.json',output);q=output['questions'][0];status=q['status'];expected=case['expected']
   passed=(status==expected if expected in {'VERIFIED_CLOSED','ACTION_COMPLETED_PENDING_VERIFICATION','SYMPTOM_RETREATED_PENDING_VERIFICATION','FALSE_ALARM_REVIEWED'} else not q['question_closed'] if expected=='NOT_CLOSED' else status!='RISK_ACCEPTED' if expected=='NOT_RISK_ACCEPTED' else False)
   result=dict(id=ident,expected=expected,status='COMPLETED',actual_status=status,passed=passed,question_closed=q['question_closed'],risk_closed=q['risk_closed'],conflicts=frame['evidence']['conflicts'],provenance_issues=frame['evidence']['provenance_issues'],input_mutated=(frame,p)!=before)
  except Exception as error:
   result=dict(id=ident,expected=case['expected'],status='REJECTED',passed=case['expected']=='REJECT',exception_type=type(error).__name__,exception=str(error),traceback=traceback.format_exc())
  dump(folder/'checks.json',result);results.append(result)
  with ledgerfile.open('a',encoding='utf-8') as f:f.write(json.dumps(dict(id=ident,status=result['status'],passed=result['passed']))+chr(10))
 for row in manifest['files']:assert hashlib.sha256((EX/row['path']).read_bytes()).hexdigest()==row['sha256']
 dump(OUT/'source-guard-after.json',dict(source=protocol['source'],export_count=len(manifest['files']),export_unchanged=True,has_caches=any(EX.rglob('__pycache__')),mainline_head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()))
 dump(OUT/'probe-results.json',dict(source=protocol['source'],assess_closure_calls=9,physical_calls=0,inference_calls=0,test_runs=0,results=results,passed=sum(r['passed'] for r in results)))
 print(json.dumps(dict(calls=9,passed=sum(r['passed'] for r in results),failed=[r for r in results if not r['passed']]),ensure_ascii=False))
if __name__=='__main__':main()
