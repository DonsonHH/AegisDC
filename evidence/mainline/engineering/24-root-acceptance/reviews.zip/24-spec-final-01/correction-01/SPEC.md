# Ticket 24 independent SPEC review

Changes required at e99073f271fb2531cdaec37bf29eb552d5864962, fixed base61257dd8766c0173e1c10c42c9cb53d973626fe3.

P1 SPEC24-01: checks discard current same-signal contradiction outside selected positive sources. A handheld flow.09 and visible fixed point_flow.01 at8s generate an explicit public conflict, yet restoration returns VERIFIED_CLOSED. The same omission permits FALSE_ALARM_REVIEWED when its dossier excludes the adverse sensor. This violates the restoration contradiction and false-alarm no-cherry-picking rules.

P1 SPEC24-02: categorical review conflicts are ignored. Simultaneous same-source ACCEPT_RISK and REJECT_RISK yield RISK_ACCEPTED. Disputed authority evidence cannot justify that current disposition.

P1 SPEC24-03: a fabricated operation duplicated in feedback and rule returns VERIFIED_CLOSED without a named public action declaration. This contradicts the declared authorized-action requirement.

The explicitly revised engineering protocol ran9 corrected public assess_closure calls:5 pass and4 counterexample cases. The original12 calls all failed an independent fixture ledger identity mismatch before closure logic; they remain invalid-fixture rejects, never product passes. No physics, test suite or inference ran. Corrected inputs, raw results, ledger and source guards are preserved. Later fixes receive a separate static supplement; original results are not rewritten. Complete-facility research remains active; this review has no ticket acceptance authority.
