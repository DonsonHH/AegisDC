"""Stdlib-only original/config census and independent literal checks.

No plant, flash solver, controller, allocator, workforce or acceptance imports.
"""
from copy import deepcopy
import hashlib
import json
import math
from pathlib import Path
import subprocess
import zipfile

HERE = Path(__file__).resolve().parent
ROOT = Path(r'C:/Users/Donson/Documents/ChatGPT/Renly/.work/worktrees/full-site-12')
BASE = ROOT / 'evidence/mainline/engineering/12-numerical'
PIN = '37ebc676a9d18c7874ba4313062fbcb7a133867a'


def sha(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024*1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def load(path):
    return json.loads(path.read_text(encoding='utf-8'))


book = load(ROOT / 'docs/mainline/12-numerical-runbook.json')
cases = {row['id']: row for row in book['cases']}
entry = load(BASE / 'final-entry-01/summary.json')
profile = load(ROOT / book['profile'])
common = load(BASE / 'capture-04/receipt.json')['runtime_sources']
indexes = {name: load(BASE / name / 'runs-index.json') for name in ('capture-04','refinement-01','resolution-v3-01')}
expected_limits = dict(temperature_K=.05, pressure_Pa=1000, heat_W=25000,
                       service_deficit_time_s=.001,unserved_service_unit_s=.001,
                       resource_time_s=.001,switch_time_s=.001)
assert book['limits'] == expected_limits == entry['limits']
assert entry['reference_fraction_of_limits'] == .25
assert len(cases) == 11 == entry['full_case_count']
assert len(entry['all_original_inputs']) == 102
assert entry['original_v1_numeric_gate_preserved'] is False
assert entry['additive_six_case_gate'] is False
assert entry['additional_resolution_gate'] is True

archive_census = {}
commit_set = set()
total_states = 0
for relative, expected in entry['all_original_inputs'].items():
    path = ROOT / relative
    assert sha(path) == expected, relative
    name, h_text = path.parent.name, path.stem.removeprefix('h-')
    family = next(folder for folder in indexes if '/' + folder + '/' in relative)
    record = indexes[family][name][h_text]
    assert record['archive_sha256'] == expected
    with zipfile.ZipFile(path) as archive:
        assert set(archive.namelist()) == {'run.json','scenario.json','private-state.jsonl','balances.jsonl'}
        run_bytes = archive.read('run.json')
        scenario_bytes = archive.read('scenario.json')
        manifest, scenario = json.loads(run_bytes), json.loads(scenario_bytes)
        for member, raw in [('run.json',run_bytes),('scenario.json',scenario_bytes)]:
            assert hashlib.sha256(raw).hexdigest() == record['original_members'][member]['sha256']
        assert hashlib.sha256(scenario_bytes).hexdigest() == manifest['artifacts']['scenario.json']['sha256']
        for member, identity in manifest['artifacts'].items():
            assert identity['sha256'] == record['original_members'][member]['sha256']
        assert manifest['code_identity']['files'] == common
        assert manifest['code_identity']['implementation_has_changes'] is False
        assert manifest['inputs']['maximum_step_s'] == float(h_text)
        assert manifest['inputs']['duration_s'] == cases[name]['duration_s']
        assert manifest['inputs']['boundary_events'] == cases[name]['events']
        assert manifest['inputs']['work_requests'] == cases[name]['work_requests']
        assert manifest['status'] == 'ENGINEERING_FIXTURE_COMPLETED'
        assert all(manifest[key] == 0 for key in ('research_trials','model_calls','training_calls'))
        assert manifest['property_reference']['sha256'] == profile['runtime']['property_sha256']
        expected_scenario = deepcopy(profile)
        for parameter in expected_scenario['parameters']:
            if parameter['id'] in cases[name]['overrides']:
                parameter.update(value=cases[name]['overrides'][parameter['id']], basis='synthetic_assumption',
                                 source_note='Frozen ticket 12 numerical engineering case: '+name)
        numeric = next(p for p in scenario['parameters'] if p['id'] == 'step_time')
        expected_numeric = next(p for p in expected_scenario['parameters'] if p['id'] == 'step_time')
        minimum = {'capture-04':.01,'refinement-01':.0025,'resolution-v3-01':.00125}[family]
        assert numeric['valid_range'][0] == minimum
        if family != 'capture-04':
            assert numeric['valid_range'][1] == expected_numeric['valid_range'][1]
            for parameter in (numeric, expected_numeric):
                for field in ('valid_range','basis','source_note'):
                    del parameter[field]
        assert scenario == expected_scenario, relative
        points = manifest['artifacts']['private-state.jsonl']['records']
        intervals = manifest['artifacts']['balances.jsonl']['records']
        assert points == intervals + 1
        commit_set.add(manifest['code_identity']['git_commit'])
        total_states += points
        archive_census[relative] = dict(sha256=expected, family=family, case=name, step_s=float(h_text),
                                       source_commit=manifest['code_identity']['git_commit'],state_points=points,
                                       member_count=4,physical_scenario_equal_except_declared_numeric_metadata=True)
assert total_states == 306705 == entry['all_original_state_points']
assert sorted(commit_set) == entry['actual_runtime_execution_commits']
git_source_checks = 0
for commit in commit_set:
    for name, expected in common.items():
        actual = subprocess.check_output(['git','show',commit+':'+name], cwd=ROOT)
        assert hashlib.sha256(actual).hexdigest() == expected
        git_source_checks += 1


def candidate(name):
    row = entry['cases'][name]
    first = row['original_inputs'][0]
    assert first['maximum_step_s'] == row['candidate_maximum_step_s']
    with zipfile.ZipFile(ROOT / first['path']) as archive:
        manifest = json.loads(archive.read('run.json'))
    return ROOT / first['path'], manifest


literals = {}
path, manifest = candidate('isolated-room')
maximum = 0.
with zipfile.ZipFile(path) as archive:
    with archive.open('private-state.jsonl') as stream:
        for line in stream:
            row = json.loads(line)
            expected = 293.15 + 10*math.exp(-row['time_s']/10)
            maximum = max(maximum,abs(row['domains']['equipment_environment']['room_temperature_K']-expected))
assert maximum <= .005
literals['isolated_room_analytic'] = dict(expected_terminal_K=293.15+10/math.e,
                                       maximum_absolute_error_K=maximum,limit_K=.005,
                                       independent_basis='Exact scalar exponential solution C/G=10 s; no Euler recurrence used.')

path, manifest = candidate('shared-AC-capacity')
with zipfile.ZipFile(path) as archive:
    with archive.open('private-state.jsonl') as stream:
        first = json.loads(next(stream))['domains']
rectifier = 100000 - 110 - 1000 - 19200 - 150000/7 - 5000
service = .97*rectifier/2200000
assert abs(first['power']['rectifier_input_W']-rectifier) < 1e-7
assert abs(first['it_service']['delivered']-service) < 1e-12
assert abs(manifest['summary']['delivered_service_unit_s']-2*service) < 1e-10
literals['shared_ac_hand_budget'] = dict(rectifier_expected_W=rectifier,service_expected=service,
                                       independent_basis='Subtract listed paid AC loads, apply .97 rectifier efficiency and 2.2 MW IT requirement.')

_, manifest = candidate('outage')
assert abs(manifest['summary']['service_deficit_time_s']-(.75+3+.5-.75)) < 1e-9
literals['outage_hand_interval'] = dict(expected_deficit_s=3.5,actual=manifest['summary']['service_deficit_time_s'])

_, manifest = candidate('finite-generator-hand')
times = {(row.get('actor'),row.get('mode')):row['time_s'] for row in manifest['events'] if row['kind']=='reserve_transition'}
empty = next(row['time_s'] for row in manifest['events'] if row['kind']=='fuel_depleted')
starter = 10000-3*1010-2*10
fuel_at_transfer = 42750-5*1000
exhaustion = 5+fuel_at_transfer/(1110/.4+1000)
assert abs(times[('generator','transferring')]-3)<.001
assert abs(times[('generator','supplying')]-5)<.001
assert abs(empty-exhaustion)<.001
literals['generator_hand_clock_and_fuel'] = dict(starter_at_transfer_J=starter,fuel_at_transfer_J=fuel_at_transfer,
                                              expected_exhaustion_s=exhaustion,actual_exhaustion_s=empty)

_, manifest = candidate('finite-UPS-hand')
summary = manifest['summary']
expected_battery = .2*1000+32.4*(100000/.9+1000)
expected_protected = 32.4*100000
control_heat = 32.6*1000
conversion = expected_protected*(1/.9-1)
assert abs(expected_battery-3632600)<1e-8
assert abs(summary['ups_output_energy_J']-(expected_protected+control_heat))<.001
assert abs(summary['ups_loss_energy_J']-conversion)<.001
assert abs(summary['reserve_room_control_heat_J']-control_heat)<.001
depletion = next(row['time_s'] for row in manifest['events'] if row['kind']=='ups_depleted')
assert abs(depletion-32.6)<.001
literals['ups_hand_energy_and_clock'] = dict(expected_battery_J=expected_battery,expected_protected_J=expected_protected,
                                          expected_control_J=control_heat,expected_conversion_J=conversion,actual_depletion_s=depletion)

_, manifest = candidate('combined-240s')
summary = manifest['summary']
offered = 240+.2*(185.25-10.25)
leak = .5*(160.5-120.5)
drain = .1*(240-120.5)
floor = leak-drain
work = next(row for row in manifest['work_records'] if row['id']=='room-engineering-visit')
assert abs(summary['demand_service_unit_s']-offered)<1e-7
assert abs(summary['internal_hot_leaked_mass_kg']-leak)<1e-7
assert abs(summary['floor_water_drained_mass_kg']-drain)<1e-7
assert abs(summary['worker_work_person_s']-25.25)<1e-7
assert abs(work['finished_at_s']-145.5)<1e-7
literals['combined_hand_mass_demand_work'] = dict(expected_offered_unit_s=offered,expected_leak_kg=leak,
                                               expected_drain_kg=drain,expected_floor_kg=floor,
                                               expected_work_person_s=25.25,actual_work_finish_s=work['finished_at_s'])

phase = load(BASE / 'capture-04/phase-domain.json')
original_phase = load(ROOT / 'evidence/mainline/engineering/04-06-root-acceptance/endpoint-representation/probe-result-01.json')
assert len(phase['frozen_outcomes']) == 432 == len(original_phase['all_outcomes'])
for current, original in zip(phase['frozen_outcomes'],original_phase['all_outcomes']):
    assert current['inputs'] == original['inputs']
    assert current['outcome']['status'] == original['outcome']['status']
    assert {key:float(value).hex() for key,value in current['inputs'].items()} == current['inputs_float_hex']
strict = [row for row in phase['frozen_outcomes'] if row['outcome']['status']=='REFUSED']
assert len(strict) == 5 == phase['frozen_refusals']
assert all(row['encoded_quality_at_nominal_pressure']>1 for row in strict)
assert len(phase['neighborhoods']) == 255
for row in phase['neighborhoods']:
    assert {key:float(value).hex() for key,value in row['inputs'].items()} == row['inputs_float_hex']
refusals = load(BASE / 'capture-04/expected-rejections.json')
assert len(refusals) == 3
for row, declared in zip(refusals,book['rejections']):
    assert row['request'] == declared
    assert declared['error_contains'] in row['error']
    assert row['successful_trajectory_returned'] is False

guards = load(HERE / 'source-guard-before-02.json')
after = {name:sha(ROOT/name) for name in guards['files']}
assert all(value == guards['files'][name] for name,value in after.items())
result = dict(status='PASS',pin=PIN,archives=102,members=408,manifest_state_points=total_states,
              physical_scenario_checks=102,actual_execution_commits=sorted(commit_set),git_execution_source_checks=git_source_checks,
              archive_census=archive_census,independent_literal_groups=literals,
              original_phase_representation_cases=432,strict_original_refusals=5,hex_neighborhoods=255,
              expected_whole_facility_refusals=3,
              source_guard='PASS',guarded_files=len(after),
              distinction='Census checks all compressed archive SHA/config/manifest identities. Actual trace/member replay is separate in the final witness readback; counts here do not claim a second simulation or re-flash.',
              physics_runs=0,property_solver_runs=0,full_suite_runs=0,research_trials=0)
with (HERE / 'independent-saved-data-audit-01.json').open('x',encoding='utf-8',newline='\n') as stream:
    stream.write(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
print(json.dumps({key:result[key] for key in ('status','archives','members','manifest_state_points','physical_scenario_checks','git_execution_source_checks','source_guard','guarded_files')}))
