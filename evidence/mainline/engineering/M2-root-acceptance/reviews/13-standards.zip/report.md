# Reader-v3 Standards closure

Baseline9a68ea7f; reviewed coree59d3ec16a598dde80cb9dcd1a26e695e2f2360c, execution/toolse4ecc1a8b30f7d85cb1b0fc31157c7d178289c40, data8ac3f7865f2fd36af4859116307b11df1726fae0 and final metadata73e5c5c15eecfcc00825069b126e82c9097125dd. Both earlier Standards reports remain unchanged.

## Hard standards

Balance-time finding:closed1; remaining/open0; new0. Existing attribute closure remains closed. replay_format.py:240-264 now requires finite builtin numeric/nonboolean times, positive contiguous nonoverlapping intervals, exact trace pairing, zero-to-actual-duration coverage and the plant's endpoint-addition maximum-step bound. It adds no physical clipping or widened tolerance. The original Temp 'not-a-time' input is now refused at trajectory_balances. A new FAILED/NOT_STARTED request retains the exact bad balance bytes at origin/trajectory/balances.jsonl; a mocked plant confirms zero calls. The frozen original probe is unchanged.

Request defaults resolve through the frozen scenario and must equal terminal/run actual inputs; replay consumes validated execution_inputs. This is separately accounted from the Spec verdict. Private-state, failure/unknown, versioned-format and registered-research boundaries remain intact.

## Judgment-based smells

0 material findings across all12 Fowler heuristics. Binding and time-axis logic are gathered in the format module, with staged reader errors at the public seam. No extra abstraction or historical-tool rewrite is warranted.

## Independent evidence and metadata

13 pure coordinate examples pass/refuse as specified, including legitimate floating endpoint rounding and one-ULP-overbound rejection; null-default binding also passes.178-file before/after byte guards pass. Both core files match e59 and e4 Git bytes. No target suite, model or full run was repeated.

The actual read-only delivery command passes126 artifacts+receipt,664 prior files,18 runtime/five tools, four completions and three real-CLI staged refusals. It reads the captured26 green targets; author_full_suite remains NOT_RUN_THIS_REVISION. Old01/02/04 packages,13.json/13-reader-v2.json and cf9's345/343/two optional-skip full remain unchanged. Final73e metadata preserves these identities and awaits root closure.

Prospective attribute-union SHA316a7acc45865a0d25737e68dd4fba820d6c2a01d218992da92bd8aa601a3ef4 independently retains all12/13 rules and only the reader's anchored root LF addition. This is static metadata advice, not merge or numerical qualification. Historical05 verification must retain its frozen8ac input identities; merged-root metadata needs its own receipt.12/M2/full-research acceptance is outside this review. All outputs are Temp.
