# Spec closure: ticket 13 execution binding

Fixed baseline `9a68ea7fb2eeee580d3fa0b794e8cbe0fb734a97`; reviewed code `e59d3ec16a598dde80cb9dcd1a26e695e2f2360c` (implementation `47b0c3cd`). Actual source bytes, rather than later metadata HEADs, were guarded.

**Previous request-binding finding: 1 closed, 0 open. New Spec findings: 0.** The initial version/lifecycle finding remains closed. Standards' separate balance-time finding is independently confirmed closed below, without adding it to the Spec count.

The contract requires replay of the frozen duration/maximum step (`13-replay-contract.md:51–53`, revision `:118–125`). The exact prior duration 2→3 and step .5→.25 mutation copies now refuse at `stage=request`, `artifact=request.json`. Replaying either creates a new FAILED/NOT_STARTED request and preserves its conflicting request bytes. `bind_execution_inputs` (`replay_format.py:205`) resolves nulls from the frozen scenario and checks terminal/run agreement; replay (`replay.py:384`) forwards validated actual values.

A self-consistent decoder copy with null requests resolves to 2/.5. An intercepted recording seam confirms replay forwards those actual values, not nulls. This is a decoder/forwarding control, not a newly executed physical result. A separate literal null-default example resolves to 3/.25.

Standards' exact `start_s='not-a-time'` copy is refused at `trajectory_balances`; its new FAILED request preserves the offending balance bytes. Numeric/non-boolean, positive, contiguous partition and trace/run boundary checks are implemented. The coordinate upper bound matches the plant's `min(..., t+h)` rule: a legal `.2+.1` endpoint passes despite subtraction rounding. No physical tolerance is widened.

Eleven selected reader/refusal tests pass, zero skips. Existing v1/v2 controls and all eighteen stored capture-04 requests remain readable (six completed/twelve failed). A 593-file before/after guard passes; twenty runtime/test files exactly match the code pin's Git blobs. Plant/thermodynamics diff is empty. No physics, full suite, research or model run occurred.

No requirement regression or extra mechanism was found within this limited closure. The preserved capture-04 and its 345/343 full remain attributed to their original source. New capture-05 delivery and root integration/full acceptance are outside this source-only review; ticket 12 qualification is separate.

Evidence: `aegisdc-review-13-reader-v3-spec-attachments/closure-01.json`, `selected-tests.log`, `closure_check.py`, `review-receipt.json`.
