"""Copy-only execution-binding and balance-coordinate closure."""
from contextlib import redirect_stdout, redirect_stderr
from hashlib import sha1, sha256
import io
import json
from pathlib import Path
import shutil
import subprocess
import sys
import unittest
from unittest.mock import patch

ROOT = Path(r'C:/Users/Donson/Documents/ChatGPT/Renly/.work/worktrees/full-site-13')
OUT = Path(__file__).resolve().parent
PIN = 'e59d3ec16a598dde80cb9dcd1a26e695e2f2360c'
CAPTURE = ROOT / 'evidence/mainline/engineering/13-replay/capture-04'
OLD = Path(r'C:/Users/Donson/AppData/Local/Temp/aegisdc-review-13-reader-v2-spec-attachments')
STD = Path(r'C:/Users/Donson/AppData/Local/Temp/aegisdc-reader-v2-balance-time-wpe3ignt')


def sha(path):
    return sha256(path.read_bytes()).hexdigest()


def write_json(path, value):
    path.write_text(json.dumps(value, allow_nan=False, indent=2) + '\n', encoding='utf-8', newline='\n')


def rehash(folder, artifact):
    path = folder / 'attempt.json'
    data = json.loads(path.read_bytes())
    data['artifacts'][artifact] = sha(folder / artifact)
    write_json(path, data)


def main():
    receipt = json.loads((CAPTURE / 'receipt.json').read_bytes())
    paths = {ROOT / name for name in receipt['runtime_sources']}
    paths |= {ROOT / 'tests/test_replay_reader_authority.py', ROOT / 'tests/test_replay_execution_binding.py',
              ROOT / 'docs/mainline/13-replay-contract.md', ROOT / 'docs/mainline/evidence/13.json',
              ROOT / 'docs/mainline/evidence/13-reader-v2.json'}
    paths |= {CAPTURE / name for name in receipt['artifacts']}
    paths |= {ROOT / name for name in receipt['prior_durable_files']}
    originals = [OLD / 'copies' / ('request_' + name) for name in ('duration_s', 'maximum_step_s')]
    originals.append(STD / 'origin')
    paths |= {p for origin in originals for p in origin.rglob('*') if p.is_file()}
    identity = lambda: {str(path): sha(path) for path in sorted(paths)}
    before = identity()
    tree = {}
    for entry in subprocess.check_output(['git', 'ls-tree', '-r', '-z', PIN], cwd=ROOT).split(b'\0'):
        if entry:
            header, name = entry.split(b'\t', 1)
            tree[name.decode()] = header.split()[2].decode()
    source_paths = set(receipt['runtime_sources']) | {'tests/test_replay_reader_authority.py', 'tests/test_replay_execution_binding.py'}
    for name in source_paths:
        raw = (ROOT / name).read_bytes()
        assert sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest() == tree[name], name
    old_receipt = json.loads((OLD / 'review-receipt.json').read_bytes())
    for name, expected in old_receipt['declared_durable_review_files'].items():
        assert sha(OLD / name) == expected, name

    sys.path[:0] = [str(ROOT / 'src'), str(ROOT / 'tests'), str(ROOT / 'scripts')]
    from aegis_dc import replay
    from aegis_dc.replay_format import balance_time_axis, bind_execution_inputs
    from patrol_rsi.contracts import digest
    plant_calls = []
    def no_plant(*args, **kwargs):
        plant_calls.append(kwargs)
        raise AssertionError('Closure review may not execute the plant')
    replay.simulate_scenario = no_plant
    closures = {}
    for name, origin, stage, bad_artifact in (
            ('duration', originals[0], 'request', 'request.json'),
            ('maximum_step', originals[1], 'request', 'request.json'),
            ('balance_string', originals[2], 'trajectory_balances', 'trajectory/balances.jsonl')):
        copied = OUT / 'copies' / name
        shutil.copytree(origin, copied)
        try:
            replay.read_attempt(copied)
        except replay.AttemptReadError as error:
            assert error.stage == stage and error.artifact == bad_artifact
            observation = dict(status='REFUSED', stage=error.stage, artifact=error.artifact, message=str(error))
        else:
            raise AssertionError(name + ' still grants authority')
        target = OUT / 'refusals' / name
        refused = replay.replay_attempt(copied, target)
        assert refused['status'] == 'FAILED' and refused['execution_kind'] == 'NOT_STARTED'
        assert refused['failure']['stage'] == 'replay_origin.' + stage
        assert (target / 'origin' / bad_artifact).read_bytes() == (copied / bad_artifact).read_bytes()
        assert replay.read_attempt(target)['run'] is None
        closures[name] = dict(observation, request_status=refused['status'], execution_kind=refused['execution_kind'],
                              bad_bytes_preserved=True, exact_original_mutation_bytes=True)

    # A self-consistent decoder positive control, not a new physical execution.
    # Only duration/step DEFAULTS change to the already-recorded effective values;
    # the old trace is retained solely as the immutable readback fixture.
    default_copy = OUT / 'copies/default_control'
    shutil.copytree(CAPTURE / 'causal-baseline', default_copy)
    scenario = json.loads((default_copy / 'scenario-input.json').read_bytes())
    terminal = json.loads((default_copy / 'attempt.json').read_bytes())
    request = json.loads((default_copy / 'request.json').read_bytes())
    effective = {key: terminal[key] for key in ('duration_s', 'maximum_step_s')}
    for row in scenario['parameters']:
        if row['id'] in {'duration', 'step_time'}:
            row['value'] = effective['duration_s' if row['id'] == 'duration' else 'maximum_step_s']
    request.update(duration_s=None, maximum_step_s=None)
    write_json(default_copy / 'scenario-input.json', scenario)
    write_json(default_copy / 'trajectory/scenario.json', scenario)
    write_json(default_copy / 'request.json', request)
    manifest = json.loads((default_copy / 'trajectory/run.json').read_bytes())
    manifest['scenario_sha256'] = terminal['scenario_sha256'] = digest(scenario)
    manifest['artifacts']['scenario.json']['sha256'] = sha(default_copy / 'trajectory/scenario.json')
    write_json(default_copy / 'trajectory/run.json', manifest)
    for artifact in ('scenario-input.json', 'trajectory/scenario.json', 'request.json', 'trajectory/run.json'):
        terminal['artifacts'][artifact] = sha(default_copy / artifact)
    write_json(default_copy / 'attempt.json', terminal)
    decoded = replay.read_attempt(default_copy)
    assert decoded['request']['duration_s'] is None and decoded['request']['maximum_step_s'] is None
    assert decoded['execution_inputs'] == effective == {'duration_s': 2, 'maximum_step_s': .5}
    forwarded = {}
    def intercept_recorded(*args, **kwargs):
        forwarded.update(kwargs)
        return {'review_seam_intercepted': True}
    with patch.object(replay, '_run_recorded', intercept_recorded):
        assert replay.replay_attempt(default_copy, OUT / 'never-created') == {'review_seam_intercepted': True}
    assert forwarded['duration_s'] == 2 and forwarded['step_s'] == .5
    assert not (OUT / 'never-created').exists()
    closures['none_default_positive_control'] = dict(status='PASS', effective=effective,
        replay_forwarded={'duration_s': forwarded['duration_s'], 'step_s': forwarded['step_s']},
        scope='Self-consistent stored decoder fixture and intercepted recording seam only; no new run or physical result')
    algebra = bind_execution_inputs({'duration_s':None, 'maximum_step_s':None},
        {'parameters':[{'id':'duration','value':3}, {'id':'step_time','value':.25}]},
        {'duration_s':3,'maximum_step_s':.25}, {'duration_s':3,'maximum_step_s':.25})
    assert algebra == {'duration_s':3,'maximum_step_s':.25}
    axis = [0., .1, .2, .2+.1]
    balance_time_axis([{'start_s':a,'end_s':b} for a,b in zip(axis,axis[1:])],
        [{'time_s':value} for value in axis], duration_s=axis[-1], maximum_step_s=.1)
    assert axis[-1] - axis[-2] > .1
    closures['binary64_coordinate_positive_control'] = dict(status='PASS', times=axis,
        maximum_step_s=.1, last_subtracted_interval_s=axis[-1]-axis[-2],
        scope='Coordinate bound accepts a legal start+h end despite subtraction rounding')

    import test_replay_reader_authority as old_tests
    import test_replay_execution_binding as new_tests
    selected = [(old_tests.ReplayReaderAuthorityTests,name) for name in dir(old_tests.ReplayReaderAuthorityTests)
                if name.startswith('test_') and name != 'test_failed_request_can_retain_invalid_declared_duration_without_claiming_completion']
    selected += [(new_tests.ExecutionBindingTests,name) for name in dir(new_tests.ExecutionBindingTests)
                 if name.startswith('test_') and name != 'test_none_parameters_resolve_frozen_defaults_and_replay_validated_actual_values']
    stream = io.StringIO()
    with redirect_stdout(stream), redirect_stderr(stream):
        tested = unittest.TextTestRunner(stream=stream, verbosity=2).run(unittest.TestSuite(cls(name) for cls,name in selected))
    (OUT / 'selected-tests.log').write_text(stream.getvalue(), encoding='utf-8', newline='\n')
    assert tested.testsRun == 11 and tested.wasSuccessful() and not tested.skipped
    completed_count = failed_count = 0
    for folder in CAPTURE.iterdir():
        if folder.is_dir() and (folder / 'attempt.json').exists():
            row = replay.read_attempt(folder)
            completed_count += row['record']['status'] == 'COMPLETED'
            failed_count += row['record']['status'] == 'FAILED'
    assert (completed_count, failed_count) == (6,12)
    assert identity() == before and not plant_calls
    result = dict(source_pin=PIN, baseline='9a68ea7fb2eeee580d3fa0b794e8cbe0fb734a97',
        spec_request_binding_finding=dict(closed=1, open=0), other_axis_balance_finding=dict(independently_confirmed_closed=1, counted_as_spec_finding=False),
        new_spec_findings=0, closures=closures, selected_tests=dict(run=11, failures=0, errors=0, skipped=0,
        methods=[cls.__name__+'.'+name for cls,name in selected]), saved_v2_requests=dict(completed=6,failed=12),
        actual_source_guard='PASS', git_bound_source_and_tests=len(source_paths), guarded_files=len(paths), guarded_sha256=before,
        plant_runs=0, full_suite_runs=0, research_trials=0, model_calls=0)
    with (OUT / 'closure-01.json').open('x', encoding='utf-8', newline='\n') as target:
        target.write(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({key:value for key,value in result.items() if key != 'guarded_sha256'}, ensure_ascii=False))


if __name__ == '__main__':
    main()
