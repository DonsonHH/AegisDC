"""Independent saved-only Spec audit of candidate 352d8333."""

from collections import Counter
from copy import deepcopy
from hashlib import sha256
import io
import json
from pathlib import Path
import subprocess
from zipfile import ZipFile

REPO=Path('C:/Users/Donson/.codex/worktrees/mainline30-protocol/Renly')
OUT=Path('C:/Users/Donson/Documents/ChatGPT/Renly/.work/30-spec-review-02')
BASE='3feccbb124b7e479b22cc8e361aad2d528b649de'
PIN='352d8333bd23b933ca1efb40027e51b7865739b7'
count=0
def check(test,message):
    global count
    count+=1
    if not test: raise AssertionError(message)
def git(*args,raw=None):
    return subprocess.check_output(['git',*args],cwd=REPO,input=raw)
def blob(name,rev=PIN):
    return git('cat-file','blob',f'{rev}:{name}')
def read(name):
    return json.loads(blob(name))
def canon(v):
    return json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
def digest(b):return sha256(b).hexdigest()
def public(document):
    d=deepcopy(document['dispatch_program'])
    d['inspection_program'].pop('realizations')
    d['sensor_program'].pop('realization')
    return d
check(git('merge-base',BASE,PIN).decode().strip()==BASE,'Non-descendant review target')
check(not git('diff','--name-only',BASE,PIN,'--','src'),'Candidate changes runtime')
plan=read('docs/mainline/30-comparison-protocol-v1.json')
blue=read('configs/full-facility-comparison-held-blueprints-v1.json')
dev=read('configs/full-facility-comparison-development-v1.json')
check(plan['status']=='DESIGN_OPEN_NO_EXECUTION','Unexpected execution status')
check(plan['global_budget']['llm_calls']==plan['global_budget']['training_calls']==plan['global_budget']['automatic_retries']==0,'New model call or retry budget')
summed=dict(attempts=0,simulated_charge_s=0,scheduled_decisions=0)
ids=set()
for phase,n,arms in [('development',6,6),('confirmation',16,6),('ablation',8,4),('robustness',8,2)]:
    row=plan['phases'][phase]
    check(len(row['worlds'])==n and len(row['arms'])==arms,'Phase unit count')
    for world in row['worlds']:
        check(world['id'] not in ids,'Cross-phase world identity reused')
        ids.add(world['id'])
        check(world['duration_s']==10,'Unexpected physical horizon')
    budget=dict(attempts=n*arms,simulated_charge_s=n*arms*10,scheduled_decisions=n*arms*10)
    check(row['budget']==budget,'Independent budget calculation')
    for key in summed:summed[key]+=budget[key]
check(summed=={k:plan['global_budget'][k] for k in summed}==dict(attempts=180,simulated_charge_s=1800,scheduled_decisions=1800),'Global budget')
check(Counter(w['family'] for w in plan['phases']['confirmation']['worlds'])==Counter({k:4 for k in blue['confirmation']}),'Confirmation strata')
variants=set()
for phase in ('confirmation','ablation'):
    for family,recipes in blue[phase].items():
        check(len(recipes)==(4 if phase=='confirmation' else 2),'Blueprint stratum count')
        for recipe in recipes:
            check(recipe['variant'] not in variants,'Duplicate held blueprint')
            variants.add(recipe['variant'])
            check(0<=recipe['network_cap']<=2 and .25<=recipe['filter_multiplier']<=100,'Baseline scalar bound')
check(set(blue['masks'])==set(plan['phases']['ablation']['arms'])-{'full'},'Ablation coverage')
check('Current equality gates need a separately reviewed extension' in blue['masks']['without_joint_crew_planning']['binding_scope'],'Adapter support not disclaimed')
check('compute-only' in blue['masks']['without_dependency_context']['capacity_transform'],'Dependency mask numeric definition missing')
check('sort_keys=True' in blue['sealing']['seed_derivation'] and 'tie break' in blue['sealing']['confirmation_order'],'Seed recipe incomplete')
check(plan['comparison']['outcome_order']==[r['label'] for r in plan['comparison']['outcome_rules']],'Outcome priority inconsistent')
check('Do not add' in plan['comparison']['metric_definition']['paid_person_s'],'Wait cost double counting')
check('Sum lower endpoints/16' in plan['comparison']['partial_outcome_details']['aggregate'],'Missing outcome denominator')
check('earliest differing' in plan['comparison']['identification']['unit'] and 'two' in plan['comparison']['identification']['criterion'],'Identification rule incomplete')
manifest=read('evidence/mainline/engineering/30-comparison-preparation/manifest.json')
archive=blob('evidence/mainline/engineering/30-comparison-preparation/preparation-originals.zip')
check(digest(archive)==manifest['archive_sha256'],'Saved preparation archive SHA')
with ZipFile(io.BytesIO(archive)) as z:
    names=z.namelist()
    check(len(names)==len(set(names)) and set(names)==set(manifest['members']),'Saved preparation members')
    for name in names:
        check(digest(z.read(name))==manifest['members'][name],'Saved original member SHA')
    for key in ('30-development-inputs-01','30-development-inputs-02'):
        record=json.loads(z.read(f'input-preparation/{key}/receipt.json'))
        check(record['source_guard'] and record['registered_research_trials']==record['facility_calls']==record['selector_calls']==0,'Preparation scope')
        check((record['status'],record['attempted'],record['passed'])==
              (('FAIL',5,4) if key.endswith('01') else ('PASS',36,36)),'Preparation attempt accounting')
        for path,expected in manifest['input_preparation'][key]['committed_source_identity'].items():
            check(digest(blob(path,record['source']))==expected,'Preparation source pins')
    frames={}
    for number in range(1,7):
        world=f'development-{number:02}'
        ds={}
        for arm in plan['phases']['development']['arms']:
            name=f'input-preparation/30-development-inputs-02/{world}/{arm}.json'
            document=json.loads(z.read(name));ds[arm]=document
            check({d['id'] for d in document['model']['domains']}=={
              'power','backup','facility_cooling','equipment_environment','it_service','control_monitoring','space_access','people_tools_work'},'Whole facility domain preservation')
            check(set(document['model']['graphs'])=={'physical','functional','control_information','access'},'Four relation views')
            check(document['duration_s']==10 and document['maximum_step_s']==.01,'Shared physical clock')
            check(document['dispatch_program']['decision_times_s']==list(range(10)),'Shared decision clock')
        same=[]
        for arm,document in ds.items():
            d=deepcopy(document)
            d['dispatch_program']['policy_program'].pop('policy')
            d['dispatch_program']['policy_program'].pop('options')
            same.append(canon(d))
        check(len(set(same))==1,'Six-arm shared world, evidence and execution envelope')
        left,right=(deepcopy(ds[k]) for k in plan['comparison']['primary'])
        for d in (left,right):d['dispatch_program']['policy_program'].pop('policy')
        check(canon(left)==canon(right),'Primary only-policy difference')
        frames[world]=public(ds['one_observation_lookahead'])
    check(canon(frames['development-01'])==canon(frames['development-03']),'Same public information for contrasting private network state')
check(read('docs/mainline/evidence/29-root.json')['status']=='ACCEPTED','Predecessor acceptance')
note=dict(
    status='DRAFT_SPEC_GAPS_RECORDED_NO_STUDY_EXECUTION',
    review_axis='Spec',candidate=PIN,base=BASE,checks=count,
    physical_calls=0,selector_calls=0,held_inputs_materialized=0,secret_reads=0,
    saved_original_members=len(manifest['members']),
    gaps=[
      dict(id='S1',scope='Pre-freeze gate',path='configs/full-facility-comparison-held-blueprints-v1.json',lines=[470,475],
           finding='Commitment/source-lock and release verifier are text only; no executable gate or accepted frozen registration evidence exists yet.'),
      dict(id='S2',scope='Declared future requirement, not hidden current support',path='configs/full-facility-comparison-held-blueprints-v1.json',lines=[347,354],
           finding='Team ablation requires a separately reviewed two-view adapter before execution; the current runtime equality contract cannot run that transform unchanged.'),
    ],
    passed_scope=[
       'Exact six-arm world/action parity in the 36 saved development inputs.',
       'Only primary policy name differs; contrasting private states share public input.',
       'Finite denominator, missing-outcome bounds, signs/cost and strata rules specified.',
       'Four held families, separate ablation and real robustness contrasts, exact seed ranking recipe.',
       'Old failure and successful input preparation preserved without facility or selector calls.'
    ])
OUT.mkdir(parents=True,exist_ok=False)
with (OUT/'audit.json').open('x',encoding='utf-8',newline='\n') as f:json.dump(note,f,indent=2);f.write('\n')
print(json.dumps(dict(status=note['status'],checks=count,members=len(manifest['members']),output=str(OUT))))
