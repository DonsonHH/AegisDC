# Ticket 30: independent Spec review of 352d8333

Base: `3feccbb124b7e479b22cc8e361aad2d528b649de`.
Reviewed candidate: `352d8333bd23b933ca1efb40027e51b7865739b7`.
Commands: `git diff BASE...CANDIDATE` and `git log BASE..CANDIDATE --oneline`.
This is a draft review; it is not protocol acceptance.

495 independently counted checks passed. The audit reads exact Git blobs and the 81-member original preparation ZIP. The 36 saved development inputs preserve the eight domains and four graphs, physical clock, actual operation and common evidence/resource envelopes. Removing the method-specific options and policy label gives identical six-arm inputs. The primary pair differs only by its policy label. The contrasting restricted/healthy network worlds have identical public input.

The protocol now fixes all 16 primary units, equal family weights, signed service and cost differences, non-double-counted paid time, missing-outcome bounds and earliest shared-history identification. The held assignment message, seed encoding and tie rule are explicit. The dependency mask now identifies its compute-only bundled knowledge assumption; it does not claim to isolate graph edges alone. Old refusals remain separate from successful preparations. No runtime code changed relative to the accepted base.

Pre-freeze finding S1: held blueprint lines 472–474 define commitment/source-lock and release only in prose; no committed verifier or actual source-bound receipt exists. They also require accepted ticket 32 before deriving confirmation inputs, while ticket 32 must already hash those inputs. Split input-only preparation from physical execution, then validate the appropriate dependency for each action. This addresses ticket 30's requirement to freeze seeds, methods and failure rules before research.

Declared future requirement S2: blueprint lines 347–354 explicitly require a separate planner/executor adapter for the team-choice mask. Existing equality gates do not implement that mask. It may remain a gated ticket 35 implementation, but no execution or support claim is justified yet.

No plant, selector, inference, seed creation or held preparation was invoked. `audit.py` is the independently authored saved-data checker; `audit.json` records its exact scope and counts.
