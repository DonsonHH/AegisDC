"""Verify saved Standards evidence only; never invoke the AegisDC runtime."""
from pathlib import Path
from hashlib import sha256
import json

folder=Path(__file__).resolve().parent
proof=json.loads((folder/'static-probes.json').read_bytes())
assert proof['source']=='352d8333bd23b933ca1efb40027e51b7865739b7'
assert proof['all_invalid_accepted'] is True and len(proof['probes'])==7
for item in proof['probes']:
    assert item['exit']==0
    assert (folder/'probes'/f"{item['name']}.stdout.raw").read_text(encoding='utf-8')==item['stdout']
    assert (folder/'probes'/f"{item['name']}.stderr.raw").read_text(encoding='utf-8')==item['stderr']
    value=json.loads(item['stdout'])
    assert value['status'].startswith('PASS')
    assert value['facility_calls']==value['selector_calls']==0
pins=json.loads((folder/'source-pins.json').read_bytes())
for path in (folder/'snapshot').rglob('*'):
    if path.is_file():
        relative=path.relative_to(folder/'snapshot').as_posix()
        assert sha256(path.read_bytes()).hexdigest()==pins[relative]
preservation=json.loads((folder/'preservation-proof.json').read_bytes())
assert preservation['members']==81 and preservation['test_stages']==8
assert {r['status'] for r in preservation['input_preparations']}=={'FAIL','PASS'}
assert proof['simulator_calls']==proof['selector_calls']==proof['seed_reads']==proof['held_inputs_materialized']==0
print(json.dumps({'status':'PASS_SAVED_STANDARDS_EVIDENCE','static_counterexamples':7,'archive_members':81,
                  'source':proof['source'],'physical_calls':0,'selector_calls':0,'held_inputs_materialized':0}))
