# Standards review — ticket 30 draft

Fixed base: `3feccbb124b7e479b22cc8e361aad2d528b649de`.
Fixed candidate: `352d8333bd23b933ca1efb40027e51b7865739b7`.
Diff: `git diff BASE...CANDIDATE`; the exact diff and SHA-256 identities are retained here.
This review does not accept ticket 30 or authorize release.

## Findings

1. **Plan validation is incomplete before freezing.** `scripts/registered_comparison.py:68–133` validates roster/clock/budget but ignores the normative metric, decision rules, cost thresholds, dependency tickets, release values and almost all attempt policy. Four saved static probes receive PASS after (a) negative gain and invalid cost dictionary, (b) immediate confirmation release through ticket31, (c) retry-until-success and no stops, or (d) deletion of metrics/rules/limits. The receipt honestly says structure-only; do not promote it to acceptance or release proof. Enforce the closed semantic protocol and add refusal witnesses. Basis: AGENTS.md immutable protocol/interface checks; spec user story30 and independent-comparison freeze rule.

2. **Blueprint validation checks identities rather than the declared transformation semantics.** `scripts/registered_comparison.py:140–193` accepts an exogenous `coolant_inventory=-1` event, negative robust offered demand, and empty ablation masks in three further saved static probes. It never validates event parameter/value legality, robust coordinate schemas/ranges or the required mask definitions. Such a PASS cannot qualify these held rules. Add closed allowed coordinate families, ranges, exact mask roles and phase-specific links. Basis: AGENTS.md source/design/assumption distinctions and invariant checks; spec unit/range/source and physical-vs-knowledge boundary rules.

No additional advisory smell rises to an actionable finding.

## Preservation and scope

The 81-member original preparation archive matches its manifest exactly, including all original test attempts, input preparation failures, successful 36-input construction and the retained authoring tools. Recorded source hashes match the specified Git blobs. No runtime cache is present in the delivery.

Seven invalid static probes used only an exported copy of the fixed stdlib CLI and public recipe drafts. No plant, selector, actual nonce/seed material or held world was run/read/materialized. See `static-probes.json`, `preservation-proof.json`, `source-pins.json` and `snapshot/`.

Result: **2 Standards findings before final freeze; exact original preservation passes.** Parent acknowledged both and is implementing corrections.
