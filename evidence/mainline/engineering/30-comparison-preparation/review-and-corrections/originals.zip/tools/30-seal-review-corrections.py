"""Retain original static review findings and their later repair evidence."""

from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys
from zipfile import ZIP_DEFLATED, ZipFile

ROOT=Path.cwd()
sys.path.insert(0,str(ROOT/'scripts'))
from inspection_delivery import hashes, read, require, write

BASE=Path('C:/Users/Donson/Documents/ChatGPT/Renly/.work')
PACKAGE=ROOT/'evidence/mainline/engineering/30-comparison-preparation/review-and-corrections'
STAGES={
    'blueprints-red-01':'FAIL','blueprints-green-01':'PASS',
    'analysis-red-01':'FAIL','analysis-green-01':'PASS',
    'semantic-red-01':'FAIL','semantic-green-01':'PASS',
    'release-red-01':'FAIL','release-green-01':'PASS','release-gate-fixture-01':'PASS',
}
RECORDS=('attempt.json','terminal.json','stdout.raw','stderr.raw')


def digest(raw):
    return sha256(raw).hexdigest()


def archive():
    members={}
    for axis,dirname,field in (('Spec','30-spec-review-02','files'),('Standards','30-standards-review-02','artifacts')):
        folder=BASE/dirname
        manifest=read(folder/'manifest.json')
        require(manifest['candidate']=='352d8333bd23b933ca1efb40027e51b7865739b7','Original review revision differs')
        for name,sha in manifest[field].items():
            raw=(folder/name).read_bytes()
            require(digest(raw)==sha,'Original independent review differs')
            members[f'independent/{axis}/{name}']=raw
        members[f'independent/{axis}/manifest.json']=(folder/'manifest.json').read_bytes()
    for stage,expected in STAGES.items():
        folder=ROOT/'.work'/f'30-{stage}'
        start,terminal=(read(folder/name) for name in RECORDS[:2])
        require(start['pins']==hashes(start['source'],start['pins'])
                and start['source']==terminal['source'] and terminal['source_guard'] and terminal['status']==expected,
                'Focused original test lifecycle differs')
        for stream in ('stdout','stderr'):
            require(digest((folder/f'{stream}.raw').read_bytes())==terminal[f'{stream}_sha256'],
                    'Native stream changed')
        for name in RECORDS:
            members[f'tests/{stage}/{name}']=(folder/name).read_bytes()
    members['tools/30-seal-review-corrections.py']=Path(__file__).read_bytes()
    PACKAGE.mkdir()
    out=PACKAGE/'originals.zip'
    with ZipFile(out,'x',compression=ZIP_DEFLATED,compresslevel=6) as z:
        for name,raw in sorted(members.items()):
            z.writestr(name,raw)
    write(PACKAGE/'manifest.json',dict(status='RETAINED_EXACT_ORIGINALS',draft_review_source='352d8333bd23b933ca1efb40027e51b7865739b7',
        correction_test_source='0bf8dbeb81dc3494696a2b6c32a53c93b1ae3fb7',
        original_static_findings={'Spec':1,'Standards':2},original_standards_probes=7,
        facility_calls=0,selector_calls=0,registered_research_trials=0,
        archive_sha256=digest(out.read_bytes()),members={name:digest(raw) for name,raw in sorted(members.items())}))
    print(f'{len(members)} review and correction artifacts sealed')


if __name__=='__main__':
    archive()
