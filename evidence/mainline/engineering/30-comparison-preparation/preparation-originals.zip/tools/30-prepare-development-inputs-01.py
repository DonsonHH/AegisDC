"""Save input-only construction receipts for all 36 development slots."""

from copy import deepcopy
from datetime import datetime, timezone
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys

ROOT=Path.cwd()
sys.path.insert(0,str(ROOT/'scripts'))
from registered_comparison import audit_pair, canonical, read
from prepare_comparison_worlds import prepare, PROTOCOL


def git(*args):
    return subprocess.check_output(['git',*args],cwd=ROOT)


def digest(data):
    return sha256(data).hexdigest()


def append(path,value):
    with path.open('a',encoding='utf-8',newline='\n') as f:
        f.write(json.dumps(dict(value,time_utc=datetime.now(timezone.utc).isoformat()),allow_nan=False)+'\n')


def write(path,value):
    with path.open('x',encoding='utf-8',newline='\n') as f:
        json.dump(value,f,ensure_ascii=False,indent=2,allow_nan=False)
        f.write('\n')


def shared_input(document):
    shared=deepcopy(document)
    policy=shared['dispatch_program']['policy_program']
    policy.pop('policy')
    policy.pop('options')
    return digest(canonical(shared))


def public_key(document):
    public=deepcopy(document['dispatch_program'])
    public['inspection_program'].pop('realizations')
    public['sensor_program'].pop('realization')
    return digest(canonical(public))


def main():
    source=sys.argv[1]
    assert git('rev-parse','HEAD').decode().strip()==source and not git('status','--porcelain')
    base=ROOT/'.work/30-development-inputs-01'
    base.mkdir()
    plan=read(PROTOCOL)['phases']['development']
    verdict=dict(status='FAIL',source=source,classification='INPUT_ONLY_ENGINEERING_NOT_REGISTERED_EXECUTION',
        planned=len(plan['worlds'])*len(plan['arms']),attempted=0,passed=0,facility_calls=0,selector_calls=0,
        registered_research_trials=0,checks={},authoring_tool_sha256=digest(Path(__file__).read_bytes()))
    try:
        from aegis_dc.action_value import assess_action_value
        from aegis_dc.policy_execution import PolicySession

        for world in plan['worlds']:
            case=world['id']
            folder=base/case
            folder.mkdir()
            common,public,admitted={},None,{}
            for arm in plan['arms']:
                verdict['attempted']+=1
                append(base/'input-attempts.jsonl',dict(world=case,arm=arm,status='STARTED'))
                try:
                    doc,legal=prepare(case,arm)
                    path=folder/f'{arm}.json'
                    write(path,doc)
                    common[arm]=shared_input(doc)
                    admitted[arm]=legal
                    if arm=='one_observation_lookahead':
                        p=doc['dispatch_program']
                        frame=PolicySession(p,world['duration_s']).work_program['initial_frame']
                        opts=p['policy_program']['options']
                        # Validate the shared finite declaration. Do not retain predictions or call either selector.
                        assess_action_value(frame,opts['belief_model'],opts['catalog'],opts['value_model'])
                        public=public_key(doc)
                except BaseException as exc:
                    append(base/'input-attempts.jsonl',dict(world=case,arm=arm,status='FAIL',error=str(exc)))
                    raise
                else:
                    verdict['passed']+=1
                    append(base/'input-attempts.jsonl',dict(world=case,arm=arm,status='PASS',eligible_paid_options=legal))
            pair=audit_pair((folder/'one_observation_lookahead.json',folder/'evidence_consistent_contingent.json'))
            assert len(set(common.values()))==1,'Physical, evidence, clock or action envelope changes across reference arms'
            verdict['checks'][case]=dict(pair_sha256=pair['shared_input_sha256'],common_six_arm_sha256=next(iter(common.values())),
                shared_public_key=public,static_paid_options=admitted)
        assert verdict['checks']['development-01']['shared_public_key']==verdict['checks']['development-03']['shared_public_key']
        assert verdict['planned']==verdict['attempted']==verdict['passed']==36
        verdict['status']='PASS'
    except BaseException as exc:
        verdict.update(error_type=type(exc).__name__,error=str(exc))
        raise
    finally:
        verdict['source_guard']=git('rev-parse','HEAD').decode().strip()==source and not git('status','--porcelain')
        if not verdict['source_guard']:
            verdict['status']='FAIL'
        verdict['artifacts']={p.relative_to(base).as_posix():digest(p.read_bytes()) for p in sorted(base.rglob('*')) if p.is_file()}
        write(base/'receipt.json',verdict)
    print(json.dumps({k:verdict[k] for k in ('status','source','planned','attempted','passed','facility_calls','selector_calls','registered_research_trials')}))


if __name__=='__main__':
    main()
