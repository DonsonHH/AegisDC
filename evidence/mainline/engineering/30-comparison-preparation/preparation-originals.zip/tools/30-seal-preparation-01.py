"""Preserve input-only development original attempts without replay or line-ending conversion."""

import json
from hashlib import sha256
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile
import sys

ROOT=Path.cwd()
sys.path.insert(0,str(ROOT/'scripts'))
from inspection_delivery import git, hashes, read, require, write

WORK=ROOT/'.work'
PACKAGE=ROOT/'evidence/mainline/engineering/30-comparison-preparation'
STAGES={
    'pair-red-01':'FAIL','pair-green-01':'PASS',
    'registry-red-01':'FAIL','registry-green-01':'PASS',
    'world-red-01':'FAIL','world-green-candidate-01':'PASS',
    'world-with-model-validation-01':'FAIL','world-with-model-validation-02':'PASS',
}
INPUTS={'30-development-inputs-01':('FAIL',5,4),'30-development-inputs-02':('PASS',36,36)}
RECORDS=('attempt.json','terminal.json','stdout.raw','stderr.raw')


def digest(raw):
    return sha256(raw).hexdigest()


def package():
    require(not git('status','--porcelain'),'Start from the clean input author source')
    members={}
    outcomes={}
    for name,expected in STAGES.items():
        folder=WORK/f'30-{name}'
        start,terminal=(read(folder/file) for file in RECORDS[:2])
        require(terminal['status']==expected and terminal['source']==start['source'] and terminal['source_guard'],
                'Development test lifecycle differs')
        require(start['pins']==hashes(start['source'],start['pins']),'Test source pins differ')
        for stream in ('stdout','stderr'):
            require(digest((folder/f'{stream}.raw').read_bytes())==terminal[f'{stream}_sha256'],
                    'Native test stream differs')
        require(terminal['facility_calls']==terminal['selector_calls']==terminal['research_trials']==0,
                'Development scope differs')
        outcomes[name]=dict(source=start['source'],status=expected)
        for file in RECORDS:
            members[f'tests/{name}/{file}']=(folder/file).read_bytes()
    attempts={}
    template_paths=['configs/full-facility-comparison-development-v1.json',
        'configs/full-facility-mainline-reserve-v6.json','configs/materials/reference-r134a-saturation.json',
        'docs/mainline/30-comparison-protocol-v1.json','scripts/registered_comparison.py',
        'scripts/prepare_comparison_worlds.py',
        'evidence/mainline/engineering/26-candidate/reference/online-baseline-inspect.json',
        'evidence/mainline/engineering/23-interventions/reference/network-full.json']
    for name,(status,started,passed) in INPUTS.items():
        folder=WORK/name
        receipt=read(folder/'receipt.json')
        require((receipt['status'],receipt['attempted'],receipt['passed'])==(status,started,passed)
                and receipt['source_guard'] and receipt['facility_calls']==receipt['selector_calls']==receipt['registered_research_trials']==0,
                'Input preparation lifecycle differs')
        require(set(receipt['artifacts'])=={p.relative_to(folder).as_posix() for p in folder.rglob('*') if p.is_file()}-{'receipt.json'},
                'Input preparation artifact declaration differs')
        script=f"30-prepare-development-inputs-{name[-2:]}.py"
        raw=(WORK/script).read_bytes()
        require(digest(raw)==receipt['authoring_tool_sha256'],'Input preflight tool differs')
        members['tools/'+script]=raw
        for file,sha in receipt['artifacts'].items():
            raw=(folder/file).read_bytes()
            require(digest(raw)==sha,'Prepared input bytes differ')
            members[f'input-preparation/{name}/{file}']=raw
        members[f'input-preparation/{name}/receipt.json']=(folder/'receipt.json').read_bytes()
        source=receipt['source']
        runtime={n for n in git('ls-tree','-rz','--name-only',source,'src/aegis_dc').decode().split('\0') if n.endswith('.py')}
        source_paths=runtime|set(template_paths)|{'src/patrol_rsi/__init__.py','src/patrol_rsi/contracts.py'}
        attempts[name]=dict(source=source,status=status,started=started,passed=passed,
            committed_source_identity=hashes(source,source_paths))
    members['tools/30-record-static-test.py']=(WORK/'30-record-static-test.py').read_bytes()
    members['tools/30-seal-preparation-01.py']=Path(__file__).read_bytes()
    PACKAGE.mkdir()
    archive=PACKAGE/'preparation-originals.zip'
    with ZipFile(archive,'x',compression=ZIP_DEFLATED,compresslevel=6) as out:
        for name,raw in sorted(members.items()):
            out.writestr(name,raw)
    write(PACKAGE/'manifest.json',dict(status='INPUT_ONLY_PREPARATION_PASS_WITH_ORIGINAL_REFUSALS',
        scope='Static declaration validation and input preparation. Zero facility runs, selector calls and registered trials.',
        tests=outcomes,input_preparation=attempts,archive_sha256=digest(archive.read_bytes()),
        members={name:digest(raw) for name,raw in sorted(members.items())}))
    verify()


def verify():
    archive=PACKAGE/'preparation-originals.zip'
    manifest=read(PACKAGE/'manifest.json')
    require(manifest['archive_sha256']==digest(archive.read_bytes()),'Preparation archive identity differs')
    with ZipFile(archive) as source:
        names=source.namelist()
        require(len(names)==len(set(names)) and set(names)==set(manifest['members']),'Preparation members differ')
        for name in names:
            p=Path(name)
            require(not p.is_absolute() and '..' not in p.parts and '__pycache__' not in p.parts
                    and p.suffix not in ('.pyc','.pyo') and digest(source.read(name))==manifest['members'][name],
                    'Original bytes or role differ')
    print(json.dumps(dict(status='PASS',durable_members=len(names),input_only_compiled=36,
        earlier_attempts=5,earlier_passed=4,registered_research_trials=0)))


if __name__=='__main__':
    package() if len(sys.argv)>1 and sys.argv[1]=='package' else verify()
