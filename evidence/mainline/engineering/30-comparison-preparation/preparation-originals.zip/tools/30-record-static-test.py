from datetime import datetime, timezone
from hashlib import sha256
import json
import os
from pathlib import Path
import subprocess
import sys

root = Path.cwd()
def git(*args):
    return subprocess.check_output(['git',*args], cwd=root)
def sha(data):
    return sha256(data).hexdigest()
def write(path, value):
    with path.open('x',encoding='utf-8',newline='\n') as stream:
        json.dump(value,stream,indent=2,allow_nan=False)
        stream.write('\n')

stage,source = sys.argv[1:]
assert git('rev-parse','HEAD').decode().strip() == source and not git('status','--porcelain')
folder = root/'.work'/f'30-{stage}'
folder.mkdir()
declared = [
    'tests/test_registered_comparison.py',
    'evidence/mainline/engineering/26-candidate/reference/online-baseline-inspect.json',
    'evidence/mainline/engineering/26-candidate/reference/online-candidate-inspect.json',
]
for p in ('scripts/registered_comparison.py','docs/mainline/30-comparison-protocol-v1.json'):
    if (root/p).exists(): declared.append(p)
pins={name:sha((root/name).read_bytes()) for name in declared}
assert all(sha(git('cat-file','blob',source+':'+name)) == value for name,value in pins.items())
args=[sys.executable,'-B','-X','utf8','-m','unittest','discover','-s','tests','-p','test_registered_comparison.py','-v']
env=dict(os.environ,PYTHONPATH=str(root/'src'),PYTHONDONTWRITEBYTECODE='1',PYTHONPYCACHEPREFIX=str(folder/'unused-cache'),PYTHONHASHSEED='0')
write(folder/'attempt.json',dict(status='STARTED',source=source,argv=args,pins=pins,recorder_sha256=sha(Path(__file__).read_bytes()),
    time_utc=datetime.now(timezone.utc).isoformat(),scope='STATIC_PREREGISTRATION_CLI',facility_calls=0,selector_calls=0,research_trials=0))
completed=subprocess.run(args,cwd=root,env=env,capture_output=True,check=False)
(folder/'stdout.raw').write_bytes(completed.stdout)
(folder/'stderr.raw').write_bytes(completed.stderr)
intact=git('rev-parse','HEAD').decode().strip()==source and not git('status','--porcelain') and all(
    sha((root/name).read_bytes())==value for name,value in pins.items())
write(folder/'terminal.json',dict(status='PASS' if completed.returncode==0 and intact else 'FAIL',source=source,
    returncode=completed.returncode,source_guard=intact,stdout_sha256=sha(completed.stdout),stderr_sha256=sha(completed.stderr),
    facility_calls=0,selector_calls=0,research_trials=0))
print((completed.stdout+completed.stderr).decode('utf-8'))
raise SystemExit(completed.returncode if intact else 7)
