"""Independent fixed-object Standards inspection; never imports project modules."""
import ast
from copy import deepcopy
from fractions import Fraction
from hashlib import sha256
import json
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parent
FIXED = ROOT / 'fixed-source'
REPO = Path(r'C:\Users\Donson\.codex\worktrees\mainline28-negative-controls\Renly')
BASE = '0a613289d983711d7637fb99857ee0333b0a1c53'
SOURCE = '105a1cf53e72abccb047e2f1a5a1cf141d8980ae'
checks = []

def check(label, condition, detail=None):
    row = {'id': len(checks) + 1, 'label': label, 'passed': bool(condition)}
    if detail is not None:
        row['detail'] = detail
    checks.append(row)
    if not condition:
        raise AssertionError(label)

def git(*args):
    result = subprocess.run(['git', '-C', str(REPO), *args], check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    return result.stdout

def reject_duplicates(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError('Duplicate JSON key: ' + key)
        result[key] = value
    return result

def load(relative):
    return json.loads((FIXED / relative).read_bytes(), object_pairs_hook=reject_duplicates,
                      parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)))

def file_hash(path):
    return sha256(path.read_bytes()).hexdigest()

def frac(value):
    return Fraction(value['numerator'], value['denominator'])

def function(tree, name):
    return next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == name)

def calls(tree, name):
    return [node for node in ast.walk(tree) if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id == name]

scope = json.loads((ROOT / 'scope.json').read_bytes())
check('source resolves exactly', git('rev-parse', SOURCE + '^{commit}').decode().strip() == SOURCE)
check('base resolves exactly', git('rev-parse', BASE + '^{commit}').decode().strip() == BASE)
check('three-dot merge base is exact base', git('merge-base', BASE, SOURCE).decode().strip() == BASE)
changed = git('diff', '--name-only', BASE + '...' + SOURCE).decode().splitlines()
check('review diff nonempty', bool(changed))
check('no runtime kernel or test changes', not any(p.startswith(('src/', 'tests/')) for p in changed))
check('four committed source steps', len(git('rev-list', BASE + '..' + SOURCE).decode().splitlines()) == 4)
check('initial worktree clean', (ROOT / 'worktree-state.txt').read_bytes() == b'')
all_paths = git('ls-tree', '-r', '--name-only', SOURCE).decode().splitlines()
check('all nested AGENTS located', [p for p in all_paths if Path(p).name == 'AGENTS.md'] == ['AGENTS.md'])
check('no CONTRIBUTING or CODING_STANDARDS source omitted', not [p for p in all_paths if Path(p).name.lower() in {'contributing.md', 'coding_standards.md'}])
for relative in scope['exported_paths']:
    check('fixed Git export ' + relative, (FIXED / relative).read_bytes() == git('show', SOURCE + ':' + relative))
check('all changed paths exported', set(changed) <= set(scope['exported_paths']))
parsed = {}
for path in sorted(FIXED.rglob('*.py')):
    relative = path.relative_to(FIXED).as_posix()
    parsed[relative] = ast.parse(path.read_bytes(), filename=relative)
    check('AST parse ' + relative, True)
for path in sorted(FIXED.rglob('*.json')):
    load(path.relative_to(FIXED).as_posix())
    check('strict JSON parse ' + path.relative_to(FIXED).as_posix(), True)

protocol = load('docs/mainline/28-negative-engineering-protocol-v1.json')
doc = load(protocol['input'])
cases = doc['cases']
literals = load(protocol['literals'])
reference = load('evidence/mainline/engineering/27-full-loop/reference/online-loop-v2.json')
check('four fixed ordered cases', list(cases) == protocol['cases'] == ['normal', 'false_report', 'local_protection', 'too_late'])
check('engineering classification', doc['classification'] == 'FINITE_FULL_FACILITY_NEGATIVE_ENGINEERING_NOT_EFFECT_COMPARISON' and protocol['research_trials'] == 0)
check('protocol requires independent fixed review', protocol['status'] == 'FROZEN_ENGINEERING_REQUIRES_INDEPENDENT_FIXED_SOURCE_REVIEW')
check('physical integration budget', protocol['total_integrations'] == 4 and protocol['expected_counters']['attempted_integrations'] == protocol['expected_counters']['completed_integrations'] == 4)
check('simulated budget exact rational', sum(Fraction(str(c['duration_s'])) for c in cases.values()) == Fraction(43, 2) == frac(literals['total_simulated_duration_s']) and protocol['total_simulated_duration_s'] == 21.5)
check('online decisions budget', protocol['online_decisions_s'] == [1, 3, 4.5, 4.75, 5.5, 6.5, 7] and literals['public_online_decisions'] == 14)
check('additional frame budgets', protocol['expected_counters']['late_preparation_frames'] == 4 and protocol['expected_counters']['late_preparation_assessments'] == 1 and protocol['expected_counters']['late_closure_assessments'] == 2 and protocol['expected_counters']['protection_initial_frames'] == 1)
expected_domains = {'power', 'backup', 'facility_cooling', 'equipment_environment', 'it_service', 'control_monitoring', 'space_access', 'people_tools_work'}
expected_graphs = {'physical', 'functional', 'control_information', 'access'}
for name, case in cases.items():
    model = case['model']
    entities = {e['id']: e for e in model['entities']}
    params = {p['id']: p for p in model['parameters']}
    check(name + ' unique entity IDs', len(entities) == len(model['entities']))
    check(name + ' unique parameter IDs', len(params) == len(model['parameters']))
    check(name + ' facility identity', model['id'] == doc['facility_id'] == reference['model']['id'])
    check(name + ' eight operational domains', {d['id'] for d in model['domains']} == expected_domains)
    check(name + ' four relations unchanged', set(model['graphs']) == expected_graphs and model['graphs'] == reference['model']['graphs'])
    check(name + ' entity identities retained', set(entities) == {e['id'] for e in reference['model']['entities']})
    check(name + ' domain members have shared identities', all(set(d['entity_ids']) <= set(entities) for d in model['domains']))
    check(name + ' graph endpoints have shared identities', all(edge['from'] in entities and edge['to'] in entities for edges in model['graphs'].values() for edge in edges))
    check(name + ' source/assumption boundary retained', bool(model['site_gaps']) and bool(model['assumptions']) and bool(model['sources']))
    check(name + ' entity provenance explicit', all(e.get('basis') and e.get('source_note') and e.get('source_refs') for e in model['entities']))
    check(name + ' all parameter SI/provenance/ranges explicit', all(p.get('unit') and p.get('quantity') and p.get('basis') and p.get('source_note') and p.get('source_refs') and p['valid_range'][0] <= p['value'] <= p['valid_range'][1] for p in model['parameters']))
    check(name + ' maximum step fixed', case['maximum_step_s'] == protocol['maximum_step_s'] == .01)
    check(name + ' property table pin', file_hash(FIXED / model['runtime']['property_table']) == model['runtime']['property_sha256'])
    check(name + ' existing protection profile retained', model['runtime']['local_control_profile'] == reference['model']['runtime']['local_control_profile'])

normal = deepcopy(cases['normal']['replay_inputs'])
false = deepcopy(cases['false_report']['replay_inputs'])
normal_records = normal['dispatch_program']['evidence_ledger'].pop('records')
false_records = false['dispatch_program']['evidence_ledger'].pop('records')
check('normal false physical inputs identical', cases['normal']['model'] == cases['false_report']['model'])
check('normal false all public rules identical except records', normal == false and normal_records == [] and len(false_records) == 2)
check('manual report and review delayed', [(r['observed_at_s'], r['arrived_at_s']) for r in false_records] == [(1.5, 3), (6.75, 7)])
check('manual records share original provenance once', len({r['provenance']['origin_id'] for r in false_records}) == 2 and all(r['provenance']['copied_from_record_id'] is None for r in false_records))
for name in ('normal', 'false_report'):
    program = cases[name]['replay_inputs']['dispatch_program']
    policy = program['policy_program']
    closure = program['closure_program']
    rule, = closure['profile']['rules']
    check(name + ' public model consistent full demand table', policy['options']['catalog'] == closure['risk_catalog'] and closure['risk_catalog']['demand'] == [{'start_s': 0, 'end_s': 6, 'rate': .5}])
    check(name + ' exact intervention declaration equality', policy['intervention_declaration'] == program['intervention_program'] == closure['intervention_declaration'])
    check(name + ' exact public observation profile equality', policy['evidence_projection']['inspection_profile'] == program['inspection_program']['profile'] and policy['evidence_projection']['background_sensor_profile'] == program['sensor_program']['profile'])
    check(name + ' closure demands two actual roles', {r['role'] for r in rule['checks']} == {'condition', 'service'} and rule['required_samples'] == 2 and rule['minimum_span_s'] == 1)
    grant, = closure['profile']['authorizations']
    channel, = closure['profile']['review_channels']
    review, = closure['profile']['false_alarm_reviews']
    check(name + ' scoped false alarm authority', grant['dispositions'] == ['FALSE_ALARM'] and channel['authorization_id'] == grant['id'] and channel['source_id'] == grant['source_id'] and channel['question_id'] in grant['question_ids'])
    check(name + ' four-sample review dossier fixed', review['supporting_record_ids'] == ['flow-transfer:0', 'flow-transfer:1', 'joint-service-transfer:0', 'joint-service-transfer:1'])
    check(name + ' prior external instructions only', program['evidence_ledger']['records'] == ([] if name == 'normal' else false_records))
    check(name + ' public nominal knowledge omits actual parameters', 'parameters' not in program['nominal_knowledge'] and 'boundary_events' not in program['nominal_knowledge'])
    check(name + ' separate physical event input empty', cases[name]['replay_inputs']['exogenous_events'] == cases[name]['replay_inputs']['action_commands'] == cases[name]['replay_inputs']['work_requests'] == [])

prior = Fraction(1, 100)
reported = prior * Fraction(3, 4) / (prior * Fraction(3, 4) + (1-prior)*Fraction(3, 100))
cleared = reported * Fraction(1, 5) / (reported * Fraction(1, 5) + (1-reported)*Fraction(9, 10))
check('independent Bayesian report literal', reported == frac(literals['false_report']['cooling_probability_after_report']) == Fraction(25, 124))
check('independent negative measurement literal', cleared == frac(literals['false_report']['cooling_probability_after_negative_handheld']) == Fraction(50, 941))
expected_literals = {
    'normal': [Fraction(29,8), Fraction(29,8), 0, 0, 0, 0],
    'false_report': [Fraction(29,8), Fraction(29,8), 0, 0, 1, Fraction(1,4)],
    'local_protection': [Fraction(9,4), Fraction(3,2), 1, 0, 0, 0],
    'too_late': [4, 1, 3, 1, Fraction(3,4), Fraction(1,4)],
}
metric_order = ['demand_service_unit_s','delivered_service_unit_s','normalized_deficit_s','travel_person_s','work_person_s','access_check_person_s']
for name, expected in expected_literals.items():
    for metric, value in zip(metric_order, expected):
        check(name + ' independent literal ' + metric, frac(literals[name][metric]) == value)

late = cases['too_late']
plan = late['public_preparation']
check('late evidence release times', plan['decision_times_s'] == [0, 1, 3.25, 4] and late['closure_assessment_times_s'] == [3.25, 4])
check('late private safety boundary isolated', late['boundary_events'][0]['time_s'] == 3 and late['boundary_events'][0]['parameter_id'] == 'it_access_permit' and 'boundary_events' not in plan and 'parameters' not in plan['nominal_knowledge'])
check('late current report only; no real sample invented', len(plan['evidence_ledger']['records']) == 1 and plan['evidence_ledger']['records'][0]['arrived_at_s'] == plan['issued_at_s'] == 1)
check('late actual/nominal worker and tool colocated', all(e['location_id'] == 'loc_control' for e in late['model']['entities'] if e['id'] in {'worker_it','tool_it_diagnostic'}) and all(e['nominal_location_id'] == 'loc_control' for e in plan['nominal_knowledge']['entities'] if e['id'] in {'worker_it','tool_it_diagnostic'}))
check('late action and closure share authority', late['closure_program']['intervention_declaration'] == late['intervention_program'])
check('late hypothetical clocks count partial work', frac(literals['too_late']['theoretical_earliest_completion_s']) == Fraction(13,4) and frac(literals['too_late']['work_person_s']) == 3-Fraction(9,4) and frac(literals['too_late']['terminal_feedback_arrives_s']) == Fraction(7,2))
idle = load(protocol['protection_workforce_input'])
check('idle workforce real empty declaration', idle['submissions'] == [] and idle['plan']['decision_times_s'] == [0] and idle['plan']['requests'] == [] and idle['evidence_ledger']['records'] == [])

for relative, author in [(protocol['preparation'],'scripts/prepare_negative_control_inputs_v2.py'), (protocol['protection_workforce_preparation'],'scripts/prepare_negative_control_workforce.py')]:
    prep = load(relative)
    check(relative + ' not executed classification', prep['status'] == 'PREPARED_NOT_EXECUTED' and prep['new_project_calls'] == 0)
    check(relative + ' authoring tool pin equality', prep['authoring_tool_sha256'] == file_hash(FIXED/author))
    for path, identity in prep['source_inputs'].items():
        check(relative + ' source pin ' + path, file_hash(FIXED/path) == identity)
    for path, identity in prep.get('outputs', prep.get('artifacts', {})).items():
        check(relative + ' output pin ' + path, file_hash((FIXED/relative).parent/path) == identity)
observation = load(protocol['retained_unexecuted_draft'][-1])
for filename, identity in observation['original_files'].items():
    path = 'evidence/mainline/engineering/28-negative-controls/reference/' + filename
    check('retained draft exact original ' + filename, file_hash(FIXED/path) == identity and (FIXED/path).read_bytes() == git('show','e76884c2:'+path))
check('retained old demand-table failure not rewritten', observation['actual_closure_demand'] != observation['expected_demand'] and observation['status'] == 'UNEXECUTED_INPUT_DRAFT_RETAINED')

capture_tree = parsed['scripts/negative_control_delivery.py']
checks_tree = parsed['scripts/negative_control_checks.py']
helper_tree = parsed['scripts/inspection_delivery.py']
verify = function(capture_tree, 'verify')
reviews = function(capture_tree, 'reviews')
execute = function(capture_tree, 'execute')
capture = function(capture_tree, 'capture')
check('capture single static simulate call site', len(calls(execute,'simulate_scenario')) == 1)
check('capture one fixed case loop', len([n for n in ast.walk(capture) if isinstance(n,ast.For) and ast.unparse(n.iter) == "protocol['cases']"]) == 1)
check('capture review gate before attempt directory', next(n.lineno for n in calls(capture,'reviews')) < next(n.lineno for n in ast.walk(capture) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='mkdir'))
review_text = ast.unparse(reviews)
check('independent axes and current-source gate present', "{'Spec', 'Standards'}" in review_text and "report.get('source', report.get('data')) == source" in review_text and "report['checks'] > 0" in review_text and "not report.get('unresolved')" in review_text)
check('review gate seals verdict and every declared member', "file.name in names" in review_text and "len(raw) == expected['bytes']" in review_text and "digest(raw) == expected['sha256']" in review_text)
check('saved-only verify has no application import', not [n for n in ast.walk(verify) if isinstance(n,(ast.Import,ast.ImportFrom))])
check('saved checks have no application import', not [n for n in ast.walk(checks_tree) if isinstance(n,ast.ImportFrom) and (n.module or '').startswith('aegis_dc')])
verify_text=ast.unparse(verify)
check('fresh committed delivery matches exact source pins', "pins(protocol, source) == receipt['pins']" in verify_text and 'group == hashes(delivery, group)' in verify_text and 'hashes(delivery, paths)' in verify_text)
check('durable declarations compared exactly', "set(receipt['artifacts']) == names" in verify_text and "durable(folder) == names | {'receipt.json'}" in verify_text)
check('source cache exclusions exact declared classes', protocol['excluded_runtime_caches'] == ['__pycache__','*.pyc','*.pyo'] and "p.suffix not in {'.pyc', '.pyo'}" in ast.unparse(function(helper_tree,'durable')))
check('no arbitrary artifact hash waiver', "for name, sha in receipt['artifacts'].items()" in verify_text and "digest((folder / name).read_bytes()) == sha" in verify_text)
check('attempt STARTED precedes execute and failure is preserved', next(n.lineno for n in ast.walk(capture) if isinstance(n,ast.Constant) and n.value=='STARTED') < next(n.lineno for n in calls(capture,'execute')) and any(isinstance(n,ast.Constant) and n.value=='FAILED' for n in ast.walk(capture)))
check('completion distinct from validation counters', "counters['completed_integrations'] += 1" in ast.unparse(execute) and "counters['validated_cases'] += 1" in ast.unparse(capture))
check('packet failures terminal FAIL, not review PASS', "status='FAIL'" in ast.unparse(capture) and "receipt['status'] == 'PASS'" in ast.unparse(capture) and 'finally:' in ast.unparse(capture))

# AST-only schema witness. No project function is imported, compiled, or executed.
intervention_tree=parsed['src/aegis_dc/intervention_execution.py']
audit_assignment=next(n for n in ast.walk(intervention_tree) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='audit' for t in n.targets) and isinstance(n.value,ast.Call) and isinstance(n.value.func,ast.Name) and n.value.func.id=='dict')
audit_keys={kw.arg for kw in audit_assignment.value.keywords}
conditional_effect=next(n for n in ast.walk(intervention_tree) if isinstance(n,ast.If) and ast.unparse(n.test)=='reason is None' and any(isinstance(child,ast.Call) and isinstance(child.func,ast.Attribute) and ast.unparse(child.func)=='audit.update' for child in ast.walk(n)))
update=next(n for n in ast.walk(conditional_effect) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and ast.unparse(n.func)=='audit.update')
late_check=function(checks_tree,'too_late')
missing_access=next(n for n in ast.walk(late_check) if isinstance(n,ast.Subscript) and isinstance(n.value,ast.Name) and n.value.id=='effect' and isinstance(n.slice,ast.Constant) and n.slice.value=='applied_at_s')
check('blocker reproduced by AST: failed audit lacks applied_at_s', 'applied_at_s' not in audit_keys)
check('blocker reproduced by AST: timestamp added only for successful effect', 'applied_at_s' in {kw.arg for kw in update.keywords} and ast.unparse(conditional_effect.test)=='reason is None')
check('blocker reproduced by AST: failed audit timestamp is indexed', missing_access.lineno==202)
private_audit=next(n for n in ast.walk(intervention_tree) if isinstance(n,ast.FunctionDef) and n.name=='private_audit')
check('private audit performs no failure-event shape normalization', 'events=deepcopy(self.events)' in ast.unparse(private_audit))

finding={
    'id':'STD-28-01','priority':'P1','kind':'documented_standard',
    'file':'scripts/negative_control_checks.py','line':202,
    'title':'Validate the actual NO_EFFECT audit shape',
    'standard':{'file':'AGENTS.md','line':31,'rule':'Shared implementation/testing boundaries are public interfaces; use independently specified behavior outcomes.'},
    'evidence':{'runtime_file':'src/aegis_dc/intervention_execution.py','audit_assignment_line':audit_assignment.lineno,'success_only_update_line':update.lineno,'private_audit_line':private_audit.lineno,'failure_audit_keys':sorted(audit_keys)},
    'explanation':'For the declared safety-aborted task, the runtime audit has outcome NO_EFFECT and does not contain applied_at_s. That key is added only when a physical effect is applied. The saved checker indexes the absent key, so the intended fourth-case validation necessarily raises KeyError instead of accepting the preserved abort. The unchanged private_audit and save_run paths do not add the field.',
    'required_change':'Check absence of applied_at_s for NO_EFFECT (or use an explicit absence-aware check) without changing the runtime audit schema, protocol criteria, failure record, or immutable old inputs.'
}
result={
    'status':'PASS_STATIC_INSPECTION_WITH_CONFIRMED_REVIEW_BLOCKER','axis':'Standards','source':SOURCE,'base':BASE,
    'checks':len(checks),'checks_passed':len(checks),'checks_failed':0,
    'application_imports':0,'physical_calls':0,'selector_calls':0,'closure_calls':0,'test_calls':0,'full_calls':0,'repository_authoring_or_verification_script_calls':0,
    'checks_detail':checks,'findings':[finding],
    'heuristics':{'baseline':'Fowler fixed baseline supplied by root','actionable_findings':[], 'suppressed':[{'smell':'Duplicated Code','reason':'The retained original and corrected immutable input-authoring versions are explicitly required by AGENTS.md preservation rules.'}]},
    'limits':['AST/JSON/Fraction/Git inspection only. Does not validate numeric thermal trajectories or authorize completion of ticket28/M4.','Exploratory path/schema probes were corrected before the independent static checker; none ran project code.']
}
(ROOT/'static-checks.json').write_text(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in result.items() if k not in {'checks_detail','findings','heuristics'}},ensure_ascii=False))
