import subprocess
from pathlib import Path
import json
ROOT=Path(__file__).resolve().parent
REPO=Path(r'C:\Users\Donson\.codex\worktrees\mainline28-negative-controls\Renly')
SOURCE='105a1cf53e72abccb047e2f1a5a1cf141d8980ae'
def git(*args):
    return subprocess.run(['git','-C',str(REPO),*args],check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE).stdout
scope=json.loads((ROOT/'scope.json').read_bytes())
paths=git('ls-tree','-r','--name-only',SOURCE).decode().splitlines()
selected={p for p in paths if p.startswith('src/') and p.endswith('.py')}
selected.add('scripts/inspection_delivery.py')
for prep in ('evidence/mainline/engineering/28-negative-controls/reference-v2/preparation.json','evidence/mainline/engineering/28-negative-controls/reference-workforce/preparation.json'):
    selected.update(json.loads((ROOT/'fixed-source'/prep).read_bytes())['source_inputs'])
cases=json.loads((ROOT/'fixed-source'/'evidence/mainline/engineering/28-negative-controls/reference-v2/cases-v1.json').read_bytes())['cases']
selected.update(c['model']['runtime']['property_table'] for c in cases.values())
selected -= set(scope['exported_paths'])
for path in sorted(selected):
    out=ROOT/'fixed-source'/path
    out.parent.mkdir(parents=True,exist_ok=True)
    out.write_bytes(git('show',SOURCE+':'+path))
scope['exported_paths']=sorted(set(scope['exported_paths'])|selected)
(ROOT/'scope.json').write_text(json.dumps(scope,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'additional_exports':len(selected),'total_exports':len(scope['exported_paths'])}))
