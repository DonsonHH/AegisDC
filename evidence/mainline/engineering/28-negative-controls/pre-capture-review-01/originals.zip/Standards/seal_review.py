"""Seal the review verdict and all durable files; exact manifest, no waivers."""
from hashlib import sha256
import json
from pathlib import Path
import subprocess

ROOT=Path(__file__).resolve().parent
REPO=Path(r'C:\Users\Donson\.codex\worktrees\mainline28-negative-controls\Renly')
SOURCE='105a1cf53e72abccb047e2f1a5a1cf141d8980ae'
BASE='0a613289d983711d7637fb99857ee0333b0a1c53'

def write(name, value):
    path=ROOT/name
    if isinstance(value,str):
        path.write_text(value,encoding='utf-8',newline='\n')
    else:
        path.write_text(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8',newline='\n')

static=json.loads((ROOT/'static-checks.json').read_bytes())
assert static['checks']==static['checks_passed']==346 and static['checks_failed']==0
assert static['source']==SOURCE and len(static['findings'])==1
finding=static['findings'][0]
write('tooling-observations.json',{
    'formal_static_review':{'command':'python static_review.py','exit_code':0,'checks':346,'failed_checks':0},
    'exploratory_probes':[
        {'kind':'file-location lookup','observation':'dispatch_policies.py and online_dispatch.py were not present. Recovered using the actual dispatch_policy.py and policy_execution.py paths.','effect':'No application import, runtime execution, source change, or acceptance check was performed by these path probes.'},
        {'kind':'JSON summary probe','observation':'Two exploratory summaries assumed graph lists had nested edges; TypeError exposed that graphs are a dictionary of edge lists. The summary was corrected before formal independent checks.','effect':'No project code ran; the formal static checker parsed and independently checked all four graph lists.'}
    ],
    'review_integrity':'The formal checker completed successfully. This FAIL verdict preserves the confirmed runtime/checker interface mismatch; no execution error is represented as a passing application check.'
})
write('review.json',{
    'schema':'aegisdc-independent-fixed-source-review-v1','axis':'Standards',
    'source':SOURCE,'base':BASE,'status':'FAIL_SOURCE_INTERFACE_MISMATCH',
    'checks':static['checks'],'unresolved':[finding],
    'hard_findings':1,'heuristic_findings':0,
    'standards_sources':['AGENTS.md','GLOSSARY.md','docs/MAINLINE.md','docs/mainline/progress.json','docs/agents/domain.md','docs/agents/issue-tracker.md','docs/agents/triage-labels.md','docs/adr/0003-complete-facility-mainline.md','.scratch/full-facility-mainline/spec.md','docs/mainline/28-negative-controls-contract.md','docs/mainline/28-negative-engineering-protocol-v1.json','.scratch/full-facility-mainline/issues/28-negative-controls.md'],
    'method':'Independent Git-object/AST/strict-JSON/Fraction/filesystem inspection only. No project authoring or verification script was invoked; no application import, selector, physical, closure, test, or full call.',
    'result_scope':'Fixed source does not qualify for the capture review gate. This is a preparation/tooling review only, not runtime or ticket/M4 acceptance.',
    'evidence':'static-checks.json','manifest':'delivery-manifest.json'
})
write('README.md',f'''# Independent Standards review

Verdict: **FAIL_SOURCE_INTERFACE_MISMATCH** for `{SOURCE}`, compared with `{BASE}` using the three-dot diff. The 346 independent static checks completed successfully. No application, selector, plant, closure, test, or full call occurred, and no repository file was changed.

One hard documented-standard finding remains: **P1 STD-28-01**, `scripts/negative_control_checks.py:202`. AGENTS.md:31 requires behavior checks at the declared interfaces. The expected NO_EFFECT audit has no `applied_at_s`: the unchanged runtime only adds that key in the successful-effect branch (`src/aegis_dc/intervention_execution.py:155-161`). `private_audit()` copies events without normalization. The fourth case therefore necessarily raises KeyError during saved validation. Check the failed event's actual absence of write fields without changing the runtime or declared outcome.

The remaining inspected gates are consistent: exact fixed exports, eight domains/four relations/shared identities, SI and source annotations, delayed evidence and scoped authority, independent analytic literals, declared call/frame budgets, idle-crew cost accounting, retained original draft plus separate correction, sealed dual-axis review gate, durable roles versus explicit runtime caches, exact fresh Git/tool/input equality, and terminal failure retention.

Fowler baseline heuristics: no actionable finding. The immutable old/new authoring copies are required preservation, so they are exempt from the duplication heuristic.

This failed review does not authorize capture or imply numerical or scientific acceptance. `review.json` is the machine verdict. `delivery-manifest.json` seals every other durable file in this directory, including all exact fixed-source exports and the review tools. Exploratory probe corrections are recorded in `tooling-observations.json`.
''')
scope=json.loads((ROOT/'scope.json').read_bytes())
for path in scope['exported_paths']:
    raw=subprocess.run(['git','-C',str(REPO),'show',SOURCE+':'+path],check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE).stdout
    assert (ROOT/'fixed-source'/path).read_bytes()==raw,path
manifest_path=ROOT/'delivery-manifest.json'
assert not manifest_path.exists(),'Refusing to replace an existing review seal'
files=sorted(path for path in ROOT.rglob('*') if path.is_file())
assert not any('__pycache__' in path.parts or path.suffix in {'.pyc','.pyo'} for path in files),'Unexpected runtime cache in review delivery'
artifacts={path.relative_to(ROOT).as_posix():{'sha256':sha256(path.read_bytes()).hexdigest(),'bytes':path.stat().st_size} for path in files}
write('delivery-manifest.json',{'schema':'aegisdc-independent-review-delivery-v1','axis':'Standards','source':SOURCE,'artifacts':artifacts})
actual={p.relative_to(ROOT).as_posix() for p in ROOT.rglob('*') if p.is_file()}
assert actual==set(artifacts)|{'delivery-manifest.json'},'Unsealed extra or missing file'
for name,pin in artifacts.items():
    raw=(ROOT/name).read_bytes()
    assert sha256(raw).hexdigest()==pin['sha256'] and len(raw)==pin['bytes'],name
assert 'review.json' in artifacts and all('fixed-source/'+p in artifacts for p in scope['exported_paths'])
print(json.dumps({'status':'SEALED_FAIL','axis':'Standards','source':SOURCE,'checks':346,'unresolved':1,'sealed_artifacts':len(artifacts),'manifest_sha256':sha256(manifest_path.read_bytes()).hexdigest(),'root':str(ROOT)}))
