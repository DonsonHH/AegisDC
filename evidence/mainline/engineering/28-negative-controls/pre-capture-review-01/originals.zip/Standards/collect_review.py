import subprocess
from pathlib import Path
import json

REPO = Path(r'C:\Users\Donson\.codex\worktrees\mainline28-negative-controls\Renly')
ROOT = Path(__file__).resolve().parent
BASE = '0a613289d983711d7637fb99857ee0333b0a1c53'
SOURCE = '105a1cf53e72abccb047e2f1a5a1cf141d8980ae'

def git(*args):
    result = subprocess.run(['git', '-C', str(REPO), *args], check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    return result.stdout

def write(relative, data):
    target = ROOT / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)

assert git('rev-parse', BASE + '^{commit}').decode().strip() == BASE
assert git('rev-parse', SOURCE + '^{commit}').decode().strip() == SOURCE
assert git('merge-base', BASE, SOURCE).decode().strip() == BASE
changed = git('diff', '--name-only', BASE + '...' + SOURCE).decode().splitlines()
all_paths = git('ls-tree', '-r', '--name-only', SOURCE).decode().splitlines()
required = [
    'AGENTS.md', 'GLOSSARY.md', 'docs/MAINLINE.md', 'docs/mainline/progress.json',
    'docs/agents/domain.md', 'docs/agents/issue-tracker.md', 'docs/agents/triage-labels.md',
    'docs/adr/0003-complete-facility-mainline.md', '.scratch/full-facility-mainline/spec.md',
]
required += [p for p in all_paths if Path(p).name.lower() in {'contributing.md', 'coding_standards.md'}]
exports = sorted(set(changed + required))
for relative in exports:
    write('fixed-source/' + relative, git('show', SOURCE + ':' + relative))
write('diff.patch', git('diff', '--binary', BASE + '...' + SOURCE))
write('commits.txt', git('log', '--format=fuller', BASE + '..' + SOURCE))
write('source-tree.txt', git('ls-tree', '-r', '--full-tree', SOURCE))
write('worktree-state.txt', git('status', '--porcelain=v1'))
write('worktrees.txt', git('worktree', 'list', '--porcelain'))
write('scope.json', (json.dumps({
    'axis': 'Standards', 'base': BASE, 'source': SOURCE, 'merge_base': BASE,
    'diff_command': 'git diff ' + BASE + '...' + SOURCE,
    'log_command': 'git log ' + BASE + '..' + SOURCE,
    'git_version': git('--version').decode().strip(), 'exported_paths': exports,
    'execution_boundary': 'Git, AST, JSON, Fraction, and filesystem inspection only; no repository scripts, application imports, selectors, plant, closures, tests, or full runs.'
}, indent=2) + '\n').encode())
print(json.dumps({'exported_paths': len(exports), 'source': SOURCE, 'root': str(ROOT)}))
