"""Independent fixed-source Spec review: files, Git, JSON, AST and Fraction only.
Never imports or executes the project, authoring scripts, simulator, selectors,
closure, application commands or tests. Source exports are read as data.
"""
import ast
from copy import deepcopy
from fractions import Fraction
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys

sys.stdout.reconfigure(encoding='utf-8')
ROOT = Path(__file__).resolve().parent
REPOSITORY = Path(r'C:\Users\Donson\.codex\worktrees\mainline28-negative-controls\Renly')
SOURCE = '105a1cf53e72abccb047e2f1a5a1cf141d8980ae'
BASE = '0a613289d983711d7637fb99857ee0333b0a1c53'
S = ROOT / 'sources'
records = []

def check(name, condition, detail):
    records.append(dict(name=name, status='PASS' if condition else 'FAIL', detail=detail))

def data(name):
    return json.loads((S / name).read_bytes())

def git(*args, input=None):
    return subprocess.run(['git', *args], cwd=REPOSITORY, input=input, capture_output=True, check=True).stdout

def fraction(value):
    return Fraction(str(value))

def literal(value):
    return Fraction(value['numerator'], value['denominator'])

index = json.loads((ROOT / 'source-index.json').read_bytes())
check('fixed_source_identity', index['source_commit'] == SOURCE and index['base_commit'] == BASE and git('rev-parse', SOURCE).decode().strip() == SOURCE, 'Full source and base SHA identities match.')
paths = sorted(index['artifacts'])
raw = git('cat-file', '--batch', input=''.join(SOURCE+':'+p+'\n' for p in paths).encode())
offset = 0
for name in paths:
    end = raw.index(b'\n', offset)
    header = raw[offset:end].split()
    start = end+1
    size = int(header[2])
    blob = raw[start:start+size]
    offset = start+size+1
    pin = index['artifacts'][name]
    check('exact_git_export:'+name, header[1] == b'blob' and blob == (S/name).read_bytes() and sha256(blob).hexdigest() == pin['sha256'] and len(blob) == pin['bytes'] and header[0].decode() == pin['git_blob'], 'Export matches the exact committed blob, SHA-256 and byte count.')
check('git_export_stream_complete', offset == len(raw), 'Every Git batch byte was classified.')
changed = git('diff','--name-only',BASE+'...'+SOURCE).decode().splitlines()
check('kernels_unchanged', not any(p.startswith('src/') for p in changed), 'The 19 changed paths contain no application or simulation kernel changes.')
check('changed_path_count', len(changed) == 19 and set(changed) <= set(paths), 'All changed paths are exported and reviewed.')
for name in paths:
    if name.endswith('.json'):
        data(name)
        check('json_parse:'+name, True, 'Strictly read as JSON; no source code imported.')
    elif name.endswith('.py'):
        ast.parse((S/name).read_bytes(), filename=name)
        check('ast_parse:'+name, True, 'Parsed as AST only; never executed.')
protocol = data('docs/mainline/28-negative-engineering-protocol-v1.json')
document = data(protocol['input'])
cases = document['cases']
oracle = data(protocol['literals'])
progress = data('docs/mainline/progress.json')
check('lifecycle_not_research_completion', progress['status'] == 'active' and progress['current_ticket'] == '28' and next(m for m in progress['milestones'] if m['id']=='M4')['status'] == 'in_progress' and progress['research_trials']['status'] == 'not_started' and progress['research_trials']['attempts'] == 0, 'M4 and the complete-facility objective remain incomplete; no registered effect trial.')
check('four_frozen_cases', list(cases) == protocol['cases'] == ['normal','false_report','local_protection','too_late'], 'Named normal, false report, local protection and too-late witnesses.')
check('fixed_physical_budget', sum(fraction(c['duration_s']) for c in cases.values()) == Fraction(43,2) == fraction(protocol['total_simulated_duration_s']) and protocol['total_integrations'] == 4 and all(c['maximum_step_s'] == .01 for c in cases.values()), 'Exactly 7.25+7.25+3+4 = 21.5 seconds, four integrations and .01 second maximum steps.')
normal = cases['normal']['replay_inputs']['dispatch_program']
false = cases['false_report']['replay_inputs']['dispatch_program']
for name, case in cases.items():
    model = case['model']
    check('full_scope:'+name, len(model['domains']) == 8 and set(model['graphs']) == {'physical','functional','control_information','access'} and model['id'] == document['facility_id'] and model['graphs'] == cases['normal']['model']['graphs'] and {e['id'] for e in model['entities']} == {e['id'] for e in cases['normal']['model']['entities']}, 'Same V6 facility, shared entity identities and all four relations.')
    check('declared_parameter_ranges:'+name, all(p['valid_range'][0] <= p['value'] <= p['valid_range'][1] and p['basis'] and p['source_note'] for p in model['parameters']), 'Each numerical parameter retains its declared range and provenance; coupled thermodynamics remain a runtime gate.')
a,b = deepcopy(normal), deepcopy(false)
ar,br = a['evidence_ledger'].pop('records'), b['evidence_ledger'].pop('records')
check('normal_false_identical_rules', a == b and cases['normal']['model'] == cases['false_report']['model'] and ar == [] and len(br) == 2, 'Only the delayed false report and declared reviewer record differ.')
for name,program in [('normal',normal),('false_report',false)]:
    policy=program['policy_program']
    check('public_model_consistency:'+name, policy['options']['catalog'] == program['closure_program']['risk_catalog'] and policy['options']['catalog']['demand'] == [{'start_s':0,'end_s':6,'rate':.5}] and policy['evidence_projection']['inspection_profile'] == program['inspection_program']['profile'] and policy['evidence_projection']['background_sensor_profile'] == program['sensor_program']['profile'] and policy['intervention_declaration'] == program['intervention_program'] == program['closure_program']['intervention_declaration'], 'Forecast, actual declaration and closure share public assumptions; no recorded outcome is copied into the forecast.')
    check('online_budget:'+name, program['decision_times_s'] == protocol['online_decisions_s'] == [1,3,4.5,4.75,5.5,6.5,7], 'Seven declared decisions; no pre-report task or extra selector call is authorized.')
check('report_arrival_order', [(r['observed_at_s'],r['arrived_at_s']) for r in br] == [(1.5,3),(6.75,7)], 'Suspicion arrives at 3; declared review is observed at 6.75 and arrives at 7.')
profile=false['closure_program']['profile']
rule=profile['rules'][0]
support=profile['false_alarm_reviews'][0]['supporting_record_ids']
check('four_genuine_review_records', set(support) == {'flow-transfer:0','flow-transfer:1','joint-service-transfer:0','joint-service-transfer:1'} and len(support)==4 and rule['required_samples']==2 and rule['minimum_span_s']==1 and {r['role'] for r in rule['checks']}=={'condition','service'}, 'Two actual condition records and two actual service records are required over a one-second span, with declared sources.')
sensors=false['sensor_program']['profile']
for mid,cid in [('lake-flow','flow-transfer'),('joint-service-meter','joint-service-transfer')]:
    m=next(v for v in sensors['measurements'] if v['id']==mid)
    channel=next(v for v in sensors['channels'] if v['id']==cid)
    check('review_record_clock:'+mid, m['phase_s']==5 and m['period_s']==1 and channel['delay_s']==.5 and channel['validity_s']==3, 'Samples 5/6 arrive 5.5/6.5, before review 6.75 and publication 7; both remain current.')
for name in ['normal','false_report','local_protection','too_late']:
    expected = {'normal':(Fraction(29,8),Fraction(29,8),0,0,0,0),'false_report':(Fraction(29,8),Fraction(29,8),0,0,1,Fraction(1,4)),'local_protection':(Fraction(9,4),Fraction(3,2),1,0,0,0),'too_late':(4,1,3,1,Fraction(3,4),Fraction(1,4))}[name]
    keys=['demand_service_unit_s','delivered_service_unit_s','normalized_deficit_s','travel_person_s','work_person_s','access_check_person_s']
    check('independent_service_cost_literals:'+name, all(literal(oracle[name][k])==v for k,v in zip(keys,expected)), 'Hand-calculated service integrals and separate personnel travel/work/access costs match the frozen literals.')
prior=Fraction(1,100)
reported=prior*Fraction(3,4)/(prior*Fraction(3,4)+(1-prior)*Fraction(3,100))
cleared=reported*Fraction(1,5)/(reported*Fraction(1,5)+(1-reported)*Fraction(9,10))
check('independent_posteriors', reported==Fraction(25,124)==literal(oracle['false_report']['cooling_probability_after_report']) and cleared==Fraction(50,941)==literal(oracle['false_report']['cooling_probability_after_negative_handheld']), 'Independent Bayes arithmetic uses declared rational likelihoods, not simulator output.')
fp=false['policy_program']['workforce_profile']
check('false_report_paid_clock', Fraction(3)+fraction(fp['access_check_s'])+fraction(fp['work_times_s']['inspect_facility_cooling']) == literal(oracle['false_report']['inspection_completed_s']) == Fraction(17,4) and literal(oracle['false_report']['inspection_arrived_s']) == Fraction(19,4), 'Co-located personnel/tool still require .25 second access plus one second of actual work and .5 second report latency.')
late=cases['too_late']
wp=late['public_preparation']['workforce_profile']
edge=next(e for e in late['model']['graphs']['access'] if e['from']=='loc_control' and e['to']=='loc_it')
start=Fraction(1)+fraction(wp['walk_times_s'][edge['id']])+fraction(wp['access_check_s'])
end=start+fraction(wp['work_times_s']['inspect_it_service'])
check('late_independent_clock', start==Fraction(9,4) and end==literal(oracle['too_late']['theoretical_earliest_completion_s'])==Fraction(13,4) and fraction(late['boundary_events'][0]['time_s'])==3<end and Fraction(3)-start==literal(oracle['too_late']['work_person_s']), 'Issue at 1, walk one second, access .25; work 2.25..3, earlier than theoretical completion 3.25.')
check('late_public_clock', late['public_preparation']['decision_times_s']==[0,1,3.25,4] and late['closure_assessment_times_s']==[3.25,4] and len(late['public_preparation']['evidence_ledger']['records'])==1 and late['public_preparation']['evidence_ledger']['records'][0]['arrived_at_s']==1, 'Four public frames, one arrived manual suspicion; no invented network/service observations or private future gate schedule in planning.')
check('protection_events_and_reset_literal', [(e['time_s'],e['parameter_id'],e['value']) for e in cases['local_protection']['boundary_events']]==[(.75,'internal_valve_opening',0),(1.25,'internal_valve_opening',1)] and literal(oracle['local_protection']['protection_sample_s'])==1 and literal(oracle['local_protection']['conditional_reset_s'])==2, 'Original one-second sample clock and thresholds are retained. Reset at 2 is conditional on actual thermal/flow gates, not a demonstrated trajectory.')
idle=data(protocol['protection_workforce_input'])
check('idle_workforce_real_zero', idle['submissions']==[] and idle['plan']['requests']==[] and idle['plan']['decision_times_s']==[0] and idle['evidence_ledger']['records']==[], 'One genuine public initial frame with no jobs; no absent counter is coerced to zero.')
for prep_name in [protocol['preparation'],protocol['protection_workforce_preparation']]:
    p=data(prep_name)
    for name,h in p['source_inputs'].items():
        check('preparation_source:'+prep_name+':'+name, sha256((S/name).read_bytes()).hexdigest()==h, 'Prepared static dependency matches its recorded input hash.')
    for name,h in p.get('outputs',p.get('artifacts',{})).items():
        check('preparation_output:'+prep_name+':'+name, sha256((S/Path(prep_name).parent/name).read_bytes()).hexdigest()==h, 'Prepared output matches its receipt hash.')
    tool='scripts/prepare_negative_control_inputs_v2.py' if prep_name==protocol['preparation'] else 'scripts/prepare_negative_control_workforce.py'
    check('preparation_tool:'+tool, sha256((S/tool).read_bytes()).hexdigest()==p['authoring_tool_sha256'], 'Pinned authoring tool is the exact source used for this prepared input.')
observation=data('evidence/mainline/engineering/28-negative-controls/reference/static-check-observation.json')
for name,h in observation['original_files'].items():
    path='evidence/mainline/engineering/28-negative-controls/reference/'+name
    check('retained_unexecuted_draft:'+name, sha256((S/path).read_bytes()).hexdigest()==h and git('show','e76884c2:'+path)==(S/path).read_bytes(), 'Original unexecuted draft retained exactly at the draft commit and current fixed source.')
check('original_demand_failure_retained', observation['status']=='UNEXECUTED_INPUT_DRAFT_RETAINED' and observation['actual_closure_demand'] != observation['expected_demand'] and observation['new_physics']==observation['new_selector_calls']==observation['registered_effect_trials']==0, 'The original static failure is retained separately and not disguised as a successful run.')
# Cross-interface AST witness: NO_EFFECT producer omits applied write fields,
# but the new checker directly indexes one. Never invoke the producer/checker.
consumer=ast.parse((S/'scripts/negative_control_checks.py').read_bytes())
producer=ast.parse((S/'src/aegis_dc/intervention_execution.py').read_bytes())
fn=next(n for n in consumer.body if isinstance(n,ast.FunctionDef) and n.name=='too_late')
reads=[n for n in ast.walk(fn) if isinstance(n,ast.Subscript) and isinstance(n.value,ast.Name) and n.value.id=='effect' and isinstance(n.slice,ast.Constant) and n.slice.value=='applied_at_s']
audit_creation=[n for n in ast.walk(producer) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='audit' for t in n.targets) and isinstance(n.value,ast.Call)]
creation_fields={k.arg for n in audit_creation for k in n.value.keywords}
success_only=[n for n in ast.walk(producer) if isinstance(n,ast.If) and isinstance(n.test,ast.Compare) and isinstance(n.test.left,ast.Name) and n.test.left.id=='reason' and any(isinstance(k,ast.keyword) and k.arg=='applied_at_s' for b in n.body for k in ast.walk(b))]
blocking=bool(reads) and 'applied_at_s' not in creation_fields and len(success_only)==1
check('no_effect_output_contract', not blocking, 'BLOCKER SPEC-001: consumer line 202 indexes applied_at_s; producer lines 155-163 adds that field only for an applied effect. Expected aborted NO_EFFECT validation necessarily raises KeyError.')
expected_failures={'no_effect_output_contract'}
actual_failures={r['name'] for r in records if r['status']=='FAIL'}
if actual_failures != expected_failures:
    raise RuntimeError('Unexpected independent static-review failures: '+str(actual_failures))
result=dict(schema='aegisdc-independent-static-spec-checks-v1',source=SOURCE,base=BASE,status='COMPLETED_WITH_BLOCKING_FINDING',checks=len(records),passed=sum(r['status']=='PASS' for r in records),failed=sum(r['status']=='FAIL' for r in records),new_project_imports=0,new_project_calls=0,new_physics=0,new_selectors=0,new_closure_calls=0,new_tests=0,new_research_trials=0,records=records)
(ROOT/'checks.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in result.items() if k!='records'},ensure_ascii=False))
