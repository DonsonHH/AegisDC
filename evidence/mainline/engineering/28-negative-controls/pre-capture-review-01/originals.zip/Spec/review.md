# Independent Spec review of fixed ticket 28 candidate

Source: `105a1cf53e72abccb047e2f1a5a1cf141d8980ae`.
Base: `0a613289d983711d7637fb99857ee0333b0a1c53`.
Verdict: **CHANGES_REQUESTED**. The static review is complete; one blocking finding remains.

## SPEC-001 (P1): aborted NO_EFFECT uses a different event shape

`scripts/negative_control_checks.py:202` indexes `effect['applied_at_s']` while checking the expected safety-aborted fourth case. The existing producer creates the base event at `src/aegis_dc/intervention_execution.py:155` without that field; lines 157-161 add applied write fields only when no failure reason exists. The aborted path assigns `actual_work_not_completed` at line 147. `private_audit()` at lines 173-174 returns these same events, and `plant.py:845-846`, `861-863` preserve their shape. The expected NO_EFFECT therefore raises KeyError in validation, even when execution obeys the frozen timings.

This blocks the negative witness required by `.scratch/full-facility-mainline/spec.md:40`, the independent-output rule at line 71 and the contract at `docs/mainline/28-negative-controls-contract.md:10,18`. Correct the checker to require absence of all physical-write fields for NO_EFFECT, retain the plant contract and independently review the corrected source before capture.

## Completed static coverage

All 19 changed paths and 98 exact Git exports were inspected. The independent file/JSON/AST/Fraction verifier recorded 233 checks: 232 passed and the single cross-interface event-shape check failed as reported above. All runtime kernels remain unchanged by this diff.

The four named cases retain eight domains, four relation sets and shared entity identities in the same synthetic V6 facility. Normal and false report share physical parameters and public decision rules. Independent service and resource-cost arithmetic matches 29/8, 29/8, 9/4 and 4 demand units; false-report timing is 3.25-4.25 work and 4.75 arrival; the late case starts work at 2.25, is stopped at 3 and cannot finish before 3.25, with feedback at 3.5. The protection witness retains the original sampled latch/reset rule and explicitly leaves thermal admissibility conditional on the first actual trace.

The false-alarm disposition remains a declared reviewer input, not simulated cognition. Its existing evaluator requires the specified two real flow records and two real service records to be available before review at 6.75, to satisfy the source/count/span criteria and current checks, then publishes the disposition at 7 without claiming physical restoration. Public evidence profiles and nominal knowledge exclude private realization values and the future gate closure. The unused v1 demand-table draft, its static finding and corrected v2 are separately retained.

The exact-source reviews gate precedes output-directory creation. The four-call/21.5-second budget, attempt ledger, declared durable roles, committed-blob comparisons and saved-only checks remain explicit. No effect trial, method superiority, field calibration, AI or RSI claim is introduced. Progress still marks ticket 28 and M4 incomplete.

## Tool errors and execution boundary

`tool-errors.json` preserves the initial Windows stdout encoding error and two incorrect source-name lookups. Both were resolved using UTF-8 output and the fixed runtime inventory, and all required reads were completed. These errors were not treated as passed checks.

Only Git, file reads/writes, JSON, AST and independent Fraction arithmetic were used. There were zero project imports or application, selector, facility, closure, test, authoring and capture calls. This review is not physical acceptance or a mainline-completion claim.
