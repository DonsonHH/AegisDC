"""Independent fixed-source Spec review: files, Git, JSON, AST and Fraction only.
Never imports or executes the project, authoring scripts, simulator, selectors,
closure, application commands or tests. Source exports are read as data.
"""
import ast
from copy import deepcopy
from fractions import Fraction
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys
import zipfile

sys.stdout.reconfigure(encoding='utf-8')
ROOT = Path(__file__).resolve().parent
REPOSITORY = Path(r'C:\Users\Donson\.codex\worktrees\mainline28-negative-controls\Renly')
SOURCE = '815294edb4befd6717a412c9fe48deac84157b4a'
BASE = '105a1cf53e72abccb047e2f1a5a1cf141d8980ae'
S = ROOT / 'sources'
records = []

def check(name, condition, detail):
    records.append(dict(name=name, status='PASS' if condition else 'FAIL', detail=detail))

def data(name):
    return json.loads((S / name).read_bytes())

def git(*args, input=None):
    return subprocess.run(['git', *args], cwd=REPOSITORY, input=input, capture_output=True, check=True).stdout

def fraction(value):
    return Fraction(str(value))

def literal(value):
    return Fraction(value['numerator'], value['denominator'])

index = json.loads((ROOT / 'source-index.json').read_bytes())
check('fixed_source_identity', index['source_commit'] == SOURCE and index['base_commit'] == BASE and git('rev-parse', SOURCE).decode().strip() == SOURCE, 'Full source and base SHA identities match.')
paths = sorted(index['artifacts'])
raw = git('cat-file', '--batch', input=''.join(SOURCE+':'+p+'\n' for p in paths).encode())
offset = 0
for name in paths:
    end = raw.index(b'\n', offset)
    header = raw[offset:end].split()
    start = end+1
    size = int(header[2])
    blob = raw[start:start+size]
    offset = start+size+1
    pin = index['artifacts'][name]
    check('exact_git_export:'+name, header[1] == b'blob' and blob == (S/name).read_bytes() and sha256(blob).hexdigest() == pin['sha256'] and len(blob) == pin['bytes'] and header[0].decode() == pin['git_blob'], 'Export matches the exact committed blob, SHA-256 and byte count.')
check('git_export_stream_complete', offset == len(raw), 'Every Git batch byte was classified.')
changed = git('diff','--name-only',BASE+'...'+SOURCE).decode().splitlines()
check('kernels_unchanged', not any(p.startswith('src/') for p in changed), 'The 12 revision paths contain no application or simulation kernel changes.')
check('changed_path_count', len(changed) == 12 and set(changed) <= set(paths), 'All 12 revision paths are exported and reviewed.')
for name in paths:
    if name.endswith('.json'):
        data(name)
        check('json_parse:'+name, True, 'Strictly read as JSON; no source code imported.')
    elif name.endswith('.py'):
        ast.parse((S/name).read_bytes(), filename=name)
        check('ast_parse:'+name, True, 'Parsed as AST only; never executed.')
protocol = data('docs/mainline/28-negative-engineering-protocol-v2.json')
document = data(protocol['input'])
cases = document['cases']
oracle = data(protocol['literals'])
progress = data('docs/mainline/progress.json')
check('lifecycle_not_research_completion', progress['status'] == 'active' and progress['current_ticket'] == '28' and next(m for m in progress['milestones'] if m['id']=='M4')['status'] == 'in_progress' and progress['research_trials']['status'] == 'not_started' and progress['research_trials']['attempts'] == 0, 'M4 and the complete-facility objective remain incomplete; no registered effect trial.')
check('four_frozen_cases', list(cases) == protocol['cases'] == ['normal','false_report','local_protection','too_late'], 'Named normal, false report, local protection and too-late witnesses.')
check('fixed_physical_budget', sum(fraction(c['duration_s']) for c in cases.values()) == Fraction(43,2) == fraction(protocol['total_simulated_duration_s']) and protocol['total_integrations'] == 4 and all(c['maximum_step_s'] == .01 for c in cases.values()), 'Exactly 7.25+7.25+3+4 = 21.5 seconds, four integrations and .01 second maximum steps.')
normal = cases['normal']['replay_inputs']['dispatch_program']
false = cases['false_report']['replay_inputs']['dispatch_program']
for name, case in cases.items():
    model = case['model']
    check('full_scope:'+name, len(model['domains']) == 8 and set(model['graphs']) == {'physical','functional','control_information','access'} and model['id'] == document['facility_id'] and model['graphs'] == cases['normal']['model']['graphs'] and {e['id'] for e in model['entities']} == {e['id'] for e in cases['normal']['model']['entities']}, 'Same V6 facility, shared entity identities and all four relations.')
    check('declared_parameter_ranges:'+name, all(p['valid_range'][0] <= p['value'] <= p['valid_range'][1] and p['basis'] and p['source_note'] for p in model['parameters']), 'Each numerical parameter retains its declared range and provenance; coupled thermodynamics remain a runtime gate.')
a,b = deepcopy(normal), deepcopy(false)
ar,br = a['evidence_ledger'].pop('records'), b['evidence_ledger'].pop('records')
check('normal_false_identical_rules', a == b and cases['normal']['model'] == cases['false_report']['model'] and ar == [] and len(br) == 2, 'Only the delayed false report and declared reviewer record differ.')
for name,program in [('normal',normal),('false_report',false)]:
    policy=program['policy_program']
    check('public_model_consistency:'+name, policy['options']['catalog'] == program['closure_program']['risk_catalog'] and policy['options']['catalog']['demand'] == [{'start_s':0,'end_s':6,'rate':.5}] and policy['evidence_projection']['inspection_profile'] == program['inspection_program']['profile'] and policy['evidence_projection']['background_sensor_profile'] == program['sensor_program']['profile'] and policy['intervention_declaration'] == program['intervention_program'] == program['closure_program']['intervention_declaration'], 'Forecast, actual declaration and closure share public assumptions; no recorded outcome is copied into the forecast.')
    check('online_budget:'+name, program['decision_times_s'] == protocol['online_decisions_s'] == [1,3,4.5,4.75,5.5,6.5,7], 'Seven declared decisions; no pre-report task or extra selector call is authorized.')
check('report_arrival_order', [(r['observed_at_s'],r['arrived_at_s']) for r in br] == [(1.5,3),(6.75,7)], 'Suspicion arrives at 3; declared review is observed at 6.75 and arrives at 7.')
profile=false['closure_program']['profile']
rule=profile['rules'][0]
support=profile['false_alarm_reviews'][0]['supporting_record_ids']
check('four_genuine_review_records', set(support) == {'flow-transfer:0','flow-transfer:1','joint-service-transfer:0','joint-service-transfer:1'} and len(support)==4 and rule['required_samples']==2 and rule['minimum_span_s']==1 and {r['role'] for r in rule['checks']}=={'condition','service'}, 'Two actual condition records and two actual service records are required over a one-second span, with declared sources.')
sensors=false['sensor_program']['profile']
for mid,cid in [('lake-flow','flow-transfer'),('joint-service-meter','joint-service-transfer')]:
    m=next(v for v in sensors['measurements'] if v['id']==mid)
    channel=next(v for v in sensors['channels'] if v['id']==cid)
    check('review_record_clock:'+mid, m['phase_s']==5 and m['period_s']==1 and channel['delay_s']==.5 and channel['validity_s']==3, 'Samples 5/6 arrive 5.5/6.5, before review 6.75 and publication 7; both remain current.')
for name in ['normal','false_report','local_protection','too_late']:
    expected = {'normal':(Fraction(29,8),Fraction(29,8),0,0,0,0),'false_report':(Fraction(29,8),Fraction(29,8),0,0,1,Fraction(1,4)),'local_protection':(Fraction(9,4),Fraction(3,2),1,0,0,0),'too_late':(4,1,3,1,Fraction(3,4),Fraction(1,4))}[name]
    keys=['demand_service_unit_s','delivered_service_unit_s','normalized_deficit_s','travel_person_s','work_person_s','access_check_person_s']
    check('independent_service_cost_literals:'+name, all(literal(oracle[name][k])==v for k,v in zip(keys,expected)), 'Hand-calculated service integrals and separate personnel travel/work/access costs match the frozen literals.')
prior=Fraction(1,100)
reported=prior*Fraction(3,4)/(prior*Fraction(3,4)+(1-prior)*Fraction(3,100))
cleared=reported*Fraction(1,5)/(reported*Fraction(1,5)+(1-reported)*Fraction(9,10))
check('independent_posteriors', reported==Fraction(25,124)==literal(oracle['false_report']['cooling_probability_after_report']) and cleared==Fraction(50,941)==literal(oracle['false_report']['cooling_probability_after_negative_handheld']), 'Independent Bayes arithmetic uses declared rational likelihoods, not simulator output.')
fp=false['policy_program']['workforce_profile']
check('false_report_paid_clock', Fraction(3)+fraction(fp['access_check_s'])+fraction(fp['work_times_s']['inspect_facility_cooling']) == literal(oracle['false_report']['inspection_completed_s']) == Fraction(17,4) and literal(oracle['false_report']['inspection_arrived_s']) == Fraction(19,4), 'Co-located personnel/tool still require .25 second access plus one second of actual work and .5 second report latency.')
late=cases['too_late']
wp=late['public_preparation']['workforce_profile']
edge=next(e for e in late['model']['graphs']['access'] if e['from']=='loc_control' and e['to']=='loc_it')
start=Fraction(1)+fraction(wp['walk_times_s'][edge['id']])+fraction(wp['access_check_s'])
end=start+fraction(wp['work_times_s']['inspect_it_service'])
check('late_independent_clock', start==Fraction(9,4) and end==literal(oracle['too_late']['theoretical_earliest_completion_s'])==Fraction(13,4) and fraction(late['boundary_events'][0]['time_s'])==3<end and Fraction(3)-start==literal(oracle['too_late']['work_person_s']), 'Issue at 1, walk one second, access .25; work 2.25..3, earlier than theoretical completion 3.25.')
check('late_public_clock', late['public_preparation']['decision_times_s']==[0,1,3.25,4] and late['closure_assessment_times_s']==[3.25,4] and len(late['public_preparation']['evidence_ledger']['records'])==1 and late['public_preparation']['evidence_ledger']['records'][0]['arrived_at_s']==1, 'Four public frames, one arrived manual suspicion; no invented network/service observations or private future gate schedule in planning.')
check('protection_events_and_reset_literal', [(e['time_s'],e['parameter_id'],e['value']) for e in cases['local_protection']['boundary_events']]==[(.75,'internal_valve_opening',0),(1.25,'internal_valve_opening',1)] and literal(oracle['local_protection']['protection_sample_s'])==1 and literal(oracle['local_protection']['conditional_reset_s'])==2, 'Original one-second sample clock and thresholds are retained. Reset at 2 is conditional on actual thermal/flow gates, not a demonstrated trajectory.')
idle=data(protocol['protection_workforce_input'])
check('idle_workforce_real_zero', idle['submissions']==[] and idle['plan']['requests']==[] and idle['plan']['decision_times_s']==[0] and idle['evidence_ledger']['records']==[], 'One genuine public initial frame with no jobs; no absent counter is coerced to zero.')
for prep_name in [protocol['preparation'],protocol['protection_workforce_preparation']]:
    p=data(prep_name)
    for name,h in p['source_inputs'].items():
        check('preparation_source:'+prep_name+':'+name, sha256((S/name).read_bytes()).hexdigest()==h, 'Prepared static dependency matches its recorded input hash.')
    for name,h in p.get('outputs',p.get('artifacts',{})).items():
        check('preparation_output:'+prep_name+':'+name, sha256((S/Path(prep_name).parent/name).read_bytes()).hexdigest()==h, 'Prepared output matches its receipt hash.')
    tool='scripts/prepare_negative_control_inputs_v2.py' if prep_name==protocol['preparation'] else 'scripts/prepare_negative_control_workforce.py'
    check('preparation_tool:'+tool, sha256((S/tool).read_bytes()).hexdigest()==p['authoring_tool_sha256'], 'Pinned authoring tool is the exact source used for this prepared input.')
observation=data('evidence/mainline/engineering/28-negative-controls/reference/static-check-observation.json')
for name,h in observation['original_files'].items():
    path='evidence/mainline/engineering/28-negative-controls/reference/'+name
    check('retained_unexecuted_draft:'+name, sha256((S/path).read_bytes()).hexdigest()==h and git('show','e76884c2:'+path)==(S/path).read_bytes(), 'Original unexecuted draft retained exactly at the draft commit and current fixed source.')
check('original_demand_failure_retained', observation['status']=='UNEXECUTED_INPUT_DRAFT_RETAINED' and observation['actual_closure_demand'] != observation['expected_demand'] and observation['new_physics']==observation['new_selector_calls']==observation['registered_effect_trials']==0, 'The original static failure is retained separately and not disguised as a successful run.')
# Recheck the original cross-interface finding against the unchanged producer.
consumer=ast.parse((S/'scripts/negative_control_checks.py').read_bytes())
producer=ast.parse((S/'src/aegis_dc/intervention_execution.py').read_bytes())
fn=next(n for n in consumer.body if isinstance(n,ast.FunctionDef) and n.name=='too_late')
reads=[n for n in ast.walk(fn) if isinstance(n,ast.Subscript) and isinstance(n.value,ast.Name) and n.value.id=='effect' and isinstance(n.slice,ast.Constant) and n.slice.value=='applied_at_s']
audit_creation=[n for n in ast.walk(producer) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='audit' for t in n.targets) and isinstance(n.value,ast.Call)]
creation_fields={k.arg for n in audit_creation for k in n.value.keywords}
success_only=[n for n in ast.walk(producer) if isinstance(n,ast.If) and isinstance(n.test,ast.Compare) and isinstance(n.test.left,ast.Name) and n.test.left.id=='reason' and any(isinstance(k,ast.keyword) and k.arg=='applied_at_s' for b in n.body for k in ast.walk(b))]
write_fields={'applied_at_s','parameter_id','old_value','new_value','effect_scope'}
absence=[n for n in ast.walk(fn) if isinstance(n,ast.UnaryOp) and isinstance(n.op,ast.Not) and isinstance(n.operand,ast.BinOp) and isinstance(n.operand.op,ast.BitAnd) and isinstance(n.operand.left,ast.Set) and ast.literal_eval(n.operand.left)==write_fields and isinstance(n.operand.right,ast.Call) and isinstance(n.operand.right.func,ast.Name) and n.operand.right.func.id=='set' and len(n.operand.right.args)==1 and isinstance(n.operand.right.args[0],ast.Name) and n.operand.right.args[0].id=='effect']
check('no_effect_output_contract_corrected', not reads and not (creation_fields & write_fields) and len(success_only)==1 and len(absence)==1, 'SPEC-001 resolved: existing failed-event shape is preserved, and all five physical-write fields must be absent. No missing field is coerced to null.')
def comparison_exists(left, right):
    target=ast.dump(ast.parse(left+' == '+right,mode='eval').body,include_attributes=False)
    return any(ast.dump(n,include_attributes=False)==target for n in ast.walk(fn) if isinstance(n,ast.Compare))
check('strict_abort_details', all(comparison_exists(left,right) for left,right in [("effect['outcome']","'NO_EFFECT'"),("effect['reason']","'actual_work_not_completed'"),("effect['task_status']","'aborted'"),("effect['observed_at_s']","3"),("feedback['outcome']","'NO_EFFECT'"),("feedback['reason']","effect['reason']"),("feedback['observed_at_s']","3"),("feedback['arrived_at_s']","3.5")]), 'The checker independently retains the expected abort reason/status/time and delayed public NO_EFFECT feedback.')
# Inherit complete prior coverage through exact unchanged blobs, not a patch-only verdict.
prior_index=json.loads((ROOT/'inherited/spec01/source-index.json').read_bytes())
prior_report=json.loads((ROOT/'inherited/spec01/review.json').read_bytes())
prior_manifest=json.loads((ROOT/'inherited/spec01/manifest.json').read_bytes())
check('prior_spec_review_completed', prior_report['axis']=='Spec' and prior_report['source']==BASE and prior_report['status']=='CHANGES_REQUESTED' and prior_report['review_complete'] and prior_report['checks']==233 and len(prior_report['unresolved'])==1 and prior_report['unresolved'][0]['id']=='SPEC-001', 'Original full Spec coverage and its unwaived finding remain immutable.')
runtime=[p for p in prior_index['artifacts'] if p.startswith('src/') and p.endswith('.py')]
check('all_67_runtime_blobs_unchanged', len(runtime)==67 and all(index['artifacts'][p]['sha256']==prior_index['artifacts'][p]['sha256'] for p in runtime), 'Every recorded runtime Python byte is unchanged from the reviewed 105 source.')
fixed_inputs=[protocol['input'],protocol['literals'],protocol['preparation'],protocol['protection_workforce_input'],protocol['protection_workforce_preparation'],*protocol['retained_unexecuted_draft'],'evidence/mainline/engineering/27-full-loop/reference/online-loop-v2.json','configs/materials/reference-r134a-saturation.json','scripts/prepare_negative_control_inputs.py','scripts/prepare_negative_control_inputs_v2.py','scripts/prepare_negative_control_workforce.py','docs/mainline/28-negative-controls-contract.md','docs/mainline/28-negative-engineering-protocol-v1.json']
for name in fixed_inputs:
    check('unchanged_inherited_input:'+name,index['artifacts'][name]['sha256']==prior_index['artifacts'][name]['sha256'],'Exact input, literal, authoring tool or original protocol blob retained; no trajectory or prior outcome tuning.')
old_protocol=data('docs/mainline/28-negative-engineering-protocol-v1.json')
check('v2_budget_and_all_criteria_retained', all(protocol[k]==v for k,v in old_protocol.items() if k not in {'schema','output','tools'}), 'All case order, physical/public budgets, numerical tolerances, failure rule and interpretation are unchanged.')
check('v2_only_declared_new_roles',set(protocol)-set(old_protocol)=={'supersedes_unexecuted_source','retained_context','retained_failed_reviews','correction','retained_review_seal_sha256'} and protocol['tools']==old_protocol['tools']+['scripts/preserve_negative_control_reviews.py'] and protocol['schema']=='aegisdc-negative-engineering-protocol-v2' and protocol['supersedes_unexecuted_source']==BASE, 'New roles are explicitly declared provenance and saved-file preservation only.')
check('new_unused_output02', protocol['output']=='evidence/mainline/engineering/28-negative-controls/capture-20261107-02' and not (REPOSITORY/protocol['output']).exists() and not (REPOSITORY/old_protocol['output']).exists() and not git('ls-tree','-r','--name-only',SOURCE,protocol['output'],old_protocol['output']).strip(), 'Neither reserved output directory exists and no original case packet is committed. No formal budget was consumed by this review.')
for name in ['scripts/check_negative_control_preflight.py','scripts/negative_control_delivery.py']:
    tree=ast.parse((S/name).read_bytes())
    setting=[n.value.value for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='PROTOCOL' for t in n.targets) and isinstance(n.value,ast.Constant)]
    check('v2_execution_entry:'+name,setting==['docs/mainline/28-negative-engineering-protocol-v2.json'],'Both capture/saved verification and static preflight use protocol v2.')
for name,functions in [('scripts/negative_control_delivery.py',['capture','reviews','check_review_archive','declared','execute','verify']),('scripts/negative_control_checks.py',['common','online','protection','paired','check_case'])]:
    before=ast.parse(git('show',BASE+':'+name))
    after=ast.parse((S/name).read_bytes())
    b={n.name:n for n in before.body if isinstance(n,ast.FunctionDef)}
    a={n.name:n for n in after.body if isinstance(n,ast.FunctionDef)}
    for function in functions:
        check('unchanged_reviewed_behavior:'+name+':'+function,ast.dump(a[function],include_attributes=False)==ast.dump(b[function],include_attributes=False),'All previously reviewed runtime call sites, evidence/public gates, saved-only checking, failure ledger and exact-source acceptance checks remain unchanged.')
helper=ast.parse((S/'scripts/preserve_negative_control_reviews.py').read_bytes())
helper_imports=[n.module for n in ast.walk(helper) if isinstance(n,ast.ImportFrom)]+[a.name for n in ast.walk(helper) if isinstance(n,ast.Import) for a in n.names]
check('retained_review_helper_file_only',set(helper_imports)<={'argparse','hashlib','json','pathlib','zipfile'},'History verifier uses file/JSON/hash/ZIP operations and imports no project module.')
package=S/'evidence/mainline/engineering/28-negative-controls/pre-capture-review-01'
declaration=json.loads((package/'declaration.json').read_bytes())
receipt=json.loads((package/'receipt.json').read_bytes())
members=json.loads((package/'members.json').read_bytes())
package_names={'declaration.json','members.json','originals.zip','receipt.json'}
check('retained_package_declared_exactly',set(p.name for p in package.iterdir() if p.is_file())==package_names and set(receipt['artifacts'])==set(declaration['artifacts'])==package_names-{'receipt.json'} and set(protocol['retained_failed_reviews'])=={(package.relative_to(S)/n).as_posix() for n in package_names},'All four immutable package members are explicit current input roles; no undeclared extras.')
check('failed_history_not_a_pass',receipt['status']=='PRESERVED_NOT_A_PASS' and receipt['source']==BASE and receipt['new_physical_calls']==0 and declaration['classification']=='FAILED_SOURCE_REVIEWS_BEFORE_ANY_CASE_EXECUTION','Historical reviews retain failed status and their unexecuted source identity.')
check('preservation_tool_identity',receipt['authoring_tool_sha256']==sha256((S/'scripts/preserve_negative_control_reviews.py').read_bytes()).hexdigest(),'Exact preservation tool identity matches its receipt and current protocol tool role.')
for name,identity in receipt['artifacts'].items():
    check('retained_package_hash:'+name,sha256((package/name).read_bytes()).hexdigest()==identity,'Committed retained member matches the original preservation receipt.')
with zipfile.ZipFile(package/'originals.zip') as archive:
    names=archive.namelist()
    check('retained_archive_exact_222_members',len(names)==len(set(names))==222 and set(names)==set(members)==set(declaration['members']),'Exact archive role set, without duplicates or undeclared members.')
    for name,identity in members.items():
        raw=archive.read(name)
        check('retained_archive_member:'+name,sha256(raw).hexdigest()==identity['sha256'] and len(raw)==identity['bytes'],'Original archived durable bytes and length match the predeclared member index.')
    check('both_old_axes_sealed',declaration['seals']=={'Spec':'manifest.json','Standards':'delivery-manifest.json'} and set(protocol['retained_review_seal_sha256'])=={'Spec/manifest.json','Standards/delivery-manifest.json'},'Both original axis seal identities are declared in the new frozen protocol.')
    for axis,seal in declaration['seals'].items():
        prefix=axis+'/'
        manifest=json.loads(archive.read(prefix+seal))
        report=json.loads(archive.read(prefix+'review.json'))
        check('retained_axis_source_and_failure:'+axis,manifest['axis']==report['axis']==axis and manifest['source']==report['source']==BASE and bool(report['unresolved']) and not report['status'].startswith('PASS') and report['checks']>0,'Failed old verdict stays bound to source 105; it cannot approve new source 815.')
        check('retained_axis_exact_roles:'+axis,{n[len(prefix):] for n in names if n.startswith(prefix)}==set(manifest['artifacts'])|{seal},'Recursive original manifest declares the full axis durable set with only its own terminal seal excluded.')
        check('retained_axis_seal_pin:'+axis,sha256(archive.read(prefix+seal)).hexdigest()==protocol['retained_review_seal_sha256'][prefix+seal],'New protocol pins the exact immutable original seal bytes.')
        for name,identity in manifest['artifacts'].items():
            check('retained_recursive_manifest:'+prefix+name,members[prefix+name]==identity,'Outer role index and original inner immutable seal agree exactly.')
        if axis=='Spec':
            check('inherited_spec_manifest_exact_archive',archive.read(prefix+seal)==(ROOT/'inherited/spec01/manifest.json').read_bytes() and archive.read(prefix+'review.json')==(ROOT/'inherited/spec01/review.json').read_bytes(),'Inherited completed Spec review is the exact archived original, not a rewritten summary.')
# New pins preserve history before output creation and keep execution-source review gates.
delivery=(S/'scripts/negative_control_delivery.py').read_text(encoding='utf-8')
check('old_history_in_source_pin_roles',"*protocol['retained_context']" in delivery and "retained_review=protocol['retained_failed_reviews']" in delivery and 'old_review = verify_preserved_reviews()' in delivery and "protocol['retained_review_seal_sha256'].items()" in delivery and "old_review['source'] == protocol['supersedes_unexecuted_source']" in delivery,'Current source pins bind retained context, package bytes, original seals and the superseded source before any case call.')
expected_failures=set()
actual_failures={r['name'] for r in records if r['status']=='FAIL'}
if actual_failures != expected_failures:
    raise RuntimeError('Unexpected independent static-review failures: '+str(actual_failures))
result=dict(schema='aegisdc-independent-static-spec-checks-v1',source=SOURCE,base=BASE,status='PASS_COMPLETE_STATIC_SPEC_REVIEW',checks=len(records),passed=sum(r['status']=='PASS' for r in records),failed=sum(r['status']=='FAIL' for r in records),new_project_imports=0,new_project_calls=0,new_physics=0,new_selectors=0,new_closure_calls=0,new_tests=0,new_research_trials=0,records=records)
(ROOT/'checks.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in result.items() if k!='records'},ensure_ascii=False))
