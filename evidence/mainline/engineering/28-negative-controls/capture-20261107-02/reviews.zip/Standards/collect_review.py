"""Export the complete fixed-source review scope without running repository code."""
import json
from pathlib import Path
import subprocess
ROOT=Path(__file__).resolve().parent
PRIOR=ROOT.parent/'28-frozen-standards-review-01'
REPO=Path(r'C:\Users\Donson\.codex\worktrees\mainline28-negative-controls\Renly')
BASE='105a1cf53e72abccb047e2f1a5a1cf141d8980ae'
SOURCE='815294edb4befd6717a412c9fe48deac84157b4a'
def git(*args):
    return subprocess.run(['git','-C',str(REPO),*args],check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE).stdout
assert git('rev-parse',SOURCE+'^{commit}').decode().strip()==SOURCE
assert git('merge-base',BASE,SOURCE).decode().strip()==BASE
prior_scope=json.loads((PRIOR/'scope.json').read_bytes())
changed=git('diff','--name-only',BASE+'...'+SOURCE).decode().splitlines()
exports=sorted(set(prior_scope['exported_paths'])|set(changed))
for path in exports:
    target=ROOT/'fixed-source'/path
    target.parent.mkdir(parents=True,exist_ok=True)
    target.write_bytes(git('show',SOURCE+':'+path))
(ROOT/'diff.patch').write_bytes(git('diff','--binary',BASE+'...'+SOURCE))
(ROOT/'commits.txt').write_bytes(git('log','--format=fuller',BASE+'..'+SOURCE))
(ROOT/'source-tree.txt').write_bytes(git('ls-tree','-r','--full-tree',SOURCE))
(ROOT/'worktree-state.txt').write_bytes(git('status','--porcelain=v1'))
(ROOT/'worktrees.txt').write_bytes(git('worktree','list','--porcelain'))
(ROOT/'scope.json').write_text(json.dumps({
    'axis':'Standards','base':BASE,'source':SOURCE,'merge_base':BASE,
    'diff_command':'git diff '+BASE+'...'+SOURCE,'log_command':'git log '+BASE+'..'+SOURCE,
    'git_version':git('--version').decode().strip(),'exported_paths':exports,
    'inherited_review_root':str(PRIOR),'inherited_review_source':BASE,
    'execution_boundary':'Git, AST, JSON, Fraction, and filesystem inspection only. No repository authoring/verification tool invocation, project imports, app/selector/plant/closure/test/full calls.'
},indent=2)+'\n',encoding='utf-8')
print(json.dumps({'source':SOURCE,'exported_paths':len(exports),'changed_paths':len(changed),'root':str(ROOT)}))
