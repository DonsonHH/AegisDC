"""Seal the complete second Standards review; preserve all reviewer-tool attempts."""
from hashlib import sha256
import json
from pathlib import Path
import subprocess
ROOT=Path(__file__).resolve().parent
REPO=Path(r'C:\Users\Donson\.codex\worktrees\mainline28-negative-controls\Renly')
SOURCE='815294edb4befd6717a412c9fe48deac84157b4a'
BASE='105a1cf53e72abccb047e2f1a5a1cf141d8980ae'
PRIOR=ROOT.parent/'28-frozen-standards-review-01'

def write(name,value):
    if not isinstance(value,str):
        value=json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n'
    (ROOT/name).write_text(value,encoding='utf-8',newline='\n')

static=json.loads((ROOT/'static-checks.json').read_bytes())
assert static['checks']==static['checks_passed']==1208 and static['checks_failed']==0
assert static['source']==SOURCE and not static['unresolved'] and not static['findings']
assert sha256((PRIOR/'delivery-manifest.json').read_bytes()).hexdigest()=='7e1e436d1ea78dcd3408f334ce30cc46ca395c3a96ed222e2521cbff66495e59'
ledger=json.loads((ROOT/'review-tool-attempts.json').read_bytes())
assert len(ledger['review_tool_attempts'])==1 and ledger['review_tool_attempts'][0]['exit_code']==1
ledger['review_tool_attempts'].append({'attempt':2,'command':'python static_review.py','status':'COMPLETED_FULL_STATIC_REVIEW','exit_code':0,'tool':'static_review.py','tool_sha256':sha256((ROOT/'static_review.py').read_bytes()).hexdigest(),'checks':1208,'failed_checks':0,'unresolved':0,'new_project_calls':0})
ledger['unresolved_review_tool_errors']=[]
write('review-tool-attempts.json',ledger)
write('review.json',{
 'schema':'aegisdc-independent-fixed-source-review-v1','axis':'Standards',
 'source':SOURCE,'base':BASE,'status':'PASS_STATIC_PRECAPTURE_FULL_SCOPE',
 'checks':1208,'unresolved':[],'hard_findings':0,'heuristic_findings':0,
 'resolved_previous_findings':[{'id':'STD-28-01','previous_source':BASE,'resolution':'Strict absence-aware validation of all five successful-write fields, exact NO_EFFECT/actual_work_not_completed/aborted/3s event and 3.5s matching feedback; unchanged runtime.'}],
 'standards_sources':['AGENTS.md','GLOSSARY.md','docs/MAINLINE.md','docs/mainline/progress.json','docs/agents/domain.md','docs/agents/issue-tracker.md','docs/agents/triage-labels.md','docs/adr/0003-complete-facility-mainline.md','.scratch/full-facility-mainline/spec.md','docs/mainline/28-negative-controls-contract.md','docs/mainline/28-negative-engineering-protocol-v1.json','docs/mainline/28-negative-engineering-protocol-v2.json','docs/mainline/28-pre-capture-correction.md','.scratch/full-facility-mainline/issues/28-negative-controls.md'],
 'coverage':'Complete current source preparation/tooling gate, independently revalidated with the prior full scope. Exact 67 runtime files, all four input cases/literals/4-call21.5s budget and prior unexecuted protocol remain unchanged. All222 original failed review members recursively bind to their fixed original seals.',
 'method':'Git-object/AST/strict-JSON/Fraction/filesystem inspection only. No project script import/invocation, app/selector/plant/closure/test/full calls.',
 'review_tool_accounting':'One reviewer status-string assertion mistake was preserved, corrected to the exact original sealed rejected statuses, and resolved by the completed 1208-check run. No source/protocol/evidence/hash criterion was changed or waived.',
 'scope_limit':'Standards pre-capture gate only. Both independent current-source reviews are required before capture. No physical/numerical runtime, ticket28/M4, scientific gain, or research completion acceptance.',
 'evidence':'static-checks.json','inheritance':'prior-review-inheritance.json','manifest':'delivery-manifest.json'
})
write('README.md',f'''# Independent Standards review 02

Verdict: **PASS_STATIC_PRECAPTURE_FULL_SCOPE** for `{SOURCE}`, compared with `{BASE}` using the three-dot diff. All **1,208** static checks completed successfully; **zero unresolved hard or heuristic findings** remain.

The prior P1 STD-28-01 is closed at this new source. The checker now requires NO_EFFECT, actual_work_not_completed, aborted status and an observation at 3 seconds; all five successful-write fields must be absent. Matching feedback must arrive at 3.5 seconds. The unchanged producer schema is respected without synthesizing missing values.

This is a full pre-capture Standards review. It revalidates the eight-domain/four-relation/shared-identity facility, SI/source boundaries, private truth and delayed evidence, scoped authority, independent service/timing literals, call/frame and abort accounting, strict dual-axis review gate, durable/cache roles, fresh Git/tool/input equality and terminal failures. All 67 runtime files, four-case inputs/literals, 4-call/21.5-second budget, original protocol and earlier input draft remain unchanged.

Protocol v2 uses a new output02. The retained archive has exactly 222 original files. Every SHA/byte count, original manifest member and fixed seal was verified recursively. The original01 Standards directory is byte-identical to its seal; its failed verdict remains failed.

One reviewer-tool attempt incorrectly assumed both rejected verdict status names began FAIL. Its source and error were preserved. The correction checks the two exact original status strings, retaining every hash and criterion, followed by the completed full review. No reviewer-tool error remains unresolved.

No application imports, project authoring/verifier scripts, selectors, plant, closure, tests or full runs occurred. This verdict supplies only the Standards pre-capture gate. It does not establish physical/numerical, ticket28/M4, scientific or research-goal acceptance.

`delivery-manifest.json` seals every other durable file, including all105 exact fixed-source exports, verdict, review tools and both tool-attempt records. No unsealed extras or cache waivers are allowed.
''')
scope=json.loads((ROOT/'scope.json').read_bytes())
for name in scope['exported_paths']:
    raw=subprocess.run(['git','-C',str(REPO),'show',SOURCE+':'+name],check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE).stdout
    assert (ROOT/'fixed-source'/name).read_bytes()==raw,name
manifest=ROOT/'delivery-manifest.json'
assert not manifest.exists(),'Refusing to replace a review seal'
files=sorted(p for p in ROOT.rglob('*') if p.is_file())
assert not any('__pycache__' in p.parts or p.suffix in {'.pyc','.pyo'} for p in files)
artifacts={p.relative_to(ROOT).as_posix():{'sha256':sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in files}
write('delivery-manifest.json',{'schema':'aegisdc-independent-review-delivery-v1','axis':'Standards','source':SOURCE,'artifacts':artifacts})
assert {p.relative_to(ROOT).as_posix() for p in ROOT.rglob('*') if p.is_file()}==set(artifacts)|{'delivery-manifest.json'}
for name,pin in artifacts.items():
    raw=(ROOT/name).read_bytes()
    assert sha256(raw).hexdigest()==pin['sha256'] and len(raw)==pin['bytes'],name
assert 'review.json' in artifacts and all('fixed-source/'+p in artifacts for p in scope['exported_paths'])
print(json.dumps({'status':'SEALED_PASS','axis':'Standards','source':SOURCE,'checks':1208,'unresolved':0,'sealed_artifacts':len(artifacts),'manifest_sha256':sha256(manifest.read_bytes()).hexdigest(),'review_sha256':sha256((ROOT/'review.json').read_bytes()).hexdigest(),'root':str(ROOT)}))
