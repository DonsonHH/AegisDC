"""Build this independent static review from the preserved full prior review coverage."""
from pathlib import Path
ROOT=Path(__file__).resolve().parent
PRIOR=ROOT.parent/'28-frozen-standards-review-01'
old=(PRIOR/'static_review.py').read_text(encoding='utf-8-sig')
old=old.replace("import subprocess\n", "import subprocess\nimport zipfile\n")
old=old.replace("BASE = '0a613289d983711d7637fb99857ee0333b0a1c53'", "BASE = '105a1cf53e72abccb047e2f1a5a1cf141d8980ae'")
old=old.replace("SOURCE = '105a1cf53e72abccb047e2f1a5a1cf141d8980ae'", "SOURCE = '815294edb4befd6717a412c9fe48deac84157b4a'")
old=old.replace("check('four committed source steps', len(git('rev-list', BASE + '..' + SOURCE).decode().splitlines()) == 4)", "check('one committed pre-capture correction', len(git('rev-list', BASE + '..' + SOURCE).decode().splitlines()) == 1)")
old=old.replace("protocol = load('docs/mainline/28-negative-engineering-protocol-v1.json')", "protocol = load('docs/mainline/28-negative-engineering-protocol-v2.json')")
old=old[:old.index('# AST-only schema witness.')]
new=r'''
# Corrected failure-event validation against the unchanged runtime audit schema.
intervention_tree=parsed['src/aegis_dc/intervention_execution.py']
audit_assignment=next(n for n in ast.walk(intervention_tree) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='audit' for t in n.targets) and isinstance(n.value,ast.Call) and isinstance(n.value.func,ast.Name) and n.value.func.id=='dict')
audit_keys={kw.arg for kw in audit_assignment.value.keywords}
conditional_effect=next(n for n in ast.walk(intervention_tree) if isinstance(n,ast.If) and ast.unparse(n.test)=='reason is None' and any(isinstance(child,ast.Call) and isinstance(child.func,ast.Attribute) and ast.unparse(child.func)=='audit.update' for child in ast.walk(n)))
update=next(n for n in ast.walk(conditional_effect) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and ast.unparse(n.func)=='audit.update')
success_write_keys={kw.arg for kw in update.keywords}
check('unchanged failed runtime audit has exactly six fields',audit_keys=={'task_id','operation_id','observed_at_s','task_status','outcome','reason'})
check('unchanged successful effect adds exactly five write fields', success_write_keys=={'applied_at_s','parameter_id','old_value','new_value','effect_scope'})
late_check=function(checks_tree,'too_late')
check('closed STD-28-01: no indexing an absent success-write field',not [n for n in ast.walk(late_check) if isinstance(n,ast.Subscript) and isinstance(n.value,ast.Name) and n.value.id=='effect' and isinstance(n.slice,ast.Constant) and n.slice.value in success_write_keys])
absence=next(n for n in ast.walk(late_check) if isinstance(n,ast.UnaryOp) and isinstance(n.op,ast.Not) and isinstance(n.operand,ast.BinOp) and isinstance(n.operand.op,ast.BitAnd) and isinstance(n.operand.left,ast.Set))
check('all five success-write fields strictly absent', {item.value for item in absence.operand.left.elts}==success_write_keys and ast.unparse(absence.operand.right)=='set(effect)')
late_text=ast.unparse(late_check)
for expected in ["effect['outcome'] == 'NO_EFFECT'", "effect['reason'] == 'actual_work_not_completed'", "effect['task_status'] == 'aborted'", "effect['observed_at_s'] == 3", "feedback['outcome'] == 'NO_EFFECT'", "feedback['reason'] == effect['reason']", "feedback['observed_at_s'] == 3", "feedback['arrived_at_s'] == 3.5", "not feedback['risk_closed']"]:
    check('corrected saved abort witness '+expected, expected in late_text)
check('aborted task cannot gain a physical event', "row['kind'] != 'completed_research_intervention'" in late_text and "row['domains']['it_service']['delivered'] == 0.25" in late_text)
check('late open status still reflects delayed failure feedback', "['OPEN_UNCONFIRMED', 'OPEN_ACTION_FAILED']" in late_text)

# Current full source inherits the complete, unchanged runtime/input boundary.
prior_root=ROOT.parent/'28-frozen-standards-review-01'
prior_seal_raw=(prior_root/'delivery-manifest.json').read_bytes()
PRIOR_SEAL='7e1e436d1ea78dcd3408f334ce30cc46ca395c3a96ed222e2521cbff66495e59'
check('prior01 root seal remains exact',sha256(prior_seal_raw).hexdigest()==PRIOR_SEAL)
prior_seal=json.loads(prior_seal_raw)
prior_files={p.relative_to(prior_root).as_posix() for p in prior_root.rglob('*') if p.is_file()}
check('prior01 root has no new/unsealed files',prior_files==set(prior_seal['artifacts'])|{'delivery-manifest.json'})
for path,pin in prior_seal['artifacts'].items():
    raw=(prior_root/path).read_bytes()
    check('prior01 immutable member '+path,sha256(raw).hexdigest()==pin['sha256'] and len(raw)==pin['bytes'])
prior_report=json.loads((prior_root/'review.json').read_bytes())
check('prior failure remains a failure',prior_report['status']=='FAIL_SOURCE_INTERFACE_MISMATCH' and prior_report['checks']==346 and [row['id'] for row in prior_report['unresolved']]==['STD-28-01'])
runtime_paths=[p for p in all_paths if p.startswith('src/') and p.endswith('.py')]
check('all 67 runtime files retained',len(runtime_paths)==67)
for path in runtime_paths:
    check('runtime unchanged from105 '+path,(FIXED/path).read_bytes()==git('show',BASE+':'+path))
immutable_paths=[p for p in scope['exported_paths'] if p.startswith('evidence/mainline/engineering/28-negative-controls/reference')]
immutable_paths += ['docs/mainline/28-negative-engineering-protocol-v1.json','docs/mainline/28-negative-controls-contract.md','scripts/prepare_negative_control_inputs.py','scripts/prepare_negative_control_inputs_v2.py','scripts/prepare_negative_control_workforce.py']
for path in sorted(set(immutable_paths)):
    check('old frozen input/tool/protocol retained '+path,(FIXED/path).read_bytes()==git('show',BASE+':'+path))
old_protocol=load('docs/mainline/28-negative-engineering-protocol-v1.json')
for key,value in old_protocol.items():
    if key not in {'schema','output','tools'}:
        check('unchanged protocol criterion '+key,protocol[key]==value)
check('new frozen protocol v2 and output02',protocol['schema']=='aegisdc-negative-engineering-protocol-v2' and protocol['output']=='evidence/mainline/engineering/28-negative-controls/capture-20261107-02' and protocol['output']!=old_protocol['output'])
check('no committed formal capture01 or02',not [p for p in all_paths if p.startswith((old_protocol['output']+'/',protocol['output']+'/'))])
check('old unexecuted protocol explicitly retained',protocol['supersedes_unexecuted_source']==BASE and 'docs/mainline/28-negative-engineering-protocol-v1.json' in protocol['retained_context'])
check('new archive authoring/verifier tool pinned',protocol['tools']==old_protocol['tools']+['scripts/preserve_negative_control_reviews.py'])
for path in ['scripts/negative_control_delivery.py','scripts/check_negative_control_preflight.py']:
    tree=parsed[path]
    assignment=next(n for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='PROTOCOL' for t in n.targets))
    check('entry point uses protocol v2 '+path,isinstance(assignment.value,ast.Constant) and assignment.value.value=='docs/mainline/28-negative-engineering-protocol-v2.json')

# Recursively validate the retained failed-review package against its fixed seals.
package='evidence/mainline/engineering/28-negative-controls/pre-capture-review-01/'
package_paths={p for p in all_paths if p.startswith(package)}
check('retained review durable set exactly four',package_paths==set(protocol['retained_failed_reviews']) and {Path(p).name for p in package_paths}=={'declaration.json','members.json','originals.zip','receipt.json'})
declaration=load(package+'declaration.json')
receipt=load(package+'receipt.json')
members=load(package+'members.json')
check('preservation keeps failed classification',declaration['classification']=='FAILED_SOURCE_REVIEWS_BEFORE_ANY_CASE_EXECUTION' and receipt['status']=='PRESERVED_NOT_A_PASS' and receipt['source']==BASE and receipt['new_physical_calls']==0)
check('preservation roots explicitly declared',set(declaration['artifacts'])==set(receipt['artifacts'])=={'declaration.json','members.json','originals.zip'} and declaration['terminal']=='receipt.json')
check('preservation tool exact hash',receipt['authoring_tool_sha256']==file_hash(FIXED/'scripts/preserve_negative_control_reviews.py'))
for name,identity in receipt['artifacts'].items():
    check('retained package original hash '+name,file_hash(FIXED/(package+name))==identity)
check('both fixed original seals declared',protocol['retained_review_seal_sha256']=={'Spec/manifest.json':'c4f6e3395814af69ecfe8762190c01c5ea7efc96071c2c25e0089748b6b8d40a','Standards/delivery-manifest.json':PRIOR_SEAL} and declaration['seals']=={'Spec':'manifest.json','Standards':'delivery-manifest.json'})
review_archive=FIXED/(package+'originals.zip')
with zipfile.ZipFile(review_archive) as archive:
    names=archive.namelist()
    check('archive 222 original unique files',len(names)==len(set(names))==len(members)==222 and set(names)==set(members)==set(declaration['members']))
    check('archive members safe relative paths',all(not Path(name).is_absolute() and '..' not in Path(name).parts for name in names))
    for name,pin in members.items():
        raw=archive.read(name)
        check('archived original SHA and bytes '+name,sha256(raw).hexdigest()==pin['sha256'] and len(raw)==pin['bytes'])
    expected_names=set()
    for axis,seal_name in declaration['seals'].items():
        seal_path=axis+'/'+seal_name
        raw=archive.read(seal_path)
        check(axis+' original seal fixed SHA',sha256(raw).hexdigest()==protocol['retained_review_seal_sha256'][seal_path])
        seal=json.loads(raw)
        report=json.loads(archive.read(axis+'/review.json'))
        check(axis+' archived failure not promoted',report['axis']==axis and report['source']==BASE and report['status'].startswith('FAIL') and bool(report['unresolved']) and report['checks']>0)
        expected_names.add(seal_path)
        for name,pin in seal['artifacts'].items():
            archive_name=axis+'/'+name
            check(axis+' recursive seal member '+name,members[archive_name]==pin)
            expected_names.add(archive_name)
    check('recursive seals cover archive without extras',set(names)==expected_names)
    check('Standards prior verdict byte-identical',archive.read('Standards/review.json')==(prior_root/'review.json').read_bytes())
    for name in prior_files:
        check('Standards archived prior01 exact '+name,archive.read('Standards/'+name)==(prior_root/name).read_bytes())

pins_text=ast.unparse(function(capture_tree,'pins'))
check('retained review root pinned in capture identities',"retained_review=protocol['retained_failed_reviews']" in pins_text)
check('original protocol/context pinned in capture inputs',"*protocol['retained_context']" in pins_text)
check('capture recursively validates retained reviews',"verify_preserved_reviews()" in pins_text and "old_review['source'] == protocol['supersedes_unexecuted_source']" in pins_text and "old_review['members'] == 222" in pins_text)
check('capture independently enforces fixed old seal SHA',"protocol['retained_review_seal_sha256'].items()" in pins_text and "digest(archive.read(name)) == sha" in pins_text)
check('capture retained package durable equality has no broad waiver',"durable(review_paths[0].parent) == {path.name for path in review_paths}" in pins_text)
archive_tree=parsed['scripts/preserve_negative_control_reviews.py']
check('archive helper no application imports',not [n for n in ast.walk(archive_tree) if isinstance(n,ast.ImportFrom) and (n.module or '').startswith('aegis_dc')])
archive_verify=ast.unparse(function(archive_tree,'verify'))
check('archive helper verifies every declared byte and size',"digest(raw) == identity['sha256']" in archive_verify and "len(raw) == identity['bytes']" in archive_verify)
check('archive helper recursively binds original review members',"members[f'{axis}/{name}'] == identity" in archive_verify)
check('archive helper retains unresolved original verdicts',"report['unresolved']" in archive_verify)

# Reinspection of the saved verification call graph: no runtime application seam.
function_tables={key:{n.name:n for n in tree.body if isinstance(n,ast.FunctionDef)} for key,tree in parsed.items() if key in {'scripts/negative_control_delivery.py','scripts/negative_control_checks.py','scripts/inspection_delivery.py','scripts/preserve_negative_control_reviews.py'}}
module_aliases={
 'scripts/negative_control_delivery.py':{'pins':('scripts/negative_control_delivery.py','pins'),'git':('scripts/inspection_delivery.py','git'),'read':('scripts/inspection_delivery.py','read'),'require':('scripts/inspection_delivery.py','require'),'durable':('scripts/inspection_delivery.py','durable'),'digest':('scripts/inspection_delivery.py','digest'),'hashes':('scripts/inspection_delivery.py','hashes'),'check_case':('scripts/negative_control_checks.py','check_case'),'paired':('scripts/negative_control_checks.py','paired'),'check_review_archive':('scripts/negative_control_delivery.py','check_review_archive'),'verify_preserved_reviews':('scripts/preserve_negative_control_reviews.py','verify')},
 'scripts/negative_control_checks.py':{name:('scripts/inspection_delivery.py',name) for name in ('read','require','digest')},
 'scripts/inspection_delivery.py':{},
 'scripts/preserve_negative_control_reviews.py':{}
}
pending=[('scripts/negative_control_delivery.py','verify')]
seen=set()
while pending:
    module,name=pending.pop()
    if (module,name) in seen:
        continue
    seen.add((module,name))
    node=function_tables[module][name]
    check('saved-only reachable function has no application import '+module+':'+name,not [n for n in ast.walk(node) if isinstance(n,ast.ImportFrom) and (n.module or '').startswith('aegis_dc')])
    for call in ast.walk(node):
        if not isinstance(call,ast.Call) or not isinstance(call.func,ast.Name):
            continue
        callee=call.func.id
        if callee in module_aliases[module]:
            pending.append(module_aliases[module][callee])
        elif callee in function_tables[module]:
            pending.append((module,callee))
check('saved-only reachable closure/plant/selector forbidden sites absent',not any(name in {'simulate_scenario','assess_closure','prepare_intervention','next_frame','select_dispatch'} for _,name in seen))

inheritance={
 'prior_review_source':BASE,'current_source':SOURCE,'prior_review_status':prior_report['status'],
 'prior_review_checks':346,'prior_manifest_sha256':PRIOR_SEAL,'prior_directory_unchanged':True,
 'current_full_scope_revalidated':True,'runtime_files_unchanged':67,
 'resolution':[{'id':'STD-28-01','status':'CLOSED_AT_NEW_FIXED_SOURCE','evidence':'AST confirms no success-write-field indexing, strict absence of all five fields, and exact NO_EFFECT/actual_work_not_completed/aborted/3s/3.5s conditions.'}],
 'inherited_limits':['Static review only; no physical thermal trajectory acceptance, project tests, or scientific gain claimed.','The original FAIL remains sealed and cannot satisfy the new execution review gate.']
}
(ROOT/'prior-review-inheritance.json').write_text(json.dumps(inheritance,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
result={
 'status':'PASS_STATIC_DECLARATIONS_AND_TOOLING','axis':'Standards','source':SOURCE,'base':BASE,
 'checks':len(checks),'checks_passed':len(checks),'checks_failed':0,'unresolved':[],
 'application_imports':0,'physical_calls':0,'selector_calls':0,'closure_calls':0,'test_calls':0,'full_calls':0,'repository_authoring_or_verification_script_calls':0,
 'checks_detail':checks,'findings':[],
 'heuristics':{'baseline':'Fowler fixed baseline supplied by root','actionable_findings':[],'suppressed':[{'smell':'Duplicated Code','reason':'Retained original/corrected input-authoring versions and archived review source copies are explicitly required immutable evidence.'}]},
 'limits':['Full fixed-source preparation/tool review only. The current source may satisfy its Standards pre-capture review gate; no numeric runtime/ticket28/M4/scientific acceptance is claimed.','No repository script was imported or invoked. Saved helper reachability was inspected through AST only.']
}
(ROOT/'static-checks.json').write_text(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in result.items() if k not in {'checks_detail','heuristics'}},ensure_ascii=False))
'''
(ROOT/'static_review.py').write_text(old+new,encoding='utf-8',newline='\n')
print('Prepared independent full-scope static checker in review02; no repository script invoked.')
