"""Independent fixed-object Standards inspection; never imports project modules."""
import ast
from copy import deepcopy
from fractions import Fraction
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parent
FIXED = ROOT / 'fixed-source'
REPO = Path(r'C:\Users\Donson\.codex\worktrees\mainline28-negative-controls\Renly')
BASE = '105a1cf53e72abccb047e2f1a5a1cf141d8980ae'
SOURCE = '815294edb4befd6717a412c9fe48deac84157b4a'
checks = []

def check(label, condition, detail=None):
    row = {'id': len(checks) + 1, 'label': label, 'passed': bool(condition)}
    if detail is not None:
        row['detail'] = detail
    checks.append(row)
    if not condition:
        raise AssertionError(label)

def git(*args):
    result = subprocess.run(['git', '-C', str(REPO), *args], check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    return result.stdout

def reject_duplicates(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError('Duplicate JSON key: ' + key)
        result[key] = value
    return result

def load(relative):
    return json.loads((FIXED / relative).read_bytes(), object_pairs_hook=reject_duplicates,
                      parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)))

def file_hash(path):
    return sha256(path.read_bytes()).hexdigest()

def frac(value):
    return Fraction(value['numerator'], value['denominator'])

def function(tree, name):
    return next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == name)

def calls(tree, name):
    return [node for node in ast.walk(tree) if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id == name]

scope = json.loads((ROOT / 'scope.json').read_bytes())
check('source resolves exactly', git('rev-parse', SOURCE + '^{commit}').decode().strip() == SOURCE)
check('base resolves exactly', git('rev-parse', BASE + '^{commit}').decode().strip() == BASE)
check('three-dot merge base is exact base', git('merge-base', BASE, SOURCE).decode().strip() == BASE)
changed = git('diff', '--name-only', BASE + '...' + SOURCE).decode().splitlines()
check('review diff nonempty', bool(changed))
check('no runtime kernel or test changes', not any(p.startswith(('src/', 'tests/')) for p in changed))
check('one committed pre-capture correction', len(git('rev-list', BASE + '..' + SOURCE).decode().splitlines()) == 1)
check('initial worktree clean', (ROOT / 'worktree-state.txt').read_bytes() == b'')
all_paths = git('ls-tree', '-r', '--name-only', SOURCE).decode().splitlines()
check('all nested AGENTS located', [p for p in all_paths if Path(p).name == 'AGENTS.md'] == ['AGENTS.md'])
check('no CONTRIBUTING or CODING_STANDARDS source omitted', not [p for p in all_paths if Path(p).name.lower() in {'contributing.md', 'coding_standards.md'}])
for relative in scope['exported_paths']:
    check('fixed Git export ' + relative, (FIXED / relative).read_bytes() == git('show', SOURCE + ':' + relative))
check('all changed paths exported', set(changed) <= set(scope['exported_paths']))
parsed = {}
for path in sorted(FIXED.rglob('*.py')):
    relative = path.relative_to(FIXED).as_posix()
    parsed[relative] = ast.parse(path.read_bytes(), filename=relative)
    check('AST parse ' + relative, True)
for path in sorted(FIXED.rglob('*.json')):
    load(path.relative_to(FIXED).as_posix())
    check('strict JSON parse ' + path.relative_to(FIXED).as_posix(), True)

protocol = load('docs/mainline/28-negative-engineering-protocol-v2.json')
doc = load(protocol['input'])
cases = doc['cases']
literals = load(protocol['literals'])
reference = load('evidence/mainline/engineering/27-full-loop/reference/online-loop-v2.json')
check('four fixed ordered cases', list(cases) == protocol['cases'] == ['normal', 'false_report', 'local_protection', 'too_late'])
check('engineering classification', doc['classification'] == 'FINITE_FULL_FACILITY_NEGATIVE_ENGINEERING_NOT_EFFECT_COMPARISON' and protocol['research_trials'] == 0)
check('protocol requires independent fixed review', protocol['status'] == 'FROZEN_ENGINEERING_REQUIRES_INDEPENDENT_FIXED_SOURCE_REVIEW')
check('physical integration budget', protocol['total_integrations'] == 4 and protocol['expected_counters']['attempted_integrations'] == protocol['expected_counters']['completed_integrations'] == 4)
check('simulated budget exact rational', sum(Fraction(str(c['duration_s'])) for c in cases.values()) == Fraction(43, 2) == frac(literals['total_simulated_duration_s']) and protocol['total_simulated_duration_s'] == 21.5)
check('online decisions budget', protocol['online_decisions_s'] == [1, 3, 4.5, 4.75, 5.5, 6.5, 7] and literals['public_online_decisions'] == 14)
check('additional frame budgets', protocol['expected_counters']['late_preparation_frames'] == 4 and protocol['expected_counters']['late_preparation_assessments'] == 1 and protocol['expected_counters']['late_closure_assessments'] == 2 and protocol['expected_counters']['protection_initial_frames'] == 1)
expected_domains = {'power', 'backup', 'facility_cooling', 'equipment_environment', 'it_service', 'control_monitoring', 'space_access', 'people_tools_work'}
expected_graphs = {'physical', 'functional', 'control_information', 'access'}
for name, case in cases.items():
    model = case['model']
    entities = {e['id']: e for e in model['entities']}
    params = {p['id']: p for p in model['parameters']}
    check(name + ' unique entity IDs', len(entities) == len(model['entities']))
    check(name + ' unique parameter IDs', len(params) == len(model['parameters']))
    check(name + ' facility identity', model['id'] == doc['facility_id'] == reference['model']['id'])
    check(name + ' eight operational domains', {d['id'] for d in model['domains']} == expected_domains)
    check(name + ' four relations unchanged', set(model['graphs']) == expected_graphs and model['graphs'] == reference['model']['graphs'])
    check(name + ' entity identities retained', set(entities) == {e['id'] for e in reference['model']['entities']})
    check(name + ' domain members have shared identities', all(set(d['entity_ids']) <= set(entities) for d in model['domains']))
    check(name + ' graph endpoints have shared identities', all(edge['from'] in entities and edge['to'] in entities for edges in model['graphs'].values() for edge in edges))
    check(name + ' source/assumption boundary retained', bool(model['site_gaps']) and bool(model['assumptions']) and bool(model['sources']))
    check(name + ' entity provenance explicit', all(e.get('basis') and e.get('source_note') and e.get('source_refs') for e in model['entities']))
    check(name + ' all parameter SI/provenance/ranges explicit', all(p.get('unit') and p.get('quantity') and p.get('basis') and p.get('source_note') and p.get('source_refs') and p['valid_range'][0] <= p['value'] <= p['valid_range'][1] for p in model['parameters']))
    check(name + ' maximum step fixed', case['maximum_step_s'] == protocol['maximum_step_s'] == .01)
    check(name + ' property table pin', file_hash(FIXED / model['runtime']['property_table']) == model['runtime']['property_sha256'])
    check(name + ' existing protection profile retained', model['runtime']['local_control_profile'] == reference['model']['runtime']['local_control_profile'])

normal = deepcopy(cases['normal']['replay_inputs'])
false = deepcopy(cases['false_report']['replay_inputs'])
normal_records = normal['dispatch_program']['evidence_ledger'].pop('records')
false_records = false['dispatch_program']['evidence_ledger'].pop('records')
check('normal false physical inputs identical', cases['normal']['model'] == cases['false_report']['model'])
check('normal false all public rules identical except records', normal == false and normal_records == [] and len(false_records) == 2)
check('manual report and review delayed', [(r['observed_at_s'], r['arrived_at_s']) for r in false_records] == [(1.5, 3), (6.75, 7)])
check('manual records share original provenance once', len({r['provenance']['origin_id'] for r in false_records}) == 2 and all(r['provenance']['copied_from_record_id'] is None for r in false_records))
for name in ('normal', 'false_report'):
    program = cases[name]['replay_inputs']['dispatch_program']
    policy = program['policy_program']
    closure = program['closure_program']
    rule, = closure['profile']['rules']
    check(name + ' public model consistent full demand table', policy['options']['catalog'] == closure['risk_catalog'] and closure['risk_catalog']['demand'] == [{'start_s': 0, 'end_s': 6, 'rate': .5}])
    check(name + ' exact intervention declaration equality', policy['intervention_declaration'] == program['intervention_program'] == closure['intervention_declaration'])
    check(name + ' exact public observation profile equality', policy['evidence_projection']['inspection_profile'] == program['inspection_program']['profile'] and policy['evidence_projection']['background_sensor_profile'] == program['sensor_program']['profile'])
    check(name + ' closure demands two actual roles', {r['role'] for r in rule['checks']} == {'condition', 'service'} and rule['required_samples'] == 2 and rule['minimum_span_s'] == 1)
    grant, = closure['profile']['authorizations']
    channel, = closure['profile']['review_channels']
    review, = closure['profile']['false_alarm_reviews']
    check(name + ' scoped false alarm authority', grant['dispositions'] == ['FALSE_ALARM'] and channel['authorization_id'] == grant['id'] and channel['source_id'] == grant['source_id'] and channel['question_id'] in grant['question_ids'])
    check(name + ' four-sample review dossier fixed', review['supporting_record_ids'] == ['flow-transfer:0', 'flow-transfer:1', 'joint-service-transfer:0', 'joint-service-transfer:1'])
    check(name + ' prior external instructions only', program['evidence_ledger']['records'] == ([] if name == 'normal' else false_records))
    check(name + ' public nominal knowledge omits actual parameters', 'parameters' not in program['nominal_knowledge'] and 'boundary_events' not in program['nominal_knowledge'])
    check(name + ' separate physical event input empty', cases[name]['replay_inputs']['exogenous_events'] == cases[name]['replay_inputs']['action_commands'] == cases[name]['replay_inputs']['work_requests'] == [])

prior = Fraction(1, 100)
reported = prior * Fraction(3, 4) / (prior * Fraction(3, 4) + (1-prior)*Fraction(3, 100))
cleared = reported * Fraction(1, 5) / (reported * Fraction(1, 5) + (1-reported)*Fraction(9, 10))
check('independent Bayesian report literal', reported == frac(literals['false_report']['cooling_probability_after_report']) == Fraction(25, 124))
check('independent negative measurement literal', cleared == frac(literals['false_report']['cooling_probability_after_negative_handheld']) == Fraction(50, 941))
expected_literals = {
    'normal': [Fraction(29,8), Fraction(29,8), 0, 0, 0, 0],
    'false_report': [Fraction(29,8), Fraction(29,8), 0, 0, 1, Fraction(1,4)],
    'local_protection': [Fraction(9,4), Fraction(3,2), 1, 0, 0, 0],
    'too_late': [4, 1, 3, 1, Fraction(3,4), Fraction(1,4)],
}
metric_order = ['demand_service_unit_s','delivered_service_unit_s','normalized_deficit_s','travel_person_s','work_person_s','access_check_person_s']
for name, expected in expected_literals.items():
    for metric, value in zip(metric_order, expected):
        check(name + ' independent literal ' + metric, frac(literals[name][metric]) == value)

late = cases['too_late']
plan = late['public_preparation']
check('late evidence release times', plan['decision_times_s'] == [0, 1, 3.25, 4] and late['closure_assessment_times_s'] == [3.25, 4])
check('late private safety boundary isolated', late['boundary_events'][0]['time_s'] == 3 and late['boundary_events'][0]['parameter_id'] == 'it_access_permit' and 'boundary_events' not in plan and 'parameters' not in plan['nominal_knowledge'])
check('late current report only; no real sample invented', len(plan['evidence_ledger']['records']) == 1 and plan['evidence_ledger']['records'][0]['arrived_at_s'] == plan['issued_at_s'] == 1)
check('late actual/nominal worker and tool colocated', all(e['location_id'] == 'loc_control' for e in late['model']['entities'] if e['id'] in {'worker_it','tool_it_diagnostic'}) and all(e['nominal_location_id'] == 'loc_control' for e in plan['nominal_knowledge']['entities'] if e['id'] in {'worker_it','tool_it_diagnostic'}))
check('late action and closure share authority', late['closure_program']['intervention_declaration'] == late['intervention_program'])
check('late hypothetical clocks count partial work', frac(literals['too_late']['theoretical_earliest_completion_s']) == Fraction(13,4) and frac(literals['too_late']['work_person_s']) == 3-Fraction(9,4) and frac(literals['too_late']['terminal_feedback_arrives_s']) == Fraction(7,2))
idle = load(protocol['protection_workforce_input'])
check('idle workforce real empty declaration', idle['submissions'] == [] and idle['plan']['decision_times_s'] == [0] and idle['plan']['requests'] == [] and idle['evidence_ledger']['records'] == [])

for relative, author in [(protocol['preparation'],'scripts/prepare_negative_control_inputs_v2.py'), (protocol['protection_workforce_preparation'],'scripts/prepare_negative_control_workforce.py')]:
    prep = load(relative)
    check(relative + ' not executed classification', prep['status'] == 'PREPARED_NOT_EXECUTED' and prep['new_project_calls'] == 0)
    check(relative + ' authoring tool pin equality', prep['authoring_tool_sha256'] == file_hash(FIXED/author))
    for path, identity in prep['source_inputs'].items():
        check(relative + ' source pin ' + path, file_hash(FIXED/path) == identity)
    for path, identity in prep.get('outputs', prep.get('artifacts', {})).items():
        check(relative + ' output pin ' + path, file_hash((FIXED/relative).parent/path) == identity)
observation = load(protocol['retained_unexecuted_draft'][-1])
for filename, identity in observation['original_files'].items():
    path = 'evidence/mainline/engineering/28-negative-controls/reference/' + filename
    check('retained draft exact original ' + filename, file_hash(FIXED/path) == identity and (FIXED/path).read_bytes() == git('show','e76884c2:'+path))
check('retained old demand-table failure not rewritten', observation['actual_closure_demand'] != observation['expected_demand'] and observation['status'] == 'UNEXECUTED_INPUT_DRAFT_RETAINED')

capture_tree = parsed['scripts/negative_control_delivery.py']
checks_tree = parsed['scripts/negative_control_checks.py']
helper_tree = parsed['scripts/inspection_delivery.py']
verify = function(capture_tree, 'verify')
reviews = function(capture_tree, 'reviews')
execute = function(capture_tree, 'execute')
capture = function(capture_tree, 'capture')
check('capture single static simulate call site', len(calls(execute,'simulate_scenario')) == 1)
check('capture one fixed case loop', len([n for n in ast.walk(capture) if isinstance(n,ast.For) and ast.unparse(n.iter) == "protocol['cases']"]) == 1)
check('capture review gate before attempt directory', next(n.lineno for n in calls(capture,'reviews')) < next(n.lineno for n in ast.walk(capture) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='mkdir'))
review_text = ast.unparse(reviews)
check('independent axes and current-source gate present', "{'Spec', 'Standards'}" in review_text and "report.get('source', report.get('data')) == source" in review_text and "report['checks'] > 0" in review_text and "not report.get('unresolved')" in review_text)
check('review gate seals verdict and every declared member', "file.name in names" in review_text and "len(raw) == expected['bytes']" in review_text and "digest(raw) == expected['sha256']" in review_text)
check('saved-only verify has no application import', not [n for n in ast.walk(verify) if isinstance(n,(ast.Import,ast.ImportFrom))])
check('saved checks have no application import', not [n for n in ast.walk(checks_tree) if isinstance(n,ast.ImportFrom) and (n.module or '').startswith('aegis_dc')])
verify_text=ast.unparse(verify)
check('fresh committed delivery matches exact source pins', "pins(protocol, source) == receipt['pins']" in verify_text and 'group == hashes(delivery, group)' in verify_text and 'hashes(delivery, paths)' in verify_text)
check('durable declarations compared exactly', "set(receipt['artifacts']) == names" in verify_text and "durable(folder) == names | {'receipt.json'}" in verify_text)
check('source cache exclusions exact declared classes', protocol['excluded_runtime_caches'] == ['__pycache__','*.pyc','*.pyo'] and "p.suffix not in {'.pyc', '.pyo'}" in ast.unparse(function(helper_tree,'durable')))
check('no arbitrary artifact hash waiver', "for name, sha in receipt['artifacts'].items()" in verify_text and "digest((folder / name).read_bytes()) == sha" in verify_text)
check('attempt STARTED precedes execute and failure is preserved', next(n.lineno for n in ast.walk(capture) if isinstance(n,ast.Constant) and n.value=='STARTED') < next(n.lineno for n in calls(capture,'execute')) and any(isinstance(n,ast.Constant) and n.value=='FAILED' for n in ast.walk(capture)))
check('completion distinct from validation counters', "counters['completed_integrations'] += 1" in ast.unparse(execute) and "counters['validated_cases'] += 1" in ast.unparse(capture))
check('packet failures terminal FAIL, not review PASS', "status='FAIL'" in ast.unparse(capture) and "receipt['status'] == 'PASS'" in ast.unparse(capture) and 'finally:' in ast.unparse(capture))


# Corrected failure-event validation against the unchanged runtime audit schema.
intervention_tree=parsed['src/aegis_dc/intervention_execution.py']
audit_assignment=next(n for n in ast.walk(intervention_tree) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='audit' for t in n.targets) and isinstance(n.value,ast.Call) and isinstance(n.value.func,ast.Name) and n.value.func.id=='dict')
audit_keys={kw.arg for kw in audit_assignment.value.keywords}
conditional_effect=next(n for n in ast.walk(intervention_tree) if isinstance(n,ast.If) and ast.unparse(n.test)=='reason is None' and any(isinstance(child,ast.Call) and isinstance(child.func,ast.Attribute) and ast.unparse(child.func)=='audit.update' for child in ast.walk(n)))
update=next(n for n in ast.walk(conditional_effect) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and ast.unparse(n.func)=='audit.update')
success_write_keys={kw.arg for kw in update.keywords}
check('unchanged failed runtime audit has exactly six fields',audit_keys=={'task_id','operation_id','observed_at_s','task_status','outcome','reason'})
check('unchanged successful effect adds exactly five write fields', success_write_keys=={'applied_at_s','parameter_id','old_value','new_value','effect_scope'})
late_check=function(checks_tree,'too_late')
check('closed STD-28-01: no indexing an absent success-write field',not [n for n in ast.walk(late_check) if isinstance(n,ast.Subscript) and isinstance(n.value,ast.Name) and n.value.id=='effect' and isinstance(n.slice,ast.Constant) and n.slice.value in success_write_keys])
absence=next(n for n in ast.walk(late_check) if isinstance(n,ast.UnaryOp) and isinstance(n.op,ast.Not) and isinstance(n.operand,ast.BinOp) and isinstance(n.operand.op,ast.BitAnd) and isinstance(n.operand.left,ast.Set))
check('all five success-write fields strictly absent', {item.value for item in absence.operand.left.elts}==success_write_keys and ast.unparse(absence.operand.right)=='set(effect)')
late_text=ast.unparse(late_check)
for expected in ["effect['outcome'] == 'NO_EFFECT'", "effect['reason'] == 'actual_work_not_completed'", "effect['task_status'] == 'aborted'", "effect['observed_at_s'] == 3", "feedback['outcome'] == 'NO_EFFECT'", "feedback['reason'] == effect['reason']", "feedback['observed_at_s'] == 3", "feedback['arrived_at_s'] == 3.5", "not feedback['risk_closed']"]:
    check('corrected saved abort witness '+expected, expected in late_text)
check('aborted task cannot gain a physical event', "row['kind'] != 'completed_research_intervention'" in late_text and "row['domains']['it_service']['delivered'] == 0.25" in late_text)
check('late open status still reflects delayed failure feedback', "['OPEN_UNCONFIRMED', 'OPEN_ACTION_FAILED']" in late_text)

# Current full source inherits the complete, unchanged runtime/input boundary.
prior_root=ROOT.parent/'28-frozen-standards-review-01'
prior_seal_raw=(prior_root/'delivery-manifest.json').read_bytes()
PRIOR_SEAL='7e1e436d1ea78dcd3408f334ce30cc46ca395c3a96ed222e2521cbff66495e59'
check('prior01 root seal remains exact',sha256(prior_seal_raw).hexdigest()==PRIOR_SEAL)
prior_seal=json.loads(prior_seal_raw)
prior_files={p.relative_to(prior_root).as_posix() for p in prior_root.rglob('*') if p.is_file()}
check('prior01 root has no new/unsealed files',prior_files==set(prior_seal['artifacts'])|{'delivery-manifest.json'})
for path,pin in prior_seal['artifacts'].items():
    raw=(prior_root/path).read_bytes()
    check('prior01 immutable member '+path,sha256(raw).hexdigest()==pin['sha256'] and len(raw)==pin['bytes'])
prior_report=json.loads((prior_root/'review.json').read_bytes())
check('prior failure remains a failure',prior_report['status']=='FAIL_SOURCE_INTERFACE_MISMATCH' and prior_report['checks']==346 and [row['id'] for row in prior_report['unresolved']]==['STD-28-01'])
runtime_paths=[p for p in all_paths if p.startswith('src/') and p.endswith('.py')]
check('all 67 runtime files retained',len(runtime_paths)==67)
for path in runtime_paths:
    check('runtime unchanged from105 '+path,(FIXED/path).read_bytes()==git('show',BASE+':'+path))
immutable_paths=[p for p in scope['exported_paths'] if p.startswith('evidence/mainline/engineering/28-negative-controls/reference')]
immutable_paths += ['docs/mainline/28-negative-engineering-protocol-v1.json','docs/mainline/28-negative-controls-contract.md','scripts/prepare_negative_control_inputs.py','scripts/prepare_negative_control_inputs_v2.py','scripts/prepare_negative_control_workforce.py']
for path in sorted(set(immutable_paths)):
    check('old frozen input/tool/protocol retained '+path,(FIXED/path).read_bytes()==git('show',BASE+':'+path))
old_protocol=load('docs/mainline/28-negative-engineering-protocol-v1.json')
for key,value in old_protocol.items():
    if key not in {'schema','output','tools'}:
        check('unchanged protocol criterion '+key,protocol[key]==value)
check('new frozen protocol v2 and output02',protocol['schema']=='aegisdc-negative-engineering-protocol-v2' and protocol['output']=='evidence/mainline/engineering/28-negative-controls/capture-20261107-02' and protocol['output']!=old_protocol['output'])
check('no committed formal capture01 or02',not [p for p in all_paths if p.startswith((old_protocol['output']+'/',protocol['output']+'/'))])
check('old unexecuted protocol explicitly retained',protocol['supersedes_unexecuted_source']==BASE and 'docs/mainline/28-negative-engineering-protocol-v1.json' in protocol['retained_context'])
check('new archive authoring/verifier tool pinned',protocol['tools']==old_protocol['tools']+['scripts/preserve_negative_control_reviews.py'])
for path in ['scripts/negative_control_delivery.py','scripts/check_negative_control_preflight.py']:
    tree=parsed[path]
    assignment=next(n for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='PROTOCOL' for t in n.targets))
    check('entry point uses protocol v2 '+path,isinstance(assignment.value,ast.Constant) and assignment.value.value=='docs/mainline/28-negative-engineering-protocol-v2.json')

# Recursively validate the retained failed-review package against its fixed seals.
package='evidence/mainline/engineering/28-negative-controls/pre-capture-review-01/'
package_paths={p for p in all_paths if p.startswith(package)}
check('retained review durable set exactly four',package_paths==set(protocol['retained_failed_reviews']) and {Path(p).name for p in package_paths}=={'declaration.json','members.json','originals.zip','receipt.json'})
declaration=load(package+'declaration.json')
receipt=load(package+'receipt.json')
members=load(package+'members.json')
check('preservation keeps failed classification',declaration['classification']=='FAILED_SOURCE_REVIEWS_BEFORE_ANY_CASE_EXECUTION' and receipt['status']=='PRESERVED_NOT_A_PASS' and receipt['source']==BASE and receipt['new_physical_calls']==0)
check('preservation roots explicitly declared',set(declaration['artifacts'])==set(receipt['artifacts'])=={'declaration.json','members.json','originals.zip'} and declaration['terminal']=='receipt.json')
check('preservation tool exact hash',receipt['authoring_tool_sha256']==file_hash(FIXED/'scripts/preserve_negative_control_reviews.py'))
for name,identity in receipt['artifacts'].items():
    check('retained package original hash '+name,file_hash(FIXED/(package+name))==identity)
check('both fixed original seals declared',protocol['retained_review_seal_sha256']=={'Spec/manifest.json':'c4f6e3395814af69ecfe8762190c01c5ea7efc96071c2c25e0089748b6b8d40a','Standards/delivery-manifest.json':PRIOR_SEAL} and declaration['seals']=={'Spec':'manifest.json','Standards':'delivery-manifest.json'})
review_archive=FIXED/(package+'originals.zip')
with zipfile.ZipFile(review_archive) as archive:
    names=archive.namelist()
    check('archive 222 original unique files',len(names)==len(set(names))==len(members)==222 and set(names)==set(members)==set(declaration['members']))
    check('archive members safe relative paths',all(not Path(name).is_absolute() and '..' not in Path(name).parts for name in names))
    for name,pin in members.items():
        raw=archive.read(name)
        check('archived original SHA and bytes '+name,sha256(raw).hexdigest()==pin['sha256'] and len(raw)==pin['bytes'])
    expected_names=set()
    for axis,seal_name in declaration['seals'].items():
        seal_path=axis+'/'+seal_name
        raw=archive.read(seal_path)
        check(axis+' original seal fixed SHA',sha256(raw).hexdigest()==protocol['retained_review_seal_sha256'][seal_path])
        seal=json.loads(raw)
        report=json.loads(archive.read(axis+'/review.json'))
        check(axis+' archived failure not promoted',report['axis']==axis and report['source']==BASE and report['status']=={'Spec':'CHANGES_REQUESTED','Standards':'FAIL_SOURCE_INTERFACE_MISMATCH'}[axis] and bool(report['unresolved']) and report['checks']>0)
        expected_names.add(seal_path)
        for name,pin in seal['artifacts'].items():
            archive_name=axis+'/'+name
            check(axis+' recursive seal member '+name,members[archive_name]==pin)
            expected_names.add(archive_name)
    check('recursive seals cover archive without extras',set(names)==expected_names)
    check('Standards prior verdict byte-identical',archive.read('Standards/review.json')==(prior_root/'review.json').read_bytes())
    for name in prior_files:
        check('Standards archived prior01 exact '+name,archive.read('Standards/'+name)==(prior_root/name).read_bytes())

pins_text=ast.unparse(function(capture_tree,'pins'))
check('retained review root pinned in capture identities',"retained_review=protocol['retained_failed_reviews']" in pins_text)
check('original protocol/context pinned in capture inputs',"*protocol['retained_context']" in pins_text)
check('capture recursively validates retained reviews',"verify_preserved_reviews()" in pins_text and "old_review['source'] == protocol['supersedes_unexecuted_source']" in pins_text and "old_review['members'] == 222" in pins_text)
check('capture independently enforces fixed old seal SHA',"protocol['retained_review_seal_sha256'].items()" in pins_text and "digest(archive.read(name)) == sha" in pins_text)
check('capture retained package durable equality has no broad waiver',"durable(review_paths[0].parent) == {path.name for path in review_paths}" in pins_text)
archive_tree=parsed['scripts/preserve_negative_control_reviews.py']
check('archive helper no application imports',not [n for n in ast.walk(archive_tree) if isinstance(n,ast.ImportFrom) and (n.module or '').startswith('aegis_dc')])
archive_verify=ast.unparse(function(archive_tree,'verify'))
check('archive helper verifies every declared byte and size',"digest(raw) == identity['sha256']" in archive_verify and "len(raw) == identity['bytes']" in archive_verify)
check('archive helper recursively binds original review members',"members[f'{axis}/{name}'] == identity" in archive_verify)
check('archive helper retains unresolved original verdicts',"report['unresolved']" in archive_verify)

# Reinspection of the saved verification call graph: no runtime application seam.
function_tables={key:{n.name:n for n in tree.body if isinstance(n,ast.FunctionDef)} for key,tree in parsed.items() if key in {'scripts/negative_control_delivery.py','scripts/negative_control_checks.py','scripts/inspection_delivery.py','scripts/preserve_negative_control_reviews.py'}}
module_aliases={
 'scripts/negative_control_delivery.py':{'pins':('scripts/negative_control_delivery.py','pins'),'git':('scripts/inspection_delivery.py','git'),'read':('scripts/inspection_delivery.py','read'),'require':('scripts/inspection_delivery.py','require'),'durable':('scripts/inspection_delivery.py','durable'),'digest':('scripts/inspection_delivery.py','digest'),'hashes':('scripts/inspection_delivery.py','hashes'),'check_case':('scripts/negative_control_checks.py','check_case'),'paired':('scripts/negative_control_checks.py','paired'),'check_review_archive':('scripts/negative_control_delivery.py','check_review_archive'),'verify_preserved_reviews':('scripts/preserve_negative_control_reviews.py','verify')},
 'scripts/negative_control_checks.py':{name:('scripts/inspection_delivery.py',name) for name in ('read','require','digest')},
 'scripts/inspection_delivery.py':{},
 'scripts/preserve_negative_control_reviews.py':{}
}
pending=[('scripts/negative_control_delivery.py','verify')]
seen=set()
while pending:
    module,name=pending.pop()
    if (module,name) in seen:
        continue
    seen.add((module,name))
    node=function_tables[module][name]
    check('saved-only reachable function has no application import '+module+':'+name,not [n for n in ast.walk(node) if isinstance(n,ast.ImportFrom) and (n.module or '').startswith('aegis_dc')])
    for call in ast.walk(node):
        if not isinstance(call,ast.Call) or not isinstance(call.func,ast.Name):
            continue
        callee=call.func.id
        if callee in module_aliases[module]:
            pending.append(module_aliases[module][callee])
        elif callee in function_tables[module]:
            pending.append((module,callee))
check('saved-only reachable closure/plant/selector forbidden sites absent',not any(name in {'simulate_scenario','assess_closure','prepare_intervention','next_frame','select_dispatch'} for _,name in seen))

inheritance={
 'prior_review_source':BASE,'current_source':SOURCE,'prior_review_status':prior_report['status'],
 'prior_review_checks':346,'prior_manifest_sha256':PRIOR_SEAL,'prior_directory_unchanged':True,
 'current_full_scope_revalidated':True,'runtime_files_unchanged':67,
 'resolution':[{'id':'STD-28-01','status':'CLOSED_AT_NEW_FIXED_SOURCE','evidence':'AST confirms no success-write-field indexing, strict absence of all five fields, and exact NO_EFFECT/actual_work_not_completed/aborted/3s/3.5s conditions.'}],
 'inherited_limits':['Static review only; no physical thermal trajectory acceptance, project tests, or scientific gain claimed.','The original FAIL remains sealed and cannot satisfy the new execution review gate.']
}
(ROOT/'prior-review-inheritance.json').write_text(json.dumps(inheritance,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
result={
 'status':'PASS_STATIC_DECLARATIONS_AND_TOOLING','axis':'Standards','source':SOURCE,'base':BASE,
 'checks':len(checks),'checks_passed':len(checks),'checks_failed':0,'unresolved':[],
 'application_imports':0,'physical_calls':0,'selector_calls':0,'closure_calls':0,'test_calls':0,'full_calls':0,'repository_authoring_or_verification_script_calls':0,
 'checks_detail':checks,'findings':[],
 'heuristics':{'baseline':'Fowler fixed baseline supplied by root','actionable_findings':[],'suppressed':[{'smell':'Duplicated Code','reason':'Retained original/corrected input-authoring versions and archived review source copies are explicitly required immutable evidence.'}]},
 'limits':['Full fixed-source preparation/tool review only. The current source may satisfy its Standards pre-capture review gate; no numeric runtime/ticket28/M4/scientific acceptance is claimed.','No repository script was imported or invoked. Saved helper reachability was inspected through AST only.']
}
(ROOT/'static-checks.json').write_text(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in result.items() if k not in {'checks_detail','heuristics'}},ensure_ascii=False))
