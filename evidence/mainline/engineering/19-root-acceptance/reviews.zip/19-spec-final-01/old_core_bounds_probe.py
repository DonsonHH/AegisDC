from pathlib import Path
import sys,json,copy,subprocess
from hashlib import sha256
out=Path('.work/19-spec-final-01').resolve();root=out.parents[1];sys.path.insert(0,str(out/'export/src'));pin='46a0b0906cb8b38cc6fc911bb106460e610a5319'
paths=subprocess.check_output(['git','ls-tree','-r','--name-only',pin,'src','configs'],cwd=root,text=True).splitlines()
def guard():
 result={}
 for p in paths:
  raw=(out/'export'/p).read_bytes(); assert raw==subprocess.check_output(['git','show',pin+':'+p],cwd=root);result[p]=sha256(raw).hexdigest()
 return result
before=guard()
from aegis_dc.risk_scenarios import assess_risks
frame=json.loads((out/'public-frame.json').read_bytes());model=json.loads((out/'export/configs/full-facility-belief-model-v1.json').read_bytes());cat=json.loads((out/'export/configs/full-facility-risk-scenarios-v1.json').read_bytes())
cat['questions'][0]['consequence_bounds']['service_deficit_time_s']['interval']=[0,0]
cat['questions'][0]['consequence_bounds']['unserved_service_unit_s']['interval']=[0,0]
result=assess_risks(frame,model,cat);q=result['questions'][0]
after=guard();assert before==after
packet=dict(core=pin,consequence_bounds=q['consequence_bounds'],probability=q['probability'],reported_consequences=q['consequences'],before=before,after=after,source_unchanged=before==after)
(out/'old-core-bounds-probe.json').write_text(json.dumps(packet,indent=2)+chr(10),encoding='utf-8')
print(json.dumps({k:v for k,v in packet.items() if k not in ['before','after']}))
