from pathlib import Path
from collections import deque
import json
out=Path('.work/19-spec-final-01');cfg=out/'export/configs';n=json.loads((cfg/'full-facility-decision-v1/public-nominal.json').read_bytes());c=json.loads((cfg/'full-facility-risk-scenarios-v1.json').read_bytes())
entities={e['id']:e for e in n['entities']};adj={}
for kind,edges in n['graphs'].items():
 for e in edges:
  adj.setdefault(e['from'],[]).append((e['to'],e['id'],kind))
  if e['bidirectional']:adj.setdefault(e['to'],[]).append((e['from'],e['id'],kind))
def path(start,finish):
 queue=deque([(start,[])]);seen={start}
 while queue:
  node,trace=queue.popleft()
  if node==finish:return trace
  for other,eid,kind in adj.get(node,[]):
   if other not in seen:seen.add(other);queue.append((other,trace+[dict(relation=kind,edge=eid,source=node,target=other)]))
 return None
routes=[('power','rectifier','critical_service','Physical electrical capacity constrains joint service.'),('backup','ups','critical_service','Reserve supports controller/pumps; control permits affect compute.'),('backup','backup_tower','immersion','Reserve cooling supports internal water and immersion.'),('facility_cooling','filter','immersion','Fluid/heat relations connect filtration and heat rejection.'),('equipment_environment','room','loc_it','Room work temperature conditions restrict access.'),('it_service','network','critical_service','Network is a required service component.'),('control_monitoring','local_controller','critical_service','Control permission directly affects compute.'),('control_monitoring','bms','evidence_inbox','Lost reports affect evidence availability separately from physical loss.'),('space_access','drainage','loc_it','Access can block work without immediate service loss.'),('people_tools_work','loc_control','loc_it','Crew capability and independent walk relation affect execution timing.')]
result=[]
for domain,start,end,meaning in routes:
 trace=path(start,end);assert trace is not None,(domain,start,end);result.append(dict(domain=domain,start=start,end=end,trace=trace,interpretation=meaning))
for q in c['questions']:
 assert all(t in entities for t in q['target_ids'])
 assert q['scenario'] and q['impact_description'] and q['conditional_consequence'] and q['closure_evidence'] and q['evidence_gaps'] and q['options']
 assert q['quantification']=='FINITE_CONDITIONAL_LAW' or q['outcome_ids']==[]
assert {d for q in c['questions'] for d in q['domain_ids']}==set(n['domain_ids'])
p=dict(classification='STATIC_PUBLIC_SEMANTIC_REVIEW_ONLY',core='46a0b0906cb8b38cc6fc911bb106460e610a5319',domain_count=8,question_count=8,finite_questions=2,unmodeled_questions=6,domain_traces=result,scope='Graph trace plus distinct physical/information/access/execution meanings; does not establish dynamic effects or calibrated probabilities. Canonical state, action feasibility and narrative reviewed together.')
(out/'domain-review.json').write_text(json.dumps(p,ensure_ascii=False,indent=2)+chr(10),encoding='utf-8')
print(json.dumps(p,ensure_ascii=False))
