from pathlib import Path
import sys,json,copy,subprocess
from hashlib import sha256
out=Path('.work/19-spec-final-01').resolve();root=out.parents[1];sys.path.insert(0,str(out/'export/src'))
from aegis_dc.risk_scenarios import assess_risks
frame=json.loads((out/'public-frame.json').read_bytes());model=json.loads((out/'export/configs/full-facility-belief-model-v1.json').read_bytes());cat=json.loads((out/'export/configs/full-facility-risk-scenarios-v1.json').read_bytes())
records=[]
for kind in ('wrong-intervention-capability','unrelated-inspection'):
 changed=copy.deepcopy(cat);q=changed['questions'][0]
 if kind=='wrong-intervention-capability':
  option=next(o for o in q['options'] if o['id']=='isolate-cooling');option.update(qualification_id='qualified_it_inspection',tool_ids=['tool_it_diagnostic'],candidate_worker_ids=['worker_it'])
 else:
  option=next(o for o in q['options'] if o['kind']=='inspect');option['request_id']='intent-it-check'
 result=assess_risks(frame,model,changed);assessment=next(o for o in result['questions'][0]['option_assessments'] if o['id']==option['id'])
 records.append(dict(case=kind,changed_option=option,assessment=assessment))
packet=dict(core='46a0b0906cb8b38cc6fc911bb106460e610a5319',results=records,scope='Frozen pre-fix option-binding counterexamples; no physics or full runs')
(out/'old-core-option-probe.json').write_text(json.dumps(packet,indent=2)+chr(10),encoding='utf-8')
print(json.dumps(packet))
