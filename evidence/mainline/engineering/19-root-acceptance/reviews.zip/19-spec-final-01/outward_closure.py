from copy import deepcopy
from fractions import Fraction as F
from hashlib import sha256
import json,math,subprocess,sys
from pathlib import Path
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[1];PIN=(OUT/'correction-pin.txt').read_text().strip();EXPORT=OUT/'correction-export';checks=[];raw=[]
sys.path.insert(0,str(EXPORT/'src'))
def check(value,label):
 if not value:raise AssertionError(label)
 checks.append(label)
def guard():
 paths=subprocess.check_output(['git','ls-tree','-r','--name-only',PIN,'src','configs'],cwd=ROOT,text=True).splitlines();hashes={}
 for path in paths:
  data=(EXPORT/path).read_bytes();assert data==subprocess.check_output(['git','show',PIN+':'+path],cwd=ROOT);hashes[path]=sha256(data).hexdigest()
 return hashes
before=guard()
from aegis_dc.risk_scenarios import assess_risks
frame=json.loads((OUT/'public-frame.json').read_bytes());belief=json.loads((EXPORT/'configs/full-facility-belief-model-v1.json').read_bytes());catalog=json.loads((EXPORT/'configs/full-facility-risk-scenarios-v1.json').read_bytes())
def evaluate(cat):return assess_risks(deepcopy(frame),deepcopy(belief),deepcopy(cat))
check(evaluate(catalog)==json.loads((OUT/'old-binary-friendly-baseline.json').read_bytes()),'binary-friendly baseline JSON unchanged')
exact=F(.1)+F(.2);canonical=math.nextafter(.3,math.inf)
check(F(.3)<exact<F(canonical),'independent exact numerator bracket')
check(exact.numerator.bit_length()==54,'exact total needs54bits')
for upper,accepted in [(.3,False),(canonical,True),(math.nextafter(canonical,math.inf),False),(0,False),(1,False)]:
 cat=deepcopy(catalog);cat['demand'][0]['rate']=.1;cat['demand'][1]['rate']=.2
 for q in cat['questions']:q['consequence_bounds']['unserved_service_unit_s']['interval']=[0,upper]
 try:result=evaluate(cat)
 except ValueError as error:
  check(not accepted,'reject expected bound '+str(upper));raw.append(dict(upper=upper,status='REJECTED',reason=str(error)))
 else:
  check(accepted,'accept only canonical bound '+str(upper));raw.append(dict(upper=upper,status='ACCEPTED',result=result))
  check(all(q['consequence_bounds']['unserved_service_unit_s']['interval']==[0,canonical] for q in result['questions']),'returned conservative canonical bound')
  check(abs(result['full_horizon_service']['offered_service_unit_s']['value']-float(exact))<=1e-14,'common demand retained decimal profile')
# Window duration itself can have an unrepresentable exact decoded difference.
cat=deepcopy(catalog);question=cat['questions'][0];cat['questions']=[question];question['window_s']=[.1,.3]
duration=F(.3)-F(.1);outward=float(duration)
if F(outward)<duration:outward=math.nextafter(outward,math.inf)
work=duration*F(.5);outwardwork=float(work)
if F(outwardwork)<work:outwardwork=math.nextafter(outwardwork,math.inf)
question['consequence_bounds']['service_deficit_time_s']['interval']=[0,outward];question['consequence_bounds']['unserved_service_unit_s']['interval']=[0,outwardwork]
result=evaluate(cat);check(len(result['questions'])==1,'decoded subwindow duration accepted canonical bounds')
check(F(outward)>=duration and F(math.nextafter(outward,-math.inf))<duration,'window outward minimal proof')
for key in ('service_deficit_time_s','unserved_service_unit_s'):
 bad=deepcopy(cat);bad['questions'][0]['consequence_bounds'][key]['interval'][1]=math.nextafter(bad['questions'][0]['consequence_bounds'][key]['interval'][1],-math.inf)
 try:evaluate(bad)
 except ValueError:check(True,'subwindow lower endpoint refused '+key)
 else:check(False,'subwindow underbound admitted '+key)
after=guard();check(before==after,'immutable correction source bytes unchanged')
report=dict(schema='aegisdc19-independent-outward-bound-closure-v1',status='PASS',correction_source=PIN,original_capture_source='1939cb2ff375f7a0632a0a05ada68ae98afbdc1a',original_data_delivery='7069f2bee86ef7cdfd8d4849bb98bb5dacbf59cc',assertions=len(checks),checks=checks,source_before=before,source_after=after,raw=raw,original_capture_rerun=False,full_suite_runs=0,new_physical_runs=0,registered_research_trials=0,llm_calls=0,training_calls=0)
(OUT/'outward-closure-result.json').write_text(json.dumps(report,indent=2)+chr(10),encoding='utf-8');print(json.dumps({k:report[k] for k in ['status','correction_source','assertions']}))
