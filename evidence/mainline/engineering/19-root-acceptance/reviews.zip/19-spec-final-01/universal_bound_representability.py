from pathlib import Path
import json,sys,copy,math
from fractions import Fraction as F
out=Path('.work/19-spec-final-01').resolve();sys.path.insert(0,str(out/'final-export/src'))
from aegis_dc.risk_scenarios import assess_risks
f=json.loads((out/'public-frame.json').read_bytes());m=json.loads((out/'final-export/configs/full-facility-belief-model-v1.json').read_bytes());base=json.loads((out/'final-export/configs/full-facility-risk-scenarios-v1.json').read_bytes())
rows=[]
for upper in [.3,math.nextafter(.3,math.inf)]:
 c=copy.deepcopy(base);c['demand'][0]['rate']=.1;c['demand'][1]['rate']=.2
 for q in c['questions']:q['consequence_bounds']['unserved_service_unit_s']['interval']=[0,upper]
 try:r=assess_risks(f,m,c);result={'status':'ACCEPTED'}
 except ValueError as e:result={'status':'REJECTED','reason':str(e)}
 rows.append(dict(upper=upper,**result))
packet=dict(source='1939cb2ff375f7a0632a0a05ada68ae98afbdc1a',exact_offered=str(F(.1)+F(.2)),rows=rows,scope='Read-only domain-bound representability check, not a new research trial')
(out/'universal-bound-representability.json').write_text(json.dumps(packet,indent=2)+chr(10),encoding='utf-8');print(json.dumps(packet))
