from copy import deepcopy
from fractions import Fraction as F
from hashlib import sha256
import json, os, subprocess, sys
from pathlib import Path
OUT=Path(__file__).resolve().parent; ROOT=OUT.parents[1]
PIN=(OUT/'final-pin.txt').read_text(encoding='utf-8').strip(); EXPORT=OUT/'final-export'
sys.path.insert(0,str(EXPORT/'src')); checks=[]; raw=[]
def check(value,label):
 if not value: raise AssertionError(label)
 checks.append(label)
def read(name): return json.loads((EXPORT/name).read_bytes())
def guard():
 paths=subprocess.check_output(['git','ls-tree','-r','--name-only',PIN,'src','configs'],cwd=ROOT,text=True).splitlines(); result={}
 for p in paths:
  content=(EXPORT/p).read_bytes(); check(content==subprocess.check_output(['git','show',PIN+':'+p],cwd=ROOT),'sourceblob '+p);result[p]=sha256(content).hexdigest()
 return result
before=guard()
from aegis_dc.risk_scenarios import assess_risks
from aegis_dc.decision_view import DecisionGateway
from aegis_dc.evidence_ledger import RECORD_FIELDS
FRAME=json.loads((OUT/'public-frame.json').read_bytes())
BELIEF=read('configs/full-facility-belief-model-v1.json');CAT=read('configs/full-facility-risk-scenarios-v1.json')
def run(frame=None,belief=None,cat=None,label=None):
 result=assess_risks(deepcopy(FRAME if frame is None else frame),deepcopy(BELIEF if belief is None else belief),deepcopy(CAT if cat is None else cat))
 if label: raw.append(dict(label=label,result=result))
 return result
def quantities(actual,expected,label):
 mapping={'offered':'offered_service_unit_s','delivered':'delivered_service_unit_s','unserved':'unserved_service_unit_s','deficit':'service_deficit_time_s'}
 for short,exact in expected.items():
  key=mapping[short];check(abs(actual[key]['value']-float(F(exact)))<=1e-14,label+' '+short)
  check(actual[key]['unit']==('s' if short=='deficit' else 'normalized_service_unit*s'),label+' unit '+short)
def reject(cat,label,frame=None):
 try: run(cat=cat,frame=frame)
 except ValueError as error: check(bool(str(error)),'reject '+label);raw.append(dict(label=label,rejected=str(error)))
 else: check(False,'admitted '+label)

result=run(label='baseline'); expected=json.loads((OUT/'independent-literal-expectations.json').read_bytes()); qs={q['id']:q for q in result['questions']}
quantities(result['full_horizon_service'],expected['all'],'common full horizon')
quantities(result['portfolio']['consequences'],expected['portfolio'],'joint portfolio')
for qid in ('cooling','power'):
 quantities(qs[qid]['consequences'],expected[qid],qid+' event contribution')
 check(abs(qs[qid]['probability']['value']-float(F(expected['event_probabilities'][qid])))<=1e-14,qid+' event probability')
check(sum(q['consequences']['service_deficit_time_s']['value'] for q in qs.values() if q['quantification']=='FINITE_CONDITIONAL_LAW')>result['portfolio']['consequences']['service_deficit_time_s']['value'],'event overlap not summed')
check(result['portfolio']['aggregation']=='JOINT_OUTCOME_AND_WINDOW_UNION','joint aggregation label')
check(result['portfolio']['completeness']=='PARTIAL_WITH_UNMODELED_QUESTIONS','partial scope explicit')
check(set(result['covered_domain_ids'])==set(result['domain_ids']) and len(result['domain_ids'])==8,'8 domain identity')
unknown=[q for q in qs.values() if q['quantification']=='UNMODELED'];check(len(unknown)==6,'six unknown questions')
for q in unknown:
 check(q['probability']['value'] is None and all(d['value'] is None for d in q['consequences'].values()),'unknown no zero '+q['id'])
 check(q['assumption_envelope'] is None and q['consequence_bounds'] and q['evidence_gaps'] and q['options'] and q['closure_evidence'],'unknown gap capability closure '+q['id'])
for q in qs.values():
 check(all(d['interval'] is None and d['unit'] for d in q['secondary_consequence_dimensions']),'dimensions separate '+q['id'])
 check(q['physical_actions']==[] and q['status']=='OPEN','information not physical '+q['id'])
 check(q['window_s']==[12,14],'absolute current window '+q['id'])
check(result['physical_actions']==[] and result['execution_permission'] is False,'no execution')

# Nonidentity stochastic conditional law: each state has the same explicitly stated outcome law.
cat=deepcopy(CAT)
for outcome,mass in zip(cat['outcomes'],(.6,.2,.1,.1)): outcome['conditional_probability']=dict.fromkeys(outcome['conditional_probability'],mass)
nonidentity=run(cat=cat,label='nonidentity conditional law')
quantities(nonidentity['full_horizon_service'],{'offered':'5/2','delivered':'763/400','unserved':'237/400','deficit':'9/25'},'nonidentity expectation')
for q in nonidentity['questions']:
 if q['id']=='cooling':check(abs(q['probability']['value']-.3)<=1e-14,'nonidentity cooling probability')
 if q['id']=='power':check(abs(q['probability']['value']-.2)<=1e-14,'nonidentity power probability')

# Window union uses partial coverage once per joint outcome.
cat=deepcopy(CAT);one=deepcopy(cat['questions'][0]);two=deepcopy(one);one['window_s']=[.5,1.5];two.update(id='overlapping-copy-question',window_s=[1,2]);cat['questions']=[one,two]
for q,bound,work in [(one,1,1.25),(two,1,2)]:
 q['consequence_bounds']['service_deficit_time_s']['interval']=[0,bound];q['consequence_bounds']['unserved_service_unit_s']['interval']=[0,work]
window=run(cat=cat,label='overlap windows');quantities(window['portfolio']['consequences'],expected['window_union_cooling_half_to2'],'window union')
check(window['portfolio']['outcome_windows_s']=={'cooling-limited':[[.5,2.0]],'other':[[.5,2.0]]},'window union exact')
check(window['full_horizon_service']==result['full_horizon_service'],'full horizon demand independent of question windows')

# Zero-demand first interval contributes no deficit despite zero capacities.
cat=deepcopy(CAT);cat['demand'][0]['rate']=0
for o in cat['outcomes']:o['capacity_profile'][0]['capacities']=dict.fromkeys(o['capacity_profile'][0]['capacities'],0)
for q in cat['questions']:q['consequence_bounds']['unserved_service_unit_s']['interval']=[0,2]
zero=run(cat=cat,label='zero demand');quantities(zero['full_horizon_service'],{'offered':'2','delivered':'1051/1648','unserved':'2245/1648','deficit':'2245/3296'},'zero demand case')

# No questions means no covered contribution, not removal of exogenous demand.
cat=deepcopy(CAT);cat['questions']=[];empty=run(cat=cat,label='empty portfolio')
check(empty['portfolio']['consequences']['service_deficit_time_s']['value']==0,'empty contribution zero')
check(empty['full_horizon_service']==result['full_horizon_service'],'empty questions retain full common demand')

# Both complete and partial likelihood conflicts stay unresolved, never zero risk.
for indices,reference_fails in [([0,1],True),([0],True),([1],False)]:
 belief=deepcopy(BELIEF)
 for i in indices:belief['variants'][i]['positive_likelihood']['fixed-hot']=[0,0,0,0]
 conflict=run(belief=belief,label='conflict '+str(indices))
 check(conflict['portfolio']['assumption_envelope'] is None,'conflict envelope withheld '+str(indices))
 check(conflict['portfolio']['consequences']['service_deficit_time_s']['value'] is None if reference_fails else conflict['portfolio']['consequences']['service_deficit_time_s']['value']>0,'reference missing stays unknown '+str(indices))
for q in result['questions']:
 if q['quantification']=='FINITE_CONDITIONAL_LAW':
  for key,interval in q['assumption_envelope'].items():
   values=[v[key]['value'] for v in q['consequences_by_variant'].values()];check(interval==[min(values),max(values)],'variant interval '+q['id']+key)

# Closure, nominal bindings, and option capability are input validation obligations.
for mutation in ['private','badfacility','badservice','components','probability','gap','badedge','unit','zerobound','unrelatedinspect','wrongcapability']:
 cat=deepcopy(CAT)
 if mutation=='private':cat['actual_fault']='filter'
 elif mutation=='badfacility':cat['facility_id']='foreign'
 elif mutation=='badservice':cat['service_id']='compute'
 elif mutation=='components':cat['service_component_ids']=['compute','network']
 elif mutation=='probability':cat['outcomes'][0]['conditional_probability']['nominal']=.5
 elif mutation=='gap':cat['outcomes'][0]['capacity_profile'][0]['end_s']=.9
 elif mutation=='badedge':cat['questions'][0]['dependency_edge_ids']=['not-an-edge']
 elif mutation=='unit':cat['time_unit']='hour'
 elif mutation=='zerobound':
  cat['questions'][0]['consequence_bounds']['service_deficit_time_s']['interval']=[0,0];cat['questions'][0]['consequence_bounds']['unserved_service_unit_s']['interval']=[0,0]
 elif mutation=='unrelatedinspect':next(o for o in cat['questions'][0]['options'] if o['kind']=='inspect')['request_id']='intent-it-check'
 elif mutation=='wrongcapability':next(o for o in cat['questions'][0]['options'] if o['id']=='isolate-cooling').update(qualification_id='qualified_it_inspection',tool_ids=['tool_it_diagnostic'],candidate_worker_ids=['worker_it'])
 reject(cat,mutation)
options={o['id']:o for o in qs['cooling']['option_assessments']}
check(options['defer-cooling']['legal_for_planning'],'defer retained');check(options['isolate-cooling']['legal_for_planning'],'direct action retained')
check(not options['isolate-cooling']['requires_prior_inspection'] and not options['isolate-cooling']['execution_permission'],'direct action no mandatory inspection or execution authorization')
check(not options['unqualified-cooling']['legal_for_planning'],'wrong worker masked')

# Construct a fresh validated public frame with arrived/expired/future entry reports.
static=deepcopy(FRAME['evidence']['static_knowledge']); base_records=[{k:r[k] for k in RECORD_FIELDS} for r in FRAME['evidence']['records']]
def access_frame(arrival,expiry):
 record=dict(id='public-access',source_id='declared-it-access-report',target_id='loc_it',observable_id='it-entry-permitted-reported',unit='1',value=False,observed_at_s=11,arrived_at_s=arrival,valid_until_s=expiry,quality=dict(status='reported',error_bound=None,note='Independent public access report'),provenance=dict(origin_id='public-access',copied_from_record_id=None))
 ledger=dict(static,schema='aegisdc-evidence-ledger-v1',id=FRAME['evidence']['ledger_id'],facility_id=FRAME['facility_id'],basis='synthetic_assumption',time_unit='s',records=base_records+[record])
 plan=dict(schema='aegisdc-public-preparation-plan-v1',id='review-access-plan',basis='synthetic_assumption',time_unit='s',decision_times_s=[12],requests=FRAME['requests'])
 return DecisionGateway(FRAME['nominal_knowledge'],ledger,plan).next_frame()
for arrival,expiry,blocked in [(12,13,True),(12,12,False),(13,14,False)]:
 current=run(frame=access_frame(arrival,expiry),label='access '+str((arrival,expiry)))
 it=next(q for q in current['questions'] if q['id']=='it-dependence');opt=next(o for o in it['option_assessments'] if o['kind']=='intervene')
 check(opt['legal_for_planning'] is (not blocked),'report mask '+str((arrival,expiry)))
 check('current_report_restricts_entry' in opt['public_reasons'] if blocked else 'current_report_restricts_entry' not in opt['public_reasons'],'report reason '+str((arrival,expiry)))

check((FRAME,BELIEF,CAT)==(json.loads((OUT/'public-frame.json').read_bytes()),read('configs/full-facility-belief-model-v1.json'),read('configs/full-facility-risk-scenarios-v1.json')),'all public inputs unmodified')
after=guard();check(before==after,'source bytes unchanged')
report=dict(schema='aegisdc19-independent-spec-probes-v1',status='PASS',source=PIN,assertions=len(checks),checks=checks,source_before=before,source_after=after,findings=[],full_suite_runs=0,new_physical_runs=0,registered_research_trials=0,llm_calls=0,training_calls=0)
(OUT/'probe-result.json').write_text(json.dumps(report,indent=2)+chr(10),encoding='utf-8');(OUT/'raw-records.json').write_text(json.dumps(raw,indent=2)+chr(10),encoding='utf-8');print(json.dumps({k:report[k] for k in ['status','source','assertions','findings']}))
