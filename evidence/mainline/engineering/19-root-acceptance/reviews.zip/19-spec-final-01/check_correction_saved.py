from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
import json,subprocess,math
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[1];PIN='83583f18669794142159e20e58016fff5b0c4fe2';SOURCE='9c0efc4dbd198d3fbf35c459cd5710c058a60569';OLD='7069f2bee86ef7cdfd8d4849bb98bb5dacbf59cc';PREFIX='evidence/mainline/engineering/19-risk-scenarios/correction-01/';checks=[]
def check(value,label):
 if not value:raise AssertionError(label)
 checks.append(label)
def blob(path,pin=PIN):return subprocess.check_output(['git','cat-file','blob',pin+':'+path],cwd=ROOT)
def read(path,pin=PIN):return json.loads(blob(path,pin))
protocol=read('docs/mainline/19-bound-correction-protocol.json');receipt=read(PREFIX+'receipt.json');attempt=read(PREFIX+'attempt.json');result=read(PREFIX+'correction-results.json')
check(receipt['status']==result['status']=='PASS' and receipt['source_head_and_bytes_unchanged'],'correction status/sourceguard')
check(receipt['execution_commit']==attempt['execution_commit']==SOURCE,'corrected execution')
check(receipt['original_execution']==protocol['original_execution']=='1939cb2ff375f7a0632a0a05ada68ae98afbdc1a','original execution identity')
check(receipt['original_data_delivery']==attempt['original_data_delivery']==protocol['original_data_delivery']==OLD,'original data identity')
check(set(receipt['artifacts'])==set(protocol['durable_outputs'])=={'attempt.json','correction-results.json'},'targeted durable set')
for name,digest in receipt['artifacts'].items():check(sha256(blob(PREFIX+name)).hexdigest()==digest,'correction artifact '+name)
for group in ('runtime_sources','authoring_tools','frozen_inputs'):
 for name,digest in receipt[group].items():check(sha256(blob(name,SOURCE)).hexdigest()==digest==sha256(blob(name)).hexdigest(),'corrected pin '+name)
for field in ('new_physical_runs','registered_research_trials','llm_calls','training_calls'):check(receipt[field]==result[field]==0,'targeted scope '+field)
check([c['id'] for c in result['cases']]==protocol['case_ids'],'seven frozen case identities')
check(len(result['cases'])==7 and result['original_frames_checked']==4 and result['closure_inference_calls']==11,'targeted call accounting')
check(result['original_frame_results_equal'] and result['original_capture_rerun'] is False and result['original_capture_modified'] is False,'original rerun/equality distinctions')
check(F(result['exact_nonrepresentable_work'])==F(.1)+F(.2),'exact work identity')
for c in result['cases']:
 check(c['status'] in ['ACCEPTED_AS_REQUIRED','REFUSED_AS_REQUIRED'],'case disposition '+c['id'])
 if c['id']=='nonrepresentable-work-outward':check(c['first_question_bounds']['unserved_service_unit_s']['interval']==[0,.30000000000000004],'saved outward work')
 if c['id']=='large-finite-work':check(c['full_horizon_service']['offered_service_unit_s']['value']==1e308,'saved finite large work')
 if c['id']=='work-output-overflow-rejected':check('finite binary64 output range' in c['reason'],'saved explicit overflow')
# All original delivery bytes, including original failed/red development records, remain unchanged.
original_paths=subprocess.check_output(['git','ls-tree','-r','--name-only',OLD,'evidence/mainline/engineering/19-risk-scenarios/capture-01'],cwd=ROOT,text=True).splitlines()
for path in original_paths:check(blob(path)==blob(path,OLD),'original capture preserved '+path)
check(receipt['full_regression_gate']=='PENDING_ROOT_CORRECTED_RUNTIME_FULL','corrected full gate pending')
report=dict(schema='aegisdc19-independent-correction-saved-spec-v1',status='PASS',execution=SOURCE,delivery=PIN,assertions=len(checks),checks=checks,findings=[],inference_rerun=False,original_capture_rerun=False,full_suite_runs=0,new_physical_runs=0,registered_research_trials=0,llm_calls=0,training_calls=0)
(OUT/'correction-saved-result.json').write_text(json.dumps(report,indent=2)+chr(10),encoding='utf-8');print(json.dumps({k:report[k] for k in ['status','execution','delivery','assertions','findings']}))
