from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
import json,subprocess
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[1];PIN='7069f2bee86ef7cdfd8d4849bb98bb5dacbf59cc';SOURCE='1939cb2ff375f7a0632a0a05ada68ae98afbdc1a';PREFIX='evidence/mainline/engineering/19-risk-scenarios/capture-01/';checks=[]
def check(value,label):
 if not value:raise AssertionError(label)
 checks.append(label)
def blob(path,pin=PIN):return subprocess.check_output(['git','cat-file','blob',pin+':'+path],cwd=ROOT)
def read(path,pin=PIN):return json.loads(blob(path,pin))
protocol=read('docs/mainline/19-risk-engineering-protocol.json');receipt=read(PREFIX+'receipt.json');attempt=read(PREFIX+'attempt.json');data=read(PREFIX+'check-results.json')
check(receipt['status']=='PASS' and receipt['source_head_and_bytes_unchanged'],'capture/source guard')
check(receipt['execution_commit']==attempt['execution_commit']==SOURCE,'execution identity')
check(receipt['global_regression_gate']=='PENDING_ROOT_INTEGRATED_FULL_WITH_TORCH' and receipt['field_calibration']=='PENDING','scope gates pending')
check(set(receipt['artifacts'])==set(protocol['durable_outputs']),'six declared durable artifacts')
for name,digest in receipt['artifacts'].items():check(sha256(blob(PREFIX+name)).hexdigest()==digest,'artifact '+name)
for group in ('runtime_sources','authoring_verification_tools','frozen_inputs'):
 for name,digest in receipt[group].items():check(sha256(blob(name,SOURCE)).hexdigest()==digest==sha256(blob(name)).hexdigest(),'source/data pin '+name)
for field in ('new_physical_runs','registered_research_trials','llm_calls','training_calls'):check(receipt[field]==attempt[field]==data[field]==0,'scope count '+field)
check(data['classification']=='ENGINEERING_ONLY' and data['maximum_absolute_error']==0,'finite scope error')
check([r['as_of_s'] for r in data['results']]==[0,10,11,12],'four frozen public times')
expected=json.loads((OUT/'independent-literal-expectations.json').read_bytes());mapping={'offered':'offered_service_unit_s','delivered':'delivered_service_unit_s','unserved':'unserved_service_unit_s','deficit':'service_deficit_time_s'}
last=data['results'][-1]
for short,key in mapping.items():check(abs(last['full_horizon_service'][key]['value']-float(F(expected['all'][short])))<=1e-14,'independent full '+short)
for short,key in mapping.items():check(abs(last['portfolio']['consequences'][key]['value']-float(F(expected['portfolio'][short])))<=1e-14,'independent portfolio '+short)
for row in data['results']:
 check(row['execution_permission'] is False and row['physical_actions']==[],'no action '+str(row['as_of_s']))
 check(len(row['questions'])==8 and len(row['domain_ids'])==8 and set(row['covered_domain_ids'])==set(row['domain_ids']),'full domain scope '+str(row['as_of_s']))
 for q in row['questions']:
  check(q['impact_description'] and q['conditional_consequence'] and q['evidence_gaps'] and q['closure_evidence'],'question semantic fields '+str((row['as_of_s'],q['id'])))
  check(all(o['execution_permission'] is False and o['requires_prior_inspection'] is False for o in q['option_assessments']),'option boundary '+str((row['as_of_s'],q['id'])))
  if q['quantification']=='UNMODELED':check(q['probability']['value'] is None and all(v['value'] is None for v in q['consequences'].values()),'unknown no zero '+str((row['as_of_s'],q['id'])))
  if q['assumption_envelope'] is not None:
   for key,interval in q['assumption_envelope'].items():
    values=[v[key]['value'] for v in q['consequences_by_variant'].values()];check(interval==[min(values),max(values)],'variant range '+str((row['as_of_s'],q['id'],key)))
# Seven archive window checks use earlier independent literal witness, not returned expectations.
window=json.loads((OUT/'19-independent-service-window-witness-01.json').read_bytes());check(len(data['window_checks'])==7,'seven archived windows')
for row in data['window_checks']:
 case=window['cases'][row['case']];win=next(w for w in case['windows'] if list(map(float,map(F,w['window_s'])))==row['window_s'])
 check(sha256(blob(row['source'])).hexdigest()==case['run_sha256']==row['source_sha256'],'original08 source '+str((row['case'],row['window_s'])))
 for short,key in mapping.items():
  exact=win['normalized_deficit_s' if short=='deficit' else short];check(abs(row['actual'][key]['value']-float(F(exact)))<=1e-14,'archive literal '+str((row['case'],row['window_s'],short)))
joint=data['joint_witness_result'];check(abs(joint['portfolio']['consequences']['service_deficit_time_s']['value']-float(F(159,400)))<=1e-14,'independent compound event union159/400')
check(sum(q['consequences']['service_deficit_time_s']['value'] for q in joint['questions'])>joint['portfolio']['consequences']['service_deficit_time_s']['value'],'compound sum deliberately exceeds union')
cli=read(PREFIX+'cli-stdout.raw');check(cli==last,'saved CLI exact result identity');check(blob(PREFIX+'cli-stderr.raw')==b'','CLI stderr empty')
report=dict(schema='aegisdc19-independent-saved-output-spec-v1',status='PASS',execution=SOURCE,delivery=PIN,assertions=len(checks),checks=checks,findings=[],inference_rerun=False,full_suite_runs=0,new_physical_runs=0,registered_research_trials=0,llm_calls=0,training_calls=0)
(OUT/'saved-output-result.json').write_text(json.dumps(report,indent=2)+chr(10),encoding='utf-8');print(json.dumps({k:report[k] for k in ['status','execution','delivery','assertions','findings']}))
