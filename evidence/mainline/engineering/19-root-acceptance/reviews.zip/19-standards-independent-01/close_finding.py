from copy import deepcopy
from hashlib import sha256
import json
import os
from pathlib import Path
import subprocess
import sys

BASE = Path(__file__).resolve().parent
REPO = BASE.parents[1]
PIN = '99a2afeabf25f2d3d31f3ddbb1819ef15dbc153f'
DATA = '0b542f7e70b49d763b5cf46377fd9213966fb3bb'
FINAL = '5cac88b5f0f2b8fa221eaf406be5196a63218412'
EXPORT = BASE / 'closure-export-99a2afea'
EXPORT.mkdir(exist_ok=False)

def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO)

def blob(pin, name):
    return git('cat-file', 'blob', pin + ':' + name)

names = [n for n in git('ls-tree', '-rz', '--name-only', PIN, 'src').decode().strip('\0').split('\0') if n.endswith('.py')]
names += ['configs/full-facility-belief-model-v1.json', 'configs/full-facility-risk-scenarios-v1.json', 'evidence/mainline/engineering/18-beliefs/capture-01/cli-frame.json']
for name in names:
    path = EXPORT / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(blob(PIN, name))
before = {n: sha256((EXPORT / n).read_bytes()).hexdigest() for n in names}
sys.path.insert(0, str(EXPORT / 'src'))
from aegis_dc.risk_scenarios import assess_risks

def read(name):
    return json.loads((EXPORT / name).read_bytes())

frame = read('evidence/mainline/engineering/18-beliefs/capture-01/cli-frame.json')
belief = read('configs/full-facility-belief-model-v1.json')
model = read('configs/full-facility-risk-scenarios-v1.json')
model['demand'] = [dict(start_s=0, end_s=2, rate=1e308)]
for question in model['questions']:
    question['window_s'] = [0, 1]
    question['consequence_bounds']['service_deficit_time_s']['interval'] = [0, 1]
    question['consequence_bounds']['unserved_service_unit_s']['interval'] = [0, 1e308]
checks = []
for identifier, questions in [('short-question', model['questions']), ('no-questions', [])]:
    changed = deepcopy(model)
    changed['questions'] = questions
    try:
        assess_risks(frame, belief, changed)
    except ValueError as error:
        assert 'finite binary64 output range' in str(error)
        checks.append(dict(id=identifier, status='REFUSED', error_type='ValueError', error=str(error)))
    else:
        raise AssertionError('Overflow model admitted')
changed = deepcopy(model)
changed['questions'] = []
changed['demand'][0]['rate'] = 5e307
result = assess_risks(frame, belief, changed)
assert result['full_horizon_service']['offered_service_unit_s']['value'] == 1e308
assert not result['execution_permission'] and result['physical_actions'] == []
checks.append(dict(id='large-finite', status='ACCEPTED', offered=1e308))
(EXPORT / 'overflow.json').write_text(json.dumps(model), encoding='utf-8')
command = [sys.executable, '-B', '-X', 'utf8', '-m', 'aegis_dc.risk_scenarios', '--frame', 'evidence/mainline/engineering/18-beliefs/capture-01/cli-frame.json', '--belief-model', 'configs/full-facility-belief-model-v1.json', '--catalog', 'overflow.json']
cli = subprocess.run(command, cwd=EXPORT, env=dict(os.environ, PYTHONPATH=str(EXPORT / 'src')), capture_output=True)
assert cli.returncode == 2 and cli.stdout == b'' and b'Traceback' not in cli.stderr and b'finite binary64 output range' in cli.stderr
(BASE / 'closure-cli-stdout.raw').write_bytes(cli.stdout)
(BASE / 'closure-cli-stderr.raw').write_bytes(cli.stderr)
checks.append(dict(id='cli', status='REFUSED', exit_code=cli.returncode, traceback=False))
after = {n: sha256((EXPORT / n).read_bytes()).hexdigest() for n in names}
assert before == after
prefix = 'evidence/mainline/engineering/19-risk-scenarios/correction-02/'
receipt = json.loads(blob(DATA, prefix + 'receipt.json'))
assert receipt['execution_commit'] == PIN and receipt['status'] == 'PASS' and receipt['source_head_and_bytes_unchanged']
for name, expected in receipt['artifacts'].items():
    assert sha256(blob(DATA, prefix + name)).hexdigest() == expected
    assert blob(DATA, prefix + name) == blob(FINAL, prefix + name)
for group in ('runtime_sources', 'authoring_tools', 'frozen_inputs'):
    for name, expected in receipt[group].items():
        assert sha256(blob(PIN, name)).hexdigest() == sha256(blob(DATA, name)).hexdigest() == sha256(blob(FINAL, name)).hexdigest() == expected
result = dict(schema='aegisdc-ticket19-independent-standards-finding-closure-v1', status='PASS', source=PIN, data_delivery=DATA, final_candidate=FINAL, original_report_retained=True, original_finding='Full-horizon offered-work overflow beyond individually finite question windows', open_findings=0, checks=checks, public_api_calls=3, cli_calls=1, guarded_export_files=len(names), source_hashes_before=before, source_hashes_after=after, source_bytes_unchanged=True, correction_artifacts=len(receipt['artifacts']), correction_terminal_receipts=1, correction_pins={g: len(receipt[g]) for g in ('runtime_sources', 'authoring_tools', 'frozen_inputs')}, full_suite_runs=0, physical_runs=0, registered_research_trials=0, llm_calls=0, training_calls=0, serialization_correction='Initial script writer syntax error dispatched no public probe; no product or research failure')
with (BASE / 'closure-result.json').open('x', encoding='utf-8', newline='\n') as stream:
    stream.write(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({k: v for k, v in result.items() if k not in ('source_hashes_before', 'source_hashes_after')}))
