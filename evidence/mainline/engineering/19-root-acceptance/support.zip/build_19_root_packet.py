"""Preserve ticket19 accepted root evidence, retaining original and corrected sources."""
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import zipfile

ROOT=Path(__file__).resolve().parents[1]
WORK=ROOT/'.work'
PACKET=Path('evidence/mainline/engineering/19-root-acceptance')
SOURCE='6193cb24851e3ed435a78153ffb79a64da77ab63'
RAW=ROOT/'runs/mainline-M3-19-root-acceptance-20261105-02'

def read(p):return json.loads(p.read_bytes())
def digest(p):return sha256(p.read_bytes()).hexdigest()
def git(*a):return subprocess.check_output(['git',*a],cwd=ROOT)
def write(p,v,new=True):
    p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('x' if new else 'w',encoding='utf-8',newline='\n') as f:f.write(json.dumps(v,ensure_ascii=False,indent=2,allow_nan=False)+'\n')

def main():
    assert git('rev-parse','HEAD').decode().strip()==SOURCE and not git('status','--porcelain')
    packet=ROOT/PACKET;assert not packet.exists()
    summary,guard=read(RAW/'summary.json'),read(RAW/'source-guard.json');tests=summary['tests']
    assert summary['overall']=='PASS' and tests['run']==tests['executed']>434
    assert tests['errors']==tests['failures']==tests['skipped']==0 and summary['verified_original_files']==20
    assert guard['sources_unchanged'] and guard['head_unchanged'] and guard['source_commit_before']==SOURCE
    spec=read(WORK/'19-spec-final-01/review.json');assert spec['status']=='PASS' and spec['total_assertions']==720 and spec['open_findings']==0
    copies={'raw/'+n:RAW/n for n in ('summary.json','tests.log','evidence.json','source-guard.json')}
    visuals={}
    for stem in ('domain-risk-map','separate-service-units'):
        png=WORK/'19-visual-qa-01'/(stem+'.png');svg=png.with_suffix('.svg');dest='figures/'+png.name
        copies[dest]=png
        if stem=='separate-service-units':
            copies['figures/'+svg.name]=svg;svgpath=(PACKET/'figures'/svg.name).as_posix()
        else:svgpath='evidence/mainline/engineering/19-risk-scenarios/capture-01/'+svg.name
        visuals[dest]=dict(svg=svgpath,svg_sha256=digest(svg),png_sha256=digest(png))
    assert read(WORK/'19-visual-qa-01/visual-review.json')['open_findings']==0
    reviews={}
    for folder in ('19-spec-final-01','19-standards-root-01','19-standards-independent-01'):
        for p in (WORK/folder).rglob('*'):
            if p.is_file() and '__pycache__' not in p.parts and p.suffix not in {'.pyc','.pyo'}:
                reviews[folder+'/'+p.relative_to(WORK/folder).as_posix()]=p
    assert read(WORK/'19-standards-independent-01/closure-review.json')['open_findings']==0
    support={n:WORK/n for n in ('19-sequential-integration-01.json','19-integration-precheck-02.json',
        '19-original-fresh-proof-01.json','19-correction-fresh-proof-01.json','19-pre-freeze-findings-01.json',
        '19-findings-continuation-02.json','19-independent-expected-consequence-witness-01.json',
        '19-independent-joint-portfolio-witness-01.json','19-independent-service-window-witness-01.json',
        'run_19_root_acceptance.py','build_19_root_packet.py','19-revision2-integration-01.json',
        '19-full-horizon-overflow-probe-01.json','19-root-first-run-status-01.json',
        '19-root-first-run-preservation-01.json','19-correction-v2-fresh-proof-01.json')}
    for p in (ROOT/'runs/mainline-M3-19-root-acceptance-20261105-01').iterdir():
        if p.is_file():support['root-first-run/'+p.name]=p
    for p in (WORK/'19-visual-qa-01').iterdir():
        if p.suffix in {'.json','.py'}:support['visual/'+p.name]=p
    declared=sorted(set(copies)|{'.gitattributes','README.md','declaration.json','source-manifest.json',
        'archive-members.json','reviews.zip','support.zip','verify_packet.py'})
    write(packet/'declaration.json',dict(artifacts=declared,terminal_receipt='receipt.json'))
    for n,p in copies.items():
        q=packet/n;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(p.read_bytes())
    attrs=['# Exact native raw records. All other whitespace checks retained.']
    for n,p in copies.items():
        if n.startswith('raw/') and b'\r\n' in p.read_bytes():attrs.append(n+' -text whitespace=blank-at-eol,blank-at-eof,space-before-tab,cr-at-eol')
    (packet/'.gitattributes').write_text('\n'.join(attrs)+'\n',encoding='utf-8',newline='\n')
    archives={}
    for name,members in (('reviews.zip',reviews),('support.zip',support)):
        archives[name]={}
        with zipfile.ZipFile(packet/name,'x',zipfile.ZIP_DEFLATED) as z:
            for n,p in sorted(members.items()):
                raw=p.read_bytes();z.writestr(n,raw);archives[name][n]=dict(sha256=sha256(raw).hexdigest(),bytes=len(raw))
    write(packet/'archive-members.json',archives)
    author={}
    for role,execution,delivery,folder,changes in (
        ('original','1939cb2ff375f7a0632a0a05ada68ae98afbdc1a','7069f2bee86ef7cdfd8d4849bb98bb5dacbf59cc','capture-01',['src/aegis_dc/risk_scenarios.py']),
        ('correction','9c0efc4dbd198d3fbf35c459cd5710c058a60569','83583f18669794142159e20e58016fff5b0c4fe2','correction-01',['src/aegis_dc/risk_scenarios.py']),
        ('correction_v2','99a2afeabf25f2d3d31f3ddbb1819ef15dbc153f','0b542f7e70b49d763b5cf46377fd9213966fb3bb','correction-02',[])):
        capture='evidence/mainline/engineering/19-risk-scenarios/'+folder+'/receipt.json'
        author[role]=dict(execution=execution,data_delivery=delivery,capture=capture,capture_sha256=digest(ROOT/capture),
            pin_groups=['runtime_sources','authoring_verification_tools','frozen_inputs'] if role=='original' else ['runtime_sources','authoring_tools','frozen_inputs'],allowed_source_changes=changes)
    write(packet/'source-manifest.json',dict(tested_source=SOURCE,author=author,visuals=visuals,
        reviews=dict(standards_findings=0,spec_findings=0,independent_assertions=720,
            standards_report_sha256=digest(WORK/'19-standards-independent-01/closure-report.md'),spec_report_sha256=digest(WORK/'19-spec-final-01/SPEC.md'))))
    (packet/'verify_packet.py').write_bytes((WORK/'19-verify_packet.py').read_bytes())
    text=f'''# 第19项根验收：风险情景与服务后果

修复后集成源码`{SOURCE}`通过{tests['executed']}项完整回归：全部执行，零失败、零错误、零跳过。20份历史原件通过核对；{len(guard['actual_sources'])}个Python与JSON源文件接受Git身份和前后字节守卫。主线仍为完整八域合成设施，本项不宣称现场风险校准或巡检收益。

![分量纲服务后果账](figures/separate-service-units.png)

两秒声明法则下，共同需求为2.5归一化service-unit·s，期望交付2053/2060、未服务3097/2060；缺额时间15877/16480s单独显示。多个问题共享联合后果时先合并结果和时间窗，不相加重复服务损失。上述数值是显式条件法则的工程结果，不是物理预测或真实设施测量。

![八域风险问题与认知边界](figures/domain-risk-map.png)

两项有限热/供电问题使用第18项认识与声明联合后果模型。其余六项具体记录后备、IT、控制、访问、人员及房间的影响路径、条件后果、保守界、证据缺口和专业转介；概率及点风险仍未识别。未知不当零，已建模子集不当全设施总风险。暂缓和直接处置可进入规划，人员与物理执行门槛仍由21–24项验收。

## 原件、修复与评审

原执行1939／数据7069／候选c35保留。五项独立发现依次关闭：处置能力、核查对象、矛盾保守界、小数需求上界可表示性、完整时域溢出。第一次数值修复在9c源码执行，835保存7个案例与4帧一致性；第二次99源码／0b数据修复短问题窗和空问题列表绕过完整时域有限输出检查，并验证CLI正常拒绝。原7b9源码的448项回归PASS作为历史原件保留，未充当当前接受；本次6193新源全检单列。所有旧捕获、协议及收据不改写。最小有限向外binary64只解决表示问题，过小、任意放大和溢出均拒绝。

Spec共720项独立断言通过，独立Standards另完成3项API与1项CLI闭环，两轴未关闭问题均为0。[评审原件](reviews.zip)保留旧失败探针、修复闭环和来源清单。[支持原件](support.zip)保留精确算例、合并保护、两次新检出证明与图像复核。原正式捕获1次0失败，数值修复两次分别1次0失败；无新增物理轨迹、注册效果实验、LLM调用或训练。

- [根接受权威](../../../../docs/mainline/evidence/19-root.json)
- [当前运行身份及复核](../../../../docs/mainline/19-current-runtime-and-reproduction.md)
- [作者报告](../19-risk-scenarios/README.md)与[主来源适用性](../../../../docs/mainline/research/19-source-applicability.md)
- [根测试摘要](raw/summary.json)、[完整日志](raw/tests.log)、[源码守卫](raw/source-guard.json)
- [声明产物](declaration.json)、[来源清单](source-manifest.json)、[收据](receipt.json)

两张展示图均本地渲染后实际查看。原异量纲条形图保持封存，新增分面图从保存数据派生，并记录源SHA与生成器；没有重新推断。复算使用本包`verify_packet.py --delivery-commit COMMIT --output OUTSIDE_CHECKOUT.json`，在明确封存提交新检出中核对原件与源码，不重跑全检或物理。

当前主票20比较检查信息与处置价值；21独立推进人员执行，M3仍未完成，整体研究目标active。
'''
    (packet/'README.md').write_text(text,encoding='utf-8',newline='\n')
    assert {p.relative_to(packet).as_posix() for p in packet.rglob('*') if p.is_file()}==set(declared)
    write(packet/'receipt.json',dict(schema='aegisdc-ticket19-root-packet-v1',tested_source=SOURCE,
        delivery_gate='PENDING_COMMIT_AND_FRESH_CHECKOUT',artifacts={n:digest(packet/n) for n in declared},root_tests=tests,
        independent_assertions=720,historical_originals=20,new_full_regressions=0,new_physical_runs=0,registered_research_trials=0,llm_calls=0,training_calls=0))
    write(ROOT/'docs/mainline/evidence/19-root.json',dict(schema='aegisdc-ticket-root-acceptance-v1',ticket='19',status='ACCEPTED',actual_root_source=SOURCE,
        root_tests=tests,packet=PACKET.as_posix(),packet_receipt_sha256=digest(packet/'receipt.json'),author=author,independent_assertions=720,
        standards_findings=0,spec_findings=0,field_calibration='PENDING',registered_research_trials=0,llm_calls=0,training_calls=0,overall_goal='ACTIVE'))
    p=ROOT/'.scratch/full-facility-mainline/issues/19-risk-scenarios.md';s=p.read_text(encoding='utf-8');assert '**Status:** claimed' in s
    s=s.replace('**Status:** claimed','**Status:** resolved',1).replace('- [ ]','- [x]');s+='\nRoot acceptance: `docs/mainline/evidence/19-root.json`, actual corrected-source integration `'+SOURCE+'`, '+str(tests['executed'])+' tests all executed and720independentassertions. Original and correction candidates retain their historical pending identities; separate Root authority resolves this ticket.\n';p.write_text(s,encoding='utf-8',newline='\n')
    p=ROOT/'docs/mainline/progress.json';v=read(p);assert v['current_ticket']=='19';v['current_ticket']='20';v['active_implementations']=[x for x in v['active_implementations'] if x['ticket']!='19'];next(x for x in v['milestones'] if x['id']=='M3')['acceptance_evidence'].append('docs/mainline/evidence/19-root.json');write(p,v,False)
    p=ROOT/'docs/current-research.json';v=read(p);v.update(current_primary_ticket='20',current_primary_ticket_assigned=False,active_tickets=['21'],next_ready_unassigned=['20'],implementation='Tickets14–19 accepted. Primary20 compares inspection and intervention value;21 personnel execution independently active. M3 remains in progress.');v['runtime_verification_documents'].append((PACKET/'README.md').as_posix());write(p,v,False)
    for name,old,new in [('docs/MAINLINE.md','当前主票19建立风险情景、时间窗及服务后果。','第19票风险情景已由根接受，当前主票20比较检查与处置价值。 [第19票数据图及复核包](../evidence/mainline/engineering/19-root-acceptance/README.md)。'),('docs/NEXT.md','当前主票19。','第19票已由根接受，当前主票20。 [风险后果图及复核包](../evidence/mainline/engineering/19-root-acceptance/README.md)。')]:
        p=ROOT/name;s=p.read_text(encoding='utf-8');assert old in s;s=s.replace(old,new,1);p.write_text(s,encoding='utf-8',newline='\n')
    p=ROOT/'docs/mainline/19-current-runtime-and-reproduction.md'
    text=p.read_text(encoding='utf-8')
    text+=chr(10)+chr(10)+'## 根接受'+chr(10)+chr(10)+'修复后集成源码`'+SOURCE+'`通过'+str(tests['executed'])+'项全执行回归，零失败、零错误、零跳过。720项Spec断言及完整时域边界独立Standards闭环通过，ticket19由单独[根权威](evidence/19-root.json)接受。原作者索引和原件保持原始身份；当前主票20，21另行验收。数据图与复算见[根验收包](../../evidence/mainline/engineering/19-root-acceptance/README.md)。'+chr(10)
    p.write_text(text,encoding='utf-8',newline=chr(10))
    print(json.dumps(dict(packet=PACKET.as_posix(),artifacts=len(declared),archive_members=sum(map(len,archives.values())),tests=tests,guarded_files=len(guard['actual_sources'])),ensure_ascii=False))

if __name__=='__main__':main()
