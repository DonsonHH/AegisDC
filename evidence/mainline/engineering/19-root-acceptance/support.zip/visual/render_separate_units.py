"""Present saved ticket19 work and deficit time on independent axes."""
from hashlib import sha256
from html import escape
import json
from pathlib import Path
import subprocess

ROOT=Path(__file__).resolve().parents[2]
OUT=Path(__file__).resolve().parent
SOURCE='7069f2bee86ef7cdfd8d4849bb98bb5dacbf59cc'
PATH='evidence/mainline/engineering/19-risk-scenarios/capture-01/check-results.json'
raw=subprocess.check_output(['git','cat-file','blob',SOURCE+':'+PATH],cwd=ROOT)
data=json.loads(raw);v=data['results'][-1]['full_horizon_service']
parts=['<svg xmlns="http://www.w3.org/2000/svg" width="1120" height="650" viewBox="0 0 1120 650" role="img">',
       '<title>Declared joint-service consequence law: work and time on separate axes</title>',
       '<metadata>Source '+SOURCE+' / '+PATH+' / SHA256 '+sha256(raw).hexdigest()+'</metadata>',
       '<rect width="1120" height="650" fill="#f7f9fc"/>',
       '<style>text{font-family:Arial,sans-serif;fill:#162b42}.title{font-size:25px;font-weight:bold}.h{font-size:19px;font-weight:bold}.b{font-size:16px}.note{font-size:14px;fill:#456079}.tick{font-size:13px}</style>']
def label(x,y,s,c='b',anchor='start'):
    parts.append(f'<text x="{x}" y="{y}" class="{c}" text-anchor="{anchor}">{escape(str(s))}</text>')
def line(x1,y1,x2,y2):
    parts.append(f'<line x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" stroke="#c9d4e1"/>')
label(35,40,'Joint service consequences | separate work and time axes','title')
label(35,70,'Two-report public belief at 12 s · declared 2 s synthetic consequence law · no site calibration','note')
label(35,115,'A · Normalized service work','h')
left,width=260,700
for t in (0,.5,1,1.5,2,2.5):
    x=left+t/2.5*width;line(x,140,x,320);label(x,343,f'{t:.1f}','tick','middle')
for i,(key,name,color) in enumerate([('offered_service_unit_s','Offered work','#657992'),('delivered_service_unit_s','Delivered work','#007b9c'),('unserved_service_unit_s','Unserved work','#b45319')]):
    y=155+i*58;value=v[key]['value'];label(35,y+23,name);parts.append(f'<rect x="{left}" y="{y}" width="{value/2.5*width:.3f}" height="32" fill="{color}"/>');label(985,y+23,f'{value:.6f}','b')
label(610,370,'Normalized service-unit seconds','b','middle')
label(35,420,'B · Fractional service-deficit time','h')
value=v['service_deficit_time_s']['value']
for t in (0,.5,1,1.5,2):
    x=left+t/2*width;line(x,445,x,510);label(x,535,f'{t:.1f}','tick','middle')
parts.append(f'<rect x="{left}" y="460" width="{value/2*width:.3f}" height="32" fill="#8448a4"/>');label(35,484,'Unserved fraction integral');label(985,484,f'{value:.6f} s')
label(610,562,'Seconds of fractional deficit within the 2 s horizon','b','middle')
label(35,605,'Common offered demand is fixed across outcomes. Shared service losses are counted once.','note')
label(35,629,'These finite conditional accounts do not quantify the six unmodeled domain probabilities or demonstrate method gain.','note')
parts.append('</svg>')
target=OUT/'separate-service-units.svg'
with target.open('x',encoding='utf-8',newline='\n') as f:f.write('\n'.join(parts)+'\n')
receipt=dict(source_commit=SOURCE,source_path=PATH,source_sha256=sha256(raw).hexdigest(),
    svg_sha256=sha256(target.read_bytes()).hexdigest(),generator_sha256=sha256(Path(__file__).read_bytes()).hexdigest(),
    classification='SAVED_DATA_PRESENTATION_ONLY',inference_rerun=False,physical_rerun=False)
with (OUT/'separate-units-source.json').open('x',encoding='utf-8',newline='\n') as f:f.write(json.dumps(receipt,indent=2)+'\n')
