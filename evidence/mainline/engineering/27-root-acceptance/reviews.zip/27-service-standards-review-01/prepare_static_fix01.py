"""Preserve the failed reviewer assertion and resume exact static checks."""
from hashlib import sha256
import json
from pathlib import Path

OUT=Path(__file__).resolve().parent
original=OUT/'audit_saved.py';raw=original.read_bytes()
failure=dict(classification='REVIEWER_STATIC_ASSERTION_FAILURE_NOT_PRODUCT_FAILURE',
    script=original.name,sha256=sha256(raw).hexdigest(),exit_code=1,line=132,
    error='AssertionError: sole tool behavior correction stable time ordering',
    cause='Reviewer token replacement accounted for the comparator change but missed its same-hunk line wrap. Exact no-index Git diff confirmed no other behavior change.',new_project_calls=0)
with (OUT/'static-audit-failure-01.json').open('x',encoding='utf-8') as stream:json.dump(failure,stream,ensure_ascii=False,indent=2)
code=raw.decode('utf-8')
before='    with path.open(\'xb\') as stream:stream.write(raw)'
after='    if path.exists():\n        assert path.read_bytes()==raw, name\n        return\n    with path.open(\'xb\') as stream:stream.write(raw)'
assert code.count(before)==1;code=code.replace(before,after)
before='old_tool.replace("key=lambda row: (row[\'time_s\'], row[\'parameter_id\'])","key=lambda row: row[\'time_s\']")==new_tool'
after='old_tool.replace("sorted(inputs[\'boundary_events\'],\\n                        key=lambda row: (row[\'time_s\'], row[\'parameter_id\']))", "sorted(inputs[\'boundary_events\'], key=lambda row: row[\'time_s\'])")==new_tool'
assert code.count(before)==1;code=code.replace(before,after)
with (OUT/'audit_saved_fix01.py').open('x',encoding='utf-8',newline='\n') as stream:stream.write(code)
