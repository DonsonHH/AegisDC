"""Read fixed Git/source/ZIP bytes and independent service literals. No project calls."""
import ast
from collections import Counter
from fractions import Fraction as F
from hashlib import sha256
import json
import math
from pathlib import Path, PurePosixPath
import subprocess
import zipfile

OUT=Path(__file__).resolve().parent
REPO=Path('C:/Users/Donson/.codex/worktrees/mainline27-full-loop/Renly')
BASE='7779696d5db603b639a19bc6c95daf97ba37a410'
SOURCE='12aa08fc974abaf4a7f4d1a9f152bd545aa97a57'
PREFIX='evidence/mainline/engineering/27-full-loop/'
TOOL='scripts/full_loop_development.py'
TEST='tests/test_full_loop_service.py'
SENSOR='src/aegis_dc/sensor_channels.py'
REFERENCE='evidence/mainline/engineering/25-baselines/reference/no-human.json'
PROPERTY='configs/materials/reference-r134a-saturation.json'
TICKET='.scratch/full-facility-mainline/issues/27-full-loop-demo.md'
SPEC='.scratch/full-facility-mainline/spec.md'
PRIOR=('26-projection-standards-review-01','26-online-standards-review-01','27-contract-standards-review-01')
checks=[]
def check(name,condition):
    ok=bool(condition);checks.append(dict(name=name,passed=ok))
    if not ok:raise AssertionError(name)
def digest(raw):return sha256(raw).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=REPO)
def write(name,raw):
    path=OUT/name;path.parent.mkdir(parents=True,exist_ok=True)
    if path.exists():
        assert path.read_bytes()==raw, name
        return
    with path.open('xb') as stream:stream.write(raw)
def jwrite(name,value):write(name,(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode())
def snapshot():return {p.relative_to(OUT.parent).as_posix():digest(p.read_bytes()) for name in PRIOR for p in sorted((OUT.parent/name).rglob('*')) if p.is_file()}
def artifact(name):return (OUT/'export'/name).read_bytes()
def source(name):return artifact(name).decode('utf-8')
def data(name):return json.loads(artifact(name))
def path_is_durable(name):
    p=PurePosixPath(name)
    return p.as_posix()==name and not p.is_absolute() and '..' not in p.parts and '\\' not in name and ':' not in name and '__pycache__' not in p.parts and p.suffix not in {'.pyc','.pyo'}
def tree(rev,*paths):return set(git('ls-tree','-r','--name-only',rev,'--',*paths).decode().splitlines())
def line(text,token):return next(i for i,s in enumerate(text.splitlines(),1) if token in s)

before=snapshot();jwrite('prior-reviews-before.json',before)
check('fixed base ancestry',git('merge-base',BASE,SOURCE).decode().strip()==BASE)
diff=git('diff',BASE+'...'+SOURCE);check('nonempty diff',bool(diff));write('candidate.diff',diff)
write('commits.txt',git('log','--format=%H %s',BASE+'..'+SOURCE))
changed=set(git('diff','--name-only',BASE+'...'+SOURCE).decode().splitlines())
check('only sensor whitelist runtime file changed',{n for n in changed if n.startswith('src/')}=={SENSOR})
standards=['AGENTS.md','GLOSSARY.md','docs/MAINLINE.md',SPEC,'docs/adr/0003-complete-facility-mainline.md','docs/agents/domain.md','docs/agents/issue-tracker.md','docs/agents/triage-labels.md']
all_names=tree(SOURCE)
extra_standards=sorted(n for n in all_names if PurePosixPath(n).name.upper() in {'CODING_STANDARDS.MD','CONTRIBUTING.MD'})
check('no missing coding/contributing standard',not extra_standards)
related=[*('src/aegis_dc/'+m+'.py' for m in ['plant','power','evidence_ledger','live_sensor_execution','policy_execution']),REFERENCE,PROPERTY,'docs/mainline/27-cross-system-loop-contract.md']
paths=sorted(changed|set(standards+related+extra_standards));base_paths=sorted((set(standards+related)|{SENSOR})&tree(BASE))
keys=[SOURCE+':'+n for n in paths]+[BASE+':'+n for n in base_paths]
batch=subprocess.check_output(['git','cat-file','--batch'],cwd=REPO,input=''.join(k+'\n' for k in keys).encode())
blobs={};blob_ids={};offset=0
for key in keys:
    end=batch.index(b'\n',offset);header=batch[offset:end].split();assert len(header)==3 and header[1]==b'blob',key
    start=end+1;size=int(header[2]);blobs[key]=batch[start:start+size];blob_ids[key]=header[0].decode();offset=start+size+1
check('fixed Git batch exact end',offset==len(batch))
exports={}
for name in paths:
    key=SOURCE+':'+name;raw=blobs[key];write('export/'+name,raw)
    exports[name]=dict(git_blob=blob_ids[key],sha256=digest(raw),bytes=len(raw))
    check('fixed export exact '+name,artifact(name)==raw)
    if name.endswith('.py'):ast.parse(raw.decode('utf-8'),filename=name);check('AST parse '+name,True)
for name in base_paths:
    raw=blobs[BASE+':'+name];write('base-export/'+name,raw)
    if name!=SENSOR:check('unchanged standards, contracts or predecessor original '+name,raw==artifact(name))
jwrite('source-manifest.json',dict(base=BASE,source=SOURCE,changed_files=sorted(changed),files=exports,standards=standards,base_exports=base_paths,new_project_calls=0))

old_sensor=blobs[BASE+':'+SENSOR].decode('utf-8');sensor=source(SENSOR)
new_mapping="    # Instantaneous normalized delivered rate, independent of the offered-demand ratio.\n    'joint_service_delivered': dict(target='critical_service', quantity='service_capacity', unit='1',\n        path=('it_service', 'delivered'), reported=False),\n"
check('exact additive one signal entry',sensor.count(new_mapping)==1 and sensor.replace(new_mapping,'')==old_sensor)
check('closed whitelist target quantity units checked',all(t in sensor for t in ("row['signal'] in SIGNALS","row['target_id'] == signal['target']","signal['quantity']","signal['unit']")))
check('live producer only actual current epoch',"snapshot['time_s']==time_s" in source('src/aegis_dc/live_sensor_execution.py') and 'points=[snapshot]' in source('src/aegis_dc/live_sensor_execution.py'))
check('existing sampler keeps missing/provenance and delay',all(t in sensor for t in ("measurement['input_range'][0] <= signal <= measurement['input_range'][1]","arrived_at_s=_number(Fraction(polled) + Fraction(channel['delay_s'])","provenance=dict(origin_id=origin, copied_from_record_id=None)")))
check('private signal remains audit side',"private_signal=signal" in sensor and "state_visibility='PRIVATE_EVALUATOR_ONLY'" in sensor)
plant=source('src/aegis_dc/plant.py');power=source('src/aegis_dc/power.py')
check('rate comes from actual service capacity, not a ratio of demand',"delivery = min(p['service_demand'], *capacities.values())" in plant and "'it_service': point['service']" in plant and "actual[name] / p[name + '_nominal_power']" in plant)
check('per unit demand power multiplied by demand/capacity',"p[name + '_demand_power'] * min(p['service_demand'], p[name + '_service_capacity'])" in power)
check('current sensor sample precedes same instant public decision',plant.index('dispatch.sensors.process(time_s,snapshot)')<plant.index('dispatch.process(time_s,workforce,inspections,interventions)'))
tests=source(TEST)
check('new attempt UUID and no overwrite',"'service-' + uuid4().hex" in tests and 'exist_ok=False' in tests)
check('precall ordered inputs, runtime/tool pins, fsynced STARTED',tests.index('snapshot.write_bytes(raw)')<tests.index("_json_new(folder / 'input.json'")<tests.index("_json_new(folder / 'attempt.json'")<tests.index('result = simulate_scenario(') and 'os.fsync(stream.fileno())' in tests and "status='STARTED'" in tests)
check('precall snapshots exact test tool, model reference and property table',"support = [Path(__file__), REFERENCE, ROOT / model['runtime']['property_table']]" in tests)
check('terminal always retained and source guard fail closed',"_json_new(folder / 'terminal.json', terminal)" in tests and 'except (OSError, subprocess.SubprocessError)' in tests and "status='FAILED_SOURCE_GUARD'" in tests)
check('terminal physical completion distinct from test acceptance','PHYSICAL_CALL_COMPLETED_NOT_TEST_ACCEPTANCE' in tests)
check('malformed profile three public refusal declarations',all(t in tests for t in ('private_failure_label',"meter['target_id'] = 'network'","['unit'] = 'W'",'validate_channel_profile(profile)')))

formats=data(PREFIX+'development-log-formats.json')['logs'];attrs=source(PREFIX+'.gitattributes')
check('exact four path CRLF exceptions',len(formats)==4 and {l.split()[0] for l in attrs.splitlines() if l and not l.startswith('#')}==set(formats))
for name,identity in formats.items():
    raw=artifact(PREFIX+name)
    check('exact native CRLF original '+name,digest(raw)==identity['sha256'] and raw.count(b'\r\n')==identity['crlf_lines'] and b'\n' not in raw.replace(b'\r\n',b''))
    check('only prescribed CRLF attr '+name,name+' -text whitespace=blank-at-eol,blank-at-eof,space-before-tab,cr-at-eol' in attrs)
logs={name[:2]:source(PREFIX+name) for name in ()}
logs={PurePosixPath(name).name[:2]:source(PREFIX+name) for name in formats}
check('01 remains whitelist refusal ERROR', 'FAILED (errors=1)' in logs['01'] and 'Signal is not in the declared measurable whitelist' in logs['01'])
check('02 remains failed initial value oracle','FAILED (failures=1)' in logs['02'] and '[0.25, 1.0, 0.0] != [0.5, 1, 0]' in logs['02'])
corrected=json.loads(logs['03'].splitlines()[-1]);check('03 saved-only oracle correction retains failure',corrected['status']=='PASS_SAVED_ORIGINAL_WITH_EXPLICIT_CORRECTED_ORACLE' and corrected['original_green_test_status']=='FAILED_ORACLE' and corrected['new_physical_runs']==corrected['new_selector_calls']==0)
check('04 saved profile-only unit method passes','Ran 1 test' in logs['04'] and logs['04'].rstrip().endswith('OK') and 'refuses_an_unlisted_signal_wrong_target_or_unit' in logs['04'])

package_names=[PREFIX+'development-service-20261107-'+n+'/' for n in ('01','02')]
packages=[]
for package in package_names:
    declaration,receipt,members=(data(package+n) for n in ('declaration.json','receipt.json','members.json'))
    check('exact fixed package durable set '+package,{n.removeprefix(package) for n in all_names if n.startswith(package)}=={'declaration.json','receipt.json','members.json','originals.zip'})
    check('exact declared package roles '+package,set(declaration['artifacts'])==set(receipt['artifacts'])=={'declaration.json','members.json','originals.zip'} and declaration['cache_classification']=='EXCLUDED_RUNTIME_CACHES')
    check('development-only receipt classification '+package,receipt['classification']=='SAVED_ORIGINALS_NOT_FORMAL_CAPTURE_OR_TICKET_ACCEPTANCE')
    for name,identity in receipt['artifacts'].items():check('receipt exact original artifact '+package+name,digest(artifact(package+name))==identity)
    check('declared logs exact native originals '+package,declaration['logs']=={PREFIX+name:v['sha256'] for name,v in formats.items()})
    with zipfile.ZipFile(OUT/'export'/(package+'originals.zip')) as archive:
        names=archive.namelist();check('all150 unique ZIP members '+package,len(names)==len(set(names))==len(members)==receipt['members']==150 and set(names)==set(members))
        cache={}
        for name,identity in members.items():
            raw=archive.read(name);cache[name]=raw
            check('durable exact ZIP member '+package+name,path_is_durable(name) and len(raw)==identity['bytes'] and digest(raw)==identity['sha256'])
    check('two unique actual ZIP case roots '+package,len(declaration['cases'])==len(set(declaration['cases']))==2 and set(declaration['cases'])=={n.split('/',1)[0] for n in cache})
    packages.append((declaration,receipt,members,cache))
d1,r1,m1,z1=packages[0];d2,r2,m2,z2=packages[1]
check('second pack preserves all original150 bytes unchanged',d1==d2 and m1==m2 and z1==z2 and r1['attempts']==r2['attempts'])
failure_prefix=PREFIX+'development-service-packaging-01/'
failure=data(failure_prefix+'failure.json');old_tool=source(failure_prefix+'first-tool.py');new_tool=source(TOOL)
check('first packaging failure explicitly distinct physics',failure['status']=='FAILED_TOOL_CHECK_NOT_PHYSICAL_FAILURE' and failure['error']=='Actual saved input differs' and failure['new_simulation_calls']==failure['new_selector_calls']==0)
check('first preserved package hashes exact',failure['failed_package']+'/'==package_names[0] and failure['retained_package_members']=={n:digest(artifact(package_names[0]+n)) for n in ('declaration.json','receipt.json','members.json','originals.zip')})
check('first tool exact hash retained',digest(artifact(failure_prefix+'first-tool.py'))==r1['tool_sha256']==failure['first_tool_sha256'])
check('second tool fixed hash exact',digest(artifact(TOOL))==r2['tool_sha256'])
check('sole tool behavior correction stable time ordering',old_tool.replace("sorted(inputs['boundary_events'],\n                        key=lambda row: (row['time_s'], row['parameter_id']))", "sorted(inputs['boundary_events'], key=lambda row: row['time_s'])")==new_tool and old_tool!=new_tool)
check('runtime boundary copied before separately sorting events',"return sorted(result, key=lambda item: item['time_s'])" in plant and plant.index('boundary_inputs = deepcopy(timed_inputs)')<plant.index('timed_inputs = sorted([dict(row, kind=') )
events=failure['comparison'];stable=sorted(events['boundary_original'],key=lambda row:row['time_s'])
check('failed sorting reproduced from saved bytes only',stable==events['boundary_saved'] and sorted(events['boundary_original'],key=lambda row:(row['time_s'],row['parameter_id']))!=stable and events['dispatch_equal'] and events['model_equal'])

runtime={n for n in tree(SOURCE,'src') if n.endswith('.py')};code_set={n for n in runtime if n.startswith('src/aegis_dc/') or n=='src/patrol_rsi/contracts.py'}
check('67 runtime source files and36 executed code identity set',len(runtime)==67 and len(code_set)==36)
runtime_keys=sorted(runtime);runtime_batch=subprocess.check_output(['git','cat-file','--batch'],cwd=REPO,input=''.join(SOURCE+':'+n+'\n' for n in runtime_keys).encode())
final_runtime={};offset=0
for name in runtime_keys:
    end=runtime_batch.index(b'\n',offset);header=runtime_batch[offset:end].split();assert len(header)==3 and header[1]==b'blob',name
    start=end+1;size=int(header[2]);final_runtime[name]=digest(runtime_batch[start:start+size]);offset=start+size+1
check('final runtime fixed batch exact end',offset==len(runtime_batch))
case_rows=[];runs=[];frozen_inputs=[]
for row in r2['attempts']:
    case=row['case'];prefix=case+'/';attempt=json.loads(z2[prefix+'attempt.json']);terminal=json.loads(z2[prefix+'terminal.json']);inputs=json.loads(z2[prefix+'input.json']);frozen_inputs.append(inputs)
    check('STARTED plus original terminal '+case,attempt['status']=='STARTED' and attempt['source_commit']==terminal['source_commit'] and attempt['started_public_run_calls']==1 and attempt['registered_research_trials']==0 and terminal['source_unchanged'] is True)
    check('attempt commit observed predecessor with dirty test source provenance '+case,attempt['source_commit']==git('rev-parse',SOURCE+'^').decode().strip())
    check('original status matches exact receipt '+case,row['terminal']==terminal['status'] and row['integration_returned']==terminal['integration_returned'])
    check('original precall exact set '+case,set(attempt['source_files'])==runtime|{TEST,REFERENCE,PROPERTY} and {n.removeprefix(prefix+'pre-call/') for n in z2 if n.startswith(prefix+'pre-call/')}==set(attempt['source_files']))
    for name,expected in attempt['source_files'].items():check('exact captured precall hash '+case+'/'+name,digest(z2[prefix+'pre-call/'+name])==expected)
    for name in (REFERENCE,PROPERTY):check('precall input dependency unchanged '+case+'/'+name,z2[prefix+'pre-call/'+name]==artifact(name))
    expected_runtime=dict(final_runtime)
    if not terminal['integration_returned']:expected_runtime[SENSOR]=digest(blobs[BASE+':'+SENSOR])
    check('all captured runtime bytes match exact intended revision '+case,{n:attempt['source_files'][n] for n in runtime}==expected_runtime)
    check('frozen actual development input extent '+case,inputs['duration_s']==1.25 and inputs['maximum_step_s']==.01)
    case_rows.append(dict(case=case,source_commit=attempt['source_commit'],terminal=terminal['status'],precall_pins=len(attempt['source_files'])))
    if terminal['integration_returned']:
        run=json.loads(z2[prefix+'original/run.json']);runs.append((prefix,run,inputs,terminal))
        check('executed actual source identity matches terminal/attempt, dirty marked '+case,run['code_identity']==terminal['executed_source'] and run['code_identity']['git_commit']==attempt['source_commit'] and run['code_identity']['implementation_has_changes'] is True and run['code_identity']['files']=={n:attempt['source_files'][n] for n in code_set})
        check('saved actual run exact scenario/program/events '+case,json.loads(z2[prefix+'original/scenario.json'])==inputs['model'] and run['inputs']['dispatch_program']==inputs['dispatch_program'] and run['inputs']['boundary_events']==stable==sorted(inputs['boundary_events'],key=lambda x:x['time_s']) and run['inputs']['duration_s']==inputs['duration_s'] and run['inputs']['maximum_step_s']==inputs['maximum_step_s'])
        check('exact original saved run member roles '+case,set(run['artifacts'])=={'scenario.json','balances.jsonl','private-state.jsonl'})
        for name,identity in run['artifacts'].items():check('saved actual physical original hash '+name,digest(z2[prefix+'original/'+name])==identity['sha256'])
        check('archive has initial failed oracle code, not post-hoc relabel',"[.5, 1, 0]" in z2[prefix+'pre-call/'+TEST].decode() and "[.25, 1, 0]" in tests)
    else:
        check('RED refused no physical original '+case,terminal['status']=='FAILED' and terminal['error_type']=='ValueError' and 'declared measurable whitelist' in terminal['error'] and not any(n.startswith(prefix+'original/') for n in z2))
check('exact same original fixture inputs RED versus first integration',len(frozen_inputs)==2 and frozen_inputs[0]==frozen_inputs[1])
check('two development public calls only one completed integration',len(case_rows)==2 and len(runs)==1)
prefix,run,inputs,terminal=runs[0]
check('saved-only03 references same actual case',corrected['saved_run'].endswith('/'+prefix.removesuffix('/')+'/original'))
trace=[json.loads(line) for line in z2[prefix+'original/private-state.jsonl'].splitlines()]
balances=[json.loads(line) for line in z2[prefix+'original/balances.jsonl'].splitlines()]
private_by_time={row['time_s']:row['domains'] for row in trace};service_rows=[private_by_time[t]['it_service'] for t in (0,.5,1)]
check('three actual sampled rate points quarter/full/zero',[r['delivered'] for r in service_rows]==[.25,1,0] and [r['demand'] for r in service_rows]==[.5,1,1])
check('first actual .5MW vs2MW nominal proves rate not ratio',private_by_time[0]['power']['actual_powers_W']['compute']==500000 and F(500000,2000000)==F(1,4) and service_rows[0]['delivered']/service_rows[0]['demand']==.5)
decisions=run['policy_public_decisions'];check('seven decisions at declared actual clocks',[d['frame']['as_of_s'] for d in decisions]==inputs['dispatch_program']['decision_times_s'])
per_decision=[]
for d in decisions:
    frame=d['frame'];now=frame['as_of_s'];rows=[r for r in frame['evidence']['records'] if r['source_id']=='service-meter-record'];per_decision.append(rows)
    check('public frame all records already arrived '+str(now),all(r['observed_at_s']<=r['arrived_at_s']<=now for r in frame['evidence']['records']))
    check('public no evaluator channels or execution permission '+str(now),not ({'domains','private_signal','private_realization','policy_sensor_private_audit'} & set(frame)) and not d['choice']['execution_permission'])
check('strict arrival count boundaries',[len(rows) for rows in per_decision]==[0,0,1,1,2,2,3])
records=per_decision[-1]
check('public final records exactly sampled values with unavailable0 masked',[(r['observed_at_s'],r['arrived_at_s'],r['value']) for r in records]==[(0,.25,.25),(.5,.75,1),(1,1.25,None)])
check('public provenance exact unique origin IDs',[r['provenance']['origin_id'] for r in records]==['service-meter@0','service-meter@1/2','service-meter@1'] and all(r['provenance']['copied_from_record_id'] is None for r in records))
check('public unit target and quality retained',all(r['target_id']=='critical_service' and r['observable_id']=='service_delivered_rate' and r['unit']=='1' for r in records) and [r['quality']['status'] for r in records]==['bounded','bounded','unknown'] and records[-1]['availability']=='missing')
private_meter=[r for r in run['policy_sensor_private_audit'] if r['measurement_id']=='service-meter']
check('private actual zero preserved evaluator only',[r['private_signal'] for r in private_meter]==[.25,1,0] and [r['polled_at_s'] for r in private_meter]==[0,.5,1])
check('prior fixed power sensing still running',any(r['measurement_id']!='service-meter' for r in run['policy_sensor_private_audit']))
check('no human work and no research',run['work_records']==[] and run['research_trials']==run['training_calls']==run['model_calls']==0 and run['field_calibration']=='PENDING')
check('full original bounded actual trace',len(trace)==len(balances)+1 and trace[0]['time_s']==0 and trace[-1]['time_s']==1.25 and all(0<r['end_s']-r['start_s']<=.01+1e-9 for r in balances))
independent=dict(demand_service_unit_s=F(1,2)*F(1,2)+F(3,4),delivered_service_unit_s=F(1,4)*F(1,2)+F(1,2),service_deficit_time_s=F(1,4)+F(1,4))
for field,value in independent.items():check('literal integrals exact '+field,math.isclose(run['summary'][field],float(value),abs_tol=1e-12,rel_tol=0) and math.isclose(math.fsum(r[field] for r in balances),float(value),abs_tol=1e-12,rel_tol=0))

progress=data('docs/mainline/progress.json');ticket=source(TICKET)
check('ticket27 claimed and root owner liveness metadata',progress['current_ticket']=='27' and progress['active_implementations'][0]['agent']=='/root' and '**Status:** claimed' in ticket)
check('not formal accepted27 or trial advancement',progress['status']=='active' and progress['research_trials']['attempts']==0 and 'no formal capture or research trial has run' in ticket)
check('old reviews still exact files/hashes',snapshot()==before);jwrite('prior-reviews-after.json',before)
diffcheck=subprocess.run(['git','diff','--check',BASE+'...'+SOURCE],cwd=REPO,capture_output=True)
check('full fixed Git diff check no skips',diffcheck.returncode==0 and not diffcheck.stdout and not diffcheck.stderr)

# Independent control-flow finding. The two fixed committed packages above are complete.
verify=next(n for n in ast.parse(new_tool).body if isinstance(n,ast.FunctionDef) and n.name=='verify')
verify_source=ast.get_source_segment(new_tool,verify)
check('nested file coverage gap witnessed at fixed tool',"{p.name for p in folder.iterdir() if p.is_file()} == FILES" in verify_source and 'folder.rglob(' not in verify_source)
check('ZIP case root closure gap witnessed at fixed tool',"for case in declaration['cases']" in verify_source and "set(declaration['cases'])" not in verify_source)
findings=[dict(id='STD-27-SERVICE-PACKAGE-01',priority=2,kind='durable_verification_contract',file=TOOL,
    lines=[line(new_tool,"if p.is_file()} == FILES"),line(new_tool,"for case in declaration['cases']")],
    standard='AGENTS.md Interfaces and verification: define the durable delivery set; verify declared artifacts against manifests and committed blobs.',
    detail='Fresh verify checks only immediate files; an extra nested durable file is invisible even if committed. Within ZIP it verifies hashes but counts only declaration.cases, so an additional ZIP case included in members.json is not counted as an attempt. The two fixed archives themselves contain exactly the two original cases and150 members.',
    remediation='Recursively compare durable package files; require unique declared cases equal the ZIP first-component attempt set. Do not rewrite either frozen archive/receipt/tool identity; use a separate verifier revision.',
    blocks='Root/fresh use of this verifier as exact delivery authority; not the sensor implementation or fixed saved bytes',new_project_calls=0)]
jwrite('checks.json',checks)
jwrite('saved-originals.json',dict(cases=case_rows,archive_members=150,same_members_both_packages=True,actual_integrations_returned=1,
    actual_duration_s=1.25,physical_oracle_failure_preserved=True,refusal_no_saved_trace=True,rate_samples=[.25,1,0],published_last_value=None,
    literal_integrals={k:[v.numerator,v.denominator] for k,v in independent.items()},new_project_calls=0))
report='''Standards：保存原件 PASS，验证工具有1项P2。\n\n硬规则：服务白名单只采当前实际交付速率，需求比例和私有真值不进入公开记录。0.25、1到时可用，量程外实际0送达为缺失。两次开发调用仅1次完成1.25秒物理；01拒绝、02断言失败、03保存修正和04拒绝检查均保留。两包150成员字节相同，首次封包排序失败及工具、原CRLF已核。\n\nP2：full_loop_development.py:47、64仅核顶层文件并遍历声明case，未闭合嵌套耐久文件与ZIP实际case根集；不符合AGENTS声明集合核验。应另修验证器，保留原包。启发性异味无。0项目调用，27仍未接受。\n'''
write('report.md',report.encode('utf-8'))
jwrite('review.json',dict(schema='aegisdc-independent-standards-review-v1',axis='Standards',status='CHANGES_REQUIRED',saved_originals_status='PASS',runtime_scope_status='PASS',base=BASE,source=SOURCE,
    scope='Fixed27 service whitelist, two preserved development attempts and both saved packaging tools/archives; Git/AST/Fraction/ZIP only',checks=len(checks),exports=len(exports),
    archive_members=150,attempts=2,physical_integrations_returned=1,prior_review_files_preserved=len(before),hard_findings=findings,heuristic_findings=[],unresolved=[findings[0]['id']],
    new_project_calls=0,tests_run=0,selectors_run=0,assessments_run=0,inference_calls=0,simulation_calls=0,formal_capture=False,ticket_acceptance=False))
artifacts={p.relative_to(OUT).as_posix():dict(sha256=digest(p.read_bytes()),bytes=p.stat().st_size) for p in sorted(OUT.rglob('*')) if p.is_file()}
jwrite('delivery-manifest.json',dict(schema='aegisdc-static-review-delivery-manifest-v1',source=SOURCE,artifacts=artifacts,terminal_receipt='delivery-manifest.json',new_project_calls=0))
print(json.dumps(dict(status='CHANGES_REQUIRED',saved_originals='PASS',checks=len(checks),prior=len(before),exports=len(exports),report_chars=len(report),report_sha256=digest((OUT/'report.md').read_bytes()),review_sha256=digest((OUT/'review.json').read_bytes()),new_project_calls=0)))
