"""Independent saved-byte and AST review for ticket27 service producer only."""
import ast
from fractions import Fraction as F
from hashlib import sha256
import json
import math
from pathlib import Path, PurePosixPath
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parent
REPO = Path(r'C:\Users\Donson\.codex\worktrees\mainline27-full-loop\Renly')
SOURCE = '12aa08fc974abaf4a7f4d1a9f152bd545aa97a57'
BASE = '7779696d5db603b639a19bc6c95daf97ba37a410'
PACKAGE = 'evidence/mainline/engineering/27-full-loop'
checks = []


def check(name, okay):
    checks.append(dict(name=name, passed=bool(okay)))
    assert okay, name


def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO)


def digest(data):
    return sha256(data).hexdigest()


def read(path):
    return json.loads(path.read_bytes())


def batch(revision, names):
    names = sorted(names)
    buffer = subprocess.check_output(['git', 'cat-file', '--batch'], cwd=REPO,
        input=''.join(revision + ':' + name + '\n' for name in names).encode())
    offset = 0;results = {}
    for name in names:
        end = buffer.index(b'\n', offset);fields = buffer[offset:end].split()
        check('expected Git blob ' + revision[:8] + ':' + name, len(fields) == 3 and fields[1] == b'blob')
        length = int(fields[2]);start = end + 1
        results[name] = digest(buffer[start:start + length]);offset = start + length + 1
    check('batch exact bytes ' + revision[:8], offset == len(buffer))
    return results


def close(actual, expected):
    return math.isclose(actual, float(expected), rel_tol=0, abs_tol=1e-12)


pins = read(ROOT / 'source-pins.json');export = ROOT / 'export'
for name, identity in pins['exports'].items():
    raw = (export / name).read_bytes()
    check('fixed Git exact export ' + name, raw == git('cat-file', 'blob', SOURCE + ':' + name) and
          digest(raw) == identity['sha256'] and len(raw) == identity['bytes'])
prior = read(ROOT / 'prior-contract-hashes.json')
for name, expected in prior.items():
    check('prior27 contract review unchanged ' + name, digest((ROOT.parent / '27-contract-spec-review-01' / name).read_bytes()) == expected)
check('only sensor runtime file changed', git('diff', '--name-only', BASE, SOURCE, '--', 'src').decode().splitlines() == ['src/aegis_dc/sensor_channels.py'])
old = (ROOT / 'base-sensor_channels.py').read_bytes();new = (export / 'src/aegis_dc/sensor_channels.py').read_bytes()
check('base exact sensor blob', old == git('cat-file', 'blob', BASE + ':src/aegis_dc/sensor_channels.py'))
old_tree = ast.parse(old);new_tree = ast.parse(new)
signal_map = next(n.value for n in new_tree.body if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'SIGNALS' for t in n.targets))
idx = next(i for i, n in enumerate(signal_map.keys) if isinstance(n, ast.Constant) and n.value == 'joint_service_delivered')
added = signal_map.values[idx]
check('narrow fixed numeric service binding', isinstance(added, ast.Call) and isinstance(added.func, ast.Name) and added.func.id == 'dict' and not added.args and
      {k.arg: ast.literal_eval(k.value) for k in added.keywords} == dict(target='critical_service', quantity='service_capacity', unit='1', path=('it_service', 'delivered'), reported=False))
signal_map.keys.pop(idx);signal_map.values.pop(idx)
check('all previous sensor laws unchanged', ast.dump(old_tree, include_attributes=False) == ast.dump(new_tree, include_attributes=False))

pkg = export / PACKAGE;archives = {};results = {};versions = {}
for suffix in ['01', '02']:
    folder = pkg / ('development-service-20261107-' + suffix)
    declaration = read(folder / 'declaration.json');receipt = read(folder / 'receipt.json');members = read(folder / 'members.json')
    check('declared durable package ' + suffix, {p.name for p in folder.iterdir() if p.is_file()} == set(declaration['artifacts']) | {'receipt.json'} and set(receipt['artifacts']) == set(declaration['artifacts']))
    for name, expected in receipt['artifacts'].items():
        check('package artifact hash ' + suffix + ':' + name, digest((folder / name).read_bytes()) == expected)
    for name, expected in declaration['logs'].items():
        check('original log hash ' + suffix + ':' + name, digest((export / name).read_bytes()) == expected)
    check('no acceptance promotion ' + suffix, receipt['classification'] == 'SAVED_ORIGINALS_NOT_FORMAL_CAPTURE_OR_TICKET_ACCEPTANCE')
    original_tool = pkg / 'development-service-packaging-01/first-tool.py' if suffix == '01' else export / receipt['tool']
    check('package exact authoring tool ' + suffix, digest(original_tool.read_bytes()) == receipt['tool_sha256'])
    with zipfile.ZipFile(folder / 'originals.zip') as z:
        check('150 declared unique members ' + suffix, len(z.namelist()) == len(set(z.namelist())) == len(members) == receipt['members'] == 150 and set(z.namelist()) == set(members))
        archives[suffix] = {name: z.read(name) for name in z.namelist()}
        for name, identity in members.items():
            path = PurePosixPath(name);raw = archives[suffix][name]
            check('durable archived original ' + suffix + ':' + name, not path.is_absolute() and '..' not in path.parts and
                  '__pycache__' not in path.parts and path.suffix not in {'.pyc', '.pyo'} and digest(raw) == identity['sha256'] and len(raw) == identity['bytes'])
    versions[suffix] = dict(declaration=declaration, receipt=receipt, members=members)
check('packaging retry retains identical original member bytes', archives['01'] == archives['02'] and versions['01']['members'] == versions['02']['members'])
failure = read(pkg / 'development-service-packaging-01/failure.json')
check('failed packaging classification remains separate', failure['status'] == 'FAILED_TOOL_CHECK_NOT_PHYSICAL_FAILURE' and failure['new_simulation_calls'] == failure['new_selector_calls'] == 0)
for name, expected in failure['retained_package_members'].items():
    check('failed original retained ' + name, digest((pkg / 'development-service-20261107-01' / name).read_bytes()) == expected)
check('failed original tool retained', digest((pkg / 'development-service-packaging-01/first-tool.py').read_bytes()) == failure['first_tool_sha256'])

archive = archives['02'];receipt = versions['02']['receipt'];cases = versions['02']['declaration']['cases']
check('exact two development call identities', len(cases) == len(set(cases)) == len(receipt['attempts']) == 2)
for case in cases:
    prefix = case + '/';attempt = json.loads(archive[prefix + 'attempt.json']);terminal = json.loads(archive[prefix + 'terminal.json'])
    inputs = json.loads(archive[prefix + 'input.json']);run = json.loads(archive[prefix + 'original/run.json']) if prefix + 'original/run.json' in archive else None
    check('original STARTED and same head terminal ' + case, attempt['status'] == 'STARTED' and attempt['started_public_run_calls'] == 1 and
          terminal['source_commit'] == attempt['source_commit'] and terminal['source_unchanged'] and attempt['registered_research_trials'] == 0)
    check('70 exact source/tool/input snapshots ' + case, len(attempt['source_files']) == 70)
    for name, expected in attempt['source_files'].items():
        check('pre-call exact archived bytes ' + case + ':' + name, digest(archive[prefix + 'pre-call/' + name]) == expected)
    runtime = {n: h for n, h in attempt['source_files'].items() if n.startswith('src/')}
    revision = SOURCE if run is not None else attempt['source_commit']
    check('captured runtime matches correct Git identity ' + case, runtime == batch(revision, runtime))
    if run is None:
        check('red initialization has no physical result', terminal['status'] == 'FAILED' and not terminal['integration_returned'] and
              terminal['error_type'] == 'ValueError' and 'measurable whitelist' in terminal['error'] and not any(n.startswith(prefix + 'original/') for n in archive))
        continue
    check('completed physics explicitly not test acceptance', terminal['status'] == 'PHYSICAL_CALL_COMPLETED_NOT_TEST_ACCEPTANCE' and terminal['integration_returned'])
    check('dirty development HEAD is honestly recorded', run['code_identity']['git_commit'] == attempt['source_commit'] and
          run['code_identity']['implementation_has_changes'] and run['code_identity'] == terminal['executed_source'] and
          all(runtime[n] == h for n, h in run['code_identity']['files'].items()))
    check('actual saved input identity including stable same-time order', run['inputs']['boundary_events'] == sorted(inputs['boundary_events'], key=lambda row: row['time_s']) and
          run['inputs']['dispatch_program'] == inputs['dispatch_program'] and json.loads(archive[prefix + 'original/scenario.json']) == inputs['model'])
    for name, identity in run['artifacts'].items():
        check('saved result member hash ' + name, digest(archive[prefix + 'original/' + name]) == identity['sha256'])
    results[case] = dict(run=run, trace=[json.loads(line) for line in archive[prefix + 'original/private-state.jsonl'].splitlines()],
        balances=[json.loads(line) for line in archive[prefix + 'original/balances.jsonl'].splitlines()], inputs=inputs)

check('one actual completed short integration', len(results) == 1)
result = next(iter(results.values()));run=result['run'];trace=result['trace'];balances=result['balances'];inputs=result['inputs']
check('actual 1.25-second saved horizon', trace[0]['time_s'] == 0 and trace[-1]['time_s'] == run['summary']['duration_s'] == 1.25 and
      len(trace) == len(balances) + 1)
samples = {r['time_s']: r for r in trace}
first = F(1000000) * F(1, 2) / F(2000000)
delivery = first * F(1, 2) + F(1) * F(1, 2)
demand = F(1, 2) * F(1, 2) + F(1) * F(3, 4)
deficit_time = (1 - first / F(1, 2)) * F(1, 2) + F(1, 4)
check('independent requested power and delivery at t0', samples[0]['domains']['power']['actual_powers_W']['compute'] == 500000 and
      samples[0]['domains']['it_service']['demand'] == .5 and samples[0]['domains']['it_service']['delivered'] == first == F(1, 4) and first != F(1, 2))
check('actual delivery differs from service ratio', first / F(1, 2) == F(1, 2) and first != first / F(1, 2))
check('actual service samples0/.5/1', [samples[t]['domains']['it_service']['delivered'] for t in [0, .5, 1]] == [.25, 1, 0])
for key, expected in [('demand_service_unit_s', demand), ('delivered_service_unit_s', delivery), ('service_deficit_time_s', deficit_time)]:
    check('independent service integral and original balance ' + key, close(run['summary'][key], expected) and close(math.fsum(b[key] for b in balances), expected))
audit = run['policy_sensor_private_audit']
check('actual private service samples exact times and values', [(r['polled_at_s'], r['source_observed_at_s'], r['private_signal']) for r in audit if r['measurement_id'] == 'service-meter'] == [(0, 0, .25), (.5, .5, 1), (1, 1, 0)])
check('old fixed power meter continues', [r['polled_at_s'] for r in audit if r['measurement_id'] == 'rectifier-meter'] == [0, 1])
seen=[]
for row in run['policy_public_decisions']:
    frame=row['frame'];now=frame['as_of_s'];records=[r for r in frame['evidence']['records'] if r['source_id']=='service-meter-record'];seen.append(records)
    check('strict current public arrival t=' + str(now), all(r['observed_at_s'] <= r['arrived_at_s'] <= now for r in frame['evidence']['records']))
    check('no human dispatch t=' + str(now), row['choice']['chosen_candidate_id'] is None and not row['choice']['execution_permission'])
check('strict service availability decision counts', [len(rs) for rs in seen] == [0, 0, 1, 1, 2, 2, 3])
records=seen[-1]
check('received service observations and validity', [(r['observed_at_s'],r['arrived_at_s'],r['valid_until_s'],r['value']) for r in records] == [(0,.25,2,.25),(.5,.75,2.5,1),(1,1.25,3,None)])
check('received source provenance distinct', [r['provenance']['origin_id'] for r in records] == ['service-meter@0','service-meter@1/2','service-meter@1'] and
      all(r['provenance']['copied_from_record_id'] is None and r['target_id']=='critical_service' and r['unit']=='1' for r in records))
check('positive bounded reports and actual zero outside range remains missing', [(r['availability'],r['quality']['status'],r['quality']['error_bound']) for r in records] ==
      [('current','bounded',0),('current','bounded',0),('missing','unknown',None)])
check('actual private readings stay separate from public metadata', not any(any(k.startswith('private_') for k in r) for r in records))
check('original fixed power observation arrives separately', any(r['source_id']=='rectifier-meter-record' and r['observed_at_s']==0 and r['arrived_at_s']==.5 and r['quality']['status']=='bounded' for r in run['policy_public_decisions'][-1]['frame']['evidence']['records']))
check('scope no work or scientific claim', run['work_records'] == [] and run['field_calibration']=='PENDING' and run['research_gain_claim']=='NOT_ESTABLISHED' and run['research_trials']==0)
logs = pkg / 'development'
check('01 original refusal retained', b'FAILED (errors=1)' in next(logs.glob('01-*.log')).read_bytes())
check('02 old oracle failure retained despite green filename', b'FAILED (failures=1)' in next(logs.glob('02-*.log')).read_bytes())
check('03 no repeated physics', b'"new_physical_runs": 0' in next(logs.glob('03-*.log')).read_bytes())
check('04 saved wrong-profile method pass', b'Ran 1 test' in next(logs.glob('04-*.log')).read_bytes() and b'OK' in next(logs.glob('04-*.log')).read_bytes())
summary=dict(status='PASS',source=SOURCE,base=BASE,checks=len(checks),check_failures=0,findings=0,unresolved=0,
    exact_exports=len(pins['exports']),prior_contract_artifacts=len(prior),archive_members_per_package=150,
    original_call_attempts=2,known_completed_short_runs=1,known_completed_physical_duration_s=1.25,
    project_calls=0,selector_calls=0,assessment_calls=0,simulation_calls=0,test_calls=0,full_calls=0,research_trials=0,
    scope='FIRST_SERVICE_OBSERVATION_DEVELOPMENT_SLICE_ONLY_NOT_FULL27')
(ROOT/'checks.json').write_text(json.dumps(dict(summary=summary,checks=checks),indent=2)+'\n',encoding='utf-8')
print(json.dumps(summary))
