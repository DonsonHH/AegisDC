"""Independent saved ticket27 Git/JSON/byte audit. No product code is executed."""
import ast
from copy import deepcopy
from datetime import datetime
from hashlib import sha256
import json
from pathlib import Path
import subprocess

OUT=Path(__file__).resolve().parent
REPO=Path('C:/Users/Donson/.codex/worktrees/mainline27-full-loop/Renly')
ORIGINAL='36ae97cc17e4b9297017289e285d00abaee29929'
OLD_DATA='3ffa95d6e966443287f6b32f156413ce9587edae'
REPLAY='83a66f1c3abe0b2613d0700448b22f82e576f3b7'
DATA='be0612c29c41b6df67b1fddc91b96a7ec217ae94'
PREFIX='evidence/mainline/engineering/27-full-loop/'
OLD=PREFIX+'capture-20261107-02/'
NEW=PREFIX+'capture-20261107-03/'
LAUNCH_OLD=PREFIX+'capture-02-launch/'
LAUNCH_NEW=PREFIX+'capture-03-launch/'
PROTO='docs/mainline/27-loop-engineering-protocol-v3.json'
TOOL='scripts/full_loop_delivery.py'
PRIOR=('26-projection-standards-review-01','26-online-standards-review-01','27-contract-standards-review-01','27-service-standards-review-01','27-replay-standards-review-01',
    '27-frozen-standards-review-01','27-frozen-standards-review-02','27-frozen-standards-review-03','27-replay-continuation-standards-01')
checks=[]
def check(name,ok):
    checks.append(dict(name=name,passed=bool(ok)))
    if not ok:raise AssertionError(name)
def digest(raw):return sha256(raw).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=REPO)
def write(name,raw):
    p=OUT/name;p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('xb') as stream:stream.write(raw)
def jwrite(name,value):write(name,(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode())
def tree(rev,*paths):return {r.split('\t',1)[1]:r.split()[2] for r in git('ls-tree','-r',rev,'--',*paths).decode().splitlines()}
def snap():return {p.relative_to(OUT.parent).as_posix():digest(p.read_bytes()) for name in PRIOR for p in sorted((OUT.parent/name).rglob('*')) if p.is_file()}
def batch(keys):
    keys=sorted(set(keys));raw=subprocess.check_output(['git','cat-file','--batch'],cwd=REPO,input=''.join(k+'\n' for k in keys).encode());offset=0;result={};ids={}
    for key in keys:
        end=raw.index(b'\n',offset);header=raw[offset:end].split();assert len(header)==3 and header[1]==b'blob',key
        start=end+1;size=int(header[2]);result[key]=raw[start:start+size];ids[key]=header[0].decode();offset=start+size+1
    check('complete batched Git bytes '+str(len(keys)),offset==len(raw));return result,ids

before=snap();jwrite('prior-reviews-before.json',before)
check('fixed replay execution source is parent of delivery',git('rev-parse',DATA+'^').decode().strip()==REPLAY)
check('fixed retained original ancestor of replay',git('merge-base',OLD_DATA,REPLAY).decode().strip()==OLD_DATA)
check('exact original runtime unchanged at all four pins',tree(ORIGINAL,'src')==tree(OLD_DATA,'src')==tree(REPLAY,'src')==tree(DATA,'src'))
new_tree=tree(DATA);replay_tree=tree(REPLAY);old_tree=tree(OLD_DATA)
old_paths={n for n in old_tree if n.startswith((OLD,LAUNCH_OLD))};new_paths={n for n in new_tree if n.startswith((NEW,LAUNCH_NEW))}
check('V2 original 14+7 path set and delivery blobs unchanged',sum(n.startswith(OLD) for n in old_paths)==14 and sum(n.startswith(LAUNCH_OLD) for n in old_paths)==7 and {n:old_tree[n] for n in old_paths}=={n:h for n,h in new_tree.items() if n.startswith((OLD,LAUNCH_OLD))})
check('V3 one replay capture18+launch7 exact paths',sum(n.startswith(NEW) for n in new_paths)==18 and sum(n.startswith(LAUNCH_NEW) for n in new_paths)==7)
changed=set(git('diff','--name-only',REPLAY+'...'+DATA).decode().splitlines())
check('delivery adds only 25 originals and path-specific attributes',changed==new_paths|{PREFIX+'.gitattributes'} and not new_paths&set(replay_tree))
check('no second original, no replay in V2 output, no unexecuted V1 capture',not any(n.startswith((NEW+'original/',OLD+'replay/',PREFIX+'capture-20261107-01/')) for n in new_tree))
write('commits.txt',git('log','--format=%H %s',ORIGINAL+'..'+DATA));jwrite('changed-files.json',sorted(changed))
first,_=batch([DATA+':'+NEW+'receipt.json',DATA+':'+PROTO]);receipt=json.loads(first[DATA+':'+NEW+'receipt.json']);protocol=json.loads(first[DATA+':'+PROTO]);roles=receipt['pins']
check('execution and data roles67/6/15/24/21 exact',receipt['source']==REPLAY and {k:len(v) for k,v in roles.items()}==dict(runtime=67,tools=6,inputs=15,development_originals=24,retained_original=21))
check('retained receipt role exact21 prior paths',set(roles['retained_original'])==old_paths)
expected_roles=json.loads((OUT.parent/'27-replay-continuation-standards-01/source-manifest.json').read_bytes())['roles']
check('executed roles match frozen independent source pins',roles==expected_roles)
all_role_names=set().union(*(set(group) for group in roles.values()))
standards=['AGENTS.md','GLOSSARY.md','docs/MAINLINE.md','docs/agents/domain.md','docs/agents/issue-tracker.md','docs/adr/0003-complete-facility-mainline.md','.scratch/full-facility-mainline/spec.md']
critical=sorted(old_paths|new_paths|set(standards)|set(roles['tools'])|set(roles['inputs'])|{PREFIX+'.gitattributes'})
keys=[DATA+':'+n for n in set(critical)|all_role_names]+[REPLAY+':'+n for n in all_role_names]+[OLD_DATA+':'+n for n in old_paths]+[ORIGINAL+':'+n for n in roles['runtime']]+[REPLAY+':'+PREFIX+'.gitattributes']
raw,ids=batch(keys)
def blob(name):return raw[DATA+':'+name]
def read(name):return json.loads(blob(name))
def lines(name):return [json.loads(row) for row in blob(name).splitlines()]
exports={}
for name in critical:
    value=blob(name);write('export/'+name,value);exports[name]=dict(git_blob=ids[DATA+':'+name],sha256=digest(value),bytes=len(value))
    if name.endswith('.py'):ast.parse(value.decode('utf-8'),filename=name);check('pinned tool syntax '+name,True)
for role,group in roles.items():
    for name,sha in group.items():
        check('exact execution/delivery role '+role+'/'+name,digest(blob(name))==sha and blob(name)==raw[REPLAY+':'+name])
for name in old_paths:check('immutable old data delivery byte equality '+name,blob(name)==raw[OLD_DATA+':'+name])
for name in roles['runtime']:check('original/replay exact 67 runtime bytes '+name,blob(name)==raw[ORIGINAL+':'+name])
jwrite('source-manifest.json',dict(original_source=ORIGINAL,original_data=OLD_DATA,replay_source=REPLAY,data=DATA,files=exports,roles=roles,old_original_paths=sorted(old_paths),new_replay_paths=sorted(new_paths),new_project_calls=0))

old_receipt=read(OLD+'receipt.json');old_cap=read(OLD+'capture.json');new_cap=read(NEW+'capture.json')
check('original outer FAIL and source guard not overwritten',old_receipt['source']==ORIGINAL and old_receipt['status']=='FAIL' and old_receipt['error']=='Maintenance/reserve gating differs' and old_receipt['source_guard'] is True and old_receipt['validated']==0)
check('one spent10s original, one remaining10s replay total20',old_receipt['attempts']==old_receipt['completed_integrations']==receipt['attempts']==receipt['completed_integrations']==receipt['validated']==1 and old_receipt['simulated_duration_attempted_s']==receipt['simulated_duration_attempted_s']==10 and protocol['combined_physical_budget_s']==20)
check('new outer PASS no failure and source guard intact',receipt['status']=='PASS' and receipt['source_guard'] is True and not {'error','source_guard_error'}&set(receipt))
check('old 2planned/20 but stopped1; V3 1planned/10',old_cap['planned_attempts']==2 and old_cap['declared_simulated_duration_s']==20 and new_cap['planned_attempts']==1 and new_cap['declared_simulated_duration_s']==10 and new_cap['retained_original']==protocol['retained_original'])
check('old actual runtime guard exactly matches new pins',old_receipt['pins']['runtime']==receipt['pins']['runtime'])
check('no effects or field calibration claimed',old_receipt['registered_effect_trials']==receipt['registered_effect_trials']==protocol['registered_effect_trials']==0 and old_receipt['field_calibration']==receipt['field_calibration']=='PENDING')
check('old failed STARTED10/FAILED ledger exact',lines(OLD+'attempts.jsonl')==[dict(case='original',status='STARTED',source=ORIGINAL,duration_s=10),dict(case='original',status='FAILED',source=ORIGINAL,error='Maintenance/reserve gating differs')])
check('new one STARTED10/COMPLETED ledger exact',lines(NEW+'attempts.jsonl')==[dict(case='replay',status='STARTED',source=REPLAY,duration_s=10),dict(case='replay',status='COMPLETED',source=REPLAY)])
for prefix,terminal,n,paths in [(OLD,old_receipt,13,old_paths),(NEW,receipt,17,new_paths)]:
    check('outer exact durable manifest and receipt '+prefix,len(terminal['artifacts'])==n and set(terminal['artifacts'])=={p.removeprefix(prefix) for p in paths if p.startswith(prefix)}-{'receipt.json'})
    for name,sha in terminal['artifacts'].items():check('outer exact committed original SHA '+prefix+name,digest(blob(prefix+name))==sha)
new_declared=set(protocol['durable_root'])|{'replay/'+name for name in protocol['durable_case']+protocol['durable_replay_extra']}
check('new durable output exact17, no cache or arbitrary skip',set(receipt['artifacts'])==new_declared and all('__pycache__' not in n and not n.endswith(('.pyc','.pyo')) for n in old_paths|new_paths))

launches=[]
for prefix,source,outer,success in [(LAUNCH_OLD,ORIGINAL,old_cap,False),(LAUNCH_NEW,REPLAY,new_cap,True)]:
    manifest=read(prefix+'manifest.json');start=read(prefix+'attempt.json');process=read(prefix+'process.json');end=read(prefix+'terminal.json')
    check('exact six manifest roles plus launch manifest '+prefix,set(manifest)=={'attempt.json','launcher.py','process.json','stderr.txt','stdout.txt','terminal.json'})
    for name,sha in manifest.items():check('exact launch original hash '+prefix+name,digest(blob(prefix+name))==sha)
    check('actual launch source PID terminal and expected result '+prefix,start['status']=='STARTED' and start['source']==process['source']==end['source']==outer['execution_source']==source and process['pid']>0 and end['status']==('COMPLETED' if success else 'FAILED') and end['returncode']==(0 if success else 1) and end['receipt_exists'] is True)
    check('exact launch executable flags and fresh cache '+prefix,start['argv'][1:4]==['-B','-X','utf8'] and start['cache_prefix_existed_before'] is False and start['environment']['PYTHONHASHSEED']=='0' and start['environment']['PYTHONDONTWRITEBYTECODE']=='1' and outer['cache_prefix']==start['environment']['PYTHONPYCACHEPREFIX'] and outer['no_bytecode'] is True and outer['utf8_mode']==1 and outer['executable_sha256']==start['executable_sha256'])
    check('actual launch script and stream hashes '+prefix,start['launcher_sha256']==digest(blob(prefix+'launcher.py')) and end['stdout_sha256']==digest(blob(prefix+'stdout.txt')) and end['stderr_sha256']==digest(blob(prefix+'stderr.txt')))
    launches.append((start,process,end))
check('old failed stderr retained and new successful stdout bounded',b'ValueError: Maintenance/reserve gating differs' in blob(LAUNCH_OLD+'stderr.txt') and not blob(LAUNCH_OLD+'stdout.txt') and not blob(LAUNCH_NEW+'stderr.txt'))
new_stdout=json.loads(blob(LAUNCH_NEW+'stdout.txt'))
check('stdout records one new replay and no original reexecution',new_stdout['status']=='PASS' and new_stdout['source']==REPLAY and new_stdout['new_physical_runs']==new_stdout['reused_originals']==1 and new_stdout['simulated_duration_s']==10 and new_stdout['combined_physical_budget_s']==20)
check('two launch records chronological and distinct cache namespaces',datetime.fromisoformat(launches[0][0]['utc'])<datetime.fromisoformat(launches[0][2]['utc'])<datetime.fromisoformat(launches[1][0]['utc'])<datetime.fromisoformat(launches[1][2]['utc']) and old_cap['cache_prefix']!=new_cap['cache_prefix'])
attrs=blob(PREFIX+'.gitattributes').decode();prior_attrs=raw[REPLAY+':'+PREFIX+'.gitattributes'].decode();added=[r for r in attrs[len(prior_attrs):].splitlines() if r.strip() and not r.startswith('#')]
check('native new streams per-path exception only',attrs.startswith(prior_attrs) and {r.split()[0] for r in added}=={'capture-03-launch/stdout.txt','capture-03-launch/stderr.txt'} and all(' -text whitespace=blank-at-eol,blank-at-eof,space-before-tab,cr-at-eol' in r for r in added))

original_case=OLD+'original/';replay_case=NEW+'replay/';records=[];runs=[]
expected_runtime={n:sha for n,sha in roles['runtime'].items() if n.startswith('src/aegis_dc/') or n=='src/patrol_rsi/contracts.py'}
doc=read(protocol['input'])
for case,source,cap in [(original_case,ORIGINAL,old_cap),(replay_case,REPLAY,new_cap)]:
    a=read(case+'attempt.json');request=read(case+'request.json');run=read(case+'trajectory/run.json');life=lines(case+'lifecycle.jsonl');decl=read(case+'declaration.json')
    records.append(a);runs.append(run)
    check('inner actual COMPLETED original record '+case,a['status']=='COMPLETED' and a['failure'] is None and a['execution_kind']=='ENGINEERING_FIXTURE' and [r['state'] for r in life]==['STARTED','COMPLETED'] and all(r['attempt_id']==a['attempt_id'] for r in life))
    check('actual inner exact full artifact role coverage '+case,set(a['artifacts'])==set(decl['required_when_completed'])==set(decl['allowed_before_finalization']))
    for name,sha in a['artifacts'].items():check('inner case exact saved byte hash '+case+name,digest(blob(case+name))==sha)
    for name,value in [('duration_s',10),('maximum_step_s',.01)]:check('actual effective request value '+case+name,request[name]==a[name]==run['inputs'][name]==value)
    identity=a['source_identity'];code=run['code_identity']
    check('executed 36-file exact runtime mapping and revision '+case,code['files']==identity['files']==expected_runtime and len(expected_runtime)==36 and all(code[k]==identity[k] for k in ('git_commit','implementation_has_changes','source_tree_sha256')) and code['git_commit']==source and code['implementation_has_changes'] is False)
    check('same interpreter tied to actual capture '+case,identity['python']['executable_sha256']==cap['executable_sha256'] and identity['python']['version']==cap['python'])
    check('actual inputs and outputs tied exact frozen program '+case,read(case+'inputs.json')==read(case+'frozen-inputs.json')==doc['replay_inputs'] and read(case+'scenario-input.json')==read(case+'trajectory/scenario.json')==doc['model'] and run['inputs']['dispatch_program']==doc['replay_inputs']['dispatch_program'] and run['inputs']['boundary_events']==doc['replay_inputs']['exogenous_events'] and run['inputs']['work_requests']==[] and not run['inputs'].get('action_commands'))
    check('three actual physical run artifact roles '+case,set(run['artifacts'])=={'scenario.json','private-state.jsonl','balances.jsonl'})
    for name,item in run['artifacts'].items():check('exact original run artifact '+case+name,digest(blob(case+'trajectory/'+name))==item['sha256'])
    decisions=run['policy_public_decisions'];computation=run['policy_computation_audit']
    check('8 actual decisions and model counts/strict arrivals '+case,[r['frame']['as_of_s'] for r in decisions]==protocol['decisions_s'] and [r['choice']['chosen_candidate_id'] for r in decisions]==protocol['choices'] and len(computation)==8 and all(a['decision_at_s']==d['frame']['as_of_s'] and a['model_evaluations']==d['choice']['model_evaluations'] and type(a['elapsed_ns']) is int and a['elapsed_ns']>=0 for a,d in zip(computation,decisions)) and all(r['observed_at_s']<=r['arrived_at_s']<=d['frame']['as_of_s'] for d in decisions for r in d['frame']['evidence']['records']+d['history']['work_feedback']))
    check('8.5 verified closure and other declared statuses retained '+case,[d['choice']['question_lifecycle']['questions'][0]['status'] for d in decisions]==protocol['closure_states'] and len(decisions[-1]['choice']['question_lifecycle']['questions'][0]['supporting_record_ids'])==4)
    check('no registered effects or model training '+case,run['research_trials']==run['model_calls']==run['training_calls']==0 and run['field_calibration']=='PENDING')
o,r=records
check('distinct attempts and exact replay provenance root',o['replay_of'] is None and o['attempt_id']!=r['attempt_id'] and r['replay_of']==dict(attempt_id=o['attempt_id'],attempt_sha256=digest(blob(original_case+'attempt.json')),mode='EXACT_REEXECUTION') and r['replay_revision_relationship']=='DIFFERENT_COMMIT_SAME_RUNTIME_BYTES')
check('actual interpreter identity identical and exact same runtime replay rule',o['source_identity']['python']==r['source_identity']['python'] and r['replay_source_rule']=='EXACT_RUNTIME_BYTES_AND_INTERPRETER')
for name in ('attempt.json','declaration.json','lifecycle.jsonl'):
    check('copied origin bytes and exact Git blob '+name,blob(original_case+name)==blob(replay_case+'origin/'+name) and ids[DATA+':'+original_case+name]==ids[DATA+':'+replay_case+'origin/'+name])
for name in ('scenario.json','private-state.jsonl','balances.jsonl'):
    check('actual physical original/replay same exact bytes and Git blob '+name,blob(original_case+'trajectory/'+name)==blob(replay_case+'trajectory/'+name) and ids[DATA+':'+original_case+'trajectory/'+name]==ids[DATA+':'+replay_case+'trajectory/'+name])
trace=lines(original_case+'trajectory/private-state.jsonl');balances=lines(original_case+'trajectory/balances.jsonl')
check('same actual 1016 points and 1015 balance rows',len(trace)==len(balances)+1==1016 and trace[0]['time_s']==0 and trace[-1]['time_s']==10)
compared=deepcopy(runs);elapsed=[]
for run,revision in zip(compared,(ORIGINAL,REPLAY)):
    check('exact metadata Git label verified before exception '+revision,run['code_identity'].pop('git_commit')==revision)
    elapsed.append([row.pop('elapsed_ns') for row in run['policy_computation_audit']])
check('strict canonical full JSON equality, only two narrow exceptions',json.dumps(compared[0],sort_keys=True,allow_nan=False)==json.dumps(compared[1],sort_keys=True,allow_nan=False) and elapsed[0]!=elapsed[1] and list(map(len,elapsed))==[8,8])
saved=read(NEW+'checks.json')
check('retained original and replay saved check summaries identical',set(saved)=={'original','replay','replay_comparison'} and saved['original']==saved['replay'] and saved['original']['status']=='PASS' and saved['original']['actual']==runs[0]['summary'] and saved['original']['trace_points']==1016)
check('saved comparison declarations exact explicitly narrow',saved['replay_comparison']==dict(status='PASS',wall_clock_exception='policy_computation_audit[*].elapsed_ns',metadata_exception='code_identity.git_commit only; both Git revisions and identical runtime/interpreter verified',scenario_trace_balances_byte_equal=True,original_and_replay_distinct=True))
check('earlier 27 and26 reviews byte preserved',snap()==before);jwrite('prior-reviews-after.json',before)
dc=subprocess.run(['git','diff','--check',REPLAY+'...'+DATA],cwd=REPO,capture_output=True)
check('full fixed delivery diff check pass without skip',dc.returncode==0 and not dc.stdout and not dc.stderr)
jwrite('checks.json',checks)
report='''Standards：be0612c保存复核 PASS。\n\n硬规则：V2原14件与启动7件原样，内层完成10秒、外层FAIL；V3新18件与启动7件，只重放一次10秒。两次模拟共20秒。67运行源、36实际源码与解释器相同；原请求、终态、三来源快照和Git字节绑定。\n\n完整运行仅排除分别核实的Git标签与elapsed_ns，其他JSON严格相同；场景、1016轨迹点及1015平衡原字节一致。实际关闭和服务账保持。启发性异味无。0项目或验证器调用；仅为保存证据结论，不替代根验收。\n'''
assert len(report)<=400;write('report.md',report.encode('utf-8'))
review=dict(schema='aegisdc-independent-standards-review-v1',axis='Standards',status='PASS',scope='Independent saved ticket27 original/replay byte verification of be0612 only; no saved verifier invocation',
    original_source=ORIGINAL,original_data=OLD_DATA,replay_source=REPLAY,data=DATA,checks=len(checks),exports=len(exports),prior_review_files_preserved=len(before),
    role_counts={k:len(v) for k,v in roles.items()},retained_original_artifacts=14,retained_launch_files=7,replay_artifacts=18,replay_launch_files=7,
    original_outer_status='FAIL',original_inner_status='COMPLETED',new_outer_status='PASS',new_inner_status='COMPLETED',physical_runs=2,total_simulated_duration_s=20,online_decisions=16,
    actual_runtime_files=36,trace_points=1016,balance_rows=1015,exact_origin_snapshots=3,comparison_exceptions=['code_identity.git_commit individually checked','policy_computation_audit[*].elapsed_ns'],
    hard_findings=[],heuristic_findings=[],unresolved=[],new_project_calls=0,tests_run=0,selectors_run=0,simulation_calls=0,fresh_project_verifier_runs=0,ticket_acceptance=False)
jwrite('review.json',review)
members={p.relative_to(OUT).as_posix():dict(sha256=digest(p.read_bytes()),bytes=p.stat().st_size) for p in sorted(OUT.rglob('*')) if p.is_file()}
jwrite('delivery-manifest.json',dict(schema='aegisdc-static-review-delivery-manifest-v1',data=DATA,artifacts=members,terminal_receipt='delivery-manifest.json',new_project_calls=0))
for name,row in members.items():assert digest((OUT/name).read_bytes())==row['sha256'] and (OUT/name).stat().st_size==row['bytes']
print(json.dumps(dict(status='PASS',checks=len(checks),exports=len(exports),prior=len(before),manifest_members=len(members),
    report_sha256=digest((OUT/'report.md').read_bytes()),review_sha256=digest((OUT/'review.json').read_bytes()),manifest_sha256=digest((OUT/'delivery-manifest.json').read_bytes()),new_project_calls=0)))
