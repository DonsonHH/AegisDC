"""Retain the reviewer-only parser error and correct one missing parenthesis."""
from hashlib import sha256
import json
from pathlib import Path
OUT=Path(__file__).resolve().parent
source=OUT/'audit_continuation.py';raw=source.read_bytes();lines=raw.decode('utf-8').splitlines(keepends=True)
positions=[i for i,line in enumerate(lines) if "check('native launcher CRLF recognized only per exact paths'" in line]
assert len(positions)==1
index=positions[0]
with (OUT/'reviewer-parser-failure-01.json').open('x',encoding='utf-8') as stream:json.dump(dict(classification='STATIC_REVIEW_SCRIPT_SYNTAX_NOT_APPLICATION_FAILURE',script=source.name,sha256=sha256(raw).hexdigest(),line=index+1,error="SyntaxError: '(' was never closed",new_project_calls=0),stream,indent=2)
lines[index]=lines[index].rstrip('\r\n')+')\n'
with (OUT/'audit_continuation_fix01.py').open('x',encoding='utf-8',newline='\n') as stream:stream.write(''.join(lines))
