"""Fixed ticket27 continuation review; read Git and original bytes only."""
import ast
from fractions import Fraction as F
from hashlib import sha256
import json
import math
from pathlib import Path
import subprocess
import sys

OUT=Path(__file__).resolve().parent
REPO=Path('C:/Users/Donson/.codex/worktrees/mainline27-full-loop/Renly')
BASE='36ae97cc17e4b9297017289e285d00abaee29929'
DATA='3ffa95d6e966443287f6b32f156413ce9587edae'
SOURCE='83a66f1c3abe0b2613d0700448b22f82e576f3b7'
PREFIX='evidence/mainline/engineering/27-full-loop/'
CAP=PREFIX+'capture-20261107-02/'
LAUNCH=PREFIX+'capture-02-launch/'
PROTO='docs/mainline/27-loop-engineering-protocol-v3.json'
PREVIOUS='docs/mainline/27-loop-engineering-protocol-v2.json'
TOOL='scripts/full_loop_delivery.py'
HELPER='scripts/inspection_delivery.py'
CHECKLIST=('26-projection-standards-review-01','26-online-standards-review-01','27-contract-standards-review-01',
    '27-service-standards-review-01','27-replay-standards-review-01','27-frozen-standards-review-01','27-frozen-standards-review-02','27-frozen-standards-review-03')
checks=[]
def check(name,ok):
    checks.append(dict(name=name,passed=bool(ok)))
    if not ok:raise AssertionError(name)
def digest(raw):return sha256(raw).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=REPO)
def write(name,raw):
    p=OUT/name;p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('xb') as stream:stream.write(raw)
def jwrite(name,v):write(name,(json.dumps(v,ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode())
def tree(rev,*paths):return {r.split('\t',1)[1]:r.split()[2] for r in git('ls-tree','-r',rev,'--',*paths).decode().splitlines()}
def snapshot():return {p.relative_to(OUT.parent).as_posix():digest(p.read_bytes()) for name in CHECKLIST for p in sorted((OUT.parent/name).rglob('*')) if p.is_file()}
def batch(keys):
    keys=sorted(set(keys));raw=subprocess.check_output(['git','cat-file','--batch'],cwd=REPO,input=''.join(k+'\n' for k in keys).encode())
    result={};ids={};offset=0
    for key in keys:
        end=raw.index(b'\n',offset);header=raw[offset:end].split();assert len(header)==3 and header[1]==b'blob',key
        start=end+1;size=int(header[2]);result[key]=raw[start:start+size];ids[key]=header[0].decode();offset=start+size+1
    check('exact Git batch end '+str(len(keys)),offset==len(raw));return result,ids
def functions(text):return {n.name:n for n in ast.parse(text).body if isinstance(n,ast.FunctionDef)}
def coincides(a,b):return math.isfinite(a) and math.isfinite(b) and abs(a-b)<=8*max(math.ulp(a),math.ulp(b))

before=snapshot();jwrite('prior-reviews-before.json',before)
check('fixed execution before retained data before continuation',git('merge-base',BASE,DATA).decode().strip()==BASE and git('merge-base',DATA,SOURCE).decode().strip()==DATA)
check('exact retained data commit parent',git('rev-parse',DATA+'^').decode().strip()==BASE)
write('candidate.diff',git('diff','--binary',BASE+'...'+SOURCE));write('commits.txt',git('log','--format=%H %s',BASE+'..'+SOURCE))
fixed=tree(SOURCE);base=tree(BASE);data_tree=tree(DATA)
retained={n:h for n,h in data_tree.items() if n.startswith((CAP,LAUNCH))};data_names={n for n in retained if n.startswith(CAP)};launch_names=set(retained)-data_names
check('14 capture plus 7 launch fixed Git blobs',len(data_names)==14 and len(launch_names)==7 and retained=={n:h for n,h in fixed.items() if n.startswith((CAP,LAUNCH))})
check('no old replay or checks.json produced in failed capture',not any(n.startswith(CAP+'replay/') for n in retained) and CAP+'checks.json' not in retained)
check('all runtime source same tree before and after',tree(BASE,'src')==tree(DATA,'src')==tree(SOURCE,'src'))
check('only explicit V3 correction after retained data',set(git('diff','--name-only',DATA+'...'+SOURCE).decode().splitlines())=={PROTO,'docs/mainline/27-reserve-oracle-correction.md',TOOL})
check('old development originals tree unchanged',{n:h for n,h in base.items() if n.startswith(PREFIX+'development')}=={n:h for n,h in fixed.items() if n.startswith(PREFIX+'development')})
check('no separate coding/contributing standard',not any(Path(n).name.upper() in {'CODING_STANDARDS.MD','CONTRIBUTING.MD'} for n in fixed))
raw0,_=batch([SOURCE+':'+PROTO,SOURCE+':'+PREVIOUS]);protocol=json.loads(raw0[SOURCE+':'+PROTO]);previous=json.loads(raw0[SOURCE+':'+PREVIOUS]);input_name=protocol['input']
raw1,_=batch([SOURCE+':'+input_name]);doc=json.loads(raw1[SOURCE+':'+input_name])
roles=dict(runtime=sorted(n for n in fixed if n.startswith('src/') and n.endswith('.py')),tools=protocol['tools'],
    inputs=sorted(set([PROTO,input_name,protocol['independent_literals'],*protocol['contracts'],*protocol['retained_protocol_inputs'],*doc['source_inputs'],doc['model']['runtime']['property_table']])),
    development_originals=sorted(n for n in fixed if n.startswith(PREFIX+'development') and '__pycache__' not in n and not n.endswith(('.pyc','.pyo'))),retained_original=sorted(retained))
standards=['AGENTS.md','GLOSSARY.md','docs/MAINLINE.md','docs/agents/domain.md','docs/agents/issue-tracker.md','docs/adr/0003-complete-facility-mainline.md','.scratch/full-facility-mainline/spec.md']
for n in standards:check('unchanged standard '+n,base[n]==fixed[n])
related=['src/aegis_dc/'+n+'.py' for n in ('power','plant','replay','time_coordinates','verified_closure')]
names=sorted(set(standards+related+roles['inputs']+roles['tools']+[PREFIX+'.gitattributes',PREFIX+'development-service-20261107-02/receipt.json']+list(retained)))
keys=[SOURCE+':'+n for n in set(names).union(*(set(v) for v in roles.values()))]+[DATA+':'+n for n in retained]+[BASE+':'+n for n in roles['runtime']]+[BASE+':'+TOOL,BASE+':'+PREFIX+'.gitattributes']
raw,ids=batch(keys)
def src(name):return raw[SOURCE+':'+name]
def text(name):return src(name).decode('utf-8')
def read(name):return json.loads(src(name))
def rows(name):return [json.loads(line) for line in src(name).splitlines()]
exports={}
for name in names:
    b=src(name);write('export/'+name,b);exports[name]=dict(git_blob=ids[SOURCE+':'+name],sha256=digest(b),bytes=len(b))
    if name.endswith('.py'):ast.parse(b.decode('utf-8'),filename=name);check('AST parse '+name,True)
for name in (TOOL,PREFIX+'.gitattributes'):write('base-export/'+name,raw[BASE+':'+name])
role_sha={k:{n:digest(src(n)) for n in names} for k,names in roles.items()}
for n in retained:check('retained original committed bytes unchanged '+n,src(n)==raw[DATA+':'+n] and ids[SOURCE+':'+n]==ids[DATA+':'+n])
for n in roles['runtime']:check('original/replay runtime byte identity '+n,src(n)==raw[BASE+':'+n])
jwrite('source-manifest.json',dict(base=BASE,retained_delivery=DATA,source=SOURCE,files=exports,roles=role_sha,retained_git_blobs=retained,new_project_calls=0))
check('all67 source runtime bytes pinned',len(roles['runtime'])==67)
for name,sha in doc['source_inputs'].items():check('input template exact committed hash '+name,role_sha['inputs'][name]==sha)
check('retained service helper pin unchanged',role_sha['tools']['scripts/full_loop_development.py']==read(PREFIX+'development-service-20261107-02/receipt.json')['tool_sha256'])
check('V3 retained source and delivery identities exact',protocol['retained_original']==dict(folder=CAP.rstrip('/'),launch_folder=LAUNCH.rstrip('/'),execution_source=BASE,delivery=DATA))
check('unique unstarted new output',protocol['output']==PREFIX+'capture-20261107-03' and not any(n.startswith(protocol['output']+'/') for n in fixed))
check('one10second replay, total budget20',protocol['cases']==['replay'] and protocol['attempt_budget']==1 and protocol['duration_s_per_case']==protocol['simulated_duration_budget_s']==doc['duration_s']==10 and protocol['combined_physical_budget_s']==20 and protocol['maximum_step_s']==doc['maximum_step_s']==.01)
same_fields=('input','independent_literals','tools','duration_s_per_case','maximum_step_s','decisions_s','choices','closure_states','absolute_tolerance','energy_tolerance_J','mass_tolerance_kg','durable_root','durable_case','durable_replay_extra','terminal','field_calibration','registered_effect_trials')
check('old physical input, scheduled decisions, closure and tolerances same',all(protocol[n]==previous[n] for n in same_fields) and fixed[input_name]==base[input_name] and protocol['scheduled_online_decisions_per_case']==previous['scheduled_online_decisions_per_case']==8)
check('new durable17outputs plus separate receipt',len(set(protocol['durable_root'])|{'replay/'+n for n in protocol['durable_case']+protocol['durable_replay_extra']})==17 and protocol['terminal']=='receipt.json')
check('same frozen V2 protocol also retained and pinned',PREVIOUS in protocol['retained_protocol_inputs'] and fixed[PREVIOUS]==base[PREVIOUS])
check('unchanged classifications no effects or calibration',protocol['registered_effect_trials']==0 and protocol['field_calibration']=='PENDING' and 'NOT_EFFECT_COMPARISON' in protocol['classification'])

receipt=read(CAP+'receipt.json');outer_capture=read(CAP+'capture.json');ledger=rows(CAP+'attempts.jsonl')
check('outer original FAIL not relabelled',receipt['source']==BASE and receipt['status']=='FAIL' and receipt['error']=='Maintenance/reserve gating differs' and receipt['source_guard'] is True and receipt['attempts']==receipt['completed_integrations']==1 and receipt['validated']==0 and receipt['simulated_duration_attempted_s']==10)
check('original attempted budget originally 2/20 and one executed',outer_capture['execution_source']==BASE and outer_capture['planned_attempts']==2 and outer_capture['declared_simulated_duration_s']==20)
check('outer STARTED original10 and FAILED only',ledger==[dict(case='original',status='STARTED',source=BASE,duration_s=10),dict(case='original',status='FAILED',source=BASE,error='Maintenance/reserve gating differs')])
check('retained receipt exact13 artifacts plus itself',set(receipt['artifacts'])=={n.removeprefix(CAP) for n in data_names}-{ 'receipt.json' })
for name,sha in receipt['artifacts'].items():check('outer retained artifact hash '+name,digest(src(CAP+name))==sha)
check('old outer source guard exact67 pinned runtime',receipt['pins']['runtime']==role_sha['runtime'])
for name,sha in read(LAUNCH+'manifest.json').items():check('exact original launch file hash '+name,digest(src(LAUNCH+name))==sha)
launch=read(LAUNCH+'attempt.json');term=read(LAUNCH+'terminal.json');process=read(LAUNCH+'process.json')
check('original external launch failure status and source exact',launch['status']=='STARTED' and launch['source']==process['source']==term['source']==BASE and process['pid']>0 and term['status']=='FAILED' and term['returncode']==1 and term['receipt_exists'] is True)
check('native stderr and stdout retained original',term['stderr_sha256']==digest(src(LAUNCH+'stderr.txt')) and term['stdout_sha256']==digest(src(LAUNCH+'stdout.txt')) and not src(LAUNCH+'stdout.txt') and b'ValueError: Maintenance/reserve gating differs' in src(LAUNCH+'stderr.txt'))
check('original interpreter flags and isolated cache launch fixed',launch['argv'][1:4]==['-B','-X','utf8'] and launch['environment']['PYTHONHASHSEED']=='0' and launch['environment']['PYTHONDONTWRITEBYTECODE']=='1' and launch['cache_prefix_existed_before'] is False and outer_capture['cache_prefix']==launch['environment']['PYTHONPYCACHEPREFIX'])
attrs=text(PREFIX+'.gitattributes');old_attrs=raw[BASE+':'+PREFIX+'.gitattributes'].decode()
check('native launcher CRLF recognized only per exact paths',attrs.startswith(old_attrs) and {r.split()[0] for r in attrs[len(old_attrs):].splitlines() if r.strip() and not r.startswith('#')}=={'capture-02-launch/stderr.txt','capture-02-launch/stdout.txt'} and all('cr-at-eol' in r and '-text' in r for r in attrs[len(old_attrs):].splitlines() if r.strip() and not r.startswith('#'))

orig=CAP+'original/';attempt=read(orig+'attempt.json');request=read(orig+'request.json');run=read(orig+'trajectory/run.json');life=rows(orig+'lifecycle.jsonl')
check('inner original completion independent from outer failure',attempt['status']=='COMPLETED' and attempt['failure'] is None and attempt['replay_of'] is None and [r['state'] for r in life]==['STARTED','COMPLETED'] and all(r['attempt_id']==attempt['attempt_id'] for r in life))
for name,sha in attempt['artifacts'].items():check('original case immutable artifact '+name,digest(src(orig+name))==sha)
check('actual original case11 exact role files',set(attempt['artifacts'])==set(read(orig+'declaration.json')['required_when_completed'])==set(protocol['durable_case'])-{'attempt.json'})
for name,value in [('duration_s',10),('maximum_step_s',.01)]:check('request/attempt/run exact bound '+name,request[name]==attempt[name]==run['inputs'][name]==value)
code=run['code_identity'];identity=attempt['source_identity'];rt={n:sha for n,sha in role_sha['runtime'].items() if n.startswith('src/aegis_dc/') or n=='src/patrol_rsi/contracts.py'}
check('original actual source clear same36 runtime identity',code['git_commit']==identity['git_commit']==BASE and code['implementation_has_changes'] is identity['implementation_has_changes'] is False and code['files']==identity['files']==rt and len(rt)==36 and code['source_tree_sha256']==identity['source_tree_sha256'])
check('old launch/attempt exact interpreter binary and version',launch['executable_sha256']==outer_capture['executable_sha256']==identity['python']['executable_sha256']==digest(Path(sys.executable).read_bytes()) and identity['python']['version']==outer_capture['python']==sys.version)
check('old actual original input frozen exact V2',read(orig+'frozen-inputs.json')==read(orig+'inputs.json')==doc['replay_inputs'] and read(orig+'scenario-input.json')==read(orig+'trajectory/scenario.json')==doc['model'] and run['inputs']['dispatch_program']==doc['replay_inputs']['dispatch_program'] and run['inputs']['boundary_events']==doc['replay_inputs']['exogenous_events'])
for name,item in run['artifacts'].items():check('original actual trajectory artifact '+name,digest(src(orig+'trajectory/'+name))==item['sha256'])
trace=rows(orig+'trajectory/private-state.jsonl');balances=rows(orig+'trajectory/balances.jsonl')
check('actual 10s original complete contiguous time axis',len(trace)==len(balances)+1==1016 and trace[0]['time_s']==0 and trace[-1]['time_s']==10 and all(r['start_s']==a['time_s']<r['end_s']==b['time_s'] and r['end_s']-r['start_s']<=.01+1e-9 for a,r,b in zip(trace,balances,trace[1:])))
applied={}
events=[row for row in run['events'] if row['kind']=='exogenous_boundary_input']
check('actual five exogenous events exactly recorded',len(events)==5)
for wanted in doc['replay_inputs']['exogenous_events']:
    match=[row for row in events if all(row[k]==v for k,v in wanted.items())]
    check('actual applied epoch within declared 8ULP '+wanted['parameter_id']+'/'+str(wanted['time_s']),len(match)==1 and coincides(match[0]['applied_at_s'],wanted['time_s']))
    applied[wanted['parameter_id'],wanted['time_s']]=match[0]['applied_at_s']
at={row['time_s']:row['domains'] for row in trace};outage=applied['grid_capacity',2];mains=applied['grid_capacity',3.4];load=applied['service_demand',.5]
recovery=[t for t,d in at.items() if coincides(t,4) and d['control_monitoring']['local_measurement']['sampled_at_s']==t]
check('actual sampled restoration at4 after mains',len(recovery)==1 and mains<recovery[0] and at[recovery[0]]['control_monitoring']['compute_permitted'] and not at[mains]['control_monitoring']['compute_permitted'])
check('actual piecewise service exact independent witness',all(d['it_service']['demand']==(.5 if t<load else 1) and d['it_service']['delivered']==(0 if outage<=t<recovery[0] else (.5 if t<load else 1)) for t,d in at.items()))
power=text('src/aegis_dc/power.py')
check('UPS protected rate isolated before internal battery control add',power.index("result['ups_protected_output_W'] = result['ups_output_W']")<power.index("result['ups_output_W'] += control_battery"))
control=next(p['value'] for p in doc['model']['parameters'] if p['id']=='ups_internal_control_power')
check('declared exact UPS internal 100W independent model input',control==100 and F(100)*(F(17,5)-2)==140)
for label,fn in [('maintenance and separate 0W protected/0W diesel',lambda d:d['backup']['reserve_states']['ups']['mode']=='maintenance' and d['power']['ups_protected_output_W']==d['power']['generator_output_W']==0),
                 ('actual internal battery100W and 0W local PLC',lambda d:d['power']['ups_output_W']==d['power']['ups_control_power_W']==d['power']['ups_control_from_battery_W']==100 and d['power']['actual_powers_W']['local_controller']==0)]:
    check(label,all(fn(d) for t,d in at.items() if outage<=t<mains) and fn(at[outage]))
summary=run['summary'];tol=protocol['absolute_tolerance']
for metric,value in [('ups_output_energy_J',140),('demand_service_unit_s',9.75),('delivered_service_unit_s',7.75),('service_deficit_time_s',2)]:
    check('original saved actual independent metric '+metric,math.isclose(summary[metric],value,rel_tol=0,abs_tol=tol) and math.isclose(math.fsum(r[metric] for r in balances),value,rel_tol=0,abs_tol=tol))
check('original conservation exact unchanged thresholds',abs(summary['whole_run_energy_residual_J'])<protocol['energy_tolerance_J'] and summary['max_mass_residual_kg']<=protocol['mass_tolerance_kg'])
decisions=run['policy_public_decisions'];closures=[r['choice']['question_lifecycle']['questions'][0] for r in decisions]
check('original 8 exact decision times choices and closure chronology',[r['frame']['as_of_s'] for r in decisions]==protocol['decisions_s'] and [r['choice']['chosen_candidate_id'] for r in decisions]==protocol['choices'] and [r['status'] for r in closures]==protocol['closure_states'])
check('original actual arrival gates strict all frames',all(r['observed_at_s']<=r['arrived_at_s']<=d['frame']['as_of_s'] for d in decisions for r in d['frame']['evidence']['records']+d['history']['work_feedback']))
check('original actual work and named effect chronology',[(r['issued_at_s'],r['work_started_at_s'],r['completed_at_s']) for r in run['work_records']]==[(3,3.25,4.25),(4.75,5,6)] and [(r['parameter_id'],r['applied_at_s'],r['old_value'],r['new_value']) for r in run['intervention_private_audit']['events']]==[('filter_resistance_multiplier',6,4,1)] and not run['intervention_public_feedback'][0]['risk_closed'])
support=set();by_role={r['role']:r for r in closures[-1]['checks']}
for role,source,value in [('condition','intake-flow-record',99.8),('service','joint-service-record',1)]:
    public=[r for r in decisions[-1]['frame']['evidence']['records'] if r['source_id']==source];ids0={r['id'] for r in public};support.update(ids0)
    check('two actual current distinct sampled closure records '+role,[(r['observed_at_s'],r['arrived_at_s']) for r in public]==[(7,7.5),(8,8.5)] and len({r['provenance']['origin_id'] for r in public})==2 and all(r['availability']=='current' and r['quality']['status']=='bounded' and math.isclose(r['value'],value,rel_tol=0,abs_tol=tol) for r in public))
    check('saved closure role actually uses the same sampled IDs '+role,by_role[role]['passed'] is True and by_role[role]['genuine_sample_count']==2 and by_role[role]['span_s']==1 and set(by_role[role]['supporting_record_ids'])==ids0)
check('actual four record closure only8.5',len(support)==4 and set(closures[-1]['supporting_record_ids'])==support and closures[-1]['risk_closed'] and not any(q['risk_closed'] for q in closures[:-1]))

tool=text(TOOL);fs=functions(tool);helper=functions(text(HELPER));cap=ast.get_source_segment(tool,fs['capture']);verify=ast.get_source_segment(tool,fs['verify']);compare=ast.get_source_segment(tool,fs['compare']);retained_check=ast.get_source_segment(tool,fs['retained_check'])
check('only one new replay application call, no original call',cap.count('result = replay_attempt(')==1 and 'run_recorded' not in cap and "protocol['cases'] == ['replay']" in cap)
check('old actual readback verified before new output and first application import',cap.index('retained_check(protocol, doc, identity)')<cap.index('folder.mkdir(exist_ok=False)')<cap.index('from aegis_dc.replay import replay_attempt'))
check('original failure receipt not rewritten',"receipt['status'] == 'FAIL'" in retained_check and "not (folder / 'replay').exists()" in retained_check and 'write(' not in retained_check)
check('synced one STARTED before replay and failure stops',cap.index("status='STARTED'")<cap.index('result = replay_attempt(') and 'os.fsync(stream.fileno())' in tool and "status='FAILED'" in cap and 'raise' in cap)
check('original and new post-call exact source guard retained',"receipt['source_guard'] = unchanged(source, identity)" in cap and 'except (OSError, subprocess.SubprocessError)' in cap and "write(folder / protocol['terminal'], receipt)" in cap)
check('each original and replay Git label bound then only pop two fields',compare.count('.pop(')==2 and "require(run['code_identity'].pop('git_commit') == expected_source" in compare and "row.pop('elapsed_ns')" in compare)
check('complete run deterministic JSON and three exact physical byte files',"json.dumps(original, sort_keys=True, allow_nan=False) == json.dumps(replay, sort_keys=True, allow_nan=False)" in compare and all(n in compare for n in ('scenario.json','private-state.jsonl','balances.jsonl')))
check('strict distinct original/replay source interpreter and origin snapshots',all(n in compare for n in ('DIFFERENT_COMMIT_SAME_RUNTIME_BYTES',"a['source_identity']['python'] == b['source_identity']['python']",'EXACT_REEXECUTION','attempt.json','declaration.json','lifecycle.jsonl')))
replay=text('src/aegis_dc/replay.py')
check('replay runtime/actual interpreter gate allows metadata-only source commit',"for field in ('schema', 'files', 'source_tree_sha256', 'python')" in replay and 'DIFFERENT_COMMIT_SAME_RUNTIME_BYTES' in replay and "required_source=prior['record']['source_identity']" in replay)
check('fresh all retained source and exact artifact Git blobs bound',"result['retained_original'] == hashes(source, original_paths)" in tool and "result['runtime'] == hashes(retained['execution_source'], result['runtime'])" in tool and "receipt['pins'] == pins(protocol, source)" in verify and 'names == hashes(delivery, names)' in verify)
check('fresh V3 only one new10s and combined20 classification',"receipt['simulated_duration_attempted_s'] == 10" in verify and 'retained_original_runs=1, replay_runs=1' in verify and 'combined_simulated_duration_s=20' in verify)
all_functions={**helper,**fs};pending=['verify'];seen=set()
while pending:
    name=pending.pop()
    if name in seen:continue
    seen.add(name);node=all_functions[name]
    check('reachable saved-only no application import '+name,not any((getattr(n,'module','') or '').startswith(('aegis_dc','patrol_rsi')) for n in ast.walk(node) if isinstance(n,(ast.Import,ast.ImportFrom))))
    for n in ast.walk(node):
        if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id in all_functions and n.func.id not in seen:pending.append(n.func.id)
check('saved verify never reaches capture or application snapshots',not {'capture','snapshots'}&seen)
check('previous source guard and findings histories unchanged',snapshot()==before);jwrite('prior-reviews-after.json',before)
diffcheck=subprocess.run(['git','diff','--check',BASE+'...'+SOURCE],cwd=REPO,capture_output=True)
check('full original-to-V3 diff check no skip',diffcheck.returncode==0 and not diffcheck.stdout and not diffcheck.stderr)
jwrite('checks.json',checks)
jwrite('retained-original.json',dict(outer='FAIL',inner='COMPLETED',outer_error=receipt['error'],already_spent_duration_s=10,unrun_replays=1,
    source=BASE,data=DATA,files=14,launch_files=7,actual_trace_points=len(trace),intervals=len(balances),actual_runtime_files=36,old_outer_runtime_files=67,
    old_ups_protected_output_W=0,old_ups_internal_control_W=100,actual_ups_output_energy_J=summary['ups_output_energy_J'],
    actual_service={n:summary[n] for n in ('demand_service_unit_s','delivered_service_unit_s','service_deficit_time_s')},
    actual_restoration_sample_s=recovery[0],closure_support=sorted(support),actual_closure_s=8.5,new_project_calls=0))
report='''Standards：83a66f1c续接静态 PASS。\n\n硬规则：3ffa原14件与启动7件字节不变；外层FAIL、内层完成10秒、无重放，均原样。67运行源一致，实跑36文件与解释器已核。UPS维护切断受保护输出，内部100W独立计约140J；原服务39/4、31/4、缺额2及8.5核验关闭可回读。\n\n仅允许新目录一次10秒重放，先读旧件、同步STARTED、失败即停。只排除已分别核验的Git提交字段和elapsed_ns；完整运行JSON其余及三轨迹文件严格比较。旧原件/失败不改。启发性异味无。0项目调用；重放和根验收须看另存实际终态。\n'''
assert len(report)<=400;write('report.md',report.encode('utf-8'))
review=dict(schema='aegisdc-independent-standards-review-v1',axis='Standards',status='PASS',base=BASE,source=SOURCE,retained_data=DATA,
    scope='V3 pre-replay static and independent saved original bytes only; no review rerun',checks=len(checks),exports=len(exports),prior_review_files_preserved=len(before),
    role_counts={k:len(v) for k,v in roles.items()},retained_data_files=14,retained_launch_files=7,old_outer_status='FAIL',old_inner_status='COMPLETED',
    old_spent_duration_s=10,remaining_replay_calls=1,remaining_replay_duration_s=10,combined_physical_budget_s=20,
    comparison_exceptions=['policy_computation_audit[*].elapsed_ns','code_identity.git_commit individually bound to exact executed revisions'],
    hard_findings=[],heuristic_findings=[],unresolved=[],new_project_calls=0,tests_run=0,selectors_run=0,simulation_calls=0,formal_replay_executed_by_reviewer=False,ticket_acceptance=False)
jwrite('review.json',review)
members={p.relative_to(OUT).as_posix():dict(sha256=digest(p.read_bytes()),bytes=p.stat().st_size) for p in sorted(OUT.rglob('*')) if p.is_file()}
jwrite('delivery-manifest.json',dict(schema='aegisdc-static-review-delivery-manifest-v1',source=SOURCE,retained_data=DATA,artifacts=members,terminal_receipt='delivery-manifest.json',new_project_calls=0))
for name,row in members.items():assert digest((OUT/name).read_bytes())==row['sha256'] and (OUT/name).stat().st_size==row['bytes']
print(json.dumps(dict(status='PASS',checks=len(checks),exports=len(exports),prior=len(before),manifest_members=len(members),role_counts=review['role_counts'],
    report_sha256=digest((OUT/'report.md').read_bytes()),review_sha256=digest((OUT/'review.json').read_bytes()),manifest_sha256=digest((OUT/'delivery-manifest.json').read_bytes()),new_project_calls=0)))
