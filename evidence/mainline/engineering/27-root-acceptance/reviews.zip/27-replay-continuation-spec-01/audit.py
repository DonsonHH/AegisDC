"""Read the retained ticket 27 original and independently check the V3 tool delta."""
import ast
from copy import deepcopy
from fractions import Fraction as F
from hashlib import sha256
import json
import math
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parent
REPO = Path(r'C:\Users\Donson\.codex\worktrees\mainline27-full-loop\Renly')
SRC = '83a66f1c3abe0b2613d0700448b22f82e576f3b7'
DATA = '3ffa95d6e966443287f6b32f156413ce9587edae'
EXEC = '36ae97cc17e4b9297017289e285d00abaee29929'
checks = []


def check(name, okay, detail=None):
    checks.append(dict(name=name, passed=bool(okay), detail=detail))
    assert okay, name


def read(path):
    return json.loads(path.read_bytes())


def sha(raw):
    return sha256(raw).hexdigest()


def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO)


def canonical(value):
    return json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False).encode()


def batch(rev,names):
    names=sorted(names);offset=0;observed={}
    raw=subprocess.check_output(['git','cat-file','--batch'],cwd=REPO,input=''.join(rev+':'+n+'\n' for n in names).encode())
    for n in names:
        end=raw.index(b'\n',offset);fields=raw[offset:end].split()
        check('exact Git role present '+rev[:8]+':'+n,len(fields)==3 and fields[1]==b'blob')
        start=end+1;offset=start+int(fields[2])+1;observed[n]=sha(raw[start:offset-1])
    check('exact Git batch framing '+rev[:8],offset==len(raw))
    return observed


export=ROOT/'export';pins=read(ROOT/'source-pins.json')
for n,i in pins['exports'].items():
    raw=(export/n).read_bytes()
    check('fixed exported Git bytes '+n,raw==git('cat-file','blob',i['source']+':'+n) and sha(raw)==i['sha256'] and len(raw)==i['bytes'])
for folder in [ROOT.parent/'27-frozen-spec-review-01',ROOT.parent/'27-frozen-spec-review-01/revision-02',ROOT.parent/'27-frozen-spec-review-01/revision-03']:
    manifest=read(folder/'manifest.json')
    check('previous review manifest and all payload retained '+folder.name,all(sha((folder/n).read_bytes())==i['sha256'] for n,i in manifest['artifacts'].items()))
check('execution-to-continuation runtime and configs unchanged',git('diff','--name-only',EXEC,SRC,'--','src','configs')==b'')
protocol=read(export/'docs/mainline/27-loop-engineering-protocol-v3.json')
previous=read(export/'docs/mainline/27-loop-engineering-protocol-v2.json')
retained=protocol['retained_original'];cap=export/retained['folder'];case=cap/'original'
check('retained source/data exact declaration',retained['execution_source']==EXEC and retained['delivery']==DATA and retained['folder']==previous['output'])
doc=read(export/protocol['input'])
check('same single input and original independent literals',all(git('cat-file','blob',EXEC+':'+n)==(export/n).read_bytes() for n in [protocol['input'],protocol['independent_literals']]))
check('physical choices, closures, thresholds and chronology unchanged',all(protocol[k]==previous[k] for k in
      ['duration_s_per_case','maximum_step_s','decisions_s','choices','closure_states','absolute_tolerance','energy_tolerance_J','mass_tolerance_kg','independent_literals','input','scope']))
retained_paths=[n for n,i in pins['exports'].items() if i['source']==DATA]
check('all 21 failed-capture and launch files still exact at V3',len(retained_paths)==21 and all(git('cat-file','blob',SRC+':'+n)==(export/n).read_bytes() for n in retained_paths))
receipt=read(cap/'receipt.json');attempt=read(case/'attempt.json');run=read(case/'trajectory/run.json')
ledger=[json.loads(line) for line in (cap/'attempts.jsonl').read_bytes().splitlines()]
check('old outer failure, one completed internal integration, no replay',receipt['status']=='FAIL' and receipt['source_guard'] and receipt['source']==EXEC and
      receipt['attempts']==receipt['completed_integrations']==1 and receipt['validated']==0 and receipt['error']=='Maintenance/reserve gating differs' and
      [(r['case'],r['status'],r['source']) for r in ledger]==[('original','STARTED',EXEC),('original','FAILED',EXEC)] and not (cap/'replay').exists())
check('no increased engineering budget',protocol['cases']==['replay'] and protocol['attempt_budget']==1 and
      protocol['simulated_duration_budget_s']==10 and receipt['simulated_duration_attempted_s']+protocol['simulated_duration_budget_s']==protocol['combined_physical_budget_s']==20)
check('old receipt exactly binds original artifacts',set(receipt['artifacts'])|{'receipt.json'}=={p.relative_to(cap).as_posix() for p in cap.rglob('*') if p.is_file()} and
      all(sha((cap/n).read_bytes())==h for n,h in receipt['artifacts'].items()))
check('old internal recorder completion exact source',attempt['status']=='COMPLETED' and attempt['failure'] is None and
      attempt['duration_s']==10 and attempt['maximum_step_s']==.01 and run['code_identity']['git_commit']==attempt['source_identity']['git_commit']==EXEC and
      not run['code_identity']['implementation_has_changes'])
for n,h in attempt['artifacts'].items():
    check('internal attempt original artifact hash '+n,sha((case/n).read_bytes())==h)
runtime=receipt['pins']['runtime']
check('all 67 exact runtime hashes across both revisions',len(runtime)==67 and runtime==batch(EXEC,runtime)==batch(SRC,runtime))
expected_runtime={n:h for n,h in runtime.items() if n.startswith('src/aegis_dc/') or n=='src/patrol_rsi/contracts.py'}
check('recorded actual runtime source subset exact',run['code_identity']['files']==attempt['source_identity']['files']==expected_runtime)
frozen=read(case/'frozen-inputs.json');request=read(case/'request.json')
check('same frozen scenario, actual dispatch and request',frozen==doc['replay_inputs']==read(case/'inputs.json') and
      sha(canonical(frozen))==attempt['inputs_sha256'] and canonical(frozen['dispatch_program'])==canonical(run['inputs']['dispatch_program']) and
      read(case/'trajectory/scenario.json')==doc['model']==read(case/'scenario-input.json') and request['duration_s']==10 and request['maximum_step_s']==.01)
trace=[json.loads(line) for line in (case/'trajectory/private-state.jsonl').read_bytes().splitlines()]
balances=[json.loads(line) for line in (case/'trajectory/balances.jsonl').read_bytes().splitlines()]
check('1016 actual trace points with 1015 positive aligned steps',len(trace)==1016 and len(balances)==1015 and
      trace[0]['time_s']==0 and trace[-1]['time_s']==10 and all(x['time_s']==row['start_s']<row['end_s']==y['time_s']<=row['start_s']+.01
      for x,row,y in zip(trace,balances,trace[1:])))
events={(e['parameter_id'],e['time_s']):e['applied_at_s'] for e in run['events'] if e['kind']=='exogenous_boundary_input'}
at={x['time_s']:x['domains'] for x in trace};outage=events['grid_capacity',2];mains=events['grid_capacity',3.4]
check('earlier 7-ULP clock finding confirmed by saved original',len(events)==5 and mains==3.399999999999997 and
      (3.4-mains)/math.ulp(3.4)==7 and 3.4 not in at and set(events.values())<=set(at))
outage_rows=[x['domains'] for x in trace if outage<=x['time_s']<mains]
check('entire actual outage: no protected bridge/PLC/diesel, separate internal control',bool(outage_rows) and all(
      x['backup']['reserve_states']['ups']['mode']=='maintenance' and
      x['power']['ups_protected_output_W']==x['power']['generator_output_W']==x['power']['actual_powers_W']['local_controller']==0 and
      x['power']['ups_control_from_battery_W']==x['power']['ups_control_power_W']==x['power']['ups_output_W']==100
      for x in outage_rows))
check('old oracle demonstrably uses wrong total at actual outage',at[outage]['power']['ups_output_W']==100 and 'ups_output_W' in
      git('cat-file','blob',EXEC+':scripts/full_loop_delivery.py').decode().split("'Maintenance/reserve gating differs'")[0][-300:])
summary=run['summary'];expected=100*(mains-outage)
check('actual UPS internal battery energy from duration and balances',math.isclose(summary['ups_output_energy_J'],expected,abs_tol=1e-9,rel_tol=0) and
      math.isclose(math.fsum(r['ups_output_energy_J'] for r in balances),expected,abs_tol=1e-9,rel_tol=0),expected)
check('actual local restoration at 4 with valid gates, not mains time',not at[mains]['control_monitoring']['compute_permitted'] and at[4]['control_monitoring']['compute_permitted'] and
      at[4]['control_monitoring']['local_measurement']['sampled_at_s']==4 and at[4]['control_monitoring']['local_measurement']['temperature_K']<330 and
      at[4]['control_monitoring']['local_measurement']['internal_volume_flow_m3_s']>=.01)
check('same service chronology on every saved point',all(x['domains']['it_service']['demand']==(.5 if x['time_s']<.5 else 1) and
      x['domains']['it_service']['delivered']==(0 if outage<=x['time_s']<4 else (.5 if x['time_s']<.5 else 1)) for x in trace))
check('independent aggregate service and cost actual',summary['demand_service_unit_s']==F(39,4) and summary['delivered_service_unit_s']==F(31,4) and
      summary['service_deficit_time_s']==summary['worker_work_person_s']==2)
check('whole boundary balances retain tolerances',abs(summary['whole_run_energy_residual_J'])<protocol['energy_tolerance_J'] and
      summary['max_mass_residual_kg']<=protocol['mass_tolerance_kg'])
work=run['work_records'];effect=run['intervention_private_audit']['events'];fb=run['intervention_public_feedback']
check('real paid inspection and authorized cleaning',[(w['issued_at_s'],w['work_started_at_s'],w['completed_at_s'],w['status']) for w in work]==
      [(3,3.25,4.25,'completed'),(4.75,5,6,'completed')] and len(effect)==len(fb)==1 and
      (effect[0]['old_value'],effect[0]['new_value'],effect[0]['applied_at_s'])==(4,1,6) and fb[0]['arrived_at_s']==6.5 and not fb[0]['risk_closed'])
decisions=run['policy_public_decisions'];clos=[d['choice']['question_lifecycle']['questions'][0] for d in decisions]
check('8 decisions and lifecycle match frozen expectations',[(d['frame']['as_of_s'],d['choice']['chosen_candidate_id']) for d in decisions]==list(zip(protocol['decisions_s'],protocol['choices'])) and
      [c['status'] for c in clos]==protocol['closure_states'])
for d in decisions:
    t=d['frame']['as_of_s'];records={r['id']:r for r in d['frame']['evidence']['records']}
    check('only arrived evidence at '+str(t),all(r['observed_at_s']<=r['arrived_at_s']<=t for r in records.values()) and
          ('delayed-lake-work-order' in records)==(t>=3) and ('actual-lake-flow-before-action' in records)==(t>=4.75))
projection=decisions[1]['choice']['prospective_evidence_audit'][0]
check('actual branch factors and independent posteriors',projection['classification']=='INFORMATIVE_COMPATIBLE_WITH_DECLARED_UPDATER' and len(projection['compatibility_by_assumption'])==4 and
      all(r['status']=='MATCHED' and r['branches']['positive']['projected_outcome_mass']['cooling-limited']==[200,299] and
          r['branches']['negative']['projected_outcome_mass']['cooling-limited']==[50,941] and
          all({x[2] for x in b['projected_factor_signature']}=={'lake-work-order','lookahead-flow-channel'} for b in r['branches'].values())
          for r in projection['compatibility_by_assumption']))
support=set(clos[-1]['supporting_record_ids']);last={r['id']:r for r in decisions[-1]['frame']['evidence']['records']}
check('closure binds precisely four arrived verification records',support=={'flow-transfer:0','flow-transfer:1','joint-service-transfer:0','joint-service-transfer:1'} and
      clos[-1]['risk_closed'] and not any(c['risk_closed'] for c in clos[:-1]) and
      {(last[n]['observed_at_s'],last[n]['arrived_at_s']) for n in support}=={(7,7.5),(8,8.5)} and
      all(last[n]['availability']=='current' and last[n]['quality']['status']=='bounded' for n in support))
tool=ast.parse((export/'scripts/full_loop_delivery.py').read_bytes());funcs={n.name:n for n in tool.body if isinstance(n,ast.FunctionDef)}
cap_ast=funcs['capture'];calls=[n.func.id for n in ast.walk(cap_ast) if isinstance(n,ast.Call) and isinstance(n.func,ast.Name)]
check('V3 has one replay invocation, no original run invocation',calls.count('replay_attempt')==1 and 'run_recorded' not in calls and
      ast.unparse(cap_ast).index('checks = {\'original\': retained_check')<ast.unparse(cap_ast).index('result = replay_attempt'))
compare=funcs['compare'];pops=[n.args[0].value for n in ast.walk(compare) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='pop']
check('only declared wall clock and source label normalized',sorted(pops)==['elapsed_ns','git_commit'] and
      'DIFFERENT_COMMIT_SAME_RUNTIME_BYTES' in ast.unparse(compare) and "a['source_identity']['python'] == b['source_identity']['python']" in ast.unparse(compare))
check('replay comparison retains exact raw scenarios, trace, balance and origin',all(n in ast.unparse(compare) for n in
      ['scenario.json','private-state.jsonl','balances.jsonl','attempt.json','declaration.json','lifecycle.jsonl','EXACT_REEXECUTION']))
verify=funcs['verify']
check('saved verifier has no physical or selector call',not any(isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id in
      {'run_recorded','replay_attempt','capture','simulate_scenario','choose_work'} for n in ast.walk(verify)))
result=dict(status='PASS',source=SRC,base=DATA,retained_execution=EXEC,checks=len(checks),check_failures=0,findings=0,unresolved=0,
    exact_exports=len(pins['exports']),retained_original_and_launch_files=21,runtime_identity_files=67,
    original_outer_status='FAIL',original_inner_status='COMPLETED',original_physical_seconds=10,review_new_physical_seconds=0,
    planned_new_replay_seconds=10,combined_budget_seconds=20,trace_points=1016,balance_intervals=1015,
    project_calls=0,selector_calls=0,assessment_calls=0,simulation_calls=0,full_calls=0,test_calls=0,research_trials=0,
    scope='SAVED ORIGINAL AND NARROW REPLAY CONTINUATION PRECAPTURE REVIEW, NOT TICKET ACCEPTANCE')
(ROOT/'checks.json').write_text(json.dumps(dict(summary=result,checks=checks),indent=2)+'\n',encoding='utf-8')
print(json.dumps(result))
