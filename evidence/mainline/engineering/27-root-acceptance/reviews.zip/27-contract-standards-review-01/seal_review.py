"""Independent ticket27 contract Standards audit: Git/AST/Fraction/hash only."""
import ast
from fractions import Fraction as F
from hashlib import sha256
import json
from pathlib import Path
import subprocess

OUT=Path(__file__).resolve().parent
REPO=Path('C:/Users/Donson/.codex/worktrees/mainline27-full-loop/Renly')
PRIOR=Path('C:/Users/Donson/Documents/ChatGPT/Renly/.work/26-online-standards-review-01')
BASE='84a431ebe41a003549478da23c7ece0b9c8d86ee'
SOURCE='7779696d5db603b639a19bc6c95daf97ba37a410'
CONTRACT='docs/mainline/27-cross-system-loop-contract.md'
LITERALS='evidence/mainline/engineering/27-full-loop/reference/independent-literals-v1.json'
TOOL='scripts/prepare_full_loop_oracles.py'
checks=[]
def check(name,ok):
    checks.append(dict(name=name,passed=bool(ok)))
    if not ok:raise AssertionError(name)
def digest(raw):return sha256(raw).hexdigest()
def read(name):return json.loads((OUT/name).read_bytes())
def text(name):return (OUT/'export'/name).read_text(encoding='utf-8')
def encode(v):return (json.dumps(v,ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode()
def write(name,raw):
    with (OUT/name).open('xb') as stream:stream.write(raw)
def git(*args):return subprocess.check_output(['git',*args],cwd=REPO)
def line(name,token):return next(i for i,s in enumerate(text(name).splitlines(),1) if token in s)

pins=read('source-manifest.json');prior=read('prior26-reviews-before.json')
check('fixed source/base pins',pins['source']==SOURCE and pins['base']==BASE)
check('triple-dot mergebase fixed',git('merge-base',BASE,SOURCE).decode().strip()==BASE)
check('nonempty fixed diff',bool((OUT/'candidate.diff').read_bytes()))
check('only3 contract assets plus3claim metadata',set(pins['changed_files'])=={CONTRACT,LITERALS,TOOL,'.scratch/full-facility-mainline/issues/27-full-loop-demo.md','docs/mainline/progress.json','docs/current-research.json'})
check('no runtime src changes',not any(n.startswith('src/') for n in pins['changed_files']))
check('no repository coding or contributing file missing from review',pins['coding_standards_files']==[])
for name,expected in prior.items():check('ticket26 review original preserved '+name,digest((PRIOR/name).read_bytes())==expected)
keys=[SOURCE+':'+n for n in pins['files']]+[BASE+':'+n for n in pins['base_exports']]
batch=subprocess.check_output(['git','cat-file','--batch'],cwd=REPO,input=''.join(k+'\n' for k in keys).encode())
offset=0;blobs={}
for key in keys:
    end=batch.index(b'\n',offset);header=batch[offset:end].split();assert len(header)==3 and header[1]==b'blob',key
    start=end+1;size=int(header[2]);blobs[key]=batch[start:start+size];offset=start+size+1
check('single exact Git batch complete',offset==len(batch))
for name,identity in pins['files'].items():
    raw=(OUT/'export'/name).read_bytes()
    check('fixed export identity '+name,raw==blobs[SOURCE+':'+name] and digest(raw)==identity['sha256'] and len(raw)==identity['bytes'])
    if name.endswith('.py'):ast.parse(raw.decode('utf-8'),filename=name);check('AST syntax only '+name,True)
for name in pins['base_exports']:
    check('base export exact and unchanged '+name,(OUT/'base-export'/name).read_bytes()==blobs[BASE+':'+name]==blobs[SOURCE+':'+name])

contract=text(CONTRACT);literal=json.loads(text(LITERALS));tool=text(TOOL)
check('contract unexecuted and ticket claimed','设计与独立字面预期，尚未执行' in contract and '本票保持 claimed' in contract)
check('same synthetic8domain4graph facility scope','同一个八域、四图V6设施' in contract)
check('26 original impaired-network world not rewritten','不改写26永久网络0.25工况' in contract)
check('exogenous demand and actual heat distinct','外生服务需求和实际请求' in contract and '实际热源为1MW' in contract)
check('pump speed assumption cannot bypass no-power','当地保护和供电限制保留，不能强制泵在失电时供流' in contract)
check('colocated actor/tool assumption explicit','公共名义位置与实际位置一致' in contract and '本次湖侧作业的行走为0' in contract)
check('resource/qualification/access controls preserved','其他专业人员、工具、通行图、资格和房间门槛全部保留' in contract)
check('workorder observed and arrived separated','操作员工单观察时刻' in contract and '人工工单到达，第二次公开决策' in contract)
check('no hidden fault labels dispatch directly','工单是有限可信度的人工疑点，尚未到达' in contract)
check('actual current handheld signal only','读取当时实际滤阻4的流量，不读取工单观察时刻或未来值' in contract)
check('pending inspection cannot be used early','已发任务仍占有资源／结果未达，不可提前使用检查结果' in contract)
check('actual action completion changes filter only at6','只有6秒完成才将滤阻4变1' in contract)
check('action report not closure','只能成为ACTION_COMPLETED_PENDING_VERIFICATION，不自动关闭' in contract)
check('closure dual actual service and flow gate','依真实流量和真实服务记录验证关闭' in contract)
check('past deficit retained after restoration','过去缺额不被恢复或清滤抹除' in contract)
check('4sreset explicitly conditional and unverified','当前尚未通过独立状态机核验' in contract and '4秒复位尚是条件预期' in contract)
check('nonlinear thermal trajectory not falsely analytic','不宣称已证明整段非线性热轨迹或任意热状态域' in contract)
check('no selecting alternate success world after failure','失败即停，保留失败后再显式修订协议，不寻找另一个恰好成功的世界' in contract)
check('automatic service vs manual filter attribution separate','不得把它标为手工恢复供电或手工恢复服务' in contract)
check('no average demand denominator substitution','不能用一个总平均需求代替' in contract)
check('finite public model forecasts separated actual horizon','这些是有限公共模型预测，与10秒实际设施结果分开' in contract)
check('public independence explicitly required','条件独立性必须公开声明' in contract)
check('actual unsupported remains genuine missing','实际手持结果若未知／失败，仍保持真实原件，不强迫满足预测支持假设' in contract)

check('new single explicit service whitelist','显式白名单 `joint_service_delivered`' in contract)
check('target observable unit explicit','目标 `critical_service`、量 `service_capacity`、单位1' in contract)
check('new sensor actual signal exact path','私有当前快照路径为 `it_service.delivered`' in contract)
check('new signal a measured instrument not all-truth access','不是故障真值、保护内部状态或全场遥测' in contract)
check('service signal quality dropout timing reuse existing pipeline','使用现有固定仪表的范围、误差、丢失、轮询、到达和有效期规则' in contract)
check('capacity rate not arbitrary delivered fraction','不把它泛称为任意需求下的交付比例' in contract and '恢复后的外生需求恰为1' in contract)
check('new sensor sampling and adversarial slices required','真实运行的采样／未达／失配负例' in contract)
sensor=text('src/aegis_dc/sensor_channels.py');sensor_ast=ast.parse(sensor)
signal_assign=next(n for n in sensor_ast.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='SIGNALS' for t in n.targets))
signals={k.value for k in signal_assign.value.keys}
check('existing signal gap correctly identified',signals=={'coolant_temperature','controller_temperature','lake_mass_flow','rectifier_input_power'} and 'joint_service_delivered' not in signals)
plant=text('src/aegis_dc/plant.py')
check('actual snapshot delivered exists',"'it_service': point['service']" in plant or "'it_service': point['service']," in plant or "'it_service': point['service']" in plant.replace(' ','') or 'it_service' in plant and "'delivered':" in plant)
check('sensor validates closed whitelist target unit',"row['signal'] in SIGNALS" in sensor and "row['target_id'] == signal['target']" in sensor and "signal['quantity']" in sensor and "signal['unit']" in sensor)
replay=text('src/aegis_dc/replay.py')
check('v1 replay existing closed field gap accurate',"fields = {'schema', 'seed', 'exogenous_events', 'action_commands', 'work_requests'}" in replay and "set(value) != fields" in replay)
check('new replay versioned with old byte semantics','拟加新版本v2' in contract and '保持旧v1字节语义' in contract)
check('dispatch exclusive legacy work and no sidegate','带dispatch时旧显式work_requests必须为空' in contract and '不能同时提供work_program／inspection／intervention侧门' in contract)
check('exogenous versus command authority retained','工程命令权限和外生事件仍按原13区分' in contract)
check('replay computes endogenous actions not truth replay','计算真正内生处置，不使用原私有轨迹作为输入' in contract)
check('replay all outputs retained','保留决策、模型调用计数、工作／反馈、测量、事件、轨迹、平衡及输入' in contract)
check('only named elapsed_ns diagnostic exception','只将 `policy_computation_audit[*].elapsed_ns` 明确列为墙钟诊断' in contract)
check('no dropping policy results block','不能整块忽略policy结果' in contract)
check('identity differences cannot become general waiver','不能成为隐藏差异的通用豁免' in contract)
check('first scope minimal public redgreen','一处真实接口缺口作为最小公开RED/GREEN切片' in contract)
check('no protocol/budget allocated claimed','当前未准备正式运行协议，尚未分配／消耗正式尝试预算' in contract)
check('original and replay separate planned attempts','原运行10秒和同冻结程序的一次精确重放10秒分别记账' in contract)
check('not independently repeated research trial','二者不是独立研究重复' in contract)
check('inputs code tools head hash planned before each call','开始前保存确切模型／程序、源码／作者工具快照、当前HEAD及哈希和同步STARTED' in contract)
check('unique original and terminal durability','新UUID目录保存所有原输出与终态' in contract)
check('freeze durable set before formal capture','正式捕获另冻结源码、协议、工具、独立预期、预算及持久产物集合' in contract)
check('caches excluded not skipped durable hashes','自动缓存不算交付证据' in contract)
check('all failed attempts kept explicit correction','任何失败停止并保留；重试或假设更改须显式新版本' in contract)
check('full fresh visual independent gates before27resolve','根验收、独立复核、实际图表观看和干净Git交付后才能解决27' in contract)

# Independent literal arithmetic. No evaluation of the supplied oracle tool.
physical=literal['physical'];public=literal['public_model'];timing=literal['expected_times_s']
demand=F(1,2)*F(1,2)+F(19,2)
delivered=F(1,2)*F(1,2)+F(3,2)+F(6)
check('demand39/4 literal',demand==F(*physical['offered_demand_integral'])==F(39,4))
check('conditional delivered31/4 literal',delivered==F(*physical['delivered_integral'])==F(31,4))
check('unserved2 literal',demand-delivered==F(*physical['unserved_integral'])==F(2))
check('normalized deficit2 explicit positive demand denominator',F(2)*(1-0)/1==F(*physical['normalized_deficit_time_s'])==F(2))
check('conditional physical assumption retained','only if its actual temperature/flow gates hold' in physical['condition'])
check('hydraulic clean fixedhead',F(150000,12000000+3000000)==F(*physical['clean_flow_squared'])==F(1,100))
check('hydraulic degraded fixedhead',F(150000,12000000*4+3000000)==F(*physical['degraded_flow_squared'])==F(1,340))
check('same water density and massflow',F(998)*F(1,10)==F(*physical['clean_mass_flow_kg_s'])==F(499,5))
prior_bad=F(1,100);odds=prior_bad/(1-prior_bad);posterior_odds=odds*F(3,4)/F(3,100)
posterior=posterior_odds/(1+posterior_odds)
check('manual workorder posterior25/124',posterior==F(*public['bad_after_arrived_work_order'])==F(25,124))
posjoint=posterior*F(4,5);negjoint=posterior*F(1,5)
posmass=posjoint+(1-posterior)*F(1,10);negmass=1-posmass
check('positive original report mass299/1240',posmass==F(*public['positive_report_mass'])==F(299,1240))
check('positive posterior200/299',posjoint/posmass==F(*public['positive_bad'])==F(200,299))
check('negative posterior50/941',negjoint/negmass==F(*public['negative_bad'])==F(50,941))
defer=6*posterior;direct=1+posterior*F(1,4)
inspect=posmass+posjoint*2+negjoint*6
check('defer75/62',defer==F(*public['defer_deficit_s'])==F(75,62))
check('direct521/496',direct==F(*public['direct_deficit_s'])==F(521,496))
check('inspect999/1240',inspect==F(*public['inspect_deficit_s'])==F(999,1240))
check('prior defer3/50',6*prior_bad==F(*public['before_work_order_defer_deficit_s'])==F(3,50))
threshold=F(4,23)
prior_positive=prior_bad*F(4,5)/(prior_bad*F(4,5)+(1-prior_bad)*F(1,10))
prior_negative=prior_bad*F(1,5)/(prior_bad*F(1,5)+(1-prior_bad)*F(9,10))
check('both prior reports below direct-vs-defer threshold',prior_positive<threshold and prior_negative<threshold)
check('arrived workorder informative positive act negative defer',F(*public['positive_bad'])>threshold and F(*public['negative_bad'])<threshold)
check('postworkorder model favors inspect arithmetic',inspect<direct<defer)
check('actual and model horizon explicitly separate',public['actual_horizon_s']==10 and public['model_horizon_s']==6 and public['model_horizon_interpretation']=='Relative to each public decision')
check('workorder observed1.5arrived3',timing['work_order_observed']==1.5 and timing['work_order_arrived']==3)
check('actual proposed professional work1second',timing['inspection_completed']-timing['inspection_started']==timing['action_completed']-timing['action_started']==1)
check('sample7,8arrived7.5,8.5',timing['postaction_sample_times']==[7,8] and timing['postaction_arrival_times']==[7.5,8.5])
check('closure earliest8.5 after2samples1second',timing['first_possible_verified_closure']==8.5 and timing['postaction_sample_times'][1]-timing['postaction_sample_times'][0]==1 and timing['postaction_sample_times'][0]>timing['action_completed'])
check('literal table strictly no application calls',literal['new_selector_calls']==literal['new_physical_calls']==literal['new_full_regressions']==literal['registered_research_trials']==0)
check('literal table proposed not frozen or effect','NOT_FROZEN_RUN_PROTOCOL' in literal['status'] and literal['field_calibration']=='PENDING' and literal['overall_goal']=='ACTIVE')
tree=ast.parse(tool)
imports=[n for n in ast.walk(tree) if isinstance(n,(ast.Import,ast.ImportFrom))]
check('oracle imports onlystdlibFractionPathJSON',{n.module for n in imports if isinstance(n,ast.ImportFrom)}=={'fractions','pathlib'} and {a.name for n in imports if isinstance(n,ast.Import) for a in n.names}=={'json'})
check('oracle never imports project modules',not any((getattr(n,'module','') or '').startswith(('aegis_dc','patrol_rsi','tests','test_')) for n in imports))
check('oracle no external call or inference',not any(t in tool for t in ('simulate_scenario(','choose_work(','assess_action_value(','subprocess','importlib','exec(','eval(')))
check('oracle exclusive output write','OUTPUT.open(\'x\'' in tool and 'allow_nan=False' in tool)
check('oracle does not overwrite old artifacts','OUTPUT.open(\'w\'' not in tool)
check('oracle comments finite prediction not physical proof','PROPOSED_BEFORE_ANY_PROJECT_CALL_NOT_FROZEN_RUN_PROTOCOL' in tool)

progress=json.loads(text('docs/mainline/progress.json'));ticket=text('.scratch/full-facility-mainline/issues/27-full-loop-demo.md')
check('27claimed singleowner metadata','**Status:** claimed' in ticket and progress['current_ticket']=='27' and len(progress['active_implementations'])==1 and progress['active_implementations'][0]['agent']=='/root/m4_27_loop')
check('M4active and research0',progress['status']=='active' and next(m for m in progress['milestones'] if m['id']=='M4')['status']=='in_progress' and progress['research_trials']['attempts']==0)
check('conditional reset and gaps declared ticket','Two genuine interface gaps' in ticket and '4second PLC/thermal recovery is explicitly conditional' in ticket)
check('no explicit acceptance from contract','not a formal run or accepted ticket' in ticket)
after={p.relative_to(PRIOR).as_posix():digest(p.read_bytes()) for p in sorted(PRIOR.rglob('*')) if p.is_file()}
check('all old26 sealed artifact paths/hashes unchanged',after==prior)
write('prior26-reviews-after.json',encode(after));write('checks.json',encode(checks))
positions=dict(service=line(CONTRACT,'显式白名单'),replay=line(CONTRACT,'拟加新版本v2'),elapsed=line(CONTRACT,'policy_computation_audit'),durable=line(CONTRACT,'每次开发调用'),conditional=line(CONTRACT,'4秒复位尚是条件预期'),
    spec_private=line('.scratch/full-facility-mainline/spec.md','只给决策端允许的静态知识与到时证据'))
report=f'''Standards：PASS（7779696d，仅契约）。\n\n硬规则：无阻断。契约27-cross-system-loop-contract.md:{positions['service']}落实spec.md:{positions['spec_private']}“只给决策端允许的静态知识与到时证据”：白名单采it_service.delivered，保留延迟、来源与缺失；读数非泛化交付比例。:{positions['replay']}保留v1闭合边界，:{positions['elapsed']}仅豁免elapsed_ns。:{positions['conditional']}保留4秒复位条件，自动服务恢复与人工清滤分开；:{positions['durable']}要求源、输入、工具、STARTED、原件和终态。\n\n启发性风险：无本切片需处理的异味。字面算术相符，尚未证明PLC/热轨迹。0项目调用，旧26包未改；仅支持最小服务producer切片，27仍claimed，正式封存及根验收待后续。\n'''
check('report under400characters',len(report)<400)
write('report.md',report.encode('utf-8'))
review=dict(schema='aegisdc-independent-standards-review-v1',axis='Standards',status='PASS',base=BASE,source=SOURCE,
    scope='Ticket27 proposed complete-facility contract, independent literal tool/JSON and claim metadata only; no producer/replay implementation or fullworld run reviewed',
    diff_command='git diff '+BASE+'...'+SOURCE,checks=len(checks),exports=len(pins['files']),prior26_files_preserved=len(prior),
    documented_standards=pins['standards'],source_positions=positions,
    smell_baseline='Fowler12 judgement heuristics, repository overrides, tooling-enforced details skipped; no actionable smell in this finite contract/oracle slice',
    hard_findings=[],heuristic_findings=[],unresolved=[],new_project_calls=0,tests_run=0,selectors_run=0,assessments_run=0,inference_calls=0,simulation_calls=0,
    formal_protocol_frozen=False,formal_capture=False,ticket_acceptance=False,
    outcome='No static blocker to a single real delivered-service producer RED/GREEN slice; not authorization or acceptance of formal/fullworld execution',
    limits=['4second automatic reset/thermal feasibility remains conditional pending independent state-machine and actual physical validation','New service/replay boundaries are proposed; actual implementation needs its own fixed source review','Finite prediction6s and actual10s are separate, no candidate gain or field calibration established'])
write('review.json',encode(review))
artifacts={p.relative_to(OUT).as_posix():dict(sha256=digest(p.read_bytes()),bytes=p.stat().st_size) for p in sorted(OUT.rglob('*')) if p.is_file() and '__pycache__' not in p.parts and p.suffix not in {'.pyc','.pyo'}}
write('delivery-manifest.json',encode(dict(schema='aegisdc-static-review-delivery-manifest-v1',source=SOURCE,artifacts=artifacts,terminal_receipt='delivery-manifest.json',new_project_calls=0)))
print(json.dumps(dict(status='PASS',checks=len(checks),report_chars=len(report),report_sha256=digest((OUT/'report.md').read_bytes()),review_sha256=digest((OUT/'review.json').read_bytes()),manifest_sha256=digest((OUT/'delivery-manifest.json').read_bytes()),new_project_calls=0)))
