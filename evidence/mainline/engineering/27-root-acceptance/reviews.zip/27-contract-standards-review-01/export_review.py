"""Exact fixed contract/source exports; no application imports or execution."""
from hashlib import sha256
import json
from pathlib import Path
import subprocess
OUT=Path(__file__).resolve().parent
REPO=Path('C:/Users/Donson/.codex/worktrees/mainline27-full-loop/Renly')
PRIOR=Path('C:/Users/Donson/Documents/ChatGPT/Renly/.work/26-online-standards-review-01')
BASE='84a431ebe41a003549478da23c7ece0b9c8d86ee'
SOURCE='7779696d5db603b639a19bc6c95daf97ba37a410'
def git(*args):return subprocess.check_output(['git',*args],cwd=REPO)
def digest(raw):return sha256(raw).hexdigest()
def encode(v):return (json.dumps(v,ensure_ascii=False,indent=2)+'\n').encode()
def write(name,raw):
    path=OUT/name;path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('xb') as stream:stream.write(raw)
before={p.relative_to(PRIOR).as_posix():digest(p.read_bytes()) for p in sorted(PRIOR.rglob('*')) if p.is_file()}
write('prior26-reviews-before.json',encode(before))
assert git('merge-base',BASE,SOURCE).decode().strip()==BASE
diff=git('diff',BASE+'...'+SOURCE);assert diff
write('candidate.diff',diff);write('commits.txt',git('log','--format=%H %s',BASE+'..'+SOURCE))
changed=git('diff','--name-only',BASE+'...'+SOURCE).decode().splitlines()
tree=set(git('ls-tree','-r','--name-only',SOURCE).decode().splitlines())
standards=['AGENTS.md','GLOSSARY.md','docs/MAINLINE.md','docs/agents/domain.md','docs/agents/issue-tracker.md',
    'docs/agents/triage-labels.md','docs/adr/0003-complete-facility-mainline.md','.scratch/full-facility-mainline/spec.md']
coding=[n for n in tree if Path(n).name.upper() in {'CODING_STANDARDS.MD','CONTRIBUTING.MD'}]
related=['src/aegis_dc/'+n+'.py' for n in ['sensor_channels','live_sensor_execution','replay','replay_format','plant','policy_execution','verified_closure','evidence_ledger','nonfixed_evidence']]
paths=sorted(set(changed+standards+coding+related+['configs/full-facility-sensor-channels-v1.json','docs/mainline/13-replay-contract.md']))
paths=[n for n in paths if n in tree]
basepaths=sorted(n for n in paths if n not in changed)
keys=[SOURCE+':'+n for n in paths]+[BASE+':'+n for n in basepaths]
raw=subprocess.check_output(['git','cat-file','--batch'],cwd=REPO,input=''.join(k+'\n' for k in keys).encode())
offset=0;blobs={};ids={}
for key in keys:
    end=raw.index(b'\n',offset);header=raw[offset:end].split();assert len(header)==3 and header[1]==b'blob',key
    size=int(header[2]);start=end+1;blobs[key]=raw[start:start+size];ids[key]=header[0].decode();offset=start+size+1
assert offset==len(raw)
files={}
for name in paths:
    data=blobs[SOURCE+':'+name];write('export/'+name,data)
    files[name]=dict(git_blob=ids[SOURCE+':'+name],sha256=digest(data),bytes=len(data))
for name in basepaths:write('base-export/'+name,blobs[BASE+':'+name])
write('source-manifest.json',encode(dict(axis='Standards',base=BASE,source=SOURCE,files=files,base_exports=basepaths,changed_files=changed,
    standards=standards,coding_standards_files=coding,prior26_review_files=len(before),new_project_calls=0)))
print(json.dumps(dict(source=SOURCE,exports=len(files),changed_files=len(changed),prior26_files=len(before),coding_standards_files=coding,new_project_calls=0)))
