"""Fixed replay review. Reads Git/ZIP/JSON and AST; never imports project code."""
import ast
from copy import deepcopy
from fractions import Fraction as F
from hashlib import sha256
import json
from pathlib import Path, PurePosixPath
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parent
REPO = Path(r'C:\Users\Donson\.codex\worktrees\mainline27-full-loop\Renly')
SOURCE = 'e81cf750d6ddaae6e01752be769a690b940488f1'
BASE = '12aa08fc974abaf4a7f4d1a9f152bd545aa97a57'
PACKAGE = 'evidence/mainline/engineering/27-full-loop'
HISTORICAL = 'evidence/mainline/engineering/13-replay/capture-05'
checks = []


def check(name, okay):
    checks.append(dict(name=name, passed=bool(okay)))
    assert okay, name


def sha(raw):
    return sha256(raw).hexdigest()


def read(path):
    return json.loads(path.read_bytes())


def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO)


def canonical(data):
    return json.dumps(data, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()


def batch(revision, names):
    names = sorted(names)
    raw = subprocess.check_output(['git', 'cat-file', '--batch'], cwd=REPO,
        input=''.join(revision + ':' + name + '\n' for name in names).encode())
    result = {};offset = 0
    for name in names:
        end = raw.index(b'\n', offset);header = raw[offset:end].split()
        check('exact pinned Git blob available ' + revision[:8] + ':' + name, len(header) == 3 and header[1] == b'blob')
        start = end + 1;size = int(header[2]);offset = start + size + 1
        result[name] = sha(raw[start:start + size])
    check('Git batch exact framing ' + revision[:8], offset == len(raw))
    return result


pins = read(ROOT / 'source-pins.json');export = ROOT / 'export'
for name, identity in pins['exports'].items():
    raw = (ROOT / name).read_bytes()
    check('fixed export ' + name, raw == git('cat-file', 'blob', identity['revision'] + ':' + identity['path']) and
          sha(raw) == identity['sha256'] and len(raw) == identity['bytes'])
prior = read(ROOT / 'prior-sealed-hashes.json')
for name, expected in prior.items():
    check('previous review unchanged ' + name, sha((ROOT.parent / name).read_bytes()) == expected)
check('only replay runtime file changed', git('diff', '--name-only', BASE, SOURCE, '--', 'src').decode().splitlines() == ['src/aegis_dc/replay.py'])
check('previously accepted service and ticket13 historical artifacts untouched', git('diff', '--name-only', BASE, SOURCE, '--',
      HISTORICAL, PACKAGE + '/development-service-20261107-01', PACKAGE + '/development-service-20261107-02') == b'')
old = ast.parse((ROOT / 'base-export/src/aegis_dc/replay.py').read_bytes())
new = ast.parse((export / 'src/aegis_dc/replay.py').read_bytes())
old_funcs = {n.name: n for n in old.body if isinstance(n, ast.FunctionDef)}
new_funcs = {n.name: n for n in new.body if isinstance(n, ast.FunctionDef)}
check('no function added or removed', set(old_funcs) == set(new_funcs))
for name in old_funcs:
    if name not in {'_inputs', '_run_recorded', '_read_attempt'}:
        check('existing helper/entry unchanged ' + name, ast.dump(old_funcs[name], include_attributes=False) == ast.dump(new_funcs[name], include_attributes=False))
call = next(n for n in ast.walk(new_funcs['_run_recorded']) if isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id == 'simulate_scenario')
check('one actual simulation receives only frozen dispatch options', len(call.args) == 1 and [k.arg for k in call.keywords] ==
      ['duration_s', 'step_s', 'boundary_events', 'action_commands', 'work_requests', None] and call.keywords[-1].value.id == 'online_options')
check('actual recorded replay uses frozen inputs, not stored true trajectory', all('run' not in ast.unparse(n.args) for n in ast.walk(new_funcs['replay_attempt'])
      if isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id == '_run_recorded'))

folder = export / PACKAGE / 'development-replay-20261107-01'
declaration, receipt, manifest = [read(folder / n) for n in ('declaration.json', 'receipt.json', 'members.json')]
check('durable declared root', set(declaration['artifacts']) == set(receipt['artifacts']) == {'declaration.json','members.json','originals.zip'} and
      {p.name for p in folder.iterdir()} == set(receipt['artifacts']) | {'receipt.json'})
for name, expected in receipt['artifacts'].items():
    check('original package artifact ' + name, sha((folder / name).read_bytes()) == expected)
check('saved-only packager pinned', sha((export / receipt['tool']).read_bytes()) == receipt['tool_sha256'])
for name, expected in declaration['support'].items():
    check('original log/tool support ' + name, sha((export / name).read_bytes()) == expected)
with zipfile.ZipFile(folder / 'originals.zip') as z:
    check('499 unique declared ZIP members', len(z.namelist()) == len(set(z.namelist())) == len(manifest) == receipt['members'] == 499 and set(z.namelist()) == set(manifest))
    payload = {n:z.read(n) for n in z.namelist()}
for name, identity in manifest.items():
    p = PurePosixPath(name);raw = payload[name]
    check('archive member ' + name, not p.is_absolute() and '..' not in p.parts and '__pycache__' not in p.parts and p.suffix not in {'.pyc','.pyo'} and
          sha(raw) == identity['sha256'] and len(raw) == identity['bytes'])
check('reader fixture membership exact', {n for n in payload if n.startswith('reader-boundaries/')} == set(declaration['reader_fixtures']))

complete = {};refusals = {};case_receipts = [];git_pins = {}
for case in declaration['cases']:
    prefix = case + '/'
    def saved(name):return json.loads(payload[prefix + name])
    outer = saved('development-attempt.json');submitted = saved('input.json');record = saved('recorded/attempt.json')
    phase = saved('recorded/declaration.json');operation = outer['operation']
    case_receipts.append(dict(case=case, operation=operation, status=record['status']))
    check('precall 71 snapshots and root membership ' + case, len(outer['source_files']) == 71 and
          {n.removeprefix(prefix) for n in payload if n.startswith(prefix)} == {'development-attempt.json','input.json','recorded/attempt.json'} |
          {'pre-call/' + n for n in outer['source_files']} | {'recorded/' + n for n in record['artifacts']})
    for name, expected in outer['source_files'].items():
        check('exact original precall ' + case + ':' + name, sha(payload[prefix + 'pre-call/' + name]) == expected)
    for name, expected in record['artifacts'].items():
        check('original terminal artifact ' + case + ':' + name, sha(payload[prefix + 'recorded/' + name]) == expected)
    lifecycle = [json.loads(l) for l in payload[prefix + 'recorded/lifecycle.jsonl'].splitlines()]
    check('correct lifecycle and source ' + case, outer['status'] == 'STARTED' and outer['source_commit'] == BASE == record['source_identity']['git_commit'] and
          [r['state'] for r in lifecycle] == ['STARTED',record['status']] and all(r['attempt_id']==record['attempt_id'] for r in lifecycle) and lifecycle[-1]['failure']==record['failure'])
    runtime = {n:h for n,h in outer['source_files'].items() if n.startswith('src/')}
    pin = SOURCE if record['source_identity']['implementation_has_changes'] else BASE
    if pin not in git_pins:git_pins[pin] = batch(pin, runtime)
    check('captured exact runtime vs correct Git pin ' + case, runtime == git_pins[pin] and
          all(runtime[n]==h for n,h in record['source_identity']['files'].items()) and len(record['source_identity']['files'])==36)
    check('frozen actual invocation request ' + case, saved('recorded/inputs.json')==submitted['replay_inputs'] and saved('recorded/scenario-input.json')==submitted['model'] and
          saved('recorded/request.json')['duration_s']==submitted['duration_s']==1.75 and saved('recorded/request.json')['maximum_step_s']==submitted['maximum_step_s']==.01)
    check('not promoted to registered research ' + case, record['research_trials']==record['model_calls']==record['training_calls']==0 and record['field_calibration']=='PENDING')
    if record['status']=='FAILED':
        check('record rejection before physics ' + case, record['execution_kind']=='NOT_STARTED' and record['failure']['stage']=='validate_inputs' and
              not any(n.startswith(prefix+'recorded/trajectory/') for n in payload))
        refusals[case]=(operation,record['failure']);continue
    check('complete original exact declaration ' + case, set(record['artifacts'])==set(phase['required_when_completed']))
    frozen=saved('recorded/frozen-inputs.json');run=saved('recorded/trajectory/run.json')
    trace=[json.loads(l) for l in payload[prefix+'recorded/trajectory/private-state.jsonl'].splitlines()]
    balances=[json.loads(l) for l in payload[prefix+'recorded/trajectory/balances.jsonl'].splitlines()]
    check('strict V2 frozen dispatch binding ' + case, set(frozen)=={'schema','seed','exogenous_events','action_commands','work_requests','dispatch_program'} and
          frozen['schema']=='aegisdc-facility-replay-inputs-v2' and not frozen['work_requests'] and not frozen['action_commands'] and
          sha(canonical(frozen))==record['inputs_sha256'] and canonical(frozen['dispatch_program'])==canonical(run['inputs']['dispatch_program']))
    check('command and exogenous separation ' + case, run['inputs']['boundary_events']==frozen['exogenous_events'] and not run['inputs'].get('action_commands',[]) and not run['inputs']['work_requests'])
    check('saved run and actual code identity ' + case, all(run['code_identity'][k]==record['source_identity'][k] for k in ('git_commit','files','source_tree_sha256','implementation_has_changes')) and
          run['code_identity']['implementation_has_changes'] and run['inputs']['duration_s']==record['duration_s']==1.75 and run['inputs']['maximum_step_s']==.01)
    check('old exact replay time axis and interval accounting ' + case, len(trace)==len(balances)+1 and trace[0]['time_s']==0 and trace[-1]['time_s']==1.75 and
          all(a['time_s']==b['start_s']<b['end_s']==c['time_s']<=b['start_s']+.01 for a,b,c in zip(trace,balances,trace[1:])))
    check('real FIFO dispatch and completion clocks ' + case, [d['choice']['chosen_candidate_id'] for d in run['policy_public_decisions']]==['first-action',None,None,None,None] and
          [(w['issued_at_s'],w['work_started_at_s'],w['completed_at_s']) for w in run['work_records']]==[(0,.25,1.25)])
    effects=run['intervention_private_audit']['events'];reports=run['intervention_public_feedback']
    check('one real paid filter effect ' + case, len(effects)==len(reports)==1 and (effects[0]['parameter_id'],effects[0]['old_value'],effects[0]['new_value'],effects[0]['applied_at_s'])==
          ('filter_resistance_multiplier',4,1,1.25) and (reports[0]['observed_at_s'],reports[0]['arrived_at_s'],reports[0]['risk_closed'])==(1.25,1.75,False))
    check('independent flow change from physical trace ' + case, all(abs(x['domains']['facility_cooling']['lake_pump']['volume_flow_m3_s']**2 -
          float(F(1,340 if x['time_s']<1.25 else 100)))<1e-12 for x in trace))
    check('fixed service integral separate from repair ' + case, run['summary']['demand_service_unit_s']==F(3,2) and run['summary']['delivered_service_unit_s']==F(5,8) and
          run['summary']['service_deficit_time_s']==1 and run['summary']['worker_work_person_s']==1)
    check('all decisions see only arrived records ' + case, all(q['observed_at_s']<=q['arrived_at_s']<=d['frame']['as_of_s'] for d in run['policy_public_decisions'] for q in d['frame']['evidence']['records']))
    normalized=deepcopy(run);elapsed=[]
    for a in normalized['policy_computation_audit']:elapsed.append(a.pop('elapsed_ns'))
    check('only explicit diagnostic elapsed entries removed ' + case, len(elapsed)==5 and all(type(t) is int and t>=0 for t in elapsed))
    complete[operation]=dict(prefix=prefix,record=record,frozen=frozen,run=normalized,elapsed=elapsed)

check('two real physical calls and four input-stage refusals', set(complete)=={'record','replay'} and len(refusals)==4 and case_receipts==receipt['attempts'])
a,b=complete['record'],complete['replay']
check('exact immutable origin attempt and copied bytes', b['record']['replay_of']==dict(attempt_id=a['record']['attempt_id'],
      attempt_sha256=sha(payload[a['prefix']+'recorded/attempt.json']),mode='EXACT_REEXECUTION') and
      all(payload[b['prefix']+'recorded/origin/'+n]==payload[a['prefix']+'recorded/'+n] for n in ('attempt.json','declaration.json','lifecycle.jsonl')))
check('exact frozen inputs and all semantic run fields except elapsed_ns', canonical(a['frozen'])==canonical(b['frozen']) and canonical(a['run'])==canonical(b['run']))
for name in ('scenario.json','private-state.jsonl','balances.jsonl'):
    check('identical raw physical output ' + name, payload[a['prefix']+'recorded/trajectory/'+name]==payload[b['prefix']+'recorded/trajectory/'+name])
boundary=json.loads(payload['reader-boundaries/boundary-result-01.json'])
check('saved boundary report preserves refusals and no physical calls', boundary['status']=='PASS' and boundary['malformed_record_calls']==3 and
      boundary['new_simulation_calls']==boundary['new_selector_calls']==boundary['registered_research_trials']==0 and
      all(refusals[r['case']]==(r['label'],r['failure']) for r in boundary['input_refusals']))
for row in boundary['preserved_v1_saved_reads']:
    path=HISTORICAL+'/'+row['case']+'/';terminal=(export/path/'attempt.json').read_bytes()
    check('legacy V1 exact committed original ' + row['case'], sha(terminal)==row['original_terminal_sha256'] and
          all((export/path/name).read_bytes()==git('cat-file','blob',BASE+':'+path+name) for name in ('attempt.json','frozen-inputs.json','trajectory/run.json')) and
          json.loads(terminal)['status']=='COMPLETED' and read(export/path/'frozen-inputs.json')['schema']=='aegisdc-facility-replay-inputs-v1' and
          'dispatch_program' not in read(export/path/'trajectory/run.json')['inputs'])
forge='reader-boundaries/'+PurePosixPath(boundary['forged_saved_origin']).name+'/'
forged_record=json.loads(payload[forge+'attempt.json']);forged_run=json.loads(payload[forge+'trajectory/run.json']);forged_frozen=json.loads(payload[forge+'frozen-inputs.json'])
check('hash-consistent reader fixture rejected for semantic program mismatch', all(sha(payload[forge+n])==h for n,h in forged_record['artifacts'].items()) and
      canonical(forged_frozen)==canonical(a['frozen']) and canonical(forged_run['inputs']['dispatch_program'])!=canonical(forged_frozen['dispatch_program']) and
      boundary['forged_refusal']['stage']=='trajectory_dispatch_program' and boundary['forged_refusal']['artifact']=='trajectory/run.json')
summary=dict(status='PASS',source=SOURCE,base=BASE,checks=len(checks),check_failures=0,findings=0,unresolved=0,
    exact_exports=len(pins['exports']),prior_files_unchanged=len(prior),archive_members=499,development_attempts=6,
    completed_original_and_replay=2,completed_physical_duration_s=3.5,input_refusals=4,legacy_v1_saved_reads=4,
    project_calls=0,selector_calls=0,assessment_calls=0,simulation_calls=0,test_calls=0,full_calls=0,research_trials=0,
    scope='SHORT_V2_RECORDED_DISPATCH_REPLAY_SLICE_ONLY_NOT_FULL27')
(ROOT/'checks.json').write_text(json.dumps(dict(summary=summary,checks=checks),indent=2)+'\n',encoding='utf-8')
print(json.dumps(summary))
