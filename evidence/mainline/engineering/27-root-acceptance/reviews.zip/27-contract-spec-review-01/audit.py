"""Fixed27 contract review: Git blobs, JSON, AST and independent Fraction only.

Never import or execute the selector, plant, public assessment or oracle tool.
"""
import ast
from fractions import Fraction as F
from hashlib import sha256
import json
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parent
REPO = Path(r'C:\Users\Donson\.codex\worktrees\mainline23-intervention\Renly')
SOURCE = '7779696d5db603b639a19bc6c95daf97ba37a410'
BASE = '84a431ebe41a003549478da23c7ece0b9c8d86ee'
checks = []


def check(name, okay, detail=None):
    checks.append(dict(name=name, passed=bool(okay), detail=detail))
    assert okay, name


def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO)


def raw(name):
    return (ROOT / 'export' / name).read_bytes()


def read(name):
    return json.loads(raw(name))


def tree(name):
    return ast.parse(raw(name).decode())


def ratios(value):
    return [value.numerator, value.denominator]


pins = read_local = json.loads((ROOT / 'source-pins.json').read_bytes())
for name, identity in pins['exports'].items():
    data = raw(name)
    check('exact fixed Git export ' + name, data == git('cat-file', 'blob', SOURCE + ':' + name) and
          sha256(data).hexdigest() == identity['sha256'] and len(data) == identity['bytes'])
check('base and source exact pinned commits', git('rev-parse', SOURCE).decode().strip() == SOURCE and git('rev-parse', BASE).decode().strip() == BASE)
check('contract slice changes no accepted implementation or26originals', git('diff', '--name-only', BASE, SOURCE, '--',
      'src', 'configs', 'evidence/mainline/engineering/26-candidate', 'evidence/mainline/engineering/26-root-acceptance') == b'')
progress = read('docs/mainline/progress.json')
check('27 is active frontier with owner and M4 unfinished', progress['status'] == 'active' and progress['current_ticket'] == '27' and
      progress['current_milestone'] == 'M4' and progress['active_implementations'][0]['agent'] == '/root/m4_27_loop')
check('effect trials remain zero and fieldcalibration pending', progress['research_trials']['attempts'] == 0 and progress['field_calibration'] == 'PENDING')
oracle = read('evidence/mainline/engineering/27-full-loop/reference/independent-literals-v1.json')
public = oracle['public_model'];physical = oracle['physical'];times = oracle['expected_times_s']

# Derive the finite branch decisions independently by exact expected loss.
# In this declared toy consequence model, defer costs6p and delayed action1+2p;
# hence the report-contingent action threshold is1/4.
prior = F(1, 100)
manual_positive = prior * F(3, 4) + (1 - prior) * F(3, 100)
posterior = prior * F(3, 4) / manual_positive
handheld_mass = posterior * F(4, 5) + (1 - posterior) * F(1, 10)
positive = posterior * F(4, 5) / handheld_mass
negative = posterior * F(1, 5) / (1 - handheld_mass)
defer = 6 * posterior
direct = 1 + posterior / 4
inspect = handheld_mass * min(6 * positive, 1 + 2 * positive) + (1 - handheld_mass) * min(6 * negative, 1 + 2 * negative)
initial_mass = prior * F(4, 5) + (1 - prior) * F(1, 10)
initial_positive = prior * F(4, 5) / initial_mass
initial_negative = prior * F(1, 5) / (1 - initial_mass)
initial_inspection = initial_mass * min(6 * initial_positive, 1 + 2 * initial_positive) + (1 - initial_mass) * min(6 * initial_negative, 1 + 2 * initial_negative)
expectations = dict(prior_bad=prior, work_order_positive_bad=F(3, 4), work_order_positive_good=F(3, 100),
    bad_after_arrived_work_order=posterior, positive_report_mass=handheld_mass, positive_bad=positive, negative_bad=negative,
    defer_deficit_s=defer, direct_deficit_s=direct, inspect_deficit_s=inspect, before_work_order_defer_deficit_s=6 * prior)
for name, value in expectations.items():
    check('independent public model literal ' + name, public[name] == ratios(value))
check('posterior exact25/124', posterior == F(25, 124))
check('branch exact200/299and50/941', positive == F(200, 299) and negative == F(50, 941))
check('check/direct/defer exact values', (inspect, direct, defer) == (F(999, 1240), F(521, 496), F(75, 62)))
check('initial reports both below action threshold', initial_positive < F(1, 4) and initial_negative < F(1, 4))
check('initial defer same loss as inspection', initial_inspection == 6 * prior == F(3, 50))
check('manual arrived makes inspection strictly preferred', inspect < direct < defer and positive > F(1, 4) > negative)
check('prediction window separate from actual horizon', public['model_horizon_s'] == 6 and public['actual_horizon_s'] == physical['duration_s'] == 10)

# Physical consequences are conditional literals, not a solved thermal path.
demand = F(1, 2) * F(1, 2) + F(19, 2)
delivery = F(1, 2) * F(1, 2) + F(3, 2) + F(6)
for name, value in [('offered_demand_integral', demand), ('delivered_integral', delivery),
                    ('unserved_integral', demand - delivery), ('normalized_deficit_time_s', F(2))]:
    check('independent conditional service integral ' + name, physical[name] == ratios(value))
check('off2to4 during demand1 has2normalizedseconds', physical['compute_permission_expected_off_s'] == [2, 4] and demand - delivery == 2)
check('mains outage shorter than conditional protection interval', physical['grid_outage_s'] == [2, 3.4] and F(17, 5) < 4)
check('maintenance and diesel gates explicit', physical['ups_maintenance_from_s'] == 1 and physical['diesel_start_delay_s'] == 30 and 2 + 30 > 10)
for multiplier, key in [(1, 'clean_flow_squared'), (4, 'degraded_flow_squared')]:
    check('independent fixed-head law ' + key, physical[key] == ratios(F(150000, 12000000 * multiplier + 3000000)))
check('independent density mass flow', physical['clean_mass_flow_kg_s'] == ratios(F(998) / 10))
check('actual task positive paid intervals', times['inspection_started'] == float(F(3) + F(1, 4)) and
      times['inspection_completed'] == times['inspection_started'] + 1 and times['handheld_record_arrived'] == times['inspection_completed'] + .5 and
      times['action_started'] == times['action_issued'] + .25 and times['action_completed'] == times['action_started'] + 1 and
      times['action_report_arrived'] == times['action_completed'] + .5)
check('closure genuine postaction sample chronology', times['postaction_sample_times'] == [7, 8] and times['postaction_arrival_times'] == [7.5, 8.5] and
      times['action_completed'] == 6 < 7 and times['first_possible_verified_closure'] == 8.5 and 8 - 7 == 1)
base_params = {p['id']: p for p in read('configs/full-facility-mainline-reserve-v6.json')['parameters']}
check('new minpump1 stays accepted parameter range', base_params['pump_min_speed']['valid_range'][0] <= 1 <= base_params['pump_min_speed']['valid_range'][1])
check('nominal2MW computes0.5/1capacity', base_params['compute_nominal_power']['value'] == 2000000 and F(1000000, 2000000) == F(1, 2))
check('sample schedule has3and4 but not3.4', base_params['control_sample_time']['value'] == 1)

# Current kernel facts supporting the contract's named gaps and conditions.
signal_node = next(n for n in tree('src/aegis_dc/sensor_channels.py').body if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'SIGNALS' for t in n.targets))
check('service producer is an actual current whitelist gap', 'joint_service_delivered' not in ast.literal_eval(ast.Dict(keys=signal_node.value.keys, values=[ast.Constant(0) for _ in signal_node.value.keys])))
replay_schema = next(n for n in tree('src/aegis_dc/replay.py').body if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'INPUT_SCHEMA' for t in n.targets))
check('online recorded transport is actualv1gap', ast.literal_eval(replay_schema.value) == 'aegisdc-facility-replay-inputs-v1')
oracle_tool = tree('scripts/prepare_full_loop_oracles.py')
imports = [n for n in ast.walk(oracle_tool) if isinstance(n, (ast.Import, ast.ImportFrom))]
check('oracle only stdlib imports', all((n.module in {'fractions', 'pathlib'} if isinstance(n, ast.ImportFrom) else all(x.name == 'json' for x in n.names)) for n in imports))
check('oracle never calls public project entry', not any(isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id in
      {'simulate_scenario', 'choose_work', 'infer_belief', 'assess_action_value', 'assess_closure'} for n in ast.walk(oracle_tool)))
check('oracle uses exclusive new output', any(isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute) and n.func.attr == 'open' and
      any(isinstance(a, ast.Constant) and a.value == 'x' for a in n.args) for n in ast.walk(oracle_tool)))

arithmetic = dict(public={name: ratios(v) for name, v in expectations.items()}, before_manual=dict(
    positive_bad=ratios(initial_positive), negative_bad=ratios(initial_negative), inspection_loss=ratios(initial_inspection),
    action_threshold=ratios(F(1, 4)), defer_loss=ratios(6 * prior)),
    physical_conditional=dict(offered=ratios(demand), delivery=ratios(delivery), unserved=ratios(demand - delivery)),
    no_thermal_path_solution=True, no_project_calls=True)
(ROOT / 'arithmetic.json').write_text(json.dumps(arithmetic, indent=2) + '\n', encoding='utf-8')
summary = dict(status='PASS_CONTRACT_SCOPE', source=SOURCE, base=BASE, checks=len(checks), check_failures=0,
               findings=0, unresolved=0, exact_exports=len(pins['exports']), project_calls=0, selector_calls=0,
               assessment_calls=0, plant_calls=0, full_calls=0, probe_calls=0, test_calls=0, research_trials=0,
               scope='CONTRACT_AND_INDEPENDENT_LITERAL_REVIEW_NOT_IMPLEMENTATION_OR_THERMAL_RECOVERY_PROOF')
(ROOT / 'checks.json').write_text(json.dumps(dict(summary=summary, checks=checks), indent=2) + '\n', encoding='utf-8')
print(json.dumps(summary))
