"""Verify saved ticket 27 originals and their replay independently, with zero project calls."""
from copy import deepcopy
from fractions import Fraction as F
from hashlib import sha256
import json
import math
from pathlib import Path
import subprocess

ROOT=Path(__file__).resolve().parent
REPO=Path(r'C:\Users\Donson\.codex\worktrees\mainline27-full-loop\Renly')
checks=[]


def check(name,okay,detail=None):
    checks.append(dict(name=name,passed=bool(okay),detail=detail))
    assert okay,name


def read(path):return json.loads(path.read_bytes())
def sha(raw):return sha256(raw).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=REPO)
def canonical(value):return json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False).encode()


def batch(rev,names):
    names=sorted(names);result={};offset=0
    raw=subprocess.check_output(['git','cat-file','--batch'],cwd=REPO,input=''.join(rev+':'+n+'\n' for n in names).encode())
    for n in names:
        end=raw.index(b'\n',offset);header=raw[offset:end].split()
        check('Git pinned role '+rev[:8]+':'+n,len(header)==3 and header[1]==b'blob')
        start=end+1;offset=start+int(header[2])+1;result[n]=sha(raw[start:offset-1])
    check('exact Git batch boundary '+rev[:8],offset==len(raw))
    return result


pins=read(ROOT/'source-pins.json');export=ROOT/'export';delivery=pins['source'];replay_src=pins['base'];old_data=pins['original_data'];original_src=pins['original_execution']
for name,i in pins['exports'].items():
    raw=(export/name).read_bytes()
    check('exact fixed export '+name,raw==git('cat-file','blob',i['source']+':'+name) and sha(raw)==i['sha256'] and len(raw)==i['bytes'])
for d in ['27-frozen-spec-review-01','27-frozen-spec-review-01/revision-02','27-frozen-spec-review-01/revision-03','27-replay-continuation-spec-01']:
    folder=ROOT.parent/d;manifest=read(folder/'manifest.json')
    check('prior sealed reviewer package unchanged '+d,all(sha((folder/n).read_bytes())==i['sha256'] for n,i in manifest['artifacts'].items()))
package='evidence/mainline/engineering/27-full-loop'
old=export/package/'capture-20261107-02';new=export/package/'capture-20261107-03'
protocol=read(export/'docs/mainline/27-loop-engineering-protocol-v3.json')
doc=read(export/protocol['input'])
old_receipt=read(old/'receipt.json');new_receipt=read(new/'receipt.json')
check('old status kept; only replay passed',old_receipt['status']=='FAIL' and old_receipt['validated']==0 and
      old_receipt['error']=='Maintenance/reserve gating differs' and new_receipt['status']=='PASS' and new_receipt['validated']==1 and
      old_receipt['source_guard'] and new_receipt['source_guard'])
check('exactly two attempted 10-second integrations, no effect trials',old_receipt['attempts']==new_receipt['attempts']==
      old_receipt['completed_integrations']==new_receipt['completed_integrations']==1 and
      old_receipt['simulated_duration_attempted_s']==new_receipt['simulated_duration_attempted_s']==10 and
      old_receipt['registered_effect_trials']==new_receipt['registered_effect_trials']==0 and
      old_receipt['field_calibration']==new_receipt['field_calibration']=='PENDING')
retained={n:i['sha256'] for n,i in pins['exports'].items() if i['source']==old_data}
check('all 21 retained capture and launch originals bound by new receipt',len(retained)==21 and new_receipt['pins']['retained_original']==retained)
check('retained 02 originals remain exact at data delivery',batch(delivery,retained)==retained)
check('sole source change is tooling/metadata, runtime remains identical',git('diff','--name-only',original_src,replay_src,'--','src','configs')==b'' and
      git('diff','--name-only',replay_src,delivery,'--','src','configs','scripts')==b'')
runtime=old_receipt['pins']['runtime']
check('exact same 67 source files across both executions',len(runtime)==67 and runtime==new_receipt['pins']['runtime']==batch(original_src,runtime)==batch(replay_src,runtime))
for rev,receipt in [(original_src,old_receipt),(replay_src,new_receipt)]:
    for role in ['tools','inputs','development_originals']:
        check('original execution pin role '+rev[:8]+':'+role,batch(rev,receipt['pins'][role])==receipt['pins'][role])
check('no committed original from unexecuted 9e variant',git('ls-tree','-r','--name-only',delivery,package+'/capture-20261107-01')==b'')
cases={}
for tag,folder,name,src,receipt,expected_members,terminal_status in [
        ('02',old,'original',original_src,old_receipt,14,'FAILED'),('03',new,'replay',replay_src,new_receipt,18,'COMPLETED')]:
    check('exact capture members '+tag,len(list(p for p in folder.rglob('*') if p.is_file()))==expected_members and
          set(receipt['artifacts'])|{'receipt.json'}=={p.relative_to(folder).as_posix() for p in folder.rglob('*') if p.is_file()})
    for n,h in receipt['artifacts'].items():check('capture artifact '+tag+':'+n,sha((folder/n).read_bytes())==h)
    ledger=[json.loads(l) for l in (folder/'attempts.jsonl').read_bytes().splitlines()]
    check('outer attempt provenance '+tag,[(r['case'],r['source'],r['status']) for r in ledger]==[(name,src,'STARTED'),(name,src,terminal_status)] and ledger[0]['duration_s']==10)
    launch=export/package/f'capture-{tag}-launch';manifest=read(launch/'manifest.json');la=read(launch/'attempt.json');lt=read(launch/'terminal.json');process=read(launch/'process.json')
    check('exact seven launch files '+tag,len(list(launch.iterdir()))==7 and set(manifest)|{'manifest.json'}=={p.name for p in launch.iterdir()} and
          all(sha((launch/n).read_bytes())==h for n,h in manifest.items()))
    check('launch lifecycle/source '+tag,la['status']=='STARTED' and la['source']==lt['source']==process['source']==src and
          lt['status']==terminal_status and lt['returncode']==(0 if tag=='03' else 1) and lt['receipt_exists'] and
          lt['stdout_sha256']==manifest['stdout.txt'] and lt['stderr_sha256']==manifest['stderr.txt'] and la['launcher_sha256']==manifest['launcher.py'])
    meta=read(folder/'capture.json');case=folder/name;attempt=read(case/'attempt.json');run=read(case/'trajectory/run.json');inputs=read(case/'frozen-inputs.json');decl=read(case/'declaration.json')
    check('exact launch Python and no cache authority '+tag,la['argv'][1:4]==['-B','-X','utf8'] and not la['cache_prefix_existed_before'] and
          meta['cache_prefix']==la['environment']['PYTHONPYCACHEPREFIX'] and meta['no_bytecode'] and meta['utf8_mode']==1 and
          meta['executable_sha256']==la['executable_sha256']==attempt['source_identity']['python']['executable_sha256'])
    check('inner success and pinned source '+tag,attempt['status']=='COMPLETED' and attempt['failure'] is None and
          attempt['source_identity']['git_commit']==run['code_identity']['git_commit']==meta['execution_source']==src and not run['code_identity']['implementation_has_changes'])
    check('exact internal durable artifacts '+tag,set(attempt['artifacts'])==set(decl['required_when_completed']) and all(sha((case/n).read_bytes())==h for n,h in attempt['artifacts'].items()))
    check('closed frozen inputs and actual run binding '+tag,inputs==doc['replay_inputs']==read(case/'inputs.json') and
          sha(canonical(inputs))==attempt['inputs_sha256'] and canonical(run['inputs']['dispatch_program'])==canonical(inputs['dispatch_program']) and
          not inputs['work_requests'] and not inputs['action_commands'] and run['inputs']['duration_s']==attempt['duration_s']==10)
    cases[tag]=dict(case=case,attempt=attempt,run=run,inputs=inputs)
a,b=cases['02'],cases['03']
check('replay original attempt linkage and distinct IDs',a['attempt']['attempt_id']!=b['attempt']['attempt_id'] and b['attempt']['replay_of']==dict(
      attempt_id=a['attempt']['attempt_id'],attempt_sha256=sha((a['case']/'attempt.json').read_bytes()),mode='EXACT_REEXECUTION') and
      b['attempt']['replay_revision_relationship']=='DIFFERENT_COMMIT_SAME_RUNTIME_BYTES')
for n in ['attempt.json','declaration.json','lifecycle.jsonl']:
    check('replay origin exact old identity bytes '+n,(a['case']/n).read_bytes()==(b['case']/'origin'/n).read_bytes())
check('recorded runtime/interpreter identity equal',a['attempt']['source_identity']['python']==b['attempt']['source_identity']['python'] and
      a['attempt']['source_identity']['files']==b['attempt']['source_identity']['files']==a['run']['code_identity']['files']==b['run']['code_identity']['files'] and
      all(runtime[n]==h for n,h in a['run']['code_identity']['files'].items()))
normalized=[]
for entry,src in [(a,original_src),(b,replay_src)]:
    run=deepcopy(entry['run']);label=run['code_identity'].pop('git_commit');elapsed=[d.pop('elapsed_ns') for d in run['policy_computation_audit']]
    check('only explicit Git and elapsed diagnostic fields '+src[:8],label==src and len(elapsed)==8 and all(type(v) is int and v>=0 for v in elapsed))
    normalized.append(canonical(run))
check('all other saved run content exact',normalized[0]==normalized[1])
for n in ['scenario.json','private-state.jsonl','balances.jsonl']:
    check('raw trajectory payload byte equality '+n,(a['case']/'trajectory'/n).read_bytes()==(b['case']/'trajectory'/n).read_bytes())
trace=[json.loads(l) for l in (b['case']/'trajectory/private-state.jsonl').read_bytes().splitlines()];bal=[json.loads(l) for l in (b['case']/'trajectory/balances.jsonl').read_bytes().splitlines()]
domains={'power','backup','facility_cooling','equipment_environment','it_service','control_monitoring','space_access','people_tools_work'}
check('all eight physical domains and four declared relations',len(trace)==1016 and len(bal)==1015 and all(set(r['domains'])==domains for r in trace) and
      set(doc['model']['graphs'])=={'physical','functional','control_information','access'})
check('complete physical interval coverage',trace[0]['time_s']==0 and trace[-1]['time_s']==10 and all(x['time_s']==r['start_s']<r['end_s']==y['time_s'] for x,r,y in zip(trace,bal,trace[1:])))
run=b['run'];ds=run['policy_public_decisions'];closed=[d['choice']['question_lifecycle']['questions'][0] for d in ds];actual=run['summary']
check('same eight decision choices and closure timeline',[(d['frame']['as_of_s'],d['choice']['chosen_candidate_id']) for d in ds]==list(zip(protocol['decisions_s'],protocol['choices'])) and
      [q['status'] for q in closed]==protocol['closure_states'])
for d in ds:
    t=d['frame']['as_of_s'];records={r['id']:r for r in d['frame']['evidence']['records']}
    check('arrived evidence only at '+str(t),all(r['observed_at_s']<=r['arrived_at_s']<=t for r in records.values()) and
          ('delayed-lake-work-order' in records)==(t>=3) and ('actual-lake-flow-before-action' in records)==(t>=4.75))
records={r['id']:r for r in ds[-1]['frame']['evidence']['records']};manual=records['delayed-lake-work-order'];hand=records['actual-lake-flow-before-action'];at={r['time_s']:r['domains'] for r in trace}
check('actual delayed report and handheld observations',(manual['observed_at_s'],manual['arrived_at_s'],hand['observed_at_s'],hand['arrived_at_s'])==(1.5,3,4.25,4.75))
check('actual paid work and unique endogenous clean effect',[(w['issued_at_s'],w['work_started_at_s'],w['completed_at_s']) for w in run['work_records']]==
      [(3,3.25,4.25),(4.75,5,6)] and [(e['parameter_id'],e['old_value'],e['new_value'],e['applied_at_s']) for e in run['intervention_private_audit']['events']]==
      [('filter_resistance_multiplier',4,1,6)] and run['intervention_public_feedback'][0]['arrived_at_s']==6.5)
check('automatic recovery before cleaning',at[4]['control_monitoring']['local_measurement']['sampled_at_s']==4 and at[4]['control_monitoring']['compute_permitted'] and
      at[4]['it_service']['delivered']==1 and at[6]['it_service']['delivered']==1)
check('maintained UPS protected zero separate from internal battery control',at[2]['power']['ups_protected_output_W']==at[2]['power']['generator_output_W']==0 and
      at[2]['power']['ups_control_from_battery_W']==at[2]['power']['ups_output_W']==100 and math.isclose(actual['ups_output_energy_J'],140,abs_tol=1e-9,rel_tol=0))
support=set(closed[-1]['supporting_record_ids'])
check('verified closure uses exactly four real reports and no early closure',support=={'flow-transfer:0','flow-transfer:1','joint-service-transfer:0','joint-service-transfer:1'} and
      {(records[n]['observed_at_s'],records[n]['arrived_at_s']) for n in support}=={(7,7.5),(8,8.5)} and
      all(records[n]['availability']=='current' and records[n]['quality']['status']=='bounded' for n in support) and
      closed[-1]['risk_closed'] and not any(q['risk_closed'] for q in closed[:-1]))
check('independent service quantities and separate work cost',actual['demand_service_unit_s']==F(39,4) and actual['delivered_service_unit_s']==F(31,4) and
      actual['service_deficit_time_s']==actual['worker_work_person_s']==2)
for metric,value in [('demand_service_unit_s',F(39,4)),('delivered_service_unit_s',F(31,4)),('service_deficit_time_s',F(2))]:
    check('independently summed interval '+metric,math.isclose(math.fsum(r[metric] for r in bal),float(value),abs_tol=1e-9,rel_tol=0))
check('engineering, not independent trials or gain',run['research_trials']==run['model_calls']==run['training_calls']==0 and run['research_gain_claim']=='NOT_ESTABLISHED' and
      run['field_calibration']=='PENDING')
summary=dict(status='PASS',source=delivery,base=replay_src,original_data=old_data,original_execution=original_src,replay_execution=replay_src,
    checks=len(checks),check_failures=0,findings=0,unresolved=0,original_capture_files=14,original_launch_files=7,replay_capture_files=18,replay_launch_files=7,
    exact_exports=len(pins['exports']),runtime_files=67,combined_formal_engineering_seconds=20,original_outer_status='FAIL',replay_outer_status='PASS',
    trace_points_per_case=1016,balance_rows_per_case=1015,project_calls=0,selector_calls=0,simulation_calls=0,test_calls=0,full_calls=0,research_trials=0,
    scope='FIXED ORIGINAL AND REPLAY SAVED EVIDENCE ONLY, NOT FULL ROOT ACCEPTANCE')
(ROOT/'checks.json').write_text(json.dumps(dict(summary=summary,checks=checks),indent=2)+'\n',encoding='utf-8')
print(json.dumps(summary))
