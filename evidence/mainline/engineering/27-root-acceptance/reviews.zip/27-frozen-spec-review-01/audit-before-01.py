"""Review the fixed 9e -> 3ea -> 36ae freeze chain without loading project code."""
import ast
from copy import deepcopy
from fractions import Fraction as F
from hashlib import sha256
import json
import math
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parent
REPO = Path(r'C:\Users\Donson\.codex\worktrees\mainline27-full-loop\Renly')
PACKAGE = 'evidence/mainline/engineering/27-full-loop'
V1_INPUT = PACKAGE + '/reference/online-loop-v1.json'
V2_INPUT = PACKAGE + '/reference/online-loop-v2.json'
V1_PROTOCOL = 'docs/mainline/27-loop-engineering-protocol.json'
V2_PROTOCOL = 'docs/mainline/27-loop-engineering-protocol-v2.json'
TOOL = 'scripts/full_loop_delivery.py'
V1 = ROOT
V2 = ROOT / 'revision-02'
V3 = ROOT / 'revision-03'
checks = []


def check(name, okay, detail=None):
    checks.append(dict(name=name, passed=bool(okay), detail=detail))
    assert okay, name


def load(path):
    return json.loads(path.read_bytes())


def export(folder, name):
    return folder / 'export' / name


def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO)


def node(path, name):
    tree = ast.parse(path.read_bytes())
    return next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == name)


def digest(raw):
    return sha256(raw).hexdigest()


def deltas(a, b, path=()):
    if type(a) is dict and type(b) is dict and a.keys() == b.keys():
        return [d for key in a for d in deltas(a[key], b[key], (*path, key))]
    if type(a) is list and type(b) is list and len(a) == len(b):
        return [d for i, (x, y) in enumerate(zip(a, b)) for d in deltas(x, y, (*path, i))]
    return [] if a == b else [path]


def pin(folder):
    pins = load(folder / 'source-pins.json')
    for name, identity in pins['exports'].items():
        raw = export(folder, name).read_bytes()
        check('fixed exact Git blob ' + name, raw == git('cat-file', 'blob', pins['source'] + ':' + name) and
              digest(raw) == identity['sha256'] and len(raw) == identity['bytes'])
    check('no runtime or config delta', git('diff', '--name-only', pins['base'], pins['source'], '--', 'src', 'configs') == b'')
    return pins


def save(folder, pins, status, findings, **details):
    summary = dict(status=status, source=pins['source'], base=pins['base'], checks=len(checks), check_failures=0,
                   findings=len(findings), unresolved=findings, project_calls=0, selector_calls=0, simulation_calls=0,
                   assessment_calls=0, test_calls=0, full_calls=0, research_trials=0, **details)
    (folder / 'checks.json').write_text(json.dumps(dict(summary=summary, checks=checks), indent=2) + '\n', encoding='utf-8')
    print(json.dumps(summary))
    checks.clear()


p1 = pin(V1)
for name, expected in load(ROOT / 'prior-sealed-hashes.json').items():
    check('prior accepted review artifact preserved ' + name, digest((ROOT.parent / name).read_bytes()) == expected)
original = load(export(V1, V1_INPUT));protocol = load(export(V1, V1_PROTOCOL))
literal = load(export(V1, PACKAGE + '/reference/independent-literals-v1.json'))
dispatch = original['replay_inputs']['dispatch_program'];belief = dispatch['policy_program']['options']['belief_model']
closure = dispatch['closure_program'];model = original['model'];parameters = {r['id']: r for r in model['parameters']}
check('one eight-domain four-relation synthetic V6', len(model['domains']) == 8 and set(model['graphs']) ==
      {'physical','functional','control_information','access'} and model['runtime']['model'] == 'aegisdc-low-order-facility-reserve-v4')
check('identical template source hashes', all(digest(export(V1, name).read_bytes()) == h for name, h in original['source_inputs'].items()))
check('exact pinned property table identity', digest(export(V1, model['runtime']['property_table']).read_bytes()) == model['runtime']['property_sha256'])
check('frozen V2 replay input only actual dispatch, no manual action side channel', original['replay_inputs']['schema'] == 'aegisdc-facility-replay-inputs-v2' and
      original['replay_inputs']['work_requests'] == original['replay_inputs']['action_commands'] == [])
events = original['replay_inputs']['exogenous_events']
check('five external requests as declared', [(r['time_s'],r['parameter_id'],r['value']) for r in events] ==
      [(.5,'service_demand',1),(1,'ups_in_service',0),(1.5,'filter_resistance_multiplier',4),(2,'grid_capacity',0),(3.4,'grid_capacity',10000000)])
check('all events satisfy their declared parameter ranges', all(parameters[r['parameter_id']]['valid_range'][0] <= r['value'] <=
      parameters[r['parameter_id']]['valid_range'][1] for r in events))
check('no double scaling of offered demand power', parameters['compute_demand_power']['value'] == 2000000 and parameters['service_demand']['value'] == .5 and
      F(parameters['compute_demand_power']['value']) * F(1,2) == 1000000)
check('maintenance and local controller conditions remain explicit', parameters['control_sample_time']['value'] == 1 and
      parameters['diesel_start_time']['value'] == 30 and parameters['pump_min_speed']['value'] == 1)
check('full original and exact replay bounded by20s', protocol['cases'] == ['original','replay'] and protocol['attempt_budget'] == 2 and
      protocol['simulated_duration_budget_s'] == 2 * protocol['duration_s_per_case'] == 20 and protocol['registered_effect_trials'] == 0)
check('eight exact dispatch instants each case', dispatch['decision_times_s'] == protocol['decisions_s'] == [1,3,4.5,4.75,6,6.5,7.5,8.5])
order = dispatch['evidence_ledger']['records'][0]
check('work order observes1.5 arrives3 and stays current', (order['observed_at_s'],order['arrived_at_s'],order['valid_until_s']) == (1.5,3,10) and order['value'] is True)
check('only designated independence pair, no fixed power belief factor', belief['independent_pairs'] == [['lake-work-order','lookahead-flow-channel']] and
      [c['source_id'] for c in belief['channels']] == ['lake-work-order-source','portable-intake-meter'])
check('all belief prior variants equal the finite law', all([F(str(v)) for v in x['prior']] == [F(74,100),F(1,100),F(1,8),F(1,8)] for x in belief['variants']))
p = F(1,100);p = p*F(3,4)/(p*F(3,4)+(1-p)*F(3,100));m=p*F(4,5)+(1-p)*F(1,10);pp=p*F(4,5)/m;pn=p*F(1,5)/(1-m)
independent = dict(bad_after_arrived_work_order=p, positive_report_mass=m, positive_bad=pp, negative_bad=pn,
                   defer_deficit_s=6*p, direct_deficit_s=1+p/4,
                   inspect_deficit_s=m*min(6*pp,1+2*pp)+(1-m)*min(6*pn,1+2*pn))
for name, value in independent.items():
    check('independent probability or value ' + name, F(*literal['public_model'][name]) == value)
check('positive branch chooses work, negative defers', pp > F(1,4) > pn and independent['inspect_deficit_s'] < independent['direct_deficit_s'] < independent['defer_deficit_s'])
check('conditional service difference stays2 seconds', F(*literal['physical']['offered_demand_integral']) == F(1,4)+F(19,2) == F(39,4) and
      F(*literal['physical']['delivered_integral']) == F(1,4)+F(3,2)+6 == F(31,4))
check('filter hydraulic and mass flow oracle', F(150000,12000000*4+3000000) == F(*literal['physical']['degraded_flow_squared']) and
      F(150000,12000000+3000000) == F(*literal['physical']['clean_flow_squared']) and F(998,10) == F(*literal['physical']['clean_mass_flow_kg_s']))
profile = dispatch['sensor_program']['profile'];times = {m['id']:(m['phase_s'],m['period_s']) for m in profile['measurements']}
check('power and recovery instruments stay scheduled', times == {'rectifier-meter':(0,10),'lake-flow':(7,1),'joint-service-meter':(7,1)} and
      all(m['enabled'] for m in profile['measurements']))
check('no other forecast background report from3 to4.75', min(t+period+.5 if t==0 else t+.5 for t,period in times.values()) == 7.5)
check('two genuine post-action condition/service samples', closure['profile']['rules'][0]['required_samples'] == 2 and
      closure['profile']['rules'][0]['minimum_span_s'] == 1 and {c['role'] for c in closure['profile']['rules'][0]['checks']} == {'condition','service'} and
      closure['intervention_feedback'] == [])
check('handheld/action release times and actual records', dispatch['inspection_program']['profile']['bindings'][0]['arrival_latency_s'] == .5 and
      dispatch['workforce_profile']['feedback_latency_s'] == .5 and dispatch['intervention_program']['profile']['feedback_latency_s'] == .5)
check('authorized, paid operations' , dispatch['policy_program']['resource_budget']['cost'] == 2 and
      sum(c['issue_cost'] for c in dispatch['policy_program']['candidates']) == 2 and
      dispatch['intervention_program']['profile']['authorizations'][0]['starts_at_s'] <= 4.75 < 6 <
      dispatch['intervention_program']['profile']['authorizations'][0]['expires_at_s'])
point = 3.25
for _ in range(15):
    point += .01
ulps = (3.4-point)/math.ulp(3.4)
check('original exact clock lookup fails on legal seven-ULP coordinate', point == 3.399999999999997 and ulps == 7 and point != 3.4 and
      'at[3.4]' in export(V1, TOOL).read_text(), dict(requested=3.4, legal_applied=point, delta_ulps=ulps))
check('original provenance text refers to excluded channels', 'coolant alarm and rectifier-meter' in belief['independence_basis'] and
      'coolant alarm and rectifier-meter' in closure['belief_model']['independence_basis'])
save(V1, p1, 'CHANGES_REQUESTED', ['27-FROZEN-SPEC-01','27-FROZEN-SPEC-02'],
     scope='Original unexecuted 9e protocol; two pre-capture findings.', exact_exports=len(p1['exports']))

p2 = pin(V2)
corrected = load(export(V2,V2_INPUT));next_protocol=load(export(V2,V2_PROTOCOL))
prefix=('replay_inputs','dispatch_program')
check('only two independence basis text changes in V2 input', set(deltas(original, corrected)) == {
      prefix+('policy_program','options','belief_model','independence_basis'),prefix+('closure_program','belief_model','independence_basis')})
new_dispatch=corrected['replay_inputs']['dispatch_program']
for model in [new_dispatch['policy_program']['options']['belief_model'],new_dispatch['closure_program']['belief_model']]:
    check('correct synthetic pair provenance stated', 'delayed work-order report and later handheld flow' in model['independence_basis'] and
          'not established for the site' in model['independence_basis'] and 'fixed power record is not a factor' in model['independence_basis'])
normalize=deepcopy(next_protocol)
for name in ['schema','input','output']:
    normalize[name]=protocol[name]
normalize.pop('supersedes_unexecuted_protocol');normalize.pop('retained_protocol_inputs')
normalize['contracts'].remove('docs/mainline/27-pre-capture-review-correction.md')
check('V2 frozen protocol changes only identity and correction pins', normalize==protocol and next_protocol['output'].endswith('capture-20261107-02'))
check('original input/protocol unchanged', all(git('cat-file','blob',p2['source']+':'+name)==export(V1,name).read_bytes() for name in [V1_INPUT,V1_PROTOCOL]))
fix=node(export(V2,TOOL),'check_case');body=ast.unparse(fix)
check('bind saved real epochs to requests and track restore separately', 'epochs = external_epochs' in body and "mains_at = epochs['grid_capacity', 3.4]" in body and
      'mains_at < recovery[0]' in body and "at[mains_at]['control_monitoring']['compute_permitted']" in body and 'at[3.4]' not in body)
check('eight ULP scoped only to physical timestamps', '8 * max(math.ulp(actual), math.ulp(requested))' in ast.unparse(node(export(V2,TOOL),'coincident_time')))
check('closure support and posterior coverage strengthened', 'len(closure_checks) == 2' in body and "set(closures[-1]['supporting_record_ids']) == all_support" in body and
      'set(worlds) ==' in body)
check('3ea poll loop overwrites dict used by return', any(isinstance(n,ast.For) and ast.unparse(n.target)=='(instrument, epochs)' for n in ast.walk(fix)) and
      'for (parameter, requested), applied in epochs.items()' in body)
save(V2,p2,'CHANGES_REQUESTED',['27-FROZEN-STANDARDS-EPOCHS'],resolves=['27-FROZEN-SPEC-01','27-FROZEN-SPEC-02'],
     scope='3ea pre-capture correction; further shadowing defect first reported by Standards.')

p3 = pin(V3)
tool3=export(V3,TOOL);fn=node(tool3,'check_case');text=ast.unparse(fn)
stored=[n for n in ast.walk(fn) if isinstance(n,ast.Name) and isinstance(n.ctx,ast.Store) and n.id=='epochs']
check('corrected code retains external dict binding through return', len(stored)==1 and 'for (parameter, requested), applied in epochs.items()' in text and
      any(isinstance(n,ast.For) and ast.unparse(n.target)=='(instrument, poll_epochs)' for n in ast.walk(fn)))
old=export(V2,TOOL).read_text();new=tool3.read_text()
check('only intended poll variable binding/use changes', new==old.replace('for instrument, epochs in','for instrument, poll_epochs in').replace('== epochs, \'Declared sparse','== poll_epochs, \'Declared sparse'))
check('latest preserves both freeze inputs and both protocol bytes', all(git('cat-file','blob',p3['source']+':'+name)==export(folder,name).read_bytes()
      for folder,name in [(V1,V1_INPUT),(V1,V1_PROTOCOL),(V2,V2_INPUT),(V2,V2_PROTOCOL)]))
check('runtime identical to replay development pin', git('diff','--name-only',p1['base'],p3['source'],'--','src')==b'')
cap=node(tool3,'capture');verify=node(tool3,'verify');compare=node(tool3,'compare')
check('exact unchanged whole-run comparison except explicit wall clock', ast.dump(compare,include_attributes=False)==ast.dump(node(export(V1,TOOL),'compare'),include_attributes=False) and
      "row.pop('elapsed_ns')" in ast.unparse(compare))
check('fresh verify contains no call to project execution', not any(isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id in
      {'capture','run_recorded','replay_attempt','simulate_scenario','choose_work'} for n in ast.walk(verify)))
check('original validation happens before second attempt', ast.unparse(cap).index('checks[case] = check_case') < ast.unparse(cap).index("status='COMPLETED'"))
check('same two bounded call sites', sum(isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id in {'run_recorded','replay_attempt'} for n in ast.walk(cap))==2)
save(V3,p3,'PASS_PRE_CAPTURE_STATIC_SCOPE',[],resolves=['27-FROZEN-SPEC-01','27-FROZEN-SPEC-02','27-FROZEN-STANDARDS-EPOCHS'],
     scope='Final pre-capture static pin, conditional physical state still requires frozen execution.', planned_attempts=2, planned_duration_s=20)
