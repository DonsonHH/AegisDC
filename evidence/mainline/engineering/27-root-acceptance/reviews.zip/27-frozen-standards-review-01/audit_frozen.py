"""Fixed ticket27 frozen protocol Standards reviews; Git/JSON/AST only."""
import ast
from fractions import Fraction as F
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys

WORK=Path(__file__).resolve().parents[1]
REPO=Path('C:/Users/Donson/.codex/worktrees/mainline27-full-loop/Renly')
E81='e81cf750d6ddaae6e01752be769a690b940488f1'
ORIGINAL='9e4809aac0aebcaae904cb8b7aecc65fcc60bbd7'
REVISION='3ea1f516cf71479d96e3665899c291452bb1a387'
FINAL='36ae97cc17e4b9297017289e285d00abaee29929'
MODES={'original':(E81,ORIGINAL,'01'),'revision':(ORIGINAL,REVISION,'02'),'final':(REVISION,FINAL,'03')}
MODE=sys.argv[1];BASE,SOURCE,NUMBER=MODES[MODE]
OUT=WORK/('27-frozen-standards-review-'+NUMBER)
PREFIX='evidence/mainline/engineering/27-full-loop/'
PROTOCOL1='docs/mainline/27-loop-engineering-protocol.json'
PROTOCOL2='docs/mainline/27-loop-engineering-protocol-v2.json'
CORRECTION='docs/mainline/27-pre-capture-review-correction.md'
TOOL='scripts/full_loop_delivery.py'
PREP='scripts/prepare_full_loop_inputs.py'
HELPER='scripts/inspection_delivery.py'
DEV1='scripts/full_loop_development.py'
DEV2='scripts/full_loop_development_v2.py'
AGENTS='AGENTS.md'
V1=MODE=='original'
PROTOCOL=PROTOCOL1 if V1 else PROTOCOL2
checks=[]
def check(name,ok):
    checks.append(dict(name=name,passed=bool(ok)))
    if not ok:raise AssertionError(name)
def git(*args):return subprocess.check_output(['git',*args],cwd=REPO)
def digest(raw):return sha256(raw).hexdigest()
def write(name,raw):
    p=OUT/name;p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('xb') as stream:stream.write(raw)
def jwrite(name,value):write(name,(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode())
def tree(rev,*paths):
    return {row.split('\t',1)[1]:row.split()[2] for row in git('ls-tree','-r',rev,'--',*paths).decode().splitlines()}
def blobs(keys):
    keys=sorted(set(keys));raw=subprocess.check_output(['git','cat-file','--batch'],cwd=REPO,input=''.join(k+'\n' for k in keys).encode());offset=0;result={};ids={}
    for key in keys:
        end=raw.index(b'\n',offset);header=raw[offset:end].split();assert len(header)==3 and header[1]==b'blob',key
        start=end+1;size=int(header[2]);result[key]=raw[start:start+size];ids[key]=header[0].decode();offset=start+size+1
    check('complete fixed Git batch '+str(len(keys)),offset==len(raw));return result,ids
def top_functions(source):return {n.name:n for n in ast.parse(source).body if isinstance(n,ast.FunctionDef)}
def differing(a,b,path=()):
    if isinstance(a,dict) and isinstance(b,dict) and a.keys()==b.keys():
        return [p for k in a for p in differing(a[k],b[k],path+(k,))]
    if isinstance(a,list) and isinstance(b,list) and len(a)==len(b):
        return [p for i,(x,y) in enumerate(zip(a,b)) for p in differing(x,y,path+(str(i),))]
    return [] if a==b else [path]
def line(raw,token):return next(i for i,s in enumerate(raw.splitlines(),1) if token in s)

prior_dirs=['26-projection-standards-review-01','26-online-standards-review-01','27-contract-standards-review-01','27-service-standards-review-01','27-replay-standards-review-01']
if not V1:prior_dirs+=['27-frozen-standards-review-01']
if MODE=='final':prior_dirs+=['27-frozen-standards-review-02']
def prior_hashes():return {p.relative_to(WORK).as_posix():digest(p.read_bytes()) for name in prior_dirs for p in sorted((WORK/name).rglob('*')) if p.is_file()}
before=prior_hashes();jwrite('prior-reviews-before.json',before)
check('exact fixed merge base',git('merge-base',BASE,SOURCE).decode().strip()==BASE)
diff=git('diff',BASE+'...'+SOURCE);check('nonempty fixed diff',bool(diff));write('candidate.diff',diff)
write('commits.txt',git('log','--format=%H %s',BASE+'..'+SOURCE))
changed=git('diff','--name-only',BASE+'...'+SOURCE).decode().splitlines()
fixed=tree(SOURCE);e81=tree(E81);base=tree(BASE)
check('runtime src unchanged from e81',tree(E81,'src')==tree(SOURCE,'src'))
check('old service/replay original packages untouched',{n:h for n,h in e81.items() if n.startswith(PREFIX+'development')}=={n:h for n,h in fixed.items() if n.startswith(PREFIX+'development')})
check('old helper and v2 verifier exact e81 blobs',fixed[DEV1]==e81[DEV1] and fixed[DEV2]==e81[DEV2])
check('no separate coding standards or contributing document',not any(Path(n).name.upper() in {'CODING_STANDARDS.MD','CONTRIBUTING.MD'} for n in fixed))
standards=[AGENTS,'GLOSSARY.md','docs/MAINLINE.md','docs/agents/domain.md','docs/agents/issue-tracker.md','docs/adr/0003-complete-facility-mainline.md','.scratch/full-facility-mainline/spec.md']
for name in standards:check('fixed standards unchanged '+name,fixed[name]==e81[name])
initial,_=blobs([SOURCE+':'+PROTOCOL,SOURCE+':'+PROTOCOL1])
protocol=json.loads(initial[SOURCE+':'+PROTOCOL]);original_protocol=json.loads(initial[SOURCE+':'+PROTOCOL1]);input_name=protocol['input'];input1_name=original_protocol['input']
input_blobs,_=blobs([SOURCE+':'+input_name,SOURCE+':'+input1_name])
doc=json.loads(input_blobs[SOURCE+':'+input_name]);doc1=json.loads(input_blobs[SOURCE+':'+input1_name])
roles=dict(runtime=sorted(n for n in fixed if n.startswith('src/') and n.endswith('.py')),
    tools=protocol['tools'],inputs=sorted(set([PROTOCOL,input_name,protocol['independent_literals'],*protocol['contracts'],*protocol.get('retained_protocol_inputs',[]),
        *doc['source_inputs'],doc['model']['runtime']['property_table']])),development_originals=sorted(n for n in fixed if n.startswith(PREFIX+'development') and '__pycache__' not in n and not n.endswith(('.pyc','.pyo'))))
related=['src/aegis_dc/'+n+'.py' for n in ('plant','time_coordinates','replay','verified_closure','local_control','belief','workforce_dispatch','sensor_channels')]
critical=sorted(set(changed+standards+related+roles['tools']+roles['inputs']+[PREFIX+'development-service-20261107-02/receipt.json']))
requested=[SOURCE+':'+name for name in set(critical).union(*(set(group) for group in roles.values()))]+[BASE+':'+name for name in changed if name in base]
raw,ids=blobs(requested)
def source(name):return raw[SOURCE+':'+name].decode('utf-8')
exports={}
for name in critical:
    k=SOURCE+':'+name;write('export/'+name,raw[k]);exports[name]=dict(git_blob=ids[k],sha256=digest(raw[k]),bytes=len(raw[k]))
    if name.endswith('.py'):ast.parse(source(name),filename=name);check('AST parse '+name,True)
for name in changed:
    if name in base:write('base-export/'+name,raw[BASE+':'+name])
if MODE!='original':write('review-tool.py',Path(__file__).read_bytes())
role_hashes={role:{n:digest(raw[SOURCE+':'+n]) for n in names} for role,names in roles.items()}
jwrite('source-manifest.json',dict(base=BASE,source=SOURCE,changed_files=changed,files=exports,standards=standards,role_sha256=role_hashes,new_project_calls=0))
check('exact67 runtime paths and 36 executed submodule paths',len(roles['runtime'])==67 and sum(n.startswith('src/aegis_dc/') or n=='src/patrol_rsi/contracts.py' for n in roles['runtime'])==36)
check('all six authoring/verifier tools pinned',set(roles['tools'])=={TOOL,PREP,HELPER,'scripts/prepare_full_loop_oracles.py',DEV1,DEV2})
for name,sha in doc['source_inputs'].items():check('source template hash matches committed '+name,role_hashes['inputs'][name]==sha)
check('old service receipt binds replay verifier transitive helper',role_hashes['tools'][DEV1]==json.loads(source(PREFIX+'development-service-20261107-02/receipt.json'))['tool_sha256'])
check('old replay verifier dual pin closes prior P2 at full delivery',DEV1 in roles['tools'] and DEV2 in roles['tools'])
check('2 unique 10s cases exact 20s/0.01 budget',protocol['cases']==['original','replay'] and protocol['attempt_budget']==2 and protocol['simulated_duration_budget_s']==2*protocol['duration_s_per_case']==20 and doc['duration_s']==10 and protocol['maximum_step_s']==doc['maximum_step_s']==.01)
check('8 exact decisions per case, 16 online total',len(protocol['decisions_s'])==len(protocol['choices'])==len(protocol['closure_states'])==protocol['scheduled_online_decisions_per_case']==8 and protocol['decisions_s']==doc['replay_inputs']['dispatch_program']['decision_times_s'])
check('durable roles22case+3origin+3root plus separate receipt',len(protocol['durable_case'])==11 and len(protocol['durable_replay_extra'])==3 and len(protocol['durable_root'])==3 and protocol['terminal']=='receipt.json')
durables=set(protocol['durable_root'])|{case+'/'+name for case in protocol['cases'] for name in protocol['durable_case']}|{'replay/'+n for n in protocol['durable_replay_extra']}
check('28 output artifacts exactly unique and no caches',len(durables)==28 and 'receipt.json' not in durables and all('__pycache__' not in n and not n.endswith(('.pyc','.pyo')) for n in durables))
check('no captured files at any frozen protocol commit',not any(n.startswith((protocol['output']+'/',original_protocol['output']+'/')) for n in fixed))
check('stop and preserve no automatic retry','Stop on any failure, retain original failures, do not automatically retry' in protocol['failure_rule'])
check('unregistered engineering classification preserved',protocol['registered_effect_trials']==0 and protocol['field_calibration']=='PENDING' and 'NOT_EFFECT_COMPARISON' in protocol['classification'])
replay=doc['replay_inputs'];dispatch=replay['dispatch_program'];p={row['id']:row['value'] for row in doc['model']['parameters']}
check('closed recorded v2 and distinct internal work',replay['schema']=='aegisdc-facility-replay-inputs-v2' and replay['work_requests']==replay['action_commands']==[])
check('same complete facility graphs/domains',len(doc['model']['domains'])==8 and set(doc['model']['graphs'])=={'physical','functional','control_information','access'})
check('no double demand scaling in new witness',p['compute_demand_power']==2_000_000 and p['service_demand']==.5 and p['network_service_capacity']==p['storage_service_capacity']==1)
check('external input classes and requested literal coordinates',[(r['parameter_id'],r['time_s'],r['value']) for r in replay['exogenous_events']]==[('service_demand',.5,1),('ups_in_service',1,0),('filter_resistance_multiplier',1.5,4),('grid_capacity',2,0),('grid_capacity',3.4,10000000)])
check('local controls and power not bypassed',p['pump_min_speed']==1 and p['diesel_start_time']==30 and protocol['closure_states'][-1]=='VERIFIED_CLOSED')
policy=dispatch['policy_program'];belief=policy['options']['belief_model'];projection=policy['evidence_projection'];profile=dispatch['sensor_program']['profile']
check('identical public executor profile declarations',projection['background_sensor_profile']==profile and projection['inspection_profile']==dispatch['inspection_program']['profile'])
check('work order and actual handheld only finite condition pair',belief['independent_pairs']==[['lake-work-order','lookahead-flow-channel']] and {r['id'] for r in belief['channels']}=={'lake-work-order','lookahead-flow-channel'})
measurements={r['id']:r for r in profile['measurements']};channels={r['measurement_id']:r for r in profile['channels']}
check('fixed power retained, no artificially silenced evidence',measurements['rectifier-meter']['enabled'] and measurements['rectifier-meter']['period_s']==10 and measurements['rectifier-meter']['phase_s']==0)
for name in ('lake-flow','joint-service-meter'):
    check('fixed recovery clock and delay '+name,measurements[name]['enabled'] and measurements[name]['phase_s']==7 and measurements[name]['period_s']==1 and channels[name]['delay_s']==.5 and channels[name]['validity_s']==3)
check('service normalized actual delivery sensor',measurements['joint-service-meter']['signal']=='joint_service_delivered' and channels['joint-service-meter']['transform']=='identity')
rule=dispatch['closure_program']['profile']['rules'][0]
check('exact closure rule two samples one second and two roles',rule['required_samples']==2 and rule['minimum_span_s']==1 and {(r['id'],r['role']) for r in rule['checks']}=={('flow-restored','condition'),('service-restored','service')})
check('closure rule uses actual separate flow and service sources',{r['role']:r['source_ids'] for r in rule['checks']}=={'condition':['intake-flow-record'],'service':['joint-service-record']})
check('closure feedback empty until actual execution',dispatch['closure_program']['intervention_feedback']==[])
literal=json.loads(source(protocol['independent_literals']));phys=literal['physical'];pub=literal['public_model']
check('independent service integrals conditional unchanged',F(1,4)+F(19,2)==F(*phys['offered_demand_integral'])==F(39,4) and F(39,4)-2==F(*phys['delivered_integral'])==F(31,4) and F(*phys['normalized_deficit_time_s'])==2)
check('independent hydraulic law unchanged',F(150000,12000000+3000000)==F(*phys['clean_flow_squared']) and F(150000,48000000+3000000)==F(*phys['degraded_flow_squared']))
odds=F(1,99)*F(3,4)/F(3,100);check('independent exact posterior',odds/(1+odds)==F(*pub['bad_after_arrived_work_order'])==F(25,124))
if not V1:
    check('old protocol and input blobs unchanged',tree(ORIGINAL,PROTOCOL1,input1_name)==tree(SOURCE,PROTOCOL1,input1_name))
    check('exact retained protocol and input in new role pins',protocol['retained_protocol_inputs']==[PROTOCOL1,input1_name] and {PROTOCOL1,input1_name}<=set(roles['inputs']))
    expected_doc={('replay_inputs','dispatch_program','policy_program','options','belief_model','independence_basis'),('replay_inputs','dispatch_program','closure_program','belief_model','independence_basis')}
    check('two explanatory strings only; physical values and rules not touched',set(differing(doc1,doc))==expected_doc)
    check('only revision protocol metadata changes',{p[0] for p in differing({k:v for k,v in original_protocol.items() if k not in {'schema','input','output','contracts'}},{k:v for k,v in protocol.items() if k not in {'schema','input','output','contracts','supersedes_unexecuted_protocol','retained_protocol_inputs'}})}==set())
    check('new explicit unique frozen output',protocol['output']==PREFIX+'capture-20261107-02' and protocol['supersedes_unexecuted_protocol']==PROTOCOL1)

tool=source(TOOL);helper=source(HELPER);functions=top_functions(tool);helper_functions=top_functions(helper)
case=ast.get_source_segment(tool,functions['check_case']);capture=ast.get_source_segment(tool,functions['capture']);verify=ast.get_source_segment(tool,functions['verify']);compare=ast.get_source_segment(tool,functions['compare'])
check('pre-call original requires clean committed exact source and isolated cache',"not git('status', '--porcelain')" in capture and 'sys.dont_write_bytecode' in capture and 'not Path(sys.pycache_prefix).exists()' in capture and 'unchanged(source, identity)' in capture)
check('no reuse formal output directory','folder.mkdir(exist_ok=False)' in capture)
check('fsynced STARTED before both calls',capture.index("status='STARTED'")<capture.index('result = run_recorded(')<capture.index('result = replay_attempt(') and 'os.fsync(stream.fileno())' in tool)
check('save and validate original before advancing next call',capture.index('checks[case] = check_case(')<capture.index("status='COMPLETED'"))
check('failure journals and stops rather than retries',"status='FAILED'" in capture and 'raise' in capture and capture.count('result = run_recorded(')==capture.count('result = replay_attempt(')==1)
check('terminal source guard missing files/Git exception fail closed',"except (OSError, subprocess.SubprocessError) as error:" in capture and "receipt.update(source_guard=False, source_guard_error=str(error))" in capture and "write(folder / protocol['terminal'], receipt)" in capture)
check('fresh verify exact clean artifact and original source pins',"not git('status', '--porcelain')" in verify and 'hashes(delivery,' in verify and "receipt['pins'] == pins(protocol, source)" in verify and 'Delivery pin bytes differ' in verify)
check('exact output role receipt no arbitrary durable skip',"durable(folder) == declared(protocol) | {protocol['terminal']}" in verify and "set(receipt['artifacts']) == declared(protocol)" in verify)
check('only named elapsed diagnostic removal',compare.count('.pop(')==1 and "row.pop('elapsed_ns')" in compare and 'json.dumps(original, sort_keys=True, allow_nan=False)' in compare)
check('replay exact original scenario, trace, balance, and origin bytes',all(n in compare for n in ('private-state.jsonl','balances.jsonl','scenario.json','EXACT_REEXECUTION','origin')))
check('fixed service and old replay helper hashed and fresh blobs',"result['tools']['scripts/full_loop_development.py'] == service['tool_sha256']" in tool and "tools=protocol['tools']" in tool and 'names == hashes(delivery, names)' in verify)
all_functions={**helper_functions,**functions};pending=['verify'];reachable=set()
while pending:
    name=pending.pop()
    if name in reachable:continue
    reachable.add(name);node=all_functions[name]
    check('saved-only reachable no app import '+name,not any((getattr(n,'module','') or '').startswith(('aegis_dc','patrol_rsi')) or any(a.name.startswith(('aegis_dc','patrol_rsi')) for a in getattr(n,'names',[])) for n in ast.walk(node) if isinstance(n,(ast.Import,ast.ImportFrom))))
    for call in ast.walk(node):
        if isinstance(call,ast.Call) and isinstance(call.func,ast.Name) and call.func.id in all_functions and call.func.id not in reachable:pending.append(call.func.id)
check('saved mode capture/app not reachable','capture' not in reachable and 'snapshots' not in reachable)
check('input prep no app or external calls',not any(t in source(PREP) for t in ('simulate_scenario(','choose_work(','from aegis_dc','subprocess')))
check('service physical recovery and separate manual actuator checks',all(t in case for t in ("'compute_permitted'","'filter_resistance_multiplier', 6, 4, 1","'arrived_at_s'] == 6.5",'whole_run_energy_residual_J','max_mass_residual_kg')))
check('delay and actual recovery values unchanged',"[(7, 7.5), (8, 8.5)]" in case and "('intake-flow-record', 99.8" in case and "('joint-service-record', 1" in case and 'Future measurement entered the decision frame' in case)

def finding(identifier,token,detail,fix):
    return dict(id=identifier,priority=2,file=TOOL,line=line(tool,token),detail=detail,remediation=fix,standard='AGENTS.md:33 and frozen independent evidence validation; preserve execution, inputs, roles and exact original sources.',new_project_calls=0)
findings=[];resolved=[]
if V1:
    check('old closure all empty case witnessed',"for check in closures[-1]['checks']" in case and 'closure_checks =' not in case)
    check('old exact posterior mapping empty case witnessed',"for world in first['valuation_current_outcome_mass_by_belief_variant'].values()" in case)
    check('old runtime set was subset only witnessed',"all(identity['runtime'][n] == sha for n, sha in code['files'].items())" in case)
    check('old request and per STARTED duration gap witnessed',"read(case / 'request.json')" not in case and "row['duration_s']" not in verify)
    findings=[finding('STD-27-FREEZE-CLOSURE-01',"require(all(check['passed']",'Empty final closure checks passed vacuously; support IDs were not tied to the four bounded actual records.','Require two exact (check_id, role) pairs, bind each role to two actual IDs and the union to all four.'),
        finding('STD-27-FREEZE-VARIANTS-02',"require(all(world['cooling-limited']",'An empty outcome-mass map passed the posterior assertion.','Require exactly the declared belief variant ID set before the exact literal.'),
        finding('STD-27-FREEZE-SOURCE-03',"require(code['files']",'Two matching but incomplete runtime maps passed the subset check.','Bind both maps to the full known 36-file executed-runtime subset of the 67 source pins.'),
        finding('STD-27-FREEZE-BUDGET-04',"ledger = lines(folder / 'attempts.jsonl')",'Per-attempt STARTED duration and request/terminal/run duration-step were unbound.','Require exact 10/.01 fields and STARTED duration.')]
else:
    check('exact two closure role IDs, no vacuity',"len(closure_checks) == 2 and {(row['check_id'], row['role']) for row in closure_checks}" in case and "{('flow-restored', 'condition'), ('service-restored', 'service')}" in case)
    check('four real closure ids tied per role and combined',"set(check['supporting_record_ids']) == record_ids" in case and "set(closures[-1]['supporting_record_ids']) == all_support" in case)
    check('all declared belief variant IDs and exact25/124',"set(worlds) == {row['id'] for row in declared_belief['variants']}" in case and "world['cooling-limited'] == [25, 124]" in case)
    check('actual source files exactly full executed subset',"code['files'] == attempt['source_identity']['files'] == expected_runtime" in case and "name.startswith('src/aegis_dc/') or name == 'src/patrol_rsi/contracts.py'" in case)
    check('request attempt and run bound10/.01',"request[key] == attempt[key] == run['inputs'][key] == value" in case)
    check('STARTED recorded duration exact per case',"row['duration_s'] == protocol['duration_s_per_case'] for row in ledger if row['status'] == 'STARTED'" in verify)
    check('new strict actual feedback arrival gate','Future workforce feedback entered the decision' in case)
    clock=ast.get_source_segment(tool,functions['coincident_time']);time=source('src/aegis_dc/time_coordinates.py')
    check('original 8ULP numeric coordinate formula same','<= 8 * max(math.ulp(actual), math.ulp(requested))' in clock and '<= 8 * max(math.ulp(first), math.ulp(second))' in time)
    check('8ULP only used for requested-vs-applied event and restoration sample',tool.count('coincident_time(')==3 and 'coincident_time(applied, wanted[\'time_s\'])' in tool and 'coincident_time(time, 4)' in case)
    check('applied real epochs pinned to trace and exact local sample',"set(epochs.values()) <= set(at)" in case and "['sampled_at_s'] == time" in case and "mains_at < recovery[0]" in case)
    check('actual physical piecewise values stay exact',"domains['it_service']['demand'] == demand and domains['it_service']['delivered'] == delivered" in case and 'not at[mains_at]' in case)
    check('unchanged earlier physical tolerance fields',all(protocol[n]==original_protocol[n] for n in ('absolute_tolerance','energy_tolerance_J','mass_tolerance_kg')))
    resolved=['STD-27-FREEZE-CLOSURE-01','STD-27-FREEZE-VARIANTS-02','STD-27-FREEZE-SOURCE-03','STD-27-FREEZE-BUDGET-04']
    loop_names=[n.id for node in ast.walk(functions['check_case']) if isinstance(node,ast.For) for n in ast.walk(node.target) if isinstance(n,ast.Name)]
    if MODE=='revision':
        check('definite Python local shadow witnessed','epochs' in loop_names and 'epochs = external_epochs(' in case and 'epochs.items()' in case)
        findings=[finding('STD-27-FREEZE-CLOCK-SHADOW-05','for instrument, epochs in','Loop target overwrites the external epoch map with a list; the saved summary always calls .items() on that list after otherwise passing checks.','Use a distinct poll_epochs loop local and retain the requested/applied map.')]
    else:
        check('external epoch map not overwritten by loop','epochs' not in loop_names and 'poll_epochs' in loop_names and 'epochs.items()' in case)
        old_tool=raw[BASE+':'+TOOL].decode('utf-8')
        check('sole final tool delta rename only',old_tool.replace('for instrument, epochs in','for instrument, poll_epochs in').replace('== epochs, \'Declared sparse instrument schedule differs\'','== poll_epochs, \'Declared sparse instrument schedule differs\'')==tool)
        check('only final tool rename plus retained explanatory note',set(changed)=={TOOL,CORRECTION} and '未运行该中间版本 `3ea1f516`' in source(CORRECTION))
        resolved.append('STD-27-FREEZE-CLOCK-SHADOW-05')
check('all previous review artifact paths and hashes intact',prior_hashes()==before);jwrite('prior-reviews-after.json',before)
dc=subprocess.run(['git','diff','--check',BASE+'...'+SOURCE],cwd=REPO,capture_output=True)
check('full diff check no skip',dc.returncode==0 and not dc.stdout and not dc.stderr)
jwrite('checks.json',checks)
if V1:
    report='''Standards：9e4809aa需修订，未执行。\n\n硬规则：full_loop_delivery.py:65、138–148、260对执行源码、双角色关闭及支持记录、后验变体和每次STARTED时长覆盖不足，须闭合声明集合及10/.01执行身份。预算2×10秒、28耐久输出＋终态、fsync与失败保留、仅elapsed_ns例外、旧helper双pin均核。\n\n启发性异味无单列。无项目调用；保留原协议与输入，不能视为正式结果。\n'''
elif MODE=='revision':
    report='''Standards：3ea1f516需修订，未执行。\n\n硬规则：此前关闭四记录、后验变体、36运行源与10/.01预算缺口已修。8ULP只识别实际外生事件与当地样本时钟，物理与到时规则未放宽。仍有阻断：full_loop_delivery.py:171的轮询局部覆盖外生epochs映射，返回摘要的items()必失败。\n\n启发性异味不另计。应在捕获前分开变量并另pin；0项目调用，旧原件未改。\n'''
else:
    report='''Standards：36ae97cc冻结工具 PASS。\n\n硬规则：两角色及四条实采记录、声明后验变体、36实际运行源码、10/.01与STARTED预算均闭合。仅8ULP匹配请求与实际时钟，物理与到时检查未放宽；外生映射不再被轮询局部覆盖。28耐久输出＋终态、旧双helper pin、保存验证不调用应用、重放仅略去elapsed_ns均核。\n\n启发性异味无。9e/3ea未执行的协议、工具与发现保留。0项目调用；本审仅支持按预算捕获，未证明实际闭环或票27接受。\n'''
assert len(report)<=400;write('report.md',report.encode('utf-8'))
review=dict(schema='aegisdc-independent-standards-review-v1',axis='Standards',status='CHANGES_REQUIRED' if findings else 'PASS',base=BASE,source=SOURCE,
    scope='Fixed pre-capture engineering protocol/input/tool static only; no new formal capture or physical feasibility claim',checks=len(checks),exports=len(exports),
    role_counts={k:len(v) for k,v in roles.items()},durable_outputs=28,terminal_receipts=1,attempt_budget=2,physical_duration_s=20,online_decisions=16,
    hard_findings=findings,heuristic_findings=[],unresolved=[f['id'] for f in findings],resolved_findings=resolved,
    declared_saved_only_functions=sorted(reachable),prior_review_files_preserved=len(before),new_project_calls=0,tests_run=0,selectors_run=0,simulation_calls=0,
    formal_capture_rerun=False,ticket_acceptance=False)
jwrite('review.json',review)
members={p.relative_to(OUT).as_posix():dict(sha256=digest(p.read_bytes()),bytes=p.stat().st_size) for p in sorted(OUT.rglob('*')) if p.is_file()}
jwrite('delivery-manifest.json',dict(schema='aegisdc-static-review-delivery-manifest-v1',source=SOURCE,artifacts=members,terminal_receipt='delivery-manifest.json',new_project_calls=0))
for name,item in members.items():assert digest((OUT/name).read_bytes())==item['sha256'] and (OUT/name).stat().st_size==item['bytes']
print(json.dumps(dict(status=review['status'],source=SOURCE,checks=len(checks),exports=len(exports),prior=len(before),members=len(members),
    report_sha256=digest((OUT/'report.md').read_bytes()),review_sha256=digest((OUT/'review.json').read_bytes()),manifest_sha256=digest((OUT/'delivery-manifest.json').read_bytes()),new_project_calls=0)))
