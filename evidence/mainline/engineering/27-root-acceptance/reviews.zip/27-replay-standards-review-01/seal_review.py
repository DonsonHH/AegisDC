"""Seal the completed saved review without executing project code."""
from hashlib import sha256
import json
from pathlib import Path

OUT=Path(__file__).resolve().parent
BASE='12aa08fc974abaf4a7f4d1a9f152bd545aa97a57'
SOURCE='e81cf750d6ddaae6e01752be769a690b940488f1'
HELPER='scripts/full_loop_development.py'
TOOL='scripts/full_loop_development_v2.py'
PREFIX='evidence/mainline/engineering/27-full-loop/'
def digest(raw):return sha256(raw).hexdigest()
def read(name):return json.loads((OUT/name).read_bytes())
def write(name,raw):
    with (OUT/name).open('xb') as stream:stream.write(raw)
def jwrite(name,v):write(name,(json.dumps(v,ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode())
def text(name):return (OUT/'export'/name).read_text(encoding='utf-8')
def line(name,token):return next(i for i,s in enumerate(text(name).splitlines(),1) if token in s)

saved=read('saved-originals.json');checks=read('checks.json');pins=read('source-manifest.json');prior=read('prior-reviews-before.json')
assert len(checks)==1213 and all(row['passed'] for row in checks)
assert prior==read('prior-reviews-after.json') and all(digest((OUT.parent/n).read_bytes())==expected for n,expected in prior.items())
assert saved['status']=='PASS' and saved['archive_members']==499 and saved['previous_service_p2_closed'] and saved['new_project_calls']==0
positions=dict(import_helper=line(TOOL,'from full_loop_development import'),replay_support=line(TOOL,"for name, identity in declaration['support'].items()"),
    seal_support=line(TOOL,"support = ['scripts/check_full_loop_replay_boundaries.py'"),
    source_rule=line('AGENTS.md','Define the durable delivery set before hashing'),
    reader_dispatch=line('src/aegis_dc/replay.py',"if ('dispatch_program' in actual_inputs)"))
finding=dict(id='STD-27-REPLAY-HELPER-01',priority=2,kind='durable_verification_tool_provenance',
    file=TOOL,lines=[positions['import_helper'],positions['replay_support'],positions['seal_support']],
    standard='AGENTS.md: '+str(positions['source_rule'])+' explicitly requires pinned authoring/verification tools and fresh committed blobs.',
    detail='Standalone replay verification imports durable, git and other behavior from the v1 helper, but the replay package does not name/hash the helper as support. A changed helper in a later clean delivery is therefore not independently refused by replay_checks. The fixed e81 helper itself exactly matches the old service receipt.',
    remediation='At the root delivery gate verify the same helper bytes against the preserved service receipt and the execution/delivery Git blobs before saved replay verification, or use a new explicit helper-pin revision. Do not edit the frozen packages.',
    blocks='Standalone verifier as complete delivery authority only; not current fixed replay or saved originals',
    preserved_service_receipt=PREFIX+'development-service-20261107-02/receipt.json',
    exact_helper_sha256=saved['retained_original_service_helper_sha256'])
report=f'''Standards：V2重放及保存原件 PASS；独立验证工具链有1项P2。\n\n硬规则：V1仍闭合；V2只接调度对象且旧work为空。读取绑定保存与冻结程序，拒绝哈希自洽但程序不同的原件。499成员、6调用（原运行与重放各1.75秒、4拒绝）核对通过；只排除elapsed_ns。旧4份V1和服务包保留，服务集合P2已关闭。\n\nP2：full_loop_development_v2.py:{positions['import_helper']}导入旧helper，独立replay核验未钉其哈希。按AGENTS:{positions['source_rule']}，根交付需以原服务receipt及Git绑定同一helper。固定e81原件无误。启发性异味无。新增项目调用0；27正式闭环及接受待完成。\n'''
assert len(report)<=400
write('report.md',report.encode('utf-8'))
review=dict(schema='aegisdc-independent-standards-review-v1',axis='Standards',status='CHANGES_REQUIRED',base=BASE,source=SOURCE,
    runtime_scope_status='PASS',saved_originals_status='PASS',scope='27 online replay inputs/reader/recorded engineering originals and development verifier dependency chain only',
    checks=len(checks),exports=len(pins['files']),preserved_prior_review_files=len(prior),archive_members=499,attempts=6,completions=2,input_refusals=4,
    original_and_replay_duration_s_each=1.75,physical_duration_s=3.5,old_v1_saved_originals=4,elapsed_ns_only_excluded=True,
    resolved_findings=['STD-27-SERVICE-PACKAGE-01'],hard_findings=[finding],heuristic_findings=[],unresolved=[finding['id']],source_positions=positions,
    new_project_calls=0,tests_run=0,selectors_run=0,assessments_run=0,inference_calls=0,simulation_calls=0,formal_capture=False,ticket_acceptance=False)
jwrite('review.json',review)
artifacts={p.relative_to(OUT).as_posix():dict(sha256=digest(p.read_bytes()),bytes=p.stat().st_size) for p in sorted(OUT.rglob('*')) if p.is_file() and '__pycache__' not in p.parts and p.suffix not in {'.pyc','.pyo'}}
jwrite('delivery-manifest.json',dict(schema='aegisdc-static-review-delivery-manifest-v1',source=SOURCE,artifacts=artifacts,terminal_receipt='delivery-manifest.json',new_project_calls=0))
for name,item in artifacts.items():assert digest((OUT/name).read_bytes())==item['sha256'] and (OUT/name).stat().st_size==item['bytes']
print(json.dumps(dict(status=review['status'],saved_originals='PASS',checks=review['checks'],prior_files=len(prior),members=len(artifacts),report_chars=len(report),
    report_sha256=digest((OUT/'report.md').read_bytes()),review_sha256=digest((OUT/'review.json').read_bytes()),manifest_sha256=digest((OUT/'delivery-manifest.json').read_bytes()),new_project_calls=0)))
