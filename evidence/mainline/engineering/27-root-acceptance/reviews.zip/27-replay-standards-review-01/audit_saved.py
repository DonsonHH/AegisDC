"""Independent fixed replay/ZIP/AST review; never import or call application code."""
import ast
from collections import Counter
from copy import deepcopy
from hashlib import sha256
import json
import math
from pathlib import Path, PurePosixPath
import subprocess
import zipfile

OUT=Path(__file__).resolve().parent
REPO=Path('C:/Users/Donson/.codex/worktrees/mainline27-full-loop/Renly')
BASE='12aa08fc974abaf4a7f4d1a9f152bd545aa97a57'
SOURCE='e81cf750d6ddaae6e01752be769a690b940488f1'
PREFIX='evidence/mainline/engineering/27-full-loop/'
PACKAGE=PREFIX+'development-replay-20261107-01/'
OLD_V1='evidence/mainline/engineering/13-replay/capture-05/'
TOOL='scripts/full_loop_development_v2.py'
HELPER='scripts/full_loop_development.py'
RUNTIME='src/aegis_dc/replay.py'
TEST='tests/test_full_loop_replay.py'
SERVICE_TEST='tests/test_full_loop_service.py'
BOUNDARY_TOOL='scripts/check_full_loop_replay_boundaries.py'
REFERENCE='evidence/mainline/engineering/25-baselines/reference/no-human.json'
PROPERTY='configs/materials/reference-r134a-saturation.json'
TICKET='.scratch/full-facility-mainline/issues/27-full-loop-demo.md'
SPEC='.scratch/full-facility-mainline/spec.md'
PRIOR=('26-projection-standards-review-01','26-online-standards-review-01','27-contract-standards-review-01','27-service-standards-review-01')
checks=[]
def check(name,ok):
    checks.append(dict(name=name,passed=bool(ok)))
    if not ok:raise AssertionError(name)
def digest(raw):return sha256(raw).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=REPO)
def write(name,raw):
    path=OUT/name;path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('xb') as stream:stream.write(raw)
def jwrite(name,value):write(name,(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode())
def snapshot():return {p.relative_to(OUT.parent).as_posix():digest(p.read_bytes()) for name in PRIOR for p in sorted((OUT.parent/name).rglob('*')) if p.is_file()}
def artifact(name):return (OUT/'export'/name).read_bytes()
def text(name):return artifact(name).decode('utf-8')
def data(name):return json.loads(artifact(name))
def safe(name):
    p=PurePosixPath(name)
    return p.as_posix()==name and not p.is_absolute() and '..' not in p.parts and '\\' not in name and ':' not in name and '__pycache__' not in p.parts and p.suffix not in {'.pyc','.pyo'}
def tree(rev,*paths):return {r.split('\t',1)[1]:r.split()[2] for r in git('ls-tree','-r',rev,'--',*paths).decode().splitlines()}
def batch_blobs(keys):
    batch=subprocess.check_output(['git','cat-file','--batch'],cwd=REPO,input=''.join(k+'\n' for k in keys).encode())
    contents={};ids={};offset=0
    for key in keys:
        end=batch.index(b'\n',offset);header=batch[offset:end].split();assert len(header)==3 and header[1]==b'blob',key
        start=end+1;size=int(header[2]);contents[key]=batch[start:start+size];ids[key]=header[0].decode();offset=start+size+1
    check('complete fixed Git batch '+str(len(keys)),offset==len(batch))
    return contents,ids

before=snapshot();jwrite('prior-reviews-before.json',before)
check('fixed base ancestry',git('merge-base',BASE,SOURCE).decode().strip()==BASE)
diff=git('diff',BASE+'...'+SOURCE);check('nonempty fixed diff',bool(diff));write('candidate.diff',diff)
write('commits.txt',git('log','--format=%H %s',BASE+'..'+SOURCE))
changed=set(git('diff','--name-only',BASE+'...'+SOURCE).decode().splitlines())
check('only replay.py changed in runtime',{n for n in changed if n.startswith('src/')}=={RUNTIME})
check('no replay CLI/format behavior change',not ({'src/aegis_dc/__main__.py','src/aegis_dc/replay_format.py'}&changed))
fixed=tree(SOURCE);base=tree(BASE)
check('no documented coding/contributing file absent',not any(PurePosixPath(n).name.upper() in {'CODING_STANDARDS.MD','CONTRIBUTING.MD'} for n in fixed))
standards=['AGENTS.md','GLOSSARY.md','docs/MAINLINE.md',SPEC,'docs/adr/0003-complete-facility-mainline.md','docs/agents/domain.md','docs/agents/issue-tracker.md','docs/agents/triage-labels.md']
v1_names=('defaults','defaults-replay','explicit','explicit-replay')
old_refs={OLD_V1+case+'/'+name for case in v1_names for name in ('attempt.json','frozen-inputs.json','trajectory/run.json')}
old_prefixes=tuple(PREFIX+n for n in ('development-service-20261107-','development-service-packaging-01/'))
old_packages={n for n in base if n.startswith(old_prefixes)}
check('all old service artifact Git blobs exact',len(old_packages)==10 and all(fixed[n]==base[n] for n in old_packages) and fixed[HELPER]==base[HELPER])
check('all original13-v1 capture Git blobs preserved',tree(BASE,OLD_V1.rstrip('/'))==tree(SOURCE,OLD_V1.rstrip('/')))
related={HELPER,SERVICE_TEST,REFERENCE,PROPERTY,'src/aegis_dc/plant.py','src/aegis_dc/policy_execution.py','src/aegis_dc/replay_format.py','docs/mainline/27-cross-system-loop-contract.md',
    PREFIX+'development-service-20261107-02/receipt.json'}
paths=sorted(changed|related|set(standards)|old_refs)
keys=[SOURCE+':'+n for n in paths]+[BASE+':'+n for n in (RUNTIME,PREFIX+'.gitattributes')]
blobs,blob_ids=batch_blobs(keys);exports={}
for name in paths:
    key=SOURCE+':'+name;raw=blobs[key];write('export/'+name,raw)
    exports[name]=dict(git_blob=blob_ids[key],sha256=digest(raw),bytes=len(raw))
    check('exact source export '+name,artifact(name)==raw)
    if name.endswith('.py'):ast.parse(raw.decode('utf-8'),filename=name);check('source AST parse '+name,True)
for name in (RUNTIME,PREFIX+'.gitattributes'):write('base-export/'+name,blobs[BASE+':'+name])
for name in standards:check('standards unchanged '+name,base[name]==fixed[name])
jwrite('source-manifest.json',dict(base=BASE,source=SOURCE,files=exports,changed_files=sorted(changed),standards=standards,old_service_package_git_blobs={n:base[n] for n in sorted(old_packages)},new_project_calls=0))

replay=text(RUNTIME);old=blobs[BASE+':'+RUNTIME].decode();r_ast=ast.parse(replay);old_ast=ast.parse(old)
functions={n.name:n for n in r_ast.body if isinstance(n,ast.FunctionDef)};old_functions={n.name:n for n in old_ast.body if isinstance(n,ast.FunctionDef)}
check('only three functions updated',{n for n in functions if ast.dump(functions[n])!=ast.dump(old_functions[n])}=={'_inputs','_run_recorded','_read_attempt'})
check('v1 exact legacy closed input key set retained',"INPUT_SCHEMA = 'aegisdc-facility-replay-inputs-v1'" in replay and "fields = {'schema', 'seed', 'exogenous_events', 'action_commands', 'work_requests'}" in replay)
check('v2 closed dispatch field only',"ONLINE_INPUT_SCHEMA = 'aegisdc-facility-replay-inputs-v2'" in replay and "set(value) != fields | ({'dispatch_program'} if online else set())" in replay)
check('V2 object and empty legacy work',"not isinstance(value['dispatch_program'], dict) or value['work_requests']" in replay)
check('exogenous commands boundary preserved',"row.get('parameter_id') in ENGINEERING_COMMAND_PARAMETERS" in replay and 'Control parameters belong to action_commands, not exogenous_events' in replay)
check('declared sorted frozen inputs and exact copies',"result = deepcopy(value)" in replay and "result[field].sort(key=lambda row: (row['time_s'], row['parameter_id']))" in replay)
check('only closed dispatch passed to actual plant',"online_options = {'dispatch_program': frozen['dispatch_program']} if frozen['schema'] == ONLINE_INPUT_SCHEMA else {}" in replay and "work_requests=frozen['work_requests'], **online_options)" in replay)
check('no independent work/inspection/intervention side door',"Policy execution owns its declared crew and observation/action bindings" in text('src/aegis_dc/plant.py'))
check('actual frozen producer randomness explicitly labelled','DECLARED_PRODUCER_REALIZATIONS_FROZEN_IN_DISPATCH_PROGRAM' in replay)
check('reader binds dispatch existence and exact digest',"('dispatch_program' in actual_inputs) != ('dispatch_program' in frozen)" in replay and "digest(actual_inputs['dispatch_program']) != digest(frozen['dispatch_program'])" in replay)
check('wrong saved program separate diagnostic','trajectory_dispatch_program' in replay)
check('only origin frozen scenario and input recomputed, not saved trajectory',"inputs = deepcopy(prior['inputs'])" in replay and "_run_recorded(prior['scenario'], directory, inputs=inputs" in replay)
check('legacy exact runtime/interpreter source gates preserved','EXACT_RUNTIME_BYTES_AND_INTERPRETER' in replay and 'Execution source changed during the attempt' in replay)
test=text(TEST);service=text(SERVICE_TEST)
check('outer pre-call snapshots/inputs before STARTED',test.index('snapshot.write_bytes(raw)')<test.index("_json_new(folder / 'input.json'")<test.index("_json_new(folder / 'development-attempt.json'"))
check('fsynced STARTED writer shared with service slice',"from test_full_loop_service import REFERENCE, ROOT, _json_new, service_fixture" in test and 'os.fsync(stream.fileno())' in service)
check('replay one new UUID and never overwrite',"label + '-' + uuid4().hex" in test and 'exist_ok=False' in test)
check('test only named elapsed_ns removal',"row.pop('elapsed_ns')" in test and "self.assertEqual(*compared)" in test)

fmt=data(PREFIX+'development-replay-log-formats.json')['logs'];attrs=text(PREFIX+'.gitattributes');old_attrs=blobs[BASE+':'+PREFIX+'.gitattributes'].decode()
check('old exact service log attributes not changed',attrs.startswith(old_attrs))
check('only 3 new exact replay log attributes',{l.split()[0] for l in attrs[len(old_attrs):].splitlines() if l.strip() and not l.startswith('#')}==set(fmt) and len(fmt)==3)
for name,identity in fmt.items():
    raw=artifact(PREFIX+name);check('exact native replay log '+name,digest(raw)==identity['sha256'] and raw.count(b'\r\n')==identity['crlf_lines'] and b'\n' not in raw.replace(b'\r\n',b''))
    check('per-path only CRLF recognition '+name,name+' -text whitespace=blank-at-eol,blank-at-eof,space-before-tab,cr-at-eol' in attrs)
logs={PurePosixPath(n).name[:2]:text(PREFIX+n) for n in fmt}
check('RED05 input validation failure preserved','FAILED (failures=1)' in logs['05'] and 'Use the closed versioned facility replay inputs contract' in logs['05'])
check('GREEN06 actual test reports one method pass','Ran 1 test' in logs['06'] and logs['06'].rstrip().endswith('OK'))
boundary=json.loads(logs['07'].splitlines()[-1]);check('07 saved checks no physical call',boundary['status']=='PASS' and boundary['malformed_record_calls']==3 and boundary['new_simulation_calls']==boundary['new_selector_calls']==boundary['registered_research_trials']==0)
for row in boundary['preserved_v1_saved_reads']:
    p=OLD_V1+row['case']+'/'
    check('V1 old terminal exact Git hash '+row['case'],digest(artifact(p+'attempt.json'))==row['original_terminal_sha256'] and data(p+'attempt.json')['status']=='COMPLETED')
    check('V1 original closed no dispatch '+row['case'],data(p+'frozen-inputs.json')['schema'].endswith('-v1') and 'dispatch_program' not in data(p+'trajectory/run.json')['inputs'])
check('four old V1 originals exactly counted',len(boundary['preserved_v1_saved_reads'])==4)

pack_decl,pack_receipt,manifest=(data(PACKAGE+n) for n in ('declaration.json','receipt.json','members.json'))
check('4 exact package durable roles',{n.removeprefix(PACKAGE) for n in fixed if n.startswith(PACKAGE)}=={'declaration.json','receipt.json','members.json','originals.zip'})
check('receipt explicitly not formal',pack_receipt['classification']=='DEVELOPMENT_RECORD_AND_REPLAY_ORIGINALS_NOT_FORMAL_CAPTURE' and pack_decl['cache_classification']=='EXCLUDED_RUNTIME_CACHES')
check('declaration receipt roles exact',set(pack_decl['artifacts'])==set(pack_receipt['artifacts'])=={'declaration.json','members.json','originals.zip'})
for name,expected in pack_receipt['artifacts'].items():check('pack receipt exact original '+name,digest(artifact(PACKAGE+name))==expected)
check('packager bytes pinned',pack_receipt['tool']==TOOL and digest(artifact(TOOL))==pack_receipt['tool_sha256'])
for name,expected in pack_decl['support'].items():check('declared support immutable '+name,digest(artifact(name))==expected)
with zipfile.ZipFile(OUT/'export'/(PACKAGE+'originals.zip')) as archive:
    names=archive.namelist();check('499 unique ZIP members, exact manifest',len(names)==len(set(names))==len(manifest)==pack_receipt['members']==499 and set(names)==set(manifest))
    z={}
    for name,identity in manifest.items():
        raw=archive.read(name);z[name]=raw
        check('durable exact ZIP member '+name,safe(name) and digest(raw)==identity['sha256'] and len(raw)==identity['bytes'])
cases=pack_decl['cases'];check('six unique cases plus reader fixtures only',len(cases)==len(set(cases))==6 and {n.split('/')[0] for n in z}==set(cases)|{'reader-boundaries'})
check('exact declared reader fixture roles',{n for n in z if n.startswith('reader-boundaries/')}==set(pack_decl['reader_fixtures']) and len(pack_decl['reader_fixtures'])==12)
runtime={n for n in fixed if n.startswith('src/') and n.endswith('.py')}
actual_runtime={n for n in runtime if n.startswith('src/aegis_dc/') or n=='src/patrol_rsi/contracts.py'}
check('67 runtime paths and 36 actual code identity paths',len(runtime)==67 and len(actual_runtime)==36)
runtime_bytes,_=batch_blobs([SOURCE+':'+n for n in sorted(runtime)])
runtime_hashes={n:digest(runtime_bytes[SOURCE+':'+n]) for n in runtime}
cases_summary=[];complete={};refusals={};source_files=runtime|{TEST,SERVICE_TEST,REFERENCE,PROPERTY}
for case in cases:
    prefix=case+'/'
    def member(name):return json.loads(z[prefix+name])
    attempt=member('development-attempt.json');record=member('recorded/attempt.json');outer=member('input.json');declaration=member('recorded/declaration.json');life=[json.loads(l) for l in z[prefix+'recorded/lifecycle.jsonl'].splitlines()]
    check('precall STARTED identity '+case,attempt['status']=='STARTED' and attempt['source_commit']==record['source_identity']['git_commit'] and attempt['source_commit']==BASE and attempt['registered_research_trials']==0)
    check('precall exact author/runtime/reference roles '+case,set(attempt['source_files'])==source_files and len(attempt['source_files'])==71)
    expected={'development-attempt.json','input.json','recorded/attempt.json'}|{'pre-call/'+n for n in source_files}|{'recorded/'+n for n in record['artifacts']}
    check('all attempt ZIP roles exact '+case,{n.removeprefix(prefix) for n in z if n.startswith(prefix)}==expected)
    for name,expected in attempt['source_files'].items():check('precall snapshot SHA '+case+'/'+name,digest(z[prefix+'pre-call/'+name])==expected)
    for name,expected in record['artifacts'].items():check('actual recorded artifact SHA '+case+'/'+name,digest(z[prefix+'recorded/'+name])==expected)
    check('runtime source set and actual hash anchor '+case,record['source_identity']['files']=={n:attempt['source_files'][n] for n in actual_runtime})
    expected_rt=dict(runtime_hashes)
    if case in logs['05']:expected_rt[RUNTIME]=digest(blobs[BASE+':'+RUNTIME])
    check('all precall runtime fixed byte identity '+case,{n:attempt['source_files'][n] for n in runtime}==expected_rt)
    check('precall frozen support refs '+case,all(z[prefix+'pre-call/'+n]==artifact(n) for n in (REFERENCE,PROPERTY,SERVICE_TEST)))
    check('recorded execution original lifecycle '+case,[r['state'] for r in life]==['STARTED',record['status']] and all(r['attempt_id']==record['attempt_id'] for r in life) and life[-1]['failure']==record['failure'])
    check('recorded artifact roles allowed '+case,set(record['artifacts'])<=set(declaration['allowed_before_finalization']))
    check('actual submitted model and v2 program inputs retained '+case,member('recorded/inputs.json')==outer['replay_inputs'] and member('recorded/scenario-input.json')==outer['model'] and outer['duration_s']==1.75 and outer['maximum_step_s']==.01)
    check('engineering only '+case,record['registered_research_trials']==0 if 'registered_research_trials' in record else record['research_trials']==record['model_calls']==record['training_calls']==0)
    status=record['status'];cases_summary.append(dict(case=case,operation=attempt['operation'],status=status))
    if status=='COMPLETED':
        run=member('recorded/trajectory/run.json');frozen=member('recorded/frozen-inputs.json');operation=attempt['operation']
        check('one completed case per original/replay '+case,operation not in complete and operation in {'record','replay'})
        check('actual complete durable original roles '+case,set(record['artifacts'])==set(declaration['required_when_completed']))
        check('actual saved program and exogenous input equals frozen '+case,run['inputs']['dispatch_program']==frozen['dispatch_program']==outer['replay_inputs']['dispatch_program'] and run['inputs']['boundary_events']==frozen['exogenous_events'] and run['inputs'].get('action_commands',[])==frozen['action_commands']==[] and run['inputs']['work_requests']==frozen['work_requests']==[])
        check('actual physical exec identity explicit dirty at base '+case,all(run['code_identity'][k]==record['source_identity'][k] for k in ('git_commit','implementation_has_changes','files','source_tree_sha256')) and run['code_identity']['implementation_has_changes'] is True)
        check('original actual1.75s and exact scenario '+case,run['inputs']['duration_s']==record['duration_s']==1.75 and run['inputs']['maximum_step_s']==record['maximum_step_s']==.01 and member('recorded/trajectory/scenario.json')==outer['model'])
        for n,identity in run['artifacts'].items():check('original physical artifact SHA '+case+'/'+n,digest(z[prefix+'recorded/trajectory/'+n])==identity['sha256'])
        check('saved named action actual at1.25 '+case,[(r['parameter_id'],r['applied_at_s'],r['old_value'],r['new_value']) for r in run['intervention_private_audit']['events']]==[('filter_resistance_multiplier',1.25,4,1)])
        check('feedback actual1.75 no closure '+case,[(r['arrived_at_s'],r['risk_closed']) for r in run['intervention_public_feedback']]==[(1.75,False)])
        decisions=run['policy_public_decisions'];audits=run['policy_computation_audit']
        check('exact five current online decisions '+case,[r['frame']['as_of_s'] for r in decisions]==[0,.25,.75,1.25,1.75] and [r['choice']['chosen_candidate_id'] for r in decisions]==['first-action',None,None,None,None])
        check('no future public records in replay '+case,all(e['observed_at_s']<=e['arrived_at_s']<=d['frame']['as_of_s'] for d in decisions for e in d['frame']['evidence']['records']))
        check('wall diagnostics separated, all model counts retained '+case,len(audits)==len(decisions) and all(type(a['elapsed_ns']) is int and a['elapsed_ns']>=0 and a['model_evaluations']==d['choice']['model_evaluations'] for a,d in zip(audits,decisions)))
        trace=[json.loads(line) for line in z[prefix+'recorded/trajectory/private-state.jsonl'].splitlines()]
        balances=[json.loads(line) for line in z[prefix+'recorded/trajectory/balances.jsonl'].splitlines()]
        check('saved true trace and interval balance contiguous '+case,len(trace)==len(balances)+1 and trace[0]['time_s']==0 and trace[-1]['time_s']==1.75 and all(b['start_s']==a['time_s'] and b['end_s']==c['time_s'] for a,b,c in zip(trace,balances,trace[1:])))
        check('independent actual filter hydraulic literal '+case,all(math.isclose(r['domains']['facility_cooling']['lake_pump']['volume_flow_m3_s'],math.sqrt(1/(100 if r['time_s']>=1.25 else 340)),rel_tol=0,abs_tol=1e-9) for r in trace))
        complete[operation]=dict(prefix=prefix,run=run,record=record,frozen=frozen)
    else:
        check('true refusal no physical work '+case,status=='FAILED' and record['execution_kind']=='NOT_STARTED' and record['failure']['stage']=='validate_inputs' and not any(n.startswith(prefix+'recorded/trajectory/') for n in z))
        refusals[case]=record['failure']
check('exact six receipt statuses and budgets',cases_summary==pack_receipt['attempts'] and len(complete)==2 and len(refusals)==4 and sum(row['record']['duration_s'] for row in complete.values())==3.5)
check('07 refusals match preserved raw records',len(boundary['input_refusals'])==3 and all(refusals[row['case']]==row['failure'] for row in boundary['input_refusals']))
o,q=complete['record'],complete['replay'];o_prefix=o['prefix']+'recorded/';q_prefix=q['prefix']+'recorded/'
check('replay exact original identity and copied source authority',q['record']['replay_of']==dict(attempt_id=o['record']['attempt_id'],attempt_sha256=digest(z[o_prefix+'attempt.json']),mode='EXACT_REEXECUTION') and q['record']['replay_revision_relationship']=='SAME_COMMIT')
for name in ('attempt.json','declaration.json','lifecycle.jsonl'):check('exact copied replay origin '+name,z[q_prefix+'origin/'+name]==z[o_prefix+name])
check('exact frozen same dispatch/exogenous source',o['frozen']==q['frozen'] and z[o_prefix+'frozen-inputs.json']==z[q_prefix+'frozen-inputs.json'])
for name in ('scenario.json','private-state.jsonl','balances.jsonl'):check('actual exact replay saved '+name,z[o_prefix+'trajectory/'+name]==z[q_prefix+'trajectory/'+name])
compared=[deepcopy(o['run']),deepcopy(q['run'])];measured=[]
for run in compared:measured.append([a.pop('elapsed_ns') for a in run['policy_computation_audit']])
check('only elapsed_ns diagnostic differs in actual raw decisions/runs',compared[0]==compared[1] and measured[0]!=measured[1])

boundary_result=json.loads(z['reader-boundaries/boundary-result-01.json']);check('reader result same native log metadata',boundary_result==boundary)
bad_prefix='reader-boundaries/'+PurePosixPath(boundary['forged_saved_origin']).name+'/'
bad_run=json.loads(z[bad_prefix+'trajectory/run.json']);bad_terminal=json.loads(z[bad_prefix+'attempt.json']);bad_frozen=json.loads(z[bad_prefix+'frozen-inputs.json'])
check('adversarial saved original genuinely hash-consistent',bad_terminal['artifacts']['trajectory/run.json']==digest(z[bad_prefix+'trajectory/run.json']) and all(digest(z[bad_prefix+n])==h for n,h in bad_terminal['artifacts'].items()))
check('adversarial example only changed executed program id',bad_run['inputs']['dispatch_program']['id']=='different-saved-program' and bad_run['inputs']['dispatch_program']!=bad_frozen['dispatch_program'] and bad_frozen==o['frozen'])
bad_run['inputs']['dispatch_program']['id']=o['run']['inputs']['dispatch_program']['id']
check('wrong program concrete readback witness',bad_run==o['run'] and boundary['forged_refusal']['stage']=='trajectory_dispatch_program' and boundary['forged_refusal']['artifact']=='trajectory/run.json')

tool=text(TOOL);tree_tool=ast.parse(tool);tool_functions={n.name:n for n in tree_tool.body if isinstance(n,ast.FunctionDef)}
verify_service=ast.get_source_segment(tool,tool_functions['verify_service']);replay_checks=ast.get_source_segment(tool,tool_functions['replay_checks'])
check('previous nested durable P2 closed recursively',"folder.rglob('*')" in tool and "root_members(folder) == FILES" in verify_service)
check('previous case set/duplicate P2 closed',"len(cases) == len(set(cases))" in verify_service and "{name.split('/')[0] for name in names} == set(cases)" in verify_service)
check('service exact per-case roles',"{name.removeprefix(prefix) for name in names if name.startswith(prefix)} == expected" in verify_service and 'return verify_v1(folder, delivery)' in verify_service)
check('archive first helper identity exact prior fixed receipt',data(PREFIX+'development-service-20261107-02/receipt.json')['tool_sha256']==digest(artifact(HELPER)))
correction=data(PREFIX+'development-service-closure-correction-01.json')
check('tool-only 3 malformed cases retained PASS',correction['source_tool_sha256']==digest(artifact(TOOL)) and correction['status']=='PASS' and correction['new_project_calls']==0 and correction['old_package_unchanged'] is True and {r['case']:r['status'] for r in correction['results']}=={'nested-artifact':'REFUSED','duplicate-case':'REFUSED','extra-zip-root':'REFUSED'})
check('replay verifier recursive durable and cases exact',"root_members(folder) == FILES" in replay_checks and "{name.split('/')[0] for name in names} == {*cases, 'reader-boundaries'}" in replay_checks)
check('saved verifier application imports absent',not any((getattr(n,'module','') or '').startswith(('aegis_dc','patrol_rsi')) for n in ast.walk(tree_tool) if isinstance(n,(ast.Import,ast.ImportFrom))))
check('replay tool comparison removes only named elapsed field',"row.pop('elapsed_ns')" in replay_checks and "completed['record'] == completed['replay']" in replay_checks)
check('literal replay helper pin gap in fixed package',"from full_loop_development import " in tool and HELPER not in pack_decl['support'] and HELPER not in replay_checks)
diffcheck=subprocess.run(['git','diff','--check',BASE+'...'+SOURCE],cwd=REPO,capture_output=True)
check('full Git diff check no path skip',diffcheck.returncode==0 and not diffcheck.stdout and not diffcheck.stderr)
check('ticket27 only development evidence','**Status:** claimed' in text(TICKET) and 'Full 27 cross-system scenario, independent final reviews and acceptance remain pending.' in text(TICKET))
check('old sealed reviews exact paths and bytes',snapshot()==before);jwrite('prior-reviews-after.json',before)

jwrite('saved-originals.json',dict(status='PASS',cases=cases_summary,archive_members=499,completions=2,input_refusals=4,
    physical_duration_s=3.5,elapsed_ns_only_excluded=True,actual_elapsed_diagnostics=measured,old_v1_originals=4,
    previous_service_p2_closed=True,retained_original_service_helper_sha256=digest(artifact(HELPER)),new_project_calls=0))
jwrite('checks.json',checks)
print(json.dumps(dict(status='PASS_SAVED_ORIGINALS',source=SOURCE,checks=len(checks),exports=len(exports),prior=len(before),members=len(z),new_project_calls=0)))
