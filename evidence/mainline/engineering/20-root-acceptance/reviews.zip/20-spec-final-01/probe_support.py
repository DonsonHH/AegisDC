from copy import deepcopy
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
import json,subprocess,sys
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[1];PIN='6cc325a65961f2448232f5c539be61e2433848f0';EXPORT=OUT/'export';sys.path.insert(0,str(EXPORT/'src'));checks=[];raw=[]
def check(v,label):
 if not v:raise AssertionError(label)
 checks.append(label)
def close(a,b,label):check(abs(a-float(F(b)))<=1e-12,label)
def read(name):return json.loads((EXPORT/name).read_bytes())
def guard():
 names=subprocess.check_output(['git','ls-tree','-r','--name-only',PIN,'src','configs'],cwd=ROOT,text=True).splitlines();hashes={}
 for name in names:
  data=(EXPORT/name).read_bytes();assert data==subprocess.check_output(['git','show',PIN+':'+name],cwd=ROOT);hashes[name]=sha256(data).hexdigest()
 return hashes
before=guard();check(sha256((OUT/'protocol.json').read_bytes()).hexdigest()==(OUT/'protocol.sha256').read_text().strip(),'frozen protocol')
from aegis_dc.action_value import assess_action_value
from aegis_dc.decision_view import DecisionGateway
PUBLIC=json.loads((OUT/'review-inputs/evidence/mainline/engineering/18-beliefs/capture-01/cli-frame.json').read_bytes())
def fixture(prior=.25):
 belief=read('configs/full-facility-belief-model-v1.json');catalog=read('configs/full-facility-risk-scenarios-v1.json');model=read('configs/full-facility-action-value-v1.json')
 priors={0:[.875,0,0,.125],.25:[.5,.25,.125,.125],.9:[.05,.9,.025,.025]}
 for variant in belief['variants']:variant['prior']=priors[prior]
 catalog.update(horizon_s=100,demand=[dict(start_s=0,end_s=100,rate=1)])
 for outcome in catalog['outcomes']:
  value=0 if outcome['id']=='cooling-limited' else 1;outcome['capacity_profile']=[dict(start_s=0,end_s=100,capacities={c:value for c in catalog['service_component_ids']})]
 for q in catalog['questions']:
  q['window_s']=[0,100];q['consequence_bounds']['service_deficit_time_s']['interval']=[0,100];q['consequence_bounds']['unserved_service_unit_s']['interval']=[0,100]
 ledger=dict(schema='aegisdc-evidence-ledger-v1',id=PUBLIC['evidence']['ledger_id'],facility_id=PUBLIC['facility_id'],basis='synthetic_assumption',time_unit='s',**deepcopy(PUBLIC['evidence']['static_knowledge']),records=[])
 frame=DecisionGateway(PUBLIC['nominal_knowledge'],ledger,dict(schema='aegisdc-public-preparation-plan-v1',id='independent20',basis='synthetic_assumption',time_unit='s',decision_times_s=[0],requests=PUBLIC['requests'])).next_frame()
 local=model['question_models'][0];local['inspection'].update(travel_s=0,wait_s=0,work_s=10,report_latency_s=0,cost=0);local['intervention'].update(travel_s=0,wait_s=0,work_s=20,cost=0)
 model['resource_budget']=dict(person_s=1000,tool_s=1000,cost=1000)
 for r in model['availability']:r['window_s']=[0,1000]
 for variant in local['variants']:
  for outcome in catalog['outcomes']:
   key=outcome['id'];variant['positive_likelihood'][key]=.8 if key=='cooling-limited' else .1;variant['during_capacity'][key]={c:0 for c in catalog['service_component_ids']};variant['after_capacity'][key]={c:1 for c in catalog['service_component_ids']}
 return frame,belief,catalog,model
def evaluate(inputs,label):
 result=assess_action_value(*deepcopy(inputs));raw.append(dict(label=label,result=result));return result
def alternatives(result):return {r['kind']:r for r in result['question_values'][0]['alternatives']}
def reject(inputs,label):
 try:assess_action_value(*inputs)
 except ValueError as e:check(True,'reject '+label);raw.append(dict(label=label,rejected=str(e)))
 else:check(False,'admitted '+label)

