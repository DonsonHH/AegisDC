## Spec

No open core findings at `6cc325a65961f2448232f5c539be61e2433848f0`, reviewed against fixed point45725818685716d78167d0fceeb84e861d397a3e. This is a core review only; final packaging/protocol/data, independent Standards and Root acceptance remain pending.

Ticket20 requires inspection value to include duration, people and action effects, use declared belief/model rather than hidden truth, and compare candidates under the same information/permission/budget.144 independent pure-public assertions pass with source/config Git-blob guards before/after. No plant, physical run, author capture or full suite was invoked.

The independent100-second witness at priors0,1/4,9/10 reproduces exact report masses, conditional fault posteriors, false-positive repair losses and separate person-time. Added travel, wait, work and communication latency preserve the continuing baseline until intervention work starts. Inspection alone changes information and incurs cost; it does not directly reduce physical loss. Zero-support reports have undefined conditional posteriors, while arbitrarily small positive support still triggers worst-branch resource gates.

Every positive-support branch must satisfy full committed person/tool/cost budgets and declared resource windows; expected costs cannot hide a30person-second positive branch behind15.5expected seconds. Horizon-truncated occupation stays separate from unfinished full commitments. Missing availability remains unknown; selected intervenors must individually meet the bound nominal capability. High-prior negative reports can still warrant intervention under the declared continuation rule.

Crossed belief/action variants form explicit sensitivity ranges; a model conflict withholds the envelope and unresolved values remain null. Current arrived public restrictions affect planning, while future/expired restrictions and inconsistent/private frames cannot create an actual-state oracle. Six unmodeled domain values remain unknown. Local question alternatives explicitly do not sum into additive global gain, and service/resource/cost units stay separate.

One reviewer arithmetic error is retained: delayed inspection loss was initially written907/50; independent joint-event decomposition is1/5×47+1/20×100+3/40×20=159/10. The original frozen protocol and failed reviewer probe remain; this is not a product finding.
