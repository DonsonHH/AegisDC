from copy import deepcopy
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
import json,subprocess,sys
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[1];PIN='6cc325a65961f2448232f5c539be61e2433848f0';EXPORT=OUT/'export';sys.path.insert(0,str(EXPORT/'src'));checks=[];raw=[]
def check(v,label):
 if not v:raise AssertionError(label)
 checks.append(label)
def close(a,b,label):check(abs(a-float(F(b)))<=1e-12,label)
def read(name):return json.loads((EXPORT/name).read_bytes())
def guard():
 names=subprocess.check_output(['git','ls-tree','-r','--name-only',PIN,'src','configs'],cwd=ROOT,text=True).splitlines();hashes={}
 for name in names:
  data=(EXPORT/name).read_bytes();assert data==subprocess.check_output(['git','show',PIN+':'+name],cwd=ROOT);hashes[name]=sha256(data).hexdigest()
 return hashes
before=guard();check(sha256((OUT/'protocol.json').read_bytes()).hexdigest()==(OUT/'protocol.sha256').read_text().strip(),'frozen protocol')
from aegis_dc.action_value import assess_action_value
from aegis_dc.decision_view import DecisionGateway
PUBLIC=json.loads((OUT/'review-inputs/evidence/mainline/engineering/18-beliefs/capture-01/cli-frame.json').read_bytes())
def fixture(prior=.25):
 belief=read('configs/full-facility-belief-model-v1.json');catalog=read('configs/full-facility-risk-scenarios-v1.json');model=read('configs/full-facility-action-value-v1.json')
 priors={0:[.875,0,0,.125],.25:[.5,.25,.125,.125],.9:[.05,.9,.025,.025]}
 for variant in belief['variants']:variant['prior']=priors[prior]
 catalog.update(horizon_s=100,demand=[dict(start_s=0,end_s=100,rate=1)])
 for outcome in catalog['outcomes']:
  value=0 if outcome['id']=='cooling-limited' else 1;outcome['capacity_profile']=[dict(start_s=0,end_s=100,capacities={c:value for c in catalog['service_component_ids']})]
 for q in catalog['questions']:
  q['window_s']=[0,100];q['consequence_bounds']['service_deficit_time_s']['interval']=[0,100];q['consequence_bounds']['unserved_service_unit_s']['interval']=[0,100]
 ledger=dict(schema='aegisdc-evidence-ledger-v1',id=PUBLIC['evidence']['ledger_id'],facility_id=PUBLIC['facility_id'],basis='synthetic_assumption',time_unit='s',**deepcopy(PUBLIC['evidence']['static_knowledge']),records=[])
 frame=DecisionGateway(PUBLIC['nominal_knowledge'],ledger,dict(schema='aegisdc-public-preparation-plan-v1',id='independent20',basis='synthetic_assumption',time_unit='s',decision_times_s=[0],requests=PUBLIC['requests'])).next_frame()
 local=model['question_models'][0];local['inspection'].update(travel_s=0,wait_s=0,work_s=10,report_latency_s=0,cost=0);local['intervention'].update(travel_s=0,wait_s=0,work_s=20,cost=0)
 model['resource_budget']=dict(person_s=1000,tool_s=1000,cost=1000)
 for r in model['availability']:r['window_s']=[0,1000]
 for variant in local['variants']:
  for outcome in catalog['outcomes']:
   key=outcome['id'];variant['positive_likelihood'][key]=.8 if key=='cooling-limited' else .1;variant['during_capacity'][key]={c:0 for c in catalog['service_component_ids']};variant['after_capacity'][key]={c:1 for c in catalog['service_component_ids']}
 return frame,belief,catalog,model
def evaluate(inputs,label):
 result=assess_action_value(*deepcopy(inputs));raw.append(dict(label=label,result=result));return result
def alternatives(result):return {r['kind']:r for r in result['question_values'][0]['alternatives']}
def reject(inputs,label):
 try:assess_action_value(*inputs)
 except ValueError as e:check(True,'reject '+label);raw.append(dict(label=label,rejected=str(e)))
 else:check(False,'admitted '+label)

protocol=json.loads((OUT/'protocol.json').read_bytes());witness=json.loads((OUT/'20-independent-information-action-witness-01.json').read_bytes())
for prior,case in zip((0,.25,.9),witness['cases']):
 inputs=fixture(prior);result=evaluate(inputs,'prior '+str(prior));rows=alternatives(result)
 for kind in ('defer','direct_intervention','inspect_then_act'):
  name='inspect_then_intervene_if_positive' if kind=='inspect_then_act' else kind
  close(rows[kind]['expected']['service_deficit_time_s']['value'],case['expected_deficit_time_s'][name],f'prior{prior} {kind} deficit')
  close(rows[kind]['expected']['person_s']['value'],case['expected_worker_person_s'][name],f'prior{prior} {kind} worker')
  close(rows[kind]['expected']['offered_service_unit_s']['value'],100,f'prior{prior} offered unchanged')
 close(rows['inspect_then_act']['branches'][0]['probability'],case['positive_probability'],f'prior{prior} positive report')
 if prior==.25:
  close(rows['inspect_then_act']['branches'][0]['posterior_outcomes']['cooling-limited'],'8/11','posterior positive defect')
  close(rows['inspect_then_act']['branches'][1]['posterior_outcomes']['cooling-limited'],'2/29','posterior negative defect')
 if prior==.9:
  close(rows['inspect_then_act']['branches'][0]['posterior_outcomes']['cooling-limited'],'72/73','high positive posterior')
  close(rows['inspect_then_act']['branches'][1]['posterior_outcomes']['cooling-limited'],'2/3','high negative posterior')
 check(result['physical_actions']==[] and not result['execution_permission'],'no physical action '+str(prior));check(len(result['unmodeled_questions'])==6 and all(x['value'] is None for x in result['unmodeled_questions']),'six unmodeled remain unknown '+str(prior))

# Add travel/wait/report latency: physical baseline continues until actual action work begins.
f,b,c,m=fixture();local=m['question_models'][0];local['inspection'].update(travel_s=2,wait_s=3,work_s=5,report_latency_s=7,cost=3);local['intervention'].update(travel_s=4,wait_s=6,work_s=20,cost=4)
rows=alternatives(evaluate((f,b,c,m),'delayed stages'));close(rows['direct_intervention']['expected']['service_deficit_time_s']['value'],'45/2','direct delayed baseline')
close(rows['inspect_then_act']['expected']['service_deficit_time_s']['value'],'159/10','inspection report action delay')
for key,value in dict(person_s='73/4',travel_person_s='31/10',wait_person_s='93/20',work_person_s='21/2',tool_s='73/4',cost='41/10').items():close(rows['inspect_then_act']['expected'][key]['value'],value,'distinct resource '+key)
check(rows['inspect_then_act']['branches'][0]['action_started_at_s']==27 and rows['inspect_then_act']['branches'][0]['action_completed_at_s']==47,'action timing after report and travel')
# Probability-weighted budget would admit15.5, but positive branch commits30.
f,b,c,m=fixture();m['resource_budget']['person_s']=16;rows=alternatives(evaluate((f,b,c,m),'worst branch budget'));check(rows['inspect_then_act']['eligible_for_planning'] is False and rows['direct_intervention']['eligible_for_planning'] is False,'full positive support budgets');check(rows['defer']['eligible_for_planning'] is True,'defer remains legal');close(rows['inspect_then_act']['expected']['person_s']['value'],'31/2','expected resources distinct gate');close(rows['inspect_then_act']['branches'][0]['required_resources']['person_s'],30,'positive branch commitment')
# Zero probability reports remain undefined conditionals and cannot veto through resource requirements.
f,b,c,m=fixture();m['resource_budget']['person_s']=11
for v in m['question_models'][0]['variants']:v['positive_likelihood']=dict.fromkeys(v['positive_likelihood'],0)
rows=alternatives(evaluate((f,b,c,m),'zero support'));positive=rows['inspect_then_act']['branches'][0];check(positive['probability']==0 and positive['posterior_outcomes'] is None and positive['status']=='ZERO_SUPPORT_REPORT','zero support explicit');check(rows['inspect_then_act']['eligible_for_planning'] is True,'zero support branch ignored by resourcegate');close(rows['inspect_then_act']['expected']['service_deficit_time_s']['value'],25,'information without action no loss reduction')
# Null availability is epistemic unknown, explicit narrow window is an infeasibility.
f,b,c,m=fixture();m['availability'][0]['window_s']=None;rows=alternatives(evaluate((f,b,c,m),'unknown availability'));check(rows['direct_intervention']['eligible_for_planning'] is None and rows['inspect_then_act']['eligible_for_planning'] is None,'unknown availability not zero/infeasible');m['availability'][0]['window_s']=[0,10];rows=alternatives(evaluate((f,b,c,m),'resource short window'));check(rows['direct_intervention']['eligible_for_planning'] is False and rows['inspect_then_act']['eligible_for_planning'] is False,'full commitment windows')
# Full commitments count even when horizon truncates observed occupation.
f,b,c,m=fixture();m['question_models'][0]['intervention']['work_s']=200;m['resource_budget']['person_s']=110;rows=alternatives(evaluate((f,b,c,m),'unfinished repair'));direct=rows['direct_intervention'];close(direct['expected']['person_s']['value'],100,'truncated resource account');check(direct['eligible_for_planning'] is False,'unfinished full budget not hidden');close(direct['branches'][0]['required_resources']['person_s'],200,'unfinished full commitment');check(direct['branches'][0]['action_status']=='UNFINISHED_WITHIN_HORIZON' and direct['branches'][0]['action_completed_at_s'] is None,'unfinished no claimed repair');close(direct['expected']['service_deficit_time_s']['value'],100,'repair outage unfinished')
f,b,c,m=fixture();m['question_models'][0]['inspection']['work_s']=120;rows=alternatives(evaluate((f,b,c,m),'unfinished inspection'));close(rows['inspect_then_act']['expected']['service_deficit_time_s']['value'],25,'no future report benefit');check(rows['inspect_then_act']['branches'][0]['report']=='unavailable_within_horizon','inspection report unavailable');close(rows['inspect_then_act']['expected']['person_s']['value'],100,'unfinished inspection account')
# Optional report continuation chooses by declared service, including negative evidence.
f,b,c,m=fixture(.9);local=m['question_models'][0];local['action_on_positive']=local['action_on_negative']='minimum_service_deficit';rows=alternatives(evaluate((f,b,c,m),'adaptive high continuation'));check([x['action'] for x in rows['inspect_then_act']['branches']]==['intervene','intervene'],'high negative report still warrants action');close(rows['inspect_then_act']['expected']['service_deficit_time_s']['value'],29,'adaptive continuation exact')
# Model conflicts retain unknown values rather than zero risk.
f,b,c,m=fixture();f=deepcopy(PUBLIC)
for v in b['variants']:v['positive_likelihood']['fixed-hot']=[0,0,0,0]
result=evaluate((f,b,c,m),'conflict');check(result['status']=='MODEL_CONFLICT','conflict status');check(all(row['expected']['service_deficit_time_s']['value'] is None and row['eligible_for_planning'] is None for row in result['question_values'][0]['alternatives']),'conflict unknown alternatives')
# Selected worker must itself qualify, even if another candidate could qualify.
f,b,c,m=fixture();c['questions'][0]['options'][1]['candidate_worker_ids']=['worker_cooling','worker_it'];m['question_models'][0]['intervenor_id']='worker_it';reject((f,b,c,m),'selected unqualified worker')
for mutation in ['private','unmodeled','wronginspector','badprob','badunit','unknownresource','overflow']:
 f,b,c,m=fixture()
 if mutation=='private':m['actual_state']='hidden'
 elif mutation=='unmodeled':m['question_models'][0]['question_id']='backup-support'
 elif mutation=='wronginspector':m['question_models'][0]['inspector_id']='worker_it'
 elif mutation=='badprob':m['question_models'][0]['variants'][0]['positive_likelihood']['other']=2
 elif mutation=='badunit':m['time_unit']='hour'
 elif mutation=='unknownresource':m['availability'][0]['resource_id']='hidden-tool'
 else:m['question_models'][0]['inspection']['report_latency_s']=1e308;m['question_models'][0]['intervention']['travel_s']=1e308
 reject((f,b,c,m),mutation)
after=guard();check(before==after,'all frozen source/config bytes unchanged');report=dict(schema='independent20-public-spec-checks-v1',status='PASS',source=PIN,assertions=len(checks),checks=checks,source_before=before,source_after=after,findings=[],physical_runs=0,full_suite_runs=0,registered_research_trials=0,llm_calls=0,training_calls=0);(OUT/'probe-result.json').write_text(json.dumps(report,indent=2)+chr(10),encoding='utf-8');(OUT/'raw-records.json').write_text(json.dumps(raw,indent=2)+chr(10),encoding='utf-8');print(json.dumps(dict(status='PASS',source=PIN,assertions=len(checks),findings=[])))
