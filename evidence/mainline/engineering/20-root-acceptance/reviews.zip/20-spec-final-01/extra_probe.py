from probe_support import *
# Scope support module performed no model calls before this file.
f,b,c,m=fixture();m['question_models'][0]['variants'][1]['after_capacity']['cooling-limited']={k:0 for k in c['service_component_ids']};result=evaluate((f,b,c,m),'variant range');value=result['question_values'][0];check(len(value['alternatives_by_assumption'])==4,'belief value crossproduct')
for kind in ['defer','direct_intervention','inspect_then_act']:
 for quantity,interval in value['assumption_envelope'][kind].items():
  vals=[next(a for a in row['alternatives'] if a['kind']==kind)['expected'][quantity]['value'] for row in value['alternatives_by_assumption']];check(interval==[min(vals),max(vals)],'crossvariant envelope '+kind+quantity)
close(value['assumption_envelope']['direct_intervention']['service_deficit_time_s'][1],40,'residual defect exact')
f,b,c,m=fixture();f=deepcopy(PUBLIC);b['variants'][1]['positive_likelihood']['fixed-hot']=[0,0,0,0];result=evaluate((f,b,c,m),'partial conflict');check(result['status']=='PARTIAL_MODEL_CONFLICT','partial conflict');check(result['question_values'][0]['assumption_envelope'] is None,'partial envelope withheld');check(result['question_values'][0]['alternatives'][0]['expected']['service_deficit_time_s']['value'] is not None,'valid reference shown')
# A finite outcome mixture independent of belief keeps same known binary fault probability.
f,b,c,m=fixture(0)
for o,prob in zip(c['outcomes'],[.5,.25,.125,.125]):o['conditional_probability']=dict.fromkeys(o['conditional_probability'],prob)
rows=alternatives(evaluate((f,b,c,m),'nonidentity joint law'));close(rows['defer']['expected']['service_deficit_time_s']['value'],25,'joint mixture usesconditional law');close(rows['inspect_then_act']['expected']['service_deficit_time_s']['value'],'25/2','joint mixture prospectivetree')
# Information-only route can be chosen with no repair and still pays inspection resources.
f,b,c,m=fixture();m['question_models'][0]['action_on_positive']=m['question_models'][0]['action_on_negative']='defer';rows=alternatives(evaluate((f,b,c,m),'no repair allowed'));close(rows['inspect_then_act']['expected']['service_deficit_time_s']['value'],25,'no information physicalgain');close(rows['inspect_then_act']['expected']['person_s']['value'],10,'informationalonepaysperson')
f,b,c,m=fixture();c['demand'][0]['rate']=0
for q in c['questions']:q['consequence_bounds']['unserved_service_unit_s']['interval']=[0,0]
result=evaluate((f,b,c,m),'zero demand');check(all(row['expected']['service_deficit_time_s']['value']==0 for row in result['question_values'][0]['alternatives']),'zero demand zero fractional deficit');check(result['question_values'][0]['comparison']['minimum_deficit_alternative']=='defer','zero demand defer')
# Restriction bound to the actual question target zone, communicated by a declared public source.
f,b,c,m=fixture();target=next(o['target_id'] for o in c['questions'][0]['options'] if o['id']=='isolate-cooling');location=next(e['nominal_location_id'] for e in f['nominal_knowledge']['entities'] if e['id']==target);n=deepcopy(f['nominal_knowledge']);n['reported_constraints'][0]['location_id']=location;constraint=n['reported_constraints'][0]
record=dict(id='public-entry',source_id=constraint['source_id'],target_id=constraint['target_id'],observable_id=constraint['observable_id'],unit='1',value=constraint['blocking_value'],observed_at_s=0,arrived_at_s=1,valid_until_s=2,quality=dict(status='reported',error_bound=None,note='Independent declared public report'),provenance=dict(origin_id='public-entry',copied_from_record_id=None))
ledger=dict(schema='aegisdc-evidence-ledger-v1',id=f['evidence']['ledger_id'],facility_id=f['facility_id'],basis='synthetic_assumption',time_unit='s',**f['evidence']['static_knowledge'],records=[record]);g=DecisionGateway(n,ledger,dict(schema='aegisdc-public-preparation-plan-v1',id='publicreport',basis='synthetic_assumption',time_unit='s',decision_times_s=[0,1,2],requests=f['requests']))
for instant in [0,1,2]:
 frame=g.next_frame();r=alternatives(evaluate((frame,b,c,m),'restriction '+str(instant)));check(r['direct_intervention']['eligible_for_planning'] is (instant!=1),'arrived current restriction actionmask '+str(instant));check(r['inspect_then_act']['eligible_for_planning'] is (instant!=1),'arrived current restriction inspectmask '+str(instant))
# Closed frame cannot insert private-world or future records.
f,b,c,m=fixture();f['actual_state']={};reject((f,b,c,m),'private frame')
f,b,c,m=fixture();forged=deepcopy(f);forged['as_of_s']=1;reject((forged,b,c,m),'clock inconsistent frame')
# Returned quantities have separate units and normalize every positive-support branch.
f,b,c,m=fixture();result=evaluate((f,b,c,m),'branch normalization');check(result['scope']=='SINGLE_NEXT_QUESTION_ALTERNATIVES_NOT_ADDITIVE_GLOBAL_GAIN','singledecisionnotglobalgain')
for row in result['question_values'][0]['alternatives']:
 close(sum(branch['probability'] for branch in row['branches']),1,'branchmass '+row['kind'])
 for branch in row['branches']:
  if branch['posterior_outcomes'] is not None:close(sum(branch['posterior_outcomes'].values()),1,'conditionalmass '+row['kind'])
 check(row['expected']['person_s']['unit']=='person*s' and row['expected']['tool_s']['unit']=='tool*s' and row['expected']['cost']['unit']==m['cost_unit'] and row['expected']['service_deficit_time_s']['unit']=='s','separateunits '+row['kind'])
# Very small positive-support report must still affect branch gates, even if display rounds.
f,b,c,m=fixture();m['resource_budget']['person_s']=11
for v in m['question_models'][0]['variants']:v['positive_likelihood']=dict.fromkeys(v['positive_likelihood'],5e-324)
rows=alternatives(evaluate((f,b,c,m),'tiny positive support'));check(rows['inspect_then_act']['eligible_for_planning'] is False,'tiny support budget notroundedaway');check(rows['inspect_then_act']['branches'][0]['status']=='PREDICTED','tiny support explicit predicted')
after=guard();check(before==after,'additionalsourceguard');report=dict(schema='independent20-extra-spec-v1',status='PASS',source=PIN,assertions=len(checks),checks=checks,source_before=before,source_after=after,physical_runs=0,full_suite_runs=0,registered_research_trials=0,findings=[]);(OUT/'extra-result.json').write_text(json.dumps(report,indent=2)+chr(10),encoding='utf-8');(OUT/'extra-raw-records.json').write_text(json.dumps(raw,indent=2)+chr(10),encoding='utf-8');print(json.dumps(dict(status='PASS',assertions=len(checks))))
