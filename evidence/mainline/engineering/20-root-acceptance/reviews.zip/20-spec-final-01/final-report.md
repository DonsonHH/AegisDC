# Spec final supplement

Core6cc remains byte-identical in candidate20da. The original independent144public assertions and their source guards remain valid and were not repeated. A separate saved-output check passes528 assertions: exact declared prior/action trees, report probabilities and posteriors, common demand and delivered/unserved conservation, full-commitment/unknown resource boundaries, zero report support, model variants, six unmodeled/null risks, CLI identity and all57runtime/3tools/36input source/data pins. Total672 recorded assertions,0open findings.

The frozen83de execution and2aea data retain their own identities; native CLI format is classified separately at00fd. The final candidate adds a fresh saved-only proof, illustrated report and Root actual two-image review, while ticket20/full acceptance remain pending. No physical intervention, global method gain or field calibration is claimed. Root must integrate and execute its complete regression.
