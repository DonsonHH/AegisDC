"""Independent saved-data check of ticket20; no inference or physics execution."""
from fractions import Fraction as F
from hashlib import sha256
import json
from pathlib import Path
import subprocess

ROOT=Path(__file__).resolve().parents[1]
DELIVERY='00fd5c283ed2895245f87da0f1bf9e8af40dcea8'
EXECUTION='83dea5cc8440eee3067b3ce593d3100c8ff00847'
CAPTURE='evidence/mainline/engineering/20-action-value/capture-01'
count=0
def check(condition,message):
    global count
    if not condition:raise ValueError(message)
    count+=1
def blob(rev,name):return subprocess.check_output(['git','cat-file','blob',rev+':'+name],cwd=ROOT)
def read(name):return json.loads(blob(DELIVERY,name))
def digest(raw):return sha256(raw).hexdigest()
def pins(rev,names):
    names=sorted(names);raw=subprocess.check_output(['git','cat-file','--batch'],cwd=ROOT,
        input=''.join(rev+':'+n+'\n' for n in names).encode())
    out={};offset=0
    for name in names:
        end=raw.index(b'\n',offset);h=raw[offset:end].split();check(len(h)==3 and h[1]==b'blob','Missing Git blob')
        start=end+1;size=int(h[2]);out[name]=digest(raw[start:start+size]);offset=start+size+1
    check(offset==len(raw),'Unexpected batch data');return out
def main():
    protocol=read('docs/mainline/20-action-value-engineering-protocol.json')
    r=read(CAPTURE+'/receipt.json');data=read(CAPTURE+'/check-results.json')
    check(r['execution_commit']==EXECUTION and r['status']=='PASS' and r['source_head_and_bytes_unchanged'],'Original capture status')
    check(set(r['artifacts'])==set(protocol['durable_outputs']) and len(r['artifacts'])==6,'Durable set')
    for name,h in r['artifacts'].items():check(digest(blob(DELIVERY,CAPTURE+'/'+name))==h,'Artifact identity')
    for role in ('runtime_sources','authoring_tools','frozen_inputs'):
        check(r[role]==pins(EXECUTION,r[role])==pins(DELIVERY,r[role]),'Execution/delivery pins')
    check(data['maximum_absolute_error']==0 and len(data['independent_cases'])==3,'Saved finite cases')
    labels=('defer','direct_intervention','inspect_then_act')
    outcomes=('nominal','cooling-limited','power-limited','other')
    for row,q,prior in zip(data['independent_cases'],(F(0),F(1,4),F(9,10)),
                         ([F(7,8),0,0,F(1,8)],[F(1,2),F(1,4),F(1,8),F(1,8)],
                          [F(1,20),F(9,10),F(1,40),F(1,40)])):
        alternatives=row['result']['question_values'][0]['alternatives']
        positive=q*F(4,5)+(1-q)*F(1,10)
        losses=(q*100,F(20),q*(F(4,5)*30+F(1,5)*100)+(1-q)*F(1,10)*20)
        persons=(F(0),F(20),10+positive*20)
        for actual,kind,loss,person in zip(alternatives,labels,losses,persons):
            check(actual['kind']==kind,'Alternative order')
            check(abs(actual['expected']['service_deficit_time_s']['value']-float(loss))<=1e-14,'Independent literal deficit')
            check(abs(actual['expected']['person_s']['value']-float(person))<=1e-14,'Independent literal person time')
            check(actual['expected']['offered_service_unit_s']['value']==100,'Common demand')
            check(abs(actual['expected']['delivered_service_unit_s']['value']-(100-float(loss)))<=1e-14,'Delivered work conservation')
        for branch,is_positive in zip(alternatives[2]['branches'],(True,False)):
            joint={state:F(mass)*(F(4,5) if state=='cooling-limited' else F(1,10)) for state,mass in zip(outcomes,prior)}
            if not is_positive:joint={state:F(mass)-joint[state] for state,mass in zip(outcomes,prior)}
            mass=sum(joint.values());check(abs(branch['probability']-float(mass))<=1e-14,'Literal report mass')
            for state,value in joint.items():check(abs(branch['posterior_outcomes'][state]-float(value/mass))<=1e-14,'Literal report posterior')
    check(len(data['boundary_cases'])==5,'Boundary case count')
    for case in data['boundary_cases']:
        alternatives={x['kind']:x for x in case['result']['question_values'][0]['alternatives']}
        if case['case']=='unfinished-inspection':
            a=alternatives['inspect_then_act'];check(a['branches'][0]['report']=='unavailable_within_horizon','Unavailable report')
            check(a['expected']['service_deficit_time_s']['value']==25,'Loss continues with no report')
        elif case['case']=='unfinished-action':
            a=alternatives['direct_intervention'];check(a['branches'][0]['action_completed_at_s'] is None,'No premature restoration')
            check(a['branches'][0]['required_resources']['person_s']==200,'Unfinished full commitment')
        elif case['case']=='resource-budget':
            check(alternatives['inspect_then_act']['eligible_for_planning'] is False,'Worst branch budget')
        elif case['case']=='unknown-availability':check(alternatives['direct_intervention']['eligible_for_planning'] is None,'Unknown resource availability')
        else:check(alternatives['inspect_then_act']['branches'][0]['posterior_outcomes'] is None,'Zero report support')
    all_results=[data['default_result']]+[x['result'] for x in data['independent_cases']+data['boundary_cases']]
    for result in all_results:
        check(result['physical_actions']==[] and result['execution_permission'] is False,'No physical actions')
        check(len(result['unmodeled_questions'])==6 and all(x['value'] is None for x in result['unmodeled_questions']),'Unknowns remain unknown')
        for value in result['question_values']:
            for assumption in value['alternatives_by_assumption']:
                if assumption['alternatives'] is None:continue
                for alternative in assumption['alternatives']:
                    check(abs(sum(x['probability'] for x in alternative['branches'])-1)<=1e-14,'Branch normalization')
                    check(alternative['execution_permission'] is False and alternative['information_updates_physical_state'] is False,'No information-as-repair')
    check(read(CAPTURE+'/cli-stdout.raw')==data['default_result'] and blob(DELIVERY,CAPTURE+'/cli-stderr.raw')==b'','Saved CLI')
    result=dict(status='PASS',source=EXECUTION,data_delivery=DELIVERY,assertions=count,
        independent_core_assertions_retained=144,public_inference_rerun=False,physical_rerun=False,full_rerun=False,
        source_pin_counts={k:len(r[k]) for k in ('runtime_sources','authoring_tools','frozen_inputs')},
        scope='Independent literal arithmetic and immutable output audit; no scientific efficacy or field calibration')
    out=ROOT/'.work/20-spec-final-01/saved-output-result.json'
    with out.open('x',encoding='utf-8',newline='\n') as f:f.write(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result))
if __name__=='__main__':main()
