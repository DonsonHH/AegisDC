"""Package the executed action-value gate and audit finite M3 evidence acceptance."""
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import zipfile
ROOT=Path(__file__).resolve().parents[1];WORK=ROOT/'.work'
SOURCE='08a7c6c05662434f8c8d9ae36a15c72040866990'
PACKET=Path('evidence/mainline/engineering/20-root-acceptance')
RAW=ROOT/'runs/mainline-M3-20-root-acceptance-20261105-01'
def read(p):return json.loads(p.read_bytes())
def digest(p):return sha256(p.read_bytes()).hexdigest()
def git(*a):return subprocess.check_output(['git',*a],cwd=ROOT)
def write(p,v,new=True):
    p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('x' if new else 'w',encoding='utf-8',newline='\n') as f:f.write(json.dumps(v,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
def main():
    assert git('rev-parse','HEAD').decode().strip()==SOURCE and not git('status','--porcelain')
    packet=ROOT/PACKET;assert not packet.exists()
    summary,guard=read(RAW/'summary.json'),read(RAW/'source-guard.json');tests=summary['tests']
    assert summary['overall']=='PASS' and tests['run']==tests['executed']==476
    assert tests['errors']==tests['failures']==tests['skipped']==0 and summary['verified_original_files']==20
    assert guard['sources_unchanged'] and guard['head_unchanged'] and guard['source_commit_before']==SOURCE
    assert read(WORK/'20-spec-final-01/final-review.json')['total_assertions']==672
    assert read(WORK/'20-standards-independent-01/review.json')['hard_findings']==[]
    copies={'raw/'+n:RAW/n for n in ('summary.json','tests.log','evidence.json','source-guard.json')};visuals={}
    for stem in ('value-comparison','decision-boundary'):
        png=WORK/'20-visual-qa-01'/(stem+'.png');svg=png.with_suffix('.svg');dest='figures/'+png.name;copies[dest]=png
        source='evidence/mainline/engineering/20-action-value/capture-01/'+svg.name
        assert digest(svg)==digest(ROOT/source)
        visuals[dest]=dict(svg=source,svg_sha256=digest(svg),png_sha256=digest(png))
    assert read(WORK/'20-visual-qa-01/visual-review.json')['open_findings']==0
    reviews={}
    for folder in ('20-spec-final-01','20-standards-root-01','20-standards-independent-01'):
        for p in (WORK/folder).rglob('*'):
            if p.is_file() and '__pycache__' not in p.parts and p.suffix not in {'.pyc','.pyo'}:
                reviews[folder+'/'+p.relative_to(WORK/folder).as_posix()]=p
    support={n:WORK/n for n in ('20-integration-precheck-01.json','20-fresh-proof-01.json',
        '20-independent-information-action-witness-01.json','20-independent-delay-truncation-witness-01.json',
        '20_saved_independent_check.py','run_20_root_acceptance.py','build_20_root_packet.py')}
    for p in (WORK/'20-visual-qa-01').glob('*.json'):support['visual/'+p.name]=p
    declared=sorted(set(copies)|{'.gitattributes','README.md','declaration.json','source-manifest.json',
        'archive-members.json','reviews.zip','support.zip','verify_packet.py'})
    write(packet/'declaration.json',dict(artifacts=declared,terminal_receipt='receipt.json'))
    for n,p in copies.items():q=packet/n;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(p.read_bytes())
    attrs=['# Exact native raw records. Other whitespace checks retained.']
    for n,p in copies.items():
        if n.startswith('raw/') and b'\r\n' in p.read_bytes():attrs.append(n+' -text whitespace=blank-at-eol,blank-at-eof,space-before-tab,cr-at-eol')
    (packet/'.gitattributes').write_text('\n'.join(attrs)+'\n',encoding='utf-8',newline='\n')
    archives={}
    for name,members in (('reviews.zip',reviews),('support.zip',support)):
        archives[name]={}
        with zipfile.ZipFile(packet/name,'x',zipfile.ZIP_DEFLATED) as z:
            for n,p in sorted(members.items()):
                raw=p.read_bytes();z.writestr(n,raw);archives[name][n]=dict(sha256=sha256(raw).hexdigest(),bytes=len(raw))
    write(packet/'archive-members.json',archives)
    capture='evidence/mainline/engineering/20-action-value/capture-01/receipt.json'
    author=dict(execution='83dea5cc8440eee3067b3ce593d3100c8ff00847',data_delivery='2aea84f7a7a5092485587d42bcb0be11b2b50936',
        candidate='20da3a87a65eec9a16407a65d35d041de02e78e1',capture=capture,capture_sha256=digest(ROOT/capture))
    write(packet/'source-manifest.json',dict(tested_source=SOURCE,author=author,visuals=visuals,
        reviews=dict(standards_findings=0,spec_findings=0,independent_assertions=672,core_public_assertions=144,saved_assertions=528)))
    (packet/'verify_packet.py').write_bytes((WORK/'20-verify_packet.py').read_bytes())
    text=f'''# 第20项根验收：检查信息与处置价值

集成执行源`{SOURCE}`通过476项完整回归，全部执行、零失败、零错误、零跳过。20份历史原件通过核对；248个Python与JSON源文件接受Git身份和前后字节守卫。已有144项独立接口断言与528项保存原件核对分别保留，两轴没有未关闭问题。

![服务与人员期望账](figures/value-comparison.png)

在明确声明的100秒二元有限法则中，先验1/4时，暂缓、直接处置、检查后阳性处置分别为25、20、12.5秒服务缺额；人员占用分别0、20、15.5person·s。先验0支持暂缓，先验9/10支持直接处置。这里只验证一个独立预定义计算法则，未据此声称合成设施比较收益或现场校准。

![信息、行动树与分量纲价值](figures/decision-boundary.png)

同一当前认识、联合后果、外生需求和资源约束进入各备选。检查期间和报告延迟继续承担损失；信息本身不修复物理状态。最坏正支持分支必须满足完整资源承诺；未知可用性不当可用，未完成操作不提前恢复。服务、人时、工具时和费用分列，不将问题值相加为全设施总增益。六项尚未识别域风险保留。

## 来源与复核

原作者83de执行、2aea数据及00fd原生CLI换行分类保留。正式工程捕获1次0失败，57个运行源、3个工具、36个输入执行前后相同；三个独立先验、五个边界和默认CLI通过。Root接续原作者交付只核对保存数据，没有重跑捕获、物理或训练。原开发红测试和审查夹具算术纠正保留在[评审ZIP](reviews.zip)；源码/输入/原件身份、解析预期、根守卫及实际图像复核在[支持ZIP](support.zip)。

- [根接受权威](../../../../docs/mainline/evidence/20-root.json)及[M3有限证据门槛](../../../../docs/mainline/evidence/M3.json)
- [作者报告](../20-action-value/README.md)与[模型约定](../../../../docs/mainline/20-action-value-contract.md)
- [原始摘要](raw/summary.json)、[日志](raw/tests.log)、[源码守卫](raw/source-guard.json)
- [声明产物](declaration.json)、[来源清单](source-manifest.json)及[收据](receipt.json)

两张PNG由原SVG本地渲染后实际查看；未声明浏览器QA。复算在本封存提交的新检出中使用`verify_packet.py --delivery-commit COMMIT --output OUTSIDE_CHECKOUT.json`，无全检/推断重跑。M3接受限于已声明的证据、风险及价值接口与有限算例；完整设施现场概率、物理干预效果、恢复闭环和独立机制比较继续由M4–M7验证。当前主票22，总目标active。
'''
    (packet/'README.md').write_text(text,encoding='utf-8',newline='\n')
    assert {p.relative_to(packet).as_posix() for p in packet.rglob('*') if p.is_file()}==set(declared)
    write(packet/'receipt.json',dict(schema='aegisdc-ticket20-root-packet-v1',tested_source=SOURCE,
        delivery_gate='PENDING_COMMIT_AND_FRESH_CHECKOUT',artifacts={n:digest(packet/n) for n in declared},root_tests=tests,
        independent_assertions=672,historical_originals=20,new_full_regressions=0,new_physical_runs=0,registered_research_trials=0,llm_calls=0,training_calls=0))
    write(ROOT/'docs/mainline/evidence/20-root.json',dict(schema='aegisdc-ticket-root-acceptance-v1',ticket='20',status='ACCEPTED',
        actual_root_source=SOURCE,root_tests=tests,packet=PACKET.as_posix(),packet_receipt_sha256=digest(packet/'receipt.json'),author=author,
        independent_assertions=672,core_assertions=144,saved_assertions=528,standards_findings=0,spec_findings=0,
        field_calibration='PENDING',registered_research_trials=0,llm_calls=0,training_calls=0,overall_goal='ACTIVE'))
    p=ROOT/'.scratch/full-facility-mainline/issues/20-action-value.md';s=p.read_text(encoding='utf-8');assert '**Status:** claimed' in s
    s=s.replace('**Status:** claimed','**Status:** resolved',1).replace('- [ ]','- [x]');s+='\nRoot acceptance: `docs/mainline/evidence/20-root.json`; actual source `'+SOURCE+'`,476executed/0skip and672separatepublic/saved assertions. Historical candidate pending receipt remains unchanged; Root authority resolves this ticket.\n';p.write_text(s,encoding='utf-8',newline='\n')
    authorities={}
    for ticket in range(14,21):
        record=ROOT/f'docs/mainline/evidence/{ticket}-root.json';value=read(record);assert value['status']=='ACCEPTED'
        issue=next((ROOT/'.scratch/full-facility-mainline/issues').glob(str(ticket)+'-*.md'))
        assert '**Status:** resolved' in issue.read_text(encoding='utf-8')
        authorities[str(ticket)]=dict(path=record.relative_to(ROOT).as_posix(),sha256=digest(record),source=value['actual_root_source'])
    write(ROOT/'docs/mainline/evidence/M3.json',dict(schema='aegisdc-mainline-milestone-acceptance-v1',milestone='M3',status='ACCEPTED',
        accepted_execution_source=SOURCE,ticket_authorities=authorities,finite_scope=['14source/arrival/expiry/provenance ledger',
        '15public currentframe isolation','16sparsefixed/control observation models','17historical/manual/portable preparation',
        '18finite evidence beliefs with explicitunidentifiedcauses','19joint finiteconsequencesandunknown6domainprobabilities',
        '20same-information finiteinspection/actionvalue with separate units and budgets'],
        integrated_tests=tests,field_calibration='PENDING',registered_effect_trials='NOT_STARTED',inspection_execution='22_PENDING',
        actual_interventions='23_PENDING',verified_closure='24_PENDING',overall_goal='ACTIVE',
        limitation='Finite engineering acceptance of declared evidence/risk/value contracts, not field reliability calibration or proof of method gain.'))
    p=ROOT/'docs/mainline/progress.json';v=read(p);assert v['current_ticket']=='20';v.update(current_ticket='22',current_milestone='M4');v['active_implementations']=[x for x in v['active_implementations'] if x['ticket']!='20'];m=next(x for x in v['milestones'] if x['id']=='M3');m['status']='accepted';m['acceptance_evidence']+=['docs/mainline/evidence/20-root.json','docs/mainline/evidence/M3.json'];write(p,v,False)
    p=ROOT/'docs/current-research.json';v=read(p);v.update(current_primary_ticket='22',current_primary_ticket_assigned=True,active_tickets=['22'],next_ready_unassigned=['23'],M3_acceptance='docs/mainline/evidence/M3.json',implementation='M3finite evidence/risk/value gates accepted. Current22realinspection active;23intervention ready. M4 and complete research objective remain active.');v['runtime_verification_documents'].append((PACKET/'README.md').as_posix());write(p,v,False)
    for name in ('docs/MAINLINE.md','docs/NEXT.md'):
        p=ROOT/name;s=p.read_text(encoding='utf-8');s+='\nM3证据、风险及价值的声明有限工程门槛已通过[M3根审计]('+('mainline/evidence/M3.json')+')与[数据图／476项回归包](../evidence/mainline/engineering/20-root-acceptance/README.md)。当前主票22；实际干预23、恢复24及独立比较仍按主线推进，总目标active。\n';p.write_text(s,encoding='utf-8',newline='\n')
    print(json.dumps(dict(packet=PACKET.as_posix(),artifacts=len(declared),archive_members=sum(map(len,archives.values())),tests=tests,guarded_files=248),ensure_ascii=False))
if __name__=='__main__':main()
