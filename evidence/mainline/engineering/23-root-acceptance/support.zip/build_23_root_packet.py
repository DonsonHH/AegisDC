"""Preserve integrated ticket23 engineering acceptance and independent originals."""
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import zipfile
ROOT=Path(__file__).resolve().parents[1];WORK=ROOT/'.work'
SOURCE='80bfed982eb50b22b020e1a07e5fee1e4531d808'
PACKET=Path('evidence/mainline/engineering/23-root-acceptance')
RAW=ROOT/'runs/mainline-M4-23-root-acceptance-20261105-01'
def read(p):return json.loads(p.read_bytes())
def sha(p):return sha256(p.read_bytes()).hexdigest()
def git(*a):return subprocess.check_output(['git',*a],cwd=ROOT)
def write(p,v,new=True):
    p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('x' if new else 'w',encoding='utf-8',newline='\n') as f:f.write(json.dumps(v,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
def main():
    assert git('rev-parse','HEAD').decode().strip()==SOURCE and not git('status','--porcelain')
    summary=read(RAW/'summary.json');guard=read(RAW/'source-guard.json');tests=summary['tests']
    assert summary['overall']=='PASS' and tests['run']==tests['executed']>490
    assert tests['failures']==tests['errors']==tests['skipped']==0 and summary['verified_original_files']==20
    assert guard['source_commit_before']==SOURCE and guard['sources_unchanged'] and guard['head_unchanged']
    spec=read(WORK/'23-spec-final-01/saved-delivery-01/saved-review.json')
    std=read(WORK/'23-standards-final-01/supplement-final.json')
    assert spec['status']=='PASS' and spec['unresolved_findings']==0 and spec['checks_passed']==335
    assert std['result']=='NO_UNRESOLVED_STANDARDS_BLOCKER_IN_REVIEWED_SCOPE' and std['all_byte_audit_checks_passed']
    assert read(WORK/'23-visual-qa-01/visual-review.json')['open_findings']==0
    packet=ROOT/PACKET;assert not packet.exists()
    copies={'raw/'+n:RAW/n for n in ('summary.json','tests.log','evidence.json','source-guard.json')}
    visuals={}
    for stem in ('intervention-data','intervention-architecture'):
        png=WORK/'23-visual-qa-01'/(stem+'.png');svg=png.with_suffix('.svg')
        source='evidence/mainline/engineering/23-interventions/capture-01/'+svg.name
        assert sha(svg)==sha(ROOT/source)
        name='figures/'+png.name;copies[name]=png;visuals[name]=dict(svg=source,svg_sha256=sha(svg),png_sha256=sha(png))
    reviews={}
    for folder in ('23-spec-final-01','23-standards-final-01'):
        for p in (WORK/folder).rglob('*'):
            if p.is_file() and '__pycache__' not in p.parts and p.suffix not in {'.pyc','.pyo'}:
                reviews[folder+'/'+p.relative_to(WORK/folder).as_posix()]=p
    support={n:WORK/n for n in ('run_23_root_acceptance.py','build_23_root_packet.py','23-author-fresh-proof-01.log')}
    support['visual-review.json']=WORK/'23-visual-qa-01/visual-review.json'
    declared=sorted(set(copies)|{'.gitattributes','README.md','declaration.json','source-manifest.json','archive-members.json','reviews.zip','support.zip','verify_packet.py'})
    write(packet/'declaration.json',dict(artifacts=declared,terminal_receipt='receipt.json'))
    for name,p in copies.items():q=packet/name;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(p.read_bytes())
    attrs=['# Exact native original logs; preserve all other whitespace checks.']
    for name,p in copies.items():
        if name.startswith('raw/') and b'\r\n' in p.read_bytes():attrs.append(name+' -text whitespace=blank-at-eol,blank-at-eof,space-before-tab,cr-at-eol')
    (packet/'.gitattributes').write_text('\n'.join(attrs)+'\n',encoding='utf-8',newline='\n')
    archives={}
    for name,members in (('reviews.zip',reviews),('support.zip',support)):
        archives[name]={}
        with zipfile.ZipFile(packet/name,'x',zipfile.ZIP_DEFLATED) as z:
            for member,p in sorted(members.items()):
                raw=p.read_bytes();z.writestr(member,raw);archives[name][member]=dict(sha256=sha256(raw).hexdigest(),bytes=len(raw))
    write(packet/'archive-members.json',archives)
    capture='evidence/mainline/engineering/23-interventions/capture-01/receipt.json'
    author=dict(execution='15a940c0fec6c5d2f3ba6758b2a4d685f872b9b3',data_delivery='6f9eb41dbae1aaa8e956f8a41914bc0b5a687ec2',candidate='505ce4e9835c79da8a8153cf53c669e379948d87',capture=capture,capture_sha256=sha(ROOT/capture))
    write(packet/'source-manifest.json',dict(tested_source=SOURCE,author=author,visuals=visuals,
        reviews=dict(standards_findings=0,spec_findings=0,independent_assertions=335,
            spec_report_sha256=sha(WORK/'23-spec-final-01/saved-delivery-01/FINAL-SPEC.md'),standards_report_sha256=sha(WORK/'23-standards-final-01/supplement-final.md')),
        preserved_independent_original=dict(physical_calls=6,passed_cases=5,failed_cases=1,passed_assertions=45,total_assertions=46,original_files=126,
            finding='SPEC23-01 decimal timestamp minimum work failure at039f; fixed15e1, formal corrected case separately pinned'),
        author_engineering=dict(attempts=8,failures=0,duration_s=30.25),registered_research_trials=0))
    (packet/'verify_packet.py').write_bytes((WORK/'23-verify_packet.py').read_bytes())
    text=f'''# 第23项根验收：真实处置、延迟与残余响应

集成执行源`{SOURCE}`通过{tests['executed']}项完整回归，全部执行、零失败、零错误、零跳过；20份历史原件与{len(guard['actual_sources'])}个Python/JSON源文件身份通过守卫。独立Spec保存复核335项，两轴无未解决问题。

![实际处置数据](figures/intervention-data.png)

八个冻结工程案例各执行一次，合计30.25模拟秒：全恢复、残余恢复、中断、过滤后真实复检、计算功率调整、备用请求、小数工时及恰好到期授权。网络三秒缺额分别为.9375、1.8125、2.25秒；过滤4→2后仍有残余，5.25秒真实手持采样、5.75秒送达；计算电能4250000J且外生需求不变；备用3.5秒请求仍等待4秒PLC和6秒切换，风机消耗5000J。

![处置与信息边界](figures/intervention-architecture.png)

原独立6次工程探针中的小数时间缺陷和失败保持封存：原45/46断言、5/6案例，不改成全通过。修复采用同一加法完成坐标；单独的正式小数案例通过，严格授权到期仍拒绝效果。捕获前两项打包缺陷、修复与红/绿日志均保留。反馈只覆盖本任务，保持risk_closed=False；第24项负责依据可用恢复证据关闭问题。

原作者源、原始交付、37声明产物及收据、59运行源/3工具/55输入在干净新检出中与Git原件一致，未重跑原捕获。两图由源SVG本地渲染并实际查看。

- [根摘要](raw/summary.json)、[完整日志](raw/tests.log)、[源码守卫](raw/source-guard.json)
- [两轴评审与原失败](reviews.zip)、[新检出和图像复核](support.zip)
- [作者原件](../23-interventions/README.md)、[冻结协议](../../../../docs/mainline/23-intervention-engineering-protocol.json)
- [权威记录](../../../../docs/mainline/evidence/23-root.json)、[清单](declaration.json)、[收据](receipt.json)

使用本提交新检出运行verify_packet.py --delivery-commit COMMIT --output OUTSIDE_CHECKOUT.json，仅复核保存原件。第23项接受后当前主票24；M4、完整42票研究主线持续active。注册效果实验、LLM和训练调用均为零，现场标定待取得，尚未证明策略或AI/RSI收益。
'''
    (packet/'README.md').write_text(text,encoding='utf-8',newline='\n')
    assert {p.relative_to(packet).as_posix() for p in packet.rglob('*') if p.is_file()}==set(declared)
    write(packet/'receipt.json',dict(schema='aegisdc-ticket23-root-packet-v1',tested_source=SOURCE,delivery_gate='PENDING_COMMIT_AND_FRESH_CHECKOUT',
        artifacts={n:sha(packet/n) for n in declared},root_tests=tests,independent_assertions=335,historical_originals=20,
        new_full_regressions=0,new_physical_runs=0,registered_research_trials=0,llm_calls=0,training_calls=0))
    write(ROOT/'docs/mainline/evidence/23-root.json',dict(schema='aegisdc-ticket-root-acceptance-v1',ticket='23',status='ACCEPTED',actual_root_source=SOURCE,
        root_tests=tests,packet=PACKET.as_posix(),packet_receipt_sha256=sha(packet/'receipt.json'),author=author,independent_assertions=335,
        standards_findings=0,spec_findings=0,field_calibration='PENDING',registered_research_trials=0,llm_calls=0,training_calls=0,overall_goal='ACTIVE'))
    p=ROOT/'.scratch/full-facility-mainline/issues/23-intervention-actions.md';s=p.read_text(encoding='utf-8');assert '**Status:** claimed' in s
    s=s.replace('**Status:** claimed','**Status:** resolved',1).replace('- [ ]','- [x]')
    s+='\nRoot acceptance: `docs/mainline/evidence/23-root.json`; actual integrated source `'+SOURCE+'`, '+str(tests['executed'])+' executed checks with zero skips, Spec335 saved checks, no unresolved Standards/Spec findings. Original independent decimal failure and correction preserved.\n'
    p.write_text(s,encoding='utf-8',newline='\n')
    p=ROOT/'docs/mainline/progress.json';v=read(p);assert v['current_ticket']=='23'
    v['current_ticket']='24';v['active_implementations']=[x for x in v['active_implementations'] if x['ticket']!='23']
    m=next(x for x in v['milestones'] if x['id']=='M4');m['acceptance_evidence'].append('docs/mainline/evidence/23-root.json')
    m['progress_scope']='21personnel,22actual inspection and23intervention accepted;24closure and25-28full-loop M4 gates remain.'
    v['liveness_refresh']='Root accepted reviewed23 source; primary24 now on dependency frontier, no live assigned implementation yet.';write(p,v,False)
    p=ROOT/'docs/current-research.json';v=read(p);v.update(current_primary_ticket='24',current_primary_ticket_assigned=False,active_tickets=[],next_ready_unassigned=['24'],
        implementation='Tickets01–23 accepted. Primary24evidence-verified closure ready. M4 full-loop and entire research objective remain active.')
    v['runtime_verification_documents'].append((PACKET/'README.md').as_posix());write(p,v,False)
    for name in ('docs/MAINLINE.md','docs/NEXT.md'):
        p=ROOT/name;s=p.read_text(encoding='utf-8').replace('当前主票23','第23票已接受，当前主票24')
        s+='\n实际处置23通过[根验收、数据图与信息边界架构](../evidence/mainline/engineering/23-root-acceptance/README.md)。当前24按可用恢复证据核验关闭，M4及整体研究目标仍active。\n'
        p.write_text(s,encoding='utf-8',newline='\n')
    print(json.dumps(dict(packet=PACKET.as_posix(),artifacts=len(declared),archive_members=sum(map(len,archives.values())),tests=tests,guarded_files=len(guard['actual_sources'])),ensure_ascii=False))
if __name__=='__main__':main()
