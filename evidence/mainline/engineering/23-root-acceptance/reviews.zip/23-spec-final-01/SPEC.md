# Ticket 23 independent SPEC review

Changes required at 039f20c27a987497da1121f044b3d779143ee799, fixed base cc727d6df127f777bdea906330821ae99e98e7cb.

P1: completed minimum work can be refused. In src/aegis_dc/intervention_execution.py, the minimum-work gate compares exact fractions of binary64 timestamps. With .2s access and 1s declared work, the public facility runner records work from .2 to 1.2 as completed. Fraction(1.2)-Fraction(.2)<1 nevertheless produces NO_EFFECT/professional_work_too_short despite eligible, authorized, in-domain work. This contradicts the completion gate and declared numerical time convention. Preserve genuine below-minimum rejection while qualifying work at its declared minimum. Reproduction inputs and untouched raw output are in runs/decimal-minimum-work/. The parent has this finding and is fixing it.

The pre-execution frozen protocol ran 6 short physical calls, 0 retries, and 9 static cases against 95 verified committed source/config blobs. Five physical cases, 45/46 physical assertions and all 9 static cases pass. Independently specified literal outcomes cover residual network service, actual power/service response with unchanged demand, authority expiry, paid hidden access refusal and residual filter flow. Feedback never auto-closes risk; conservation checks pass.

This is engineering acceptance evidence only. It does not rerun the author full suite or formal captures and does not establish research gain, field calibration, verified repair, policy comparison, AI or RSI effectiveness. A later fix does not rewrite this frozen failure: review its pinned source and saved outputs in a supplement.
