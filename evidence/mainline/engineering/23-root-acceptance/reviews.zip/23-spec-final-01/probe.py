from pathlib import Path
from copy import deepcopy
import datetime, hashlib, json, math, subprocess, sys, traceback
OUT=Path(__file__).resolve().parent;EXPORT=OUT/'export'
sys.path.insert(0,str(EXPORT/'src'))
from aegis_dc.scenario import load_scenario
from aegis_dc.decision_view import DecisionGateway
from aegis_dc.intervention_execution import prepare_intervention
from aegis_dc.plant import simulate_scenario

def dump(path,value):
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')

def fixture(kind='restore_network_capacity',setting=.75,access=.5,worktime=1.25):
    s=load_scenario(EXPORT/'configs/full-facility-mainline-reserve-v6.json')
    for row in s['parameters']:
        if row['id']=='walk_short':row['value']=1
        elif row['id']=='walk_long':row['value']=2
        elif row['id']=='inspection_time':row['value']=worktime
        elif row['id']=='network_service_capacity':row['value']=.25
    nominal=json.loads((EXPORT/'configs/full-facility-decision-v1/public-nominal.json').read_bytes())
    ledger=json.loads((EXPORT/'configs/full-facility-decision-v1/common-ledger.json').read_bytes())
    plan=dict(schema='aegisdc-public-preparation-plan-v1',id='spec23-independent',basis='synthetic_assumption',time_unit='s',decision_times_s=[0],requests=[])
    frame=DecisionGateway(nominal,ledger,plan).next_frame()
    values={p['id']:p['value'] for p in s['parameters']}
    target,interface,worker,qual,unit={
        'restore_network_capacity':('network','inspect_it_service','worker_it','qualified_it_inspection','1'),
        'adjust_compute_request':('compute','inspect_it_service','worker_it','qualified_it_inspection','W'),
        'clean_filter':('filter','inspect_facility_cooling','worker_cooling','qualified_cooling_inspection','1'),
    }[kind]
    task=dict(id='independent-task-'+kind,work_interface_id=interface,target_id=target,crew=[dict(worker_id=worker,qualification_id=qual)],tool_carrier_id=worker,deadline_s=20,source_note='Independent synthetic spec probe; engineering only.')
    timing=dict(schema='aegisdc-workforce-profile-v1',id='independent-timing',facility_id=s['id'],nominal_knowledge_id=nominal['id'],basis='synthetic_assumption',source_note='Independent synthetic timing with positive resource accounting; no calibration.',time_unit='s',access_check_s=access,feedback_latency_s=.375,walk_times_s={e['id']:values[e['duration_parameter']] for e in s['graphs']['access']},work_times_s={x['id']:values[x['duration_parameter']] for d in s['domains'] for x in d['work_interfaces']},shifts={e['id']:[0,values['shift_end_time']] for e in s['entities'] if e['kind']=='worker'})
    work=dict(schema='aegisdc-work-program-v1',id='independent-work',profile=timing,submissions=[dict(frame=frame,task=task)])
    op=dict(id='op23',kind=kind,target_id=target,unit=unit,minimum_work_s=worktime,source_note='Named bounded synthetic setting after actual completion.')
    authority=dict(id='grant23',operation_ids=['op23'],target_ids=[target],starts_at_s=0,expires_at_s=20,basis='synthetic_assumption',source_note='Independent synthetic research authorization.')
    profile=dict(schema='aegisdc-intervention-profile-v1',id='independent-interventions',facility_id=s['id'],nominal_knowledge_id=nominal['id'],basis='synthetic_assumption',source_note='Independent engineering review profile.',time_unit='s',feedback_latency_s=.375,operations=[op],authorizations=[authority])
    actions=dict(schema='aegisdc-intervention-program-v1',profile=profile,bindings=[dict(task_id=task['id'],operation_id='op23',setting=setting,authorization_id='grant23')])
    return s,work,actions

def assess(w,a):
    row=w['submissions'][0]
    return prepare_intervention(row['frame'],w['profile'],row['task'],a['profile'],a['bindings'][0])

def static_probes():
    rows=[]
    for mode in ('unknown binding field','unknown operation kind','unit mismatch','wrong target','unqualified carrier','negative setting','nonfinite setting','bool setting','same public proposal under hidden gate difference'):
        s,w,a=fixture()
        try:
            if mode=='unknown binding field':a['bindings'][0]['parameter_id']='service_demand'
            elif mode=='unknown operation kind':a['profile']['operations'][0]['kind']='write_arbitrary_parameter'
            elif mode=='unit mismatch':a['profile']['operations'][0]['unit']='W'
            elif mode=='wrong target':w['submissions'][0]['task']['target_id']='compute'
            elif mode=='unqualified carrier':
                w['submissions'][0]['task']['crew']=[dict(worker_id='worker_cooling',qualification_id='qualified_cooling_inspection')]
                w['submissions'][0]['task']['tool_carrier_id']='worker_cooling'
            elif mode=='negative setting':a['bindings'][0]['setting']=-1
            elif mode=='nonfinite setting':a['bindings'][0]['setting']=float('nan')
            elif mode=='bool setting':a['bindings'][0]['setting']=True
            before=assess(w,a)
            if mode=='same public proposal under hidden gate difference':
                hidden=deepcopy(s)
                next(p for p in hidden['parameters'] if p['id']=='it_access_permit')['value']=0
                result=dict(id=mode,passed=before==assess(w,a),assessment=before,plant_queried=False)
            else:result=dict(id=mode,passed=mode=='unqualified carrier' and not before['legal_for_planning'],assessment=before)
        except ValueError as error:
            result=dict(id=mode,passed=mode not in {'unqualified carrier','same public proposal under hidden gate difference'},exception=str(error))
        rows.append(result)
    dump(OUT/'static-results.json',rows);return rows

def main():
    manifest=json.loads((OUT/'source-manifest.json').read_bytes())
    protocol_bytes=(OUT/'protocol.json').read_bytes();protocol=json.loads(protocol_bytes)
    expected_sha=(OUT/'protocol.sha256').read_text().split()[0]
    assert hashlib.sha256(protocol_bytes).hexdigest()==expected_sha
    for row in manifest['files']:assert hashlib.sha256((EXPORT/row['path']).read_bytes()).hexdigest()==row['sha256']
    static=static_probes();results=[]; ledger=OUT/'attempts.jsonl'
    assert not ledger.exists(),'Do not overwrite prior attempts'
    for case in protocol['cases']:
        ident=case['id'];folder=OUT/'runs'/ident;folder.mkdir(parents=True,exist_ok=False)
        kind='adjust_compute_request' if ident=='compute-power' else 'clean_filter' if ident=='filter-residual' else 'restore_network_capacity'
        s,w,a=fixture(kind,case.get('setting',.75),case['access_s'],case['work_s'])
        if ident=='compute-power':next(p for p in s['parameters'] if p['id']=='network_service_capacity')['value']=1
        if ident=='authorization-expiry':a['profile']['authorizations'][0]['expires_at_s']=case['expiry_s']
        if ident=='hidden-closed-gate':
            next(e for e in s['entities'] if e['id']=='worker_it')['location_id']='loc_control'
            next(e for e in s['entities'] if e['id']=='tool_it_diagnostic')['location_id']='loc_control'
            next(p for p in s['parameters'] if p['id']=='it_access_permit')['value']=0
        if ident=='filter-residual':next(p for p in s['parameters'] if p['id']=='filter_resistance_multiplier')['value']=4
        inputs=dict(scenario=s,work_program=w,intervention_program=a,duration_s=case['horizon_s'],step_s=.05)
        dump(folder/'inputs.json',inputs)
        stamp=dict(id=ident,status='STARTED',source=manifest['source'],protocol_sha256=expected_sha,inputs_sha256=hashlib.sha256((folder/'inputs.json').read_bytes()).hexdigest(),at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
        with ledger.open('a',encoding='utf-8') as stream:stream.write(json.dumps(stamp)+'\n');stream.flush()
        try:
            r=simulate_scenario(s,duration_s=case['horizon_s'],step_s=.05,work_program=w,intervention_program=a)
            dump(folder/'raw-run.json',r)
            checks=[]
            def check(name,actual,expected):
                ok=math.isclose(actual,expected,rel_tol=1e-12,abs_tol=1e-9) if type(expected) in (int,float) and type(actual) in (int,float) else actual==expected
                checks.append(dict(name=name,actual=actual,expected=expected,passed=ok))
            expected=case['expected'];audit=r['intervention_private_audit']['events'];event=audit[0] if audit else {};feedback=r['intervention_public_feedback'];record=r['work_records'][0]
            if 'completion_s' in expected:check('work completion',record.get('completed_at_s'),expected['completion_s'])
            for key in ('delivered_service_unit_s','service_deficit_time_s','demand_service_unit_s','worker_work_person_s'):
                if key in expected:check(key,r['summary'][key],expected[key])
            if 'outcome' in expected:check('intervention outcome',event.get('outcome'),expected['outcome'])
            if 'reason' in expected:check('intervention reason',event.get('reason'),expected['reason'])
            if 'feedback_s' in expected:check('feedback arrives',feedback[0]['arrived_at_s'] if feedback else None,expected['feedback_s'])
            if 'observed_s' in expected:check('feedback observed',feedback[0]['observed_at_s'] if feedback else None,expected['observed_s'])
            if 'travel_person_s' in expected:check('travel resource',r['summary']['worker_travel_person_s'],expected['travel_person_s'])
            if 'compute_energy_J' in expected:
                energy=math.fsum(row['domains']['power']['actual_powers_W']['compute']*(nxt['time_s']-row['time_s']) for row,nxt in zip(r['trace'],r['trace'][1:]))
                check('compute energy',energy,expected['compute_energy_J'])
                after=next(t for t in r['trace'] if t['time_s']==expected['completion_s'])
                check('post effect compute actual W',after['domains']['power']['actual_powers_W']['compute'],case['setting'])
            if ident=='filter-residual':
                first=r['trace'][0]['domains']['facility_cooling']['lake_pump']['volume_flow_m3_s']
                after=next(t for t in r['trace'] if t['time_s']==expected['completion_s'])['domains']['facility_cooling']['lake_pump']['volume_flow_m3_s']
                check('initial flow squared',first*first,1/340);check('residual flow squared',after*after,1/260);check('residual below nominal clean',after<.1,True)
            check('risk never auto-closed',all(not f['risk_closed'] for f in feedback),True)
            check('mass conservation tolerance',r['summary']['max_mass_residual_kg']<=1e-9,True)
            check('energy conservation tolerance',abs(r['summary']['whole_run_energy_residual_J'])<1e-4,True)
            result=dict(id=ident,status='COMPLETED',passed=all(c['passed'] for c in checks),checks=checks,summary=r['summary'],audit=audit,feedback=feedback,work_records=r['work_records'])
        except Exception as error:
            result=dict(id=ident,status='FAILED',passed=False,exception_type=type(error).__name__,exception=str(error),traceback=traceback.format_exc())
        dump(folder/'checks.json',result);results.append(result)
        with ledger.open('a',encoding='utf-8') as stream:stream.write(json.dumps(dict(id=ident,status=result['status'],passed=result['passed'],at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat()))+'\n')
    dump(OUT/'probe-results.json',dict(static=static,physical=results,physical_calls=len(results),static_cases=len(static),passed_physical=sum(r['passed'] for r in results)))
    for row in manifest['files']:assert hashlib.sha256((EXPORT/row['path']).read_bytes()).hexdigest()==row['sha256']
    dump(OUT/'source-guard-after.json',dict(source=manifest['source'],export_verified_file_count=len(manifest['files']),no_cache_files=not any(EXPORT.rglob('__pycache__')),mainline_head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),checked_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat()))
    print(json.dumps(dict(static_passed=sum(r['passed'] for r in static),static_count=len(static),physical_passed=sum(r['passed'] for r in results),physical_count=len(results),failed=[dict(id=r['id'],checks=[c for c in r.get('checks',[]) if not c['passed']],exception=r.get('exception')) for r in results if not r['passed']]),ensure_ascii=False))
if __name__=='__main__':main()
