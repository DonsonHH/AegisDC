from pathlib import Path
import subprocess,json,hashlib,math,datetime
ROOT=Path.cwd();OUT=Path(__file__).resolve().parent
EXEC='15a940c0fec6c5d2f3ba6758b2a4d685f872b9b3';DELIVERY='6f9eb41dbae1aaa8e956f8a41914bc0b5a687ec2'
CAP='evidence/mainline/engineering/23-interventions/capture-01';AUTHOR=Path('C:/Users/Donson/.codex/worktrees/mainline23-intervention/Renly')
checks=[]
def check(name,ok,actual=None,expected=None):
 checks.append(dict(name=name,passed=bool(ok),actual=actual,expected=expected));assert ok,name
def close(name,actual,expected,tol=1e-9):check(name,math.isclose(actual,expected,rel_tol=0,abs_tol=tol),actual,expected)
def sha(raw):return hashlib.sha256(raw).hexdigest()
def batch(revision,names):
 names=list(names);raw=subprocess.check_output(['git','cat-file','--batch'],input=''.join(revision+':'+n+chr(10) for n in names).encode());offset=0;got={}
 for n in names:
  end=raw.index(bytes([10]),offset);header=raw[offset:end].split();assert len(header)==3 and header[1]==b'blob',(n,header)
  size=int(header[2]);start=end+1;got[n]=raw[start:start+size];offset=start+size+1
 assert offset==len(raw);return got
def dump(path,value):path.write_text(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+chr(10),encoding='utf-8')
paths=subprocess.check_output(['git','ls-tree','-rz','--name-only',DELIVERY,CAP]).decode().strip(chr(0)).split(chr(0));data=batch(DELIVERY,paths)
for name,raw in data.items():
 p=OUT/'export'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw)
def read(name):return json.loads(data[CAP+'/'+name])
receipt=read('receipt.json');attempt=read('attempt.json');ledger=[json.loads(line) for line in data[CAP+'/attempts.jsonl'].splitlines()]
names=list({p for group in receipt['pinned'].values() for p in group});executed=batch(EXEC,names);delivered=batch(DELIVERY,names);protocol=json.loads(executed['docs/mainline/23-intervention-engineering-protocol.json'])
check('receipt pass',receipt['status']=='PASS' and receipt['failures']==0 and receipt['source_head_and_bytes_unchanged'])
check('receipt execution',receipt['execution_commit']==EXEC and attempt['execution_commit']==EXEC)
check('attempt accounting',receipt['physical_attempts']==receipt['physical_completed']==8 and len(ledger)==16)
check('horizon',sum(c['duration_s'] for c in protocol['cases'])==30.25)
expected=set(protocol['durable_root'])|{c['id']+'/'+n for c in protocol['cases'] for n in protocol['durable_per_case']}
check('durable set',len(data)==38 and len(receipt['artifacts'])==37 and set(receipt['artifacts'])==expected and {p.removeprefix(CAP+'/') for p in data}==expected|{'receipt.json'})
for n,h in receipt['artifacts'].items():check('artifact hash '+n,sha(data[CAP+'/'+n])==h)
for role,group in receipt['pinned'].items():
 for n,h in group.items():check('execution delivery pin '+role+' '+n,sha(executed[n])==h==sha(delivered[n]) and sha((AUTHOR/n).read_bytes())==h)
check('interpreter hash',sha(Path(attempt['executable']).read_bytes())==attempt['executable_sha256'])
results=[]
for i,c in enumerate(protocol['cases']):
 ident=c['id'];run=read(ident+'/run.json');trace=[json.loads(t) for t in data[CAP+'/'+ident+'/private-state.jsonl'].splitlines()];balances=[json.loads(t) for t in data[CAP+'/'+ident+'/balances.jsonl'].splitlines()];inputs=json.loads(executed[c['input']]);e=c['expected'];s=run['summary'];events=run['intervention_private_audit']['events'];fbs=run['intervention_public_feedback'];event=events[0];fb=fbs[0];count=len(checks)
 pair=ledger[2*i:2*i+2];check(ident+' ledger',[x['case'] for x in pair]==[ident]*2 and [x['status'] for x in pair]==['STARTED','COMPLETED'] and all(x['execution_commit']==EXEC for x in pair))
 check(ident+' runtime identity',run['code_identity']['git_commit']==EXEC and not run['code_identity']['implementation_has_changes'] and all(sha(executed[n])==h for n,h in run['code_identity']['files'].items()))
 check(ident+' inputs',run['inputs']['work_program']==inputs['work_program'] and run['inputs']['intervention_program']==inputs['intervention_program'] and run['inputs']['boundary_events']==inputs['boundary_events'] and read(ident+'/scenario.json')==inputs['model'])
 for n,row in run['artifacts'].items():check(ident+' raw hash '+n,sha(data[CAP+'/'+ident+'/'+n])==row['sha256'])
 check(ident+' classification',run['research_trials']==run['model_calls']==run['training_calls']==0 and run['field_calibration']=='PENDING' and run['state_visibility']=='PRIVATE_PLANT_EVALUATOR_ONLY')
 check(ident+' complete trace',trace[0]['time_s']==0 and trace[-1]['time_s']==c['duration_s'] and len(trace)==len(balances)+1)
 check(ident+' intervals',all(b['start_s']==p['time_s'] and b['end_s']==q['time_s'] and 0<b['end_s']-b['start_s']<=.01+1e-9 for b,p,q in zip(balances,trace,trace[1:])))
 check(ident+' single terminal',len(events)==len(fbs)==1);check(ident+' outcome',event['outcome']==e['outcome'])
 if 'reason' in e:check(ident+' reason',event['reason']==e['reason'])
 if 'applied_at_s' in e:close(ident+' completion',event['applied_at_s'],e['applied_at_s']);check(ident+' completed actual work',run['work_records'][0]['status']=='completed')
 close(ident+' retained demand',s['demand_service_unit_s'],c['duration_s'])
 for k,target in [('delivered','delivered_service_unit_s'),('deficit','service_deficit_time_s')]:
  if k in e:close(ident+' '+k,s[target],e[k])
 integral=math.fsum(p['domains']['it_service']['delivered']*(q['time_s']-p['time_s']) for p,q in zip(trace,trace[1:]));close(ident+' trace service integral',integral,s['delivered_service_unit_s']);close(ident+' loss identity',s['demand_service_unit_s']-s['delivered_service_unit_s'],s['service_deficit_time_s'])
 check(ident+' conservation',abs(s['whole_run_energy_residual_J'])<1e-4 and s['max_mass_residual_kg']<=1e-9)
 check(ident+' feedback',fb['risk_closed'] is False and fb['outcome']==event['outcome'] and fb['observed_at_s']==event['observed_at_s'] and fb['arrived_at_s']>=fb['observed_at_s']+.5 and not ({'old_value','new_value','parameter_id','private_state'}&set(fb)))
 if ident=='decimal-completion':
  w=run['work_records'][0];close('decimal start',w['work_started_at_s'],.2);close('decimal completion',w['completed_at_s'],1.2);close('decimal work cost',s['worker_work_person_s'],1);close('decimal feedback',fb['arrived_at_s'],1.7);check('decimal repaired',event['outcome']=='APPLIED' and w['completed_at_s']==w['work_started_at_s']+1)
 if ident=='expired-authority':
  check('expiry exclusive',event['outcome']=='NO_EFFECT' and event['reason']=='authorization_unavailable_at_completion' and run['work_records'][0]['completed_at_s']==inputs['intervention_program']['profile']['authorizations'][0]['expires_at_s']==1.25);close('expiry work paid',s['worker_work_person_s'],1)
 if ident=='compute-power':
  energy=math.fsum(p['domains']['power']['actual_powers_W']['compute']*(q['time_s']-p['time_s']) for p,q in zip(trace,trace[1:]));close('compute energy',energy,4250000);at=next(p for p in trace if p['time_s']==1.25);check('compute power timing',all(p['domains']['power']['actual_powers_W']['compute']==2000000 for p in trace if p['time_s']<1.25) and at['domains']['power']['actual_powers_W']['compute']==1000000)
 if ident=='filter-later-inspection':
  first=trace[0]['domains']['facility_cooling']['lake_pump']['volume_flow_m3_s'];after=next(p for p in trace if p['time_s']==3.25)['domains']['facility_cooling']['lake_pump']['volume_flow_m3_s'];close('filter original law',first*first,1/340);close('filter residual law',after*after,1/180);check('filter below clean',first<after<.1);r=run['inspection_public_snapshot']['records'][0];close('filter actual reading',r['value'],math.sqrt(1/180));close('filter observed',r['observed_at_s'],5.25);close('filter arrived',r['arrived_at_s'],5.75);check('filter actual later work',run['work_records'][1]['status']=='completed' and run['work_records'][1]['completed_at_s']==5.25);check('inspection origin',r['provenance']==run['inspection_public_feedback'][0]['provenance'])
 if ident=='backup-request':
  p={x['time_s']:x for x in trace};state=p[4]['domains']['backup']['reserve_states']['cooling'];check('backup no extra sample',p[3.5]['domains']['backup']['backup_tower_mode']=='primary' and all(x['domains']['backup']['backup_tower_mode']=='primary' for x in trace if 3.5<=x['time_s']<4));check('backup switch schedule',state['requested_at_s']==4 and state['ready_at_s']==6 and p[6]['domains']['backup']['backup_tower_mode']=='active');close('backup fan paid',s['backup_fan_energy_J'],5000);check('backup heat paid',s['backup_water_heat_J']>0)
 results.append(dict(id=ident,status='PASS',checks=len(checks)-count,trace_points=len(trace),balances=len(balances),outcome=event['outcome'],delivered=s['delivered_service_unit_s'],deficit=s['service_deficit_time_s'],feedback=fb,energy_residual_J=s['whole_run_energy_residual_J']))
original=ROOT/'.work/23-spec-final-01';old=json.loads((original/'delivery-manifest.json').read_bytes())
for row in old['files']:assert sha((original/row['path']).read_bytes())==row['sha256']
result=dict(status='PASS',unresolved_findings=0,execution=EXEC,delivery=DELIVERY,physical_calls_in_supplement=0,full_suite_runs=0,inference_calls=0,formal_attempts=8,formal_duration_s=30.25,durable_artifacts=37,terminal_receipts=1,pin_counts={k:len(v) for k,v in receipt['pinned'].items()},checks_passed=len(checks),checks=checks,cases=results,original_independent_packet_unchanged_files=len(old['files']),original_independent_failure_retained=True,root_integrated_regression='PENDING_PARENT_GATE',checked_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
dump(OUT/'saved-review.json',result);dump(OUT/'export-manifest.json',dict(delivery=DELIVERY,files=[dict(path=n,sha256=sha(raw),bytes=len(raw)) for n,raw in data.items()]))
print(json.dumps({k:v for k,v in result.items() if k not in {'checks','cases'}}))
