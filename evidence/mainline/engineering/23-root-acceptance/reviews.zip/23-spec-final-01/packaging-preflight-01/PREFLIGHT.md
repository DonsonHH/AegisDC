# Ticket 23 capture preflight

Static PASS at 15a940c0fec6c5d2f3ba6758b2a4d685f872b9b3. No physical calls executed. All eight frozen inputs and30.25s total agree with the finite protocol. Independently calculated capacity, power, hydraulic, decimal-work, strict-expiry and backup timing values match. Later actual inspection remains5.25s observation/5.75s arrival, with residual flow below the fully clean reference. Existing protection settles before crew completion; post-effect reserves use sampled=False, so3.5s backup request waits until4s PLC and6s connection.

The initial e139 packaging had deferred all expected-value checks until after eight calls, contradicting stop-on-failure. This concrete preflight issue was reported before capture and fixed: each saved case is checked before COMPLETED or the next attempt. The final source guard now records a failure count and cause. No capture blocker remains.

Prepared inputs are engineering fixtures; literal oracles derive from prior independent witnesses. Hashes identify immutable input/tool/runtime blobs. Formal output and fresh delivery verification are pending. This supplement preserves the original6-call review packet, including its decimal failure.
