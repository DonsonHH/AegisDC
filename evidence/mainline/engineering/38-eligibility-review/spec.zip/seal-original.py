"""Preserve the initial38 finding and its closed raw log."""
import hashlib,json
from pathlib import Path
out=Path(__file__).resolve().parent
sha=lambda raw:hashlib.sha256(raw).hexdigest()
files={p.name:dict(sha256=sha(p.read_bytes()),bytes=p.stat().st_size)
    for p in sorted(out.iterdir()) if p.is_file() and p.name!='original-manifest.json'}
with (out/'original-manifest.json').open('x',encoding='utf-8',newline='\n') as stream:
    stream.write(json.dumps(dict(schema='aegisdc-spec38-original-finding-packet-v1',
        source='9948d55d4a42df4cf299cec4b41c509bda2fdc5f',status='FINDING_REQUIRES_CORRECTION',
        artifacts=files,excluded=['Self-hash','Runtime caches']),indent=2)+'\n')
print(json.dumps(dict(status='SEALED_ORIGINAL_FINDING',artifacts=len(files),
    manifest_sha256=sha((out/'original-manifest.json').read_bytes()))))
