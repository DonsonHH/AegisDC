"""Close the original38 P2 using only its additive qualitative revision."""
import hashlib,json
from pathlib import Path
import subprocess

ROOT=Path('C:/Users/Donson/Documents/ChatGPT/Renly')
OUT=Path(__file__).resolve().parent
OLD='9948d55d4a42df4cf299cec4b41c509bda2fdc5f'
SOURCE='2a17aa5628af343427ee3057bdc5f197bf9cf5b1'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
git=lambda *args:subprocess.check_output(['git',*args],cwd=ROOT)
hashes={}

def blob(path,source=SOURCE):
    raw=git('show',source+':'+path)
    hashes[source+':'+path]=dict(sha256=sha(raw),bytes=len(raw))
    return raw

def save(name,value):
    with (OUT/name).open('x',encoding='utf-8',newline='\n') as stream:
        stream.write(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n')

original_manifest=sha((OUT/'original-manifest.json').read_bytes())
assert original_manifest=='a3284c9a479df0d094e9e9f6f7d65e639ccfc10a1d7f254e0fde5f42e1680ef7'
for path in ('docs/mainline/38-eligibility-audit.md','docs/mainline/38-eligibility-proposal.json'):
    assert blob(path)==blob(path,OLD)
audit=blob('docs/mainline/38-eligibility-audit-v2.md').decode()
decision=json.loads(blob('docs/mainline/38-eligibility-decision-v2.json'))
revision=json.loads(blob('docs/mainline/38-eligibility-revision.json'))
progress=json.loads(blob('docs/mainline/progress.json'))
assert decision['decision']=='ELIGIBLE_FOR_NARROW_STRUCTURED_POLICY_FACTOR'
assert decision['status']=='PROPOSED_PENDING_CORRECTION_REVIEW'
assert decision['original_disposition']=='WITHDRAWN_AFTER_SPEC_P2; retained unmodified'
assert revision['original_source']==OLD and revision['original_disposition']=='WITHDRAWN_NOT_ACCEPTED'
assert revision['research_trials_before']==revision['research_trials_after']==decision['registered_runs_unchanged']==180
assert decision['overall_goal']=='INCOMPLETE'
assert decision['measured_AI_gain'] is None and decision['measured_RSI_gain'] is None
assert decision['not_measured']==['AI policy increment','Language understanding','Sitewide task discovery','RSI improvement-process increment']
for key in ('new_physical_calls','new_selectors','new_inference_or_training','new_LLM_experiment_calls','new_nonce_reads','new_research_trials'):
    assert decision[key]==0
assert 'ready-for-agent; unrun; no gate deferral'==decision['lifecycle']['39']
assert decision['lifecycle']['40']=='unrun; depends on39'
assert decision['lifecycle']['41']==decision['lifecycle']['42']=='not started; dependencies unresolved'
assert '可以提出可归因的窄比较；尚未执行' in audit
assert '不能据此否决结构化策略比较' in audit
assert '“还没有选择新假设”不等于“不具备科学资格”' in audit
assert '不标`deferred-by-gate`' in audit and '不宣称42或总目标完成' in audit
assert '不在本次增加新试验' in audit
assert '不能在已见180次上挑规则后再称独立确认' in audit
assert '模型调用、失败、令牌、时间和人工帮助另计' in audit
assert progress['status']=='active' and progress['current_ticket']=='38'
assert progress['research_trials']['attempts']==180
assert '180 original registered runs completed' in progress['liveness_refresh']
issue39=blob('.scratch/full-facility-mainline/issues/39-agent-increment.md').decode()
assert '**Status:** ready-for-agent' in issue39 and '**Blocked by:** 38' in issue39
for number,path in [('40','40-rsi-increment.md'),('41','41-increment-conclusion.md'),('42','42-research-closeout.md')]:
    text=blob('.scratch/full-facility-mainline/issues/'+path).decode()
    assert '**Status:** ready-for-agent' in text
assert '**Blocked by:** 39' in blob('.scratch/full-facility-mainline/issues/40-rsi-increment.md').decode()
assert '**Blocked by:** 38, 39, 40' in blob('.scratch/full-facility-mainline/issues/41-increment-conclusion.md').decode()
assert '**Blocked by:** 37, 41' in blob('.scratch/full-facility-mainline/issues/42-research-closeout.md').decode()
assert not git('diff','--name-only',OLD,SOURCE,'--','src','scripts','configs','tests','evidence','paper').strip()
facts=json.loads((OUT/'independent-eligibility-facts.json').read_bytes())
assert len(facts['identified_worlds'])==12 and len(facts['identified_families'])==3 and facts['min_common_paid_candidates']>=2
save('correction-closure.json',dict(source=SOURCE,original_source=OLD,status='PASS',finding='38SPEC-P2-01',
    disposition='CLOSED_BY_ADDITIVE_REVISION',original_packet_sha256=original_manifest,
    reasoning='Existing structured choice and service/cost interfaces can isolate a narrow solver factor. Revised eligibility recognizes this without claiming an implemented AI policy, gain, language understanding or RSI process.',
    lifecycle='39 ready/unrun after38 acceptance, separate protocol/new confirmation still owed;40–42 depend on unresolved work. User reading checkpoint does not masquerade as NOT_ELIGIBLE or overall completion.',
    preserved='Original9948 proposal/audit and P2 raw review artifacts unchanged;180 original runs and scientific source unchanged.',
    measured_AI_gain=None,measured_RSI_gain=None,project_calls=0,tests=0,models=0,selectors=0,
    builder_calls=0,checker_calls=0,nonce_reads=0,HMAC_calls=0,new_trials=0))
save('correction-source-hashes.json',hashes)
save('receipt.json',dict(status='PASS_SPEC_ELIGIBILITY_CORRECTION',source=SOURCE,original_source=OLD,
    original_P2_preserved=True,original_P2_closed=True,unresolved=0,
    decision=decision['decision'],overall_goal='INCOMPLETE',ticket39='READY_UNRUN_NOT_GATE_DEFERRED',
    physical_or_AI_execution_authorized=False,
    scope='Qualitative testability approval only; independent next-protocol approval and new conditions required before any future experiment.',
    project_calls=0,tests=0,models=0,selectors=0,nonce_reads=0,new_trials=0))
report='''Spec：2a17aa56通过，原9948的P2已闭合，原发现与失败原文保留。

现有12工况/3族的共享选择、两任务与服务/成本后果，支持窄的结构化求解器替换比较；这只判断可检验性，不证明AI有益。修订正确区分语言理解、任务发现、RSI过程尚未操作化和效果未测。

39保持ready未运行，不按资格门槛延期；40–42依赖未完成，总目标INCOMPLETE。38后阅读检查点来自本轮交付范围，未替代科学资格。未来仍须冻结独立因素、成本/失败及新确认条件。180运行、负结果及原件未变。本审查仅静态/字面核对，零项目、模型、策略、测试或nonce调用。
'''
assert len(report)<400
with (OUT/'report.md').open('x',encoding='utf-8',newline='\n') as stream:stream.write(report)
print(json.dumps(dict(status='PASS_SPEC_CORRECTION',source=SOURCE,closed_findings=1,unresolved=0,
    original_manifest_sha256=original_manifest,project_calls=0)))
