"""Static Spec audit of the original38 decision; no project or nonce calls."""
from datetime import datetime,timezone
import hashlib
import json
from pathlib import Path
import subprocess

ROOT=Path('C:/Users/Donson/Documents/ChatGPT/Renly')
OUT=Path(__file__).resolve().parent
BASE='00cfc313eaaf99d5cb833334cdc0af6df4c7d8b7'
SOURCE='9948d55d4a42df4cf299cec4b41c509bda2fdc5f'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
git=lambda *args:subprocess.check_output(['git',*args],cwd=ROOT)
hashes={}

def blob(path,source=SOURCE):
    raw=git('show',source+':'+path)
    hashes[source+':'+path]=dict(sha256=sha(raw),bytes=len(raw))
    return raw

def save(name,data):
    with (OUT/name).open('x',encoding='utf-8',newline='\n') as stream:
        stream.write(json.dumps(data,ensure_ascii=False,indent=2,allow_nan=False)+'\n')

save('original-start.json',dict(source=SOURCE,base=BASE,started_utc=datetime.now(timezone.utc).isoformat(),scope='STATIC_ELIGIBILITY_ARGUMENT_AND_SAVED_METADATA_ONLY'))
authority_paths=['docs/meetings/2026-11-03-research-reset.md','docs/MAINLINE.md',
    '.scratch/full-facility-mainline/spec.md','docs/agents/issue-tracker.md',
    '.scratch/full-facility-mainline/issues/38-agent-eligibility.md',
    '.scratch/full-facility-mainline/issues/39-agent-increment.md',
    '.scratch/full-facility-mainline/issues/40-rsi-increment.md',
    '.scratch/full-facility-mainline/issues/41-increment-conclusion.md',
    '.scratch/full-facility-mainline/issues/42-research-closeout.md']
texts={path:blob(path).decode() for path in authority_paths}
audit=blob('docs/mainline/38-eligibility-audit.md').decode()
proposal=json.loads(blob('docs/mainline/38-eligibility-proposal.json'))
primary=json.loads(blob('evidence/mainline/research/34-paired-analysis/results.json'))
protocol=json.loads(blob('docs/mainline/30-comparison-protocol-v1.json'))
baseline_report=blob('paper/mainline-report-20261108/report.md').decode()
reference=json.loads(blob('evidence/mainline/engineering/26-candidate/reference/online-baseline-inspect.json'))
blob('docs/mainline/evidence/M6.json')
opportunities=primary['opportunities']
identified=[name for name,record in opportunities.items() if record['identified']]
assert set(identified)==set(primary['identified_world_ids']) and len(identified)==12
families={record['world_id']:record['family'] for record in primary['pairs']}
identified_families=sorted({families[name] for name in identified})
assert len(identified_families)==3
assert all(opportunities[name]['same_public_frame_and_history'] is True
    and len(opportunities[name]['common_eligible_paid'])>=2
    and opportunities[name]['baseline_intent']!=opportunities[name]['candidate_intent'] for name in identified)
assert len(reference['dispatch_program']['policy_program']['candidates'])==2
assert [(r['id'],r['kind']) for r in reference['dispatch_program']['policy_program']['candidates']]==[('first-inspection','inspect'),('first-action','intervene')]
assert primary['status']=='NO_PRACTICAL_GAIN' and primary['mean_service_delta_s']==.03515625
assert '同一设施/证据/工具预算' in texts['.scratch/full-facility-mainline/issues/39-agent-increment.md']
assert '普通方法与单独智能体因素' in texts['.scratch/full-facility-mainline/issues/39-agent-increment.md']
assert '理解/决策/经验改进增量' in texts['docs/MAINLINE.md']
assert proposal['decision']=='NOT_ELIGIBLE_CURRENT_STUDY'
assert proposal['measured_AI_gain'] is None and proposal['measured_RSI_gain'] is None
assert '直接接入LLM只能得到另一种策略输出' in audit
assert '没有带可核对语义真值的自由工单' in audit
assert 'deferred-by-gate' in proposal['conditional_effect']['39']
assert '候选平均服务收益尚未成立，AI/RSI增量尚未试验' in baseline_report
assert not git('diff','--name-only',BASE,SOURCE,'--','src','scripts','configs','tests','evidence').strip()
with (OUT/'original-9948-audit.md').open('x',encoding='utf-8',newline='\n') as stream:stream.write(audit)
save('original-9948-proposal.json',proposal)
finding=dict(id='38SPEC-P2-01',severity='P2',source=SOURCE,status='OPEN_AT_9948',
    file='docs/mainline/38-eligibility-audit.md',lines=[11,17,19,32],
    requirement_refs=[dict(path='.scratch/full-facility-mainline/spec.md',lines=[50,51]),
        dict(path='.scratch/full-facility-mainline/issues/39-agent-increment.md',line=3),
        dict(path='docs/MAINLINE.md',line=33)],
    finding='The blanket NOT_ELIGIBLE proposal conflates absence of free-text/task-discovery/recursive-process endpoints with absence of an independently testable AI decision factor. The original39 contract includes structured decision-policy replacement at equal information/actions/budgets.',
    evidence='12 same-public-history divergent worlds over3 families have at least2 shared eligible paid tasks; service/cost consequences already exist. Replacing only the decision solver is conceptually attributable without claiming language understanding, task discovery, multi-agent coordination or RSI.',
    consequence='A lack of a selected future hypothesis or protocol does not establish that the existing benchmark is scientifically ineligible. It cannot by itself justify deferring39 through the NOT_ELIGIBLE branch.',
    correction='Separate narrow structured-policy eligibility from unoperationalized language/discovery/RSI factors. A user-directed reading checkpoint may leave39 ready/unrun; it must not claim measured effects or premature completion of40–42.',
    limits='This is a logical testability counterexample, not an implemented AI candidate, new protocol, gain claim or experiment.')
save('original-findings.json',dict(source=SOURCE,status='FINDING_REQUIRES_CORRECTION',findings=[finding]))
save('independent-eligibility-facts.json',dict(source=SOURCE,baseline_evidence='Saved primary metadata; upstream native verification reused, not rerun.',
    identified_worlds=identified,identified_families=identified_families,min_common_paid_candidates=min(len(opportunities[name]['common_eligible_paid']) for name in identified),
    comparable_choice_condition=True,old_primary_unchanged=True,
    supportable_current_limits=['Current180-run study has no AI/RSI effects measured.','Current task inputs do not evaluate free-text understanding or general task discovery.','No separately evaluated static/ordinary-feedback/recursive-generation process exists.'],
    unsupported_inference='Those capability-specific omissions do not exclude a narrower same-interface decision solver comparison.',
    acceptable_revision_direction='ELIGIBLE_FOR_NARROW_STRUCTURED_POLICY_FACTOR;39ready/unrun at user reading checkpoint;40–42 dependencies and incomplete overall objective preserved.',
    project_calls=0,tests=0,model_calls=0,selectors=0,builder_calls=0,checker_calls=0,nonce_reads=0,HMAC_calls=0,new_trials=0))
save('original-source-hashes.json',hashes)
report='''Spec：9948d55d存在1项P2，不能按原提案接受。

原39允许同设施、同证据/动作/预算的独立智能体因素；并未要求自由工单、任务发现或多作业标签。现有12工况、3族、共同可用两付费任务及服务/成本后果，允许窄的求解器替换比较。缺少语言/RSI端点不等于这一因素不可检验，“尚未选定新假设”不能单独推出NOT_ELIGIBLE。

建议承认窄结构化策略因素有资格，语言理解/任务发现/RSI另列未操作化；按用户阅读检查点令39保持ready未运行，40–42依赖和总体目标未完成状态保持。这只判断可检验性，不宣称AI收益或要求立即试验。原负结果、未测null和180运行均保持；本审查零项目/模型/测试/nonce调用。
'''
assert len(report)<400
with (OUT/'original-report.md').open('x',encoding='utf-8',newline='\n') as stream:stream.write(report)
print(json.dumps(dict(status='FINDING_REQUIRES_CORRECTION',source=SOURCE,findings=1,
    identified_worlds=len(identified),families=len(identified_families),project_calls=0)))
