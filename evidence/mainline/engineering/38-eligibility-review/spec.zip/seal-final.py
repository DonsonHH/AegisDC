"""Seal both original finding and separately logged corrective review."""
import hashlib,json
from pathlib import Path
out=Path(__file__).resolve().parent
sha=lambda raw:hashlib.sha256(raw).hexdigest()
original=json.loads((out/'original-manifest.json').read_bytes())
for name,entry in original['artifacts'].items():
    raw=(out/name).read_bytes();assert sha(raw)==entry['sha256'] and len(raw)==entry['bytes'],name
receipt=json.loads((out/'receipt.json').read_bytes())
assert receipt['status']=='PASS_SPEC_ELIGIBILITY_CORRECTION' and receipt['unresolved']==0
manifest=dict(schema='aegisdc-independent-spec38-final-review-v1',
    original_source='9948d55d4a42df4cf299cec4b41c509bda2fdc5f',
    source='2a17aa5628af343427ee3057bdc5f197bf9cf5b1',status='PASS_CORRECTION',
    original_findings=1,closed_findings=1,unresolved=0,authoritative_report='report.md',
    original_manifest_sha256=sha((out/'original-manifest.json').read_bytes()),
    artifacts={p.name:dict(sha256=sha(p.read_bytes()),bytes=p.stat().st_size)
        for p in sorted(out.iterdir()) if p.is_file() and p.name!='final-manifest.json'},
    excluded=['Self-hash','Runtime caches'])
with (out/'final-manifest.json').open('x',encoding='utf-8',newline='\n') as stream:
    stream.write(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(dict(status='PASS_CORRECTION',source=manifest['source'],artifacts=len(manifest['artifacts']),
    final_manifest_sha256=sha((out/'final-manifest.json').read_bytes()),project_calls=0)))
