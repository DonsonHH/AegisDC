"""Narrow fixed-source eligibility revision/record closure; no project calls."""
from pathlib import Path,PurePosixPath
import hashlib,json,re,subprocess
ROOT=Path(r"C:\Users\Donson\Documents\ChatGPT\Renly")
OUT=Path(__file__).resolve().parent
OLD='9948d55d4a42df4cf299cec4b41c509bda2fdc5f'
SOURCE='2a17aa5628af343427ee3057bdc5f197bf9cf5b1'
checks=[]
def ck(ok,label):checks.append({'label':label,'passed':bool(ok)});assert ok,label
def git(*a):return subprocess.check_output(['git','-C',str(ROOT),*a])
def blob(p,rev=SOURCE):return git('cat-file','blob',rev+':'+p)
def doc(p,rev=SOURCE):return json.loads(blob(p,rev))
sha=lambda raw:hashlib.sha256(raw).hexdigest()
paths=['.scratch/full-facility-mainline/issues/37-baseline-report.md','docs/mainline/38-eligibility-audit-v2.md','docs/mainline/38-eligibility-decision-v2.json','docs/mainline/38-eligibility-revision.json','docs/mainline/progress.json']
ck(set(git('diff','--name-only',OLD+'...'+SOURCE).decode().splitlines())==set(paths),'revision limited to three additive decision docs and two lifecycle records')
for p in ['docs/mainline/38-eligibility-proposal.json','docs/mainline/38-eligibility-audit.md']:
    ck(blob(p)==blob(p,OLD),'original withdrawn proposal/audit byte-preserved '+p)
decision=doc(paths[2]);revision=doc(paths[3]);audit=blob(paths[1]).decode();progress=doc(paths[4]);oldprogress=doc(paths[4],OLD)
ck(decision['decision']=='ELIGIBLE_FOR_NARROW_STRUCTURED_POLICY_FACTOR' and decision['status']=='PROPOSED_PENDING_CORRECTION_REVIEW','corrected testability decision remains pending independent acceptance')
ck('not an experiment or a quantitative result' in decision['classification'] and decision['measured_AI_gain'] is None and decision['measured_RSI_gain'] is None,'eligibility is not a fabricated positive or negative effect')
ck(set(decision['not_measured'])=={'AI policy increment','Language understanding','Sitewide task discovery','RSI improvement-process increment'},'distinct AI/language/discovery/RSI effects all unmeasured')
ck('not a disqualification of structured policy comparisons' in decision['language_task_discovery'] and 'no effect judgment' in decision['RSI'],'missing language/RSI operationalization not misused as policy-factor rejection')
ck(revision['original_source']==OLD and revision['original_decision']=='NOT_ELIGIBLE_CURRENT_STUDY' and revision['original_disposition']=='WITHDRAWN_NOT_ACCEPTED','original unsupported rejection is withdrawn, never accepted or relabelled a measurement')
ck(revision['replacement']==paths[2] and revision['replacement_audit']==paths[1] and 'Spec P2' in revision['finding'],'revision preserves independent Spec finding and replacement authority chain')
ck('还没有选择新假设' in audit and '撤回原否决' in audit and '尚未执行' in audit,'argument corrected prospectively, no experimental claim')
ck(all(decision[k]==0 for k in ['new_physical_calls','new_selectors','new_inference_or_training','new_LLM_experiment_calls','new_nonce_reads','new_research_trials']) and decision['registered_runs_unchanged']==180,'no new model/research work asserted or added')
ck(progress['research_trials']==oldprogress['research_trials'] and progress['research_trials']['attempts']==180 and progress['research_trials']['charged_s']==1800,'complete existing180/1800 account untouched')
ck('No36implementation or research run started' not in progress['liveness_refresh'] and '180 original registered runs completed' in progress['liveness_refresh'] and 'Current38' in progress['liveness_refresh'],'inherited stale liveness note corrected to actual completed work')
ticket37=blob(paths[0]).decode()
ck('**Status:** resolved' in ticket37 and 'Pending implementation and acceptance.' not in ticket37 and 'Accepted; see the source-bound report' in ticket37,'resolved37 evidence placeholder reconciled without scientific edits')
ck('**Status:** claimed' in blob('.scratch/full-facility-mainline/issues/38-agent-eligibility.md').decode(),'38 still awaits independent correction acceptance')
for n,blocker in [('39-agent-increment.md','38'),('40-rsi-increment.md','39')]:
    text=blob('.scratch/full-facility-mainline/issues/'+n).decode()
    ck('**Status:** ready-for-agent' in text and '**Blocked by:** '+blocker in text,'unrun successor retained original blocking edge '+n)
ck('no gate deferral' in decision['lifecycle']['39'] and decision['lifecycle']['40']=='unrun; depends on39' and all('dependencies unresolved' in decision['lifecycle'][n] for n in ['41','42']),'no false deferral or completion of39–42')
ck(decision['overall_goal']=='INCOMPLETE' and progress['status']=='active' and 'no overall completion claim' in decision['delivery_checkpoint'],'user reading checkpoint distinct from overall goal/42 completion')
ck(all(t in decision['next_protocol'] for t in ['one factor','matched information/tools/permission/action budgets','all calls/failures/costs','new independent confirmation conditions']),'future narrow policy study requires frozen factor/budget and new independent confirmation')
ck('原180次结果作为未见确认' in audit and '多个提交不属于RSI实验' in audit,'seen outcomes and maintenance/feedback are not promoted into independent confirmation or RSI')
ck(not git('diff','--name-only',OLD,SOURCE,'--','src','scripts','configs','tests','evidence','paper').strip(),'no runtime, tests, saved data or existing report altered by eligibility revision')
tree={p.decode() for p in git('ls-tree','-r','-z','--name-only',SOURCE).split(b'\0') if p}
sources=[]
for p in [decision['predecessor_acceptance'],*decision['evidence'],decision['original_proposal'],decision['revision_record']]:
    raw=blob(p);ck(bool(raw),'decision evidence pointer exists '+p);sources.append({'path':p,'sha256':sha(raw),'bytes':len(raw)})
result={'status':'PASS_CORRECTED_NARROW_POLICY_ELIGIBILITY_AND_CHECKPOINT_ACCOUNTING','source':SOURCE,'original_source':OLD,'check_count':len(checks),'checks':checks,'reviewed_files':[{'path':p,'sha256':sha(blob(p)),'bytes':len(blob(p))} for p in paths],'evidence_sources':sources,'remaining_blockers':[],'lifecycle_note':'S38-LIFECYCLE-01 closed by current liveness wording; ticket37 historical pending placeholder also reconciled.','scientific_scope':'Testability of a prospective narrow structured-policy factor only; no AI/RSI benefit, new model call or experimental result. User review checkpoint does not close39–42 or overall goal.','reviewer_activity':{'models':0,'selectors':0,'tests':0,'builder':0,'verifier':0,'nonce':0,'HMAC':0,'browser':0,'physical_runs':0,'project_imports':0,'tracked_edits':0}}
(OUT/'revision-2a17-result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:result[k] for k in ['status','source','check_count','remaining_blockers','scientific_scope','reviewer_activity']}))
