"""Seal fixed-source eligibility Standards records; no project execution."""
from pathlib import Path
import hashlib,json
OUT=Path(__file__).resolve().parent
sha=lambda raw:hashlib.sha256(raw).hexdigest()
assert not (OUT/'manifest.json').exists()
initial=json.loads((OUT/'initial-9948-result.json').read_bytes())
revision=json.loads((OUT/'revision-2a17-result.json').read_bytes())
assert initial['check_count']==23 and revision['check_count']==28 and revision['remaining_blockers']==[]
assert "KeyError: 'identified_worlds'" in (OUT/'initial-9948-review-01.log').read_text(encoding='utf-8-sig')
correction={'classification':'REVIEWER_ONLY_SAVED_SCHEMA_FIELD_NAME','preserved_source':'initial_review_01.py','preserved_log':'initial-9948-review-01.log','field_assumed':'identified_worlds','actual_original_field':'identified_world_ids','corrected_source':'initial_review.py','corrected_log':'initial-9948-review-02.log','project_or_experimental_calls':0,'old_data_or_proposal_modified':False}
(OUT/'reviewer-correction.json').write_text(json.dumps(correction,indent=2)+'\n',encoding='utf-8')
receipt={'schema':'aegisdc-independent-eligibility-standards-v1','status':revision['status'],'source':revision['source'],'original_source':initial['source'],'initial_scope':'Metadata/source/no-measurement classification only; not a scientific eligibility approval.','initial_saved_checks':23,'corrected_revision_checks':28,'original_scientific_rejection':'WITHDRAWN_AFTER_INDEPENDENT_SPEC_P2; original proposal/audit retained byte-identically','inherited_lifecycle_note':initial['inherited_lifecycle_note'],'lifecycle_closure':revision['lifecycle_note'],'remaining_blockers':[],'scientific_scope':revision['scientific_scope'],'meaningful_smell_findings':[],'reviewer_activity':revision['reviewer_activity']}
(OUT/'receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
files=[]
for path in sorted(OUT.iterdir()):
    if path.is_file() and path.name not in {'manifest.json','seal-verification.json'}:
        raw=path.read_bytes();files.append({'path':path.name,'sha256':sha(raw),'bytes':len(raw)})
manifest={'schema':'aegisdc-independent-review-manifest-v1','source':revision['source'],'original_source':initial['source'],'files':files,'excluded':['manifest.json (self)','seal-verification.json (post-seal proof)','runtime caches (none declared)']}
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
for row in json.loads((OUT/'manifest.json').read_bytes())['files']:
    raw=(OUT/row['path']).read_bytes();assert sha(raw)==row['sha256'] and len(raw)==row['bytes']
proof={'status':'PASS','manifest_sha256':sha((OUT/'manifest.json').read_bytes()),'fresh_read_artifacts':len(files),'reviewer_project_calls':0}
(OUT/'seal-verification.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf-8')
print(json.dumps(proof))
