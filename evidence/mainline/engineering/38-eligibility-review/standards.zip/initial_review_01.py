"""Fixed9948 metadata/source Standards observations, not an eligibility experiment."""
from pathlib import Path
import hashlib,json,re,subprocess
ROOT=Path(r"C:\Users\Donson\Documents\ChatGPT\Renly")
OUT=Path(__file__).resolve().parent
SOURCE='9948d55d4a42df4cf299cec4b41c509bda2fdc5f'
BASE='00cfc313eaaf99d5cb833334cdc0af6df4c7d8b7'
checks=[]
def ck(ok,label):checks.append({'label':label,'passed':bool(ok)});assert ok,label
def git(*a):return subprocess.check_output(['git','-C',str(ROOT),*a])
def blob(p,rev=SOURCE):return git('cat-file','blob',rev+':'+p)
def doc(p,rev=SOURCE):return json.loads(blob(p,rev))
sha=lambda raw:hashlib.sha256(raw).hexdigest()
paths=['.scratch/full-facility-mainline/issues/38-agent-eligibility.md','docs/mainline/38-eligibility-audit.md','docs/mainline/38-eligibility-proposal.json','docs/mainline/progress.json']
ck(set(git('diff','--name-only',BASE+'...'+SOURCE).decode().splitlines())==set(paths),'single four-document eligibility proposal diff')
ck(git('rev-list',BASE+'..'+SOURCE).decode().splitlines()==[SOURCE],'single proposed commit after fixed base')
proposal=doc(paths[2]);audit=blob(paths[1]).decode();progress=doc(paths[3]);before=doc(paths[3],BASE)
ck(proposal['status']=='PROPOSED_PENDING_INDEPENDENT_REVIEW' and proposal['decision']=='NOT_ELIGIBLE_CURRENT_STUDY','original proposal remains a pending current-study decision')
ck(proposal['measured_AI_gain'] is None and proposal['measured_RSI_gain'] is None,'no invented measured AI or RSI effect')
ck(all(proposal[k]==0 for k in ['new_physical_calls','new_selectors','new_inference_or_training','new_LLM_experiment_calls','new_nonce_reads','new_research_trials']),'zero new experiment/call claims in documentary diff')
ck('not a new experiment or preregistered quantitative result' in proposal['classification'] and '不是AI效果实验' in audit,'post-baseline qualitative classification is explicit')
ck('不能报告NO-GO或无增益' in audit and '不是永久否定AI/RSI' in audit,'unrun increment not falsely converted to negative measurement')
ck('不能说“没有选择空间”' in audit and '不是' in audit and len(proposal['not_reasons_alone'])==4,'existing choice space and non-reasons retained')
ck(progress['current_ticket']=='38' and progress['current_milestone']=='M7' and progress['status']=='active','current38/M7 and overall goal remains active')
ck(progress['research_trials']==before['research_trials'] and progress['research_trials']['attempts']==180 and progress['research_trials']['charged_s']==1800,'registered180/1800 records unchanged')
ck('**Status:** claimed' in blob(paths[0]).decode(),'ticket38 not falsely resolved before acceptance')
for n in ['39-agent-increment.md','40-rsi-increment.md']:
    text=blob('.scratch/full-facility-mainline/issues/'+n).decode()
    ck('**Status:** ready-for-agent' in text and 'deferred-by-gate' not in text,'successors not deferred before38 acceptance '+n)
tracker=blob('docs/agents/issue-tracker.md').decode()
ck('After 38 resolves a `NOT_ELIGIBLE` decision with evidence' in tracker,'conditional defer rule requires prior accepted eligibility decision')
authorities=[]
for p in proposal['sources']:
    raw=blob(p);authorities.append({'path':p,'sha256':sha(raw),'bytes':len(raw)})
    ck(bool(raw),'declared source exists '+p)
m6=doc('docs/mainline/evidence/M6.json');r34=doc('docs/mainline/evidence/34-root.json')
ck(m6['status']=='ACCEPTED' and m6['registered_runs']==180 and m6['M7'].startswith('Eligibility not yet decided'),'accepted finite M6 did not pre-decide eligibility')
primary=doc('evidence/mainline/research/34-paired-analysis/results.json');identified=primary['identified_worlds']
plan=doc('docs/mainline/30-comparison-protocol-v1.json');worlds={w['id']:w for w in plan['phases']['confirmation']['worlds']}
ck(len(identified)==r34['identified_worlds']==12 and len({worlds[w]['family'] for w in identified})==r34['identified_families']==3,'actual saved shared-history identification12 worlds/3 families')
ck(plan['comparison']['identification']['minimum_common_eligible_paid_candidates']==2,'identified criterion preserves at least2 common paid tasks')
old_hint=progress['liveness_refresh']
ck(old_hint==before['liveness_refresh'] and 'No36implementation or research run started' in old_hint,'stale no36 liveness hint inherited from base, not a new scientific result')
notes={'id':'S38-LIFECYCLE-01','path':'docs/mainline/progress.json','json_pointer':'/liveness_refresh','at_fixed_source':'INHERITED_CURRENT_HINT_CONTRADICTS_COMPLETED36/37_AND180_RUNS','root_disposition':'Root acknowledged; update at38 acceptance to current qualitative audit with zero new runs, retaining original in Git history.','blocks_scientific_decision':False}
result={'status':'METADATA_AND_NO_MEASUREMENT_CLASSIFICATION_CHECKED_NOT_SCIENTIFIC_ELIGIBILITY_APPROVAL','source':SOURCE,'base':BASE,'check_count':len(checks),'checks':checks,'source_identities':[{'path':p,'sha256':sha(blob(p)),'bytes':len(blob(p))} for p in paths],'declared_evidence_sources':authorities,'inherited_lifecycle_note':notes,'original_provisional_observation':'Documentary classification/source/lifecycle checks do not themselves establish that structured policy replacement is ineligible.','independent_spec_disposition':'Root separately accepted Spec objection: absence of a selected increment hypothesis does not imply that structured-data AI policy replacement cannot be tested. Original negative eligibility argument is superseded prospectively, not accepted by this packet.','pending_revision':'Root will submit ELIGIBLE_FOR_NARROW_STRUCTURED_POLICY_FACTOR and a user review checkpoint; successor work remains unrun.','reviewer_activity':{'models':0,'selectors':0,'tests':0,'builder':0,'verifier':0,'nonce':0,'HMAC':0,'browser':0,'physical_runs':0,'project_imports':0,'tracked_edits':0}}
(OUT/'initial-9948-result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:result[k] for k in ['status','source','check_count','pending_revision','reviewer_activity']}))
