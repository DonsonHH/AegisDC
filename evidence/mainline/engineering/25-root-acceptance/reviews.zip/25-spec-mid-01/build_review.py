"""Static committed-byte review; no application imports or execution."""
from pathlib import Path
from hashlib import sha256
import json
import subprocess
from datetime import datetime,timezone

REPO=Path('C:/Users/Donson/.codex/worktrees/mainline23-intervention/Renly')
OUT=Path(__file__).resolve().parent
BASE='f1f88c3681c19f61cc51813a95345a02c01a9d98'
PIN='2e7645e53f57226fe09937dba4fe68d85c1e34b6'
def git(*args):return subprocess.check_output(['git',*args],cwd=REPO)
def digest(raw):return sha256(raw).hexdigest()
def write(path,value):
    with path.open('x',encoding='utf-8',newline='\n') as stream:stream.write(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
names=['AGENTS.md','GLOSSARY.md','docs/MAINLINE.md','docs/mainline/progress.json',
    '.scratch/full-facility-mainline/spec.md','.scratch/full-facility-mainline/issues/25-transparent-baselines.md',
    'docs/mainline/25-policy-execution.md','docs/mainline/information-boundary.md','docs/research/20261105/baseline-selection.md',
    'src/aegis_dc/dispatch_policy.py','src/aegis_dc/policy_execution.py','src/aegis_dc/live_sensor_execution.py',
    'src/aegis_dc/lookahead_policy.py','src/aegis_dc/risk_condition_policy.py','src/aegis_dc/sensor_channels.py',
    'src/aegis_dc/workforce_dispatch.py','src/aegis_dc/intervention_execution.py','src/aegis_dc/plant.py',
    'src/aegis_dc/action_value.py','src/aegis_dc/inspection_execution.py','src/aegis_dc/decision_view.py',
    'tests/test_dispatch_policy.py']
files={}
for name in names:
    raw=git('cat-file','blob',PIN+':'+name);path=OUT/'export'/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(raw)
    files[name]=dict(sha256=digest(raw),bytes=len(raw),git_blob=git('rev-parse',PIN+':'+name).decode().strip())
diff=git('diff',BASE+'...'+PIN);(OUT/'review.diff').write_bytes(diff)
commits=git('log',BASE+'..'+PIN,'--oneline');(OUT/'commits.txt').write_bytes(commits)
findings=[
    dict(id='SPEC25-MID-01',severity='P1',file='src/aegis_dc/live_sensor_execution.py',line=36,
        rule='Ticket25 shared available information; implemented exact-epoch live sampling declaration',
        summary='Rounded-down non-dyadic polling epochs disappear in the one-point adapter',
        static_counterexample='phase=0,period=0.1,counter=5. Exact5*binary64(.1)=.5+2^-55 rounds to.5. Live session schedules.5; sample_trace floor(Fraction(.5)/Fraction(.1))+1=5 enumerates counters0..4, all before the sole point. No record, but session index advances.',
        implication='Fixed observation availability depends on numeric schedule spelling; policies receive undeclared missing data.',
        suggested_check='Author public facility-run slice atperiod.1 andepoch.5; no reviewer reproduction performed.'),
    dict(id='SPEC25-MID-02',severity='P2',file='src/aegis_dc/dispatch_policy.py',line=38,
        rule='Ticket25 infeasible choices must be traceable;25contract public issued-task occupation releases on arrived execution reports',
        summary='Rejected issued tasks permanently retain public worker/tool occupation',
        static_counterexample='Issue FIFO task at0 with deadline.5 and public access.25+work1. prepare_work sees legal nominal capabilities; actual_start rejectsshift_or_deadline_unavailable without feedback. Issuedhistory only releases completed/aborted, so next feasible sameworker/tool task stays blocked forever.',
        implication='A terminal failed proposal incorrectly disables remaining feasible work.',
        suggested_check='Declare arrived task-local rejection feedback or reject known timing before issue, without hidden-state oracle.'),
    dict(id='SPEC25-MID-03',severity='P2',file='src/aegis_dc/policy_execution.py',line=87,
        rule='25contract all policies share current action authority and trace every public infeasibility reason',
        summary='Known action-authorization failure is computed after choosing but ignored when submitting work',
        static_counterexample='An intervention grant already expired at issue. Candidate prepare_work audit remains eligible;record_issue storesprepare_intervention false assessment but returns nothing;workforce.submit still starts paid task. Only terminal effect becomesNO_EFFECT.',
        implication='Publicly unavailable authority is not represented in policy feasibility/reasons and known futile work can be selected.',
        suggested_check='Common public operation-assessment gate before selection/issue; if already pending, account explicitly before accepting25.')]
review=dict(schema='aegisdc-ticket25-static-spec-mid-review-v1',status='CHANGES_REQUIRED_DEVELOPMENT_ONLY',
    source=PIN,comparison_base=BASE,reviewer='/root/m4_24_spec_final',findings=findings,unresolved_findings=3,
    new_assessments=0,new_selectors=0,new_tests=0,new_physics=0,new_inference=0,
    known_incomplete_excluded_from_findings=['common cumulative budget','model-to-actual timing bridge','CLI','closure binding','formal frozen delivery','independent final/root gates'],
    scope='Static committed code only; no policy effect or mainline acceptance claim',source_files=files,
    reviewed_utc=datetime.now(timezone.utc).isoformat())
write(OUT/'review.json',review)
report='''# Ticket25 mid-development SPEC review

Fixed comparison: f1f88c36...2e7645e5. Three concrete implemented-path findings; this is not final ticket acceptance.

- P1, SPEC25-MID-01, `live_sensor_execution.py:36`: rounded-down polling epochs vanish when the one-point adapter recomputes its poll count. For phase0/period0.1/counter5, exact5×binary64(.1)=.5+2^-55 rounds to.5. The live session schedules.5; `sample_trace` enumerates only counters0–4, all before the sole point, then the session advances without producing the due reading. This violates shared declared observation availability and exact-epoch sampling.
- P2, SPEC25-MID-02, `dispatch_policy.py:38–43`: only completed/aborted feedback releases the issued resource book. `CrewWorkforce._start_queued` can reject an issued task for deadline/shift without any feedback. A capability-legal task issued0 with deadline.5 but access.25+work1 therefore prevents every later feasible task sharing its crew/tool. Ticket25 requires traceable infeasibility and arrived resource accounting. Add declared task-local rejection acknowledgement or a common known-timing refusal.
- P2, SPEC25-MID-03, `policy_execution.py:87–88`: `record_issue` calculates an invalid public intervention assessment but selection already occurred and workforce submission proceeds. An already-expired grant remains eligible in the candidate audit and can consume paid work before NO_EFFECT. The shared-authority/public-reasons contract requires a common proposal gate before selection/issue.

Known unfinished cumulative budgets, physical timing bridge, CLI, closure integration and final evidence gates are acknowledged separately, not reclassified as completed behavior. No application calls, tests, physics, inference or effect evaluation were run. Original24packages and author source were not changed; source exports, exact diff and findings are preserved here. Complete research goal remains active.
'''
(OUT/'SPEC.md').write_text(report,encoding='utf-8',newline='\n')
for name,item in files.items():assert digest((OUT/'export'/name).read_bytes())==item['sha256']
write(OUT/'delivery-manifest.json',dict(source=PIN,files={p.relative_to(OUT).as_posix():dict(sha256=digest(p.read_bytes()),bytes=p.stat().st_size) for p in OUT.rglob('*') if p.is_file()}))
print(json.dumps(dict(status=review['status'],findings=len(findings),source_files=len(files),report_words=len(report.split()),new_application_calls=0)))
