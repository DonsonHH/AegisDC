# Ticket25 static correction supplement

Source5697c7b5 resolves SPEC25-MID-02/03: task rejection now produces a delayed task-local generic acknowledgement without private cause/location, and arrived rejected status releases the public concurrency reservation; cumulative admission envelopes remain spent. All online policy versions receive the same declared intervention profile before selection, with v3 selector/executor identity matching and explicit public authority reasons. The inspection minimum-work comparison now matches the executor additive clock.

SPEC25-MID-01 is only partially fixed. Explicit validated poll indices preserve counter5 at .5 inside a longer run. However `live_sensor_execution.py:19` still truncates counter enumeration before converting epochs to binary64. At duration.5,phase0,period.1, count is5(indices0–4); counter5exact=.5+2^-55 rounds to.5 but is omitted. A longer run samples it at.5, violating prefix consistency. Include the adjacent counter, filter converted instants by the horizon, and retain distinct-coordinate guards.

Original22sourceexports,227word report and three original findings remain immutable. This supplement performed no application calls, selectors, assessments, tests, physics or inference. New model timing/CLI/closure/final gates remain parent development work; no acceptance or scientific gain is claimed.
