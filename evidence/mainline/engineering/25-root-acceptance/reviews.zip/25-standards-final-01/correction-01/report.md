# Standards correction — continuation feasibility

Pinned correction:e571cb91, runtime change57e86ff5, against originalb199271a. Static review only. Unresolved documented findings in these correction paths:0.

STD25-FINAL-01 is corrected. For an inspection plan with any positive-probability intervention continuation, the selector adds both candidates' declared admission envelopes in every person/tool/cost dimension and compares their sum with the same current cumulative remaining ledger. It no longer credits a continuation merely because each task independently passes the first-action mask. An over-budget branch receives COMMON_CONTINUATION_ENVELOPE_EXCEEDS_BUDGET and cannot win. Current issue charging and no terminal refund remain unchanged; actual plant occupation stays separate.

STD25-FINAL-02 is corrected. Direct action begins at the current public decision instant; a contingent action adds the declared inspection travel/wait/work/report latency. Forecast completion adds declared intervention travel/wait/work. Both proposed issue and completion epochs must satisfy the bound public authorization's half-open interval. Exact expiry3 is rejected without a tolerance or private-state query, and the unavailable alternative retains an explicit reason.

The updated contract clearly identifies the budget as a conservative admission constraint rather than measured labor. It labels numerical report thresholds, likelihoods, travel/wait and residual effects as declared forecast assumptions, not calibrated instrument/plant truths. The earlier observation-law scope note is therefore addressed as a documented model limitation; actor/capability, work duration, report latency and reference probability declaration checks remain distinct.

Read retained RED67/GREEN68, RED69/GREEN70 and log71 reporting26 focused passes; none were executed. All original review artifacts, findings, counterexamples and hashes remain unchanged. Existing duplicated registry-merge logic remains a nonblocking judgment-only observation.

No tests, probes, assessments, physics, inference, captures or full regressions were run by this reviewer. New frozen five-policy engineering evidence, saved-source/tool review, actual rendering, fresh checkout and root integrated gates are still required. This static supplement does not accept ticket25 or claim policy superiority, field calibration or research completion.
