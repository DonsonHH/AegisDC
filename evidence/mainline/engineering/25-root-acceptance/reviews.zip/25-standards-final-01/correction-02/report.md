# Standards precision correction — intermediate review

Pinned source:db8229bd versus e571cb91. Static review only; no project code executed.

AdmissionBudget correctly retains Fraction values derived from decoded public declarations. The same object supplies exact single-candidate and combined positive-support continuation can_reserve gates. The earlier.3/19.4 continuation-envelope rounding path no longer consumes displayed reservation/remaining values. No private state, new authority or budget refund is introduced. Prior action-time authorization and issued-history validation remain in force.

One residual P2 display-to-decision path remains:dispatch_policy.py still reads rounded ledger.remaining values to rewrite value_model.resource_budget before assess_action_value. That model's _planning uses the rewritten limits to decide branch eligibility. Thus display rounding can still alter forecast affordability, contrary to the new contract sentence that rounded ledger values never decide affordability. The exact admission gate itself is fixed; this finding concerns the separate forecast-model gate. Parent acknowledged the path and plans to remove the display clamp while retaining declared model budgets, exact admission gates and common cost-unit validation.

Read saved RED72/GREEN73 and log74 reporting39 policy/sensor checks; none were rerun. Original reports, counterexamples and correction01 hashes remain unchanged. No selector, tests, probes, assessments, physics, inference, captures or full regressions were run by this reviewer.

This intermediate source is not accepted. Frozen tools/results, independent saved review and root gates remain pending; the complete research goal remains active.
