# Standards — ticket25 static preflight

Pinned source:b199271a againstf1f88c36. Static committed-byte review only; no tests, probes, assessments, physics, inference or captures executed.

**Documented findings:two P2 planning-consistency paths.**

STD25-FINAL-01:lookahead_policy.py:85–89 checks inspection and prospective intervention independently against the same current admission ledger. policy_budget.py:21–25 charges each full candidate window; assess_action_value uses shorter stage occupation. In the existing co-located fixture, each candidate reserves10person/tool-seconds. With common budgets15/15 and cost2, both are individually eligible, but after the inspection only5remain, making the proposed continuation impossible. The model still permits the inspection-then-action plan. baseline-selection.md §2 explicitly says every positive-probability branch must fit the same declared budget. Check the combined admission envelopes, not only each current mask, before attributing continuation benefit.

STD25-FINAL-02:validate_execution_bindings:19–38 matches work/report timing but never checks known future completion against the bound action grant. Set the same public action expiry to2s:at0 direct action can finish1.25, while inspection/report/action predicts completion3. Current authority is valid, so choose_work's mask permits the contingent plan; the real executor later refuses it. The same baseline §2 requires compatible authorized continuation, and §4 requires mapping decision time to the relative model window. Reject the known-expired continuation or explicitly represent its no-effect response.

**Scope note:**source/target/observable plus reference probabilities do not establish that a numeric instrument's threshold/polarity actually realizes that report law. For example, changing the belief threshold while retaining likelihoods passes the new validator. Document this as an explicit probabilistic-model assumption, or bind the intended report semantics; do not overclaim validation.

Earlier rejection, decimal-poll and inspection-clock findings remain statically corrected. Closed arrival/provenance boundaries, strict issue/completion authority, cumulative issue charges, CLI and common-frame lifecycle integration were inspected. The existing registry-merge duplication remains a nonblocking heuristic.

Contract completion, frozen delivery, saved review and root gates remain outstanding. Author log64 reports23 focused passes; it was read, not rerun. Prior review artifacts remain unchanged. This pin is not accepted and establishes no method or research gain.
