"""Final static pre-capture audit; no AegisDC imports or execution."""
from pathlib import Path
from fractions import Fraction
from hashlib import sha256
import subprocess,json
REPO=Path('C:/Users/Donson/.codex/worktrees/mainline23-intervention/Renly');OUT=Path(__file__).resolve().parent;OLD=OUT.parent
PIN='e4d48e74abc4ad7b0a199ff9805f9eac06a45d45';PRIOR='1f4b3e91a86c3ddfdfc85977ebaf4d10ddb77b6c'
PROTOCOL='docs/mainline/25-policy-engineering-protocol.json';PACKAGE='evidence/mainline/engineering/25-baselines'
checks=[]
def verify(ok,name):
    checks.append(dict(name=name,passed=bool(ok)))
    if not ok:raise ValueError(name)
def git(*args):return subprocess.check_output(['git',*args],cwd=REPO)
def blob(rev,path):return git('cat-file','blob',rev+':'+path)
def digest(raw):return sha256(raw).hexdigest()
def write(p,value):
    with p.open('x',encoding='utf-8',newline='\n') as f:f.write(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
old=json.loads((OLD/'delivery-manifest.json').read_bytes())
for name,item in old['files'].items():
    raw=(OLD/name).read_bytes();verify(digest(raw)==item['sha256'] and len(raw)==item['bytes'],'prior preflight preserved '+name)
protocol=json.loads(blob(PIN,PROTOCOL));prior=json.loads(blob(PRIOR,PROTOCOL));cases=protocol['cases']
verify(len(cases)==protocol['physical_runs']==13,'13frozen physical calls')
verify(sum(Fraction(c['duration_s']) for c in cases)==protocol['total_simulated_duration_s']==30,'30seconds exact budget')
verify(len(protocol['durable_root'])+len(cases)*len(protocol['durable_case'])==57,'57durable artifacts plus receipt')
verify(protocol['registered_research_trials']==protocol['llm_calls']==protocol['training_calls']==0,'no research/LLM/training')
documents={c['id']:json.loads(blob(PIN,c['input'])) for c in cases};priorinputs={c['id']:c['input'] for c in prior['cases']}
for c in cases:verify(blob(PIN,c['input'])==blob(PRIOR,priorinputs[c['id']]),'unchanged frozen physical input '+c['id'])
common=[]
for name in protocol['same_world_cases']:
    d=json.loads(json.dumps(documents[name]));p=d['dispatch_program']['policy_program'];p.pop('policy');p.pop('options');common.append(d)
verify(all(d==common[0] for d in common),'five common fullworld/info/resources declarations identical')
expectedfixed=[[],[[0,.5],[1,1.5]],[[0,.5],[1,1.5]],[[0,.5],[1,1.5],[2,2.5],[3,3.5]]]
spent={'no-human':[0,0,0],'fifo':[20,20,2],'periodic':[10,10,1],'risk-condition':[20,20,2],'one-observation':[20,20,2]}
for c in cases:
    expected=c['expected'];d=documents[c['id']];p=d['dispatch_program'];param={r['id']:r['value'] for r in d['model']['parameters']}
    verify(param['network_service_capacity']==.25,'common quarter bottleneck '+c['id'])
    duration=Fraction(c['duration_s']);delivered=duration/4
    if c['id']=='delayed-rejection':delivered=Fraction(9,4)/4+Fraction(3,4)/2
    verify((expected['demand_service_unit_s'],expected['delivered_service_unit_s'],expected['service_deficit_time_s'])==(duration,delivered,duration-delivered),'independent service integral '+c['id'])
    if c['id'] in protocol['same_world_cases']:
        verify(expected['fixed_records_per_decision']==expectedfixed,'literal fixed arrivals '+c['id'])
        verify(expected['sensor_poll_epochs_s']==[0,1,2,3,4],'literal fixed epochs '+c['id'])
        verify(list(expected['final_spent_or_reserved'].values())==spent[c['id']],'literal final cumulative envelopes '+c['id'])
        human=c['id'] in {'fifo','risk-condition','one-observation'}
        verify(expected['handheld_records_per_decision']==([0,0,1,1] if human else [0,0,0,0]),'literal handheld availability '+c['id'])
        if human:
            m=expected['handheld_measurement'];verify((m['observed_at_s'],m['arrived_at_s'],m['value_squared_ratio'])==(1.25,1.75,[1,340]),'literal analytic handheld witness '+c['id'])
    if c['id'] in {'future-authority','continuation-budget','exact-continuation-budget'}:
        verify(expected['chosen']==['first-action'],'literal direct fallback '+c['id'])
obs=next(c for c in cases if c['id']=='one-observation');options=documents['one-observation']['dispatch_program']['policy_program']['options']
priorweights=[Fraction(1,2),Fraction(1,4),Fraction(1,8),Fraction(1,8)]
negativeweights=[Fraction(9,10),Fraction(4,5),Fraction(1,10),Fraction(3,5)]
mass=[a*b for a,b in zip(priorweights,negativeweights)];normalizer=sum(mass);posterior=[v/normalizer for v in mass]
verify(posterior==[Fraction(36,59),Fraction(16,59),Fraction(1,59),Fraction(6,59)],'power-conditioned posterior independent literal')
verify(obs['expected']['arrived_posterior_cooling_ratio']==[16,59],'frozen cooling16/59')
verify(options['belief_model']['independent_pairs']==[['fixed-hot','fixed-low-power']],'power/flow independence not invented')
verify(obs['expected']['handheld_update_disposition']=='dependence_not_modeled' and obs['expected']['used_fixed_record_id']=='power-transfer:1','frozen information audit identity')
verify(Fraction(2125000)/Fraction(97,100)>2000000,'fixed power report below2MW is negative')
positive_mass=Fraction(1,4)*Fraction(4,5)+Fraction(3,4)*Fraction(1,10)
forecast=2*Fraction(1,4)*Fraction(4,5)+positive_mass+5*Fraction(1,4)*Fraction(1,5)
verify(forecast==Fraction(37,40) and obs['expected']['initial_forecast_deficit_s']==.925,'initial no-fixed forecast37/40')
verify(Fraction(63,59)<Fraction(80,59),'at1.75direct predicted deficit below deferral')
verify(2*(Fraction(10)-Fraction(.3))>Fraction(19.4),'exact shared budget decimal counterexample')
verify(float(5*Fraction(.1))==.5 and Fraction(5)*Fraction(.1)>Fraction(.5),'decimal fifth epoch boundary')
names=[PROTOCOL,'scripts/policy_delivery.py','scripts/inspection_delivery.py','scripts/prepare_policy_inputs.py','docs/mainline/25-policy-execution.md',
    'src/aegis_dc/dispatch_policy.py','src/aegis_dc/lookahead_policy.py','src/aegis_dc/policy_budget.py','src/aegis_dc/live_sensor_execution.py',*[c['input'] for c in cases]]
files={}
for name in names:
    raw=blob(PIN,name);p=OUT/'export'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw)
    verify(p.read_bytes()==raw,'exact committed export '+name)
    files[name]=dict(sha256=digest(raw),bytes=len(raw),git_blob=git('rev-parse',PIN+':'+name).decode().strip())
tool=blob(PIN,'scripts/policy_delivery.py').decode()
for expression in ('save_run(result,folder/case[\'id\'])','check_case(folder,case,protocol)','STARTED','os.fsync','source_guard_error=','receipt.setdefault(\'error_type\'','receipt.setdefault(\'error\''):
    verify(expression in tool,'static capture guard '+expression)
verify(tool.index("check_case(folder,case,protocol);receipt['validated_cases']+=1")<tool.index("append(folder/'attempts.jsonl',dict(case=case['id'],status='COMPLETED'"),'save/check precedes completion and next attempt')
for name in ('fixed_records_per_decision','handheld_records_per_decision','final_spent_or_reserved','initial_forecast_deficit_s','arrived_posterior_cooling_ratio','used_fixed_record_id','handheld_update_disposition'):
    verify(name in tool,'literal oracle consumed '+name)
verify("receipt['pinned']==pins(protocol,source)" in tool and 'identities==hashes(delivery,identities)' in tool,'saved verifier pins execution and delivery')
verify('durable(folder)==declared(protocol)' in tool and 'hashes(delivery,[(folder/n).relative_to(ROOT)' in tool,'declared exact durable set and committed delivery')
verify(git('diff','--name-only','319d1d1b51ffe893223f28add2012fec12540b4b',PIN,'--','src')==b'','runtime unchanged since reviewed319d')
review=dict(status='STATIC_PREFLIGHT_PASS',source=PIN,prior_source=PRIOR,unresolved_findings=0,resolved_findings=['SPEC25-PROTOCOL-01','SPEC25-PROTOCOL-02'],
    checks_passed=len(checks),checks=checks,source_files=files,prior_preflight_files_preserved=len(old['files']),physical_call_budget=13,simulated_seconds_budget=30,durable_artifacts=57,
    new_selectors=0,new_assessments=0,new_tests=0,new_physics=0,new_inference=0,new_captures=0,root_acceptance=False,full_goal='ACTIVE')
write(OUT/'review.json',review)
report='''# 第25项最终捕获前复核

固定源e4d48e74静态通过，捕获阻断0。13例、30秒、57产物及逐例保存校验后再继续的规则一致；工具保留首错并单列源码守卫失败。

固定/手持送达、平方流量1/340、累计预算、直接处置回退、精确小数及授权到期均有独立字面门槛。首查预测37/40；固定功率负报告后冷却后验16/59，手持因未声明独立性不重复更新，账中明确保留该限制。

原审阅与静态脚本失败未改。本次零项目调用；仅确认可按冻结协议捕获，不代表票据或根验收。
'''
(OUT/'SPEC.md').write_text(report,encoding='utf-8',newline='\n')
write(OUT/'delivery-manifest.json',dict(source=PIN,files={p.relative_to(OUT).as_posix():dict(sha256=digest(p.read_bytes()),bytes=p.stat().st_size) for p in OUT.rglob('*') if p.is_file()}))
print(json.dumps(dict(status=review['status'],checks_passed=len(checks),prior_preserved=len(old['files']),exports=len(files),report_sha256=digest((OUT/'SPEC.md').read_bytes()),review_sha256=digest((OUT/'review.json').read_bytes()),new_application_calls=0)))
