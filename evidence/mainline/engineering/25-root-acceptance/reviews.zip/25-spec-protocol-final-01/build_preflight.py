"""Static protocol/input audit and independent literal arithmetic, no application calls."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction
import json,subprocess
REPO=Path('C:/Users/Donson/.codex/worktrees/mainline23-intervention/Renly');OUT=Path(__file__).resolve().parent
PIN='1f4b3e91a86c3ddfdfc85977ebaf4d10ddb77b6c';GUARD_FIX='3b3275c95836d4316a297a36caff064de354f83d'
PROTOCOL='docs/mainline/25-policy-engineering-protocol.json';PACKAGE='evidence/mainline/engineering/25-baselines'
checks=[]
def verify(ok,name):
    checks.append(dict(name=name,passed=bool(ok)))
    if not ok:raise ValueError(name)
def git(*args):return subprocess.check_output(['git',*args],cwd=REPO)
def blob(revision,name):return git('cat-file','blob',revision+':'+name)
def digest(raw):return sha256(raw).hexdigest()
def write(p,value):
    with p.open('x',encoding='utf-8',newline='\n') as stream:stream.write(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
protocol=json.loads(blob(PIN,PROTOCOL));cases=protocol['cases']
verify(len(cases)==13==protocol['physical_runs'],'13physical case budget')
verify(sum(Fraction(c['duration_s']) for c in cases)==30==protocol['total_simulated_duration_s'],'30seconds exact total')
verify(len({c['id'] for c in cases})==13 and len({c['input'] for c in cases})==13,'unique case and input identities')
verify(len(protocol['durable_root'])+len(cases)*len(protocol['durable_case'])==57,'57declared durable outputs plus receipt')
verify(protocol['registered_research_trials']==protocol['llm_calls']==protocol['training_calls']==0,'engineering-only scope')
documents={c['id']:json.loads(blob(PIN,c['input'])) for c in cases};common=[]
for name in protocol['same_world_cases']:
    raw=json.loads(json.dumps(documents[name]));p=raw['dispatch_program']['policy_program'];p.pop('policy');p.pop('options');common.append(raw)
verify(all(d==common[0] for d in common),'same five fullworld/publicinput/resource/budget declarations')
literal={}
for c in cases:
    d=documents[c['id']];p=d['dispatch_program'];actual={r['id']:r['value'] for r in d['model']['parameters']}
    verify(actual['network_service_capacity']==Fraction(1,4),'quarter network bottleneck '+c['id'])
    demand=Fraction(c['duration_s']);delivered=demand/4
    if c['id']=='delayed-rejection':delivered=Fraction(9,4)/4+Fraction(3,4)/2
    deficit=demand-delivered
    verify(c['expected']['demand_service_unit_s']==demand and c['expected']['delivered_service_unit_s']==delivered
        and c['expected']['service_deficit_time_s']==deficit,'independent service literal '+c['id'])
    literal[c['id']]=dict(demand=str(demand),delivered=str(delivered),deficit=str(deficit))
    if c['id'] in protocol['same_world_cases']:
        verify(p['decision_times_s']==[0,1.5,1.75,4],'same decision epochs '+c['id'])
        measurement=p['sensor_program']['profile']['measurements'][0];channel=p['sensor_program']['profile']['channels'][0]
        verify((measurement['phase_s'],measurement['period_s'],channel['delay_s'])==(0,1,.5),'fixed epoch/delay literal '+c['id'])
        verify(p['policy_program']['resource_budget']==dict(person_s=100,tool_s=100,cost=2,cost_unit='research_cost_unit'),'same common caps '+c['id'])
        verify(all(candidate['task']['deadline_s']==10 and candidate['available_at_s']==0 and candidate['issue_cost']==1 for candidate in p['policy_program']['candidates']),'tenwindow/onefee '+c['id'])
prior=Fraction(1,4);positive_cooling=prior*Fraction(4,5);positive_total=positive_cooling+(1-prior)*Fraction(1,10)
defer=5*prior;direct=Fraction(1,4)*prior+1
inspection=2*positive_cooling+positive_total+5*(prior-positive_cooling)
verify((defer,direct,inspection)==(Fraction(5,4),Fraction(17,16),Fraction(37,40)),'independent finite lookahead literals1.25/1.0625/.925')
verify(positive_cooling/positive_total==Fraction(8,11),'independent positiveposterior8/11')
window=Fraction(10)-Fraction(.3);verify(2*window>Fraction(19.4),'exact decimal continuation exceeds budget')
verify(Fraction(5)*Fraction(.1)>Fraction(.5) and float(5*Fraction(.1))==.5,'rounded endpoint counter5 rationale')
verify(Fraction(7,4)+Fraction(5,4)==3,'strict future grant completion3')
literal['independent_forecast']=dict(defer=str(defer),direct=str(direct),inspection=str(inspection),positive_probability=str(positive_total),positive_cooling_posterior='8/11')
literal['mandatory_pre_execution_additions']=dict(fixed_arrived_counts=[0,2,2,4],fixed_observation_delay_s=.5,handheld_observed_at_s=1.25,handheld_arrived_at_s=1.75,
    handheld_flow_squared='1/340',common_final_spent={'no-human':[0,0,0],'fifo':[20,20,2],'periodic':[10,10,1],'risk-condition':[20,20,2],'one-observation':[20,20,2]},
    blocked_inspection_replacement='first-action')
names=[PROTOCOL,'scripts/policy_delivery.py','scripts/prepare_policy_inputs.py','scripts/inspection_delivery.py','docs/mainline/25-policy-execution.md',
    'src/aegis_dc/policy_budget.py','src/aegis_dc/lookahead_policy.py','src/aegis_dc/live_sensor_execution.py','src/aegis_dc/dispatch_policy.py',*[c['input'] for c in cases]]
files={}
for name in names:
    raw=blob(PIN,name);p=OUT/'export'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw)
    verify(p.read_bytes()==blob(PIN,name),'immutable committed export '+name)
    files[name]=dict(sha256=digest(raw),bytes=len(raw),git_blob=git('rev-parse',PIN+':'+name).decode().strip())
guard=blob(GUARD_FIX,'scripts/policy_delivery.py');(OUT/'source-guard-fix.py').write_bytes(guard)
verify(b"receipt.setdefault('error_type'" in guard and b"receipt.setdefault('error'" in guard and b"receipt['source_guard_error']" in guard,'source guard preserves primary failure after3b3275')
findings=[dict(id='SPEC25-PROTOCOL-01',severity='P2',status='FIXED_AT_3b3275_PENDING_NEXT_PIN',summary='Initial author tool overwrote primary failure under sourceguard failure'),
    dict(id='SPEC25-PROTOCOL-02',severity='P2',status='PRE_CAPTURE_EXPECTATIONS_REQUIRED',summary='Formal checks lack independent literal arrived fixed/handheld evidence and cumulativebudget outputs despite exact choice/completion/service checks')]
review=dict(status='CHANGES_REQUIRED_PRE_CAPTURE',source=PIN,source_guard_fix=GUARD_FIX,checks_passed=len(checks),checks=checks,findings=findings,
    source_files=files,physical_call_budget=13,simulated_seconds_budget=30,durable_outputs=57,terminal_receipts=1,new_selectors=0,new_assessments=0,new_tests=0,new_physics=0,new_inference=0,new_captures=0,
    scope='Pre-capture static input/tool/source review. Protocol literals/service and sameworld declarations verified; pending added independent observation/budget gates before capture.')
write(OUT/'review.json',review);write(OUT/'literal-witnesses.json',literal)
report='''# 第25项捕获前协议复核

1f4b3e91的13例、30模拟秒、57产物预算相符。五策略同场、同输入和预算；服务积分、1.25/3秒作业、0.5秒拒绝送达、精确预算和授权到期预期可独立核对。首错覆盖已在3b3275单独修复。

捕获前仍须补字面核验：固定测点到达计数、手持1.25观察/1.75到达及平方流量1/340、各策略累计预算输出；仅检查未来信息和选择序列不足以发现早送或预算账破坏。三种拒绝检查后的首动作也应固定为first-action。

本复核只读Git/JSON并作独立分数算术，零应用调用。原件不改；完成新源冻结后再确认可捕获，尚非票据验收。
'''
(OUT/'SPEC.md').write_text(report,encoding='utf-8',newline='\n')
write(OUT/'delivery-manifest.json',dict(source=PIN,files={p.relative_to(OUT).as_posix():dict(sha256=digest(p.read_bytes()),bytes=p.stat().st_size) for p in OUT.rglob('*') if p.is_file()}))
print(json.dumps(dict(status=review['status'],checks_passed=len(checks),exports=len(files),physical_calls=0,report_sha256=digest((OUT/'SPEC.md').read_bytes()))))
