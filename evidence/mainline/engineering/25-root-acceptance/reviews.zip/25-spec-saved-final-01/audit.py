"""Independent saved-data audit. No AegisDC imports, application or author verifier calls."""
from pathlib import Path
from fractions import Fraction
from hashlib import sha256
from copy import deepcopy
from datetime import datetime,timezone
import subprocess,json,math

REPO=Path('C:/Users/Donson/.codex/worktrees/mainline23-intervention/Renly')
OUT=Path(__file__).resolve().parent
WORK=Path('C:/Users/Donson/Documents/ChatGPT/Renly/.work')
SOURCE='6a9e3ca8dfd38bf529bec51cd3e10ad66af320d9'
ORIGINAL_SOURCE='e4d48e74abc4ad7b0a199ff9805f9eac06a45d45'
ORIGINAL_DELIVERY='e5f195254b890bb2aa3fccee6f540b729ea39175'
DELIVERY='f2e66125f782b54fbebd2a7818ba76e9a0a3927c'
PACKAGE='evidence/mainline/engineering/25-baselines'
CAPTURE=PACKAGE+'/capture-02';ORIGINAL_CAPTURE=PACKAGE+'/capture-01'
PROTOCOL='docs/mainline/25-policy-engineering-correction-01.json'
checks=[]
def verify(ok,name):
    checks.append(dict(name=name,passed=bool(ok)))
    if not ok:raise ValueError(name)
def close(a,b,name,tol=1e-9):verify(math.isclose(a,b,rel_tol=0,abs_tol=tol),name)
def digest(raw):return sha256(raw).hexdigest()
def read(path):return json.loads(path.read_bytes())
def rows(path):return [json.loads(line) for line in path.read_text(encoding='utf-8').splitlines()]
def git(*args):return subprocess.check_output(['git',*args],cwd=REPO)
def blobs(revision,names):
    names=sorted(set(names));raw=subprocess.check_output(['git','cat-file','--batch'],cwd=REPO,
        input=''.join(revision+':'+n+'\n' for n in names).encode());result={};offset=0
    for name in names:
        end=raw.index(b'\n',offset);header=raw[offset:end].split()
        verify(len(header)==3 and header[1]==b'blob','committed blob '+revision[:8]+' '+name)
        start=end+1;size=int(header[2]);result[name]=raw[start:start+size];offset=start+size+1
    verify(offset==len(raw),'complete Git batch '+revision[:8]);return result
def write(path,value):
    with path.open('x',encoding='utf-8',newline='\n') as stream:stream.write(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
def durable(folder):return {p.relative_to(folder).as_posix() for p in folder.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix not in {'.pyc','.pyo'}}
def public_keys(value):
    if type(value) is dict:
        for key,child in value.items():yield key;yield from public_keys(child)
    elif type(value) is list:
        for child in value:yield from public_keys(child)

def main():
    protocol=read(REPO/PROTOCOL);receipt=read(REPO/CAPTURE/'receipt.json');oldreceipt=read(REPO/ORIGINAL_CAPTURE/'receipt.json')
    verify(protocol['original_execution']==ORIGINAL_SOURCE and protocol['original_delivery']==ORIGINAL_DELIVERY,'explicit original identities')
    verify(protocol['new_physical_runs']==11 and protocol['new_simulated_duration_s']==22 and protocol['cumulative_physical_runs']==13
        and protocol['cumulative_simulated_duration_s']==30,'correction budget11new22s plus2old8s')
    verify(receipt['execution_commit']==SOURCE and receipt['status']=='PASS' and receipt['physical_attempts']==receipt['physical_completed']==receipt['validated_new_cases']==11
        and receipt['reused_cases_validated']==2 and receipt['failures']==0 and receipt['simulated_duration_attempted_s']==22,'correction terminal actual totals')
    verify(oldreceipt['execution_commit']==ORIGINAL_SOURCE and oldreceipt['status']=='FAIL' and oldreceipt['physical_attempts']==oldreceipt['physical_completed']==2
        and oldreceipt['validated_cases']==1 and oldreceipt['simulated_duration_attempted_s']==8 and oldreceipt['error']=='Literal selection sequence differs: fifo','original validation failure preserved, not all-pass')
    verify(oldreceipt['source_head_and_bytes_unchanged'] and receipt['source_head_and_bytes_unchanged'],'both execution source guards passed')
    verify(receipt['registered_research_trials']==receipt['llm_calls']==receipt['training_calls']==0,'no effect research/LLM/training')
    declared=set(protocol['durable_root'])|{c['id']+'/'+n for c in protocol['cases'] for n in protocol['durable_case']}
    verify(len(declared)==58 and set(receipt['artifacts'])==declared and durable(REPO/CAPTURE)==declared|{'receipt.json'},'58artifacts plus correction receipt')
    oldnames=durable(REPO/ORIGINAL_CAPTURE);verify(len(oldnames)==11 and oldnames==set(oldreceipt['artifacts'])|{'receipt.json'},'original11 durable files')
    deliveryblobs=blobs(DELIVERY,[CAPTURE+'/'+n for n in declared|{'receipt.json'}])
    oldblobs=blobs(ORIGINAL_DELIVERY,[ORIGINAL_CAPTURE+'/'+n for n in oldnames])
    for name in declared|{'receipt.json'}:
        raw=(REPO/CAPTURE/name).read_bytes();verify(raw==deliveryblobs[CAPTURE+'/'+name],'correction delivered exact '+name)
        if name!='receipt.json':verify(digest(raw)==receipt['artifacts'][name],'correction receipt hash '+name)
    for name in oldnames:
        raw=(REPO/ORIGINAL_CAPTURE/name).read_bytes();verify(raw==oldblobs[ORIGINAL_CAPTURE+'/'+name],'failed original exact '+name)
        if name!='receipt.json':verify(digest(raw)==oldreceipt['artifacts'][name],'failed original receipt hash '+name)
    pin_names={name for group in receipt['pinned'].values() for name in group}
    sourceblobs=blobs(SOURCE,pin_names);pindelivery=blobs(DELIVERY,pin_names)
    for role,group in receipt['pinned'].items():
        for name,wanted in group.items():
            verify(digest(sourceblobs[name])==wanted==digest(pindelivery[name]),'source/delivery '+role+' '+name)
            verify(digest((REPO/name).read_bytes())==wanted,'current byte pin '+role+' '+name)
    verify({k:len(v) for k,v in receipt['pinned'].items()}==dict(runtime=66,tools=4,inputs=201),'66runtime4tools201inputs')
    verify(receipt['pinned']['runtime']==oldreceipt['pinned']['runtime'],'oracle correction did not change physical runtime')
    priorpinblobs=blobs(ORIGINAL_SOURCE,{n for group in oldreceipt['pinned'].values() for n in group})
    for role,group in oldreceipt['pinned'].items():
        for name,wanted in group.items():verify(digest(priorpinblobs[name])==wanted,'original execution role '+role+' '+name)
    tree=git('ls-tree','-rz','--name-only',SOURCE,'src','tests','configs',PACKAGE+'/development',PACKAGE+'/reference',
        'evidence/mainline/engineering/18-beliefs/capture-01','evidence/mainline/engineering/23-interventions/reference').decode().strip('\0').split('\0')
    original_protocol=read(REPO/protocol['original_protocol'])
    expected_inputs={protocol['original_protocol'],protocol['contract'],protocol['literature_note'],PACKAGE+'/.gitattributes',PROTOCOL,protocol['revision_note'],
        *[n for n in tree if n.startswith(('tests/',PACKAGE+'/','configs/full-facility','configs/materials/',
            'evidence/mainline/engineering/18-beliefs/capture-01/','evidence/mainline/engineering/23-interventions/reference/')) and '__pycache__' not in n and not n.endswith(('.pyc','.pyo'))],
        *[ORIGINAL_CAPTURE+'/'+n for n in oldnames]}
    verify(set(receipt['pinned']['inputs'])==expected_inputs,'independent complete input pin membership')
    verify(set(receipt['pinned']['runtime'])=={n for n in tree if n.startswith('src/') and n.endswith('.py')},'independent runtime pin membership')
    verify(set(receipt['pinned']['tools'])=={'scripts/policy_delivery.py','scripts/policy_correction_delivery.py','scripts/inspection_delivery.py','scripts/prepare_policy_inputs.py'},'independent tool membership')
    reuse=read(REPO/CAPTURE/'reused-originals.json')
    verify(reuse['classification']=='BYTE_IDENTICAL_REUSE_NO_NEW_PHYSICAL_CALL' and len(reuse['copies'])==8,'two cases eight original outputs reused')
    for name,item in reuse['copies'].items():
        raw=(REPO/CAPTURE/name).read_bytes();verify(raw==(REPO/item['original']).read_bytes() and digest(raw)==item['sha256'],'reused byte-for-byte '+name)
    verify(reuse['original_failed_receipt_sha256']==digest((REPO/ORIGINAL_CAPTURE/'receipt.json').read_bytes()),'reuse index retains failed receipt identity')
    oldledger=rows(REPO/ORIGINAL_CAPTURE/'attempts.jsonl');ledger=rows(REPO/CAPTURE/'attempts.jsonl')
    verify([r['status'] for r in oldledger]==['STARTED','COMPLETED','STARTED','FAILED'],'original stop-on-second-validation-failure ledger')
    newcases=[c for c in protocol['cases'] if c['id'] not in protocol['reused_cases']]
    verify(len(ledger)==22 and len(newcases)==11,'only11new calls in correction ledger')
    for i,case in enumerate(newcases):
        pair=ledger[i*2:i*2+2];verify([r['status'] for r in pair]==['STARTED','COMPLETED']
            and all(r['case']==case['id'] and r['execution_commit']==SOURCE for r in pair),'one new accounted attempt '+case['id'])
    corrected=deepcopy(protocol['cases']);original=deepcopy(original_protocol['cases'])
    for a,b in zip(corrected,original):
        if a['id']=='fifo':a['expected']=b['expected']
    verify(corrected==original,'only FIFO expectation changed among13cases')
    for c in protocol['cases']:
        verify(sourceblobs[c['input']]==priorpinblobs[c['input']],'all physical reference inputs unchanged '+c['id'])

    literal_choices={'no-human':[None,None,None,None],'fifo':['first-action',None,'first-inspection',None],
        'periodic':[None,None,None,'first-inspection'],'risk-condition':['first-inspection',None,'first-action',None],
        'one-observation':['first-inspection',None,'first-action',None],'decimal-prefix':[None],
        'future-authority':['first-action'],'continuation-budget':['first-action'],
        'closure-pending':['first-inspection',None,'first-action',None],'exact-continuation-budget':['first-action'],
        'hidden-open':['a-first',None],'hidden-closed':['a-first',None],'delayed-rejection':['a-first',None,'b-second']}
    runs={};documents={};case_results={};literalfixed=[[],[[0,.5],[1,1.5]],[[0,.5],[1,1.5]],[[0,.5],[1,1.5],[2,2.5],[3,3.5]]]
    for case in protocol['cases']:
        name=case['id'];path=REPO/CAPTURE/name;run=read(path/'run.json');runs[name]=run
        doc=json.loads(sourceblobs[case['input']]);documents[name]=doc;program=doc['dispatch_program'];summary=run['summary']
        trace=rows(path/'private-state.jsonl');balances=rows(path/'balances.jsonl');decisions=run['policy_public_decisions']
        expected_source=ORIGINAL_SOURCE if name in protocol['reused_cases'] else SOURCE
        verify(run['code_identity']['git_commit']==expected_source and not run['code_identity']['implementation_has_changes'],'actual run source '+name)
        verify(read(path/'scenario.json')==doc['model'] and run['inputs']['dispatch_program']==program,'raw declared input identity '+name)
        verify([d['frame']['as_of_s'] for d in decisions]==program['decision_times_s'],'exact decision schedule '+name)
        chosen=[d['choice']['chosen_candidate_id'] for d in decisions]
        verify(chosen==literal_choices[name] and chosen==case['expected']['chosen'],'independent literal choices '+name)
        duration=Fraction(case['duration_s']);delivered=duration/4
        if name=='delayed-rejection':delivered=Fraction(9,4)/4+Fraction(3,4)/2
        for key,wanted in [('demand_service_unit_s',duration),('delivered_service_unit_s',delivered),('service_deficit_time_s',duration-delivered)]:
            close(summary[key],float(wanted),'independent service '+name+'/'+key)
            close(math.fsum(b[key] for b in balances),float(wanted),'raw interval service '+name+'/'+key)
        verify(len(trace)==len(balances)+1 and trace[0]['time_s']==0 and trace[-1]['time_s']==case['duration_s'],'raw endpoints/count '+name)
        verify(all(t['time_s']==b['start_s'] and n['time_s']==b['end_s'] and 0<b['end_s']-b['start_s']<=.010000001 for t,b,n in zip(trace,balances,trace[1:])),'complete positive interval partition '+name)
        verify(abs(summary['whole_run_energy_residual_J'])<1e-4 and summary['max_mass_residual_kg']<=1e-9,'whole energy/mass conservation '+name)
        verify(all(abs(v)<1e-4 for b in balances for v in b['energy_residuals_J'].values()) and all(abs(v)<=1e-9 for b in balances for v in b['mass_residuals_kg'].values()),'raw interval conservation '+name)
        for member,item in run['artifacts'].items():
            raw=(path/member).read_bytes();verify(digest(raw)==item['sha256'],'run member digest '+name+'/'+member)
            if member.endswith('.jsonl'):verify(len(raw.splitlines())==item['records'],'run member record count '+name+'/'+member)
        verify(run['research_trials']==run['model_calls']==run['training_calls']==0 and run['field_calibration']=='PENDING','engineering interpretation '+name)
        for d in decisions:
            now=d['frame']['as_of_s'];choice=d['choice'];records=d['frame']['evidence']['records']
            verify(all(r['observed_at_s']<=r['arrived_at_s']<=now for r in records),'arrived-only evidence '+name+'/'+str(now))
            verify(all(r['observed_at_s']<=r['arrived_at_s']<=now for r in d['history']['work_feedback']),'arrived-only task reports '+name+'/'+str(now))
            verify(not choice['execution_permission'] and not choice['generated_tour'],'no fabricated execution or tour '+name+'/'+str(now))
            verify(not {'private_realization','private_signal','private_bias','private_noise_bucket','actual_state','raw_truth'}&set(public_keys(d)),'no hidden-state fields in decision '+name+'/'+str(now))
        verify(all(not r['risk_closed'] for r in run.get('intervention_public_feedback',[])),'action reports never auto-close '+name)
        work=run['work_records'];effects=[e for e in run.get('intervention_private_audit',{}).get('events',[]) if e['outcome']=='APPLIED']
        expected_completion=([1.25,3] if name in {'fifo','risk-condition','one-observation','closure-pending'} else [2.25] if name=='delayed-rejection' else [])
        expected_effect=([1.25] if name=='fifo' else [3] if name in {'risk-condition','one-observation','closure-pending'} else [2.25] if name=='delayed-rejection' else [])
        verify([r['completed_at_s'] for r in work if r['status']=='completed']==expected_completion,'independent actual completion '+name)
        verify([e['applied_at_s'] for e in effects]==expected_effect,'independent physical effect timing '+name)
        if name in protocol['same_world_cases']:
            fixed=[[[r['observed_at_s'],r['arrived_at_s']] for r in d['frame']['evidence']['records'] if r['source_id']=='rectifier-meter-record'] for d in decisions]
            verify(fixed==literalfixed,'literal fixed delivery epochs '+name)
            verify([r['polled_at_s'] for r in run['policy_sensor_private_audit']]==[0,1,2,3,4],'actual fixed sample epochs '+name)
            for d in decisions:
                for record in d['frame']['evidence']['records']:
                    if record['source_id']=='rectifier-meter-record':
                        point=next(t for t in trace if t['time_s']==record['observed_at_s'])
                        close(record['value'],point['domains']['power']['rectifier_input_W'],'fixed physical sample value '+name+'/'+record['id'])
                        verify(record['value']>2000000 and record['quality']['error_bound']==0,'fixed negative low-power interpretation '+name+'/'+record['id'])
            final=run['policy_public_resource_ledger'];spent=[0,0,0] if name=='no-human' else [10,10,1] if name=='periodic' else [20,20,2]
            verify([final['spent_or_reserved'][k] for k in ('person_s','tool_s','cost')]==spent and final['terminal_report_refund'] is False,'literal final common envelope '+name)
            handheld=[[r for r in d['frame']['evidence']['records'] if r['source_id']=='portable-intake-meter'] for d in decisions]
            wanted=([0,0,0,1] if name=='fifo' else [0,0,1,1] if name in {'risk-condition','one-observation'} else [0,0,0,0])
            verify([len(r) for r in handheld]==wanted,'literal handheld delivery counts '+name)
            for records in handheld:
                for record in records:
                    timing=(3,3.5) if name=='fifo' else (1.25,1.75);denominator=180 if name=='fifo' else 340
                    verify((record['observed_at_s'],record['arrived_at_s'])==timing,'literal handheld timing '+name)
                    close(record['value']**2,1/denominator,'independent hydraulic squared flow '+name)
                    verify(record['provenance']==dict(origin_id='post-clean-flow',copied_from_record_id=None),'handheld original provenance '+name)
            if name in {'fifo','risk-condition','one-observation'}:
                close(summary['worker_work_person_s'],2,'actual paid work '+name);close(summary['tool_occupation_tool_s'],2.5,'actual tool occupation '+name)
        case_results[name]=dict(chosen=chosen,execution_source=expected_source,trace_points=len(trace),completed=expected_completion,effects=expected_effect,
            delivered=float(delivered),deficit=float(duration-delivered),work_status=[r['status'] for r in work])

    # Independent FIFO tie audit, including the original preflight omission.
    fifo_input=documents['fifo']['dispatch_program']['policy_program'];order=sorted(fifo_input['candidates'],key=lambda c:(c['available_at_s'],c['id']))
    verify([c['id'] for c in order]==['first-action','first-inspection'],'independent FIFO identity tie correction')
    verify(runs['fifo']['work_records'][0]['id']=='lookahead-action' and runs['fifo']['work_records'][1]['id']=='lookahead-inspect','FIFO actual task identity order')
    verify(original_protocol['cases'][1]['expected']['chosen']!=literal_choices['fifo'],'original protocol oracle and priorPASS miss retained')
    common=[]
    for name in protocol['same_world_cases']:
        d=deepcopy(documents[name]);p=d['dispatch_program']['policy_program'];p.pop('policy');p.pop('options');common.append(d)
    verify(all(d==common[0] for d in common),'same plant/resources/evidence models for allfive policies')
    verify(runs['hidden-open']['policy_public_decisions']==runs['hidden-closed']['policy_public_decisions'],'hidden-world public frames/history/choices identical')
    verify(runs['hidden-open']['work_records'][0]['status']=='working' and runs['hidden-closed']['work_records'][0]['status']=='aborted','hidden plant statuses different without oracle leak')
    verify(runs['hidden-open']['workforce_public_feedback']==runs['hidden-closed']['workforce_public_feedback']==[] and runs['hidden-closed']['summary']['access_check_person_s']>0,'hidden discovery paid and not arrived')
    rejection=runs['delayed-rejection']['policy_public_decisions'];report=rejection[-1]['history']['work_feedback'][0]
    verify(rejection[1]['history']['work_feedback']==[] and (report['status'],report['observed_at_s'],report['arrived_at_s'],report['reason'],report['location_id'])==('rejected',0,.5,'DECLARED_TASK_ADMISSION_REFUSAL',None),'delayed generic task-local refusal releases concurrency')
    decimal=runs['decimal-prefix']['policy_sensor_private_audit'];verify(len(decimal)==6 and decimal[-1]['poll_index']==5 and decimal[-1]['polled_at_s']==.5,'decimal endpoint prefix poll literal')
    for name,reason in [('future-authority','FORECAST_ACTION_AUTHORITY_UNAVAILABLE_AT_COMPLETION'),('continuation-budget','COMMON_CONTINUATION_ENVELOPE_EXCEEDS_BUDGET'),('exact-continuation-budget','COMMON_CONTINUATION_ENVELOPE_EXCEEDS_BUDGET')]:
        plan=next(a for a in runs[name]['policy_public_decisions'][0]['choice']['forecast_plans'][0]['alternatives'] if a['kind']=='inspect_then_act')
        verify(not plan['eligible'] and reason in plan['planning_reasons'],'forecast explicit rejected continuation '+name)
    verify(2*(Fraction(10)-Fraction(.3))>Fraction(19.4),'independent exact decimal admission inequality')
    verify(Fraction(7,4)+Fraction(5,4)==3,'independent future completion exactly expiry3')
    look=runs['one-observation']['policy_public_decisions'];close(look[0]['choice']['forecast_plans'][0]['best_expected_service_deficit_s'],37/40,'initial independent forecast37/40')
    belief=look[2]['choice']['forecast_belief'];close(belief['posterior']['cooling-limited'],16/59,'fixed-conditioned cooling posterior16/59')
    verify('power-transfer:1' in belief['information_updates'],'latest power representative used')
    verify(next(r for r in belief['record_audit'] if r['record_id']=='post-clean-flow')['disposition']=='dependence_not_modeled','handheld no invented independence increment')
    closure=runs['closure-pending']['policy_public_decisions'][-1]['choice']['question_lifecycle']['questions'][0]
    verify(closure['status']=='ACTION_COMPLETED_PENDING_VERIFICATION' and not closure['question_closed'] and not closure['risk_closed'],'actual closure stays pending')
    event=next(e for e in closure['trace'] if e['event']=='ACTION_REPORT_AVAILABLE');verify((event['observed_at_s'],event['arrived_at_s'])==(3,3.5),'closure uses actual arrived effect report')
    verify(all(not c['passed'] for c in closure['checks']) and not closure['supporting_record_ids'],'no post-action restoration fabricated from earlier reading')
    prior_preserved={}
    folders=[WORK/'25-spec-mid-01',WORK/'25-spec-mid-01/correction-01',WORK/'25-spec-mid-01/correction-02',
        WORK/'25-spec-final-01',WORK/'25-spec-final-01/correction-01',WORK/'25-spec-final-01/correction-02',WORK/'25-spec-final-01/correction-03',
        WORK/'25-spec-protocol-final-01',WORK/'25-spec-protocol-final-01/final-supplement-01']
    for folder in folders:
        manifest=read(folder/'delivery-manifest.json')
        for name,item in manifest['files'].items():
            raw=(folder/name).read_bytes();verify(digest(raw)==item['sha256'] and len(raw)==item['bytes'],'prior review preserved '+folder.relative_to(WORK).as_posix()+'/'+name)
        prior_preserved[folder.relative_to(WORK).as_posix()]=len(manifest['files'])
    review=dict(schema='aegisdc-ticket25-independent-saved-spec-review-v1',status='PASS',unresolved_findings=0,
        source=SOURCE,data_delivery=DELIVERY,original_source=ORIGINAL_SOURCE,original_delivery=ORIGINAL_DELIVERY,
        checks_passed=len(checks),checks=checks,pin_counts={k:len(v) for k,v in receipt['pinned'].items()},
        new_physical_calls=11,reused_original_cases=2,reused_original_files=8,cumulative_physical_calls=13,cumulative_simulated_seconds=30,
        durable_artifacts=58,terminal_receipts=1,original_failure_files=11,original_status='FAIL_ORACLE_MISMATCH_RETAINED',
        reviewer_prior_omission='The previous148-checkSTATIC_PREFLIGHT_PASS missed the FIFO available0/identity tie. OriginalPASSreport and actual validation failure remain immutable.',
        prior_packages_preserved=prior_preserved,new_reviewer_selectors=0,new_reviewer_assessments=0,new_reviewer_tests=0,new_reviewer_physics=0,new_reviewer_inference=0,new_reviewer_captures=0,
        case_results=case_results,root_acceptance=False,scope='Finite saved engineering behavior and exact identities only; no effect gain or research completion',reviewed_utc=datetime.now(timezone.utc).isoformat())
    write(OUT/'review.json',review);write(OUT/'source-pins.json',dict(execution=SOURCE,original_execution=ORIGINAL_SOURCE,data_delivery=DELIVERY,pinned=receipt['pinned']))
    report='''# 第25项独立保存结果复核

PASS，未解决发现0。修订源6a9e3ca8、交付f2e66125：13例的选择、作业、观测、服务、预算、授权及公开信息边界通过独立核对。FIFO按同刻身份先处置，1.25秒生效；后查3秒采样、3.5秒到达，平方流量1/180。

原e4两次/8秒中FIFO预期错误导致FAIL；此前148项静态PASS也漏检此tie，旧报告和11原件均保留。修订逐字节复用原2例8文件，仅新增11次/22秒，累计仍13次/30秒，未重跑。58产物＋收据、66运行源/4工具/201输入及双执行身份一致。

本复核未新增项目调用。固定/手持到达、精确预算、未来授权、依赖处理、隐蔽场景、拒绝反馈与关闭待核验均有字面证据；现场校准、效果研究与根验收未由此成立。
'''
    (OUT/'SPEC.md').write_text(report,encoding='utf-8',newline='\n')
    write(OUT/'delivery-manifest.json',dict(source=SOURCE,data_delivery=DELIVERY,files={p.relative_to(OUT).as_posix():dict(sha256=digest(p.read_bytes()),bytes=p.stat().st_size) for p in OUT.rglob('*') if p.is_file()}))
    print(json.dumps(dict(status=review['status'],checks_passed=len(checks),unresolved_findings=0,pins=review['pin_counts'],prior_files_preserved=sum(prior_preserved.values()),
        report_sha256=digest((OUT/'SPEC.md').read_bytes()),review_sha256=digest((OUT/'review.json').read_bytes()),new_application_calls=0)))
if __name__=='__main__':main()
