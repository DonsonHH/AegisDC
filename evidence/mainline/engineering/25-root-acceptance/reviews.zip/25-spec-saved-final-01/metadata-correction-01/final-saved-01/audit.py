"""Independent metadata saved audit; no project or author-verifier execution."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,subprocess,math
REPO=Path('C:/Users/Donson/Documents/ChatGPT/Renly');OUT=Path(__file__).resolve().parent;STATIC=OUT.parent;OLD=STATIC.parent
SOURCE='44ab2870da1cae04faf09e0ed4fb569cf7f7795d';DELIVERY='8006988047691756162cfcee9b86b17ee76db05b';ROOTFULL='9d5aeceb5c653f0bd5b5e7b850a1afdf4e086af1'
PACKAGE='evidence/mainline/engineering/25-baselines';CAPTURE=PACKAGE+'/metadata-capture-01';PROTOCOL='docs/mainline/25-policy-metadata-correction-01.json'
checks=[]
def verify(ok,name):
    checks.append(dict(name=name,passed=bool(ok)))
    if not ok:raise ValueError(name)
def digest(raw):return sha256(raw).hexdigest()
def read(p):return json.loads(p.read_bytes())
def rows(p):return [json.loads(s) for s in p.read_text(encoding='utf-8').splitlines()]
def git(*a):return subprocess.check_output(['git',*a],cwd=REPO)
def blobs(revision,names):
    names=sorted(set(names));raw=subprocess.check_output(['git','cat-file','--batch'],cwd=REPO,input=''.join(revision+':'+n+'\n' for n in names).encode());offset=0;result={}
    for name in names:
        end=raw.index(b'\n',offset);header=raw[offset:end].split();verify(len(header)==3 and header[1]==b'blob','committed blob '+revision[:8]+' '+name)
        start=end+1;size=int(header[2]);result[name]=raw[start:start+size];offset=start+size+1
    verify(offset==len(raw),'complete Git batch '+revision[:8]);return result
def write(p,value):
    with p.open('x',encoding='utf-8',newline='\n') as f:f.write(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
preserved={}
for folder in (OLD,STATIC):
    manifest=read(folder/'delivery-manifest.json')
    for name,item in manifest['files'].items():
        raw=(folder/name).read_bytes();verify(digest(raw)==item['sha256'] and len(raw)==item['bytes'],'preserved earlier review '+folder.name+'/'+name)
    preserved[folder.name]=len(manifest['files'])
original_review=read(OLD/'review.json');verify(original_review['checks_passed']==2609 and original_review['status']=='PASS','original2609review identity retained')
protocol=read(REPO/PROTOCOL);receipt=read(REPO/CAPTURE/'receipt.json');oldreceipt=read(REPO/PACKAGE/'capture-02/receipt.json')
verify(receipt['execution_commit']==SOURCE and receipt['status']=='PASS' and receipt['physical_attempts']==receipt['physical_completed']==receipt['validated_cases']==2
    and receipt['failures']==receipt['registered_research_trials']==receipt['original_policy_reruns']==0 and receipt['source_head_and_bytes_unchanged'],'two metadata actual runs only')
declared=set(protocol['durable_root'])|{c['id']+'/'+n for c in protocol['cases'] for n in protocol['durable_case']}
actual={p.relative_to(REPO/CAPTURE).as_posix() for p in (REPO/CAPTURE).rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix not in {'.pyc','.pyo'}}
verify(len(declared)==11 and actual==declared|{'receipt.json'} and set(receipt['artifacts'])==declared,'11metadata artifacts plus receipt')
delivered=blobs(DELIVERY,[CAPTURE+'/'+n for n in actual])
for name in actual:
    raw=(REPO/CAPTURE/name).read_bytes();verify(raw==delivered[CAPTURE+'/'+name],'metadata committed original '+name)
    if name!='receipt.json':verify(digest(raw)==receipt['artifacts'][name],'metadata receipt hash '+name)
names={name for group in receipt['pinned'].values() for name in group};execution=blobs(SOURCE,names);delivery=blobs(DELIVERY,names)
for role,group in receipt['pinned'].items():
    for name,wanted in group.items():verify(digest(execution[name])==wanted==digest(delivery[name]),'metadata execution/delivery '+role+' '+name)
changed=protocol['runtime_changed_path'];oldsource=blobs(protocol['prior_runtime_source'],oldreceipt['pinned']['runtime'])
verify(oldsource[changed].count(protocol['original_metadata_line'].encode())==1 and oldsource[changed].replace(protocol['original_metadata_line'].encode(),protocol['corrected_metadata_line'].encode())==execution[changed],'exact one metadata source replacement')
for name,wanted in oldreceipt['pinned']['runtime'].items():
    verify(digest(oldsource[name])==wanted,'original runtime recorded identity '+name)
    if name!=changed:verify(oldsource[name]==execution[name],'unchanged original runtime '+name)
ledger=rows(REPO/CAPTURE/'attempts.jsonl');verify(len(ledger)==4,'four metadata ledger rows')
inputdoc=json.loads(execution[protocol['input']]);case_results={}
for i,case in enumerate(protocol['cases']):
    pair=ledger[i*2:i*2+2];verify([r['status'] for r in pair]==['STARTED','COMPLETED'] and all(r['case']==case['id'] and r['execution_commit']==SOURCE for r in pair),'single metadata attempt '+case['id'])
    folder=REPO/CAPTURE/case['id'];run=read(folder/'run.json');trace=rows(folder/'private-state.jsonl');balances=rows(folder/'balances.jsonl')
    verify(run['code_identity']['git_commit']==SOURCE and not run['code_identity']['implementation_has_changes'],'actual metadata execution source '+case['id'])
    verify(run['dispatch_interface']==case['expected_interface'] and ('policy_public_decisions' in run)==case['dispatch'],'metadata value matches actual dispatch records '+case['id'])
    verify(read(folder/'scenario.json')==inputdoc['model'] and len(trace)==2 and len(balances)==1 and [t['time_s'] for t in trace]==[0,.01],'same model and exact metadata time span '+case['id'])
    verify(run['work_records']==[] and run.get('intervention_private_audit',{}).get('events',[])==[],'metadata runs create no crew/effect '+case['id'])
    if case['dispatch']:
        verify(len(run['policy_public_decisions'])==1 and run['policy_public_decisions'][0]['frame']['as_of_s']==0
            and run['policy_public_decisions'][0]['choice']['policy']=='no_human' and run['policy_public_decisions'][0]['choice']['chosen_candidate_id'] is None,'nohuman enabled metadata literal')
        expected=inputdoc['dispatch_program'];expected['decision_times_s']=[0]
        verify(run['inputs']['dispatch_program']==expected,'metadata policy input only time list shortened')
    else:verify('dispatch_program' not in run['inputs'],'default metadata has no policy declaration')
    for name,wanted in [('demand_service_unit_s',.01),('delivered_service_unit_s',.0025),('service_deficit_time_s',.0075)]:
        verify(math.isclose(run['summary'][name],wanted,rel_tol=0,abs_tol=1e-12),'independent metadata service literal '+case['id']+'/'+name)
        verify(math.isclose(balances[0][name],wanted,rel_tol=0,abs_tol=1e-12),'raw metadata service literal '+case['id']+'/'+name)
    verify(run['research_trials']==run['model_calls']==run['training_calls']==0,'metadata engineering only '+case['id'])
    for name,item in run['artifacts'].items():verify(digest((folder/name).read_bytes())==item['sha256'],'raw metadata member '+case['id']+'/'+name)
    case_results[case['id']]=dict(interface=run['dispatch_interface'],work=0,actual_source=run['code_identity']['git_commit'],duration_s=.01)
sidecar=read(REPO/protocol['sidecar']);verify(len(sidecar['entries'])==15,'15old saved runs sidecar')
historicalfiles=[]
for row in sidecar['entries']:
    raw=(REPO/row['path']).read_bytes();run=json.loads(raw)
    verify(digest(raw)==row['sha256'] and run['dispatch_interface']==row['original_emitted_value']=='NOT_IMPLEMENTED','old emitted value/hash retained '+row['path'])
    verify(run['code_identity']['git_commit']==row['execution_commit'] and 'policy_public_decisions' in run and row['sidecar_classification']=='PUBLIC_SELECTION_WITH_PRIVATE_EXECUTION','old classification not reexecution '+row['path'])
    historicalfiles.append(row['path'])
summary=read(REPO/'runs/mainline-M4-25-root-acceptance-20261105-01/summary.json');guard=read(REPO/'runs/mainline-M4-25-root-acceptance-20261105-01/source-guard.json')
verify(summary['overall']=='PASS' and summary['tests']['run']==summary['tests']['executed']==538 and summary['tests']['failures']==summary['tests']['errors']==summary['tests']['skipped']==0
    and summary['verified_original_files']==20,'538fullregression and20historical checks at originalroot source')
verify(guard['source_commit_before']==guard['source_commit_after']==ROOTFULL and guard['sources_unchanged'] and guard['head_unchanged'],'root538source9d retained')
rootpins=guard['committed_sources'];verify(len(rootpins)==270,'270originalrootguardfiles')
rootblobs=blobs(ROOTFULL,rootpins);currentblobs=blobs(DELIVERY,rootpins)
for name,wanted in rootpins.items():
    verify(digest(rootblobs[name])==wanted,'root538committed source '+name)
    if name==changed:verify(rootblobs[name].replace(protocol['original_metadata_line'].encode(),protocol['corrected_metadata_line'].encode())==currentblobs[name],'rootplant exact metadata delta')
    else:verify(rootblobs[name]==currentblobs[name],'other269root sources unchanged '+name)
verify(git('diff','--name-only',ROOTFULL,DELIVERY,'--','src').decode().splitlines()==[changed],'delivery runtime only one metadata path differs from testedroot')
savedchecks=read(REPO/CAPTURE/'checks.json');verify(savedchecks['all_engineering_calls']==15 and savedchecks['all_engineering_simulated_duration_s']==30.02
    and savedchecks['original_policy_calls']==13 and savedchecks['new_metadata_calls']==2,'policy13/30 plus metadata2/.02 separate totals')
review=dict(schema='aegisdc-ticket25-independent-metadata-saved-spec-review-v1',status='PASS',unresolved_findings=0,source=SOURCE,data_delivery=DELIVERY,
    root_full_executed_source=ROOTFULL,root_full_tests=538,root_guarded_files=270,historical_originals=20,
    prior_policy_review_source=original_review['source'],prior_policy_review_checks=2609,metadata_checks_passed=len(checks),checks_passed=2609+len(checks),checks=checks,
    pin_counts={k:len(v) for k,v in receipt['pinned'].items()},prior_review_files_preserved=preserved,metadata_cases=case_results,historical_run_classifications=15,
    original_policy_calls=13,original_policy_simulated_seconds=30,new_metadata_calls=2,new_metadata_seconds=.02,all_engineering_calls=15,all_engineering_seconds=30.02,
    original_policy_reruns=0,new_reviewer_project_calls=0,new_reviewer_tests=0,new_reviewer_physics=0,new_reviewer_inference=0,
    root_acceptance=False,scope='Mixed evidence:538full at9d plus exact one-line classification and separately executed metadata2cases at44ab. Nofull538claimat44ab.',reviewed_utc=datetime.now(timezone.utc).isoformat())
write(OUT/'review.json',review);write(OUT/'source-pins.json',dict(source=SOURCE,delivery=DELIVERY,pinned=receipt['pinned'],root_full_source=ROOTFULL,root_full_committed_sources=rootpins))
(OUT/'SPEC.md').write_text('''# 第25项元数据保存结果复核

PASS，未解决发现0。44ab源／80069880交付的默认禁用、无人工启用两个0.01秒案例，其字段与实际记录、无作业、服务积分及源身份一致。11产物加收据和执行／交付字节核对通过。

历史15个run保留原值与SHA；相对原策略源及9d全量源仅plant元数据一行改变，其余269个根守卫源不变。538项全量PASS仍只属于9d，另2项新元数据证据属于44ab；不作跨源全量归属。

原2609策略复核和FIFO失败、复用记录未改。策略13次30秒、元数据2次0.02秒分别记账；本复核零项目调用。最终根接受另设门槛。
''',encoding='utf-8',newline='\n')
write(OUT/'delivery-manifest.json',dict(source=SOURCE,data_delivery=DELIVERY,files={p.relative_to(OUT).as_posix():dict(sha256=digest(p.read_bytes()),bytes=p.stat().st_size) for p in OUT.rglob('*') if p.is_file()}))
print(json.dumps(dict(status=review['status'],metadata_checks_passed=len(checks),checks_passed=review['checks_passed'],pin_counts=review['pin_counts'],
    report_sha256=digest((OUT/'SPEC.md').read_bytes()),review_sha256=digest((OUT/'review.json').read_bytes()),new_application_calls=0)))
