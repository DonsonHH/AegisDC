"""Static metadata correction classification, never application execution."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction
from datetime import datetime,timezone
import subprocess,json
REPO=Path('C:/Users/Donson/Documents/ChatGPT/Renly');OUT=Path(__file__).resolve().parent;OLD=OUT.parent
PIN='44ab2870da1cae04faf09e0ed4fb569cf7f7795d';PRIOR='6a9e3ca8dfd38bf529bec51cd3e10ad66af320d9';ROOTFULL='9d5aeceb5c653f0bd5b5e7b850a1afdf4e086af1'
PROTOCOL='docs/mainline/25-policy-metadata-correction-01.json';PACKAGE='evidence/mainline/engineering/25-baselines'
checks=[]
def verify(ok,name):
    checks.append(dict(name=name,passed=bool(ok)))
    if not ok:raise ValueError(name)
def git(*a):return subprocess.check_output(['git',*a],cwd=REPO)
def blob(revision,name):return git('cat-file','blob',revision+':'+name)
def digest(raw):return sha256(raw).hexdigest()
def read(p):return json.loads(p.read_bytes())
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:f.write(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
old=read(OLD/'delivery-manifest.json')
for name,item in old['files'].items():
    raw=(OLD/name).read_bytes();verify(digest(raw)==item['sha256'] and len(raw)==item['bytes'],'prior2609review artifact unchanged '+name)
protocol=json.loads(blob(PIN,PROTOCOL));name=protocol['runtime_changed_path']
before=blob(PRIOR,name);after=blob(PIN,name)
verify(before.count(protocol['original_metadata_line'].encode())==1,'original metadata line occurs exactly once')
verify(before.replace(protocol['original_metadata_line'].encode(),protocol['corrected_metadata_line'].encode())==after,'exact one-line output metadata correction')
verify(git('diff','--name-only',PRIOR,PIN,'--','src').decode().splitlines()==[name],'only plant runtime source changed from author source')
verify(git('diff','--name-only',ROOTFULL,PIN,'--','src').decode().splitlines()==[name],'only plant runtime source changed from actualrootfull')
verify(blob(ROOTFULL,name)==before,'rootfull executed original metadata line')
sidecar=json.loads(blob(PIN,protocol['sidecar']))
paths={p.relative_to(REPO).as_posix() for folder in ('capture-01','capture-02') for p in (REPO/PACKAGE/folder).glob('*/run.json')}
verify(len(sidecar['entries'])==15 and {r['path'] for r in sidecar['entries']}==paths,'all15historicalrun paths classified')
for row in sidecar['entries']:
    raw=(REPO/row['path']).read_bytes();run=json.loads(raw)
    verify(digest(raw)==row['sha256'] and raw==blob(PIN,row['path']),'historical run exact '+row['path'])
    verify(run['dispatch_interface']==row['original_emitted_value']=='NOT_IMPLEMENTED','historical emitted value retained '+row['path'])
    verify(run['code_identity']['git_commit']==row['execution_commit'] and 'policy_public_decisions' in run
        and row['sidecar_classification']=='PUBLIC_SELECTION_WITH_PRIVATE_EXECUTION','sidecar based on actual saved records '+row['path'])
verify(protocol['physical_runs']==2 and protocol['total_simulated_duration_s']==.02 and protocol['maximum_step_s']==.01,'two separate metadata cases only')
verify([(c['id'],c['dispatch'],c['expected_interface']) for c in protocol['cases']]==[
    ('default',False,'DISABLED_FOR_THIS_RUN'),('no-human',True,'PUBLIC_SELECTION_WITH_PRIVATE_EXECUTION')],'both metadata branches independently declared')
verify(protocol['expected_summary']==dict(demand_service_unit_s=.01,delivered_service_unit_s=.0025,service_deficit_time_s=.0075),'independent .01time quarter service literal')
verify(len(protocol['durable_root'])+2*len(protocol['durable_case'])==11,'11declared metadata artifacts plusreceipt')
tool=blob(PIN,protocol['authoring_tool']).decode()
for text in ("receipt.setdefault('error_type'","receipt.setdefault('error'","status='STARTED'","check_case(folder,case,protocol);receipt['validated_cases']+=1",
    "require(before.replace(old,new)==git('cat-file','blob',revision+':'+name)","identities==hashes(receipt['execution_commit'],identities)","if name!=protocol['runtime_changed_path']",'historical_run_classifications=15',"declared_new_physical_runs=2,original_policy_reruns=0"):
    verify(text in tool,'metadata source/tool boundary '+text)
verify(tool.index("check_case(folder,case,protocol);receipt['validated_cases']+=1")<tool.index("status='COMPLETED'"),'check before next metadata case')
summary=read(REPO/'runs/mainline-M4-25-root-acceptance-20261105-01/summary.json')
guard=read(REPO/'runs/mainline-M4-25-root-acceptance-20261105-01/source-guard.json')
verify(summary['overall']=='PASS' and summary['tests']['executed']==summary['tests']['run']==538
    and summary['tests']['failures']==summary['tests']['errors']==summary['tests']['skipped']==0,'actual538root results retained')
verify(guard['source_commit_before']==guard['source_commit_after']==ROOTFULL and guard['head_unchanged'] and guard['sources_unchanged'],'actualrootfull source stays9d not44ab')
names=[PROTOCOL,protocol['revision_note'],protocol['sidecar'],protocol['authoring_tool'],name]
files={}
for n in names:
    raw=blob(PIN,n);p=OUT/'export'/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw);verify(p.read_bytes()==raw,'exact metadataexport '+n)
    files[n]=dict(sha256=digest(raw),bytes=len(raw),git_blob=git('rev-parse',PIN+':'+n).decode().strip())
(OUT/'metadata.diff').write_bytes(git('diff',PRIOR,PIN,'--','src'))
review=dict(status='STATIC_METADATA_PREFLIGHT_PASS_SAVED_RESULTS_PENDING',source=PIN,root_full_executed_source=ROOTFULL,
    checks_passed=len(checks),checks=checks,unresolved_findings=0,old_policy_cases=13,old_policy_simulated_seconds=30,
    new_metadata_case_budget=2,new_metadata_seconds_budget=.02,all_engineering_case_budget=15,all_engineering_seconds_budget=30.02,
    historical_run_classifications=15,prior_2609_review_files_preserved=len(old['files']),source_files=files,
    new_reviewer_project_calls=0,new_reviewer_tests=0,new_reviewer_physics=0,new_reviewer_inference=0,
    metadata_actual_results='PENDING',root_acceptance=False,scope='Static exact historical classification and separately frozen metadata checks, not a rerun of policy13or538atnewsource',reviewed_utc=datetime.now(timezone.utc).isoformat())
write(OUT/'review.json',review)
(OUT/'SPEC.md').write_text('''# 第25项元数据修订静态复核

44ab2870静态通过，捕获阻断0。相对作者6a9e及全量9d运行源，仅plant返回元数据一行改变；历史15个run保留原值、SHA与执行身份，sidecar据实际公开策略记录分类。

两个新0.01秒默认／无人工案例单独冻结，服务字面预期与58旧产物保持分离；累计策略仍13次30秒，元数据另2次0.02秒。旧538项PASS只属于9d，不移记为44ab全量通过。

原2609项复核包哈希未变。本复核零项目调用；新保存结果、交付与根接受仍待核对。
''',encoding='utf-8',newline='\n')
write(OUT/'delivery-manifest.json',dict(source=PIN,files={p.relative_to(OUT).as_posix():dict(sha256=digest(p.read_bytes()),bytes=p.stat().st_size) for p in OUT.rglob('*') if p.is_file()}))
print(json.dumps(dict(status=review['status'],checks_passed=len(checks),report_sha256=digest((OUT/'SPEC.md').read_bytes()),review_sha256=digest((OUT/'review.json').read_bytes()),new_application_calls=0)))
