"""Static final-candidate review, without application execution."""
from pathlib import Path
from hashlib import sha256
import subprocess,json
from datetime import datetime,timezone
REPO=Path('C:/Users/Donson/.codex/worktrees/mainline23-intervention/Renly');OUT=Path(__file__).resolve().parent
PIN='b199271a0ea338b2633e14d6189e967cd19a2704';BASE='f1f88c3681c19f61cc51813a95345a02c01a9d98'
def git(*args):return subprocess.check_output(['git',*args],cwd=REPO)
def digest(raw):return sha256(raw).hexdigest()
def write(path,value):
    with path.open('x',encoding='utf-8',newline='\n') as stream:stream.write(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
names=['AGENTS.md','GLOSSARY.md','docs/MAINLINE.md','docs/mainline/progress.json',
    '.scratch/full-facility-mainline/spec.md','.scratch/full-facility-mainline/issues/25-transparent-baselines.md',
    'docs/mainline/25-policy-execution.md','docs/mainline/information-boundary.md','docs/research/20261105/baseline-selection.md',
    'src/aegis_dc/dispatch_policy.py','src/aegis_dc/policy_execution.py','src/aegis_dc/live_sensor_execution.py',
    'src/aegis_dc/lookahead_policy.py','src/aegis_dc/risk_condition_policy.py','src/aegis_dc/sensor_channels.py',
    'src/aegis_dc/workforce_dispatch.py','src/aegis_dc/intervention_execution.py','src/aegis_dc/plant.py',
    'src/aegis_dc/action_value.py','src/aegis_dc/policy_budget.py','src/aegis_dc/verified_closure.py',
    'src/aegis_dc/inspection_execution.py','src/aegis_dc/decision_view.py','tests/test_dispatch_policy.py']
files={}
for name in names:
    raw=git('cat-file','blob',PIN+':'+name);p=OUT/'export'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw)
    files[name]=dict(sha256=digest(raw),bytes=len(raw),git_blob=git('rev-parse',PIN+':'+name).decode().strip())
(OUT/'review.diff').write_bytes(git('diff',BASE+'...'+PIN));(OUT/'commits.txt').write_bytes(git('log',BASE+'..'+PIN,'--oneline'))
prior=Path('C:/Users/Donson/Documents/ChatGPT/Renly/.work/25-spec-mid-01');preserved={}
for folder in (prior,prior/'correction-01',prior/'correction-02'):
    manifest=json.loads((folder/'delivery-manifest.json').read_bytes())
    for name,item in manifest['files'].items():
        raw=(folder/name).read_bytes();assert digest(raw)==item['sha256'] and len(raw)==item['bytes']
    preserved[folder.name]=len(manifest['files'])
findings=[dict(id='SPEC25-FINAL-01',severity='P1',file='src/aegis_dc/lookahead_policy.py',line=88,
    requirement='baseline-selection.md section2: all positive-support continuation branches must fit the same hard resource budget',
    summary='Inspection continuation does not fit the common cumulative admission budget despite individual eligibility',
    static_counterexample='Remainingperson_s/tool_s15;inspection/actioncandidatewindows10each;modeledstages1.25each,cost0. Bothauditseligibleandmodeled2.5branchfits15,soinspect_then_actcanwin. Issuinginspectionpermanentlyspends10;continuationenvelope10cannotfitremaining5,evenaftercompletion.',
    resolution='Before allowing an inspection branch with intervention, check sum of its distinct common admission envelopes against remaining budget. Do not actually issue or reserve future work prematurely.'),
    dict(id='SPEC25-FINAL-02',severity='P1',file='src/aegis_dc/lookahead_policy.py',line=85,
    requirement='25shared action authority and baseline-selection.md declared compatible authorized continuation timelines',
    summary='Forecasted beneficial action completion can occur after its known declared authorization expires',
    static_counterexample='Decision0;grant[0,1);declaredforecastwait.25+knownactualwork1=>completion1.25. Currentpublicinterventionassessmentpassesat0;lookaheadusesafter_capacityat1.25andmayselectdirectactionorinspectioncontinuation,whileaccepted23willalwaysNO_EFFECTatcompletion.',
    resolution='Gate each positive-support forecast action completion at absolute decisiontime+predictedcompletion against its exact bound grant interval; do not query plant state.')]
review=dict(schema='aegisdc-ticket25-static-spec-final-preflight-v1',status='CHANGES_REQUIRED',source=PIN,comparison_base=BASE,
    unresolved_findings=len(findings),findings=findings,source_files=files,prior_packages_preserved=preserved,
    new_selectors=0,new_assessments=0,new_tests=0,new_physics=0,new_inference=0,
    reviewed_scope=['allfivepoliciesandcommonpublicframe','arrivedfixed/actualinspectionevidence','delayedworkacknowledgments','currentauthority','cumulativecommonenvelope','CLI','lookaheadknownwork/reportbinding','sharedoptionalclosure'],
    resolved_prior_findings=['SPEC25-MID-01','SPEC25-MID-01-HORIZON','SPEC25-MID-02','SPEC25-MID-03'],
    not_findings=['Numericmeasurementbeliefthresholdisadeclaredmodelassumption;changingitaloneisnotaprovenreportbindingdefect','Declaredforecasttravel/waitremainexplicitassumptions','Noformal/rootfull/effecttrialyet'],
    reviewed_utc=datetime.now(timezone.utc).isoformat())
write(OUT/'review.json',review)
report='''# Ticket25 final-candidate SPEC preflight

CHANGES_REQUIRED atb199271a againstf1f88c36. Two P1 forecast-feasibility findings remain.

- SPEC25-FINAL-01, `lookahead_policy.py:85–89`: inspection and continuation only check individual candidate eligibility. The shared v3 budget permanently charges full task-window envelopes, while the action-value branch checks shorter modeled stage costs. With remainingperson/tool15 and two envelopes10each, modeled1.25+1.25stages can make inspection preferable; after issuing it, remaining5 can never admit its necessary10continuation. This violates the declared all-positive-branches/common-hard-budget rule. Check the complete branch's distinct admission envelopes before ranking; submit only the present first action.
- SPEC25-FINAL-02, same forecast gate: current issue authority is checked, but known forecast completion is not. Atdecision0, grant[0,1) and wait.25+knownwork1 produce forecast completion1.25. The model can credit after-capacity and select this direct/continuation action although the accepted physical executor must returnNO_EFFECT at expiry. Check each positive-support action completion at its absolute forecast time against the bound authorization interval.

The original mid-review defects are corrected in the pinned source. Static inspection confirms same advancing plant, arrived-only evidence, explicit periodic reference, unknown-risk accounting, common candidate/crew resources, current proposal authority, no-human behavior and optional shared closure. Model alternatives use one catalog/demand/joint-outcome horizon; no overlapping gains are summed. Numeric threshold calibration remains a declared assumption, not a proven report-binding defect.

No selector, assessment, test, physics or inference was executed. Earlier25reviews and all24packages remain unchanged. The current final contract still needs its declared documentation update and frozen engineering/root/delivery gates; no policy gain, ticket acceptance or overall completion is claimed.
'''
(OUT/'SPEC.md').write_text(report,encoding='utf-8',newline='\n')
write(OUT/'delivery-manifest.json',dict(source=PIN,files={p.relative_to(OUT).as_posix():dict(sha256=digest(p.read_bytes()),bytes=p.stat().st_size) for p in OUT.rglob('*') if p.is_file()}))
print(json.dumps(dict(status='CHANGES_REQUIRED',findings=2,exports=len(files),report_words=len(report.split()),prior_preserved=preserved,new_application_calls=0)))
