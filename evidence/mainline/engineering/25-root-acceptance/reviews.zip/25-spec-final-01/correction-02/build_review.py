"""Independent static correction export and integrity checks only."""
from pathlib import Path
from hashlib import sha256
import json,subprocess
from datetime import datetime,timezone
REPO=Path('C:/Users/Donson/.codex/worktrees/mainline23-intervention/Renly')
OUT=Path(__file__).resolve().parent;BASE=OUT.parent
PIN='db8229bdadaf89732f850950845e522c004827f7';PRIOR='e571cb915d6b2bf42a9ccbdf04776fdf81e986b0'
checks=[]
def verify(ok,name):
    checks.append(dict(name=name,passed=bool(ok)))
    if not ok:raise ValueError(name)
def git(*args):return subprocess.check_output(['git',*args],cwd=REPO)
def digest(raw):return sha256(raw).hexdigest()
def write(p,value):
    with p.open('x',encoding='utf-8',newline='\n') as stream:stream.write(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
preserved={}
for folder in (BASE,BASE/'correction-01'):
    manifest=json.loads((folder/'delivery-manifest.json').read_bytes())
    for name,item in manifest['files'].items():
        raw=(folder/name).read_bytes()
        verify(digest(raw)==item['sha256'] and len(raw)==item['bytes'],'prior artifact '+folder.name+'/'+name)
    preserved[folder.name]=len(manifest['files'])
names=['src/aegis_dc/dispatch_policy.py','src/aegis_dc/policy_budget.py','src/aegis_dc/lookahead_policy.py',
    'docs/mainline/25-policy-execution.md','tests/test_dispatch_policy.py']
logs=git('ls-tree','-r','--name-only',PIN,'evidence/mainline/engineering/25-baselines/development').decode().splitlines()
names +=[n for n in logs if Path(n).name.startswith(('72-','73-','74-'))]
files={};source={}
for name in names:
    raw=git('cat-file','blob',PIN+':'+name);blob=git('rev-parse',PIN+':'+name).decode().strip()
    p=OUT/'export'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw);source[name]=raw
    verify(p.read_bytes()==raw,'immutable exact export '+name)
    verify(git('cat-file','blob',blob)==raw,'Git blob identity '+name)
    files[name]=dict(sha256=digest(raw),bytes=len(raw),git_blob=blob)
diff=git('diff',PRIOR,PIN,'--','src/aegis_dc');(OUT/'correction.diff').write_bytes(diff)
changed=git('diff','--name-only',PRIOR,PIN,'--','src/aegis_dc').decode().splitlines()
verify(set(changed)=={'src/aegis_dc/dispatch_policy.py','src/aegis_dc/policy_budget.py','src/aegis_dc/lookahead_policy.py'},'runtime delta limited to exact-account correction')
budget=source['src/aegis_dc/policy_budget.py'].decode();dispatch=source['src/aegis_dc/dispatch_policy.py'].decode();lookahead=source['src/aegis_dc/lookahead_policy.py'].decode()
verify("window=Fraction(task['deadline_s'])-Fraction(candidate['available_at_s'])" in budget,'raw window exact decoded Fraction')
verify("remaining={key:Fraction(budget[key])-spent[key] for key in DIMENSIONS}" in budget,'remaining exact decoded Fraction less issued sums')
verify('self.reservations,self.spent,self.remaining,self.cost_unit=_state(frame,program,history,candidates)' in budget,'same exact state retained by AdmissionBudget')
verify('sum((self.reservations[candidate_id][key] for candidate_id in candidate_ids),Fraction(0))' in budget
    and '<=self.remaining[key] for key in DIMENSIONS)' in budget,'joint reserve test uses exact state directly')
verify("if not self.can_reserve([audit['candidate_id']])" in budget,'single task uses same reserve test')
verify('admission_budget=AdmissionBudget(frame,program,history,candidates)' in dispatch
    and 'ledger=admission_budget.audit(audits)' in dispatch,'selector creates one exact admission account')
verify('admission_budget=admission_budget' in dispatch,'selector passes exact account to lookahead')
verify("admission_budget.can_reserve([binding['inspection_candidate_id'],binding['intervention_candidate_id']])" in lookahead,'continuation uses exact account')
verify("Fraction(first[k])" not in lookahead and 'resource_ledger[' not in lookahead,'rounded display values removed from continuation gate')
verify("grant['starts_at_s']<=finish<grant['expires_at_s']" in lookahead,'strict forecast completion authority preserved')
report='''# 第25项精确预算修订复核

固定源db8229bd静态复核通过；原两项最终候选发现及精度残余均已修正。AdmissionBudget以同一原始Fraction账计算窗口、已发扣减及剩余额度，单任务与联合continuation共享can_reserve，显示浮点不再进入联合门槛。严格半开授权时点检查保留。

RED72/GREEN73及74仅作为作者原件导出。先前报告、差异及清单逐项验哈希未变。本复核未新增selector、assessment、测试、物理、推理或捕获调用。

冻结交付工具、保存结果独立复核、根回归与验收仍待完成；未声称第25项或整体研究完成。
'''
(OUT/'SPEC.md').write_text(report,encoding='utf-8',newline='\n')
review=dict(schema='aegisdc-ticket25-static-exact-budget-correction-review-v1',status='STATIC_CORRECTIONS_PASS_FINAL_GATES_PENDING',
    source=PIN,prior_source=PRIOR,unresolved_findings=0,resolved_findings=['SPEC25-FINAL-01','SPEC25-FINAL-01-ROUNDING','SPEC25-FINAL-02'],
    checks_passed=len(checks),checks=checks,source_files=files,prior_packages_preserved=preserved,
    new_selectors=0,new_assessments=0,new_tests=0,new_physics=0,new_inference=0,new_captures=0,
    acceptance_claimed=False,root_gate='PENDING',full_goal='ACTIVE',reviewed_utc=datetime.now(timezone.utc).isoformat())
write(OUT/'review.json',review)
write(OUT/'delivery-manifest.json',dict(source=PIN,files={p.relative_to(OUT).as_posix():dict(sha256=digest(p.read_bytes()),bytes=p.stat().st_size) for p in OUT.rglob('*') if p.is_file()}))
print(json.dumps(dict(status=review['status'],checks_passed=len(checks),exports=len(files),prior_preserved=preserved,
    report_sha256=digest((OUT/'SPEC.md').read_bytes()),review_sha256=digest((OUT/'review.json').read_bytes()),new_application_calls=0)))
