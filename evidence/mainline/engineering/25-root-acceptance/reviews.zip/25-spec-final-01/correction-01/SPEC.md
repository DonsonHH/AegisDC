# Ticket25 final-candidate correction review

Sourcee571cb91 statically resolves SPEC25-FINAL-02: both predicted action issue and completion are checked at absolute decision-relative times against the bound half-open authorization. Completion exactly at expiry remains unavailable. The common continuation-envelope logic also fixes the original integer example, and the updated contract distinguishes conservative admission envelopes, actual occupation and forecast assumptions.

One P2 residual remains for SPEC25-FINAL-01 at `lookahead_policy.py:95`: branch sums use rounded display reservations and remaining budget. For two raw windows10−Fraction(.3), each exact reservation is9.700000000000000011… but displayfloat9.7 is9.699999999999999289…. Budgetfloat19.4 equals twice that display. The combined display check passes although the exact cumulative accounting prevents the second action after the first is issued. Compare raw exact candidate reservations against the exact budget remainder, leaving display conversion only for output.

The original final review remains immutable; author RED67/GREEN68 and69/70 plus71 are saved evidence, not reviewer execution. This supplement performs zero selectors, assessments, tests, physics or inference. No formal capture/root regression/acceptance or policy-effect conclusion is claimed.
