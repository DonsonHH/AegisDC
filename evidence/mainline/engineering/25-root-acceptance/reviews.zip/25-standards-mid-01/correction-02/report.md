# Standards correction supplement — endpoint closure

Pinned correction0509768f is statically reviewed against5697c7b5. Unresolved documented Standards findings in the reviewed correction paths:0. This is not final ticket acceptance.

The remaining STD25-MID-02 terminal-poll boundary is corrected. LiveSensorSession now includes the adjacent rational counter, rounds each candidate to its supported binary64 epoch, then admits only epochs at or before the run horizon. With phase0/period.1/duration.5, counter5 is retained at.5, matching the same prefix in a longer run. Per-instrument budget and distinct-coordinate checks apply to included polls; a rounded coordinate beyond the horizon is not sampled. Explicit validated counters still bridge to the accepted observation law, leaving its default saved-trace path unchanged.

STD25-MID-01 remains statically corrected:generic positive-latency rejection acknowledgments release the public concurrency book only after arrival, without exposing actual refusal cause or location. The inherited minimum-duration inspection concern remains resolved by the same additive completion coordinate as the crew scheduler. Strict current action authorization and cumulative no-refund admission envelopes are unchanged.

The nonblocking malformed-binding note is addressed:task/status, intervention binding, condition and forecast identities receive text guards before hash membership/indexing. The CLI now loads the declared policy program through strict JSON and the same simulate_scenario path; its implementation grants no extra execution authority.

Author RED50 preserves the five-versus-six endpoint failure; GREEN51 and binding RED52/GREEN53 remain saved. Read log54 reporting33 targeted passes; none were rerun. Previous reports, hashes, counterexamples and correction01 remain byte-identical.

The existing registry-merge duplication heuristic remains nonblocking. Timing mapping, actual online lookahead, closure integration, frozen artifacts and root gates are still pending, as declared by the owner. No tests, probes, assessments, physics, inference, captures or full regressions were executed by this reviewer. The complete research goal remains active.
