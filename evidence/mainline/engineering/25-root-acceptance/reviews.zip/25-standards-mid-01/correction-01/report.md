# Standards correction supplement — ticket25

Reviewed committed correction:5697c7b5 versus original2e7645e5. The supplied pin had an extra leadingf; the actual branch commit was independently resolved. Static review only.

STD25-MID-01 is corrected:all crew rejection paths now generate a generic task-local report after a positive administrative interval. It discloses no actual location/private refusal cause. The public history accepts rejected terminal reports, releases concurrency only after arrival, and retains spent admission envelopes/costs. The inherited inspection endpoint defect is also corrected with the scheduler's additive completion coordinate.

STD25-MID-02 is partly corrected:explicit validated measurement counters prevent sample_trace from losing an internally scheduled rounded-down decimal epoch, preserving the accepted default sampling path. One P2 endpoint remains in live_sensor_execution.py:19:count still floors the exact rational duration/period before rounding epochs. With phase0,period.1,duration.5, count5 creates only counters0–4; counter5 rounds to supported endpoint.5 but is never scheduled. The new test covers the .5poll within a1s run, not a terminal rounded-down poll. The same declared timing/coverage rule cited by the original finding still requires correction.

New authority checks validate declared task/kind/bindings before selection, require v3 selector/executor declarations to agree, and keep completion-time authorization separate. The v3 budget is explicitly a conservative full-candidate-window admission envelope; terminal feedback releases concurrency but does not refund spent/reserved work/tool/cost. Actual plant time is separately reported. Timing-model bridging, CLI, closure and final gates remain declared unfinished.

Nonblocking robustness note:malformed plain-JSON task_id=[] in the new binding loop reaches set membership before text validation and can raise TypeError rather than a controlled refusal. The prior registry-merge duplication heuristic is unchanged.

Original reports and artifacts remain unchanged. Read author RED/GREEN39–46 and log47 reporting70passes; executed none. No tests, probes, assessments, physics, inference or captures were run. This supplement does not accept ticket25 or the research goal.
