# Standards — ticket25 mid-development

Fixed comparison:f1f88c36...2e7645e5. Static committed-byte review only.

**Documented violations (P2, two):**

1. `policy_execution.py:92–93` records every submitted intention as issued, while `dispatch_policy.py:32,41–43` recognizes no rejected terminal report and reserves its resources indefinitely. `workforce_dispatch.py:215–229` can reject a publicly eligible task for an infeasible actual deadline/shift without feedback. Example:at0, same-site access.25 plus work1, deadline.5; the executor rejects, yet the next admissible same-crew candidate remains permanently busy. `25-policy-execution.md:5` requires a public acknowledged resource book, and:9 requires constrained/failed-action traceability. Add a declared delayed/task-local rejection channel and release only after its arrival, preserving the hidden-state boundary.

2. `live_sensor_execution.py:23,36` rounds a rational poll epoch then asks `sample_trace` to regenerate due counters. `sensor_channels.py:323` floors the rounded endpoint against the exact period. For phase0/period.1, fifth exact poll lies just above.5 but rounds to.5; count becomes5 and omits counter5. All earlier polls precede the single saved point, so no measurement is produced. This violates ADR0002's declared sparse-measurement coverage/timing and the mainline spec's event-order verification requirement. Use one consistent counter/epoch convention without inventing future samples.

**Inherited integration concern, not a new-diff finding:** `inspection_execution.py:84–85` still subtracts exact Fractions of rounded work endpoints. Full work.2→1.2 may be discarded as shorter than1s, the same boundary already corrected for interventions23. Online inspection integration should cover it before acceptance.

**Judgment-only smell:** possible duplicated registry-merge logic at `policy_execution.py:32–36,52–56`; a small shared merge operation could clarify the same identity check. Nonblocking.

Cumulative budgets, forecast timing bridge, CLI and frozen/root acceptance are declared unfinished, not misreported as regressions. No tests, probes, assessments, physics, inference or captures were executed. All prior24Standards artifacts remain unchanged. This pin is not ready for ticket acceptance; the complete research goal remains active.
