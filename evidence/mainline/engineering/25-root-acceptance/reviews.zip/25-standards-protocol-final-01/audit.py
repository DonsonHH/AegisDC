"""Static Git/JSON/AST inspection only; does not import project modules."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction
import subprocess
import json
import ast

ROOT=Path('C:/Users/Donson/.codex/worktrees/mainline23-intervention/Renly')
OUT=Path(__file__).resolve().parent
OLD='1f4b3e91a86c3ddfdfc85977ebaf4d10ddb77b6c'
REV='3b3275c95836d4316a297a36caff064de354f83d'
RUNTIME='319d1d1b51ffe893223f28add2012fec12540b4b'
PACKAGE='evidence/mainline/engineering/25-baselines'
PROTOCOL='docs/mainline/25-policy-engineering-protocol.json'

def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT)
def sha(raw):return sha256(raw).hexdigest()
def write(name,value):
    raw=value if isinstance(value,bytes) else (json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode()
    p=OUT/name;p.parent.mkdir(exist_ok=True,parents=True)
    with p.open('xb') as stream:stream.write(raw)
def blobs(revision,names):
    names=sorted(set(names));raw=subprocess.check_output(['git','cat-file','--batch'],cwd=ROOT,
        input=''.join(revision+':'+n+'\n' for n in names).encode());result={};offset=0
    for name in names:
        end=raw.index(b'\n',offset);header=raw[offset:end].split()
        assert len(header)==3 and header[1]==b'blob',name
        start=end+1;size=int(header[2]);result[name]=raw[start:start+size];offset=start+size+1
    assert offset==len(raw);return result

p=json.loads(blobs(REV,[PROTOCOL])[PROTOCOL]);checks=[]
def check(name,value,actual=None):
    checks.append(dict(name=name,passed=bool(value),actual=actual));assert value,name
check('actual pinned source object',git('rev-parse','--verify',REV+'^{commit}').decode().strip()==REV)
check('runtime unchanged after319d',not git('diff','--name-only',RUNTIME,REV,'--','src'))
check('only author tool changed from original frozen pin',git('diff','--name-only',OLD,REV).decode().splitlines()==['scripts/policy_delivery.py'])
check('13 frozen cases',len(p['cases'])==p['physical_runs']==13)
check('30 declared seconds',sum(Fraction(c['duration_s']) for c in p['cases'])==Fraction(p['total_simulated_duration_s'])==30)
check('distinct case/input identities',len({c['id'] for c in p['cases']})==len({c['input'] for c in p['cases']})==13)
check('scope calls zero',p['registered_research_trials']==p['llm_calls']==p['training_calls']==0 and p['full_regression']=='ROOT_INTEGRATED_ONLY')
check('engineering field scope',p['field_calibration']=='PENDING' and p['classification']=='FINITE_ENGINEERING_INTERFACE_CHECKS_NOT_EFFECT_COMPARISON')
declared=set(p['durable_root'])|{c['id']+'/'+n for c in p['cases'] for n in p['durable_case']}
check('57 durable outputs and receipt',len(declared)==57 and p['terminal_receipt']=='receipt.json',len(declared))
check('no output caches',all('__pycache__' not in n and not n.endswith(('.pyc','.pyo')) for n in declared))
paths=git('ls-tree','-rz','--name-only',REV,'src','tests','configs',PACKAGE+'/development',PACKAGE+'/reference',
    'evidence/mainline/engineering/18-beliefs/capture-01','evidence/mainline/engineering/23-interventions/reference').decode().strip('\0').split('\0')
inputs={PROTOCOL,p['contract'],p['literature_note'],PACKAGE+'/.gitattributes'}|{n for n in paths if n.startswith(('tests/',PACKAGE+'/',
    'configs/full-facility','configs/materials/','evidence/mainline/engineering/18-beliefs/capture-01/',
    'evidence/mainline/engineering/23-interventions/reference/')) and '__pycache__' not in n and not n.endswith(('.pyc','.pyo'))}
groups=dict(runtime={n for n in paths if n.startswith('src/') and n.endswith('.py')},
    tools={p['authoring_tool'],p['helper_tool'],p['input_preparation_tool']},inputs=inputs)
raws=blobs(REV,set().union(*groups.values()));pins={role:{n:dict(sha256=sha(raws[n]),bytes=len(raws[n])) for n in sorted(names)} for role,names in groups.items()}
check('case input pins',all(c['input'] in inputs for c in p['cases']))
check('preparation fixture pins',all(p[k] in inputs for k in ('input_fixture','additional_test_input','closure_test_input')))
check('configuration references pinned',all(n in inputs for n in ('configs/full-facility-sensor-channels-v1.json','configs/full-facility-belief-model-v1.json',
    'configs/full-facility-action-value-v1.json','configs/full-facility-risk-scenarios-v1.json')))
check('all referenced blobs exist',len(raws)==sum(len(v) for v in groups.values()))
for name in groups['tools']:ast.parse(raws[name].decode(),filename=name)
check('tool syntax without execution',len(groups['tools'])==3)
documents={c['id']:json.loads(raws[c['input']]) for c in p['cases']}
for name,d in documents.items():check('closed prepared outer input '+name,set(d)=={'classification','model','dispatch_program'} and d['classification']=='ENGINEERING_ONLY_NOT_POLICY_EFFECT_TRIAL')
common=[]
for name in p['same_world_cases']:
    document=json.loads(json.dumps(documents[name]));policy=document['dispatch_program']['policy_program'];policy.pop('policy');policy.pop('options');common.append(document)
check('five same-world declarations',len(common)==5 and all(d==common[0] for d in common))
left,right=(documents[n] for n in p['hidden_public_equal_cases'])
check('hidden pair public declarations',left['dispatch_program']==right['dispatch_program'])
changes=[(a['id'],a['value'],b['value']) for a,b in zip(left['model']['parameters'],right['model']['parameters']) if a!=b]
check('hidden pair only access change',changes==[('it_access_permit',1,0)])
text=raws[p['authoring_tool']].decode();helper=raws[p['helper_tool']].decode()
check('clean source guard',"require(not git('status','--porcelain')" in text and 'unchanged(source,identities)' in text)
check('unique/exclusive output',"folder.mkdir(exist_ok=False)" in text and "with p.open('xb')" in helper)
check('started fsync before physical call',text.index("status='STARTED'")<text.index('result=simulate_scenario(') and 'os.fsync(stream.fileno())' in text)
check('saved validation before next case',text.index('check_case(folder,case,protocol);receipt')<text.index("status='COMPLETED'"))
check('failure retained and propagated',"status='FAILED'" in text and 'error=str(error)));raise' in text)
check('cache classification explicit',"'__pycache__' not in p.parts" in helper and "{'.pyc','.pyo'}" in helper)
check('first error preserved on source guard failure',"receipt.setdefault('error_type','SourceGuardError')" in text and "receipt.setdefault('error','Source changed during capture')" in text
    and "source_guard_error='Source changed during capture'" in text)
section=text[text.index('def verify('):]
check('save-only verifier',all(name not in section for name in ('simulate_scenario(','choose_work(','assess_closure(')))
check('delivery Git/source guards',"hashes(delivery" in section and "receipt['pinned']==pins(protocol,source)" in section and "run['code_identity']['git_commit']==source" in section)
check('strict ledger source/order',"[r['status'] for r in pair]==['STARTED','COMPLETED']" in section and "r['execution_commit']==source" in section)
check('exact figure re-derivation',"raw==(folder/name).read_bytes()" in section)

prior_dir=OUT.parent/'25-standards-final-01'
prior={q.relative_to(prior_dir).as_posix():sha(q.read_bytes()) for q in prior_dir.rglob('*') if q.is_file()}
write('prior-review-hashes.json',prior)
export_names=[PROTOCOL,p['authoring_tool'],p['helper_tool'],p['input_preparation_tool'],p['contract']]
for name in export_names:write('export/'+name,raws[name])
write('original-tool.py',blobs(OLD,[p['authoring_tool']])[p['authoring_tool']])
write('tool-fix.diff',git('diff','--no-ext-diff',OLD,REV,'--',p['authoring_tool']))
write('pin-manifest.json',dict(source=REV,pin_counts={k:len(v) for k,v in pins.items()},pins=pins,new_project_calls=0))
write('static-checks.json',dict(status='PASS_FOR_LISTED_STATIC_CHECKS',checks_passed=len(checks),checks=checks,unresolved_findings=0,source=REV,
    durable_output_count=57,terminal_receipts=1,physical_runs_declared=13,simulated_duration_s=30,new_selector_calls=0,new_assessments=0,
    new_simulate_calls=0,new_tests=0,new_inference=0,new_capture=0,prior_review_files_preserved=len(prior)))
print(json.dumps(dict(source=REV,static_checks_passed=len(checks),pin_counts={k:len(v) for k,v in pins.items()},outputs=57,
    unresolved_findings=0,prior_review_files_preserved=len(prior),new_project_calls=0)))
