"""Independent saved JSON/Git/Fraction audit; never import project runtime."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction
import subprocess
import json
import ast
import math

ROOT=Path('C:/Users/Donson/.codex/worktrees/mainline23-intervention/Renly')
OUT=Path(__file__).resolve().parent
WORK=OUT.parent
DELIVERY='f2e66125f782b54fbebd2a7818ba76e9a0a3927c'
SOURCE='6a9e3ca8dfd38bf529bec51cd3e10ad66af320d9'
OLD_SOURCE='e4d48e74abc4ad7b0a199ff9805f9eac06a45d45'
OLD_DELIVERY='e5f195254b890bb2aa3fccee6f540b729ea39175'
README_SOURCE='b6ce92e3d516f28234f8d82ea7657db8da20add5'
PACKAGE='evidence/mainline/engineering/25-baselines'
OLD_CAPTURE=PACKAGE+'/capture-01'
CAPTURE=PACKAGE+'/capture-02'
OLD_PROTOCOL='docs/mainline/25-policy-engineering-protocol.json'
PROTOCOL='docs/mainline/25-policy-engineering-correction-01.json'

def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT)
def sha(raw):return sha256(raw).hexdigest()
def write(name,value):
    raw=value if isinstance(value,bytes) else (json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode()
    target=OUT/name;target.parent.mkdir(exist_ok=True,parents=True)
    with target.open('xb') as stream:stream.write(raw)
def names(revision,*paths):
    value=git('ls-tree','-rz','--name-only',revision,*paths).decode().strip('\0')
    return value.split('\0') if value else []
def blobs(revision,paths):
    paths=sorted(set(paths));raw=subprocess.check_output(['git','cat-file','--batch'],cwd=ROOT,
        input=''.join(revision+':'+n+'\n' for n in paths).encode());result={};offset=0
    for name in paths:
        end=raw.index(b'\n',offset);header=raw[offset:end].split()
        assert len(header)==3 and header[1]==b'blob',name
        start=end+1;size=int(header[2]);result[name]=raw[start:start+size];offset=start+size+1
    assert offset==len(raw);return result
def read(raw):return json.loads(raw)
def jsonl(raw):return [json.loads(line) for line in raw.decode().splitlines()]

checks=[]
def check(name,condition,actual=None):
    checks.append(dict(name=name,passed=bool(condition),actual=actual));assert condition,name
def close(name,actual,expected,tolerance=1e-9):
    check(name,math.isclose(actual,expected,abs_tol=tolerance,rel_tol=0),dict(actual=actual,expected=expected))

prior={}
for folder in ('25-standards-mid-01','25-standards-final-01','25-standards-protocol-final-01'):
    for path in (WORK/folder).rglob('*'):
        if path.is_file():prior[folder+'/'+path.relative_to(WORK/folder).as_posix()]=sha(path.read_bytes())
write('prior-reviews-before.json',prior)
original_names=names(OLD_DELIVERY,OLD_CAPTURE)
old=blobs(OLD_DELIVERY,original_names)
delivered_originals=blobs(DELIVERY,original_names)
protocol_raw=blobs(SOURCE,[PROTOCOL])[PROTOCOL];protocol=read(protocol_raw)
old_protocol=read(blobs(OLD_SOURCE,[OLD_PROTOCOL])[OLD_PROTOCOL])
receipt_names=names(DELIVERY,CAPTURE)
saved=blobs(DELIVERY,receipt_names)
receipt=read(saved[CAPTURE+'/receipt.json'])
old_receipt=read(old[OLD_CAPTURE+'/receipt.json'])
check('old durable set has11files',len(original_names)==11,len(original_names))
check('original fail status preserved',old_receipt['status']=='FAIL' and old_receipt['physical_attempts']==old_receipt['physical_completed']==2
    and old_receipt['validated_cases']==1 and old_receipt['failures']==1 and old_receipt['simulated_duration_attempted_s']==8)
check('original semantic failure preserved',old_receipt['error_type']=='ValueError' and old_receipt['error']=='Literal selection sequence differs: fifo'
    and old_receipt['execution_commit']==OLD_SOURCE and old_receipt['source_head_and_bytes_unchanged'])
for name,raw in old.items():
    check('original11byte preservation '+name,delivered_originals[name]==raw)
    local=name[len(OLD_CAPTURE)+1:]
    if local!='receipt.json':check('original receipt hash '+local,sha(raw)==old_receipt['artifacts'][local])
check('original receipt exact membership',set(old_receipt['artifacts'])=={n[len(OLD_CAPTURE)+1:] for n in original_names if not n.endswith('/receipt.json')})
old_ledger=jsonl(old[OLD_CAPTURE+'/attempts.jsonl'])
check('old fail ledger exact',[(r['case'],r['status']) for r in old_ledger]==[('no-human','STARTED'),('no-human','COMPLETED'),('fifo','STARTED'),('fifo','FAILED')])
check('original starts carryexecution',all(r['execution_commit']==OLD_SOURCE and r.get('duration_s',4)==4 for r in old_ledger if r['status']=='STARTED'))
check('original terminal failledger cause',old_ledger[-1]['error']=='Literal selection sequence differs: fifo')
check('correction source and PASS',receipt['status']=='PASS' and receipt['execution_commit']==SOURCE and receipt['source_head_and_bytes_unchanged'] and receipt['failures']==0)
check('new counts11and2reused',receipt['physical_attempts']==receipt['physical_completed']==receipt['validated_new_cases']==11 and receipt['reused_cases_validated']==2)
check('new22plusold8seconds',Fraction(receipt['simulated_duration_attempted_s'])==22 and Fraction(old_receipt['simulated_duration_attempted_s'])+Fraction(receipt['simulated_duration_attempted_s'])==30)
check('originalfailurehonestlyretained',receipt['original_validation_failure_retained'] is True)
check('engineering scope preserved',receipt['registered_research_trials']==receipt['llm_calls']==receipt['training_calls']==0 and receipt['field_calibration']=='PENDING'
    and receipt['global_regression_gate']=='PENDING_ROOT_INTEGRATED_FULL')
check('protocol declared budget unchanged cumulative',protocol['new_physical_runs']==11 and protocol['new_simulated_duration_s']==22
    and protocol['cumulative_physical_runs']==13 and protocol['cumulative_simulated_duration_s']==30)
check('protocol reused exactly original two',protocol['reused_cases']==['no-human','fifo'] and protocol['original_execution']==OLD_SOURCE and protocol['original_delivery']==OLD_DELIVERY)
old_cases={c['id']:c for c in old_protocol['cases']};cases={c['id']:c for c in protocol['cases']}
check('same13case identities',set(cases)==set(old_cases) and len(cases)==13)
check('only FIFO oracle revised',[c['id'] for c in protocol['cases'] if c!=old_cases[c['id']]]==['fifo'])
new_cases=[c for c in protocol['cases'] if c['id'] not in protocol['reused_cases']]
check('newcase budget independently summed',len(new_cases)==11 and sum(Fraction(c['duration_s']) for c in new_cases)==22)
declared=set(protocol['durable_root'])|{c['id']+'/'+n for c in protocol['cases'] for n in protocol['durable_case']}
check('58declared outputs plus receipt',len(declared)==58 and set(receipt['artifacts'])==declared and set(receipt_names)=={CAPTURE+'/'+n for n in declared|{'receipt.json'}})
check('durable caches absent',all('__pycache__' not in n and not n.endswith(('.pyc','.pyo')) for n in original_names+receipt_names))
artifact_hashes={}
for name in sorted(declared|{'receipt.json'}):
    raw=saved[CAPTURE+'/'+name];artifact_hashes[name]=dict(sha256=sha(raw),bytes=len(raw))
    if name!='receipt.json':check('correction artifact receipt hash '+name,sha(raw)==receipt['artifacts'][name])
new_ledger=jsonl(saved[CAPTURE+'/attempts.jsonl'])
check('newledger22rows',len(new_ledger)==22,len(new_ledger))
for i,case in enumerate(new_cases):
    pair=new_ledger[2*i:2*i+2]
    check('ordered newattempt '+case['id'],[r['status'] for r in pair]==['STARTED','COMPLETED'] and all(r['case']==case['id'] and r['execution_commit']==SOURCE for r in pair)
        and pair[0]['duration_s']==case['duration_s'])
check('no reused physical attempts',not set(protocol['reused_cases'])&{r['case'] for r in new_ledger})
index=read(saved[CAPTURE+'/reused-originals.json'])
check('explicit reuse classification',index['classification']=='BYTE_IDENTICAL_REUSE_NO_NEW_PHYSICAL_CALL' and index['original_failed_capture']==OLD_CAPTURE)
check('reuse failedreceipt hash',index['original_failed_receipt_sha256']==sha(old[OLD_CAPTURE+'/receipt.json']))
expected_reused={case+'/'+n for case in protocol['reused_cases'] for n in protocol['durable_case']}
check('reuse index exact8members',set(index['copies'])==expected_reused and len(expected_reused)==8)
check('reuse originalindex exact11',index['original_artifacts']=={n:sha(raw) for n,raw in old.items()})
for name,item in index['copies'].items():
    check('reuse source byte identity '+name,item['original']==OLD_CAPTURE+'/'+name and saved[CAPTURE+'/'+name]==old[item['original']]
        and sha(saved[CAPTURE+'/'+name])==item['sha256'])

# Reconstruct pin roles independently, without importing the authoring tools.
paths=names(SOURCE,'src','tests','configs',PACKAGE+'/development',PACKAGE+'/reference',
    'evidence/mainline/engineering/18-beliefs/capture-01','evidence/mainline/engineering/23-interventions/reference')
input_names={OLD_PROTOCOL,protocol['contract'],protocol['literature_note'],PACKAGE+'/.gitattributes'}|{n for n in paths if n.startswith(('tests/',PACKAGE+'/',
    'configs/full-facility','configs/materials/','evidence/mainline/engineering/18-beliefs/capture-01/',
    'evidence/mainline/engineering/23-interventions/reference/')) and '__pycache__' not in n and not n.endswith(('.pyc','.pyo'))}
input_names|={PROTOCOL,protocol['revision_note'],*original_names}
groups=dict(runtime={n for n in paths if n.startswith('src/') and n.endswith('.py')},tools={protocol['authoring_tool'],protocol['original_authoring_tool'],
    protocol['helper_tool'],protocol['input_preparation_tool']},inputs=input_names)
source_files=blobs(SOURCE,set().union(*groups.values()));delivery_files=blobs(DELIVERY,set(source_files));pins={}
check('exact pin counts66/4/201',{k:len(v) for k,v in groups.items()}=={'runtime':66,'tools':4,'inputs':201})
for role,named in groups.items():
    check('pinmembership '+role,set(receipt['pinned'][role])==named)
    pins[role]={}
    for name in sorted(named):
        raw=source_files[name];h=sha(raw);pins[role][name]=dict(sha256=h,bytes=len(raw))
        check('source/delivery byte pin '+role+'/'+name,h==receipt['pinned'][role][name] and raw==delivery_files[name])
for role,identities in old_receipt['pinned'].items():
    original_blobs=blobs(OLD_SOURCE,identities)
    for name,h in identities.items():check('original execution pin '+role+'/'+name,sha(original_blobs[name])==h and delivery_files[name]==original_blobs[name])
check('runtime physical unchanged across sources',receipt['pinned']['runtime']==old_receipt['pinned']['runtime'])
for name in groups['tools']:ast.parse(source_files[name].decode(),filename=name)
check('four tools parsed without project execution',len(groups['tools'])==4)
documents={c['id']:read(source_files[c['input']]) for c in protocol['cases']}
for case in protocol['cases']:
    check('13inputs unchanged from initial execution '+case['id'],source_files[case['input']]==blobs(OLD_SOURCE,[case['input']])[case['input']])

case_audits={};runs={}
for case in protocol['cases']:
    name=case['id'];folder=CAPTURE+'/'+name;run=read(saved[folder+'/run.json']);runs[name]=run;expected=case['expected'];inputs=documents[name]
    trace=jsonl(saved[folder+'/private-state.jsonl']);balances=jsonl(saved[folder+'/balances.jsonl']);summary=run['summary'];decisions=run['policy_public_decisions']
    expected_source=OLD_SOURCE if name in protocol['reused_cases'] else SOURCE
    check('mixed actualexecution revision '+name,run['code_identity']['git_commit']==expected_source and run['code_identity']['implementation_has_changes'] is False)
    for path,h in run['code_identity']['files'].items():check('actualruntime recorded source '+name+'/'+path,path in receipt['pinned']['runtime'] and h==receipt['pinned']['runtime'][path])
    check('saved input model/program '+name,read(saved[folder+'/scenario.json'])==inputs['model'] and run['inputs']['dispatch_program']==inputs['dispatch_program'])
    check('declared horizon and step '+name,run['inputs']['duration_s']==case['duration_s'] and run['inputs']['maximum_step_s']==protocol['maximum_step_s'])
    check('all trace and balances covered '+name,len(trace)==len(balances)+1 and trace[0]['time_s']==0 and trace[-1]['time_s']==case['duration_s'])
    check('positive bounded integration '+name,all(0<b['end_s']-b['start_s']<=protocol['maximum_step_s']+1e-9 for b in balances))
    check('trace/interval current clocks '+name,all(point['time_s']==b['start_s'] and nxt['time_s']==b['end_s'] for point,nxt,b in zip(trace,trace[1:],balances)))
    for member,identity in run['artifacts'].items():
        raw=saved[folder+'/'+member];check('run rawartifact hash '+name+'/'+member,sha(raw)==identity['sha256'])
        count=len(jsonl(raw)) if member.endswith('.jsonl') else 1
        check('run rawartifact count '+name+'/'+member,identity['records']==count)
    chosen=[d['choice']['chosen_candidate_id'] for d in decisions]
    if 'chosen' in expected:check('frozen literal choice '+name,chosen==expected['chosen'])
    if 'forbidden_first' in expected:
        plan=next(a for a in decisions[0]['choice']['forecast_plans'][0]['alternatives'] if a['kind']=='inspect_then_act')
        check('knowncontinuation refusal '+name,chosen[0]!=expected['forbidden_first'] and not plan['eligible'] and expected['forecast_block'] in plan['planning_reasons'])
    completed=[r['completed_at_s'] for r in run['work_records'] if r['status']=='completed']
    effects=[e['applied_at_s'] for e in run.get('intervention_private_audit',{}).get('events',[]) if e['outcome']=='APPLIED']
    check('literalcompletion/effect '+name,completed==expected['completed_at_s'] and effects==expected['effect_at_s'])
    if 'work_status' in expected:check('literalwork status '+name,[r['status'] for r in run['work_records']]==expected['work_status'])
    check('allactualactionfeedback remainsopen '+name,all(r['risk_closed'] is False for r in run.get('intervention_public_feedback',[])))
    check('decision schedule '+name,[d['frame']['as_of_s'] for d in decisions]==inputs['dispatch_program']['decision_times_s'])
    for i,decision in enumerate(decisions):
        frame=decision['frame'];choice=decision['choice'];now=frame['as_of_s']
        check('publicsameclock '+name+'/'+str(i),choice['as_of_s']==now and choice['facility_id']==frame['facility_id'])
        check('nochoicepermission/tour '+name+'/'+str(i),choice['execution_permission'] is False and choice['generated_tour'] is False)
        check('evidencearrived only '+name+'/'+str(i),all(r['observed_at_s']<=r['arrived_at_s']<=now for r in frame['evidence']['records']))
        check('workfeedbackarrived only '+name+'/'+str(i),all(r['observed_at_s']<=r['arrived_at_s']<=now for r in decision['history']['work_feedback']))
        if 'resource_ledger' in choice:
            catalog={c['id']:c for c in inputs['dispatch_program']['policy_program']['candidates']};exact={k:Fraction(0) for k in ('person_s','tool_s','cost')}
            interfaces={w['id']:w for w in frame['nominal_knowledge']['work_interfaces']}
            for issued in decision['history']['issued']:
                candidate=catalog[issued['candidate_id']];task=candidate['task'];window=Fraction(task['deadline_s'])-Fraction(candidate['available_at_s'])
                exact['person_s']+=window*len(task['crew']);exact['tool_s']+=window*len(interfaces[task['work_interface_id']]['tool_ids']);exact['cost']+=Fraction(candidate['issue_cost'])
            for key,value in exact.items():close('independentcumulative ledger '+name+'/'+str(i)+'/'+key,choice['resource_ledger']['spent_or_reserved'][key],float(value))
    if 'fixed_records_per_decision' in expected:
        arrivals=[[[r['observed_at_s'],r['arrived_at_s']] for r in d['frame']['evidence']['records'] if r['source_id']=='rectifier-meter-record'] for d in decisions]
        check('literal fixedarrivals '+name,arrivals==expected['fixed_records_per_decision'])
        check('literal fixedepochs '+name,[p['polled_at_s'] for p in run['policy_sensor_private_audit']]==expected['sensor_poll_epochs_s'])
        measured=[[r for r in d['frame']['evidence']['records'] if r['source_id']=='portable-intake-meter'] for d in decisions]
        check('literalhandheld arrivals '+name,[len(r) for r in measured]==expected['handheld_records_per_decision'])
        if expected['handheld_measurement'] is not None:
            ref=expected['handheld_measurement'];a,b=ref['value_squared_ratio']
            for group in measured:
                for record in group:
                    close('literalhandheld value '+name,record['value'],math.sqrt(a/b));check('literalhandheld times/origin '+name,
                        record['observed_at_s']==ref['observed_at_s'] and record['arrived_at_s']==ref['arrived_at_s'] and record['provenance']['origin_id']=='post-clean-flow')
        check('literal finaladmission spending '+name,run['policy_public_resource_ledger']['spent_or_reserved']==expected['final_spent_or_reserved'])
    if 'initial_forecast_deficit_s' in expected:
        close('literal first forecast '+name,decisions[0]['choice']['forecast_plans'][0]['best_expected_service_deficit_s'],expected['initial_forecast_deficit_s'])
        belief=decisions[2]['choice']['forecast_belief'];a,b=expected['arrived_posterior_cooling_ratio'];close('literal power posterior '+name,belief['posterior']['cooling-limited'],a/b)
        check('fixedchannel explicit update '+name,expected['used_fixed_record_id'] in belief['information_updates'])
        entry=next(r for r in belief['record_audit'] if r['record_id']=='post-clean-flow');check('flowdependence explicit '+name,entry['disposition']=='dependence_not_modeled')
    if 'sensor_polls' in expected:
        audit=run['policy_sensor_private_audit'];check('decimal endpoint originalcounter '+name,len(audit)==expected['sensor_polls'] and audit[-1]['poll_index']==expected['last_poll_index'] and audit[-1]['polled_at_s']==expected['last_polled_at_s'])
    if 'closure_status' in expected:
        question=decisions[-1]['choice']['question_lifecycle']['questions'][0];check('actualreport closurepending '+name,question['status']==expected['closure_status'] and not question['question_closed'] and not question['risk_closed'])
    if expected.get('empty_work_feedback'):check('paid hidden reportnotarrived '+name,run['workforce_public_feedback']==[])
    if name=='hidden-closed':check('positive paid hiddenaccess '+name,summary['access_check_person_s']>0)
    if 'rejection_observed_at_s' in expected:
        report=decisions[2]['history']['work_feedback'][0]
        check('delayedtasklocal genericrejection '+name,decisions[1]['history']['work_feedback']==[] and report['status']=='rejected' and report['reason']=='DECLARED_TASK_ADMISSION_REFUSAL'
            and report['location_id'] is None and report['observed_at_s']==expected['rejection_observed_at_s'] and report['arrived_at_s']==expected['rejection_arrived_at_s'])
    for key in ('demand_service_unit_s','delivered_service_unit_s','service_deficit_time_s'):
        close('literal serviceintegral '+name+'/'+key,summary[key],expected[key]);close('savedbalance sum '+name+'/'+key,math.fsum(b[key] for b in balances),summary[key])
    check('conservation scope '+name,abs(summary['whole_run_energy_residual_J'])<protocol['energy_tolerance_J'] and summary['max_mass_residual_kg']<=protocol['mass_tolerance_kg'])
    check('engineering nonresearch '+name,run['research_trials']==run['model_calls']==run['training_calls']==0 and run['field_calibration']=='PENDING')
    case_audits[name]=dict(actual_execution=expected_source,chosen=chosen,completed_at_s=completed,effect_at_s=effects,trace_points=len(trace),balance_records=len(balances))

# Pure declaration/record reasoning, not another selector or physical run.
fifo_input=documents['fifo']['dispatch_program']['policy_program'];first_decision=runs['fifo']['policy_public_decisions'][0]
eligible={a['candidate_id'] for a in first_decision['choice']['candidates'] if a['eligible']}
order=sorted((c for c in fifo_input['candidates'] if c['id'] in eligible),key=lambda c:(c['available_at_s'],c['id']))
check('independent FIFO declared tie order',order[0]['id']=='first-action' and first_decision['choice']['chosen_candidate_id']==order[0]['id'])
check('original FIFO oracle really failed',old_cases['fifo']['expected']['chosen']!=case_audits['fifo']['chosen'] and old_receipt['status']=='FAIL')
check('corrected FIFO onlyoracle notruntime',cases['fifo']['expected']['chosen']==case_audits['fifo']['chosen'] and old_receipt['pinned']['runtime']==receipt['pinned']['runtime'])
common=[]
for name in protocol['same_world_cases']:
    d=json.loads(json.dumps(documents[name]));p=d['dispatch_program']['policy_program'];p.pop('policy');p.pop('options');common.append(d)
check('fivepolicy commonworld exactlysame',len(common)==5 and all(d==common[0] for d in common))
check('hiddenpair decisions byte-semantic equal',runs['hidden-open']['policy_public_decisions']==runs['hidden-closed']['policy_public_decisions'])
tool=source_files[protocol['authoring_tool']].decode();oldtool=source_files[protocol['original_authoring_tool']].decode()
check('newcall loop skips reused beforeSTARTED',tool.index("if case['id'] in protocol['reused_cases']:continue")<tool.index("status='STARTED'")<tool.index('result=simulate_scenario('))
check('newcase savedcheck before nextcall',tool.index('original.check_case(folder,case,protocol);receipt')<tool.index("status='COMPLETED'"))
check('newtool failure firstcause preserved',"receipt.setdefault('error_type','SourceGuardError')" in tool and "source_guard_error='Source changed during capture'" in tool)
check('saveonly correction verifier',all(s not in tool[tool.index('def verify('):] for s in ('simulate_scenario(','choose_work(','assess_closure(')))
check('source runtime guardprecondition',"identities['runtime']==old['pinned']['runtime']" in tool)
check('input scope and costlimitations explicit',b'not measured labor' in source_files[protocol['contract']] and b'no superiority claim' in json.dumps(protocol).encode())
check('FIFO figurefooter corrected',b'FIFO: action 1.25 s, later measurement 3 s / arrival 3.5 s' in saved[CAPTURE+'/policy-decisions.svg'])
check('figure scope interfaces only',b'no effect-comparison claim' in saved[CAPTURE+'/policy-decisions.svg'] and b'Registered effect trials = 0' in saved[CAPTURE+'/policy-boundary.svg'])
for svg in ('policy-decisions.svg','policy-boundary.svg'):
    image=(WORK/'25-visual-qa-01'/svg).read_bytes();check('parent viewed SVG exactsource '+svg,image==saved[CAPTURE+'/'+svg])
readme=blobs(README_SOURCE,[PACKAGE+'/README.md'])[PACKAGE+'/README.md'].decode()
check('README failed attempt and reuse honest',all(t in readme for t in ('FIFO','11','22','13','30')) and ('失败' in readme or 'FAIL' in readme))
check('README no conclusion overreach','目标' in readme and ('active' in readme or '未' in readme))

exports=[PROTOCOL,OLD_PROTOCOL,protocol['revision_note'],protocol['authoring_tool'],protocol['original_authoring_tool'],protocol['helper_tool'],protocol['input_preparation_tool'],protocol['contract']]
for name in exports:write('export/'+name,source_files[name])
write('README-reviewed.md',readme.encode())
write('pin-manifest.json',dict(execution_source=SOURCE,original_execution=OLD_SOURCE,data_delivery=DELIVERY,pin_counts={k:len(v) for k,v in pins.items()},pins=pins))
write('original-failure-audit.json',dict(status='ORIGINAL_FAIL_PRESERVED_NOT_UPGRADED',original_source=OLD_SOURCE,original_delivery=OLD_DELIVERY,
    original_artifact_count=11,physical_calls=2,simulated_seconds=8,validated_cases=1,validation_failures=1,error=old_receipt['error'],
    FIFO_expected_original=old_cases['fifo']['expected']['chosen'],FIFO_actual=case_audits['fifo']['chosen'],previous_static_PASS_missed_tie_order=True,
    original_artifacts={n:sha(raw) for n,raw in old.items()}))
write('saved-byte-checks.json',dict(status='PASS',checks_passed=len(checks),checks=checks,case_audits=case_audits,artifacts=artifact_hashes,
    original_source=OLD_SOURCE,execution_source=SOURCE,data_delivery=DELIVERY,pin_counts={k:len(v) for k,v in pins.items()},new_physical_calls=11,
    reused_original_cases=2,cumulative_physical_calls=13,new_simulated_seconds=22,cumulative_simulated_seconds=30,original_validation_failure_retained=True,
    durable_outputs=58,terminal_receipts=1,original_failed_artifacts=11,new_selector_calls=0,new_simulate_calls=0,new_tests=0,new_assessments=0,
    new_inference=0,new_capture=0,new_full_regressions=0))
post={}
for folder in ('25-standards-mid-01','25-standards-final-01','25-standards-protocol-final-01'):
    for path in (WORK/folder).rglob('*'):
        if path.is_file():post[folder+'/'+path.relative_to(WORK/folder).as_posix()]=sha(path.read_bytes())
check('prior review artifacts unchanged',post==prior);write('prior-reviews-after.json',post)
print(json.dumps(dict(status='PASS',checks_passed=len(checks),pins={k:len(v) for k,v in pins.items()},durable_outputs=58,original_files=11,
    reused_files=8,new_physical_calls=11,cumulative_physical_calls=13,prior_review_files_preserved=len(prior),new_project_calls=0)))
