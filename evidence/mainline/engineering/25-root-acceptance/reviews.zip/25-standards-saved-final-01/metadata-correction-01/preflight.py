"""Metadata correction static JSON/Git audit; no assessed project imports."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction
import subprocess
import json
import ast

ROOT=Path('C:/Users/Donson/.codex/worktrees/mainline23-intervention/Renly')
OUT=Path(__file__).resolve().parent
WORK=OUT.parent.parent
REV='44ab2870da1cae04faf09e0ed4fb569cf7f7795d'
OLD='f2e66125f782b54fbebd2a7818ba76e9a0a3927c'
PRIOR_RUNTIME='6a9e3ca8dfd38bf529bec51cd3e10ad66af320d9'
FULL='9d5aeceb5c653f0bd5b5e7b850a1afdf4e086af1'
PACKAGE='evidence/mainline/engineering/25-baselines'
PROTOCOL='docs/mainline/25-policy-metadata-correction-01.json'

def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT)
def sha(raw):return sha256(raw).hexdigest()
def write(name,value):
    raw=value if isinstance(value,bytes) else (json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode()
    p=OUT/name;p.parent.mkdir(exist_ok=True,parents=True)
    with p.open('xb') as f:f.write(raw)
def names(rev,*paths):
    raw=git('ls-tree','-rz','--name-only',rev,*paths).decode().strip('\0');return raw.split('\0') if raw else []
def blobs(rev,paths):
    paths=sorted(set(paths));raw=subprocess.check_output(['git','cat-file','--batch'],cwd=ROOT,
        input=''.join(rev+':'+n+'\n' for n in paths).encode());result={};offset=0
    for name in paths:
        end=raw.index(b'\n',offset);header=raw[offset:end].split();assert len(header)==3 and header[1]==b'blob',name
        start=end+1;size=int(header[2]);result[name]=raw[start:start+size];offset=start+size+1
    assert offset==len(raw);return result

p=json.loads(blobs(REV,[PROTOCOL])[PROTOCOL]);checks=[]
def check(name,value,actual=None):checks.append(dict(name=name,passed=bool(value),actual=actual));assert value,name
check('source verified',git('rev-parse','--verify',REV+'^{commit}').decode().strip()==REV)
changed=git('diff','--name-only',PRIOR_RUNTIME,REV,'--','src').decode().splitlines()
check('one changed runtime path',changed==[p['runtime_changed_path']])
old_plant=blobs(PRIOR_RUNTIME,[p['runtime_changed_path']])[p['runtime_changed_path']]
new_plant=blobs(REV,[p['runtime_changed_path']])[p['runtime_changed_path']]
oldline=p['original_metadata_line'].encode();newline=p['corrected_metadata_line'].encode()
check('exact one replacement',old_plant.count(oldline)==1 and old_plant.replace(oldline,newline)==new_plant)
check('no state visibility change',b"'state_visibility': 'PRIVATE_PLANT_EVALUATOR_ONLY'" in newline)
check('two metadata classifications',b"'PUBLIC_SELECTION_WITH_PRIVATE_EXECUTION' if dispatch is not None else 'DISABLED_FOR_THIS_RUN'" in newline)
check('metadata budget only2x.01',p['physical_runs']==2 and Fraction(p['total_simulated_duration_s'])==Fraction(.02) and p['maximum_step_s']==.01
    and [(c['id'],c['dispatch']) for c in p['cases']]==[('default',False),('no-human',True)])
check('nonresearch protocol',p['registered_research_trials']==0 and p['classification']=='METADATA_ENGINEERING_ONLY_NOT_POLICY_RERUN_OR_EFFECT_TRIAL')
check('two mode literal labels',[c['expected_interface'] for c in p['cases']]==['DISABLED_FOR_THIS_RUN','PUBLIC_SELECTION_WITH_PRIVATE_EXECUTION'])
sidecar_raw=blobs(REV,[p['sidecar']])[p['sidecar']];sidecar=json.loads(sidecar_raw)
originals=names(OLD,PACKAGE+'/capture-01',PACKAGE+'/capture-02')
run_names={n for n in originals if n.endswith('/run.json')}
check('15 exact original run paths',len(run_names)==15 and {r['path'] for r in sidecar['entries']}==run_names and len(sidecar['entries'])==15)
old_blobs=blobs(OLD,originals);current_blobs=blobs(REV,originals)
for name,raw in old_blobs.items():check('all historical artifact unchanged '+name,current_blobs[name]==raw)
for row in sidecar['entries']:
    raw=current_blobs[row['path']];run=json.loads(raw)
    check('sidecar exact identity '+row['path'],sha(raw)==row['sha256'] and row['execution_commit']==run['code_identity']['git_commit']
        and row['original_emitted_value']==run['dispatch_interface']=='NOT_IMPLEMENTED'
        and row['sidecar_classification']=='PUBLIC_SELECTION_WITH_PRIVATE_EXECUTION' and 'policy_public_decisions' in run)
old_receipt=json.loads(old_blobs[PACKAGE+'/capture-02/receipt.json'])
old_protocol='docs/mainline/25-policy-engineering-protocol.json';correction_protocol='docs/mainline/25-policy-engineering-correction-01.json'
correction=json.loads(blobs(REV,[correction_protocol])[correction_protocol])
base_groups={role:set(values) for role,values in old_receipt['pinned'].items()}
groups=dict(runtime=base_groups['runtime'],tools=base_groups['tools']|{p['authoring_tool']},
    inputs=base_groups['inputs']|{PROTOCOL,p['revision_note'],p['sidecar']}|{n for n in originals if '/capture-02/' in n})
raws=blobs(REV,set().union(*groups.values()));pins={role:{n:dict(sha256=sha(raws[n]),bytes=len(raws[n])) for n in sorted(paths)} for role,paths in groups.items()}
check('new metadata pins66/5/263',{k:len(v) for k,v in pins.items()}=={'runtime':66,'tools':5,'inputs':263})
old_source_blobs=blobs(PRIOR_RUNTIME,set().union(*base_groups.values()))
for role,named in old_receipt['pinned'].items():
    for name,h in named.items():
        check('old execution hash '+role+'/'+name,sha(old_source_blobs[name])==h)
        if name!=p['runtime_changed_path']:check('only allowed delivery difference '+role+'/'+name,raws[name]==old_source_blobs[name])
for name in groups['tools']:ast.parse(raws[name].decode(),filename=name)
check('tool syntax no execution',len(groups['tools'])==5)
tool=raws[p['authoring_tool']].decode()
check('clean/unique guards',"require(not git('status','--porcelain')" in tool and 'folder.mkdir(exist_ok=False)' in tool)
check('first error retained',"receipt.setdefault('error_type','SourceGuardError')" in tool and "source_guard_error='Metadata source changed'" in tool)
check('started before call',tool.index("status='STARTED'")<tool.index('result=simulate_scenario('))
check('saved validation before next',tool.index('check_case(folder,case,protocol);receipt')<tool.index("status='COMPLETED'"))
check('old policy not rerun',tool.count('result=simulate_scenario(')==1 and 'original_policy_reruns=0' in tool and 'duration_s=.01,step_s=.01' in tool)
check('save-only final verifier',all(n not in tool[tool.index('def verify('):] for n in ('simulate_scenario(','choose_work(','assess_closure(')))
check('actual selectedmode check',"('policy_public_decisions' in run)==case['dispatch']" in tool and "run['work_records']==[]" in tool)
declared=set(p['durable_root'])|{c['id']+'/'+n for c in p['cases'] for n in p['durable_case']}
check('11metadata artifacts plusreceipt',len(declared)==11 and p['terminal_receipt']=='receipt.json')

# Check the existing full-regression guard independently against both revisions.
raw_dir=Path('C:/Users/Donson/Documents/ChatGPT/Renly/runs/mainline-M4-25-root-acceptance-20261105-01')
guard_raw=(raw_dir/'source-guard.json').read_bytes();guard=json.loads(guard_raw);summary_raw=(raw_dir/'summary.json').read_bytes();summary=json.loads(summary_raw)
check('root538 exact recorded source',guard['source_commit_before']==guard['source_commit_after']==FULL and guard['head_unchanged'] and guard['sources_unchanged']
    and summary['tests']['run']==summary['tests']['executed']==538 and summary['tests']['failures']==summary['tests']['errors']==summary['tests']['skipped']==0)
check('root270 declaration',len(guard['committed_sources'])==270)
root_blobs=blobs(FULL,guard['committed_sources']);new_blobs=blobs(REV,guard['committed_sources'])
for name,h in guard['committed_sources'].items():
    check('root tested Git source '+name,sha(root_blobs[name])==h)
    check('root current delivery exactclassification '+name,new_blobs[name]==(root_blobs[name].replace(oldline,newline) if name==p['runtime_changed_path'] else root_blobs[name]))
check('root full not relabeled metadata source',p['root_full_source']==FULL and p['prior_runtime_source']==PRIOR_RUNTIME)
write('root-guard-reviewed.json',guard_raw);write('root-summary-reviewed.json',summary_raw)
for name in [PROTOCOL,p['revision_note'],p['sidecar'],p['authoring_tool']]:write('export/'+name,raws[name])
write('source.diff',git('diff','--no-ext-diff',FULL,REV,'--','src'))
write('pin-manifest.json',dict(source=REV,pin_counts={k:len(v) for k,v in pins.items()},pins=pins))
write('static-checks.json',dict(status='STATIC_PREFLIGHT_PASS',source=REV,checks_passed=len(checks),checks=checks,
    old_policy_original_artifacts=len(originals),sidecar_entries=15,root_guarded_sources=270,root_unchanged_sources=269,
    root_execution_source=FULL,root_tests_read_not_rerun=538,new_selector_calls=0,new_simulate_calls=0,new_tests=0,new_assessments=0,new_inference=0,new_capture=0))
print(json.dumps(dict(status='STATIC_PREFLIGHT_PASS',source=REV,checks_passed=len(checks),pins={k:len(v) for k,v in pins.items()},
    sidecar_entries=15,root_guarded_sources=270,root_unchanged_sources=269,new_project_calls=0)))
