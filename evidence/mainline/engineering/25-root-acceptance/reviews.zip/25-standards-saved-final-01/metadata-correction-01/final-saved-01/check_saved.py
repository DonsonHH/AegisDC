"""Independent metadata saved/Git audit; no project-runtime imports or calls."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction
import subprocess
import json
import math
import ast

ROOT=Path('C:/Users/Donson/.codex/worktrees/mainline23-intervention/Renly')
OUT=Path(__file__).resolve().parent
PARENT=OUT.parent.parent
WORK=PARENT.parent
SOURCE='44ab2870da1cae04faf09e0ed4fb569cf7f7795d'
DELIVERY='8006988047691756162cfcee9b86b17ee76db05b'
PRIOR_DELIVERY='f2e66125f782b54fbebd2a7818ba76e9a0a3927c'
PRIOR_SOURCE='6a9e3ca8dfd38bf529bec51cd3e10ad66af320d9'
FULL='9d5aeceb5c653f0bd5b5e7b850a1afdf4e086af1'
PACKAGE='evidence/mainline/engineering/25-baselines'
CAPTURE=PACKAGE+'/metadata-capture-01'
PROTOCOL='docs/mainline/25-policy-metadata-correction-01.json'

def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT)
def sha(raw):return sha256(raw).hexdigest()
def write(name,value):
    raw=value if isinstance(value,bytes) else (json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode()
    path=OUT/name;path.parent.mkdir(exist_ok=True,parents=True)
    with path.open('xb') as stream:stream.write(raw)
def names(rev,*paths):
    raw=git('ls-tree','-rz','--name-only',rev,*paths).decode().strip('\0');return raw.split('\0') if raw else []
def blobs(rev,paths):
    paths=sorted(set(paths));raw=subprocess.check_output(['git','cat-file','--batch'],cwd=ROOT,
        input=''.join(rev+':'+n+'\n' for n in paths).encode());result={};offset=0
    for name in paths:
        end=raw.index(b'\n',offset);header=raw[offset:end].split();assert len(header)==3 and header[1]==b'blob',name
        start=end+1;size=int(header[2]);result[name]=raw[start:start+size];offset=start+size+1
    assert offset==len(raw);return result
def jsonl(raw):return [json.loads(line) for line in raw.decode().splitlines()]

checks=[]
def check(name,value,actual=None):checks.append(dict(name=name,passed=bool(value),actual=actual));assert value,name
def close(name,value,wanted):check(name,math.isclose(value,wanted,abs_tol=1e-9,rel_tol=0),dict(actual=value,expected=wanted))
prior={path.relative_to(PARENT).as_posix():sha(path.read_bytes()) for path in PARENT.rglob('*') if path.is_file() and 'final-saved-01' not in path.parts}
write('prior-review-before.json',prior)
protocol=json.loads(blobs(SOURCE,[PROTOCOL])[PROTOCOL])
captured_names=names(DELIVERY,CAPTURE);raw=blobs(DELIVERY,captured_names)
receipt=json.loads(raw[CAPTURE+'/receipt.json']);recorded_checks=json.loads(raw[CAPTURE+'/checks.json'])
check('metadata receipt actualsource PASS',receipt['status']=='PASS' and receipt['execution_commit']==SOURCE and receipt['source_head_and_bytes_unchanged'])
check('only2metadata calls nooriginalreruns',receipt['physical_attempts']==receipt['physical_completed']==receipt['validated_cases']==2 and receipt['failures']==0
    and receipt['original_policy_reruns']==0 and receipt['registered_research_trials']==0)
declared=set(protocol['durable_root'])|{c['id']+'/'+n for c in protocol['cases'] for n in protocol['durable_case']}
check('11declared plusreceipt exactset',len(declared)==11 and set(receipt['artifacts'])==declared and set(captured_names)=={CAPTURE+'/'+n for n in declared|{'receipt.json'}})
check('nocaches delivered',all('__pycache__' not in n and not n.endswith(('.pyc','.pyo')) for n in captured_names))
artifacts={}
for name in sorted(declared|{'receipt.json'}):
    member=raw[CAPTURE+'/'+name];artifacts[name]=dict(sha256=sha(member),bytes=len(member))
    if name!='receipt.json':check('metadata manifestsha '+name,sha(member)==receipt['artifacts'][name])
ledger=jsonl(raw[CAPTURE+'/attempts.jsonl'])
check('metadata ledger4rows',len(ledger)==4)
for i,case in enumerate(protocol['cases']):
    pair=ledger[2*i:2*i+2]
    check('ordered sourceattempt '+case['id'],[r['status'] for r in pair]==['STARTED','COMPLETED'] and all(r['case']==case['id'] and r['execution_commit']==SOURCE for r in pair))
old_capture_names=names(PRIOR_DELIVERY,PACKAGE+'/capture-01',PACKAGE+'/capture-02');old_raw=blobs(PRIOR_DELIVERY,old_capture_names)
now_originals=blobs(DELIVERY,old_capture_names)
for name,member in old_raw.items():check('all70policy originalsunchanged '+name,now_originals[name]==member)
check('policy originalcounts retained',len(old_capture_names)==70)
policy_receipt=json.loads(old_raw[PACKAGE+'/capture-02/receipt.json']);original_receipt=json.loads(old_raw[PACKAGE+'/capture-01/receipt.json'])
check('originalFAILnotrewritten',original_receipt['status']=='FAIL' and original_receipt['physical_attempts']==2 and original_receipt['validated_cases']==1
    and original_receipt['error']=='Literal selection sequence differs: fifo')
check('policy11newplus2reused',policy_receipt['physical_attempts']==policy_receipt['physical_completed']==11 and policy_receipt['reused_cases_validated']==2
    and policy_receipt['status']=='PASS' and policy_receipt['original_validation_failure_retained'])
check('explicit cumulativemetadata budgeting',recorded_checks['original_policy_calls']==13 and recorded_checks['new_metadata_calls']==2
    and recorded_checks['all_engineering_calls']==15 and recorded_checks['all_engineering_simulated_duration_s']==30.02)
check('2metadata durations frozen',protocol['physical_runs']==2 and protocol['total_simulated_duration_s']==.02)

# Exact role membership and source-vs-delivery hashes.
groups={role:set(values) for role,values in policy_receipt['pinned'].items()}
groups['tools'].add(protocol['authoring_tool'])
groups['inputs']|={PROTOCOL,protocol['revision_note'],protocol['sidecar']}|{n for n in old_capture_names if '/capture-02/' in n}
source=blobs(SOURCE,set().union(*groups.values()));delivered=blobs(DELIVERY,set(source));pins={}
check('pin counts66/5/263',{k:len(v) for k,v in groups.items()}=={'runtime':66,'tools':5,'inputs':263})
for role,paths in groups.items():
    check('pin set '+role,set(receipt['pinned'][role])==paths);pins[role]={}
    for name in sorted(paths):
        h=sha(source[name]);check('metadata recorded/source/delivery '+role+'/'+name,h==receipt['pinned'][role][name] and source[name]==delivered[name])
        pins[role][name]=dict(sha256=h,bytes=len(source[name]))
for name in groups['tools']:ast.parse(source[name].decode(),filename=name)
check('fivetools staticparsed',len(groups['tools'])==5)
old_plant=blobs(PRIOR_SOURCE,[protocol['runtime_changed_path']])[protocol['runtime_changed_path']]
oldline=protocol['original_metadata_line'].encode();newline=protocol['corrected_metadata_line'].encode()
check('exact one plantmetadata line',old_plant.count(oldline)==1 and old_plant.replace(oldline,newline)==source[protocol['runtime_changed_path']])
prior_source_files=blobs(PRIOR_SOURCE,set().union(*(set(v) for v in policy_receipt['pinned'].values())))
for role,paths in policy_receipt['pinned'].items():
    for name,h in paths.items():
        check('oldpolicy sourcehash '+role+'/'+name,sha(prior_source_files[name])==h)
        if name!=protocol['runtime_changed_path']:check('oldpolicy otherdeliveryhash '+role+'/'+name,delivered[name]==prior_source_files[name])
sidecar=json.loads(source[protocol['sidecar']]);old_run_names={n for n in old_capture_names if n.endswith('/run.json')}
check('sidecar15coverage',len(sidecar['entries'])==15 and sidecar['originals_unchanged'] and {r['path'] for r in sidecar['entries']}==old_run_names)
for row in sidecar['entries']:
    original=json.loads(now_originals[row['path']])
    check('sidecar exactclassification '+row['path'],sha(now_originals[row['path']])==row['sha256'] and row['execution_commit']==original['code_identity']['git_commit']
        and original['dispatch_interface']==row['original_emitted_value']=='NOT_IMPLEMENTED' and row['sidecar_classification']=='PUBLIC_SELECTION_WITH_PRIVATE_EXECUTION'
        and original['inputs'].get('dispatch_program') is not None and 'policy_public_decisions' in original)

# Check two actual saved public calls; do not invoke either public function.
input_record=json.loads(source[protocol['input']]);summaries={}
for case in protocol['cases']:
    name=case['id'];folder=CAPTURE+'/'+name;run=json.loads(raw[folder+'/run.json']);trace=jsonl(raw[folder+'/private-state.jsonl']);balances=jsonl(raw[folder+'/balances.jsonl'])
    check('newcase actualexecution revision '+name,run['code_identity']['git_commit']==SOURCE and run['code_identity']['implementation_has_changes'] is False)
    for path,h in run['code_identity']['files'].items():check('newcase actualsourcehash '+name+'/'+path,path in receipt['pinned']['runtime'] and receipt['pinned']['runtime'][path]==h)
    check('newcase conditionalmetadata '+name,run['dispatch_interface']==case['expected_interface'] and ('policy_public_decisions' in run)==case['dispatch'])
    check('newcase actualinput unchanged '+name,json.loads(raw[folder+'/scenario.json'])==input_record['model'] and run['inputs']['duration_s']==.01 and run['inputs']['maximum_step_s']==.01)
    check('newcase noactualwork '+name,run['work_records']==[] and run.get('intervention_private_audit',{}).get('events',[])==[])
    check('newcase bothtraceepochs '+name,len(trace)==2 and len(balances)==1 and [t['time_s'] for t in trace]==[0,.01]
        and balances[0]['start_s']==0 and balances[0]['end_s']==.01)
    check('newcase privatevisibility unchanged '+name,run['state_visibility']=='PRIVATE_PLANT_EVALUATOR_ONLY' and run['field_calibration']=='PENDING')
    check('newcase nonresearch '+name,run['research_trials']==run['model_calls']==run['training_calls']==0)
    if case['dispatch']:
        expected_program=json.loads(json.dumps(input_record['dispatch_program']));expected_program['decision_times_s']=[0]
        check('nohuman exactprogram '+name,run['inputs']['dispatch_program']==expected_program)
        choices=run['policy_public_decisions'];check('nohuman actualdecision only '+name,len(choices)==1 and choices[0]['frame']['as_of_s']==0
            and choices[0]['choice']['chosen_candidate_id'] is None and not choices[0]['choice']['execution_permission'])
    else:check('default nodispatchinput '+name,'dispatch_program' not in run['inputs'])
    for path,identity in run['artifacts'].items():
        member=raw[folder+'/'+path];check('newcase rawartifactsha '+name+'/'+path,sha(member)==identity['sha256'])
        check('newcase rawartifactcount '+name+'/'+path,identity['records']==(len(jsonl(member)) if path.endswith('.jsonl') else 1))
    for quantity,value in protocol['expected_summary'].items():
        close('literal metadata serviceintegral '+name+'/'+quantity,run['summary'][quantity],value)
        close('saved metadata balanceintegral '+name+'/'+quantity,math.fsum(b[quantity] for b in balances),value)
    for key in ('worker_travel_person_s','worker_work_person_s','tool_occupation_tool_s'):check('newcase zeroactualoccupation '+name+'/'+key,run['summary'][key]==0)
    check('newcase recordedchecks exact '+name,recorded_checks['cases'][name]['status']=='PASS' and recorded_checks['cases'][name]['interface']==case['expected_interface']
        and recorded_checks['cases'][name]['summary']==run['summary'])
    summaries[name]=run['summary']
check('both metadata modes commonphysics',all(summaries['default'][k]==summaries['no-human'][k] for k in summaries['default']))

# Independently match all270 old full-test source blobs, not a generic skip.
guard_raw=(WORK.parent/'runs/mainline-M4-25-root-acceptance-20261105-01/source-guard.json').read_bytes();guard=json.loads(guard_raw)
summary_raw=(WORK.parent/'runs/mainline-M4-25-root-acceptance-20261105-01/summary.json').read_bytes();summary=json.loads(summary_raw)
check('rootfull exactrecorded source',guard['source_commit_before']==guard['source_commit_after']==FULL and guard['sources_unchanged'] and guard['head_unchanged'])
check('rootfull538actualexecuted notmetadatafull',summary['tests']['run']==summary['tests']['executed']==538 and summary['tests']['failures']==summary['tests']['errors']==summary['tests']['skipped']==0)
check('rootguardexact270',len(guard['committed_sources'])==270)
tested_blobs=blobs(FULL,guard['committed_sources']);current_blobs=blobs(DELIVERY,guard['committed_sources'])
for name,h in guard['committed_sources'].items():
    check('rootrecordedGit '+name,sha(tested_blobs[name])==h)
    check('root exactcurrentdifference '+name,current_blobs[name]==(tested_blobs[name].replace(oldline,newline) if name==protocol['runtime_changed_path'] else tested_blobs[name]))
check('source classification separates old538/new2',protocol['root_full_source']==FULL and protocol['prior_runtime_source']==PRIOR_SOURCE)

# Read and parse the parent's critical verifier path, without running it.
verifier=(WORK/'25-verify_packet.py').read_bytes();builder=(WORK/'build_25_root_packet.py').read_bytes()
ast.parse(verifier.decode());ast.parse(builder.decode());verify_text=verifier.decode()
check('rootverifier actualsource checks',"committed_sources == blobs(root, source, committed_sources)" in verify_text)
check('rootverifier only exactmetadata exception',"metadata_tool.exact_metadata_source(metadata_protocol,delivery)" in verify_text
    and "current_sources[n]==h for n,h in committed_sources.items() if n!=metadata_path" in verify_text)
check('rootverifier metadatafresh check retained',"metadata_tool.verify(" in verify_text and "metadata_result['new_metadata_calls']==2" in verify_text)
check('rootverifier originalFAILandreuse retained',"previous_saved['status'] == 'FAIL'" in verify_text and "len(reused['copies']) == 8" in verify_text)
check('rootverifier exactCRLFclassification',"raw == original.replace(b'\\n', b'\\r\\n')" in verify_text and 'CHECKOUT_CRLF' in verify_text)
write('root-verifier-reviewed.py',verifier);write('root-builder-reviewed.py',builder)
write('root-source-guard-reviewed.json',guard_raw);write('root-summary-reviewed.json',summary_raw)
for name in [PROTOCOL,protocol['sidecar'],protocol['authoring_tool'],protocol['revision_note']]:write('export/'+name,source[name])
write('pin-manifest.json',dict(metadata_source=SOURCE,metadata_data_delivery=DELIVERY,pin_counts={k:len(v) for k,v in pins.items()},pins=pins))
post={path.relative_to(PARENT).as_posix():sha(path.read_bytes()) for path in PARENT.rglob('*') if path.is_file() and 'final-saved-01' not in path.parts}
check('all prior finding/reviews unchanged',prior==post);write('prior-review-after.json',post)
write('saved-checks.json',dict(status='PASS',checks_passed=len(checks),checks=checks,metadata_source=SOURCE,metadata_data_delivery=DELIVERY,
    original_policy_data_delivery=PRIOR_DELIVERY,metadata_artifacts=artifacts,metadata_pin_counts={k:len(v) for k,v in pins.items()},new_metadata_cases=2,
    new_metadata_duration_s=.02,original_policy_calls=13,original_policy_simulated_seconds=30,all_engineering_calls=15,all_engineering_duration_s=30.02,
    root_full_source=FULL,root_full_tests_read=538,root_guarded_sources=270,root_unchanged_source_blobs=269,sidecar_originals=15,
    original_policy_files_preserved=70,prior_review_files_preserved=len(prior),new_selector_calls=0,new_simulate_calls=0,new_tests=0,new_assessments=0,
    new_inference=0,new_capture=0,new_full_regressions=0))
print(json.dumps(dict(status='PASS',checks_passed=len(checks),metadata_pins={k:len(v) for k,v in pins.items()},metadata_artifacts=12,
    root_guarded_sources=270,root_unchanged_sources=269,prior_review_files_preserved=len(prior),new_project_calls=0)))
