"""Seal reviewed policy execution and its immutable failed-oracle originals."""
import argparse
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import zipfile

ROOT=Path(__file__).resolve().parents[1];WORK=ROOT/'.work'
PACKET=Path('evidence/mainline/engineering/25-root-acceptance')

def read(p):return json.loads(p.read_bytes())
def sha(p):return sha256(p.read_bytes()).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT)
def write(path,value,new=True):
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('x' if new else 'w',encoding='utf-8',newline='\n') as stream:stream.write(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n')

def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--settings',type=Path,required=True);args=parser.parse_args()
    settings=read(args.settings);source=settings['source'];raw=ROOT/settings['raw']
    assert git('rev-parse','HEAD').decode().strip()==settings['packet_base'] and not git('status','--porcelain')
    summary=read(raw/'summary.json');guard=read(raw/'source-guard.json');tests=summary['tests']
    assert summary['overall']=='PASS' and tests['run']==tests['executed']>512
    assert tests['errors']==tests['failures']==tests['skipped']==0 and summary['verified_original_files']==20
    assert guard['source_commit_before']==guard['source_commit_after']==source and guard['sources_unchanged'] and guard['head_unchanged']
    spec=read(WORK/settings['spec_review']/'review.json');standards=read(WORK/settings['standards_review']/'review.json')
    assert spec['status']==standards['status']=='PASS' and spec['unresolved_findings']==standards['unresolved_findings']==0
    spec_count=spec['checks_passed'];std_count=standards['checks_passed'];assert spec_count>0 and std_count>0
    visual=WORK/settings['visual_review'];assert read(visual/'visual-review.json')['open_findings']==0
    packet=ROOT/PACKET;assert not packet.exists()
    copies={'raw/'+n:raw/n for n in ('summary.json','tests.log','evidence.json','source-guard.json')};visuals={}
    for stem in ('policy-decisions','policy-boundary'):
        png=visual/(stem+'.png');svg=visual/(stem+'.svg');target='evidence/mainline/engineering/25-baselines/capture-02/'+svg.name
        assert sha(svg)==sha(ROOT/target);name='figures/'+png.name;copies[name]=png
        visuals[name]=dict(svg=target,svg_sha256=sha(svg),png_sha256=sha(png))
    review_files={}
    review_folders=[p for p in WORK.glob('25-*') if p.is_dir() and ('spec' in p.name or 'standards' in p.name)]
    for folder in review_folders:
        for path in folder.rglob('*'):
            if path.is_file() and '__pycache__' not in path.parts and path.suffix not in {'.pyc','.pyo'}:
                review_files[folder.name+'/'+path.relative_to(folder).as_posix()]=path
    support={name:WORK/name for name in settings['support']}
    support['visual-review.json']=visual/'visual-review.json';support['packet-settings.json']=args.settings
    declared=sorted(set(copies)|{'.gitattributes','README.md','declaration.json','source-manifest.json','archive-members.json','reviews.zip','support.zip','verify_packet.py'})
    write(packet/'declaration.json',dict(artifacts=declared,terminal_receipt='receipt.json'))
    for name,path in copies.items():target=packet/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(path.read_bytes())
    attributes=['# Preserve exact native originals; retain all other whitespace checks.']
    for name,path in copies.items():
        if name.startswith('raw/') and b'\r\n' in path.read_bytes():attributes.append(name+' -text whitespace=blank-at-eol,blank-at-eof,space-before-tab,cr-at-eol')
    (packet/'.gitattributes').write_text('\n'.join(attributes)+'\n',encoding='utf-8',newline='\n')
    archives={}
    for name,members in (('reviews.zip',review_files),('support.zip',support)):
        archives[name]={}
        with zipfile.ZipFile(packet/name,'x',zipfile.ZIP_DEFLATED) as archive:
            for member,path in sorted(members.items()):
                blob=path.read_bytes();archive.writestr(member,blob);archives[name][member]=dict(sha256=sha256(blob).hexdigest(),bytes=len(blob))
    write(packet/'archive-members.json',archives)
    capture='evidence/mainline/engineering/25-baselines/capture-02/receipt.json';saved=read(ROOT/capture)
    assert saved['status']=='PASS' and saved['physical_attempts']==saved['physical_completed']==saved['validated_new_cases']==11
    assert saved['reused_cases_validated']==2 and saved['failures']==0
    author=dict(execution=settings['author_source'],data_delivery=settings['author_delivery'],candidate=settings['candidate'],
        capture=capture,capture_sha256=sha(ROOT/capture))
    assert saved['execution_commit']==author['execution']
    previous=dict(execution='e4d48e74abc4ad7b0a199ff9805f9eac06a45d45',data_delivery='e5f195254b890bb2aa3fccee6f540b729ea39175',
        capture='evidence/mainline/engineering/25-baselines/capture-01/receipt.json',physical_calls=2,validated_cases=1,
        status='FAIL',original_validation_error='Literal selection sequence differs: fifo')
    reviews=dict(standards_findings=0,spec_findings=0,independent_assertions=spec_count,standards_checks=std_count,
        spec_report_sha256=sha(WORK/settings['spec_review']/'SPEC.md'),standards_report_sha256=sha(WORK/settings['standards_review']/'report.md'))
    metadata_capture='evidence/mainline/engineering/25-baselines/metadata-capture-01/receipt.json'
    metadata_correction=dict(execution=settings['metadata_source'],data_delivery=settings['metadata_delivery'],capture=metadata_capture,capture_sha256=sha(ROOT/metadata_capture))
    write(packet/'source-manifest.json',dict(tested_source=source,author=author,previous_author=previous,metadata_correction=metadata_correction,visuals=visuals,reviews=reviews,
        original_physical_calls=2,correction_new_physical_calls=11,reused_cases=2,cumulative_physical_calls=13,cumulative_simulated_duration_s=30,
        all_declared_engineering_calls=15,all_engineering_simulated_duration_s=30.02,registered_research_trials=0,field_calibration='PENDING'))
    (packet/'verify_packet.py').write_bytes((WORK/'25-verify_packet.py').read_bytes())
    text=f'''# 第25项根验收：同一设施中的透明策略

集成执行源`{source}`通过{tests['executed']}项完整回归，全部执行，零失败、零错误、零跳过。20份历史原件与{len(guard['actual_sources'])}个Python/JSON源码身份通过守卫。独立Spec{spec_count}项、Standards{std_count}项保存复核通过，两轴无未解决发现。

![五策略的实际决策和作业时刻](figures/policy-decisions.png)

无人工、FIFO、显式周期对照、条件风险优先适配和单次观察前瞻共用同一八域合成设施、真实时钟、公开证据及人员工具。选择/暂缓/不可行原因、精确累计准入账、模型调用和计算时间分别记录。固定测点覆盖稀疏；现场检查必须实际到场作业，记录到达后才可供决策。处置完成与恢复核验分别记账。

FIFO同可用时刻按标识排序，先处置、后复查；其效果1.25秒、手持3秒采样、3.5秒到达。条件风险和前瞻在1.25秒完成检查、1.75秒取得记录、3秒完成处置。主工程见证中网络瓶颈维持0.25，五种策略的4秒服务交付均1单位秒、缺额均3秒。这证明有限接口行为，不是效果比较或方法优越性证据。前瞻的功率证据后验为16/59，未声明独立的手持流量不再计因子；无固定通道开发见证的8/11另有范围。

![策略、公开证据和私有执行边界](figures/policy-boundary.png)

另发现旧dispatch_interface遗留字段与策略运行矛盾，原15份运行原件保留，精确sidecar分类；新版本只改一行输出元数据。两个单列0.01秒工程运行验证启用/禁用状态，原538项针对9d源，未冒充新元数据源完整回归。策略包仍13次/30秒，含元数据检查的全部声明工程捕获15次/30.02秒。

原封存协议把FIFO并列顺序写反，执行至第2例后按协议停止。原11文件、FAIL收据、原静态PASS遗漏及失败账均保留。显式修订只更正FIFO预期；复用原两例8份物理原件，新执行11个未试条件，累计13次/30模拟秒，没有物理重试。修订包逐项钉住源码、工具、输入及原失败文件，干净新检出复核，图像实际渲染查看。

- [根摘要](raw/summary.json)、[完整日志](raw/tests.log)、[源码守卫](raw/source-guard.json)
- [独立审阅和原发现](reviews.zip)、[新检出和图像复核](support.zip)
- [候选交付和原失败](../25-baselines/README.md)、[显式修订协议](../../../../docs/mainline/25-policy-engineering-correction-01.md)
- [权威](../../../../docs/mainline/evidence/25-root.json)、[产物声明](declaration.json)、[收据](receipt.json)

第25项接受后，主票26实现可证伪的联合核查处置候选；M4仍需26–28。效果研究须到30先冻结协议，AI/RSI须通过38资格门槛。注册研究试验为零，现场标定pending，完整42票目标持续active。
'''
    (packet/'README.md').write_text(text,encoding='utf-8',newline='\n')
    assert {p.relative_to(packet).as_posix() for p in packet.rglob('*') if p.is_file()}==set(declared)
    write(packet/'receipt.json',dict(schema='aegisdc-ticket25-root-packet-v1',tested_source=source,delivery_gate='PENDING_COMMIT_AND_FRESH_CHECKOUT',
        artifacts={n:sha(packet/n) for n in declared},root_tests=tests,independent_assertions=spec_count,standards_checks=std_count,
        new_full_regressions=0,new_physical_runs=0,registered_research_trials=0,llm_calls=0,training_calls=0))
    write(ROOT/'docs/mainline/evidence/25-root.json',dict(schema='aegisdc-ticket-root-acceptance-v1',ticket='25',status='ACCEPTED',actual_root_source=source,
        root_tests=tests,metadata_correction=metadata_correction,all_declared_engineering_calls=15,packet=PACKET.as_posix(),packet_receipt_sha256=sha(packet/'receipt.json'),author=author,previous_author=previous,
        independent_assertions=spec_count,standards_checks=std_count,standards_findings=0,spec_findings=0,field_calibration='PENDING',registered_research_trials=0,
        llm_calls=0,training_calls=0,overall_goal='ACTIVE'))
    index_path=ROOT/'evidence/mainline/engineering/25-baselines/README.md'
    index_text=index_path.read_text(encoding='utf-8')
    index_text=index_text.replace('当前仍须独立保存复核与集成根验收；组件和图像通过不等于第25项或完整研究目标完成。','第25项独立保存复核与[集成根验收](../25-root-acceptance/README.md)已通过。元数据更正及原字段分类见[单列说明](../../../../docs/mainline/25-policy-metadata-correction-01.md)；原538项完整检查与新两例元数据检查的执行源分开保留。第26项尚需实现，完整研究目标持续active。')
    index_path.write_text(index_text,encoding='utf-8',newline='\n')
    ticket=ROOT/'.scratch/full-facility-mainline/issues/25-transparent-baselines.md';s=ticket.read_text(encoding='utf-8')
    assert '**Status:** claimed' in s;s=s.replace('**Status:** claimed','**Status:** resolved',1).replace('- [ ]','- [x]')
    s+='\nRoot acceptance: `docs/mainline/evidence/25-root.json`; integrated source `'+source+'`, '+str(tests['executed'])+' executed checks, zero failures/errors/skips, independentSpec'+str(spec_count)+' andStandards'+str(std_count)+'. Original failed FIFO oracle and two original physical outputs preserved; eleven unattempted cases completed under an explicit correction, no rerun.\n'
    ticket.write_text(s,encoding='utf-8',newline='\n')
    path=ROOT/'docs/mainline/progress.json';progress=read(path);assert progress['current_ticket']=='25';progress['current_ticket']='26'
    progress['active_implementations']=[x for x in progress['active_implementations'] if x['ticket']!='25']
    milestone=next(m for m in progress['milestones'] if m['id']=='M4');milestone['acceptance_evidence'].append('docs/mainline/evidence/25-root.json')
    milestone['progress_scope']='21personnel through25transparent policies accepted;26candidate,27cross-system loop and28negative gates remain.'
    progress['liveness_refresh']='Reviewed25 accepted after integrated checks;26ready and not assigned yet.';write(path,progress,False)
    path=ROOT/'docs/current-research.json';phase=read(path);phase.update(current_primary_ticket='26',current_primary_ticket_assigned=False,
        active_tickets=[],next_ready_unassigned=['26'],implementation='Tickets01–25 accepted. Primary26joint candidate ready; M4 and full research goal remain active.')
    phase['runtime_verification_documents'].append((PACKET/'README.md').as_posix());write(path,phase,False)
    for name in ('docs/MAINLINE.md','docs/NEXT.md'):
        path=ROOT/name;body=path.read_text(encoding='utf-8')
        if name=='docs/MAINLINE.md':
            old='M0–M3已按声明的有限工程范围接受。M4中人员21、实际检查22、处置23和证据核验关闭24已接受；当前主票25实施透明策略与贴近问题的文献基线，26–28仍须完成候选方法、同场闭环与负例。M4尚未完成，整个研究目标持续active。'
            new='M0–M3已按声明的有限工程范围接受。M4中21–25的人员、实际检查、处置、证据关闭和透明策略已接受；当前主票26实现可证伪候选，27–28仍须完成同场闭环与负例。M4尚未完成，整个研究目标持续active。'
            assert old in body;body=body.replace(old,new,1)
        if name=='docs/NEXT.md':
            body=body.replace('01–24已接受；当前25为透明策略、共同资源/信息接口与贴近问题的文献基线，仍属M4。26–28的候选方法、同场闭环和负例尚未接受。','01–25已接受；当前26实现可证伪的联合核查处置候选，仍属M4。26–28的候选方法、同场闭环和负例尚未接受。',1)
            body=body.replace('## 会前执行记录（历史）','## 历史执行记录（含主线旧状态）',1)
        body+='\n透明策略25通过[根验收、真实决策数据和公开/私有架构](../evidence/mainline/engineering/25-root-acceptance/README.md)。当前主票26准备可证伪候选；M4及完整研究目标仍active。\n'
        path.write_text(body,encoding='utf-8',newline='\n')
    print(json.dumps(dict(packet=PACKET.as_posix(),artifacts=len(declared),archive_members=sum(map(len,archives.values())),root_tests=tests,guarded_files=len(guard['actual_sources'])),ensure_ascii=False))

if __name__=='__main__':main()
