const fs = require('node:fs/promises');
const path = require('node:path');
const crypto = require('node:crypto');
const sharp = require('C:/Users/Donson/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/sharp');
const source = 'C:/Users/Donson/.codex/worktrees/mainline23-intervention/Renly/evidence/mainline/engineering/25-baselines/capture-02';
const destination = path.join(__dirname, '25-visual-qa-01');
const sha = b => crypto.createHash('sha256').update(b).digest('hex');
(async () => {
  await fs.mkdir(destination, {recursive: false});
  const output = {renderer: 'sharp', versions: sharp.versions, node: process.version, figures: []};
  for (const name of ['policy-decisions', 'policy-boundary']) {
    const svg = await fs.readFile(path.join(source, name + '.svg'));
    const png = await sharp(svg, {density: 144}).png().toBuffer();
    await fs.writeFile(path.join(destination, name + '.svg'), svg, {flag: 'wx'});
    await fs.writeFile(path.join(destination, name + '.png'), png, {flag: 'wx'});
    const metadata = await sharp(png).metadata();
    output.figures.push({name, svg_sha256: sha(svg), png_sha256: sha(png), width: metadata.width, height: metadata.height});
  }
  await fs.writeFile(path.join(destination, 'render.json'), JSON.stringify(output, null, 2) + '\n', {flag: 'wx'});
  process.stdout.write(JSON.stringify({destination, figures: output.figures}) + '\n');
})().catch(error => {process.stderr.write(error.stack + '\n'); process.exitCode = 1;});
