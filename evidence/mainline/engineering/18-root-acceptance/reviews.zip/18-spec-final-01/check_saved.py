from fractions import Fraction as F
from hashlib import sha256
from itertools import product
import json
from pathlib import Path
import subprocess
OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[1]
PIN='6fc1d0eed811fd246403dc1c1a0ba14dbb12fdea'
SOURCE='c2ef61baafba0dd538768526d88e5b6caad5f4e3'
PREFIX='evidence/mainline/engineering/18-beliefs/capture-01/'
checks=[]
def check(value,label):
    if not value: raise AssertionError(label)
    checks.append(label)
def blob(path,revision=PIN): return subprocess.check_output(['git','cat-file','blob',revision+':'+path],cwd=ROOT)
def read(path): return json.loads(blob(path))
protocol=read('docs/mainline/18-belief-engineering-protocol.json')
receipt=read(PREFIX+'receipt.json'); attempt=read(PREFIX+'attempt.json')
check(receipt['status']=='PASS','capture status')
check(receipt['execution_commit']==SOURCE==attempt['execution_commit'],'execution identity')
check(receipt['source_head_and_bytes_unchanged'],'execution source guard')
check(receipt['global_regression_gate']=='PENDING_ROOT_INTEGRATED_FULL_WITH_TORCH','root gate pending')
check(receipt['field_calibration']=='PENDING','field calibration pending')
check(set(receipt['artifacts'])==set(protocol['durable_outputs']),'durable set exact')
for name,digest in receipt['artifacts'].items(): check(sha256(blob(PREFIX+name)).hexdigest()==digest,'artifact '+name)
for group in ('runtime_sources','authoring_verification_tools','frozen_inputs'):
    for name,digest in receipt[group].items(): check(sha256(blob(name,SOURCE)).hexdigest()==digest==sha256(blob(name)).hexdigest(),'source and delivery '+name)
for field in ('new_physical_runs','registered_research_trials','llm_calls','training_calls'): check(receipt[field]==attempt[field]==0,'scope '+field)

# Separately stated joint law, not the author's oracle routine.
prior=list(map(F,['3/5','1/5','1/10','1/10']))
transition=[[F(v) for v in row] for row in [('7/10','1/10','1/10','1/10'),('1/5','3/5','1/10','1/10'),('1/5','1/10','3/5','1/10'),('3/10','1/10','1/10','1/2')]]
hot=list(map(F,['1/10','4/5','1/5','2/5'])); power=list(map(F,['1/10','1/5','9/10','2/5']))
states=['nominal','cooling-limited','power-limited','other']
atoms=[]
for old,new,h,p in product(range(4),range(4),(False,True),(False,True)):
    mass=prior[old]*transition[old][new]*(hot[old] if h else 1-hot[old])*(power[new] if p else 1-power[new])
    atoms.append((new,(h,p),mass))
check(len(atoms)==64 and sum(m for _,_,m in atoms)==1,'64 atom normalization')
data=read(PREFIX+'calibration.json'); saved={(r['stage'],tuple(r['reports'])):r for r in data['pattern_rows']}
check(len(saved)==len(data['pattern_rows'])==7,'seven distinct conditional rows')
for n,stage in enumerate(('no-reports','arrived-hot-only','both-arrived')):
    score=F(0)
    for pattern in product((False,True),repeat=n):
        masses=[sum(m for truth,reports,m in atoms if truth==state and reports[:n]==pattern) for state in range(4)]
        total=sum(masses); posterior=[m/total for m in masses]; row=saved[stage,pattern]
        check(F(row['exact_probability'])==total,'pattern probability '+str((stage,pattern)))
        check(all(F(row['exact_frequencies'][s])==p for s,p in zip(states,posterior)),'exact frequencies '+str((stage,pattern)))
        check(all(abs(row['inference'][s]-float(p))<=1e-14 for s,p in zip(states,posterior)),'saved inference '+str((stage,pattern)))
        score+=sum(m*sum((p-(index==truth))**2 for index,p in enumerate(posterior)) for truth,reports,m in atoms if reports[:n]==pattern)
    check(F(data['true_law_weighted_multiclass_brier'][stage]['exact'])==score,'exact Brier '+stage)
    check(abs(data['true_law_weighted_multiclass_brier'][stage]['inference']-float(score))<=1e-14,'saved Brier '+stage)
archive=read(PREFIX+'archived-trajectory.json'); original=read(protocol['archived_public_snapshots'])[protocol['archived_snapshot_key']]
records={r['id']:r for r in original['records']}
check(len(records)==len(original['records'])==archive['input_record_count']==1133,'1133 public records')
check(len(archive['frames'])==27 and [r['as_of_s'] for r in archive['frames']]==protocol['archived_as_of_s'],'27 declared instants')
check(len(archive['domains'])==8,'eight-domain identity')
check(archive['scope_id']!=read(protocol['reference_model'])['scope']['id'],'archive and finite scopes distinct')
boundaries={r['as_of_s']:r['rectifier_record'] for r in protocol['archived_arrival_expectations']}
for frame in archive['frames']:
    t=frame['as_of_s']; available={k:r for k,r in records.items() if r['observed_at_s']<=t and r['arrived_at_s']<=t}
    check(frame['arrived_count']==len(available),'visible records '+str(t))
    for used in frame['used']:
        actual=available[used['record_id']]
        check(used['observed_value']==actual['value'] and all(used[k]==actual[k] for k in ('source_id','observed_at_s','arrived_at_s','valid_until_s')),'selected identity '+str((t,used['record_id'])))
        check(actual['provenance']['copied_from_record_id'] is None,'selected root '+str((t,used['record_id'])))
    if t in boundaries: check([u['record_id'] for u in frame['used'] if u['channel_id']=='fixed-low-power']==[boundaries[t]],'arrival boundary '+str(t))
    for variant,posterior in frame['posterior_by_variant'].items(): check(abs(sum(posterior.values())-1)<=1e-14 and all(0<=p<=1 for p in posterior.values()),'normalized variant '+str((t,variant)))
    for state,interval in frame['assumption_envelope'].items():
        values=[p[state] for p in frame['posterior_by_variant'].values()]
        check(interval==[min(values),max(values)],'sensitivity envelope '+str((t,state)))
report=dict(schema='aegisdc-ticket18-independent-spec-saved-output-v1',status='PASS',execution=SOURCE,delivery=PIN,assertions=len(checks),checks=checks,inference_rerun=False,full_suite_runs=0,new_physical_runs=0,registered_research_trials=0,llm_calls=0,training_calls=0,findings=[])
(OUT/'saved-output-result.json').write_text(json.dumps(report,indent=2)+chr(10),encoding='utf-8')
print(json.dumps({k:report[k] for k in ('status','execution','delivery','assertions','findings')}))
