from copy import deepcopy
from fractions import Fraction as F
from hashlib import sha256
from itertools import product
import json
from math import nextafter, inf
from pathlib import Path
import subprocess
import sys

OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[1]
EXPORT=OUT/'export'
CORE='65d857fded9ff410af4285a5966ba97ece841fa2'
FINAL='c2ef61baafba0dd538768526d88e5b6caad5f4e3'
sys.path.insert(0,str(EXPORT/'src'))
assertions=[]

def check(value,label):
    if not value: raise AssertionError(label)
    assertions.append(label)

def read(name): return json.loads((EXPORT/'configs'/name).read_bytes())

def guard():
    paths=subprocess.check_output(['git','ls-tree','-r','--name-only',CORE,'src','configs'],cwd=ROOT,text=True).splitlines()
    hashes={}
    for name in paths:
        data=(EXPORT/name).read_bytes()
        expected=subprocess.check_output(['git','show',CORE+':'+name],cwd=ROOT)
        if data!=expected: raise AssertionError('Export changed: '+name)
        hashes[name]=sha256(data).hexdigest()
    return hashes

before=guard()
from aegis_dc.belief import infer_belief
from aegis_dc.decision_view import DecisionGateway
MODEL=read('full-facility-belief-model-v1.json')
NOMINAL=read('full-facility-decision-v1/public-nominal.json')
LEDGER=read('full-facility-sensor-channels-v1.json')['ledger']
for other in (read('full-facility-nonfixed-evidence-v1.json')['registry'],read('full-facility-decision-v1/common-ledger.json')):
    for field in ('sources','observables'):
        merged={row['id']:row for row in LEDGER[field]}
        for row in other[field]:
            if row['id'] in merged: check(merged[row['id']]==row,'registry identity '+row['id'])
            merged[row['id']]=row
        LEDGER[field]=list(merged.values())
LEDGER['id']=MODEL['scope']['ledger_id']
PLAN=read('full-facility-decision-v1/public-plan.json')

def record(name,channel,value,observed=1,arrived=1,expiry=None,origin=None,parent=None,bound=0):
    c=next(row for row in MODEL['channels'] if row['id']==channel)
    return dict(id=name,source_id=c['source_id'],target_id=c['target_id'],observable_id=c['observable_id'],unit=c['unit'],value=value,observed_at_s=observed,arrived_at_s=arrived,valid_until_s=expiry,quality=dict(status='unknown' if value is None else 'reported' if c['unit']=='1' else 'bounded',error_bound=None if value is None or c['unit']=='1' else bound,note='Independent spec engineering probe.'),provenance=dict(origin_id=origin or name,copied_from_record_id=parent))

def frame(records=(),time=12,ledger=None):
    public=deepcopy(LEDGER if ledger is None else ledger); public['records']=deepcopy(list(records))
    return DecisionGateway(NOMINAL,public,dict(PLAN,decision_times_s=[time])).next_frame()

def run(records=(),time=12,model=None,ledger=None):
    return infer_belief(frame(records,time,ledger),deepcopy(MODEL if model is None else model))

def dispositions(result): return {r['record_id']:r['disposition'] for r in result['record_audit']}

def close(actual,exact,label):
    check(set(actual)==set(exact),label+' states')
    for state,p in exact.items(): check(abs(actual[state]-float(p))<=1e-14,label+' '+state)

prior=list(map(F,['3/5','1/5','1/10','1/10']))
transition=[[F(v) for v in row] for row in [('7/10','1/10','1/10','1/10'),('1/5','3/5','1/10','1/10'),('1/5','1/10','3/5','1/10'),('3/10','1/10','1/10','1/2')]]
hot=list(map(F,['1/10','4/5','1/5','2/5']))
power=list(map(F,['1/10','1/5','9/10','2/5']))
states=['nominal','cooling-limited','power-limited','other']
for h,p in product((False,True),repeat=2):
    roots=[record('hot','fixed-hot',h,1,11,20),record('power','fixed-low-power',0 if p else 3000000,10,12,20)]
    copy=record('copy','fixed-hot',h,1,10,20,origin='hot',parent='hot')
    for count,time in enumerate((10,11,12)):
        weights=[F(0)]*4
        for old,new in product(range(4),repeat=2):
            w=prior[old]*transition[old][new]
            if count>=1: w*=hot[old] if h else 1-hot[old]
            if count==2: w*=power[new] if p else 1-power[new]
            weights[new]+=w
        total=sum(weights); expected=dict(zip(states,[w/total for w in weights]))
        result=run([copy,*roots],time)
        close(result['posterior'],expected,f'path enumeration {h}/{p}/{time}')
        check(result['information_updates']==['hot','power'][:count],'arrival factors '+str((h,p,time)))
        check(dispositions(result)['copy']==('copy_root_unavailable' if count==0 else 'copy_not_a_factor'),'copy factor '+str((h,p,time)))
        check(result['physical_actions']==[],'no physical action '+str((h,p,time)))

accepted=record('accepted','fixed-hot',True,1,11,12)
expired=record('expired','fixed-hot',True,1,12,12)
check(run([accepted],12)['information_updates']==['accepted'],'pre-expiry arrival retained historically')
check(dispositions(run([accepted],12))['accepted']=='used','expired root audited used')
check(run([expired],12)['information_updates']==[],'arrival at exact expiry audit only')
check(dispositions(run([expired],12))['expired']=='expired_before_arrival','arrival expiry disposition')
check(run([accepted],20)['posterior']!=run([accepted],12)['posterior'],'historical factor ages through transitions')
check(abs(sum(run(time=20)['posterior'].values())-1)<1e-14,'prior prediction normalized after two steps')

for value,bound,expected in [(305,0,True),(nextafter(305,-inf),0,False),(305,1,None),(304,1,None),(306,1,True)]:
    audit=run([record('hand','handheld-hot',value,bound=bound)])['record_audit'][0]
    check(audit.get('positive') is expected,'handheld endpoint '+str((value,bound)))
    check(audit['disposition']==('threshold_straddled' if expected is None else 'used'),'handheld disposition '+str((value,bound)))
for value,bound,expected in [(2000000,0,False),(nextafter(2000000,-inf),0,True),(2000000,1,None),(1999999,1,None),(2000001,1,False),(0,0,True)]:
    check(run([record('meter','fixed-low-power',value,bound=bound)])['record_audit'][0].get('positive') is expected,'power endpoint '+str((value,bound)))
manual=record('manual','manual-vibration',True)
ambiguous=record('hand','handheld-hot',305,bound=1)
check(run([manual,ambiguous])['information_updates']==['manual'],'ambiguous bin does not occupy slot')
check(run([record('unknown','fixed-hot',None)])['posterior']==run()['posterior'],'missing does not become false')
check(run([record('false','fixed-hot',False)])['information_updates']==['false'],'false report is factor')

h=record('h','fixed-hot',True,1,11)
p=record('p','fixed-low-power',0,10,11)
bridge=record('bridge','handheld-hot',310,10,12,origin='p',parent='p',bound=1)
bridge.update(source_id='coolant-probe-record',observable_id='coolant_temperature')
base=run([h,p],11); linked=run([h,p,bridge],12)
check(base['information_updates']==['h','p'],'independent pair before link')
check(linked['information_updates']==['h'],'late transitive dependency removes factor')
check(dispositions(linked)['p']=='shared_provenance','linked factor audit')
check(run([p,bridge,h],12)==linked,'insertion order invariant')
check(run([h,record('p','fixed-low-power',0,10,11,origin='h')])['information_updates']==['h'],'shared origin blocks double count')
wrong=run([h,record('wrongcopy','handheld-hot',310,10,12,origin='wrong',parent='h',bound=1)])
check(wrong['information_updates']==[],'ambiguous origin defers root component')
check(dispositions(wrong)['h']=='provenance_ambiguous','ambiguous component audit')
a=record('a','fixed-hot',True,origin='cycle',parent='b')
b=record('b','fixed-hot',True,origin='cycle',parent='a')
check(run([a,b])['information_updates']==[],'visible cycle has no factors')
conflict=record('conflict','fixed-hot',False,1,12)
check(run([h,conflict])['information_updates']==[],'conflicting roots deferred')
check(set(dispositions(run([h,conflict])).values())=={'conflicting_reports'},'conflict audit')

for mutation in [{'source_id':'unknown'},{'observable_id':'unknown'},{'unit':'banana'},{'target_id':'immersion'},{'source_id':'unknown','observable_id':'unknown','unit':'banana'}]:
    model=deepcopy(MODEL); model['channels'][1].update(mutation)
    try: run(model=model)
    except ValueError as error: check(bool(str(error)),'binding rejection '+str(mutation))
    else: check(False,'binding admitted '+str(mutation))

f=frame([h]); saved=deepcopy(f); model=deepcopy(MODEL); model_saved=deepcopy(model)
result=infer_belief(f,model)
check(f==saved and model==model_saved,'inputs detached unmodified')
result['unidentified'].append('result mutation')
check(model==model_saved,'result mutation cannot alter model')
check(run([h,record('future','fixed-hot',False,13,14)],12)==run([h],12),'future evidence unavailable')
f['actual_state']={'failure':'cooling'}
try: infer_belief(f,model)
except ValueError: check(True,'hidden state field rejected')
else: check(False,'hidden state field admitted')

after=guard()
check(before==after,'all exported runtime/config bytes unchanged')
for module in ('aegis_dc.belief','aegis_dc.decision_view','aegis_dc.evidence_ledger','patrol_rsi.contracts'):
    check(Path(sys.modules[module].__file__).resolve().is_relative_to(EXPORT/'src'),'import confined '+module)
report=dict(schema='aegisdc-ticket18-independent-spec-review-v1',status='PASS',core_pin=CORE,final_source_pin=FINAL,source_trees_identical_at_final_pin=True,assertions=len(assertions),checks=assertions,source_before=before,source_after=after,scope='Independent exact public-interface semantic probes; no full suite, physics, registered research, model or training calls.',findings=[],registered_research_trials=0,new_physical_runs=0,llm_calls=0,training_calls=0,full_suite_runs=0)
(OUT/'probe-result.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({k:report[k] for k in ('status','core_pin','final_source_pin','assertions','findings','scope')}))
