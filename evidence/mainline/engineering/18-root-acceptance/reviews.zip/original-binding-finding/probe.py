import json
import os
from pathlib import Path

from aegis_dc.belief import infer_belief
from aegis_dc.decision_view import DecisionGateway

ROOT = Path(os.environ["AEGIS18_REVIEW_TREE"]) / "configs"
def read(name):
    return json.loads((ROOT / name).read_text(encoding="utf-8"))

def evaluate(model):
    nominal = read("full-facility-decision-v1/public-nominal.json")
    ledger = read("full-facility-decision-v1/common-ledger.json")
    ledger["id"] = model["scope"]["ledger_id"]
    ledger["records"] = []
    plan = read("full-facility-decision-v1/public-plan.json")
    plan["decision_times_s"] = [0]
    return infer_belief(DecisionGateway(nominal, ledger, plan).next_frame(), model)

model = read("full-facility-belief-model-v1.json")
baseline = evaluate(model)
print("No-record baseline:", baseline["status"], baseline["posterior"])

# This unregistered numeric source and observable have no SI unit contract.
channel = next(item for item in model["channels"] if item["id"] == "fixed-low-power")
channel.update(source_id="unregistered-source", observable_id="unregistered-observable", unit="banana")
try:
    result = evaluate(model)
except ValueError as error:
    print("Unregistered non-SI channel rejected:", error)
else:
    assert result == baseline
    print("Unregistered non-SI channel admitted with no audit:", result["status"])
