"""Package already-executed ticket18 evidence without altering author originals."""
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parents[1]
WORK = ROOT / '.work'
PACKET = Path('evidence/mainline/engineering/18-root-acceptance')
SOURCE = '49a40b760e6bab1a89c884e3ef466a45337a5e26'
AUTHOR = '4bce1defcd4b31d9062873d9e9b9e3c2b2c97142'
EXECUTION = 'c2ef61baafba0dd538768526d88e5b6caad5f4e3'
DATA = '6fc1d0eed811fd246403dc1c1a0ba14dbb12fdea'
RAW = ROOT / 'runs/mainline-M3-18-root-acceptance-20261105-01'

def read(path):
    return json.loads(path.read_bytes())

def digest(path):
    return sha256(path.read_bytes()).hexdigest()

def write(path, value, *, new=True):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x' if new else 'w', encoding='utf-8', newline='\n') as stream:
        stream.write(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n')

def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)

def prepare():
    assert git('rev-parse', 'HEAD').decode().strip() == SOURCE and not git('status', '--porcelain')
    packet = ROOT / PACKET
    assert not packet.exists()
    summary, guard = read(RAW / 'summary.json'), read(RAW / 'source-guard.json')
    tests = summary['tests']
    assert summary['overall'] == 'PASS' and tests['run'] == tests['executed'] > 420
    assert tests['failures'] == tests['errors'] == tests['skipped'] == 0
    assert summary['verified_original_files'] == 20 and guard['sources_unchanged'] and guard['head_unchanged']
    assert guard['source_commit_before'] == guard['source_commit_after'] == SOURCE
    spec = read(WORK / '18-spec-final-01/review.json')
    standards = read(WORK / '18-standards-final-01/review.json')
    assert spec['total_assertions'] == 599 and spec['findings'] == []
    assert standards['hard_findings'] == standards['actionable_smell_findings'] == []
    reviews = {}
    for folder in ('18-spec-final-01', '18-standards-final-01'):
        for path in (WORK / folder).rglob('*'):
            if path.is_file() and '__pycache__' not in path.parts and path.suffix not in {'.pyc', '.pyo'}:
                reviews[folder + '/' + path.relative_to(WORK / folder).as_posix()] = path
    original = Path('C:/Users/Donson/AppData/Local/Temp/aegisdc-ticket18-spec-f88718cb53c5490e92d89c8a472dd223')
    for path in original.iterdir():
        if path.is_file():
            reviews['original-binding-finding/' + path.name] = path
    support_names = ['18-sequential-integration-01.json','18-root-source-line-ending-precheck-01.json',
        '18-channel-binding-root-closure-01.json','18-independent-calibration-oracle-01.json',
        '18-independent-finite-path-witness-01.json','18-public-inference-oracle-65d857fd-01.json',
        '18-archived-inference-0e97b1c3-01.json','18-threshold-selection-draft-probe-01.json',
        'check_18_calibration_oracle.py','check_18_inference_against_oracle.py',
        'run_18_root_acceptance.py','build_18_root_packet.py']
    support = {n: WORK / n for n in support_names}
    for path in (WORK / '18-visual-qa-01').glob('*.json'):
        support['visual/' + path.name] = path
    copies = {f'raw/{n}': RAW / n for n in ('summary.json','source-guard.json','evidence.json','tests.log')}
    visual_manifest = {}
    visual_dir = WORK / '18-visual-qa-01'
    assert read(visual_dir / 'visual-review.json')['open_findings'] == 0
    assert read(visual_dir / 'architecture-visual-review.json')['open_findings'] == 0
    for stem in ('archived-posterior','finite-calibration','belief-boundary'):
        png = visual_dir / (stem + '.png'); svg = visual_dir / (stem + '.svg')
        dest = 'figures/' + png.name; copies[dest] = png
        if stem == 'belief-boundary':
            copies['figures/' + svg.name] = svg
            svg_target = (PACKET / 'figures' / svg.name).as_posix()
        else:
            svg_target = 'evidence/mainline/engineering/18-beliefs/capture-01/' + svg.name
            assert digest(ROOT / svg_target) == digest(svg)
        visual_manifest[dest] = dict(svg=svg_target,svg_sha256=digest(svg),png_sha256=digest(png))
    declared = sorted(set(copies) | {'.gitattributes','README.md','verify_packet.py','declaration.json',
        'source-manifest.json','archive-members.json','reviews.zip','support.zip'})
    write(packet / 'declaration.json', dict(schema='aegisdc-ticket18-root-delivery-v1',artifacts=declared,terminal_receipt='receipt.json'))
    for name, path in copies.items():
        target = packet / name; target.parent.mkdir(parents=True,exist_ok=True); target.write_bytes(path.read_bytes())
    attrs = ['# Exact original raw output line endings; all other whitespace checks retained.']
    for name, path in copies.items():
        if name.startswith('raw/') and b'\r\n' in path.read_bytes():
            attrs.append(name + ' -text whitespace=blank-at-eol,blank-at-eof,space-before-tab,cr-at-eol')
    (packet / '.gitattributes').write_text('\n'.join(attrs)+'\n',encoding='utf-8',newline='\n')
    archives = {}
    for name, members in (('reviews.zip',reviews),('support.zip',support)):
        archives[name] = {}
        with zipfile.ZipFile(packet / name,'x',zipfile.ZIP_DEFLATED) as archive:
            for member,path in sorted(members.items()):
                raw = path.read_bytes(); archive.writestr(member,raw)
                archives[name][member] = dict(sha256=sha256(raw).hexdigest(),bytes=len(raw))
    write(packet / 'archive-members.json',archives)
    capture = 'evidence/mainline/engineering/18-beliefs/capture-01/receipt.json'
    author = dict(candidate=AUTHOR,execution=EXECUTION,data_delivery=DATA,capture=capture,capture_sha256=digest(ROOT/capture))
    write(packet / 'source-manifest.json',dict(tested_source=SOURCE,author=author,visuals=visual_manifest,
        reviews=dict(standards_findings=0,spec_findings=0,independent_assertions=599,
                     standards_report_sha256=digest(WORK/'18-standards-final-01/report.md'),
                     spec_report_sha256=digest(WORK/'18-spec-final-01/SPEC.md'))))
    (packet/'verify_packet.py').write_bytes((WORK/'18-verify_packet.py').read_bytes())
    text = f'''# 第18项根验收：公开证据与认识更新

第18项在已评审集成源码 `{SOURCE}` 上通过统一根验收：{tests['executed']}项全执行，零失败、零错误、零跳过。20份历史原件通过校验；{len(guard['actual_sources'])}个Python与JSON源文件通过执行前后守卫，并逐一核对Git blobs。四份旧配置的LF到CRLF检出差异按精确路径记录，未改动历史原件。

![公开信息与认识边界](figures/belief-boundary.png)

## 两张数据图

![公开V6记录的后验变化](figures/archived-posterior.png)

27个时点使用第16项242秒公开快照的1,133条记录。阴影是声明似然变体的范围。它不是现场统计置信区间，模型没有枚举全设施所有故障。迟到记录作用于观察时段后向当前投影；复制、同源及相关记录不增添独立证据。

![独立有限法则的校验](figures/finite-calibration.png)

独立64原子法则的7组条件后验与公开推断最大绝对差为0，冻结容差1e-14。概率加权四类Brier为0.657800、0.630365、0.540401；故意错误的时点和复制独立性处理分别为0.564227和0.549375。这是有限生成法则下的工程校验，不代表巡检收益或现场校准。

## 来源与复核

作者执行源为`{EXECUTION}`，原件交付为`{DATA}`，候选为`{AUTHOR}`。作者正式工程捕获1次、失败0次；未执行作者全回归。作者原件、pending收据与候选索引保持其原始身份。本次根验收用独立记录接受第18项。

两轴评审均为0项未关闭问题。Spec独立通过163项公开接口断言和436项保存原件断言，共599项；原未注册绑定缺陷、开发红测试及审查夹具错误/纠正均保留。报告和原件在[评审ZIP](reviews.zip)，根守卫、合并保护和实际图像复核在[支持ZIP](support.zip)，ZIP不含运行缓存。

- [根接受权威](../../../../docs/mainline/evidence/18-root.json)
- [作者工程报告](../18-beliefs/README.md)与[接口定义](../../../../docs/mainline/18-belief-updates.md)
- [原始根测试摘要](raw/summary.json)、[日志](raw/tests.log)、[源码守卫](raw/source-guard.json)
- [产物清单](declaration.json)、[来源身份](source-manifest.json)与[原始收据](receipt.json)

三张PNG均实际本地查看。架构图修正一次长标签越界，最终无未关闭视觉问题；未声称浏览器QA。数据SVG来自封存作者输出，架构SVG是独立说明图，二者分别记源。用`verify_packet.py --delivery-commit COMMIT --output OUTSIDE_CHECKOUT.json`在新检出中核对声明产物、ZIP成员、作者原件与根执行源码，无需重跑推断或全回归。

M3继续推进第19项风险情景及后果、第20项检查与处置价值。注册效果试验未开始，现场标定待补，AI/RSI增量未建立；完整研究目标仍active。
'''
    (packet/'README.md').write_text(text,encoding='utf-8',newline='\n')
    assert {p.relative_to(packet).as_posix() for p in packet.rglob('*') if p.is_file()} == set(declared)
    write(packet/'receipt.json',dict(schema='aegisdc-ticket18-root-packet-v1',tested_source=SOURCE,
        delivery_gate='PENDING_COMMIT_AND_FRESH_CHECKOUT',artifacts={n:digest(packet/n) for n in declared},
        root_tests=tests,guarded_source_files=len(guard['actual_sources']),historical_originals=20,
        new_full_regressions=0,new_physical_runs=0,registered_research_trials=0,llm_calls=0,training_calls=0))
    write(ROOT/'docs/mainline/evidence/18-root.json',dict(schema='aegisdc-ticket-root-acceptance-v1',ticket='18',status='ACCEPTED',
        actual_root_source=SOURCE,root_tests=tests,packet=PACKET.as_posix(),packet_receipt_sha256=digest(packet/'receipt.json'),
        author_pending_index='docs/mainline/evidence/18.json',author=author,independent_assertions=599,
        standards_findings=0,spec_findings=0,field_calibration='PENDING',registered_research_trials=0,
        llm_calls=0,training_calls=0,overall_goal='ACTIVE'))
    ticket=ROOT/'.scratch/full-facility-mainline/issues/18-belief-updates.md'
    text=ticket.read_text(encoding='utf-8');assert '**Status:** claimed' in text
    text=text.replace('**Status:** claimed','**Status:** resolved',1).replace('- [ ]','- [x]')
    text+='\nRoot acceptance: `docs/mainline/evidence/18-root.json`; unified execution `'+SOURCE+'` passed '+str(tests['executed'])+' checks with zero skips. Figures and review evidence: `evidence/mainline/engineering/18-root-acceptance/README.md`. Original author candidate remains pending by design; Root authority resolves this ticket.\n'
    ticket.write_text(text,encoding='utf-8',newline='\n')
    progress=read(ROOT/'docs/mainline/progress.json');assert progress['current_ticket']=='18'
    progress.update(current_ticket='19',active_implementations=[])
    next(m for m in progress['milestones'] if m['id']=='M3')['acceptance_evidence'].append('docs/mainline/evidence/18-root.json')
    write(ROOT/'docs/mainline/progress.json',progress,new=False)
    current=read(ROOT/'docs/current-research.json')
    current.update(implementation='Tickets14–18 accepted. Current ticket19 maps evidence-based risk scenarios and service consequences. M3 remains in progress.',
        current_primary_ticket='19',current_primary_ticket_assigned=False,active_tickets=[],next_ready_unassigned=['19'])
    current['runtime_verification_documents'].append((PACKET/'README.md').as_posix())
    write(ROOT/'docs/current-research.json',current,new=False)
    changes={
        'docs/MAINLINE.md':('第15–17票已通过统一验收，当前主票18研究如何随证据和时间更新风险认识。','第18票已通过根验收，当前主票19建立风险情景、时间窗及服务后果。 [第18票数据图与架构](../evidence/mainline/engineering/18-root-acceptance/README.md)。'),
        'docs/NEXT.md':('第15–17票已通过统一验收，当前主票18。','第18票已通过根验收，当前主票19。 [认识更新数据图与架构](../evidence/mainline/engineering/18-root-acceptance/README.md)。')}
    for name,(old,new) in changes.items():
        p=ROOT/name;text=p.read_text(encoding='utf-8');assert old in text;text=text.replace(old,new,1);p.write_text(text,encoding='utf-8',newline='\n')
    print(json.dumps(dict(packet=str(PACKET),artifacts=len(declared),zip_members=sum(map(len,archives.values())),
        tests=tests,guarded=len(guard['actual_sources'])),ensure_ascii=False))

if __name__=='__main__':
    prepare()
