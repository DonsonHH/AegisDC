"""Check the public inference seam against an independently enumerated oracle."""
import argparse
from fractions import Fraction
from hashlib import sha256
from itertools import product
import json
from pathlib import Path
import subprocess
import sys


WORK = Path(__file__).resolve().parent


def read(path):
    return json.loads(path.read_bytes())


def row(identifier, channel, value, observed, arrived, *, parent=None):
    quality = dict(status='reported' if channel['unit'] == '1' else 'bounded',
                   error_bound=None if channel['unit'] == '1' else 0,
                   note='Declared synthetic engineering observation')
    return dict(id=identifier, source_id=channel['source_id'], target_id=channel['target_id'],
                observable_id=channel['observable_id'], unit=channel['unit'], value=value,
                observed_at_s=observed, arrived_at_s=arrived, valid_until_s=16,
                quality=quality, provenance=dict(origin_id=parent or identifier, copied_from_record_id=parent))


def compare(actual, expected):
    assert set(actual) == set(expected)
    for key, exact in expected.items():
        assert abs(actual[key] - float(Fraction(exact))) <= 1e-14, (key, actual[key], exact)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('checkout', type=Path)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    checkout = args.checkout.resolve()
    sys.path.insert(0, str(checkout / 'src'))
    sources = [checkout / path for path in ('src/aegis_dc/belief.py', 'src/aegis_dc/decision_view.py',
        'src/aegis_dc/evidence_ledger.py', 'configs/full-facility-belief-model-v1.json')]
    before = {path.relative_to(checkout).as_posix(): sha256(path.read_bytes()).hexdigest() for path in sources}
    from aegis_dc.belief import infer_belief
    from aegis_dc.decision_view import DecisionGateway

    public_fixture = read(WORK / '18-archived-public-frames-01.json')
    accepted_frame = public_fixture['frames'][0]
    model = read(sources[-1])
    nominal = accepted_frame['nominal_knowledge']
    registry = accepted_frame['evidence']['static_knowledge']
    channels = {channel['id']: channel for channel in model['channels']}
    oracle = read(WORK / '18-independent-calibration-oracle-01.json')['outcome_partitions']
    expected = {count: {tuple(row['reports']): row['exact_frequencies'] for row in oracle[label]['rows']}
                for count, label in enumerate(('no-reports', 'arrived-hot-only', 'both-arrived'))}
    checks = []
    for hot, low_power in product((False, True), repeat=2):
        report = row('hot', channels['fixed-hot'], hot, 1, 11)
        copy = row('copy', channels['fixed-hot'], hot, 1, 10, parent='hot')
        power = row('power', channels['fixed-low-power'], 0 if low_power else 3_000_000, 10, 12)
        ledger = dict(schema='aegisdc-evidence-ledger-v1', id=model['scope']['ledger_id'],
                      facility_id=nominal['facility_id'], basis='synthetic_assumption', time_unit='s',
                      **registry, records=[copy, power, report])
        plan = dict(schema='aegisdc-public-preparation-plan-v1', id='independent-finite-oracle-check',
                    basis='synthetic_assumption', time_unit='s', decision_times_s=[10, 11, 12],
                    requests=accepted_frame['requests'])
        gateway = DecisionGateway(nominal, ledger, plan)
        pattern = (hot, low_power)
        for count, instant in enumerate(plan['decision_times_s']):
            result = infer_belief(gateway.next_frame(), model)
            compare(result['posterior'], expected[count][pattern[:count]])
            assert result['physical_actions'] == [] and 'copy' not in result['information_updates']
            checks.append(dict(reports=pattern[:count], as_of_s=instant,
                               factors=result['information_updates'], posterior=result['posterior']))
    assert all(sha256((checkout / name).read_bytes()).hexdigest() == h for name, h in before.items())
    with args.output.open('x', encoding='utf-8', newline='\n') as stream:
        stream.write(json.dumps(dict(status='PASS', scope='Read-only public inference engineering checks',
            source_commit=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=checkout, text=True).strip(),
            source_sha256=before, checks=checks, physical_runs=0, registered_research_trials=0,
            model_calls=0, training_calls=0), ensure_ascii=False, indent=2) + '\n')
    print(f'{len(checks)} public inference outputs matched independent exact frequencies; source bytes unchanged.')


if __name__ == '__main__':
    main()
