"""Prepare a ticket 30 governance record only after both reviews and saved proof."""

from hashlib import sha256
import json
from pathlib import Path
import subprocess
from zipfile import ZIP_DEFLATED, ZipFile

ROOT=Path.cwd()
WORK=ROOT/'.work'
CANDIDATE='412a72b756b3691d596fc1e4fd6c4c1b43be8bd0'
BASE='3feccbb124b7e479b22cc8e361aad2d528b649de'
PROTOCOL='docs/mainline/30-comparison-protocol-v1.json'
LOCK='docs/mainline/evidence/30-protocol-lock.json'
AUTHORITY='docs/mainline/evidence/30-root.json'
PACKET='evidence/mainline/engineering/30-comparison-acceptance'


def git(*args):
    return subprocess.check_output(['git',*args],cwd=ROOT)


def read(path):
    return json.loads(path.read_bytes())


def digest(raw):
    return sha256(raw).hexdigest()


def write(path,obj,mode='x'):
    raw=(json.dumps(obj,ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode()
    with path.open(mode+'b') as stream:
        stream.write(raw)


def main():
    head=git('rev-parse','HEAD').decode().strip()
    assert not git('status','--porcelain')
    assert git('show','-s','--format=%P',head).decode().split()==[BASE,CANDIDATE]
    assert not git('diff','--name-only',CANDIDATE,head)
    assert git('rev-parse','pre-meeting-20261103^{}').decode().strip()=='076d9aa15c5bc99a5b7985f296e15543b7b0f3d7'
    proof=read(WORK/'30-fresh-protocol-01.json')
    assert proof['status']=='PASS_SAVED_PROTOCOL_DELIVERY' and proof['delivery']==CANDIDATE
    assert proof['facility_calls']==proof['selector_calls']==proof['seed_reads']==proof['registered_research_trials']==0
    assert proof['prepared_development_inputs']==36 and proof['refused_original_probe_types']==7
    assert proof['protocol_lock_sha256']==digest((ROOT/LOCK).read_bytes())
    p=read(ROOT/'docs/mainline/progress.json')
    assert p['current_ticket']=='30' and p['current_milestone']=='M5' and p['research_trials']['attempts']==0
    a=ROOT/PACKET
    files={}
    for axis,dirname in (('Spec','30-spec-final-01'),('Standards','30-standards-final-01')):
        f=WORK/dirname
        review=read(f/'manifest.json')
        assert review['candidate']==CANDIDATE
        declared=review['files'] if axis=='Spec' else review['artifacts']
        actual={p.relative_to(f).as_posix() for p in f.rglob('*') if p.is_file()
                and '__pycache__' not in p.parts and p.suffix not in ('.pyc','.pyo')}
        assert actual==set(declared)|{'manifest.json'},(axis,'Review artifact set differs')
        for name,sha in declared.items():
            raw=(f/name).read_bytes()
            assert digest(raw)==sha,(axis,name)
            files[f'reviews/{axis}/{name}']=raw
        files[f'reviews/{axis}/manifest.json']=(f/'manifest.json').read_bytes()
        if axis=='Spec':
            check=read(f/'audit.json')
            assert check['status']=='PASS_FROZEN_PROTOCOL_SPEC_ONLY' and not check['findings']
        else:
            assert review['status']=='PASS_FINAL_STANDARDS' and review['unresolved_findings']==0
    wt=Path('C:/Users/Donson/.codex/worktrees/mainline30-protocol/Renly')
    launch=wt/'.work/30-source-lock-01'
    focused=wt/'.work/30-frozen-design-tests-01'
    terminal=read(focused/'terminal.json')
    assert terminal['status']=='PASS' and terminal['source']==proof['design_commit']
    assert b'Ran 8 tests' in (focused/'stderr.raw').read_bytes()
    for folder,names in ((launch,('attempt.json','terminal.json','stdio.log')),
                         (focused,('attempt.json','terminal.json','stdout.raw','stderr.raw'))):
        for name in names:
            files[f'checks/{folder.name}/{name}']=(folder/name).read_bytes()
    files['checks/fresh-protocol.json']=(WORK/'30-fresh-protocol-01.json').read_bytes()
    integrated=read(WORK/'30-integrated-protocol-01.json')
    assert integrated==dict(proof,delivery=head)
    files['checks/integrated-protocol.json']=(WORK/'30-integrated-protocol-01.json').read_bytes()
    files['tools/record_30_protocol_acceptance.py']=Path(__file__).read_bytes()
    a.mkdir()
    archive=a/'acceptance-originals.zip'
    with ZipFile(archive,'x',compression=ZIP_DEFLATED,compresslevel=6) as out:
        for name,raw in sorted(files.items()):
            out.writestr(name,raw)
    write(a/'manifest.json',dict(status='PASS_REVIEWED_REGISTRATION',design_source=proof['design_commit'],
        reviewed_candidate=CANDIDATE,integrated_source=head,archive_sha256=digest(archive.read_bytes()),
        members={name:digest(raw) for name,raw in sorted(files.items())},
        research_trials=0,held_inputs_materialized=0,scope='Protocol acceptance. Review and input-only verification; no effect execution.'))
    write(ROOT/'docs/mainline/evidence/30-root-delivery.json',proof)
    write(ROOT/AUTHORITY,dict(status='ACCEPTED',ticket='30',milestone='M5',accepted_date='2026-11-08',
        classification='FROZEN_FINITE_SYNTHETIC_COMPARISON_PROTOCOL_ONLY',
        actual_root_source=head,reviewed_candidate=CANDIDATE,design_commit=proof['design_commit'],
        protocol=PROTOCOL,protocol_lock=LOCK,protocol_lock_sha256=proof['protocol_lock_sha256'],
        fresh_delivery_proof='docs/mainline/evidence/30-root-delivery.json',packet=PACKET,
        packet_manifest_sha256=digest((a/'manifest.json').read_bytes()),frozen_source_pins=proof['design_source_pins'],
        budget=read(ROOT/PROTOCOL)['global_budget'],prepared_development_inputs=36,focused_checks=8,
        independent_axes=['Spec','Standards'],original_invalid_probe_types_refused=7,held_inputs_materialized=0,
        registered_research_trials=0,field_calibration='PENDING',overall_goal='ACTIVE',next_ticket='31'))
    ticket=ROOT/'.scratch/full-facility-mainline/issues/30-freeze-protocol.md'
    text=ticket.read_text(encoding='utf-8')
    assert text.count('- [ ]')==4 and '**Status:** claimed' in text
    text=text.replace('**Status:** claimed','**Status:** resolved').replace('- [ ]','- [x]').replace(
        'Pending implementation and acceptance.','Accepted as a frozen protocol, before any effect execution.')
    text+='\n\n[Protocol](../../../docs/mainline/30-registered-comparison.md), [machine registration](../../../docs/mainline/30-comparison-protocol-v1.json), [source lock](../../../docs/mainline/evidence/30-protocol-lock.json), [root acceptance](../../../docs/mainline/evidence/30-root.json) and [fresh exact proof](../../../docs/mainline/evidence/30-root-delivery.json). Six development conditions and all 36 method inputs were verified without executing the facility or selector. Sealed phase inputs were not materialized. Next: 31 development only.\n'
    ticket.write_text(text,encoding='utf-8',newline='\n')
    p['current_ticket']='31'
    p['active_implementations']=[]
    p['liveness_refresh']='2026-11-08: frozen ticket30 accepted with exact saved delivery and independent review. Ticket31 ready; no registered attempts.'
    p['research_trials'].update(status='frozen_not_started',protocol=PROTOCOL)
    m=next(row for row in p['milestones'] if row['id']=='M5')
    assert m['status']=='in_progress'
    m['acceptance_evidence'].append(AUTHORITY)
    m['progress_scope']='29–30 accepted; registered development (31) is the only next executable phase.'
    write(ROOT/'docs/mainline/progress.json',p,'w')
    current=read(ROOT/'docs/current-research.json')
    current.update(date='2026-11-08',implementation='Tickets01–30 accepted within declared scope. Protocol frozen; next ticket31 development only. Zero registered trials.',
        current_primary_ticket='31',current_primary_ticket_assigned=False,next_ready_unassigned=['31'],active_tickets=[])
    current['runtime_verification_documents'].append('docs/mainline/30-registered-comparison.md')
    write(ROOT/'docs/current-research.json',current,'w')
    mainline=ROOT/'docs/MAINLINE.md'
    text=mainline.read_text(encoding='utf-8')
    old='当前主票 30 冻结独立比较协议，M5 和完整研究目标持续进行。'
    assert old in text
    text=text.replace(old,'第 30 项独立比较协议已冻结，当前主票 31 仅在公开开发条件上评估；M5 和完整研究目标持续进行。')
    text+='\n\n[独立比较注册协议](mainline/30-registered-comparison.md)固定主配对、六种参照方法、成本与硬约束、确认样本及分阶段预算。真实确认输入与执行分别通过 32、33；冻结时注册效果试验为零。\n'
    mainline.write_text(text,encoding='utf-8',newline='\n')
    print(json.dumps(dict(status='ACCEPTED',integrated=head,archive_members=len(files),next_ticket='31',registered_trials=0)))


if __name__=='__main__':
    main()
