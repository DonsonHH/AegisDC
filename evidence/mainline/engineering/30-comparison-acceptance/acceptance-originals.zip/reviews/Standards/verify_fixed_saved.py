"""Independent final Standards verification, using only fixed public and saved Git bytes."""
import ast
from collections import Counter
from copy import deepcopy
from hashlib import sha256
import io
import json
from pathlib import Path, PurePosixPath
import subprocess
import sys
from zipfile import ZipFile

ROOT=Path(sys.argv[1]); OUT=Path(sys.argv[2])
REV='412a72b756b3691d596fc1e4fd6c4c1b43be8bd0'
DESIGN='5c24e464d226fc46406a1102e4fa3b052a0f0a45'
BASE='3feccbb124b7e479b22cc8e361aad2d528b649de'
PROTOCOL='docs/mainline/30-comparison-protocol-v1.json'
BLUEPRINT='configs/full-facility-comparison-held-blueprints-v1.json'
DEV='configs/full-facility-comparison-development-v1.json'
LOCK='docs/mainline/evidence/30-protocol-lock.json'
PACKAGE='evidence/mainline/engineering/30-comparison-preparation'
REVIEW=PACKAGE+'/review-and-corrections'
counts=Counter()
cache={}
def check(rule,actual):
    if not actual:
        raise AssertionError(rule)
    counts[rule]+=1
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT)
def blob(name,rev=REV):
    key=(name,rev)
    if key not in cache:
        cache[key]=git('cat-file','blob',rev+':'+name)
    return cache[key]
def sha(raw):return sha256(raw).hexdigest()
def unpack(raw):return json.loads(raw)
def read(name,rev=REV):return unpack(blob(name,rev))
def write(name,value):
    file=OUT/name
    file.parent.mkdir(parents=True,exist_ok=True)
    with file.open('xb') as stream:
        stream.write(value if isinstance(value,bytes) else (json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode())
def paths(rev,*scopes):return set(git('ls-tree','-rz','--name-only',rev,'--',*scopes).decode().split('\0'))-{''}

check('design and delivery are fixed descendant commits',
      git('merge-base',DESIGN,REV).decode().strip()==DESIGN and git('rev-parse',REV+'^').decode().strip()==DESIGN)
check('lock is the only postdesign committed change',git('diff','--name-only',DESIGN,REV).decode().splitlines()==[LOCK])
check('historic source tag preserved',
      git('rev-parse','pre-meeting-20261103^{}').decode().strip()=='076d9aa15c5bc99a5b7985f296e15543b7b0f3d7')
lock=read(LOCK); plan=read(PROTOCOL); blue=read(BLUEPRINT); dev=read(DEV)
check('fixed frozen protocol identity',lock['design_commit']==DESIGN and lock['protocol_id']==plan['id']
    and lock['status']=='FROZEN_INPUT_DESIGN' and plan['status']=='FROZEN_NO_EXECUTION_UNTIL_TICKET_30_ACCEPTED')
check('design lock declares no executed research',lock['held_inputs_materialized']==lock['registered_research_trials']==0)
seals=lock['commitments_sha256']
check('three distinct syntactically valid public commitments',
    set(seals)=={'confirmation','ablation','robustness'} and len(set(seals.values()))==3
    and all(len(v)==64 and v==v.lower() and int(v,16)>=0 for v in seals.values()))
gate=ast.parse(blob('scripts/comparison_release.py'))
statement=next(s for s in gate.body if isinstance(s,ast.Assign) and isinstance(s.targets[0],ast.Name) and s.targets[0].id=='PINS')
explicit={PROTOCOL}|{ast.literal_eval(item) for item in statement.value.elts[1:]}
runtime={n for n in paths(DESIGN,'src/aegis_dc') if n.endswith('.py')}
pins=lock['pins']
check('61 design pins exactly equal declared runtime and static source roles',set(pins)==explicit|runtime and len(pins)==61)
for name,digest in pins.items():
    check('frozen design Git blob and candidate Git blob agree',sha(blob(name,DESIGN))==digest==sha(blob(name)))
    check('design and working path hash agree',sha((ROOT/name).read_bytes())==digest)
for phase,per_family in (('confirmation',4),('ablation',2)):
    counts_by_family=Counter(row['family'] for row in plan['phases'][phase]['worlds'])
    check('held family cardinality matches blueprint and plan',counts_by_family=={k:len(v) for k,v in blue[phase].items()}
        and set(counts_by_family.values())=={per_family})
for name,block in blue['robustness'].items():
    worlds=[row for row in plan['phases']['robustness']['worlds'] if row['family']==name]
    check('robustness group and arm identities match',len(worlds)==2
        and all(w['comparison']==block['key'] for w in worlds)
        and {w['level'] for w in worlds}=={'reference','perturbed'}
        and bool(block['allowed_deltas']))
keys=set()
for row in [*dev['worlds'].values(),*(r for p in ('confirmation','ablation') for v in blue[p].values() for r in v),
            *(v['shared'] for v in blue['robustness'].values())]:
    semantic=dict(row);semantic.pop('variant',None)
    key=json.dumps(semantic,sort_keys=True,separators=(',',':'))
    check('distinct semantic recipe coordinates across roles',key not in keys)
    keys.add(key)
def archive(folder, filename, number):
    manifest=read(folder+'/manifest.json')
    raw=blob(folder+'/'+filename)
    check('archive identity bound to manifest',sha(raw)==manifest['archive_sha256'])
    check('archive working file matches committed blob',(ROOT/folder/filename).read_bytes()==raw)
    with ZipFile(io.BytesIO(raw)) as file:
        names=file.namelist()
        check('archive roles exactly equal declared members',len(names)==len(set(names))==number and set(names)==set(manifest['members']))
        members={}
        for name in names:
            p=PurePosixPath(name)
            raw=file.read(name)
            check('archive has only durable safe exact members',
                  not p.is_absolute() and '..' not in p.parts and '\\' not in name and '__pycache__' not in p.parts
                  and p.suffix not in ('.pyc','.pyo') and sha(raw)==manifest['members'][name])
            members[name]=raw
    return manifest,members
prep,old=archive(PACKAGE,'preparation-originals.zip',81)
corr,retained=archive(REVIEW,'originals.zip',77)
check('review disposition and archival classifications',corr['original_standards_probes']==7
      and corr['original_static_findings']=={'Spec':1,'Standards':2}
      and corr['facility_calls']==corr['selector_calls']==corr['registered_research_trials']==0)
for members in (old,retained):
    for path in members:
        if not path.startswith('tests/') or not path.endswith('/attempt.json'):continue
        prefix=path.removesuffix('attempt.json')
        start,term=unpack(members[path]),unpack(members[prefix+'terminal.json'])
        check('native test lifecycle has exact guarded source',start['source']==term['source'] and term['source_guard']
              and term['facility_calls']==term['selector_calls']==term['research_trials']==0)
        for name,digest in start['pins'].items():
            check('original attempt pinned Git blob matches',sha(blob(name,start['source']))==digest)
        for stream in ('stdout','stderr'):
            check('native original test stream hash matches',sha(members[prefix+stream+'.raw'])==term[stream+'_sha256'])
for name,attempt in prep['input_preparation'].items():
    prefix='input-preparation/'+name+'/'
    receipt=unpack(old[prefix+'receipt.json'])
    check('original input-only preparation attempted and terminal counts retained',
          receipt['source']==attempt['source'] and receipt['status']==attempt['status']
          and receipt['attempted']==attempt['started'] and receipt['passed']==attempt['passed'] and receipt['source_guard'])
    for path,digest in attempt['committed_source_identity'].items():
        check('original preparation Git source matches',sha(blob(path,attempt['source']))==digest)
    for path,digest in receipt['artifacts'].items():
        check('original preparation generated bytes match',sha(old[prefix+path])==digest)
    check('original preparation tool bytes match receipt',sha(old[f'tools/30-prepare-development-inputs-{name[-2:]}.py'])==receipt['authoring_tool_sha256'])
draft_prefix='independent/Standards/'
original=unpack(retained[draft_prefix+'manifest.json'])
for name,digest in original['artifacts'].items():
    check('earlier reviewer original equals preserved byte identity',sha(retained[draft_prefix+name])==digest)
cli='scripts/registered_comparison.py'
for path in (PROTOCOL,BLUEPRINT,cli):
    write('snapshot/'+path,blob(path))
probes=[]
def probe(name,doc,kind,needle):
    path=OUT/'probes'/f'{name}.json'
    write(f'probes/{name}.json',doc)
    args=[sys.executable,'-B','-X','utf8',str(OUT/'snapshot'/cli),kind]
    if kind=='audit-blueprints':
        args += [str(OUT/'snapshot'/PROTOCOL)]
    args += [str(path)]
    result=subprocess.run(args,cwd=OUT,capture_output=True,check=False)
    write(f'probes/{name}.stdout.raw',result.stdout)
    write(f'probes/{name}.stderr.raw',result.stderr)
    check('each original invalid declaration is specifically refused',
        result.returncode==2 and not result.stdout and needle.lower() in result.stderr.decode('utf-8').lower())
    probes.append(dict(name=name,exit=result.returncode,expected_reason=needle,reason=result.stderr.decode('utf-8').strip(),
        raw_stdout_sha256=sha(result.stdout),raw_stderr_sha256=sha(result.stderr)))

x=deepcopy(plan);x['comparison']['minimum_worthwhile_gain_s']=-1000;x['comparison']['cost_bounds']={'anything':False}
probe('negative-threshold-and-invalid-cost',x,'audit-plan','minimum worthwhile gain')
x=deepcopy(plan);x['phases']['confirmation'].update(ticket='31',release='IMMEDIATE')
probe('premature-release',x,'audit-plan','phase preparation/execution gate')
x=deepcopy(plan);x['attempt_policy'].update(stop_conditions=[],repeated_attempts='Retry until successful')
probe('empty-stop-and-retry-forever',x,'audit-plan','stop/retry rules')
x=deepcopy(plan);x['comparison'].pop('metric_definition');x['comparison'].pop('outcome_rules');x.pop('registration_limits')
probe('missing-metric-rules-and-limits',x,'audit-plan','root field roles')
x=deepcopy(blue);x['confirmation']['network-restorable'][0]['events']=[dict(time_s=.5,parameter_id='coolant_inventory',value=-1,source_note='Invalid public exogenous coordinate')]
probe('illegal-exogenous-input',x,'audit-blueprints','allowed exogenous parameter')
x=deepcopy(blue);x['robustness']['load-level']['perturbed']={'offered_demand':-1}
probe('negative-robust-demand',x,'audit-blueprints','registered limits')
x=deepcopy(blue);x['masks']={name:{} for name in x['masks']}
probe('empty-ablation-rules',x,'audit-blueprints','Missing ablation transform semantics')
write('saved-proof.json',dict(status='PASS_CORRECTED_STATIC_REFUSALS_AND_EXACT_ORIGINALS',base=BASE,design_commit=DESIGN,
    candidate=REV,assertions=sum(counts.values()),assertion_groups=counts,source_pins=len(pins),archive_members=len(old)+len(retained),
    original_probe_types_refused=len(probes),probes=probes,facility_calls=0,selector_calls=0,seed_reads=0,held_inputs_materialized=0))
print(json.dumps(dict(status='PASS',assertions=sum(counts.values()),source_pins=len(pins),archives=len(old)+len(retained),refused=len(probes))))
