"""Recheck exact execution ancestry and pin logic with generic bytes. No release/nonce calls."""
from copy import deepcopy
from hashlib import sha256
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
from tempfile import TemporaryDirectory

SOURCE=Path(sys.argv[1])
OUT=Path(sys.argv[2])
CANDIDATE='412a72b756b3691d596fc1e4fd6c4c1b43be8bd0'
EXEC='docs/mainline/evidence/30-confirmation-execution-lock.json'
LOCK='docs/mainline/evidence/30-protocol-lock.json'
PROBE_INPUT='synthetic-world/literal-arm.json'
results=[]
def digest(raw):return sha256(raw).hexdigest()
with TemporaryDirectory(prefix='30-standards-git-fixture-') as folder:
    root=Path(folder)/'repo'
    root.mkdir()
    directory=Path(folder)/'generic-bytes'
    def write(path,raw):
        p=root/path
        p.parent.mkdir(parents=True,exist_ok=True)
        p.write_bytes(raw if isinstance(raw,bytes) else (json.dumps(raw,indent=2,allow_nan=False)+'\n').encode())
    def git(*args):
        return subprocess.check_output(['git','-c','core.autocrlf=false','-c','user.name=Standards Fixture',
            '-c','user.email=fixture@example.invalid',*args],cwd=root).decode().strip()
    def commit(note):
        git('add','--','.')
        git('commit','-qm',note)
        return git('rev-parse','HEAD')
    git('init','-q')
    for name in ('scripts/comparison_release.py','scripts/inspection_delivery.py','scripts/registered_comparison.py'):
        write(name,subprocess.check_output(['git','cat-file','blob',f'{CANDIDATE}:{name}'],cwd=SOURCE))
    write('src/aegis_dc/dummy.py',b'# Generic fixture executable role, never loaded.\n')
    prior=commit('Pre-design synthetic Git revision')
    write('design-note.txt',b'Generic static Git ancestry fixture only\n')
    design=commit('Design ancestor')
    write('scripts/dummy.py',b'# Phase runner identity fixture, never loaded.\n')
    execution=commit('Execution freeze')
    sibling=git('commit-tree',git('rev-parse',execution+'^{tree}'),'-p',design,'-m','Unmerged synthetic sibling')
    assert sibling!=execution
    (directory/'synthetic-world').mkdir(parents=True)
    (directory/PROBE_INPUT).write_bytes(b'{"test":"opaque byte identity, not a research input"}')
    write(LOCK,{'synthetic_byte_identity_only':True})
    pins={name:digest((root/name).read_bytes()) for name in git('ls-files','--','src','scripts','configs').splitlines()}
    budget={'attempts':1,'simulated_charge_s':10,'scheduled_decisions':10}
    plan={'phases':{'confirmation':{'budget':budget,'worlds':[{'id':'synthetic-world'}],'arms':['literal-arm']}}}
    receipt=dict(schema='aegisdc-comparison-execution-lock-v1',status='REVIEWED_FOR_EXECUTION',phase='confirmation',
        design_lock_sha256=digest((root/LOCK).read_bytes()),execution_source=execution,execution_pins=pins,
        interpreter_sha256=digest(Path(sys.executable).read_bytes()),input_hashes={PROBE_INPUT:digest((directory/PROBE_INPUT).read_bytes())},
        budget=budget)
    def install(data,note):
        write(EXEC,data)
        commit(note)
        return dict(execution_lock=EXEC,execution_lock_sha256=digest((root/EXEC).read_bytes()))
    accepted=install(receipt,'First generic governance receipt')
    sys.path.insert(0,str(root/'scripts'))
    spec=importlib.util.spec_from_file_location('fixed_gate',root/'scripts/comparison_release.py')
    assert spec is not None and spec.loader is not None
    gate=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(gate)
    assert gate.ROOT==root.resolve()
    def test(name,expected=None,auth=None):
        try:
            result=gate._execution_receipt('confirmation',{'design_commit':design},plan,directory,accepted if auth is None else auth)
        except ValueError as e:
            assert expected is not None and expected in str(e),(name,e)
            results.append(dict(name=name,status='REFUSED',reason=str(e),governance=git('rev-parse','HEAD')))
        else:
            assert expected is None and result==execution,(name,result)
            results.append(dict(name=name,status='PASS_VALID_BYTE_FIXTURE',source=result,governance=git('rev-parse','HEAD')))
    test('Committed descendant governance leaves frozen code valid')
    test('Authority does not bind committed receipt','Accepted ticket 32 does not bind',
         dict(accepted,execution_lock_sha256='0'*64))
    (directory/PROBE_INPUT).write_bytes(b'changed bytes')
    test('Input byte mismatch','Frozen phase input set or bytes differ')
    (directory/PROBE_INPUT).write_bytes(b'{"test":"opaque byte identity, not a research input"}')
    (directory/'extra.txt').write_bytes(b'extra')
    test('Extra unregistered input file','Frozen phase input set or bytes differ')
    (directory/'extra.txt').unlink()
    for name,key,value,expected in [
        ('Source predates registered design','execution_source',prior,'not an ancestor'),
        ('Unmerged sibling is not an ancestor of governance','execution_source',sibling,'not an ancestor'),
        ('Missing executable pin','execution_pins',{k:v for k,v in pins.items() if k!='scripts/dummy.py'},'Executable files differ'),
        ('Interpreter differs','interpreter_sha256','0'*64,'Interpreter differs'),
        ('Missing input slot','input_hashes',{},'Phase input denominator differs'),
    ]:
        item=dict(receipt,**{key:value})
        accepted=install(item,name)
        test(name,expected)
    accepted=install(receipt,'Restore genuine synthetic lock')
    write('scripts/dummy.py',b'# Changed executable bytes after design\n')
    commit('Unexpected executable changes')
    test('Same path but new committed executable bytes','Executable files differ')
    commits=dict(prior=prior,design=design,execution=execution,unmerged_sibling=sibling)
with (OUT/'synthetic-ancestry-and-pins.json').open('x',encoding='utf-8',newline='\n') as out:
    json.dump(dict(status='PASS_SYNTHETIC_EXECUTION_LOCK_CHECKS',candidate=CANDIDATE,
        checked_cases=len(results),passed_valid=1,refused_invalid=len(results)-1,synthetic_commits=commits,cases=results,
        facility_calls=0,selector_calls=0,seed_reads=0,held_inputs_materialized=0,
        scope='One synthetic generic input slot; checks immutable byte/ancestry gates only.'),out,indent=2,allow_nan=False)
    out.write('\n')
print(json.dumps(dict(status='PASS',checks=len(results),refused=len(results)-1,raw_nonce_reads=0)))
