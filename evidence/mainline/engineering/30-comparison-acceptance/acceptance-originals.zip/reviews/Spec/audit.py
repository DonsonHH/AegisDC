"""Independent final Spec audit: exact frozen Git and saved evidence only."""
import ast
from collections import Counter
from copy import deepcopy
from hashlib import sha256
import io
import json
from pathlib import Path, PurePosixPath
import subprocess
from zipfile import ZipFile

REPO=Path('C:/Users/Donson/.codex/worktrees/mainline30-protocol/Renly')
ROOT=Path('C:/Users/Donson/Documents/ChatGPT/Renly')
OUT=ROOT/'.work/30-spec-final-01'
BASE='3feccbb124b7e479b22cc8e361aad2d528b649de'
DESIGN='5c24e464d226fc46406a1102e4fa3b052a0f0a45'
PIN='412a72b756b3691d596fc1e4fd6c4c1b43be8bd0'
PLAN='docs/mainline/30-comparison-protocol-v1.json'
LOCK='docs/mainline/evidence/30-protocol-lock.json'
PACKAGE='evidence/mainline/engineering/30-comparison-preparation'
BUNDLE_NAMES=('preparation-originals.zip','originals.zip')
checks=Counter()
def check(condition,label):
    checks[label]+=1
    if not condition:raise AssertionError(label)
def git(*args,raw=None):
    return subprocess.check_output(['git',*args],cwd=REPO,input=raw)
def blob(name,rev=PIN):
    return git('cat-file','blob',f'{rev}:{name}')
def blobs(names,rev):
    names=sorted(names)
    raw=git('cat-file','--batch',raw=b''.join(f'{rev}:{n}\n'.encode() for n in names))
    data=io.BytesIO(raw)
    out={}
    for name in names:
        head=data.readline().split()
        check(len(head)==3 and head[1]==b'blob','Git batch blob identity')
        out[name]=data.read(int(head[2]))
        check(data.read(1)==b'\n','Git batch byte boundary')
    check(data.read()==b'','Git batch complete')
    return out
def read(name,rev=PIN):
    return json.loads(blob(name,rev))
def digest(raw):return sha256(raw).hexdigest()
def canon(v):return json.dumps(v,sort_keys=True,separators=(',',':'),allow_nan=False).encode()

def originals(folder,archive_name,count):
    m=read(f'{folder}/manifest.json')
    archive=blob(f'{folder}/{archive_name}')
    check(digest(archive)==m['archive_sha256'],'Original archive SHA')
    with ZipFile(io.BytesIO(archive)) as zipfile:
        names=zipfile.namelist()
        check(len(names)==len(set(names))==count and set(names)==set(m['members']),'Unique exact original members')
        values={name:zipfile.read(name) for name in names}
    for name,raw in values.items():
        p=PurePosixPath(name)
        check(not p.is_absolute() and '..' not in p.parts and '__pycache__' not in p.parts
              and p.suffix not in {'.pyc','.pyo'} and digest(raw)==m['members'][name],'Archive original and durable classification')
    return m,values

check(git('rev-parse','pre-meeting-20261103^{}').decode().strip()=='076d9aa15c5bc99a5b7985f296e15543b7b0f3d7','History preservation')
check(git('merge-base',BASE,PIN).decode().strip()==BASE and git('rev-parse',PIN+'^').decode().strip()==DESIGN,'Integration ancestry')
check(git('diff','--name-only',DESIGN,PIN).decode().splitlines()==[LOCK],'Post-design only the public lock added')
check(not git('diff','--name-only',BASE,PIN,'--','src'),'Accepted eight-domain runtime unchanged')
lock=read(LOCK)
plan=read(PLAN)
held=read(plan['held_blueprints'])
check(lock['design_commit']==DESIGN and lock['protocol_id']==plan['id'],'Freeze identity')
check(lock['held_inputs_materialized']==lock['registered_research_trials']==0,'Frozen at zero held materializations and outcomes')
check(plan['status']=='FROZEN_NO_EXECUTION_UNTIL_TICKET_30_ACCEPTED','Frozen status')
commitments=lock['commitments_sha256']
check(set(commitments)=={'confirmation','ablation','robustness'} and len(set(commitments.values()))==3
      and all(len(x)==64 and set(x)<=set('0123456789abcdef') for x in commitments.values()),'Three distinct public SHA-256 commitments')
source=blob('scripts/comparison_release.py').decode()
release_module=ast.parse(source)
paths_assignment=next(node.value for node in release_module.body if isinstance(node,ast.Assign)
                      and isinstance(node.targets[0],ast.Name) and node.targets[0].id=='PINS')
pins={PLAN,*[ast.literal_eval(node) for node in paths_assignment.elts[1:]]}
runtime=set(git('ls-tree','-r','--name-only',DESIGN,'src/aegis_dc').decode().splitlines())
runtime={n for n in runtime if n.endswith('.py')}
check(pins|runtime==set(lock['pins']),'All declared source roles, including runtime, pinned')
for commit in (DESIGN,PIN):
    for path,raw in blobs(lock['pins'],commit).items():
        check(digest(raw)==lock['pins'][path],'Exact lock source bytes')
for token in ("_accepted('30')","_accepted('31' if phase=='confirmation' and stage=='prepare' else '32' if phase=='confirmation' else '34')",
              '_execution_receipt(phase,lock,plan,input_directory.resolve(),gate)',
              "_read_nonce(nonce_path,lock['commitments_sha256'][phase])"):
    check(token in source,'Stage-specific gate is implemented')
check(source.index('_execution_receipt(phase,lock,plan,input_directory.resolve(),gate)')<
      source.index("_read_nonce(nonce_path,lock['commitments_sha256'][phase])"),'No nonce read until source/receipt validation')
check("accepted.get('execution_lock_sha256')" in source and '_ancestor(source,_head())' in source and
      'code==hashes(source,code)==hashes(_head(),code)' in source,'Confirmation binding to exact immutable ancestor')
check('digest(Path(sys.executable).read_bytes())' in source and 'actual==expected' in source,'Interpreter and full input denominator pinned')
check('prepare' in plan['seed_policy']['release_rules'].lower() and 'accepted31' in plan['seed_policy']['release_rules']
      and 'accepted32' in plan['seed_policy']['release_rules'],'No prepare/execute dependency cycle')
check('source and input' in plan['registration_limits']['release'] or 'attempt ledger' in plan['registration_limits']['release'],'Audit is not an execution ledger')
for stage,n,arms in (('development',6,6),('confirmation',16,6),('ablation',8,4),('robustness',8,2)):
    phase=plan['phases'][stage]
    check(len(phase['worlds'])==n and len(phase['arms'])==arms,'Finite phase denominators')
    check(phase['budget']==dict(attempts=n*arms,simulated_charge_s=10*n*arms,scheduled_decisions=10*n*arms),'Finite stage budget')
check(sum(p['budget']['attempts'] for p in plan['phases'].values())==plan['global_budget']['attempts']==180,'Global attempt budget')
check(set(held['masks'])==set(plan['phases']['ablation']['arms'])-{'full'},'Exact planned ablation arms')
check('Current equality gates need a separately reviewed extension' in held['masks']['without_joint_crew_planning']['binding_scope'],'Team adapter expressly future-gated')
check('compute-only aggregation' in held['masks']['without_dependency_context']['capacity_transform'],'Dependency aggregation is explicit and prospective')
check('matched' in plan['comparison']['independence_unit'],'Independent world rather than row')
check(Counter(w['family'] for w in plan['phases']['confirmation']['worlds'])==Counter({k:4 for k in held['confirmation']}),'Four fixed equal strata')
check(plan['comparison']['outcome_order']==[r['label'] for r in plan['comparison']['outcome_rules']],'Finite outcome precedence')
check('Sum lower endpoints/16' in plan['comparison']['partial_outcome_details']['aggregate'],'Original denominator retained with failure')
check('earliest differing' in plan['comparison']['identification']['unit'] and 'at least four' in plan['comparison']['identification']['criterion'],'Identification is distinct first-divergence worlds')
a=blob('scripts/summarize_comparison_facts.py').decode()
check(a.index('elif not enough:')<a.index("status='PRACTICAL_HARM'")<a.index("status='STRATUM_SENSITIVE'"),'Insufficient action discrimination never silently becomes gain/no-gain')
check("source_verification='REQUIRED_SEPARATELY'" in a,'Summarizer cannot authenticate facts by itself')
tokens={plan['id'],*plan['seed_policy']['namespaces'].values(),'assignment','seed','portable','fixed'}
for phase in plan['phases'].values():
    for row in phase['worlds']:
        tokens.update((row['family'],row['id']))
        if 'comparison' in row:tokens.add(row['comparison'])
for stage in ('confirmation','ablation'):
    for family,recipes in held[stage].items():
        tokens.add(family)
        tokens.update(r['variant'] for r in recipes)
check(all(token.isascii() for token in tokens),'All frozen HMAC message fields are ASCII (canonical encoding parity)')
before,orig=originals(PACKAGE,BUNDLE_NAMES[0],81)
review,cor=originals(PACKAGE+'/review-and-corrections',BUNDLE_NAMES[1],77)
check(review['original_static_findings']=={'Spec':1,'Standards':2} and review['original_standards_probes']==7,'Original independent findings retained')
stage='tests/release-gate-fixture-01'
term=json.loads(cor[f'{stage}/terminal.json'])
check(term['status']=='PASS' and term['source_guard'] and term['facility_calls']==term['selector_calls']==term['research_trials']==0,'Synthetic release-gate test scope')
check(term['stderr_sha256']==digest(cor[f'{stage}/stderr.raw']) and term['stdout_sha256']==digest(cor[f'{stage}/stdout.raw']),'Exact synthetic gate test original streams')
check('test_confirmation_can_prepare_before_32_but_execute_only_its_reviewed_source' in cor[f'{stage}/stderr.raw'].decode(),'Positive staged-release fixture named')
testdir=REPO/'.work/30-frozen-design-tests-01'
terminal=json.loads((testdir/'terminal.json').read_bytes())
check(terminal['source']==DESIGN and terminal['source_guard'] and terminal['status']=='PASS','Exact frozen design test status')
check(terminal['facility_calls']==terminal['selector_calls']==terminal['research_trials']==0,'Frozen test scope excludes physical/selector work')
stderr=(testdir/'stderr.raw').read_bytes()
check(digest(stderr)==terminal['stderr_sha256'] and 'Ran 8 tests' in stderr.decode() and stderr.decode().rstrip().endswith('OK'),'Eight original passing tests at design pin')
attempt=json.loads((testdir/'attempt.json').read_bytes())
for path,raw in blobs(attempt['pins'],DESIGN).items():
    check(digest(raw)==attempt['pins'][path],'Exact frozen test input/tool pins')
prep='input-preparation/30-development-inputs-02'
receipt=json.loads(orig[f'{prep}/receipt.json'])
compiled=0
for world in plan['phases']['development']['worlds']:
    one,two=[],[]
    for arm in plan['phases']['development']['arms']:
        path=f"{world['id']}/{arm}.json"
        raw=orig[f'{prep}/{path}']
        check(digest(raw)==receipt['artifacts'][path],'Exact saved development input')
        d=json.loads(raw)
        p=d['dispatch_program']
        policy=p['policy_program']
        check(policy.pop('policy')==arm and p['decision_times_s']==plan['decision_times_s']
              and policy['resource_budget']==plan['comparison']['common_admission_budget']
              and d['duration_s']==world['duration_s'] and d['maximum_step_s']==plan['maximum_step_s'],'Saved arm/clock/resource assignment')
        if arm in plan['comparison']['primary']:one.append(digest(canon(d)))
        policy.pop('options')
        two.append(digest(canon(d)))
        compiled+=1
    expected=receipt['checks'][world['id']]
    check(len(set(one))==1 and one[0]==expected['pair_sha256'] and len(set(two))==1
          and two[0]==expected['common_six_arm_sha256'],'Independently exact paired and six-arm parity')
check(compiled==36 and receipt['status']=='PASS' and receipt['facility_calls']==receipt['selector_calls']==receipt['registered_research_trials']==0,'Development input-only completion')
assert OUT.is_dir()
payload=dict(status='PASS_FROZEN_PROTOCOL_SPEC_ONLY',base=BASE,design=DESIGN,candidate=PIN,
    checks=sum(checks.values()),check_groups=dict(sorted(checks.items())),
    findings=[],source_pins=len(lock['pins']),original_members=len(orig)+len(cor),
    prepared_development_inputs=compiled,held_inputs_materialized=0,nonce_file_reads=0,
    registered_research_trials=0,plant_calls=0,selector_calls=0,
    follow_through=[
      'Ticket32 must create and independently verify actual held inputs and evidence, without running them. Ticket33 must enforce the attempt ledger before every start.',
      'Ablation and robustness need accepted separate phase audits; the two-view team adapter requires an additive reviewed seam or explicitly amended frozen runtime.',
      'First divergent common public frame and at least two common admissible paid options must be established from actual originals before feeding arithmetic facts to the analyzer.',
      'ASCII-only canonical HMAC is identical for this pinned catalog; if future variant IDs become non-ASCII, align canonical ensure_ascii behavior with the frozen formula before a revision.'
    ])
with (OUT/'audit.json').open('x',encoding='utf-8',newline='\n') as f:
    json.dump(payload,f,ensure_ascii=False,indent=2)
    f.write('\n')
print(json.dumps(dict(status=payload['status'],checks=payload['checks'],pins=len(lock['pins']),archive_members=payload['original_members'],prepared=compiled)))
