from copy import deepcopy as cp
from fractions import Fraction
from hashlib import sha256
import json, math, os, pathlib, re, subprocess, sys
BASE=pathlib.Path(r'C:\Users\Donson\Documents\ChatGPT\Renly')
OUT=pathlib.Path(os.environ['TEMP'])/'aegisdc-review-M3-15-17-spec'
T=sys.argv[1]
ROOT=BASE/'.work'/'worktrees'/('full-site-'+T)
sys.path.insert(0,str(ROOT/'src'))
sys.dont_write_bytecode=True
checks=[]
def check(name,value):
 if not value: raise AssertionError(name)
 checks.append(name)
def refuse(name,func):
 try: func()
 except ValueError as err: checks.append(name); return str(err)
 raise AssertionError(name+' was accepted')
def read(path): return json.loads(pathlib.Path(path).read_text(encoding='utf-8'))
from aegis_dc.evidence_ledger import EvidenceLedger, RECORD_FIELDS
if T=='15':
 from aegis_dc.decision_view import DecisionGateway,decision_options,public_feasibility
 folder=ROOT/'configs/full-facility-decision-v1'
 nominal=read(folder/'public-nominal.json');plan=read(folder/'public-plan.json');ledger=read(folder/'common-ledger.json')
 plan['decision_times_s']=[math.nextafter(2,-math.inf),2,3,4]
 ledger['records']=[dict(id='review-independent-permit',source_id='declared-it-access-report',target_id='loc_it',observable_id='it-entry-permitted-reported',unit='1',value=False,observed_at_s=1,arrived_at_s=2,valid_until_s=3,quality=dict(status='unknown',error_bound=None,note='Unverified explicit negative permit claim.'),provenance=dict(origin_id='review-root',copied_from_record_id=None))]
 gateway=DecisionGateway(nominal,ledger,plan)
 frames=[gateway.next_frame() for _ in plan['decision_times_s']]
 choices=[decision_options(frame) for frame in frames]
 check('arrival-and-exclusive-expiry-affect-only-current-report',[row['legal_mask']['intent-it-check'] for row in choices]==[True,False,True,True])
 check('unknown-dynamics-retain-real-planning-option',all(row['legal_mask']['intent-filter-check'] and not row['legal_mask']['intent-unqualified-it-check'] for row in choices))
 check('positive-and-negative-planning-options-never-authorize-execution',all(row['execution_permission'] is False for row in choices))
 alarm=cp(nominal);alarm['reported_constraints'][0]['blocking_value']=True
 report=cp(ledger);report['records'][0]['value']=True
 alarm_gateway=DecisionGateway(alarm,report,plan)
 check('explicit-alarm-polarity-matches-permit-semantics',[decision_options(alarm_gateway.next_frame())['legal_mask'] for _ in frames]==[row['legal_mask'] for row in choices])
 for name,mutator in [('boolean-zero',lambda f:f['evidence']['records'][0].update(value=0)),('forged-current-set',lambda f:f['evidence'].update(current_record_ids=[])),('future-arrival',lambda f:f['evidence']['records'][0].update(arrived_at_s=math.nextafter(2,math.inf))),('private-field',lambda f:f.update(private_state={}))]:
  forged=cp(frames[1]);mutator(forged);refuse('reject-'+name,lambda:decision_options(forged))
 detached=DecisionGateway(nominal,ledger,plan);ledger['records'][0]['value']=True;nominal['reported_constraints'][0]['blocking_value']=True
 check('gateway-detaches-submitted-inputs',detached.next_frame()==frames[0])
 first=detached.next_frame();first['nominal_knowledge']['entities'][0]['domain']='arbitrary-mutation'
 check('released-frame-cannot-mutate-later-frame',detached.next_frame()==frames[2])
 traces={};private={};capture=ROOT/'evidence/mainline/engineering/15-truth/capture-01'
 for world in ('A','B'):
  manifest=read(capture/'audit/private-worlds'/world/'run.json')
  private[world]=dict(service=manifest['summary']['delivered_service_unit_s'],job=next(r['status'] for r in manifest['work_records'] if r['id']=='private-it-audit-job'),step=manifest['inputs']['maximum_step_s'])
  for stream in ('common','open','closed'):
   traces[world,stream]=read(capture/'audit/evaluator-traces'/world/stream/'private-decision-trace.json')
 check('saved-worlds-are-actually-distinct',abs(private['A']['service']-7)<1e-9 and private['B']['service']==0 and private['A']['job']=='working' and private['B']['job']=='rejected')
 check('saved-three-public-streams-ignore-hidden-world',all(traces['A',s]==traces['B',s] for s in ('common','open','closed')))
 check('saved-four-before-two-after-depend-on-arrival',traces['A','open']['steps'][:4]==traces['B','closed']['steps'][:4] and all(traces['A','open']['steps'][i]['options']!=traces['B','closed']['steps'][i]['options'] for i in (4,5)))
 check('full-V6-public-identities-and-directions',len(frames[0]['nominal_knowledge']['entities'])==45 and len(frames[0]['nominal_knowledge']['domain_ids'])==8 and len(frames[0]['nominal_knowledge']['graphs'])==4 and len(frames[0]['nominal_knowledge']['graphs']['access'])==5 and all(e['bidirectional'] for e in frames[0]['nominal_knowledge']['graphs']['access']))
 details=dict(hand_authored_frames=4,saved_private_worlds=private,saved_trace_streams=6,source='current tree bytes guarded against fixed endpoint')
elif T=='16':
 from aegis_dc.sensor_channels import sample_trace,public_model
 profile=read(ROOT/'configs/full-facility-sensor-channels-v1.json');realization=read(ROOT/'configs/full-facility-sensor-realization-private-v1.json')
 for m in profile['measurements']:m.update(period_s=2,phase_s=1,declared_dropout_probability=0)
 realization['biases']={k:0 for k in realization['biases']};realization['noise_bounds']={k:0 for k in realization['noise_bounds']};realization['dropout_probabilities']={k:0 for k in realization['dropout_probabilities']}
 def point(t,temp,flow,power,sampled,local):
  return dict(time_s=t,domains=dict(equipment_environment=dict(refrigerant=dict(temperature_K=temp)),facility_cooling=dict(lake_mass_flow_kg_s=flow),power=dict(rectifier_input_W=power),control_monitoring=dict(local_measurement=dict(temperature_K=local,sampled_at_s=sampled,temperature_valid=True)),undeclared_fault_label='PRIVATE_AND_IGNORED'))
 trace=dict(schema='aegisdc-observation-private-trace-v1',facility_id=profile['ledger']['facility_id'],entity_ids=profile['ledger']['entity_ids'],points=[point(0,301,0,0,0,299),point(4.75,310,4,100,4,302),point(7.25,315,5,200,4,302),point(8,316,5,200,4,302)])
 produced=sample_trace(profile,trace,realization);rows={r['id']:r for r in produced['ledger']['records']}
 check('coarse-trace-latest-before-poll-without-jump-interpolation',[rows['coolant-transfer:'+str(i)]['value'] for i in range(4)]==[301,301,310,310])
 check('polling-cached-fixed-reading-keeps-observed-time-and-origin',[(rows['coolant-transfer:'+str(i)]['observed_at_s'],rows['coolant-transfer:'+str(i)]['provenance']) for i in (0,1)][0]==[(rows['coolant-transfer:'+str(i)]['observed_at_s'],rows['coolant-transfer:'+str(i)]['provenance']) for i in (0,1)][1])
 check('cached-controller-retains-own-sample-coordinate',all(rows['controller-temperature-transfer:'+str(i)]['observed_at_s']==4 for i in (2,3)))
 check('explicit-zero-flow-power-survive',rows['flow-transfer:0']['value']==0 and rows['power-transfer:0']['value']==0)
 snap=lambda t:EvidenceLedger(produced['ledger']).snapshot(t)
 check('one-ulp-future-arrival-hidden','coolant-transfer:0' not in {r['id'] for r in snap(math.nextafter(3,-math.inf))['records']} and 'coolant-transfer:0' in snap(3)['current_record_ids'])
 check('cached-late-transfer-cannot-refresh-expiry',next(r for r in snap(5)['records'] if r['id']=='coolant-transfer:1')['availability']=='expired' and rows['coolant-transfer:1']['observed_at_s']==0 and rows['coolant-transfer:1']['valid_until_s']==4)
 changed=cp(realization);changed['biases']['coolant-calibration']=40;changed['noise_bounds']['coolant-probe']=0.25
 mismatch=sample_trace(profile,trace,changed);badrows={r['id']:r for r in mismatch['ledger']['records']}
 check('mismatched-private-calibration-does-not-relabel-public-quality',produced['public_model']==mismatch['public_model'] and all(rows[k]['quality']==badrows[k]['quality'] and rows[k]['provenance']==badrows[k]['provenance'] for k in rows))
 check('same-observation-key-retains-random-draw-across-transfer-polls',badrows['coolant-transfer:0']['value']==badrows['coolant-transfer:1']['value'] and badrows['coolant-transfer:2']['value']==badrows['coolant-transfer:3']['value'])
 check('threshold-and-raw-are-carried-as-correlated',rows['coolant-transfer:0']['provenance']==rows['coolant-alarm-transfer:0']['provenance'] and rows['coolant-alarm-transfer:0']['value'] is False and badrows['coolant-alarm-transfer:0']['value'] is True)
 dropped=cp(realization);dropped['dropout_probabilities']['coolant-probe']=1
 nulls=sample_trace(profile,trace,dropped)
 check('availability-failure-is-null-and-unknown',all(r['value'] is None and r['quality']['status']=='unknown' for r in nulls['ledger']['records'] if r['id'].startswith('coolant-')))
 future=cp(trace);future['points'][2]['domains']['equipment_environment']['refrigerant']['temperature_K']=349
 check('future-state-does-not-alter-earlier-measurements',sample_trace(profile,future,realization)['ledger']==produced['ledger'])
 collapsed=cp(profile)
 for m in collapsed['measurements']:m.update(enabled=m['id']=='coolant-probe',phase_s=2**53,period_s=0.5)
 very_late=cp(trace);very_late['points'][-1]['time_s']=2**53+2
 refuse('reject-collapsed-poll-coordinates',lambda:sample_trace(collapsed,very_late,realization))
 capture=ROOT/'evidence/mainline/engineering/16-sensors/capture-01';saved=read(capture/'cli-primary/production-private.json');savedbad=read(capture/'mismatch-production-private.json');full=read(capture/'full-check/summary.json');receipt=read(capture/'receipt.json');book=read(ROOT/'docs/mainline/16-sensor-delivery-addendum-v1.json')
 check('saved-production-and-primary-static-model-have-correct-size',len(saved['ledger']['records'])==1134 and len(saved['private_audit'])==652 and len(saved['public_model']['ledger']['entity_ids'])==45 and saved['public_model']['ledger']['records']==[])
 check('saved-primary-mismatch-model-identical',saved['public_model']==savedbad['public_model'])
 log=(capture/'full-check/tests.log').read_text(encoding='utf-8')
 signature=[dict(kind=k,test_id=i) for k,_,i in re.findall(r'^(ERROR|FAIL): (.+) \(([^)]+)\)$',log,re.MULTILINE)]
 check('failed-full-is-retained-with-specific-error-signature',receipt['engineering_capture']=='FAIL' and full['overall']=='FAIL' and full['tests']['failures']==1 and full['tests']['errors']==1 and signature==book['original_results'] and 'No module named aegis_dc' in log and receipt['missing_declared_artifacts']==['source-guard.json'])
 check('closure-is-exactly-two-CLI-tests-not-global-pass',read(ROOT/'evidence/mainline/engineering/16-sensors/environment-closure-01/receipt.json')['narrow_tests']==dict(run=2,failures=0,errors=0,skipped=0) and book['global_regression_gate'].startswith('PENDING_ROOT_'))
 details=dict(hand_authored_polls=16,hand_authored_transfers=len(rows),saved_records=len(saved['ledger']['records']),saved_polls=len(saved['private_audit']),original_full=full['tests'],original_full_remains='FAIL')
elif T=='17':
 from aegis_dc.nonfixed_evidence import NonfixedEvidenceProducer,NonfixedSession,SavedRunSignals
 profile=read(ROOT/'configs/full-facility-nonfixed-evidence-v1.json');plan=read(ROOT/'configs/full-facility-nonfixed-private-plan-v1.json')
 req=next(r for r in plan['completion_requests'] if r['model_id']=='coolant-numeric');token=cp(req['completion']);model=cp(next(r['model'] for r in profile['models'] if r['model']['id']=='coolant-numeric'))
 token['id']='review-independent-completion';token['arrival_latency_s']=1e-15
 absent=SavedRunSignals(OUT/'private-input-that-does-not-exist')
 producer=NonfixedEvidenceProducer(profile['registry'])
 for status in ('INCOMPLETE','ABORTED','REJECTED'):
  t=cp(token);t['status']=status
  check('no-private-IO-for-'+status,producer.publish_completion(t,model=model,private_signals=absent,realization=req['realization'],as_of_s=200) is None and absent._rows is None)
 for name,changes in [('unqualified',dict(qualification_declared=False)),('uncovered',dict(coverage=[]))]:
  t=dict(token,**changes);check('no-private-IO-for-'+name,producer.publish_completion(t,model=model,private_signals=absent,realization=req['realization'],as_of_s=200) is None and absent._rows is None)
 check('sub-ULP-positive-latency-does-not-arrive-at-completion',producer.publish_completion(token,model=model,private_signals=absent,realization=req['realization'],as_of_s=97.5) is None and absent._rows is None)
 invalid=dict(token,valid_until_s=97.5);refuse('expiry-refused-before-opening-private-source',lambda:producer.publish_completion(invalid,model=model,private_signals=absent,realization=req['realization'],as_of_s=200))
 detector_req=next(r for r in plan['completion_requests'] if r['model_id']=='threshold-miss');detector=next(r['model'] for r in profile['models'] if r['model']['id']=='threshold-miss')
 refuse('detector-realization-refused-before-opening-private-source',lambda:producer.publish_completion(detector_req['completion'],model=detector,private_signals=absent,realization=dict(seed=4,bias=1,noise_half_width=0),as_of_s=200))
 unknown=next(r['model'] for r in profile['models'] if r['model']['id']=='coolant-indeterminate')
 indeterminate=producer.publish_completion(token,model=unknown,private_signals=absent,realization=None,as_of_s=200)
 check('indeterminate-is-null-without-private-source',indeterminate['value'] is None and indeterminate['quality']['status']=='unknown' and absent._rows is None)
 saved_path=ROOT/'evidence/mainline/engineering/13-replay/capture-04/combined-episode-CLI/trajectory';signal=SavedRunSignals(saved_path)
 record=producer.publish_completion(token,model=model,private_signals=signal,realization=dict(seed=37,bias=0,noise_half_width=0),as_of_s=math.nextafter(97.5,math.inf))
 states={r['time_s']:r for r in [json.loads(line) for line in (saved_path/'private-state.jsonl').read_text(encoding='utf-8').splitlines()]}
 temp=lambda t:states[t]['domains']['equipment_environment']['refrigerant']['temperature_K']
 check('completion-samples-exact-saved-point-of-changing-interval',record['value']==temp(97.5) and record['value']!=temp(65.5) and record['value']!=temp(98) and record['observed_at_s']==97.5 and record['arrived_at_s']==math.nextafter(97.5,math.inf))
 noisy=dict(seed=37,bias=0.25,noise_half_width=0.5)
 a=producer.publish_completion(token,model=model,private_signals=signal,realization=noisy,as_of_s=100)
 b=producer.publish_completion(token,model=model,private_signals=signal,realization=noisy,as_of_s=200)
 check('query-count-and-query-time-do-not-redraw-or-refresh',a==b)
 mismatch=producer.publish_completion(token,model=model,private_signals=signal,realization=dict(noisy,bias=50),as_of_s=200)
 check('private-bias-does-not-change-quality-id-or-provenance',a['value']!=mismatch['value'] and all(a[k]==mismatch[k] for k in ('quality','id','provenance','observed_at_s','arrived_at_s')))
 missing=dict(token,completed_at_s=97.6)
 refuse('nonexistent-completion-coordinate-refuses-instead-of-forward-peek',lambda:producer.publish_completion(missing,model=model,private_signals=signal,realization=req['realization'],as_of_s=200))
 bypass=dict(schema='aegisdc-nonfixed-plan-v1',reported_records=[],external_records=[record],completion_requests=[])
 refuse('upstream-handheld-record-cannot-bypass-completion',lambda:NonfixedSession(profile,bypass,private_signals=signal))
 capture=ROOT/'evidence/mainline/engineering/17-nonfixed/capture-01';saved=read(capture/'snapshots.json')
 history=next(r for r in saved['late-history']['records'] if r['id']=='late-history')
 check('saved-history-retains-stale-negative',history['value'] is False and history['age_s']==30 and history['availability']=='expired')
 check('saved-copy-root-remains-opaque-before-alarm-arrival','alarm-later' not in {r['id'] for r in saved['copy-first']['records']} and saved['copy-first']['provenance_issues']==[] and any(g['kind']=='reported_origin' and g['record_ids']==['alarm-later','copy-first'] for g in saved['arrived']['correlation_groups']))
 public=json.dumps(saved)+json.dumps(read(capture/'public-models.json'))
 check('saved-dispatch-does-not-contain-private-audit-fields',all(k not in public for k in ('private_source','private_draw','private_realization','run_sha256','source_tree_sha256','authorized_raw_signal')))
 witness=read(capture/'private-source-witness.json')
 check('historical-physical-source-retains-one-second-qualification',witness['historical_maximum_step_s']==1.0 and witness['new_physics_execution'] is False)
 details=dict(saved_actual_samples={str(t):temp(t) for t in (65.5,97.5,98)},new_arrival_probe=record['arrived_at_s'],real_professional_execution_connected=False,historical_physical_step_s=1.0)
else: raise ValueError(T)
result=dict(schema='aegisdc-independent-spec-probes-v1',ticket=T,status='PASS',checks=checks,check_count=len(checks),details=details,physical_runs=0,full_regressions=0,author_targets_rerun=0,registered_research_trials=0,model_calls=0,training_calls=0)
(OUT/('probe-'+T+'.json')).write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
print(json.dumps({k:result[k] for k in ('ticket','status','check_count','details')},ensure_ascii=False))
