"""Read-only 11-leaf format closure, without restarting the source review."""
from pathlib import Path
import hashlib
import json
import re
import subprocess

ROOT = Path('C:/Users/Donson/Documents/ChatGPT/Renly')
OUT = Path(__file__).resolve().parent
BASE = '56bcfe23af09c54f2e5927fe21cf87fdd17e8820'
FINAL = '777ee58541a4cb2be2ff200de2ac135c6f13affe'
M15 = 'bbe38115bf12cef357d3475372d8f5f7ae2db44c'
M16 = '076e3de6683f68b5a35666ac6c5d1003843719bc'
M17 = 'fcf8cad8d722323fe242bfea7f0d256ef1bbc0b9'
D17 = '83617cd19bdd1be9564cc9e94ef803f6f892ef4e'
PREFIX = 'evidence/mainline/engineering/'
ATTR = PREFIX + '.gitattributes'
metadata = [
    ('15-truth/DELIVERY.md', M15),
    ('15-truth/delivery-9cef63f3-existing-proof-observation-01.json', M15),
    ('17-nonfixed/DELIVERY.md', M17),
    ('17-nonfixed/delivery-readback-01/verify.stdout.raw', M17),
]
early = ['01-history-red','02-history-green','03-completion-gate-red','04-completion-gate-green','05-dynamic-completion-red','06-dynamic-completion-green','07-history-manual-copy-compat']
leaves = metadata + [('17-nonfixed/development/' + name + '/stderr.raw', M17) for name in early]
expected_whitespace = 'blank-at-eol,blank-at-eof,space-before-tab,cr-at-eol'

def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

observed_head = git('rev-parse', 'HEAD').decode().strip()
assert observed_head == FINAL
parent = git('rev-parse', FINAL + '^').decode().strip()
mutation = git('diff', '--name-status', parent + '..' + FINAL).decode().splitlines()
assert mutation == ['A\t' + ATTR]
rules = [line for line in (ROOT / ATTR).read_text(encoding='utf-8').splitlines() if line and not line.startswith('#')]
assert rules == [name + ' -text whitespace=' + expected_whitespace for name, _ in leaves]
assert len(rules) == len(set(rules)) == 11
receipt = json.loads((ROOT / (PREFIX + '17-nonfixed/capture-01/receipt.json')).read_text(encoding='utf-8'))
rows = []
for relative, author_ref in leaves:
    name = PREFIX + relative
    raw = (ROOT / name).read_bytes()
    reference = git('show', author_ref + ':' + name)
    assert raw == reference == git('show', parent + ':' + name) == git('show', FINAL + ':' + name)
    assert b'\r\n' in raw and raw.replace(b'\r\n', b'').count(b'\r') == 0 and raw.replace(b'\r\n', b'').count(b'\n') == 0
    assert not any(line.endswith((b' ', b'\t')) for line in raw.splitlines())
    attrs = git('check-attr', '-z', 'text', 'whitespace', '--', name).decode().split('\0')
    effective = {attrs[index+1]: attrs[index+2] for index in range(0, len(attrs)-1, 3)}
    assert effective == {'text': 'unset', 'whitespace': expected_whitespace}
    pinned = None
    if '/development/' in name:
        pinned = receipt['frozen_inputs'][name]
        assert pinned == sha(raw) == sha(git('show', D17 + ':' + name))
    rows.append(dict(path=name, author_ref=author_ref, raw_sha256=sha(raw), raw_bytes=len(raw), raw_equals_author_parent_and_final=True, pure_CRLF=True, no_trailing_space_tab=True, effective_attributes=effective, original_receipt_pin=pinned))
frozen_attrs = [('.gitattributes',BASE),('configs/full-facility-decision-v1/.gitattributes',M15),(PREFIX+'15-truth/.gitattributes',M15),(PREFIX+'16-sensors/.gitattributes',M16),(PREFIX+'17-nonfixed/.gitattributes',M17)]
frozen = []
for name, revision in frozen_attrs:
    raw = (ROOT / name).read_bytes()
    assert raw == git('show', revision + ':' + name) == git('show', FINAL + ':' + name)
    frozen.append(dict(path=name, original_ref=revision, sha256=sha(raw), unchanged=True))
log = ROOT / '.work/M3-integrated-default-style-before-01.log'
prior = log.read_bytes()
prior_paths = sorted(set(re.findall(r'^(.+?):\d+: trailing whitespace\.$', prior.decode('utf-8'), re.MULTILINE)))
assert prior_paths == sorted(PREFIX + name for name, _ in leaves)
command = ['git','diff','--check',BASE,FINAL]
checked = subprocess.run(command, cwd=ROOT, capture_output=True)
(OUT / 'native-classification-default-check.stdout.raw').write_bytes(checked.stdout)
(OUT / 'native-classification-default-check.stderr.raw').write_bytes(checked.stderr)
assert checked.returncode == 0 and checked.stdout == checked.stderr == b''
assert git('rev-parse','HEAD').decode().strip() == observed_head
result = dict(schema='aegisdc-independent-native-classification-closure-v1', status='PASS', source_review_unchanged=True, source_findings={'15':0,'16':0,'17':0}, root_format_finding=dict(original=1,closed=1,open=0), root_commit=FINAL, only_commit_mutation=mutation, exact_rules=len(rules), leaves=rows, frozen_attribute_checks=frozen, original_failed_check_log=dict(path=str(log),sha256=sha(prior),bytes=len(prior),distinct_paths=len(prior_paths),retained=True), default_diff_check=dict(argv=command,exit_code=checked.returncode,stdout_bytes=len(checked.stdout),stderr_bytes=len(checked.stderr)), root_status=git('status','--porcelain').decode().splitlines(), physics_runs=0,full_regression_runs=0,target_test_runs=0,model_calls=0)
(OUT / 'independent-native-classification-closure.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({key:result[key] for key in ('status','root_commit','exact_rules','source_findings','root_format_finding','default_diff_check','root_status','physics_runs','full_regression_runs','target_test_runs','model_calls')},ensure_ascii=False,indent=2))
