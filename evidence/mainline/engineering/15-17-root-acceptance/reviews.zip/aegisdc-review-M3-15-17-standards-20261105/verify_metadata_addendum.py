"""Finite metadata-only addendum; immutable source review is not restarted."""
from pathlib import Path
import hashlib
import json
import subprocess

ROOT = Path('C:/Users/Donson/Documents/ChatGPT/Renly')
OUT = Path(__file__).resolve().parent
PAIRS = {
    15: ('9cef63f3a72ebfc1196a3bd4a3509e54266dbd4c', 'bbe38115bf12cef357d3475372d8f5f7ae2db44c', '15-truth'),
    16: ('d032d2a7d88ec19d46f69a8ed6085512b6b1138f', '076e3de6683f68b5a35666ac6c5d1003843719bc', '16-sensors'),
    17: ('83617cd19bdd1be9564cc9e94ef803f6f892ef4e', 'fcf8cad8d722323fe242bfea7f0d256ef1bbc0b9', '17-nonfixed'),
}

def run(tree, *args):
    child = subprocess.run(['git', *args], cwd=tree, capture_output=True)
    return dict(argv=['git', *args], exit_code=child.returncode, stdout=child.stdout.decode('utf-8'), stderr=child.stderr.decode('utf-8'))

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def read(path):
    return json.loads(path.read_text(encoding='utf-8'))

results = []
for ticket, (data, metadata, label) in PAIRS.items():
    tree = ROOT / f'.work/worktrees/full-site-{ticket}'
    changed = run(tree, 'diff', data + '..' + metadata, '--name-status')['stdout'].splitlines()
    paths = [line.split('\t')[-1] for line in changed]
    checks = []
    for name in paths:
        blob = subprocess.check_output(['git', 'show', metadata + ':' + name], cwd=tree)
        checks.append(dict(path=name, raw_sha256=sha((tree / name).read_bytes()), committed_sha256=sha(blob), exact=(tree / name).read_bytes() == blob))
    evidence = tree / 'evidence/mainline/engineering' / label
    manifest_checks = []
    if ticket in (16, 17):
        directory = evidence / 'delivery-readback-01'
        manifest = read(directory / 'manifest.json')
        for name, expected in manifest['artifacts'].items():
            manifest_checks.append(dict(path='delivery-readback-01/' + name, expected=expected, actual=sha((directory / name).read_bytes()), exact=sha((directory / name).read_bytes()) == expected))
    else:
        observation = read(evidence / 'delivery-9cef63f3-existing-proof-observation-01.json')
        proof = sha((evidence / 'delivery-9cef63f3-fresh-cli-01.json').read_bytes())
        manifest_checks.append(dict(path='delivery-9cef63f3-fresh-cli-01.json', expected=observation['proof_sha256'], actual=proof, exact=proof == observation['proof_sha256']))
    candidate = read(tree / f'docs/mainline/evidence/{ticket}.json')
    results.append(dict(ticket=ticket, fixed_data=data, metadata_commit=metadata, changed=changed, metadata_bytes=checks, metadata_hash_checks=manifest_checks, default_diff_check=run(tree, 'diff', '--check', data + '..' + metadata), native_terminal_diff_check=run(tree, '-c', 'core.whitespace=blank-at-eol,blank-at-eof,space-before-tab,cr-at-eol', 'diff', '--check', data + '..' + metadata), author_status=run(tree, 'status', '--porcelain'), candidate_status=candidate['status'], lifecycle=candidate['ticket_lifecycle'], M3_acceptance=candidate['M3_acceptance'], global_regression_gate=candidate['global_regression_gate'], root_acceptance=candidate.get('root_independent_acceptance', candidate.get('independent_root_reviews')), checks_pass=all(row['exact'] for row in checks + manifest_checks)))
(OUT / 'metadata-addendum-checks.json').write_text(json.dumps(results, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps([{key: row[key] for key in ('ticket', 'metadata_commit', 'checks_pass', 'candidate_status')} | dict(metadata_files=len(row['metadata_bytes']), default_diff_check_exit=row['default_diff_check']['exit_code'], native_terminal_diff_check_exit=row['native_terminal_diff_check']['exit_code'], clean=not row['author_status']['stdout'].strip()) for row in results], ensure_ascii=False, indent=2))
raise SystemExit(0 if all(row['checks_pass'] and row['native_terminal_diff_check']['exit_code'] == 0 for row in results) else 1)
