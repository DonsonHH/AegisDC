"""Read-only Standards audit: fixed delivery blobs, original receipts and source pins."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys

ROOT = Path('C:/Users/Donson/Documents/ChatGPT/Renly')
OUT = Path(__file__).resolve().parent
BASE = '56bcfe23af09c54f2e5927fe21cf87fdd17e8820'
TIPS = {15: '9cef63f3a72ebfc1196a3bd4a3509e54266dbd4c', 16: 'd032d2a7d88ec19d46f69a8ed6085512b6b1138f', 17: '83617cd19bdd1be9564cc9e94ef803f6f892ef4e'}
CAPTURES = {15: '15-truth', 16: '16-sensors', 17: '17-nonfixed'}

def sha(path):
    value = hashlib.sha256()
    with path.open('rb') as source:
        for part in iter(lambda: source.read(1024 * 1024), b''):
            value.update(part)
    return value.hexdigest()

def git(tree, *args):
    return subprocess.check_output(['git', *args], cwd=tree).decode('utf-8').strip()

class BlobReader:
    def __init__(self, tree):
        self.child = subprocess.Popen(['git', 'cat-file', '--batch'], cwd=tree, stdin=subprocess.PIPE, stdout=subprocess.PIPE)
    def sha(self, revision, name):
        self.child.stdin.write((revision + ':' + name + '\n').encode('utf-8'))
        self.child.stdin.flush()
        header = self.child.stdout.readline().decode('utf-8').strip().split()
        if len(header) != 3 or header[1] != 'blob':
            raise ValueError('Missing delivery blob: ' + revision + ':' + name)
        remaining = int(header[2])
        value = hashlib.sha256()
        while remaining:
            part = self.child.stdout.read(min(remaining, 1024 * 1024))
            if not part:
                raise ValueError('Truncated Git blob')
            remaining -= len(part)
            value.update(part)
        if self.child.stdout.read(1) != b'\n':
            raise ValueError('Invalid Git batch framing')
        return value.hexdigest()
    def close(self):
        self.child.stdin.close()
        self.child.wait()

def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))

def audit_ticket(number, tip):
    tree = ROOT / f'.work/worktrees/full-site-{number}'
    capture_rel = f'evidence/mainline/engineering/{CAPTURES[number]}/capture-01'
    directory = tree / capture_rel
    receipt = read(directory / 'receipt.json')
    declaration = read(directory / 'declaration.json')
    execution = receipt['execution_commit']
    blobs = BlobReader(tree)
    mismatches = []
    source_counts = {}
    def compare(label, actual, expected):
        if actual != expected:
            mismatches.append(dict(label=label, actual=actual, expected=expected))
    compare('original receipt delivery bytes', sha(directory / 'receipt.json'), blobs.sha(tip, capture_rel + '/receipt.json'))
    declared = set(declaration['declared_artifacts'])
    missing = set(receipt['missing_declared_artifacts'])
    compare('declared-minus-missing roles', sorted(receipt['artifacts']), sorted(declared - missing))
    actual_durable = {p.relative_to(directory).as_posix() for p in directory.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix.lower() not in {'.pyc', '.pyo'}}
    compare('actual durable roles', sorted(actual_durable), sorted(set(receipt['artifacts']) | {'receipt.json'}))
    for name, expected in receipt['artifacts'].items():
        compare('artifact actual:' + name, sha(directory / name), expected)
        compare('artifact delivery:' + name, blobs.sha(tip, capture_rel + '/' + name), expected)
    for group in ('runtime_sources', 'authoring_verification_tools', 'frozen_inputs'):
        source_counts[group] = len(receipt[group])
        compare('declaration pin set:' + group, sorted(declaration['pinned_paths'][group]), sorted(receipt[group]))
        for name, expected in receipt[group].items():
            compare('pin actual:' + name, sha(tree / name), expected)
            compare('pin execution:' + name, blobs.sha(execution, name), expected)
            compare('pin delivery:' + name, blobs.sha(tip, name), expected)
    changed_evidence = [name for name in git(tree, 'diff', BASE + '...' + tip, '--name-only', '--', 'evidence').splitlines() if name]
    original_guard = []
    for name in changed_evidence:
        actual = sha(tree / name)
        expected = blobs.sha(tip, name)
        compare('fixed evidence actual:' + name, actual, expected)
        original_guard.append(dict(ticket=number, path=name, sha256=actual, fixed_git_sha256=expected))
    closure = None
    if number == 16:
        closure_rel = 'evidence/mainline/engineering/16-sensors/environment-closure-01'
        closed = read(tree / closure_rel / 'receipt.json')
        closure = {key: closed[key] for key in ('status', 'execution_commit', 'narrow_tests', 'original_capture_status', 'original_full_regression_remains', 'global_regression_gate')}
        compare('closure terminal bytes', sha(tree / closure_rel / 'receipt.json'), blobs.sha(tip, closure_rel + '/receipt.json'))
        for name, expected in closed['artifacts'].items():
            compare('closure artifact actual:' + name, sha(tree / closure_rel / name), expected)
            compare('closure artifact delivery:' + name, blobs.sha(tip, closure_rel + '/' + name), expected)
        for name, expected in closed['new_verification_tools'].items():
            compare('closure tool actual:' + name, sha(tree / name), expected)
            compare('closure tool execution:' + name, blobs.sha(closed['execution_commit'], name), expected)
            compare('closure tool delivery:' + name, blobs.sha(tip, name), expected)
    blobs.close()
    summary = dict(ticket=number, fixed_tip=tip, execution_commit=execution, engineering_capture=receipt['engineering_capture'], delivery_gate=receipt['delivery_gate'], original_artifact_count=len(receipt['artifacts']), source_pin_counts=source_counts, original_missing_declared=sorted(missing), full_tests=receipt['full_tests'], closure=closure, fixed_evidence_guard_count=len(original_guard), mismatches=mismatches, physics_runs=0, full_regression_runs=0, target_test_runs=0)
    return summary, original_guard

summaries, guard = [], []
for number, tip in TIPS.items():
    summary, ticket_guard = audit_ticket(number, tip)
    summaries.append(summary)
    guard.extend(ticket_guard)
(OUT / 'independent-original-byte-audit.json').write_text(json.dumps(summaries, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
(OUT / 'original-evidence-byte-guard-before.json').write_text(json.dumps(guard, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps(summaries, ensure_ascii=False, indent=2))
raise SystemExit(1 if any(item['mismatches'] for item in summaries) else 0)
