"""Compare only the previously observed files; metadata HEAD is a separate epoch."""
from pathlib import Path
import hashlib
import json
import subprocess

ROOT = Path('C:/Users/Donson/Documents/ChatGPT/Renly')
OUT = Path(__file__).resolve().parent

def read(name):
    return json.loads((OUT / name).read_text(encoding='utf-8-sig'))

def sha(path):
    value = hashlib.sha256()
    with path.open('rb') as source:
        for part in iter(lambda: source.read(1024 * 1024), b''):
            value.update(part)
    return value.hexdigest()

def git(tree, *args):
    return subprocess.check_output(['git', *args], cwd=tree).decode('utf-8').strip()

protected = read('source-byte-guard-before.json')
originals = read('original-evidence-byte-guard-before.json')
result = dict(schema='aegisdc-standards-fixed-review-byte-guard-v1', source_files=len(protected), original_evidence_files=len(originals), unchanged=True, mismatches=[], metadata_epochs=[], physics_runs=0, full_regression_runs=0, target_test_runs=0)
for group, entries in [('source_test_tool_config', protected), ('original_evidence', originals)]:
    for item in entries:
        actual = sha(ROOT / f'.work/worktrees/full-site-{item["ticket"]}' / item['path'])
        if actual != item['sha256']:
            result['mismatches'].append(dict(group=group, ticket=item['ticket'], path=item['path'], before=item['sha256'], after=actual))
result['unchanged'] = not result['mismatches']
for fixed in read('fixed-git-index.json'):
    tree = ROOT / f'.work/worktrees/full-site-{fixed["ticket"]}'
    head = git(tree, 'rev-parse', 'HEAD')
    result['metadata_epochs'].append(dict(ticket=fixed['ticket'], fixed_source_data_tip=fixed['tip'], observed_head=head, commits_since_fixed=git(tree, 'log', fixed['tip'] + '..' + head, '--oneline').splitlines(), changed_since_fixed=git(tree, 'diff', fixed['tip'] + '..' + head, '--name-status').splitlines(), protected_path_changes_since_fixed=git(tree, 'diff', fixed['tip'] + '..' + head, '--name-status', '--', 'src', 'tests', 'scripts', 'configs').splitlines(), status=git(tree, 'status', '--porcelain').splitlines()))
result['root_head'] = git(ROOT, 'rev-parse', 'HEAD')
result['root_status'] = git(ROOT, 'status', '--porcelain').splitlines()
(OUT / 'source-and-original-byte-guard-after.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps(result, ensure_ascii=False, indent=2))
raise SystemExit(0 if result['unchanged'] else 1)
