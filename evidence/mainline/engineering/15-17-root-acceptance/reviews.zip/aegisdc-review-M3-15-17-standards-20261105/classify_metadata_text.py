"""Exact correction for three ordinary candidate indexes, retaining the initial refusal."""
from pathlib import Path
import hashlib
import json
import re
import subprocess

ROOT = Path('C:/Users/Donson/Documents/ChatGPT/Renly')
OUT = Path(__file__).resolve().parent
original = json.loads((OUT / 'metadata-addendum-checks.json').read_text(encoding='utf-8'))
correction = dict(schema='aegisdc-standards-metadata-classification-correction-v1', original_result_retained='metadata-addendum-checks.json', original_checker_retained='verify_metadata_addendum.py', reason='Initial reviewer check imposed raw Git equality on every new metadata file. The three candidate-index JSON documents are ordinary non-pinned Git text; durable proof/manifest/raw bytes still require exact equality.', exact_classified_paths=[f'docs/mainline/evidence/{n}.json' for n in (15, 16, 17)], tickets=[], physics_runs=0, full_regression_runs=0, target_test_runs=0)
for row in original:
    ticket = row['ticket']
    tree = ROOT / f'.work/worktrees/full-site-{ticket}'
    metadata = row['metadata_commit']
    mismatches = [item for item in row['metadata_bytes'] if not item['exact']]
    expected_path = f'docs/mainline/evidence/{ticket}.json'
    if [item['path'] for item in mismatches] != [expected_path]:
        raise ValueError('Unexpected metadata byte mismatch; do not broadly exempt it')
    raw = (tree / expected_path).read_bytes()
    blob = subprocess.check_output(['git', 'show', metadata + ':' + expected_path], cwd=tree)
    filtered = subprocess.check_output(['git', 'hash-object', '--path=' + expected_path, expected_path], cwd=tree).decode().strip()
    committed = subprocess.check_output(['git', 'rev-parse', metadata + ':' + expected_path], cwd=tree).decode().strip()
    newline_only = raw != blob and raw.replace(b'\r\n', b'\n') == blob
    if not newline_only or filtered != committed:
        raise ValueError('Ordinary text mismatch is not explained by the exact newline/clean-filter classification')
    source_receipt = tree / 'evidence/mainline/engineering' / {15:'15-truth',16:'16-sensors',17:'17-nonfixed'}[ticket] / 'capture-01/receipt.json'
    pinned = json.loads(source_receipt.read_text(encoding='utf-8'))
    if any(expected_path in pinned[group] for group in ('runtime_sources','authoring_verification_tools','frozen_inputs')):
        raise ValueError('Candidate index unexpectedly belongs to an immutable original pin set')
    whitespace_paths = sorted(set(re.findall(r'^(.+?):\d+: trailing whitespace\.$', row['default_diff_check']['stdout'], re.MULTILINE)))
    correction['tickets'].append(dict(ticket=ticket, metadata_commit=metadata, classified_text_path=expected_path, raw_sha256=hashlib.sha256(raw).hexdigest(), git_blob_sha256=hashlib.sha256(blob).hexdigest(), only_CRLF_LF_difference=newline_only, clean_filtered_git_blob=filtered, committed_git_blob=committed, not_original_receipt_pinned=True, exact_other_metadata_paths=sum(item['exact'] for item in row['metadata_bytes']), exact_manifest_hash_checks=len(row['metadata_hash_checks']), all_manifest_hash_checks_pass=all(item['exact'] for item in row['metadata_hash_checks']), native_terminal_whitespace_exit=row['native_terminal_diff_check']['exit_code'], remaining_default_whitespace_exact_leaf_paths=whitespace_paths, pending_root_rule='Add cr-at-eol only for these new metadata leaves using new evidence/mainline/engineering/.gitattributes; retain existing frozen attributes and raw bytes.'))
correction['status'] = 'PASS_EXACT_METADATA_TEXT_CLASSIFICATION_WITH_RAW_MANIFESTS_UNCHANGED'
(OUT / 'metadata-addendum-classification-correction.json').write_text(json.dumps(correction, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps(correction, ensure_ascii=False, indent=2))
