# M3 tickets 15–17 independent Spec review

Reviewer: `/root/m3_review_spec`. Read-only review; the authoring/delivery agent is separate. Scope is Spec only under `code-review/SKILL.md`; the Standards axis remains independent. No integration, ticket resolution, M3 acceptance or goal-completion claim is made.

## Fixed comparison and authority

Baseline: `56bcfe23af09c54f2e5927fe21cf87fdd17e8820`. Commands for each fixed endpoint are `git diff BASE...TIP` and `git log BASE..TIP --oneline`; the exact commands, nonempty path lists and commit lists are in `fixed-git-review-manifest.json`.

| Ticket | Fixed endpoint | Recorded observation execution | Diff files |
|---|---|---|---:|
|15|`9cef63f3a72ebfc1196a3bd4a3509e54266dbd4c`|`ba9bf5be7fe4fb57dacaca48f1163ff0f4eb1c6c`|98|
|16|`d032d2a7d88ec19d46f69a8ed6085512b6b1138f`|`842093460248167c0b8e4d9e37e74aebc9da034a`|86|
|17|`83617cd19bdd1be9564cc9e94ef803f6f892ef4e`|`6b76088de3e83efd8b157ff4dd86e6052f29064f`|184|

Read AGENTS, MAINLINE, progress/current tickets, GLOSSARY, ADR 0002/0003, issue/domain consumer rules, complete-facility spec, information boundary, ticket contracts, changed runtime/configuration/test and capture/verification code. Live agent/worktree inventory confirmed the reviewer did not duplicate an active implementation. The complete eight-domain synthetic V6 objective, sparse fixed coverage and explicit source/modeling assumptions remain intact. Root conformance readbacks and prior reviews informed scope only; the checks below were independently authored.

## Ticket 15 Spec — 0 findings

(a) No missing/partial requirement found within ticket 15. The ticket requires “调度API只收到允许的静态知识与证据” (issue 15:11) and equal inputs/actions for equal available records (issue 15:3,19; spec:27,74). `decision_view.py:191–227,271–319` admits detached current frames, rebuilds ticket-14 derived metadata and never accepts a world, trajectory, full queue or arbitrary evaluator query time. Nominal knowledge retains 45 identities, eight domains, four graphs and five bidirectional access edges.

(b) No scope creep found. Contract:25–32 explicitly defines planning eligibility and keeps actual safety private; `execution_permission=False` does not collapse the meaningful planning mask. The demo selects a declared intention and does not execute work or claim benefit (contract:41–55).

(c) No apparently implemented but incorrect requirement found. Explicit `blocking_value` matches contract:34–39; unknown-quality reports remain reports. Four new hand-authored frames test exact arrival, exclusive expiry, both permit/alarm polarities, mutation isolation and forged future/derived/boolean-zero fields. Independent saved-data checks confirm actual distinct A/B service and safety outcomes, identical three-stream public traces, and four equal pre-arrival/two differing post-arrival frames. `probe-15.json`: 14 assertions PASS.

## Ticket 16 Spec — 0 findings

(a) No missing/partial implementation requirement found. Issue 16:11–13 requires a non-truth coverage mask, independent measurement errors and a nonfixed fallback. Contract:9–20 confines output to a static empty-record registry plus arrived snapshots; `sensor_channels.py:89–159,308–383` keeps private realizations/diagnostics separate. Coverage remains sparse rather than an all-asset health array.

(b) No scope creep found. This adapter reads an old saved physical trajectory, changes information only and implements neither repair nor risk/AI dispatch (contract:3–7,65–76).

(c) No incorrect implementation found. New coarse-trace fixtures independently establish latest-at-or-before selection across jumps, controller-owned time, cache age/origin/noise preservation, exact future-arrival/expiry gates, zero/null/False distinctions, shared raw/threshold roots, independently changed private bias and rejection of genuinely collapsed fractional clocks (contract:22–63). `probe-16.json`: 16 assertions PASS; saved capture retains 1,134 records/652 polls.

Acceptance limit remains explicit: the original 390/388 full result is FAIL with one failure, one error and two optional skips, and its sole missing `source-guard.json` remains missing. Addendum:4–24 and verifier:22–61,103–145 bind exact original receipt hash, error signatures, declared missing role and two-test CLI environment closure. This is not a global pass; root integrated full remains pending. The earlier polling-loop finding remains historically retained and closed, not erased.

## Ticket 17 Spec — 0 findings

(a) No missing/partial implementation requirement found within the declared producer seam. Issue 17:11–13 requires negative/normal/uncertain coverage, completion-time availability and common handling of stale/copied records. Contract:7–13,23–25 declares typed fixture completion preparation for 21/22; actual travel/qualification/tool execution and repair remain later tickets. The fixed scenario and saved physical trajectory are unchanged.

(b) No scope creep found. Declared human/history/work-order claims and whitelist measurements change information; the new session/CLI does not attest M1 work as professional completion or introduce repair.

(c) No incorrect implementation found. `nonfixed_evidence.py:62–110,266–323,359–415` validates completion/coverage/arrival and numeric/binary realization before private I/O; the exact saved sampler refuses unavailable coordinates. Independent checks use a nonexistent private directory for incomplete/aborted/rejected/unqualified/uncovered, expiry and detector-invalid paths. A sub-ULP latency probe samples actual 97.5 state only after `97.50000000000001`, rather than 65.5 or 98 state; repeated queries retain the same draw/time/quality. Private calibration changes do not relabel quality, IDs or provenance; upstream handheld bypass is rejected. Saved stale history, copy-first/future-alarm provenance and private-field absence were read independently. `probe-17.json`: 18 assertions PASS.

The historical physical carrier remains a 1-second run, explicitly not a new .01 qualification. No present claim establishes professional execution, physical recovery or mechanism benefit.

## Actual checks and artifact guard

48 independent assertions passed (15:14, 16:16, 17:18). The sole earlier review-harness failure is retained in `probe-execution-01.json`: an integral period at 2**53 was incorrectly expected to round, despite the documented arbitrary-precision integral-coordinate rule. The original probe source is preserved; `independent-probes-02.py` changes only that witness to a genuinely fractional period. Ticket 16 then passes. This was not a source failure or author rerun.

`core-before.json` / `core-after.json` protect actual working bytes of 209/206/204 tracked source/script/config/test paths. All bytes remained unchanged; every changed-ticket path matches its fixed endpoint blob. Runtime/tool/input sets match original capture hashes. Thirteen inherited old JSON files per tree differ from blobs solely by exact CRLF checkout bytes, unchanged since baseline; this exact classification is recorded, not a blanket ignored hash mismatch. Source/appended-document HEAD identity is recorded separately.

New physical executions: 0. Full regressions: 0. Author target reruns: 0. Registered research/model/training calls: 0. Reviewer writes were confined to this Temp report and its attachments. Finalizer metadata/index/proof appends were separately read and checked at the final refs below; no core probe was repeated.

Spec finding counts: 15 = 0; 16 = 0; 17 = 0. No worst Spec issue. M3 and the complete research goal remain active; 18, real execution and independent effect/AI gates are not accepted by this review.

## Final metadata delta readback — PASS, 0 additional findings

| Ticket | Final metadata ref | Changed metadata paths | Original execution source/tool blobs checked | New local Markdown links checked |
|---|---|---:|---:|---:|
|15|`bbe38115bf12cef357d3475372d8f5f7ae2db44c`|5|174|5|
|16|`076e3de6683f68b5a35666ac6c5d1003843719bc`|8|173|12|
|17|`fcf8cad8d722323fe242bfea7f0d256ef1bbc0b9`|11|179|5|

All three author trees were clean at these exact final refs. No runtime, tool, config or test path changed from the fixed core endpoints, and all 209/206/204 actual core bytes still match the review's initial maps. Original execution source/tool hashes were independently checked against raw Git blobs as well as current files. Candidate statuses preserve claimed/pending root acceptance and the integrated correct-environment/Torch gate. New relative links and named artifact pointers resolve.

15 accurately separates the existing PASS proof from its newly observed presence/clean checkout; its original actual verifier argv remains unavailable, and its reproduction template is expressly unexecuted. 16 readback manifest hashes and proof keep the failed full capture and narrow two-test closure distinct. 17 readback manifest hashes, actual argv/environment, exit zero, exact proof stdout, empty stderr and clean before/after statements agree; its historical 1-second physical carrier and unconnected professional executor remain explicit. All three retain the earlier app-worktree request as outcome unknown rather than inferring success or cancellation.

See `final-metadata-delta.json`. No new probe, full regression or physical run accompanied this metadata check. Root progress was re-read and remains active/M3 in progress/current ticket 15. Final Spec counts remain **15:0, 16:0, 17:0**, with no actionable Spec finding. Integration and milestone acceptance are root responsibilities.
