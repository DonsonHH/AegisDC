# Independent Standards review: M3 tickets 15, 16 and 17

Reviewer: `/root/m3_review_standards`; read-only Standards axis of `code-review`. Fixed baseline: `56bcfe23af09c54f2e5927fe21cf87fdd17e8820`. Source/data endpoints below remain fixed even when separate delivery metadata advances. This is no ticket, milestone, research-gain or integration acceptance.

## Ticket 15 — Standards

**0 documented-standard violations; 0 retained Fowler heuristic findings.** Endpoint `9cef63f3a72ebfc1196a3bd4a3509e54266dbd4c`; execution `ba9bf5be7fe4fb57dacaca48f1163ff0f4eb1c6c`. Comparison: `git diff 56bcfe23af09c54f2e5927fe21cf87fdd17e8820...9cef63f3a72ebfc1196a3bd4a3509e54266dbd4c`.

`src/aegis_dc/decision_view.py:191` validates a detached current-frame contract; `:230` computes planning eligibility from nominal capabilities and arrived declared reports; `:291` keeps the advancing clock/ledger evaluator-owned. The offline accumulated trace is private and is rejected by the consumer. These respect `AGENTS.md:11,31` and spec Implementation Decisions on public interfaces and separate authority. Tests use public frames, explicit expected masks/times, callback rejection and independent hidden-world witnesses rather than private-state test seams.

The capture/verifier declares durable roles before hashing, excludes caches, checks recorded execution/delivery blobs, and preserves the pending original receipt (`AGENTS.md:13,33`). Independent readback found all **58 artifacts plus receipt**, **51 runtime / 123 tool / 42 input pins** and all **81 changed evidence files** byte-consistent. The earlier CRLF preflight refusal remains a decoded terminal record explicitly marked as not independently captured binary output; it records zero physical/full runs.

The stored 386/384-executed result has zero failures/errors and two identified optional Torch skips; this reviewer did not rerun it. The historical PASS receipt and separate fresh-proof provenance do not complete M3. Metadata addendum remains separate.

## Ticket 16 — Standards

**0 documented-standard violations; 0 retained Fowler heuristic findings.** Endpoint `d032d2a7d88ec19d46f69a8ed6085512b6b1138f`; observation execution `842093460248167c0b8e4d9e37e74aebc9da034a`. Comparison: `git diff 56bcfe23af09c54f2e5927fe21cf87fdd17e8820...d032d2a7d88ec19d46f69a8ed6085512b6b1138f`.

`src/aegis_dc/sensor_channels.py:89` enforces a closed static empty-record registry, typed coverage/units and declared performance assumptions. `:186,308` keys draws by measurement/source observation, uses only at-or-before saved points, preserves cached age/origin, and separates realized errors/audit from the public model. Exact polling budgets and non-early arrival coordinates are explicit. This follows `AGENTS.md:11` and spec Implementation/Testing Decisions on SI units, provenance and future-information gates. Public tests include independent literals and sparse/disabled/missing/negative cases.

`verify_sensor_retained_capture.py` preserves the original capture as **FAIL**, the exact missing `source-guard.json`, 390/388-executed with one failure, one error and two optional skips. It verifies the actual two legacy CLI error signatures and the separate two-test environment closure; the global regression gate stays pending. The older success-only verifier is retained and refuses this failed original, rather than silently upgrading it (`AGENTS.md:13,33`).

Independent readback found **32 original artifacts plus receipt**, all closure artifacts, **51 runtime / 122 tool / 68 input pins**, and all **71 changed evidence files** consistent with their fixed execution/delivery blobs. This supports preserved saved-data integrity and narrow closure only. This reviewer ran no observation producer, physical simulation, target suite or full regression.

## Ticket 17 — Standards

**0 documented-standard violations; 0 retained Fowler heuristic findings.** Endpoint `83617cd19bdd1be9564cc9e94ef803f6f892ef4e`; producer execution `6b76088de3e83efd8b157ff4dd86e6052f29064f`. Comparison: `git diff 56bcfe23af09c54f2e5927fe21cf87fdd17e8820...83617cd19bdd1be9564cc9e94ef803f6f892ef4e`.

`src/aegis_dc/nonfixed_evidence.py:62,266` validates declared completion, time, coverage, expiry and realization gates before reading private signals. The typed lazy saved-run adapter samples an exact authorized completion point. Reports retain source times/quality/provenance; false, zero and null remain distinct. Session upstream records cannot bypass completion, and detached public outputs exclude private source hashes/draws (`AGENTS.md:11`; spec Implementation/Testing Decisions). Tests inspect emitted records, strict availability and explicit saved-point literals.

The declared fixture is consistently distinguished from future professional execution in 21/22. Its old `cf9b3390` trajectory has maximum step **1 s**, with exact 97.5 s completion sampling and 98 s delivery; it is not presented as new 0.01 s qualification or physical execution. No plant/physics, legacy research, or paper source was changed.

The capture/verifier preserves original evidence, source epochs, cache exclusion and pending delivery receipt (`AGENTS.md:13,33`). Independent readback found **52 artifacts plus receipt**, **51 runtime / 128 tool / 139 input pins**, and all **172 changed evidence files** byte-consistent. The stored 398/396-executed result has zero failures/errors and two identified optional Torch skips; this reviewer did not rerun it. Professional execution, field calibration and research gain remain unestablished. Metadata addendum remains separate.

## Verification record and scope

Attachments: `C:/Users/Donson/AppData/Local/Temp/aegisdc-review-M3-15-17-standards-20261105/`.

- `fixed-git-index.json` records the exact diff/log commands, commits, file categories and initial statuses. Counts: 15 = 98 files (81 evidence); 16 = 86 (71 evidence); 17 = 184 (172 evidence). No `CODING_STANDARDS.md`, `CONTRIBUTING.md`, nested `AGENTS.md` or changes to physics/paper modules were present in these pinned diffs.
- `independent-original-byte-audit.json` is the new finite readback result. Actual command: `C:/Users/Donson/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe -B -X utf8 C:/Users/Donson/AppData/Local/Temp/aegisdc-review-M3-15-17-standards-20261105/verify_review_bytes.py`; observed exit 0, tool chunk `69687f`, 3.11605 s. It checks declared artifact sets, raw actual bytes, fixed delivery Git blobs, original terminal receipts and recorded execution/source/tool/input blobs. It does not claim to be the authors' fresh-checkout execution, regenerate scientific results or supply missing historical invocation logs.
- `source-byte-guard-before.json`, `original-evidence-byte-guard-before.json` and `source-and-original-byte-guard-after.json` protect **619 source/test/tool/config files and 324 original evidence files**. The initial after-readback observed **zero byte drift**, root clean at baseline, and no protected-path commit changes. Actual guard command uses the same interpreter and `check_review_guards.py`; observed exit 0, chunk `cbf902`.
- Reviewer executions: **0 physical runs, 0 full regressions, 0 target-test executions**. Existing stored test counts are explicitly historical observations. No authored tree or Root file was written by this reviewer; only Temp report/attachments were created.

Standards read: `AGENTS.md`; `GLOSSARY.md`; `docs/MAINLINE.md`; `docs/mainline/progress.json`; `docs/agents/domain.md`, `issue-tracker.md`, `triage-labels.md`; ADR 0002/0003; `.scratch/full-facility-mainline/spec.md` Implementation/Testing Decisions; the three tickets and their contract/runbook/attributes. `pyproject.toml` supplies package/runtime conventions. The complete Fowler baseline was considered as judgement, with repository rules taking priority. Closed JSON domain records are deliberate public contracts; distinct adapter validation and preserved frozen tools do not justify compulsory extraction or speculative abstraction. Tool-enforced checks were treated as evidence, not duplicated as style findings.

**Source result: 15 = 0 hard / 0 heuristic; 16 = 0 hard / 0 heuristic; 17 = 0 hard / 0 heuristic. The final metadata addendum below completes this reviewer handoff; no merge or goal-completion claim.**

## Final metadata addendum

| Ticket | Metadata endpoint | Source findings hard / heuristic | Delivery metadata findings hard / heuristic |
|---|---|---|---|
| 15 | `bbe38115bf12cef357d3475372d8f5f7ae2db44c` | 0 / 0 | 0 / 0 |
| 16 | `076e3de6683f68b5a35666ac6c5d1003843719bc` | 0 / 0 | 0 / 0 |
| 17 | `fcf8cad8d722323fe242bfea7f0d256ef1bbc0b9` | 0 / 0 | 0 / 0 |

Finite `git diff DATA..METADATA --name-status` review covered 5/8/11 metadata paths. Each author tree was clean at its stated endpoint. A new afterguard (actual exit 0, tool chunk `613403`) again found all **619 source/test/tool/config files and 324 original evidence files unchanged**, including frozen 15/17 README and attributes. The original fixed source review remains authoritative.

All 12 new proof/manifest hash references checked out. The 21 non-index metadata paths were raw-identical to their committed blobs. The initial metadata checker incorrectly required raw identity for the three ordinary candidate-index JSON documents too; its exit-1 result and original checker remain retained as `metadata-addendum-checks.json` / `verify_metadata_addendum.py`. The exact additive correction, `metadata-addendum-classification-correction.json`, verifies **only** `docs/mainline/evidence/15.json`, `16.json`, `17.json`: each differs solely by CRLF/LF, is outside the original receipt pin sets, and has matching `git hash-object --path` / committed clean-filter identity. Correction execution actually exited 0 (chunk `94863c`). No raw proof or manifest mismatch was excused.

15's new delivery summary/observation accurately limits its existing proof provenance; it does not invent the missing historical argv or elapsed time. 16 retains its original FAIL, sole missing role, separate two-test PASS and pending global gate. 17 provides the newly observed real detached-CLI fresh invocation and raw streams, retaining its historical 1 s source and unconnected professional-execution status. All candidate indexes keep ticket lifecycle claimed, Root acceptance/M3/global regression pending, zero research/model/training counters and no effect claim.

**Accepted integration preparation, still pending Root closure:** default metadata-only whitespace checks identify exactly four new native-CRLF leaves: `15-truth/DELIVERY.md`, `15-truth/delivery-9cef63f3-existing-proof-observation-01.json`, `17-nonfixed/DELIVERY.md`, `17-nonfixed/delivery-readback-01/verify.stdout.raw` (under `evidence/mainline/engineering/`). The same checks with command-local `cr-at-eol` recognition exit 0 for all three tickets while preserving other default whitespace checks. Root plans a new ancestor `evidence/mainline/engineering/.gitattributes` containing only those exact new leaves and CR recognition, preserving raw bytes and every frozen existing attribute. This formatting closure is not a source/delivery correctness finding and is not claimed complete here. Root may provide its actual rule/path-byte result for a small follow-up closure. No implementation, producer, physical or full-regression rerun occurred in this addendum.
