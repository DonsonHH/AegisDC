"""Finite transport/schema conformance of three separately captured M3 slices."""
from copy import deepcopy
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys
import types

ROOT = Path(__file__).resolve().parents[1]
DECISION_SOURCE = 'ba9bf5be7fe4fb57dacaca48f1163ff0f4eb1c6c'
OUTPUT = ROOT / '.work/M3-three-channel-saved-conformance-01.json'


def read(path):
    return json.loads(path.read_text(encoding='utf-8'))


def blob(revision, name):
    return subprocess.check_output(['git', 'show', revision + ':' + name], cwd=ROOT)


def main():
    assert not OUTPUT.exists()
    base = ROOT / '.work/worktrees'
    decision = base / 'full-site-15'
    sensor = base / 'full-site-16/evidence/mainline/engineering/16-sensors/capture-01'
    portable = base / 'full-site-17/evidence/mainline/engineering/17-nonfixed/capture-01'
    fixture = decision / 'configs/full-facility-decision-v1'
    paths = [fixture / 'public-nominal.json', fixture / 'public-plan.json',
             fixture / 'common-ledger.json', sensor / 'cli-primary/production-private.json',
             portable / 'profile-copy.json', portable / 'snapshots.json']
    raw_before = {path: sha256(path.read_bytes()).hexdigest() for path in paths}
    sys.path.insert(0, str(ROOT / 'src'))
    from aegis_dc.evidence_ledger import RECORD_FIELDS
    module = types.ModuleType('aegis_dc._root_saved_decision')
    module.__package__ = 'aegis_dc'
    raw_source = blob(DECISION_SOURCE, 'src/aegis_dc/decision_view.py')
    exec(compile(raw_source, '<frozen-decision-source>', 'exec'), module.__dict__)
    nominal, plan, initial = [read(path) for path in paths[:3]]
    production = read(paths[3])
    registry = read(paths[4])['registry']
    stored_portable = read(paths[5])['expired']
    nonfixed = deepcopy(registry)
    nonfixed['records'] = [{key: row[key] for key in RECORD_FIELDS}
                           for row in stored_portable['records']]
    ledgers = [initial, production['ledger'], nonfixed]
    combined = deepcopy(initial)
    combined['id'] = 'declared-M3-transport-conformance-v1'
    for incoming in ledgers[1:]:
        assert incoming['facility_id'] == combined['facility_id']
        assert set(incoming['entity_ids']) == set(combined['entity_ids'])
        for group in ('sources', 'observables', 'records'):
            existing = {row['id']: row for row in combined[group]}
            for row in incoming[group]:
                if row['id'] in existing:
                    assert existing[row['id']] == row
                else:
                    combined[group].append(deepcopy(row))
                    existing[row['id']] = row
    times = [0, 30, 97.5, 97.99999999999999, 98, 120]
    plan['id'] = 'declared-M3-public-transport-clock-v1'
    plan['decision_times_s'] = times
    gateway = module.DecisionGateway(nominal, combined, plan)
    sensor_ids = {row['id'] for row in production['ledger']['records']}
    portable_ids = {row['id'] for row in nonfixed['records']}
    result = []
    for instant in times:
        frame = gateway.next_frame()
        options = module.decision_options(frame)
        expected = {row['id'] for row in combined['records']
                    if row['observed_at_s'] <= instant and row['arrived_at_s'] <= instant}
        arrived = {row['id'] for row in frame['evidence']['records']}
        assert arrived == expected and not options['execution_permission']
        if instant < 98:
            assert 'completed-numeric' not in arrived
        elif instant == 98:
            assert 'completed-numeric' in arrived
            assert {'copy-first', 'alarm-later'} <= arrived
            assert any({'copy-first', 'alarm-later'} <= set(row['record_ids'])
                       for row in frame['evidence']['correlation_groups'])
        result.append(dict(as_of_s=instant, arrived_records=len(arrived),
                           sensor_records=len(arrived & sensor_ids),
                           nonfixed_records=len(arrived & portable_ids),
                           completed_numeric_visible='completed-numeric' in arrived,
                           demo_choice=options['demo_choice_id'], execution_permission=False))
    assert all(sha256(path.read_bytes()).hexdigest() == identity
               for path, identity in raw_before.items())
    receipt = dict(
        scope='Finite transport/schema conformance only, using three separately captured engineering slices',
        result='PASS', decision_source=DECISION_SOURCE,
        decision_source_sha256=sha256(raw_source).hexdigest(),
        observation_adapter_source='842093460248167c0b8e4d9e37e74aebc9da034a',
        nonfixed_adapter_source='6b76088de3e83efd8b157ff4dd86e6052f29064f',
        sensor_global_capture_status='FAIL_ENVIRONMENT_RETAINED; component observations used here only',
        same_entity_ids=len(combined['entity_ids']), shared_facility_id=combined['facility_id'],
        explicit_static_registry_union=True, future_queue_passed_to_consumer=False,
        source_bytes_unchanged=True,
        input_sha256={path.relative_to(ROOT).as_posix(): identity
                      for path, identity in raw_before.items()}, steps=result,
        limitations=['The sensor and portable records come from distinct historical physical executions with different maximum steps.',
                     'This is not a coherent jointly observed physical-world experiment or risk/decision-effect evaluation.',
                     'The explicitly authored registry union is a conformance fixture, not a production orchestration API.',
                     'Ticket18 and subsequent dynamic mechanisms still require their own accepted inputs and validation.'],
        new_physical_runs=0, new_observation_adapter_runs=0, new_full_regressions=0,
        registered_research_trials=0, model_calls=0, training_calls=0)
    with OUTPUT.open('x', encoding='utf-8', newline='\n') as stream:
        stream.write(json.dumps(receipt, ensure_ascii=False, indent=2, allow_nan=False) + '\n')
    print(json.dumps({key: value for key, value in receipt.items()
                      if key not in ('input_sha256', 'limitations')}, ensure_ascii=False))


if __name__ == '__main__':
    main()
