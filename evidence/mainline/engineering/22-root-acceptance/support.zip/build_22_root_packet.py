"""Preserve actual-inspection root acceptance with immutable source/data identities."""
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import zipfile
ROOT=Path(__file__).resolve().parents[1];WORK=ROOT/'.work'
SOURCE='e33ff63a4a110a00cbce640fa267dff7c2da48bf'
PACKET=Path('evidence/mainline/engineering/22-root-acceptance')
RAW=ROOT/'runs/mainline-M4-22-root-acceptance-20261105-01'
def read(p):return json.loads(p.read_bytes())
def digest(p):return sha256(p.read_bytes()).hexdigest()
def git(*a):return subprocess.check_output(['git',*a],cwd=ROOT)
def write(p,v,new=True):
    p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('x' if new else 'w',encoding='utf-8',newline='\n') as f:f.write(json.dumps(v,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
def main():
    assert git('rev-parse','HEAD').decode().strip()==SOURCE and not git('status','--porcelain')
    packet=ROOT/PACKET;assert not packet.exists()
    summary,guard=read(RAW/'summary.json'),read(RAW/'source-guard.json');tests=summary['tests']
    assert summary['overall']=='PASS' and tests['run']==tests['executed']>476
    assert tests['errors']==tests['failures']==tests['skipped']==0 and summary['verified_original_files']==20
    assert guard['sources_unchanged'] and guard['head_unchanged'] and guard['source_commit_before']==SOURCE
    spec=read(WORK/'22-spec-final-01/review.json');std=read(WORK/'22-standards-final-01/review.json')
    assert spec['status']=='PASS' and spec['assertions']==1427 and spec['findings']==[] and std['hard_findings']==[]
    copies={'raw/'+n:RAW/n for n in ('summary.json','tests.log','evidence.json','source-guard.json')};visuals={}
    for stem in ('inspection-timing','inspection-boundary'):
        png=WORK/'22-visual-qa-01'/(stem+'.png');svg=png.with_suffix('.svg');dest='figures/'+png.name;copies[dest]=png
        source='evidence/mainline/engineering/22-inspections/capture-01/'+svg.name
        assert digest(svg)==digest(ROOT/source)
        visuals[dest]=dict(svg=source,svg_sha256=digest(svg),png_sha256=digest(png))
    assert read(WORK/'22-visual-qa-01/visual-review.json')['open_findings']==0
    reviews={}
    for folder in ('22-spec-final-01','22-standards-final-01'):
        for p in (WORK/folder).rglob('*'):
            if p.is_file() and '__pycache__' not in p.parts and p.suffix not in {'.pyc','.pyo'}:
                reviews[folder+'/'+p.relative_to(WORK/folder).as_posix()]=p
    support={n:WORK/n for n in ('22-integration-precheck-01.json','22-sequential-integration-01.json',
        '22-fresh-proof-02.json','22-fresh-attempt-01.json','22-independent-completion-measurement-witness-01.json',
        '22-independent-measurement-kernel-witness-01.json','run_22_root_acceptance.py','build_22_root_packet.py')}
    for p in (WORK/'22-visual-qa-01').glob('*.json'):support['visual/'+p.name]=p
    declared=sorted(set(copies)|{'.gitattributes','README.md','declaration.json','source-manifest.json',
        'archive-members.json','reviews.zip','support.zip','verify_packet.py'})
    write(packet/'declaration.json',dict(artifacts=declared,terminal_receipt='receipt.json'))
    for n,p in copies.items():q=packet/n;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(p.read_bytes())
    attrs=['# Exact native raw output; all other whitespace checks retained.']
    for n,p in copies.items():
        if n.startswith('raw/') and b'\r\n' in p.read_bytes():attrs.append(n+' -text whitespace=blank-at-eol,blank-at-eof,space-before-tab,cr-at-eol')
    (packet/'.gitattributes').write_text('\n'.join(attrs)+'\n',encoding='utf-8',newline='\n')
    archives={}
    for name,members in (('reviews.zip',reviews),('support.zip',support)):
        archives[name]={}
        with zipfile.ZipFile(packet/name,'x',zipfile.ZIP_DEFLATED) as z:
            for n,p in sorted(members.items()):
                raw=p.read_bytes();z.writestr(n,raw);archives[name][n]=dict(sha256=sha256(raw).hexdigest(),bytes=len(raw))
    write(packet/'archive-members.json',archives)
    capture='evidence/mainline/engineering/22-inspections/capture-01/receipt.json'
    author=dict(execution='5486442a5fdb44f62f53fdf9a53d73b251018f62',data_delivery='68127e11c73835ff4b984d0336885d22d2dc5d07',
        candidate='4b7a8a335a715b02c55830db6989ed93e344119d',capture=capture,capture_sha256=digest(ROOT/capture))
    write(packet/'source-manifest.json',dict(tested_source=SOURCE,author=author,visuals=visuals,
        accepted20_source='08a7c6c05662434f8c8d9ae36a15c72040866990',
        reviews=dict(standards_findings=0,spec_findings=0,independent_assertions=1427,
            spec_report_sha256=digest(WORK/'22-spec-final-01/SPEC.md'),standards_report_sha256=digest(WORK/'22-standards-final-01/report.md'))))
    (packet/'verify_packet.py').write_bytes((WORK/'22-verify_packet.py').read_bytes())
    text=f'''# 第22项根验收：实际检查、观测与确认

集成执行源`{SOURCE}`通过{tests['executed']}项完整回归：全部执行，零失败、零错误、零跳过。20份历史原件通过核对；{len(guard['actual_sources'])}个Python与JSON源文件接受Git身份及前后字节守卫。独立Spec通过1427项断言，两轴无未关闭问题；旧第17项观测规律及其他主线行为仍受统一回归检查。

![实际检查时序](figures/inspection-timing.png)

正式三秒V6工程见证只运行一次：1秒移动、.25秒安全访问检查，1.25秒开工、2.25秒完成采样、2.75秒上报可用。工作区间内1.75秒的声明泵压力变化使流量从.12降至0m³/s；完成记录使用当前0。实际到访、作业、观察和送达各有时刻，两个严格早于完成/到达的公开快照均为空。

![物理执行到公开证据边界](figures/inspection-boundary.png)

同一CrewWorkforce提供真实完成，调用方夹具token不能代替。局部保护先于同刻完成，取消、未完成和过短观测不产生成功记录。质量未知和条件不适用按声明来源、时标及固定说明保留。数值界能确认命名信号与阈值的关系；它不是故障诊断或恢复认证。确认与读数同源、同有效期且不增添独立证据，过期后只保留历史事实。

## 原件与独立复核

原5486执行源、6812交付、三秒尝试及收据保持独立身份。11个声明产物加收据、57运行源、1工具、30输入在新检出中与Git原件一致；303轨迹点和内部物理清单通过核对。只读快照由实际产生记录经14门槛重建，没有重复物理运行。

1427项独立断言包括1186保存数据、10完成门槛、30公开接口、17拒绝以及184守卫检查。[评审ZIP](reviews.zip)保留协议、导出源码、探针和原始读回结果；[支持ZIP](support.zip)保留来源、合并保护、解析时序、新检出与实际图像复核。审查脚本先误写图名control，原失败及仅改为control_information的修正版均保留；首次新检出命令漏PYTHONPATH的导入失败及随后显式src通过亦单列。两者不计为物理捕获失败，不重写旧记录。

- [根接受权威](../../../../docs/mainline/evidence/22-root.json)
- [作者候选报告](../22-inspections/README.md)及[实际检查契约](../../../../docs/mainline/22-inspection-contract.md)
- [根摘要](raw/summary.json)、[完整日志](raw/tests.log)、[源码守卫](raw/source-guard.json)
- [声明产物](declaration.json)、[来源清单](source-manifest.json)、[收据](receipt.json)

两图由源SVG本地渲染并实际查看，未声称浏览器QA。复算在本封存提交新检出中使用`verify_packet.py --delivery-commit COMMIT --output OUTSIDE_CHECKOUT.json`，不重跑推断、物理或全量回归。当前主票23继续完成实际处置，随后24核验恢复关闭；M4与完整研究目标仍active。无注册效果实验、LLM调用或训练，现场标定待取得。
'''
    (packet/'README.md').write_text(text,encoding='utf-8',newline='\n')
    assert {p.relative_to(packet).as_posix() for p in packet.rglob('*') if p.is_file()}==set(declared)
    write(packet/'receipt.json',dict(schema='aegisdc-ticket22-root-packet-v1',tested_source=SOURCE,
        delivery_gate='PENDING_COMMIT_AND_FRESH_CHECKOUT',artifacts={n:digest(packet/n) for n in declared},root_tests=tests,
        independent_assertions=1427,historical_originals=20,new_full_regressions=0,new_physical_runs=0,registered_research_trials=0,llm_calls=0,training_calls=0))
    write(ROOT/'docs/mainline/evidence/22-root.json',dict(schema='aegisdc-ticket-root-acceptance-v1',ticket='22',status='ACCEPTED',
        actual_root_source=SOURCE,root_tests=tests,packet=PACKET.as_posix(),packet_receipt_sha256=digest(packet/'receipt.json'),author=author,
        independent_assertions=1427,standards_findings=0,spec_findings=0,field_calibration='PENDING',registered_research_trials=0,llm_calls=0,training_calls=0,overall_goal='ACTIVE'))
    p=ROOT/'.scratch/full-facility-mainline/issues/22-inspection-actions.md';s=p.read_text(encoding='utf-8');assert '**Status:** claimed' in s
    s=s.replace('**Status:** claimed','**Status:** resolved',1).replace('- [ ]','- [x]');s+='\nRoot acceptance: `docs/mainline/evidence/22-root.json`; actual source`'+SOURCE+'`, '+str(tests['executed'])+' executed checks with0skips and1427independentassertions. Author candidate and pendingreceipt remain their historical snapshots; Root authority resolves this ticket.\n';p.write_text(s,encoding='utf-8',newline='\n')
    p=ROOT/'docs/mainline/progress.json';v=read(p);assert v['current_ticket']=='22';v['current_ticket']='23';v['active_implementations']=[x for x in v['active_implementations'] if x['ticket']!='22'];m=next(x for x in v['milestones'] if x['id']=='M4');m['acceptance_evidence'].append('docs/mainline/evidence/22-root.json');m['progress_scope']='21personnel and22actual inspection accepted;23intervention and24closure remain.';write(p,v,False)
    p=ROOT/'docs/current-research.json';v=read(p);v.update(current_primary_ticket='23',current_primary_ticket_assigned=True,active_tickets=['23'],next_ready_unassigned=[],implementation='Tickets01–22 accepted. Primary23actual physical intervention active;24blockeduntil23. M4 and whole research objective remain active.');v['runtime_verification_documents'].append((PACKET/'README.md').as_posix());write(p,v,False)
    for name in ('docs/MAINLINE.md','docs/NEXT.md'):
        p=ROOT/name;s=p.read_text(encoding='utf-8');s=s.replace('当前主票22','第22票已接受，当前主票23');s+='\n实际检查22通过[根验收、时序与架构图](../evidence/mainline/engineering/22-root-acceptance/README.md)。实际处置23和验证关闭24继续，整体目标active。\n';p.write_text(s,encoding='utf-8',newline='\n')
    print(json.dumps(dict(packet=PACKET.as_posix(),artifacts=len(declared),archive_members=sum(map(len,archives.values())),tests=tests,guarded_files=len(guard['actual_sources'])),ensure_ascii=False))
if __name__=='__main__':main()
