"""Independent ticket22 review: saved physical evidence and private completion-gate harness.

The harness advances the real typed crew clock and supplies independently stated
current-point scalars. It does not call simulate_scenario or claim a new coupled
physical trajectory. Coupled-plant evidence is read from immutable author data.
"""
from copy import deepcopy
from fractions import Fraction as F
from hashlib import sha256
import json
import math
from pathlib import Path
import subprocess
import sys

OUT=Path(__file__).resolve().parent
REPO=OUT.parents[1]
EXPORT=OUT/'export'
PROTOCOL=json.loads((OUT/'protocol.json').read_bytes())
SOURCE=PROTOCOL['source'];DELIVERY=PROTOCOL['delivery']
CAPTURE='evidence/mainline/engineering/22-inspections/capture-01'
assert sha256((OUT/'protocol.json').read_bytes()).hexdigest()==(OUT/'protocol.sha256').read_text().strip()
sys.path.insert(0,str(EXPORT/'src'))
COUNT={'saved':0,'gate_harness':0,'public':0,'negative':0,'guard':0}
RAW={}
def check(ok,message,kind='saved'):
    if not ok:raise ValueError(message)
    COUNT[kind]+=1
def read(p):return json.loads(p.read_bytes())
def digest(raw):return sha256(raw).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=REPO)
def blob(revision,name):return git('cat-file','blob',revision+':'+name)
def saved(name):return json.loads(blob(DELIVERY,CAPTURE+'/'+name))
def write_new(p,value):
    with p.open('x',encoding='utf-8',newline='\n') as stream:stream.write(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
def hashes(rev,names):
    names=sorted(set(names));raw=subprocess.check_output(['git','cat-file','--batch'],cwd=REPO,
        input=''.join(rev+':'+n+'\n' for n in names).encode())
    out={};offset=0
    for n in names:
        end=raw.index(b'\n',offset);header=raw[offset:end].split();check(len(header)==3 and header[1]==b'blob','Missing Git blob','guard')
        start=end+1;size=int(header[2]);out[n]=digest(raw[start:start+size]);offset=start+size+1
    check(offset==len(raw),'Unexpected batch bytes','guard');return out
def keys(value):
    result=set()
    if isinstance(value,dict):
        result.update(value)
        for child in value.values():result.update(keys(child))
    elif isinstance(value,list):
        for child in value:result.update(keys(child))
    return result
def refused(label,call):
    try:call()
    except ValueError as error:
        RAW.setdefault('refusals',[]).append(dict(id=label,error=str(error)))
        check(True,label,'negative')
    else:raise ValueError('Expected closed-input refusal: '+label)

def check_saved():
    protocol=json.loads(blob(SOURCE,'docs/mainline/22-inspection-engineering-protocol.json'))
    r=saved('receipt.json');run=saved('run.json');scenario=saved('scenario.json')
    check(r['execution_commit']==SOURCE and r['status']=='PASS' and r['source_head_and_bytes_unchanged'],'Original source receipt')
    check(r['global_regression_gate']=='PENDING_ROOT_INTEGRATED_FULL' and r['field_calibration']=='PENDING','Original gate preserved')
    check(set(r['artifacts'])==set(protocol['durable_outputs']) and len(r['artifacts'])==11,'Durable declaration')
    delivery_names=git('ls-tree','-rz','--name-only',DELIVERY,CAPTURE).decode().strip('\0').split('\0')
    check(set(delivery_names)=={CAPTURE+'/'+n for n in r['artifacts']}|{CAPTURE+'/receipt.json'},'Exact committed durable set')
    for name,h in r['artifacts'].items():check(digest(blob(DELIVERY,CAPTURE+'/'+name))==h,'Original artifact SHA: '+name)
    check(not any('__pycache__' in n or n.endswith(('.pyc','.pyo')) for n in delivery_names),'No cache in durable set')
    for role,pins in r['pinned'].items():check(pins==hashes(SOURCE,pins)==hashes(DELIVERY,pins),'Execution/delivery pins: '+role)
    src_names=git('ls-tree','-rz','--name-only',SOURCE,'src').decode().strip('\0').split('\0')
    check(set(r['pinned']['runtime'])=={n for n in src_names if n.endswith('.py')},'Complete runtime Python pin set')
    check(set(r['pinned']['tools'])=={protocol['authoring_tool']},'Authoring tool pin')
    inputs=read(EXPORT/protocol['input']);check(scenario==inputs['model'],'Saved scenario equals declared input')
    check(len(scenario['domains'])==8 and set(scenario['graphs'])=={'physical','functional','control_information','access'},'Same complete facility identity')
    task=run['work_records'][0];record=run['inspection_public_snapshot']['records'][0];feedback=run['inspection_public_feedback'][0]
    # Independent arithmetic from the declared access edge/work/latency, not author checks.json.
    params={p['id']:p['value'] for p in scenario['parameters']}
    route=next(e for e in scenario['graphs']['access'] if e['from']=='loc_control' and e['to']=='loc_hx')
    travel=F(params[route['duration_parameter']]);gate=F(inputs['work_program']['profile']['access_check_s'])
    work=F(params['inspection_time']);arrival=travel+gate;completion=arrival+work
    binding=inputs['inspection_program']['profile']['bindings'][0]
    available=completion+F(binding['arrival_latency_s'])
    check((travel,gate,work,arrival,completion,available)==(F(1),F(1,4),F(1),F(5,4),F(9,4),F(11,4)),'Independent literal timeline')
    check(task['arrived_at_s']==float(arrival) and task['work_started_at_s']==float(arrival),'Actual arrival/start')
    check(task['status']=='completed' and task['completed_at_s']==float(completion),'Actual completed work')
    check(record['observed_at_s']==float(completion) and record['arrived_at_s']==float(available),'Observation/delivery times')
    check(record['valid_until_s']==float(completion+F(binding['validity_s'])),'Validity tied to completion')
    expected_summary={'worker_travel_person_s':1,'worker_wait_person_s':.25,'worker_work_person_s':1,
        'access_check_person_s':.25,'tool_occupation_tool_s':2.25,'tool_work_tool_s':1}
    for key,value in expected_summary.items():check(run['summary'][key]==value,'Independent resource time: '+key)
    check(record['value']==0 and record['quality']['status']=='bounded' and record['unit']=='m3/s','Zero is a valid bounded SI reading')
    check(feedback['record_id']==record['id'] and feedback['provenance']==record['provenance'] and feedback['additional_evidence_factor'] is False,'Confirmation shares source, no new factor')
    check(feedback['confirmation']=='CONFIRMED_BELOW_THRESHOLD' and feedback['current_confirmation'],'Signal-only confirmation')
    check(feedback['scope']=='NAMED_SIGNAL_THRESHOLD_ONLY_NOT_FAULT_DIAGNOSIS','Confirmation scope')
    check(not keys([run['inspection_public_snapshot'],run['inspection_public_models'],run['inspection_public_feedback']]) &
        {'seed','bias','noise_half_width','authorized_raw_signal','private_realization','private_draw','actual_error_vs_signal','latent_signal_above_threshold'},'No private answer key in public channels')
    check(run['inspection_public_models']['execution_permission'] is False,'No physical operation permission')
    trace=[json.loads(line) for line in blob(DELIVERY,CAPTURE+'/private-state.jsonl').splitlines()]
    balances=[json.loads(line) for line in blob(DELIVERY,CAPTURE+'/balances.jsonl').splitlines()]
    for name,item in run['artifacts'].items():check(digest(blob(DELIVERY,CAPTURE+'/'+name))==item['sha256'],'Internal physical manifest')
    check(all(a['time_s']<b['time_s'] for a,b in zip(trace,trace[1:])),'Strictly increasing actual trace')
    check(trace[0]['time_s']==0 and trace[-1]['time_s']==3,'Original trajectory bounds')
    times={x['time_s']:x for x in trace};change=F(inputs['boundary_events'][0]['time_s'])
    check(arrival<change<completion and change==F(7,4),'Real signal changes within actual work')
    path=lambda x:x['domains']['facility_cooling']['internal_pump']['volume_flow_m3_s']
    check(path(times[0])==.12 and path(times[1.75])==0 and path(times[2.25])==0,'Independent declared pump change witness')
    check(path(times[2.25])==record['value'] and path(times[0])!=record['value'],'Current completion sample, not dispatch sample')
    domain_ids={x['id'] for x in scenario['domains']}
    for point in trace:
        check(set(point['domains'])==domain_ids,'Eight domains continue while checking')
        location=point['domains']['people_tools_work']['workers']['worker_control']
        if point['time_s']<1:check(location['location_id'] is None,'Actual travelling before gate')
        elif point['time_s']<1.25:check(location['status']=='waiting','Actual positive gate check')
        elif point['time_s']<2.25:check(location['status']=='working','Actual professional work interval')
    for row in balances:
        check(all(row[k]>=0 for k in expected_summary),'Nonnegative incurred resources')
        check(abs(row['worker_wait_person_s']-(row['access_check_person_s']+row['rendezvous_wait_person_s']+row['queue_wait_person_s']))<1e-12,'Wait subcategory conservation')
    for name,count in zip(('public-before-completion.json','public-before-arrival.json','public-at-arrival.json'),(0,0,1)):
        snap=saved(name);check(len(snap['records'])==count,'Saved strict public gate: '+name)
    audit=run['inspection_private_audit'];check(len(audit['events'])==1 and audit['events'][0]['source_sample_at_s']==2.25,'One private sample event')
    check(audit['events'][0]['authorized_raw_signal']==record['value'] and audit['attempts'][0]['measurement_record_id']==record['id'],'Private audit linked to completed observation')
    RAW['saved_summary']=dict(trace_points=len(trace),balance_rows=len(balances),resource_literal=expected_summary,
        observed=record,confirmation=feedback,pin_counts={k:len(v) for k,v in r['pinned'].items()})
    return inputs,run

def completion_gates(inputs):
    from aegis_dc.inspection_execution import InspectionSession
    from aegis_dc.workforce_dispatch import CrewWorkforce
    def harness(name,mutate=None,times=(0,1,1.25,2.25,2.75),temp=False):
        scenario=deepcopy(inputs['model']);wp=deepcopy(inputs['work_program']);ip=deepcopy(inputs['inspection_program'])
        if mutate:mutate(wp,ip)
        before=deepcopy((scenario,wp,ip));parameters={p['id']:p['value'] for p in scenario['parameters']}
        workforce=CrewWorkforce(scenario,parameters,wp,10);session=InspectionSession(scenario,wp,ip)
        observations=[]
        for time in times:
            workforce.process(time,set())
            value=300 if temp else .03125 if time==2.25 else .125 if time<2.25 else 999
            point={'time_s':time,'domains':{'equipment_environment':{'immersion':{'coolant_temperature_K':value}}} if temp else
                {'facility_cooling':{'internal_pump':{'volume_flow_m3_s':value}}}}
            # Exact whitelist path for temperature uses immersion's public named field.
            if temp:
                from aegis_dc.nonfixed_evidence import SIGNALS
                point={'time_s':time,'domains':{}}
                target=point['domains']
                keys_path=SIGNALS['immersion.coolant_temperature'][2]
                for key in keys_path[:-1]:target=target.setdefault(key,{})
                target[keys_path[-1]]=value
            session.process(time,workforce,point)
            observations.append(dict(time_s=time,snapshot=session.snapshot(time),feedback=session.public_feedback(time)))
        check((scenario,wp,ip)==before,'Gate harness does not mutate inputs','gate_harness')
        RAW[name]=dict(observations=observations,private_audit=session.private_audit())
        return session,observations
    session,rows=harness('current-completion-sample')
    check(rows[0]['snapshot']['records']==rows[1]['snapshot']['records']==rows[2]['snapshot']['records']==rows[3]['snapshot']['records']==[],'No pre-arrival reading','gate_harness')
    reading=rows[-1]['snapshot']['records'][0]
    check(reading['value']==.03125 and reading['observed_at_s']==2.25 and reading['arrived_at_s']==2.75,'Independent current-point gate sample','gate_harness')
    check(len(session.private_audit()['events'])==1,'Only one sample event','gate_harness')
    check(session.snapshot(2.75)==session.snapshot(2.75),'Repeated public snapshot stable','public')
    previous=session.snapshot(math.nextafter(2.75,-math.inf));check(previous['records']==[],'Strict nextafter arrival boundary','public')
    for time in (True,math.nan,math.inf,-1,3):
        refused('snapshot clock '+str(time),lambda t=time:session.snapshot(t))
        refused('feedback clock '+str(time),lambda t=time:session.public_feedback(t))
    detached=session.public_models();detached['bindings'].clear();check(bool(session.public_models()['bindings']),'Public model detached','public')
    def late(wp,ip):ip['profile']['bindings'][0].update(arrival_latency_s=1,validity_s=.25)
    late_session,late_rows=harness('late-expired-confirmation',late,times=(0,1,1.25,2.25,3.25))
    feedback=late_rows[-1]['feedback'][0];reading=late_rows[-1]['snapshot']['records'][0]
    check(reading['valid_until_s']==2.5 and reading['arrived_at_s']==3.25 and reading['availability']=='expired','Late validity not refreshed','gate_harness')
    check(feedback['confirmation']=='CONFIRMED_BELOW_THRESHOLD' and not feedback['current_confirmation'],'Historical confirmation not current authorization','public')
    check(feedback['provenance']==reading['provenance'] and not feedback['additional_evidence_factor'],'Feedback not independent observation','public')
    def unknown(wp,ip):ip['profile']['bindings'][0]['condition_range']=[1,2]
    unknown_session,unknown_rows=harness('condition-unknown',unknown)
    r=unknown_rows[-1]['snapshot']['records'][0]
    check(r['value'] is None and r['quality']['status']=='unknown','Condition-ineligible reading remains unknown','gate_harness')
    check(r['quality']['note']==rows[-1]['snapshot']['records'][0]['quality']['note'],'No private failure reason in quality note','public')
    check(unknown_rows[-1]['feedback'][0]['confirmation']=='UNCONFIRMED','Unknown not confirmed','public')
    def binary(wp,ip):
        task=wp['submissions'][0]['task'];task.update(target_id='immersion',work_interface_id='inspect_equipment_environment',
            crew=[dict(worker_id='worker_cooling',qualification_id='qualified_cooling_inspection')],tool_carrier_id='worker_cooling')
        ip['profile']['bindings'][0].update(model_id='threshold-miss',condition_range=[250,400],confirmation_threshold=290)
    binary_session,binary_rows=harness('threshold-false-negative',binary,times=(0,1,1.25,2.5,3.5,4),temp=True)
    r=binary_rows[-1]['snapshot']['records'][0]
    check(r['value'] is False and r['quality']['status']=='reported','False is a valid threshold report','gate_harness')
    check(r['observed_at_s']==3.5 and r['arrived_at_s']==4 and binary_rows[-1]['feedback'][0]['confirmation']=='UNCONFIRMED','Binary report does not invent diagnosis','public')
    # Closed binding/attestation refusal occurs before any physical or sampled point.
    constructor_cases={
        'caller-completion-token':lambda wp,ip:ip.update(completion_token={'status':'COMPLETED'}),
        'wrong-target':lambda wp,ip:wp['submissions'][0]['task'].update(target_id='filter'),
        'wrong-tool':lambda wp,ip:ip['profile']['bindings'][0].update(tool_id='tool_it_diagnostic'),
        'wrong-qualification':lambda wp,ip:ip['profile']['bindings'][0].update(qualification_id='qualified_it_inspection'),
        'false-minimum-work':lambda wp,ip:ip['profile']['bindings'][0].update(minimum_work_s=False),
        'private-model-field':lambda wp,ip:ip['profile']['nonfixed_profile']['models'][-1]['model'].update(actual_fault='filter')}
    for name,mutate in constructor_cases.items():
        wp=deepcopy(inputs['work_program']);ip=deepcopy(inputs['inspection_program']);mutate(wp,ip)
        refused(name,lambda w=wp,i=ip:InspectionSession(inputs['model'],w,i))
    refused('fake-executor',lambda:session.process(2.75,{'records':[{'status':'completed'}]},{'time_s':2.75}))
    check(not keys(session.public_models()) & {'seed','bias','noise_half_width','private_draw','authorized_raw_signal'},'Public declared models no private realization','public')
    return rows[-1]['snapshot']['records'][0]

def check_gateway(inputs,run):
    from aegis_dc.evidence_ledger import EvidenceLedger,RECORD_FIELDS
    from aegis_dc.decision_view import DecisionGateway
    from aegis_dc.belief import infer_belief
    registry=deepcopy(inputs['inspection_program']['profile']['nonfixed_profile']['registry'])
    # Static declaration union, not any hidden state or future label.
    for path,key in (('configs/full-facility-decision-v1/common-ledger.json',None),('configs/full-facility-sensor-channels-v1.json','ledger')):
        source=read(EXPORT/path);source=source[key] if key else source
        for field in ('sources','observables'):
            known={x['id']:x for x in registry[field]}
            for row in source[field]:
                if row['id'] in known:check(row==known[row['id']],'Static shared identity consistency','public')
                else:registry[field].append(row)
    record=run['inspection_public_snapshot']['records'][0]
    registry['records']=[{key:record[key] for key in RECORD_FIELDS}]
    plan=dict(schema='aegisdc-public-preparation-plan-v1',id='independent22-arrival',basis='synthetic_assumption',time_unit='s',
        decision_times_s=[math.nextafter(2.75,-math.inf),2.75],requests=[])
    nominal=inputs['work_program']['submissions'][0]['frame']['nominal_knowledge']
    gateway=DecisionGateway(nominal,registry,plan)
    before,after=gateway.next_frame(),gateway.next_frame()
    check(before['evidence']['records']==[] and len(after['evidence']['records'])==1,'Real produced record enters public gateway only after arrival','public')
    belief=read(EXPORT/'configs/full-facility-belief-model-v1.json');belief['scope']['ledger_id']=registry['id']
    first,last=infer_belief(before,belief),infer_belief(after,belief)
    check(first['posterior']==last['posterior'] and first['status']==last['status']=='PRIOR_PREDICTION','Unsupported flow is not a hidden cause oracle','public')
    check(last['information_updates']==[] and last['record_audit'][0]['disposition']=='unsupported_channel','Unsupported real evidence remains audited','public')
    RAW['gateway']=dict(before=before,after=after,belief_before=first,belief_after=last)

def main():
    manifest=read(OUT/'export-manifest.json')['files'];before={n:digest((EXPORT/n).read_bytes()) for n in manifest}
    check(before==manifest,'Export equals immutable source blobs before','guard')
    inputs,run=check_saved();completion_gates(inputs);check_gateway(inputs,run)
    after={n:digest((EXPORT/n).read_bytes()) for n in manifest};check(after==before,'Export source bytes unchanged after','guard')
    write_new(OUT/'raw-records.json',RAW)
    result=dict(schema='aegisdc-ticket22-independent-spec-review-v1',status='PASS',source=SOURCE,data_delivery=DELIVERY,
        assertions=sum(COUNT.values()),assertions_by_category=COUNT,export_guarded_files=len(manifest),source_guards_equal=True,
        new_physical_runs=0,full_regression_runs=0,author_capture_reruns=0,registered_research_trials=0,llm_calls=0,training_calls=0,
        scope='Immutable coupled-plant data plus declared private completion-gate harness and public14/15/18 reads; no new physical trajectory',findings=[])
    write_new(OUT/'probe-result.json',result);print(json.dumps(result))
if __name__=='__main__':main()
