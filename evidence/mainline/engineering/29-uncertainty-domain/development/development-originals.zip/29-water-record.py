from pathlib import Path
from hashlib import sha256
import json, os, subprocess, sys

stage, source = sys.argv[1:3]
root = Path.cwd()
def git(*args):
    return subprocess.check_output(['git',*args]).decode().strip()
assert git('rev-parse','HEAD') == source and not git('status','--porcelain')
out=root/'.work'/f'29-water-{stage}'
out.mkdir(parents=True)
files=['tests/test_water_envelope.py','src/aegis_dc/scenario.py',
       'src/aegis_dc/thermodynamics.py','src/aegis_dc/heat_transfer.py','src/aegis_dc/time_coordinates.py','configs/full-facility-mainline-reserve-v6.json',
       'configs/materials/reference-r134a-saturation.json']
implementation='src/aegis_dc/water_envelope.py'
if (root/implementation).is_file():
    files.append(implementation)
pins={n:sha256((root/n).read_bytes()).hexdigest() for n in files}
args=[sys.executable,'-B','-X','utf8','-m','unittest','discover','-s','tests',
      '-p','test_water_envelope.py','-v']
env=dict(os.environ,PYTHONPATH=str(root/'src'),PYTHONDONTWRITEBYTECODE='1',
         PYTHONPYCACHEPREFIX=str(out/'fresh-cache-prefix'),PYTHONHASHSEED='0')
def write(n,v):
    with (out/n).open('x',encoding='utf-8',newline='\n') as f:
        f.write(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
write('attempt.json',dict(status='STARTED',source=source,argv=args,pins=pins,scope='FINITE_WATER_ENVELOPE_DEVELOPMENT',
                          physical_runs=0,registered_research_trials=0))
p=subprocess.run(args,cwd=root,env=env,capture_output=True)
(out/'stdout.raw').write_bytes(p.stdout)
(out/'stderr.raw').write_bytes(p.stderr)
same=git('rev-parse','HEAD')==source and not git('status','--porcelain') and all(
    sha256((root/n).read_bytes()).hexdigest()==sha for n,sha in pins.items())
write('terminal.json',dict(status='PASS' if not p.returncode and same else 'FAIL',source=source,
    returncode=p.returncode,source_guard=same,physical_runs=0,registered_research_trials=0,
    stdout_sha256=sha256(p.stdout).hexdigest(),stderr_sha256=sha256(p.stderr).hexdigest()))
print((p.stdout+p.stderr).decode('utf-8'))
if not same:
    raise SystemExit(9)
raise SystemExit(p.returncode)
