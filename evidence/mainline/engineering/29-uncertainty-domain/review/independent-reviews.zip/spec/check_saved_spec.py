"""Independently reconstruct raw saved ticket 29 engineering balances; no facility imports."""
from hashlib import sha256
import json
from math import fsum, isfinite
from pathlib import Path
import subprocess
import sys

repo = Path(sys.argv[1])
delivery = sys.argv[2]
source = '718ffa9cc7ed5ca1e6738a284b11112179ffcb91'
folder = 'evidence/mainline/engineering/29-uncertainty-domain/capture-01'
prep = 'evidence/mainline/engineering/29-uncertainty-domain/prepared-01/cases'
protocol = 'docs/mainline/29-domain-engineering-protocol.json'
checks = 0


def check(value, desc):
    global checks
    if not value:
        raise ValueError(desc)
    checks += 1


def near(a, b, tol, desc):
    check(isfinite(a) and isfinite(b) and abs(a-b) <= tol, f'{desc}: {a!r}, {b!r}')


def git(*args):
    return subprocess.check_output(['git',*args],cwd=repo)


def raw(name, rev=delivery):
    data=git('cat-file','blob',f'{rev}:{name}')
    if rev==delivery:
        check((repo/name).read_bytes()==data,'Saved bytes differ from Git: '+name)
    return data


def doc(name, rev=delivery):
    return json.loads(raw(name,rev))


def rows(name):
    return [json.loads(line) for line in raw(name).splitlines()]


check(not git('merge-base','--is-ancestor',source,delivery),'original source lineage')
spec=doc(protocol,source)
receipt=doc(f'{folder}/receipt.json')
check(receipt['execution_commit']==source and receipt['source_unchanged'] and receipt['status']=='PASS','capture authority')
check(receipt['started']==receipt['passed']==8 and receipt['charged_simulated_s']==33,'capture budget')
check(all(receipt[k]==0 for k in ('registered_research_trials','dispatch_calls','model_calls','training_calls')),'engineering scope')
for role, names in receipt['pinned'].items():
    for name, expected_sha in names.items():
        check(sha256(raw(name,source)).hexdigest()==expected_sha,'execution SHA: '+role+'/'+name)
        check(sha256(raw(name)).hexdigest()==expected_sha,'delivery SHA: '+role+'/'+name)
names={name.decode().removeprefix(folder+'/') for name in git('ls-tree','-rz','--name-only',delivery,folder).split(b'\0') if name}
check(names==set(receipt['artifacts'])|{'receipt.json'},'durable capture set')
for name,expected_sha in receipt['artifacts'].items():
    check(sha256(raw(f'{folder}/{name}')).hexdigest()==expected_sha,'artifact hash '+name)
ledger=rows(f'{folder}/attempts.jsonl')
check(len(ledger)==16,'ledger row count')
authored=doc(f'{folder}/checks.json')
results={}
for i, case in enumerate(spec['cases'],1):
    name=case['id']
    a,b=ledger[2*i-2:2*i]
    check((a['status'],b['status'])==('STARTED','PASS') and a['attempt']==b['attempt']==i
          and a['case_id']==b['case_id']==name and b['returned'] is True
          and a['simulated_charge_s']==case['seconds'],'attempt order '+name)
    prefix=f'{folder}/{name}'
    run=doc(f'{prefix}/run.json')
    scenario=doc(f'{prefix}/scenario.json')
    init=doc(f'{prep}/{name}.json',source)
    trace=rows(f'{prefix}/private-state.jsonl')
    balances=rows(f'{prefix}/balances.jsonl')
    check(scenario==init['scenario'] and run['inputs']['boundary_events']==init['boundary_events'],'frozen inputs '+name)
    check(run['engineering_fixture'] is True and run['state_visibility']=='PRIVATE_PLANT_EVALUATOR_ONLY'
          and run['dispatch_interface']=='DISABLED_FOR_THIS_RUN' and not run['work_records']
          and run['research_trials']==run['model_calls']==run['training_calls']==0,'no hidden decision or external calls '+name)
    check(run['code_identity']['files']==receipt['pinned']['runtime'] and
          run['code_identity']['git_commit']==source and run['code_identity']['implementation_has_changes'] is False,
          'run source '+name)
    check(len(trace)==len(balances)+1 and trace[0]['time_s']==0 and trace[-1]['time_s']==case['seconds'],'complete trace '+name)
    model_domains={r['id'] for r in scenario['domains']}
    expected_events=init['boundary_events']
    applied=[r for r in run['events'] if r['kind']=='exogenous_boundary_input']
    check(len(applied)==len(expected_events),'event count '+name)
    time_set={t['time_s'] for t in trace}
    for before,event in zip(expected_events,applied):
        check({k:event[k] for k in before}==before and event['applied_at_s'] in time_set,'event identity '+name)
        near(event['applied_at_s'],event['time_s'],2e-10,'applied time '+name)
    base_p={r['id']:r['value'] for r in scenario['parameters']}
    p=dict(base_p)
    event_index=0
    offers,deliveries,deficits,boundary_ins,boundary_outs=[],[],[],[],[]
    max_mass,max_component,max_whole_step,max_power=0.,0.,0.,0.
    last_after=None
    for left,right,balance in zip(trace,trace[1:],balances):
        t=left['time_s']
        while event_index<len(applied) and applied[event_index]['applied_at_s']<=t:
            e=applied[event_index]
            p[e['parameter_id']]=e['value']
            event_index+=1
        dt=right['time_s']-t
        check(balance['start_s']==t and balance['end_s']==right['time_s'] and 0<dt<=.0100000002,'step clock')
        d=left['domains']
        check(set(d)==model_domains,'all eight domains')
        power=d['power']
        actual=power['actual_powers_W']
        service=d['it_service']
        cap=[min(p[k+'_service_capacity'],actual[k]/p[k+'_nominal_power']) for k in ('compute','network','storage')]
        demand=p['service_demand']
        served=min(demand,*cap)
        near(service['demand'],demand,0,'external demand')
        near(service['delivered'],served,1e-12,'actual capacity service')
        offers.append(demand*dt)
        deliveries.append(served*dt)
        deficits.append((demand-served)/demand*dt if demand else 0.)
        for k,v in zip(('demand_service_unit_s','delivered_service_unit_s','service_deficit_time_s'),
                       (offers[-1],deliveries[-1],deficits[-1])):
            near(balance[k],v,1e-10,'interval service integral '+k)
        if not p['shared_distribution_available']:
            check(power['grid_draw_W']==power['generator_output_W']==power['ups_protected_output_W']==served==0,
                  'common path disconnect')
        # Read primitive balance rows, rather than accepting the reported max residuals.
        st0,st1=balance['storage_before_J'],balance['storage_after_J']
        check(set(st0)==set(st1)==set(balance['component_energy_rates_W']),'storage accounting completeness')
        if last_after is not None:
            check(st0==last_after,'continuous storage ledger')
        last_after=st1
        for k, rate in balance['component_energy_rates_W'].items():
            resid=(st1[k]-st0[k])-rate*dt
            near(resid,balance['energy_residuals_J'][k],1e-9,'component stored energy '+k)
            max_component=max(max_component,abs(resid))
        inbound=fsum((power['grid_draw_W']*dt,balance['floor_inlet_energy_J']))
        outbound=fsum(balance[k] for k in ('lake_heat_J','room_heat_J','generator_waste_energy_J',
                       'floor_drain_energy_J','backup_water_heat_J','reserve_external_electric_heat_J'))
        near(inbound,balance['boundary_input_J'],1e-9,'gross energy input')
        near(outbound,balance['boundary_output_J'],1e-9,'gross energy output')
        boundary_ins.append(inbound)
        boundary_outs.append(outbound)
        e_resid=fsum([*st1.values(),*(-v for v in st0.values()),-inbound,outbound])
        max_whole_step=max(max_whole_step,abs(e_resid))
        electric=fsum([power['grid_draw_W'],power['generator_output_W'],power['ups_output_W'],
                       power['starter_output_W'],-power['rectifier_loss_W'],*(-v for v in actual.values())])
        near(electric,balance['electrical_residual_W'],2e-9,'electrical allocation')
        max_power=max(max_power,abs(electric))
        check(set(balance['mass_accounts_kg'])==set(balance['mass_residuals_kg']),'mass accounting completeness')
        for k, m in balance['mass_accounts_kg'].items():
            resid=fsum([m['before_kg'],m['in_kg'],-m['out_kg'],-m['after_kg']])
            near(resid,balance['mass_residuals_kg'][k],1e-15,'raw mass '+k)
            max_mass=max(max_mass,abs(resid))
        phase=d['equipment_environment']['refrigerant']
        x=phase['quality']
        near(fsum([phase['liquid_mass_kg'],phase['vapor_mass_kg']]),p['coolant_inventory'],1e-9,'mixture mass')
        near(fsum([phase['liquid_mass_kg']*phase['v_l_m3_kg'],phase['vapor_mass_kg']*phase['v_v_m3_kg']]),
             p['coolant_control_volume'],1e-10,'mixture volume')
        near(fsum([phase['liquid_mass_kg']*phase['u_l_J_kg'],phase['vapor_mass_kg']*phase['u_v_J_kg']]),
             phase['internal_energy_J'],1e-6*p['coolant_inventory'],'mixture energy')
        check(0<=x<=1 and 1e5<=phase['pressure_Pa']<=3e6,'phase applicability')
    limits=spec['limits']
    check(max(max_component,max_whole_step)<=limits['step_energy_residual_J'],'independent step energy')
    check(max_mass<=limits['mass_residual_kg'],'independent step mass')
    initial,terminal=balances[0]['storage_before_J'],balances[-1]['storage_after_J']
    whole=fsum([*terminal.values(),*(-v for v in initial.values()),*boundary_outs,*(-v for v in boundary_ins)])
    check(abs(whole)<=limits['whole_energy_residual_J'],'independent entire-run energy')
    near(fsum(offers),case['offered'],1e-9,'literal offered')
    check(case['delivered'][0]-1e-9<=fsum(deliveries)<=case['delivered'][1]+1e-9,'frozen literal delivered')
    for key,got in (('offered_service_unit_s',fsum(offers)),('delivered_service_unit_s',fsum(deliveries)),
                    ('deficit_time_s',fsum(deficits))):
        near(got,authored[name][key],1e-9,'independent metric vs author '+key)
    observed={}
    if name=='warm-restricted-intake':
        by_time={row['time_s']:row['domains']['facility_cooling']['lake_pump'] for row in trace}
        observed['intake_flow_m3_s']=[]
        for t,expected in zip([0,*[x['applied_at_s'] for x in applied]],[1/100,1/340,9/3200]):
            pump=by_time[t]
            near((pump['volume_flow_m3_s']/pump['speed'])**2,expected,1e-12,'causal lake response')
            observed['intake_flow_m3_s'].append([t,pump['volume_flow_m3_s']])
    if name=='wet-access-slow-work':
        closed=[e['applied_at_s'] for e in run['events'] if e['kind']=='floor_access_closed']
        check(len(closed)==1,'single closure')
        near(closed[0],2.5,2e-10,'analytic access time')
        near(trace[-1]['domains']['space_access']['floor_water_mass_kg'],10.2,1e-9,'analytic terminal floor mass')
        near(fsum(b['internal_hot_leaked_mass_kg'] for b in balances),.9,1e-9,'leak total')
        observed['closure_s']=closed[0]
    if name=='local-sensor-loss':
        fresh=[(x['time_s'],x['domains']['control_monitoring']) for x in trace
               if x['domains']['control_monitoring']['local_measurement']['sampled_at_s']==x['time_s']]
        check(len(fresh)==5,'PLC clock count')
        for i_s,(t,c) in enumerate(fresh):
            near(t,i_s,2e-10,'PLC clock epoch')
            check(c['compute_permitted']==(i_s not in (1,2)) and
                  c['supervisory_mode']==('autonomous' if i_s in (1,2,3) else 'connected'),'local protection independence')
        observed['permitted_by_local_sample']=[[t,c['compute_permitted']] for t,c in fresh]
    results[name]={'intervals':len(balances),'offered':fsum(offers),'delivered':fsum(deliveries),
        'normalized_deficit_s':fsum(deficits),'independent_boundary_residual_J':whole,
        'max_component_residual_J':max_component,'max_boundary_step_residual_J':max_whole_step,
        'max_mass_residual_kg':max_mass,'max_electrical_residual_W':max_power,'specific_witnesses':observed}
result={'status':'PASS_INDEPENDENT_SAVED_ENGINEERING_SPEC','physical_source':source,'capture_delivery':delivery,
        'checks':checks,'physical_runs':0,'dispatch_runs':0,'research_trials':0,'case_results':results}
with Path(sys.argv[3]).open('x',encoding='utf-8',newline='\n') as stream:
    json.dump(result,stream,ensure_ascii=False,indent=2,allow_nan=False)
    stream.write('\n')
print(json.dumps({'status':result['status'],'checks':checks,'intervals':sum(x['intervals'] for x in results.values())}))
