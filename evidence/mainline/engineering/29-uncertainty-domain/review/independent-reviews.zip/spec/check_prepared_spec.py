"""Independent saved-input audit of ticket 29; never imports the facility."""
import hashlib
import json
import math
from pathlib import Path
import subprocess
import sys
from fractions import Fraction

repo = Path(sys.argv[1])
revision = sys.argv[2]
base = '03e2e3e0e42f468733356dee1bb68cd259aeff1e'
where = 'evidence/mainline/engineering/29-uncertainty-domain'
declaration_path = 'configs/full-facility-parameter-domain-v1.json'
protocol_path = 'docs/mainline/29-domain-engineering-protocol.json'
baseline_path = 'configs/full-facility-mainline-reserve-v6.json'
checks = 0


def check(value, message):
    global checks
    if not value:
        raise ValueError(message)
    checks += 1


def git(*args):
    return subprocess.check_output(['git', *args], cwd=repo)


def blob(path):
    return git('cat-file', 'blob', f'{revision}:{path}')


def doc(path):
    return json.loads(blob(path))


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def load(path):
    return json.loads(path.read_bytes())


def params(model):
    return {row['id']: row for row in model['parameters']}


def near(left, right, tol, message):
    check(abs(left-right) <= tol, message)


def coincident(a, b):
    return abs(a-b) <= 8*max(math.ulp(a),math.ulp(b))


def clock(horizon, events):
    # Minimal time-grid counterexample: no plant, events, or policies executed.
    now, sample, index = 0., 0, 0
    times = []
    while True:
        while index < len(events) and (now >= events[index] or coincident(now,events[index])):
            index += 1
        if now >= sample or coincident(now,sample):
            sample += 1
        times.append(now)
        if now == horizon:
            return times
        now = min(now+.01, sample, events[index] if index<len(events) else horizon,horizon)


check(not git('merge-base','--is-ancestor',base,revision), 'base not ancestor')
protocol = doc(protocol_path)
declaration = doc(declaration_path)
baseline = doc(baseline_path)
table_path = baseline['runtime']['property_table']
table = doc(table_path)
p = {k:v['value'] for k,v in params(baseline).items()}
check(sha(blob(table_path)) == baseline['runtime']['property_sha256'], 'property SHA')
check({r['id'] for r in baseline['domains']} == {
    'power','backup','facility_cooling','equipment_environment','it_service','control_monitoring','space_access','people_tools_work'
},'8 domains')
check(set(baseline['graphs']) == {'physical','functional','control_information','access'},'4 relations')
check(len(baseline['site_gaps']) == 4 and all(r['value'] is None for r in baseline['site_gaps']),'site gaps')
expected = {
    'nominal':4, 'cooler-light-demand':4, 'warm-restricted-intake':4.5, 'shared-path-loss':4,
    'capacity-limited':3, 'wet-access-slow-work':4.5, 'local-sensor-loss':4,'coupled-adverse':5,
}
check(expected == {r['id']:r['seconds'] for r in protocol['cases']}, 'fixed durations')
check(sum(expected.values()) == protocol['budget']['simulated_duration_s'] == 33, 'fixed seconds')
check(list(expected) == [r['id'] for r in declaration['cases']], 'case order')
for name, expected_sha in declaration['references_sha256'].items():
    check(sha(blob(name)) == expected_sha, 'reference SHA: '+name)
for ref in [declaration_path, protocol_path, baseline_path, table_path, 'src/aegis_dc/parameter_domain.py',
            'src/aegis_dc/refrigerant_initialization.py','src/aegis_dc/water_envelope.py','src/aegis_dc/plant.py']:
    check(sha(blob(ref)) == sha((repo/ref).read_bytes()), 'live source mismatch: '+ref)
for name in ('registered_research_trials','dispatch_calls','model_calls','training_calls'):
    check(protocol['budget'][name] == 0, 'unexpected call allowance: '+name)

boundaries = {}
for case in declaration['cases']:
    for key, val in case['initial_overrides'].items():
        lo, hi = params(baseline)[key]['valid_range']
        check(lo <= val <= hi, f'{case["id"]} override range {key}')
    for e in case['boundary_events']:
        lo, hi = params(baseline)[e['parameter_id']]['valid_range']
        check(lo <= e['value'] <= hi and 0 <= e['time_s'] <= case['duration_s'],'schedule range')
    raw_times = clock(case['duration_s'],[r['time_s'] for r in case['boundary_events']])
    for when in (2.25,2.5,3.,4.):
        cluster = [t for t in raw_times if abs(t-when)<=2e-10]
        if len(cluster)>1:
            boundaries.setdefault(case['id'],{})[str(when)] = cluster
check(len(boundaries['warm-restricted-intake']['2.5']) == 2,'distinct warm clock witness')
check(len(boundaries['local-sensor-loss']['2.25']) == 2,'distinct local clock witness')
check(len(boundaries['local-sensor-loss']['3.0']) == 2,'distinct PLC clock witness')

head = Fraction(p['pump_pressure_rise'])
r_passive = Fraction(p['lake_hydraulic_resistance'])
r_valve = Fraction(p['lake_valve_open_resistance'])
hydraulic = [head/(r_passive*mul+r_valve/(aperture*aperture)) for mul,aperture in
             [(1,Fraction(1)),(4,Fraction(1)),(4,Fraction(3,4))]]
check(hydraulic == [Fraction(1,100),Fraction(1,340),Fraction(9,3200)],'independent intake law')
witness = {c['id']:c for c in protocol['cases']}
for (_, coeff), rational in zip(witness['warm-restricted-intake']['flow_squared_over_realized_speed_squared'],hydraulic):
    check(float(rational) == coeff, 'frozen intake oracle')
near(witness['capacity-limited']['delivered'][1],3*350_000/p['compute_nominal_power'],1e-12,'grid bound')
near(witness['coupled-adverse']['delivered'][1],1.5*.5+3.5*900_000/p['compute_nominal_power'],1e-12,'coupled bound')
near(witness['wet-access-slow-work']['floor']['open_until_s'],(p['access_block_mass']-9.75)/(.2-.1),1e-12,'floor crossing')
near(witness['wet-access-slow-work']['floor']['terminal_mass_kg'],9.75+4.5*(.2-.1),1e-12,'floor inventory')
near(witness['wet-access-slow-work']['floor']['leaked_kg'],4.5*.2,1e-12,'hot debit')
q_bad=(p['coolant_control_volume']/500-table['rows'][-1]['v_l_m3_kg']) / (
        table['rows'][-1]['v_v_m3_kg']-table['rows'][-1]['v_l_m3_kg'])
check(q_bad > 1,'scalar legal but jointly impossible phase')
check(1_000_000/p['coolant_inventory'] < min(row['u_l_J_kg'] for row in table['rows']),'incompatible scalar energy')

prep = repo/where/protocol['prepared_directory']
receipt=load(prep/'receipt.json')
check(receipt['status']=='PASS' and receipt['source_unchanged'] and receipt['execution_commit']==revision,'prep receipt')
check(receipt['started']==receipt['passed']==8 and receipt['charged_simulated_s']==0,'prep ledger')
attempts=[json.loads(x) for x in (prep/'attempts.jsonl').read_bytes().splitlines()]
check(len(attempts)==16,'prep ledger rows')
for name, value in receipt['artifacts'].items():
    check(sha((prep/name).read_bytes())==value,'prep saved SHA '+name)
for role, files in receipt['pinned'].items():
    for name,value in files.items():
        check(sha(blob(name))==value,'prep revision SHA '+role+'/'+name)
case_out={}
nominal = doc(declaration['public_nominal_reference'])
channels = doc(declaration['fixed_sensor_reference'])
for i, row in enumerate(declaration['cases'],1):
    name=row['id']
    item=load(prep/'cases'/f'{name}.json')
    check(item['case_id']==name and item['duration_s']==expected[name],'prepared ID/time')
    check(item['boundary_events']==row['boundary_events'],'prepared schedule')
    check(item['declaration_sha256']==sha(blob(declaration_path)),'prepared config SHA')
    a,b=attempts[2*i-2:2*i]
    check(a['case_id']==b['case_id']==name and a['attempt']==b['attempt']==i
          and a['status']=='STARTED' and b['status']=='PASS' and b['returned'] is True,
          'prepare lifecycle '+name)
    scenario=item['scenario']
    check({k:v for k,v in scenario.items() if k!='parameters'}==
          {k:v for k,v in baseline.items() if k!='parameters'},'unchanged topology, sources and site gaps '+name)
    differing=set(row['initial_overrides']) | ({'coolant_inventory','coolant_initial_energy'} if row['phase'] else set())
    check({k for k,v in params(scenario).items() if v!=params(baseline)[k]}==differing,'exact parameter-row changes '+name)
    for key,value in row['initial_overrides'].items():
        check(params(scenario)[key]['value']==value,'override matches '+key)
    public=item['public_static']
    check(set(public)=={'nominal_knowledge','workforce_profile','fixed_sensor_profile'},'static public surface')
    check(public['nominal_knowledge']==nominal,'static nominal knowledge')
    fixed=public['fixed_sensor_profile']
    check(set(fixed)==set(channels) and all(fixed[k]==v for k,v in channels.items() if k!='measurements'),'fixed profile metadata')
    check(not fixed['ledger']['records'],'fixed profile invents no evidence')
    check(len(fixed['measurements'])==len(channels['measurements']),'measurement set')
    for got, prior in zip(fixed['measurements'],channels['measurements']):
        check(got==dict(prior,enabled=prior['id'] in row['enabled_fixed_measurements']),'static measurement '+prior['id'])
    initial=item['initialization']['phase']
    check(0<initial['quality']<1 and initial['volume_m3']==p['coolant_control_volume'],'interior fixed phase')
    if row['phase']:
        requested=row['phase']
        line=next(r for r in table['rows'] if r['p_Pa']==requested['pressure_Pa'])
        volume_per_kg=p['coolant_control_volume']/requested['mass_kg']
        mix=(volume_per_kg-line['v_l_m3_kg'])/(line['v_v_m3_kg']-line['v_l_m3_kg'])
        energy=requested['mass_kg']*((1-mix)*line['u_l_J_kg']+mix*line['u_v_J_kg'])
        near(initial['quality'],mix,1e-11,'phase volume mixture')
        near(initial['internal_energy_J'],energy,1e-5,'phase energy mixture')
    case_out[name]={'duration_s':item['duration_s'],'phase':initial,
                    'enabled_public_channels':row['enabled_fixed_measurements']}
shared=load(prep/'cases/shared-path-loss.json')['initialization']['power_and_service']['regimes']
check([r['grid_path_upper_W'] for r in shared]==[10_000_000,0,10_000_000],'shared grid declaration')
check([r['ups_protected_path_upper_W'] for r in shared]==[100_000,0,100_000],'shared UPS declaration')
check([r['diesel_path_upper_W'] for r in shared]==[4_000_000,0,4_000_000],'shared diesel declaration')
check([r['offered_demand'] for r in shared]==[1,1,1],'shared demand retained')
wet=load(prep/'cases/wet-access-slow-work.json')['initialization']['water']['hot_inventory']
near(wet['declared_loss_kg'],.9,1e-12,'wet static debit')
result={'status':'PASS_FINITE_SOURCE_AND_PREPARED_INPUT_SPEC','base':base,'revision':revision,
        'checks':checks,'new_physical_calls':0,'new_dispatch_calls':0,'new_registered_trials':0,
        'independent_requested_hydraulic_ratios':list(map(str,hydraulic)),
        'invalid_500kg_3MPa_quality':q_bad,'distinct_clock_counterexamples':boundaries,
        'cases':case_out,'scope':'Read Git blobs and original prepared bytes; no dynamic qualification or policy benefit.'}
with Path(sys.argv[3]).open('x',encoding='utf-8',newline='\n') as stream:
    json.dump(result,stream,ensure_ascii=False,indent=2,allow_nan=False)
    stream.write('\n')
print(json.dumps({k:result[k] for k in ('status','revision','checks','new_physical_calls')}))
