"""Independent read-only provenance and prepared-case review; stdlib and Git only."""
from datetime import datetime
from hashlib import sha256
import io
import json
from pathlib import Path
import subprocess
from zipfile import ZipFile

ROOT = Path('C:/Users/Donson/.codex/worktrees/mainline29-uncertainty-domain/Renly')
BASE = '03e2e3e0e42f468733356dee1bb68cd259aeff1e'
ORIGINAL = '72f7ff86af73f43c7736e2c93ece5705c3b2ac8c'
SOURCE = '902b9423cdf1b6fb250f4fa1eb75e73153cae047'
DELIVERY = '718ffa9cc7ed5ca1e6738a284b11112179ffcb91'
PREFIX = 'evidence/mainline/engineering/29-uncertainty-domain'
PREP = PREFIX + '/prepared-01'
COUNTS = {}


def check(value, name):
    if not value:
        raise ValueError(name)
    COUNTS[name] = COUNTS.get(name, 0) + 1


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)


def blob(path, revision=DELIVERY):
    return git('cat-file', 'blob', f'{revision}:{path}')


def document(path, revision=DELIVERY):
    return json.loads(blob(path, revision))


def sha(data):
    return sha256(data).hexdigest()


def files(folder, revision=DELIVERY):
    return set(git('ls-tree', '-r', '-z', '--name-only', revision, folder).decode().strip('\0').split('\0'))


check(not git('diff', '--check', f'{BASE}...{DELIVERY}'), 'Git diff whitespace')
check(not git('merge-base', '--is-ancestor', SOURCE, DELIVERY), 'source is delivery ancestor')
check(git('rev-parse', 'pre-meeting-20261103^{}').decode().strip() ==
      '076d9aa15c5bc99a5b7985f296e15543b7b0f3d7', 'historical tag peeled target')
receipt = document(f'{PREP}/receipt.json')
check(receipt['execution_commit'] == SOURCE and receipt['status'] == 'PASS'
      and receipt['mode'] == 'prepare' and receipt['source_unchanged']
      and receipt['charged_simulated_s'] == receipt['registered_research_trials'] ==
          receipt['dispatch_calls'] == receipt['model_calls'] == receipt['training_calls'] == 0,
      'execution source and zero-call boundaries')
check(set(receipt['pinned']) == {'runtime', 'bootstrap', 'tools', 'inputs'}, 'pin roles')
check(set(receipt['pinned']['bootstrap']) == {'src/patrol_rsi/__init__.py'}
      and 'src/aegis_dc/__init__.py' in receipt['pinned']['runtime']
      and 'src/patrol_rsi/contracts.py' in receipt['pinned']['runtime'], 'dependency bootstrap')
check(not Path(receipt['unused_pycache_prefix']).exists(), 'cache prefix remains unused')
for role, pins in receipt['pinned'].items():
    for path, expected in pins.items():
        check(expected == sha(blob(path, SOURCE)) == sha(blob(path)) ==
              sha((ROOT / path).read_bytes()), 'exact execution and delivery pins: ' + role)

protocol = document('docs/mainline/29-domain-engineering-protocol.json')
declaration = document(protocol['declaration'])
expected = {f'cases/{case["id"]}.json' for case in declaration['cases']} | {'attempts.jsonl'}
check(set(receipt['artifacts']) == expected and files(PREP) ==
      {f'{PREP}/{name}' for name in expected | {'receipt.json'}}, 'exact durable set')
for path, expected in receipt['artifacts'].items():
    full = f'{PREP}/{path}'
    check(expected == sha(blob(full)) == sha((ROOT / full).read_bytes()), 'durable prepared artifact')
check(not any('__pycache__' in path.split('/') or path.endswith(('.pyc', '.pyo'))
              for path in files(PREFIX)), 'no delivered runtime caches')
attempts = [json.loads(line) for line in blob(f'{PREP}/attempts.jsonl').splitlines()]
check(len(attempts) == 16 and receipt['started'] == receipt['passed'] == 8, 'attempt totals')
check(all(datetime.fromisoformat(a['recorded_at_utc']) <= datetime.fromisoformat(b['recorded_at_utc'])
          for a,b in zip(attempts,attempts[1:])), 'lifecycle chronology')
baseline = document(declaration['baseline'])
nominal = document(declaration['public_nominal_reference'])
inventory = document(f'{PREFIX}/reference/v6-parameter-inventory-v1.json')
check(inventory['basis_counts'] == {'derived_reference':7,'synthetic_assumption':106}
      and inventory['calibrated_site_parameter_count'] == 0
      and len(inventory['site_gaps']) == 4
      and all(row['value'] is None for row in inventory['site_gaps'].values()), 'inventory/site separation')
for path, expected in inventory['source_pins'].items():
    check(expected == sha(blob(path)), 'inventory provenance pin')

for i, case in enumerate(declaration['cases']):
    start, terminal = attempts[i*2:i*2+2]
    case_id = case['id']
    check(start['attempt'] == terminal['attempt'] == i+1
          and start['case_id'] == terminal['case_id'] == case_id
          and start['status'] == 'STARTED' and terminal['status'] == 'PASS'
          and start['simulated_charge_s'] == 0 and terminal['returned'] is True,
          'ordered zero-physical preparation lifecycle')
    prepared = document(f'{PREP}/cases/{case_id}.json')
    scenario = prepared['scenario']
    expected_duration = protocol['cases'][i]
    check(expected_duration['id'] == case_id and expected_duration['seconds'] ==
          prepared['duration_s'] == case['duration_s']
          and prepared['maximum_step_s'] == .01, 'protocol/declared/prepared case contract')
    check(prepared['declaration_sha256'] == sha(blob(protocol['declaration']))
          and prepared['status'] == 'ADMITTED_INITIALIZATION_NOT_TRAJECTORY_QUALIFIED'
          and prepared['field_calibration'] == 'PENDING', 'preparation is not physical qualification')
    check(scenario['graphs'] == baseline['graphs'] and scenario['entities'] == baseline['entities']
          and scenario['domains'] == baseline['domains'] and scenario['site_gaps'] == baseline['site_gaps'],
          'fixed identity, topology and site gaps')
    check(prepared['boundary_events'] == case['boundary_events'], 'private exogenous input identity')
    public = prepared['public_static']
    check(set(public) == {'nominal_knowledge','workforce_profile','fixed_sensor_profile'}
          and public['nominal_knowledge'] == nominal, 'public nominal identity and limited surface')
    sensor_expected = document(declaration['fixed_sensor_reference'])
    for row in sensor_expected['measurements']:
        row['enabled'] = row['id'] in case['enabled_fixed_measurements']
    check(public['fixed_sensor_profile'] == sensor_expected
          and not public['fixed_sensor_profile']['ledger']['records'],
          'coverage change only, no observation generation')
    p = {row['id']:row['value'] for row in scenario['parameters']}
    work = public['workforce_profile']
    check(work['walk_times_s'] == {edge['id']:p[edge['duration_parameter']] for edge in scenario['graphs']['access']}
          and work['work_times_s'] == {item['id']:p[item['duration_parameter']]
             for domain in scenario['domains'] for item in domain['work_interfaces']},
          'declared public timing matches physical model')
check(sum(row['seconds'] for row in protocol['cases']) == 33
      and protocol['budget']['plant_calls'] == 8, 'fixed physical budget')

development = f'{PREFIX}/development'
dev_manifest = document(f'{development}/manifest.json')
dev_bytes = blob(f'{development}/development-originals.zip')
check(dev_manifest['archive_sha256'] == sha(dev_bytes), 'development archive identity')
with ZipFile(io.BytesIO(dev_bytes)) as z:
    check(len(z.namelist()) == len(set(z.namelist())) == len(dev_manifest['members']) == 39
          and set(z.namelist()) == set(dev_manifest['members']), '39 exact development members')
    for name, expected in dev_manifest['members'].items():
        check(expected == sha(z.read(name)), 'development member identity')
    for case, item in dev_manifest['attempts'].items():
        start = json.loads(z.read(f'{case}/attempt.json'))
        terminal = json.loads(z.read(f'{case}/terminal.json'))
        check(start['source'] == terminal['source'] == item['source']
              and terminal['status'] == item['status']
              and start['physical_runs'] == terminal['physical_runs'] == 0,
              'development execution status')
        for path, expected in start['pins'].items():
            check(expected == sha(blob(path, item['source'])), 'development exact runtime pin')
check(len(dev_manifest['attempts']) == 9
      and sum(v['status']=='FAIL' for v in dev_manifest['attempts'].values()) == 4,
      'four original development failures retained')
refusal = document(f'{development}/prepare-cli-refusal-01.json')
refusal_raw = blob(f'{development}/prepare-cli-refusal-01.zip')
check(refusal['source'] == ORIGINAL and refusal['archive_sha256'] == sha(refusal_raw)
      and refusal['initialization_calls'] == refusal['plant_calls'] == 0,
      'original launcher refusal retained')
with ZipFile(io.BytesIO(refusal_raw)) as z:
    check({name:sha(z.read(name)) for name in z.namelist()} == refusal['member'], 'refusal log identity')

near_t = 2.
for _ in range(50):
    near_t += .01
check(8 * 2**-51 < 2.5 - near_t < 2e-10, 'binary64 near point ambiguity witness')
old_checks = blob('scripts/parameter_domain_witness_checks.py', ORIGINAL)
new_checks = blob('scripts/parameter_domain_witness_checks.py', SOURCE)
check(b"abs(row['time_s']-time) <= tolerance" in old_checks
      and b"row['time_s'] == time" in new_checks
      and b"['applied_at_s']" in new_checks and b"['sampled_at_s']" in new_checks,
      'exact processing epochs replace ambiguous snapshot selection')
print(json.dumps({
    'review_axis':'Standards', 'status':'PASS_STATIC_AND_SAVED_PREPARATION',
    'base':BASE, 'original':ORIGINAL, 'execution':SOURCE, 'delivery':DELIVERY,
    'assertion_count':sum(COUNTS.values()), 'assertions':COUNTS,
    'nearby_clock_witness':near_t, 'actual_event_request_s':2.5,
    'runtime_calls':0, 'plant_calls':0, 'policy_calls':0, 'research_trials':0,
}, indent=2))
