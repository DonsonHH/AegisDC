"""Verify the sealed ticket 29 capture, without importing or running project code."""
from datetime import datetime
from hashlib import sha256
from io import BytesIO
import json
from pathlib import Path
import subprocess
from zipfile import ZipFile

ROOT = Path('C:/Users/Donson/.codex/worktrees/mainline29-uncertainty-domain/Renly')
EXECUTION = '718ffa9cc7ed5ca1e6738a284b11112179ffcb91'
DELIVERY = '9e221a77663508b46e04c6d5f9de505baa34d927'
PKG = 'evidence/mainline/engineering/29-uncertainty-domain'
CAP = PKG + '/capture-01'
PRE = PKG + '/prepared-01'
LAUNCH = PKG + '/capture-launch-01'
COUNTS = {}


def check(ok, key):
    if not ok:
        raise ValueError(key)
    COUNTS[key] = COUNTS.get(key,0)+1


def git(*args, stdin=None):
    return subprocess.check_output(['git',*args], cwd=ROOT, input=stdin)


def sha(raw):
    return sha256(raw).hexdigest()


def read(path):
    return json.loads(git('cat-file','blob',f'{DELIVERY}:{path}'))


def canonical_sha(value):
    return sha(json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False).encode())


def batch(revision, paths):
    keys = sorted(set(paths))
    requests = ''.join(f'{revision}:{path}\n' for path in keys).encode()
    raw = BytesIO(git('cat-file','--batch',stdin=requests))
    files = {}
    for path in keys:
        header = raw.readline().split()
        if len(header) != 3 or header[1] != b'blob':
            raise ValueError(f'Missing {revision}:{path}')
        files[path] = raw.read(int(header[2]))
        if raw.read(1) != b'\n':
            raise ValueError('Git batch frame did not end')
    if raw.read(1):
        raise ValueError('Trailing Git batch bytes')
    return files


def rows(data):
    return [json.loads(line) for line in data.splitlines()]


protocol = read('docs/mainline/29-domain-engineering-protocol.json')
receipt = read(CAP + '/receipt.json')
launch = read(LAUNCH + '/manifest.json')
cases = protocol['cases']
paths = {f'{CAP}/{pattern.replace("{id}",case["id"])}'
         for pattern in protocol['outputs']['capture'] for case in cases}
launch_paths = {f'{LAUNCH}/manifest.json', f'{LAUNCH}/launch-originals.zip'}
pin_paths = {path for group in receipt['pinned'].values() for path in group}
check(set(git('diff','--name-only',EXECUTION,DELIVERY).decode().splitlines()) ==
      paths | launch_paths, 'capture commit changes only declared immutable outputs')
tree = set(git('ls-tree','-rz','--name-only',DELIVERY,CAP).decode().strip('\0').split('\0'))
check(tree == paths and len(tree) == 35, '35 exact capture blobs including receipt')
check(set(receipt['artifacts']) == {name[len(CAP)+1:] for name in tree if not name.endswith('/receipt.json')},
      'receipt declares every capture artifact')
check(not any('__pycache__' in name.split('/') or name.endswith(('.pyc','.pyo'))
              for name in paths | pin_paths), 'no runtime cache artifact')
check(receipt['status'] == 'PASS' and receipt['execution_commit'] == EXECUTION
      and receipt['mode'] == 'capture' and receipt['source_unchanged']
      and receipt['registered_research_trials'] == receipt['dispatch_calls'] ==
          receipt['model_calls'] == receipt['training_calls'] == 0,
      'capture classification and recorded source')
check(not Path(receipt['unused_pycache_prefix']).exists(), 'isolated cache prefix remains absent')
check(launch['execution'] == EXECUTION, 'launch binds execution')
captured = batch(DELIVERY,paths | launch_paths | pin_paths)
execution = batch(EXECUTION,pin_paths)
for role, group in receipt['pinned'].items():
    for path, expected in group.items():
        check(expected == sha(execution[path]) == sha(captured[path]) == sha((ROOT/path).read_bytes()),
              f'exact source and delivery pins: {role}')
for path in paths | launch_paths:
    check(sha(captured[path]) == sha((ROOT/path).read_bytes()), 'working output equals committed blob')
for name, expected in receipt['artifacts'].items():
    check(expected == sha(captured[f'{CAP}/{name}']), 'original capture artifact fingerprint')
launch_bytes = captured[f'{LAUNCH}/launch-originals.zip']
check(sha(launch_bytes) == launch['archive_sha256'], 'launcher archive SHA-256')
with ZipFile(BytesIO(launch_bytes)) as z:
    names = z.namelist()
    check(len(names) == len(set(names)) == 5 and set(names) == set(launch['members']), 'launcher member set')
    for name in names:
        check(sha(z.read(name)) == launch['members'][name], 'launcher member identity')
    terminal = json.loads(z.read('stdout.raw'))
    check(not z.read('stderr.raw') and terminal['status'] == 'PASS'
          and terminal['execution_commit'] == EXECUTION and terminal['mode'] == 'capture'
          and terminal['started'] == terminal['passed'] == 8 and terminal['charged_simulated_s'] == 33,
          'outer capture terminal agrees with authoritative receipt')

attempts = rows(captured[f'{CAP}/attempts.jsonl'])
check(len(attempts) == 16 and receipt['started'] == receipt['passed'] == 8,
      'eight attempts, eight returned, no retry')
check(all(datetime.fromisoformat(a['recorded_at_utc']) <= datetime.fromisoformat(b['recorded_at_utc'])
          for a,b in zip(attempts,attempts[1:])), 'attempt lifecycle chronology')
checks = json.loads(captured[f'{CAP}/checks.json'])
check(list(checks) == [case['id'] for case in cases], 'saved checker outputs in frozen order')
actual_trace_count = 0
total_seconds = 0
for i, case in enumerate(cases):
    case_id = case['id']
    a,b = attempts[i*2:i*2+2]
    check(a['attempt'] == b['attempt'] == i+1 and a['case_id'] == b['case_id'] == case_id
          and a['status'] == 'STARTED' and b['status'] == 'PASS' and b['returned'] is True
          and a['simulated_charge_s'] == case['seconds'], 'start/return pairing and charged seconds')
    total_seconds += a['simulated_charge_s']
    case_root = f'{CAP}/{case_id}'
    run = json.loads(captured[f'{case_root}/run.json'])
    prepared = json.loads(captured[f'{PRE}/cases/{case_id}.json'])
    scenario = json.loads(captured[f'{case_root}/scenario.json'])
    check(scenario == prepared['scenario'] and run['scenario_sha256'] == canonical_sha(scenario)
          and run['facility_id'] == scenario['id'], 'exact frozen private scenario and identity')
    check(run['inputs'] == {'duration_s':case['seconds'],'maximum_step_s':.01,
                            'work_requests':[],'boundary_events':prepared['boundary_events']},
          'no dispatch, work or extra inputs')
    public = prepared['public_static']
    check(set(public) == {'nominal_knowledge','fixed_sensor_profile','workforce_profile'}
          and public['fixed_sensor_profile']['ledger']['records'] == [], 'public static only, no evidence samples')
    check(run['state_visibility'] == 'PRIVATE_PLANT_EVALUATOR_ONLY'
          and run['dispatch_interface'] == 'DISABLED_FOR_THIS_RUN'
          and not run['work_records'] and run['engineering_fixture'] is True
          and run['status'] == 'ENGINEERING_FIXTURE_COMPLETED'
          and run['field_calibration'] == 'PENDING'
          and run['research_gain_claim'] == 'NOT_ESTABLISHED'
          and run['research_trials'] == run['model_calls'] == run['training_calls'] == 0
          and not any(key.startswith(('policy_','inspection_','intervention_','workforce_public'))
                      for key in run), 'private evaluator and no policy or observation records')
    code = run['code_identity']
    check(code['git_commit'] == EXECUTION and code['implementation_has_changes'] is False
          and code['files'] == receipt['pinned']['runtime']
          and code['source_tree_sha256'] == canonical_sha(code['files']), 'native plant identity')
    check(run['property_reference']['sha256'] ==
          receipt['pinned']['inputs'][scenario['runtime']['property_table']],
          'material reference identity')
    trace = rows(captured[f'{case_root}/private-state.jsonl'])
    balances = rows(captured[f'{case_root}/balances.jsonl'])
    files = {'scenario.json':1,'private-state.jsonl':len(trace),'balances.jsonl':len(balances)}
    check(set(files) == set(run['artifacts']), 'native artifact declaration')
    for name, expected in files.items():
        check(run['artifacts'][name] ==
              {'sha256':sha(captured[f'{case_root}/{name}']),'records':expected},
              'native artifact fingerprint and exact row count')
    check(len(trace) == len(balances) + 1 and checks[case_id]['trace_points'] == len(trace)
          and trace[0]['time_s'] == 0 and trace[-1]['time_s'] == case['seconds'],
          'complete trajectory')
    actual_trace_count += len(trace)
    domains = {row['id'] for row in scenario['domains']}
    check(len(domains) == 8 and set(scenario['graphs']) == {'physical','functional','control_information','access'},
          'whole synthetic facility')
    for snapshot in trace:
        check(set(snapshot['domains']) == domains, 'complete domain state per private row')
    for left, balance, right in zip(trace,balances,trace[1:]):
        check(left['time_s'] == balance['start_s'] < balance['end_s'] == right['time_s'],
              'exact processing intervals')
check(total_seconds == receipt['charged_simulated_s'] == protocol['budget']['simulated_duration_s'] == 33,
      'budget reconciliation')
print(json.dumps({
    'review_axis':'Standards', 'status':'PASS_SAVED_PHYSICAL_DELIVERY', 'execution':EXECUTION, 'delivery':DELIVERY,
    'assertion_count':sum(COUNTS.values()), 'assertions':COUNTS, 'cases':len(cases),
    'trace_points':actual_trace_count, 'capture_blobs':len(paths), 'launch_blobs':len(launch_paths),
    'source_role_pins':{role:len(group) for role,group in receipt['pinned'].items()},
    'observed_captured_simulated_seconds':total_seconds, 'new_plant_calls':0, 'new_policy_calls':0,
    'registered_research_trials':0, 'unresolved_findings':0,
}, indent=2))
