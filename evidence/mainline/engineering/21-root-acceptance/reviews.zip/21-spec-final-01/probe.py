from copy import deepcopy
from hashlib import sha256
import json,subprocess,sys
from pathlib import Path
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[1];EXPORT=OUT/'export';PIN='65db38e45ebf6db44093b52f6ae72553b481c233';RUNS=OUT/'runs-01';checks=[]
sys.path.insert(0,str(EXPORT/'src'))
def check(value,label):
 if not value:raise AssertionError(label)
 checks.append(label)
def read(path):return json.loads((EXPORT/path).read_bytes())
def guard():
 paths=subprocess.check_output(['git','ls-tree','-r','--name-only',PIN,'src','configs'],cwd=ROOT,text=True).splitlines();result={}
 for name in paths:
  raw=(EXPORT/name).read_bytes();assert raw==subprocess.check_output(['git','show',PIN+':'+name],cwd=ROOT);result[name]=sha256(raw).hexdigest()
 return result
before=guard();protocol=json.loads((OUT/'protocol.json').read_bytes());check(sha256((OUT/'protocol.json').read_bytes()).hexdigest()==(OUT/'protocol.sha256').read_text().strip(),'frozen protocol hash')
from aegis_dc.scenario import load_scenario
from aegis_dc.decision_view import DecisionGateway
from aegis_dc.workforce_dispatch import prepare_work,CrewWorkforce
from aegis_dc.plant import simulate_scenario

def fixture(times=(0,),records=()):
 scenario=load_scenario(EXPORT/'configs/full-facility-mainline-reserve-v6.json')
 for p in scenario['parameters']:
  if p['id'] in ('walk_short','inspection_time'):p['value']=1
  elif p['id']=='walk_long':p['value']=2
 n=read('configs/full-facility-decision-v1/public-nominal.json');ledger=read('configs/full-facility-decision-v1/common-ledger.json');ledger['records']=list(records)
 g=DecisionGateway(n,ledger,dict(schema='aegisdc-public-preparation-plan-v1',id='independent21',basis='synthetic_assumption',time_unit='s',decision_times_s=list(times),requests=[]))
 values={p['id']:p['value'] for p in scenario['parameters']}
 profile=dict(schema='aegisdc-workforce-profile-v1',id='independent21scaled',facility_id=scenario['id'],nominal_knowledge_id=n['id'],basis='synthetic_assumption',source_note='Frozen independent engineering review scaled timings.',time_unit='s',access_check_s=.25,feedback_latency_s=.5,walk_times_s={e['id']:values[e['duration_parameter']] for e in scenario['graphs']['access']},work_times_s={w['id']:values[w['duration_parameter']] for d in scenario['domains'] for w in d['work_interfaces']},shifts={e['id']:[0,values['shift_end_time']] for e in scenario['entities'] if e['kind']=='worker'})
 return scenario,profile,[g.next_frame() for _ in times]
def task(name,crew=('worker_cooling',),target='plate_hx',interface='inspect_facility_cooling',roles=None,carrier=None,deadline=20):
 roles=roles or ['qualified_cooling_inspection']*len(crew)
 return dict(id=name,work_interface_id=interface,target_id=target,crew=[dict(worker_id=w,qualification_id=q) for w,q in zip(crew,roles)],tool_carrier_id=carrier or crew[0],deadline_s=deadline,source_note='Independent engineering intention, no inspection result or repair.')
def program(profile,*submissions):return dict(schema='aegisdc-work-program-v1',id='independent21',profile=profile,submissions=[dict(frame=f,task=t) for f,t in submissions])
def execute(case,scenario,program,duration,events=()):
 folder=RUNS/case;folder.mkdir(exist_ok=False);data=dict(scenario=scenario,program=program,duration_s=duration,step_s=.01,boundary_events=list(events));(folder/'inputs.json').write_text(json.dumps(data,indent=2)+chr(10),encoding='utf-8');attempt=dict(case=case,source=PIN,classification='ENGINEERING_ONLY_INDEPENDENT_REVIEW',input_sha256=sha256((folder/'inputs.json').read_bytes()).hexdigest(),protocol_sha256=sha256((OUT/'protocol.json').read_bytes()).hexdigest());(folder/'attempt.json').write_text(json.dumps(attempt,indent=2)+chr(10),encoding='utf-8')
 try:
  result=simulate_scenario(scenario,duration_s=duration,step_s=.01,work_program=program,boundary_events=events)
  (folder/'run.json').write_text(json.dumps(result,indent=2)+chr(10),encoding='utf-8');(folder/'receipt.json').write_text(json.dumps(dict(status='RETURNED',case=case,source=PIN,run_sha256=sha256((folder/'run.json').read_bytes()).hexdigest()),indent=2)+chr(10),encoding='utf-8');return result
 except Exception as error:
  (folder/'receipt.json').write_text(json.dumps(dict(status='FAIL',case=case,error_type=type(error).__name__,error=str(error)),indent=2)+chr(10),encoding='utf-8');raise

# Public preparation has no live state and does not mutate caller inputs.
s,p,frames=fixture((0,.5));f=frames[0];team=task('public',('worker_cooling','worker_control'),roles=['qualified_cooling_inspection','qualified_control_inspection']);saved=deepcopy((f,p,team));a=prepare_work(f,p,team)
check(a['legal_for_planning'] and a['execution_permission'] is False,'qualified heterogeneous carrier and assistant');check((f,p,team)==saved,'prepare inputs detached')
for mutation in ('duplicate-role','absent-carrier','wrong-carrier','unknown-qual','private'):
 changed=deepcopy(team)
 if mutation=='duplicate-role':changed['crew'].append(deepcopy(changed['crew'][0]))
 elif mutation=='absent-carrier':changed['tool_carrier_id']='worker_it'
 elif mutation=='wrong-carrier':changed['tool_carrier_id']='worker_control';changed['work_interface_id']='inspect_power';changed['target_id']='rectifier'
 elif mutation=='unknown-qual':changed['crew'][0]['qualification_id']='unknown'
 else:changed['actual_state']={'closed':True}
 try:out=prepare_work(f,p,changed)
 except ValueError:check(mutation!='wrong-carrier','closed public rejection '+mutation)
 else:check(mutation=='wrong-carrier' and out['legal_for_planning'] is False,'invalid planning '+mutation)

# Incremental public submit is current-frame-only; delayed feedback cannot be queried ahead.
executor=CrewWorkforce(s,{x['id']:x['value'] for x in s['parameters']},program(p,(f,task('initial'))),20);executor.process(0,set())
try:executor.public_feedback(.1)
except ValueError:check(True,'future feedback refused')
else:check(False,'future feedback admitted')
try:executor.submit(frames[1],task('future-submit',target='internal_water'))
except ValueError:check(True,'future issued frame refused')
else:check(False,'future issued frame admitted')
executor.submit(f,task('current-submit',('worker_control',),target='internal_water'));check(executor.records[-1]['status']=='queued','incremental current frame accepted')
try:executor.submit(f,task('current-submit',target='filter'))
except ValueError:check(True,'duplicate task id refused')
else:check(False,'duplicate task id admitted')

# Eight short independent whole-facility simulations, all declared above.
s,p,ff=fixture();f=ff[0];cool=task('cooling-control',('worker_cooling','worker_control'),roles=['qualified_cooling_inspection','qualified_control_inspection']);elec=task('electrical',('worker_electrical',),target='rectifier',interface='inspect_power',roles=['qualified_electrical_inspection'])
normal=execute('normal-parallel',s,program(p,(f,cool),(f,elec)),3)
s,p,ff=fixture((0,.5));queue=execute('resource-queue',s,program(p,(ff[0],task('first')),(ff[1],task('second',('worker_control',),target='internal_water')),(ff[1],task('expires',target='filter',deadline=.75)),(ff[1],task('duplicate',('worker_control',)))),4)
s,p,ff=fixture();room=task('hidden-room',target='room',interface='inspect_equipment_environment');opening=prepare_work(ff[0],p,room)
openrun=execute('hidden-open',s,program(p,(ff[0],room)),3.5);closed=deepcopy(s)
for value in closed['parameters']:
 if value['id']=='it_access_permit':value['value']=0
check(prepare_work(ff[0],p,room)==opening,'same public preparation for hidden closure');closedrun=execute('hidden-closed',closed,program(p,(ff[0],room)),3.5)
s,p,ff=fixture((0,.5));hazard=dict(time_s=.5,parameter_id='it_access_permit',value=0,source_note='Independent synthetic hazard for cancellation and reservation accounting.');waiting=task('cancel-team',('worker_cooling','worker_it'),target='room',interface='inspect_equipment_environment',roles=['qualified_cooling_inspection','qualified_it_inspection']);nexttask=task('next-tool',('worker_control',),target='plate_hx');cancel=execute('waiting-cancel',s,program(p,(ff[0],waiting),(ff[1],nexttask)),3,[hazard])
s,p,ff=fixture();working=task('working-room',('worker_it',),target='room',interface='inspect_equipment_environment',roles=['qualified_it_inspection']);working['tool_carrier_id']='worker_it'
# IT worker cannot carry the cooling interface tool, so use cooling specialist placed onsite as an explicit physical/static fixture.
working=task('working-room',target='plate_hx');stop=dict(time_s=.5,parameter_id='room_work_temperature_limit',value=290,source_note='Independent onsite hazard needs valid parameter; actual check follows input contract.')
# Preserve protocol working-stop meaning with canonical IT specialist's own IT interface.
working=task('working-room',('worker_it',),target='compute',interface='inspect_it_service',roles=['qualified_it_inspection']);workstop=execute('working-stop',s,program(p,(ff[0],working)),1.5,[hazard])
s,p,ff=fixture();p['shifts']['worker_control']=[.5,2];short=task('shift-unavailable',('worker_control',),deadline=2);route=task('route-unavailable',target='loc_electrical',interface='inspect_space_access');shift=execute('shift-and-deadline',s,program(p,(ff[0],short),(ff[0],route)),2)
s,p,ff=fixture();constraint=ff[0]['nominal_knowledge']['reported_constraints'][0];report=dict(id='remote-access',source_id=constraint['source_id'],target_id=constraint['target_id'],observable_id=constraint['observable_id'],unit='1',value=constraint['blocking_value'],observed_at_s=.25,arrived_at_s=.5,valid_until_s=2,quality=dict(status='reported',error_bound=None,note='Independent declared remote report'),provenance=dict(origin_id='remote-access',copied_from_record_id=None));s,p,ff=fixture((0,.5),[report]);early=task('early',target='room',interface='inspect_equipment_environment');late=deepcopy(early);late['id']='late';latereport=execute('public-late-restriction',s,program(p,(ff[0],early),(ff[1],late)),.75)
after=guard();check(before==after,'all frozen source/config bytes unchanged');(OUT/'physical-probe-record.json').write_text(json.dumps(dict(status='CAPTURED_FOR_INDEPENDENT_ASSERTIONS',source=PIN,source_before=before,source_after=after,public_checks=checks,physical_calls=8,registered_research_trials=0,full_suite_runs=0),indent=2)+chr(10),encoding='utf-8');print(json.dumps(dict(status='CAPTURED',public_assertions=len(checks),physical_calls=8)))
