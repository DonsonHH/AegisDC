from pathlib import Path
import json,math
OUT=Path(__file__).resolve().parent;RUNS=OUT/'runs-01';checks=[]
def check(v,label):
 if not v:raise AssertionError(label)
 checks.append(label)
def close(a,b,label):check(abs(a-b)<=1e-9,label)
def run(name):return json.loads((RUNS/name/'run.json').read_bytes())
def records(r):return {x['id']:x for x in r['work_records']}
normal=run('normal-parallel');n=records(normal);close(n['cooling-control']['work_started_at_s'],1.25,'crew starts after rendezvous');close(n['cooling-control']['completed_at_s'],2.25,'crew complete');close(n['electrical']['completed_at_s'],1.25,'independent parallel work')
for k,v in dict(worker_travel_person_s=1,worker_wait_person_s=1.75,access_check_person_s=.75,rendezvous_wait_person_s=1,queue_wait_person_s=0,worker_work_person_s=3,tool_occupation_tool_s=3.5,tool_work_tool_s=2).items():close(normal['summary'][k],v,'normal literal '+k)
q=run('resource-queue');r=records(q);close(r['first']['completed_at_s'],1.25,'first completes');close(r['second']['started_at_s'],1.25,'equal time tool release start');close(r['second']['completed_at_s'],3.5,'queued tool user completion');close(r['second']['queue_wait_s'],.75,'queue delay');close(r['expires']['finished_at_s'],.75,'queued deadline exact');check(r['expires']['reason']=='deadline_expired_in_queue','deadline reason');check(r['duplicate']['reason']=='duplicate_open_work','duplicate open mask')
for k,v in dict(worker_travel_person_s=1,worker_wait_person_s=1.25,access_check_person_s=.5,rendezvous_wait_person_s=0,queue_wait_person_s=.75,worker_work_person_s=2,tool_occupation_tool_s=3.5,tool_work_tool_s=2).items():close(q['summary'][k],v,'queue literal '+k)
opened=run('hidden-open');closed=run('hidden-closed');orow=records(opened)['hidden-room'];crow=records(closed)['hidden-room'];close(orow['work_started_at_s'],2.5,'open hidden starts');close(crow['finished_at_s'],2.5,'closed discovered at paid gate');check(crow['status']=='aborted','closed abort');close(closed['summary']['worker_travel_person_s'],2,'closed travel retained');close(closed['summary']['worker_wait_person_s'],.5,'closed check retained');check(all(x['arrived_at_s']==3 for x in closed['workforce_public_feedback']),'closed delayed feedback');check(opened['work_records'][0]['public_assessment']==closed['work_records'][0]['public_assessment'],'samepublic mask hidden pair')
check(closed['trace'][-1]['domains']['people_tools_work']['workers']['worker_cooling']['location_id']=='loc_control','closed safe approach location')
cancel=run('waiting-cancel');cr=records(cancel);close(cr['cancel-team']['cancel_requested_at_s'],.5,'onsite hazard stop exact');close(cr['cancel-team']['finished_at_s'],1.25,'cancel edge/check cost retained');close(cr['next-tool']['started_at_s'],1.25,'new task waits physical tool release');check('work_started_at_s' not in cr['cancel-team'],'cancelled waiting crew never works')
feedback=cancel['workforce_public_feedback'];check([(x['observed_at_s'],x['arrived_at_s'],x['status']) for x in feedback]==[(.5,1,'safety_stop_observed'),(1.25,1.75,'aborted')],'separate hazard and terminal report times')
for point in cancel['trace']:
 t=point['time_s'];w=point['domains']['people_tools_work'];carrier=w['workers']['worker_cooling'];tool=w['tools']['tool_flow_meter']
 if 0<t<1.25:
  check(carrier['location_id'] is None,'moving carrier never teleports '+str(t));check(carrier['request_id']=='cancel-team' and carrier['status']!='idle','moving participant reserved '+str(t));check(tool['reserved_by']=='cancel-team','tool reserved to safe point '+str(t))
 if 1.25<=t<1.26:check(carrier['location_id']=='loc_control','carrier stops at current edge endpoint')
work=run('working-stop');wr=records(work)['working-room'];close(wr['work_started_at_s'],.25,'onsite paid check');close(wr['finished_at_s'],.5,'working hazard stop');close(work['summary']['worker_work_person_s'],.25,'partial work charged');close(work['summary']['tool_occupation_tool_s'],.5,'tool reserved through stop');check(all(x['arrived_at_s']==1 for x in work['workforce_public_feedback']),'working stop latency')
shift=run('shift-and-deadline');sr=records(shift);check(sr['shift-unavailable']['reason']=='shift_or_deadline_unavailable','short shift refusal');check(sr['route-unavailable']['reason']=='static_access_unreachable','qualified route refusal');check(all(shift['summary'][k]==0 for k in ['worker_travel_person_s','worker_wait_person_s','worker_work_person_s','tool_occupation_tool_s']),'pre-shift wait excluded and rejected no motion')
late=run('public-late-restriction');lr=records(late);check(lr['early']['status']=='travelling' and lr['late']['status']=='rejected','public arrived restriction affects only later issue');check(lr['late']['public_assessment']['considered_record_ids']==['remote-access'],'public restriction explicit source');close(late['summary']['worker_travel_person_s'],.75,'no extra travel from public refusal')
for folder in RUNS.iterdir():
 if not folder.is_dir():continue
 result=run(folder.name);summary=result['summary'];close(summary['worker_wait_person_s'],sum(summary[k] for k in ['access_check_person_s','rendezvous_wait_person_s','queue_wait_person_s']),'wait partition '+folder.name)
 check(all(summary[k]>=0 for k in ['worker_wait_person_s','access_check_person_s','rendezvous_wait_person_s','queue_wait_person_s']),'nonnegative categories '+folder.name)
 for b in result['balances']:
  close(b['worker_wait_person_s'],b['access_check_person_s']+b['rendezvous_wait_person_s']+b['queue_wait_person_s'],'perstep wait partition '+folder.name)
 for point in result['trace']:
  state=point['domains']['people_tools_work'];active=state['active_requests'];known={r['id']:r for r in result['work_records']};worker_tasks={}
  for job in active:
   for role in known[job]['crew']:worker_tasks.setdefault(role['worker_id'],[]).append(job)
  check(all(len(v)==1 for v in worker_tasks.values()),'no active worker doubleallocation '+folder.name)
  for worker,tasks in worker_tasks.items():check(state['workers'][worker]['request_id']==tasks[0],'worker active identity '+folder.name)
  for tool in state['tools'].values():
   check(tool['reserved_by'] is None or tool['reserved_by'] in active,'tool reservation references one active task '+folder.name)
   if tool['carried_by'] is not None:check(tool['carried_by'] in state['workers'],'tool carrier identity '+folder.name)
 for report in result['workforce_public_feedback']:check(report['arrived_at_s']>=report['observed_at_s']+.5,'report latency '+folder.name)
record=json.loads((OUT/'physical-probe-record.json').read_bytes());report=dict(schema='independent-ticket21-short-run-spec-v1',status='PASS',source=record['source'],public_assertions=len(record['public_checks']),run_assertions=len(checks),total_assertions=len(checks)+len(record['public_checks']),checks=checks,source_before=record['source_before'],source_after=record['source_after'],physical_calls=8,full_suite_runs=0,registered_research_trials=0,llm_calls=0,training_calls=0,findings=[]);(OUT/'run-checks.json').write_text(json.dumps(report,indent=2)+chr(10),encoding='utf-8');print(json.dumps({k:report[k] for k in ['status','source','public_assertions','run_assertions','total_assertions','physical_calls','findings']}))
