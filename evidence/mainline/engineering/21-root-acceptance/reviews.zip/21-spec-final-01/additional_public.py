from pathlib import Path
import sys,json,copy
out=Path('.work/21-spec-final-01').resolve();sys.path.insert(0,str(out/'export/src'))
from aegis_dc.scenario import load_scenario
from aegis_dc.decision_view import DecisionGateway
from aegis_dc.workforce_dispatch import prepare_work,CrewWorkforce
s=load_scenario(out/'export/configs/full-facility-mainline-reserve-v6.json');params={p['id']:p['value'] for p in s['parameters']};n=json.loads((out/'export/configs/full-facility-decision-v1/public-nominal.json').read_bytes());l=json.loads((out/'export/configs/full-facility-decision-v1/common-ledger.json').read_bytes());g=DecisionGateway(n,l,dict(schema='aegisdc-public-preparation-plan-v1',id='closed',basis='synthetic_assumption',time_unit='s',decision_times_s=[0,1],requests=[]));f=g.next_frame();future=g.next_frame();p=dict(schema='aegisdc-workforce-profile-v1',id='closed',facility_id=s['id'],nominal_knowledge_id=n['id'],basis='synthetic_assumption',source_note='Independent public boundary check',time_unit='s',access_check_s=1,feedback_latency_s=2,walk_times_s={e['id']:params[e['duration_parameter']] for e in s['graphs']['access']},work_times_s={w['id']:params[w['duration_parameter']] for d in s['domains'] for w in d['work_interfaces']},shifts={e['id']:[0,params['shift_end_time']] for e in s['entities'] if e['kind']=='worker'});task=dict(id='closed',work_interface_id='inspect_facility_cooling',target_id='plate_hx',crew=[dict(worker_id='worker_cooling',qualification_id='qualified_cooling_inspection')],tool_carrier_id='worker_cooling',deadline_s=100,source_note='Independent public boundary check')
checks=[]
for label,frame,profile,intention in [('wrong-interface-target',f,p,dict(task,target_id='rectifier')),('privateframe',dict(f,actual_state=1),p,task),('privateprofile',f,dict(p,actual_access=1),task)]:
 try:r=prepare_work(frame,profile,intention)
 except ValueError as e:checks.append(dict(case=label,rejected=str(e)))
 else:checks.append(dict(case=label,result=r))
program=dict(schema='aegisdc-work-program-v1',id='x',profile=p,submissions=[dict(frame=f,task=task)])
x=CrewWorkforce(s,params,program,100);x.process(0,set());x.process(1,set())
try:x.submit(f,dict(task,id='stale'))
except ValueError as e:checks.append(dict(case='stale-currentframe',rejected=str(e)))
else:checks.append(dict(case='stale-currentframe',accepted=True))
(out/'additional-public-checks.json').write_text(json.dumps(checks,indent=2)+chr(10),encoding='utf-8');print(json.dumps(checks))
