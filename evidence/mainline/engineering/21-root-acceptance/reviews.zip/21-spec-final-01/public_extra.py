from pathlib import Path
from hashlib import sha256
import json,sys,subprocess,copy
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[1];EXPORT=OUT/'export';PIN='65db38e45ebf6db44093b52f6ae72553b481c233';sys.path.insert(0,str(EXPORT/'src'));checks=[]
def check(v,label):
 if not v:raise AssertionError(label)
 checks.append(label)
def guard():
 names=['src/aegis_dc/workforce_dispatch.py','src/aegis_dc/workforce.py','src/aegis_dc/decision_view.py','configs/full-facility-mainline-reserve-v6.json','configs/full-facility-decision-v1/public-nominal.json'];hashes={}
 for name in names:
  data=(EXPORT/name).read_bytes();check(data==subprocess.check_output(['git','show',PIN+':'+name],cwd=ROOT),'frozen public-check source '+name);hashes[name]=sha256(data).hexdigest()
 return hashes
before=guard()
from aegis_dc.scenario import load_scenario
from aegis_dc.decision_view import DecisionGateway
from aegis_dc.workforce_dispatch import CrewWorkforce,prepare_work
s=load_scenario(EXPORT/'configs/full-facility-mainline-reserve-v6.json');params={p['id']:p['value'] for p in s['parameters']};n=json.loads((EXPORT/'configs/full-facility-decision-v1/public-nominal.json').read_bytes());l=json.loads((EXPORT/'configs/full-facility-decision-v1/common-ledger.json').read_bytes());g=DecisionGateway(n,l,dict(schema='aegisdc-public-preparation-plan-v1',id='bound',basis='synthetic_assumption',time_unit='s',decision_times_s=[0,1],requests=[]));first=g.next_frame();later=g.next_frame();profile=dict(schema='aegisdc-workforce-profile-v1',id='independent21bound',facility_id=s['id'],nominal_knowledge_id=n['id'],basis='synthetic_assumption',source_note='Independent direct public-interface check; no physical run',time_unit='s',access_check_s=1,feedback_latency_s=2,walk_times_s={e['id']:params[e['duration_parameter']] for e in s['graphs']['access']},work_times_s={w['id']:params[w['duration_parameter']] for d in s['domains'] for w in d['work_interfaces']},shifts={e['id']:[0,params['shift_end_time']] for e in s['entities'] if e['kind']=='worker'});task=dict(id='first',work_interface_id='inspect_facility_cooling',target_id='plate_hx',crew=[dict(worker_id='worker_cooling',qualification_id='qualified_cooling_inspection')],tool_carrier_id='worker_cooling',deadline_s=100,source_note='Independent direct public-interface check')
program=dict(schema='aegisdc-work-program-v1',id='bound',profile=profile,submissions=[dict(frame=first,task=task)])
x=CrewWorkforce(s,params,program,100);x.process(0,set())
changed=copy.deepcopy(first);changed['nominal_knowledge']['source_note']+='changed'
try:x.submit(changed,dict(task,id='forged-registry'))
except ValueError as e:check('registry' in str(e),'currentframe changed nominal registry refused')
else:check(False,'changed nominal accepted')
for at in [-1,.1,float('inf'),float('nan'),True]:
 try:x.public_feedback(at)
 except ValueError:check(True,'invalid feedback instant refused '+str(at))
 else:check(False,'invalid feedback instant accepted '+str(at))
check(x.public_feedback(0)==[],'no free initial actual feedback')
# Advance only documented private crew object clock, no plant simulation.
x.process(1,set())
try:x.submit(first,dict(task,id='stale'))
except ValueError:check(True,'stale incremental frame refused')
else:check(False,'stale frame admitted')
feedback=x.public_feedback(1);feedback.append({'forged':'external'});check(x.public_feedback(1)==[],'returned feedback detached')
for label,f,p,t in [('wrong-target',first,profile,dict(task,target_id='rectifier')),('privateframe',dict(first,actual_state=1),profile,task),('privateprofile',first,dict(profile,actual_access=1),task)]:
 try:r=prepare_work(f,p,t)
 except ValueError:check(label!='wrong-target','closed public rejection '+label)
 else:check(label=='wrong-target' and not r['legal_for_planning'],'wrong target planning refused')
after=guard();check(before==after,'public-only probe source bytes unchanged');report=dict(status='PASS',source=PIN,assertions=len(checks),checks=checks,source_before=before,source_after=after,physical_runs=0,registered_research_trials=0,full_suite_runs=0);(OUT/'public-extra-result.json').write_text(json.dumps(report,indent=2)+chr(10),encoding='utf-8');print(json.dumps(dict(status='PASS',assertions=len(checks),physical_runs=0)))
