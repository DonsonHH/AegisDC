from pathlib import Path
from hashlib import sha256
from math import isclose
import json,subprocess
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[1];CAND='fb31168700f14294a9f166d9f8967f7f5c33b401';ORIG='710538a6eda8cf02ae99313c5c51881da7ea745d';CORR='e39300451b6dc2a6cd39a6a7733e1e0b8bed8a0c';checks=[]
def check(v,label):
 if not v:raise AssertionError(label)
 checks.append(label)
def blob(path,pin=CAND):return subprocess.check_output(['git','cat-file','blob',pin+':'+path],cwd=ROOT)
def read(path,pin=CAND):return json.loads(blob(path,pin))
def h(raw):return sha256(raw).hexdigest()
base='evidence/mainline/engineering/21-workforce/';normal=read(base+'capture-01/receipt.json',ORIG);correction=read(base+'safety-closure-01/receipt.json',CORR);classification=read('docs/mainline/evidence/21-source-classification.json');observed_changes={}
for folder,delivery,receipt,source,guard in [('capture-01/',ORIG,normal,'4b9caadec5f0ec91307f29d5619ce41648d6610c','source_head_and_bytes_unchanged'),('safety-closure-01/',CORR,correction,'65db38e45ebf6db44093b52f6ae72553b481c233','source_unchanged')]:
 check(receipt['status']=='PASS' and receipt[guard],'author sourceguard '+folder);check(receipt['execution_commit']==source,'exact author source '+folder)
 for name,digest in receipt['artifacts'].items():check(h(blob(base+folder+name,delivery))==digest==h(blob(base+folder+name)),'exact unchanged author artifact '+folder+name)
 pinned=receipt['pinned'];groups=pinned if folder=='capture-01/' else {'flat':pinned}
 for group,paths in groups.items():
  for name,digest in paths.items():
   check(h(blob(name,source))==digest==h(blob(name,delivery)),'recorded source/delivery '+folder+name)
   current=h(blob(name))
   if current!=digest:
    observed_changes[name]=dict(original_sha256=digest,corrected_sha256=current)
    check(name in classification['changes'],'changed original source explicitly classified '+name)
    check(classification['changes'][name]['original_sha256']==digest and classification['changes'][name]['corrected_sha256']==current,'exact classification hashes '+name)
 check(receipt['global_regression_gate']=='PENDING_ROOT_INTEGRATED_FULL' and receipt['field_calibration']=='PENDING','pending author gates '+folder)
 run=read(base+folder+'run.json',delivery)
 for name,metadata in run['artifacts'].items():check(h(blob(base+folder+name,delivery))==metadata['sha256'],'internal physical manifest '+folder+name)
 check(run['research_trials']==run['model_calls']==run['training_calls']==0,'author engineering classification '+folder)
 balances=[json.loads(line) for line in blob(base+folder+'balances.jsonl',delivery).splitlines()]
 for b in balances:check(isclose(b['worker_wait_person_s'],sum(b[k] for k in ['access_check_person_s','rendezvous_wait_person_s','queue_wait_person_s']),abs_tol=1e-12,rel_tol=0),'saved wait partition '+folder)
 check(len(balances)==(9545 if folder=='capture-01/' else 200),'saved balance row count '+folder)
check(set(observed_changes)==set(classification['changes']),'no arbitrary old-manifest waiver')
run=read(base+'capture-01/run.json',ORIG);record=run['work_records'][0];summary=run['summary'];check(record['work_started_at_s']==61 and record['completed_at_s']==91,'independent canonical61/91');check(run['workforce_public_feedback'][0]['arrived_at_s']==93,'canonical report93')
for key,value in dict(worker_travel_person_s=60,worker_wait_person_s=62,access_check_person_s=2,rendezvous_wait_person_s=60,queue_wait_person_s=0,worker_work_person_s=60,tool_occupation_tool_s=91,tool_work_tool_s=30).items():check(abs(summary[key]-value)<=1e-9,'canonical independent '+key)
check(summary['worker_wait_person_s']+summary['worker_travel_person_s']+summary['worker_work_person_s']==182,'canonical twopeople91s conservation')
cor=read(base+'safety-closure-01/run.json',CORR);record=cor['work_records'][0];check(record['cancel_requested_at_s']==.5 and record['finished_at_s']==1.25,'correction hazard/finaltimes');check([(r['observed_at_s'],r['arrived_at_s']) for r in cor['workforce_public_feedback']]==[(.5,1),(1.25,1.75)],'correction reportlatency');check(cor['summary']['worker_travel_person_s']==1 and cor['summary']['tool_occupation_tool_s']==1.25,'correction chargedtravel/tool')
trace=[json.loads(line) for line in blob(base+'safety-closure-01/private-state.jsonl',CORR).splitlines()];mid=next(t for t in trace if t['time_s']==1);worker=mid['domains']['people_tools_work']['workers']['worker_cooling'];check(worker['location_id'] is None and worker['status']!='idle','saved mid-edge no teleport');check(mid['domains']['people_tools_work']['tools']['tool_flow_meter']['reserved_by']==record['id'],'saved mid-edge tool reserved')
report=dict(schema='independent-ticket21-saved-evidence-spec-v1',status='PASS',candidate=CAND,original_execution=normal['execution_commit'],original_delivery=ORIG,corrected_execution=correction['execution_commit'],corrected_delivery=CORR,assertions=len(checks),checks=checks,source_changes=observed_changes,physical_rerun=False,full_suite_runs=0,registered_research_trials=0,llm_calls=0,training_calls=0,findings=[]);(OUT/'saved-checks.json').write_text(json.dumps(report,indent=2)+chr(10),encoding='utf-8');print(json.dumps({k:report[k] for k in ['status','candidate','assertions','source_changes','findings']}))
