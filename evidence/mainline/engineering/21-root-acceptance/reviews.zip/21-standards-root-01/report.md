# Standards

Finalcandidatefb311687 staticallyreviewed against28f7117c:0 documented-standard findings and0 actionable baseline smells. The opt-inexecution seam extends the sameWorkforce identities/routes/toolstate; legacy requests remain underexistingbehavior. Publicpreparation admits one currentvalidatedframe and declaredtiming, uses staticqualification/reportchecks and returnsplanningonly. Actualprivate resource/state checks remain separate; public taskfeedback enforcescurrentclock anddeclaredlatency.

Crewtravel/check/rendezvous/work and queuewait are explicit, disjointpersonoccupation categories with statedsubsetidentities; toolreservationand toolworkare separate. The boundedcancelpolicy retains already-startedmotion and reservations toasafeendpoint, stops unsafe onsiteactivity and sends hazard/terminalreports separately. No LLMagents, physicalrepair orinspectionmeasurementis invented. Closedcanonicalregistry binding and duplicateopenwork protection followrepo information/capabilityrules. Statefulprivateexecutor class is justified; extra classhierarchies or generic schedulers would add speculativegenerality.

The canonical95srun4b9/710 and safety2s65db/e393 have separate frozenprotocols, attempts andsourceguards, declared durablecache-free outputs and originalfreshproofs. Exactsourceclassificationlists onlyworkforce_dispatch.py andcontract changes; no oldhashfailureis skipped. Original data remain normal-caseevidence atitsactualrevision. FollowupRootfull/independentSpec and currentintegrationmerge remain required; this reportaccepts neither21norM4.

No tests, inference, physicalruns orfullsuite ran for this staticStandards review. Finalintegrationmustpreserve later19numericfixes and original21sourceidentities.
