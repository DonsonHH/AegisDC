"""Package already executed ticket21 acceptance and its distinct original sources."""
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import zipfile

ROOT=Path(__file__).resolve().parents[1];WORK=ROOT/'.work'
SOURCE='6fb25fc0a7c7d8fa47dbe14a04f129cd887eab4c'
PACKET=Path('evidence/mainline/engineering/21-root-acceptance')
RAW=ROOT/'runs/mainline-M4-21-root-acceptance-20261105-01'
def read(p):return json.loads(p.read_bytes())
def digest(p):return sha256(p.read_bytes()).hexdigest()
def git(*a):return subprocess.check_output(['git',*a],cwd=ROOT)
def write(p,v,new=True):
    p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('x' if new else 'w',encoding='utf-8',newline='\n') as f:f.write(json.dumps(v,ensure_ascii=False,indent=2,allow_nan=False)+'\n')

def main():
    assert git('rev-parse','HEAD').decode().strip()==SOURCE and not git('status','--porcelain')
    packet=ROOT/PACKET;assert not packet.exists()
    summary,guard=read(RAW/'summary.json'),read(RAW/'source-guard.json');tests=summary['tests']
    assert summary['overall']=='PASS' and tests['run']==tests['executed']>450
    assert tests['errors']==tests['failures']==tests['skipped']==0 and summary['verified_original_files']==20
    assert guard['sources_unchanged'] and guard['head_unchanged'] and guard['source_commit_before']==SOURCE
    spec=read(WORK/'21-spec-final-01/review.json');std=read(WORK/'21-standards-independent-01/review.json')
    assert spec['status']=='PASS' and spec['total_assertions']==27027 and spec['findings']==[]
    assert std['status']=='PASS' and std['hard_findings']==[]
    copies={'raw/'+n:RAW/n for n in ('summary.json','tests.log','evidence.json','source-guard.json')};visuals={}
    for stem in ('crew-timing','workforce-boundary'):
        png=WORK/'21-visual-qa-01'/(stem+'.png');svg=png.with_suffix('.svg');dest='figures/'+png.name;copies[dest]=png
        original='evidence/mainline/engineering/21-workforce/capture-01/'+svg.name
        assert digest(svg)==digest(ROOT/original)
        visuals[dest]=dict(svg=original,svg_sha256=digest(svg),png_sha256=digest(png))
    assert read(WORK/'21-visual-qa-01/visual-review.json')['open_findings']==0
    reviews={}
    for folder in ('21-spec-final-01','21-standards-root-01','21-standards-independent-01'):
        for p in (WORK/folder).rglob('*'):
            if p.is_file() and '__pycache__' not in p.parts and p.suffix not in {'.pyc','.pyo'}:
                reviews[folder+'/'+p.relative_to(WORK/folder).as_posix()]=p
    support={n:WORK/n for n in ('21-root-integration-precheck-01.json','21-integration-base-refresh-01.json',
        '21-root-original-fresh-proof-01.json','21-independent-timed-resource-witness-01.json',
        '21-independent-gated-timing-witness-01.json','21-independent-wait-subcategory-annotation-01.json',
        'run_21_root_acceptance.py','build_21_root_packet.py')}
    for p in (WORK/'21-visual-qa-01').glob('*.json'):support['visual/'+p.name]=p
    declared=sorted(set(copies)|{'.gitattributes','README.md','declaration.json','source-manifest.json',
        'archive-members.json','reviews.zip','support.zip','verify_packet.py'})
    write(packet/'declaration.json',dict(artifacts=declared,terminal_receipt='receipt.json'))
    for n,p in copies.items():q=packet/n;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(p.read_bytes())
    attrs=['# Preserve exact native raw output.']
    for n,p in copies.items():
        if n.startswith('raw/') and b'\r\n' in p.read_bytes():attrs.append(n+' -text whitespace=blank-at-eol,blank-at-eof,space-before-tab,cr-at-eol')
    (packet/'.gitattributes').write_text('\n'.join(attrs)+'\n',encoding='utf-8',newline='\n')
    archives={}
    for name,members in (('reviews.zip',reviews),('support.zip',support)):
        archives[name]={}
        with zipfile.ZipFile(packet/name,'x',zipfile.ZIP_DEFLATED) as z:
            for n,p in sorted(members.items()):
                raw=p.read_bytes();z.writestr(n,raw);archives[name][n]=dict(sha256=sha256(raw).hexdigest(),bytes=len(raw))
    write(packet/'archive-members.json',archives)
    author={}
    for role,execution,delivery,folder,changes in (
        ('original','4b9caadec5f0ec91307f29d5619ce41648d6610c','710538a6eda8cf02ae99313c5c51881da7ea745d','capture-01',['docs/mainline/21-workforce-contract.md','src/aegis_dc/workforce_dispatch.py']),
        ('correction','65db38e45ebf6db44093b52f6ae72553b481c233','e39300451b6dc2a6cd39a6a7733e1e0b8bed8a0c','safety-closure-01',[])):
        capture='evidence/mainline/engineering/21-workforce/'+folder+'/receipt.json'
        author[role]=dict(execution=execution,data_delivery=delivery,capture=capture,capture_sha256=digest(ROOT/capture),allowed_source_changes=changes)
    write(packet/'source-manifest.json',dict(tested_source=SOURCE,author=author,visuals=visuals,
        preserved19source='6193cb24851e3ed435a78153ffb79a64da77ab63',
        reviews=dict(standards_findings=0,spec_findings=0,independent_assertions=27027,
            standards_report_sha256=digest(WORK/'21-standards-independent-01/report.md'),spec_report_sha256=digest(WORK/'21-spec-final-01/SPEC.md'))))
    (packet/'verify_packet.py').write_bytes((WORK/'21-verify_packet.py').read_bytes())
    text=f'''# 第21项根验收：异质人员与持续执行

集成执行源码`{SOURCE}`通过{tests['executed']}项完整回归：全部执行、零失败、零错误、零跳过。20份历史原件通过核对；{len(guard['actual_sources'])}个Python与JSON源文件接受Git身份及前后字节守卫。第19项已接受的完整时域数值修复保留，主票20仍在M3推进。

![双专业人员和工具计时](figures/crew-timing.png)

原正常工程见证使用同一V6设施95秒、最大步长.01：控制人员移动60秒，两人检查合计2person·s，汇合等待60person·s，工作60person·s；总等待62包含访问检查子集。两人61秒共同开工、91秒完成，公开完成记录93秒可用。工具预留91tool·s，实际工作30tool·s，二者不重复相加。

![公共准备与私有执行边界](figures/workforce-boundary.png)

普通调度通过当前公开帧及声明能力发出意图；同一物理人员、工具和独立通行图执行移动、排队、汇合与作业。静态资格、当前已到达限制可以阻止规划；隐藏门禁须到安全访问点并完成正耗时检查后才能形成任务局部反馈。私有记录和资源快照不当作免费遥测。未来时刻反馈查询被拒绝。

## 安全修复与独立复核

原正常捕获4b9／710保留；后续65db／e393按独立协议验证等待中的区域危险和取消。现场活动立即停止，已上路人员完成当前边及安全点检查后才释放，工具同时保留。危险观察.5秒／1秒公开，最终取消1.25秒／1.75秒公开；未宣称实际疏散或恢复。两次正式工程捕获各1次0失败，原正常源不冒称验证新安全边界。

Spec27027项断言通过，包含先冻结协议的8个独立短时工程夹具（总21.25秒）和作者原件核验；没有重复95秒或2秒原捕获。两轴未关闭问题均为0。[评审ZIP](reviews.zip)保存探针、原始输出、源码守卫及规范报告；[支持ZIP](support.zip)保存计时解析、来源分类、合并保护和实际图像复核。人员是领域执行者，未调用LLM、训练或注册效果实验。

- [根接受权威](../../../../docs/mainline/evidence/21-root.json)
- [作者工程报告](../21-workforce/README.md)与[执行契约](../../../../docs/mainline/21-workforce-contract.md)
- [原始根摘要](raw/summary.json)、[日志](raw/tests.log)、[源码守卫](raw/source-guard.json)
- [声明产物](declaration.json)、[来源清单](source-manifest.json)和[收据](receipt.json)

图由封存SVG本地渲染后实际查看。复算在明确封存提交新检出中运行本包`verify_packet.py --delivery-commit COMMIT --output OUTSIDE_CHECKOUT.json`，核对包原件、两次作者运行身份及源码分类，不重跑物理或全检。检查结果生成、实际处置和验证关闭仍按22–24推进；M4和完整研究目标未完成。
'''
    (packet/'README.md').write_text(text,encoding='utf-8',newline='\n')
    assert {p.relative_to(packet).as_posix() for p in packet.rglob('*') if p.is_file()}==set(declared)
    write(packet/'receipt.json',dict(schema='aegisdc-ticket21-root-packet-v1',tested_source=SOURCE,
        delivery_gate='PENDING_COMMIT_AND_FRESH_CHECKOUT',artifacts={n:digest(packet/n) for n in declared},root_tests=tests,
        independent_assertions=27027,historical_originals=20,new_full_regressions=0,new_physical_runs=0,registered_research_trials=0,llm_calls=0,training_calls=0))
    write(ROOT/'docs/mainline/evidence/21-root.json',dict(schema='aegisdc-ticket-root-acceptance-v1',ticket='21',status='ACCEPTED',
        actual_root_source=SOURCE,root_tests=tests,packet=PACKET.as_posix(),packet_receipt_sha256=digest(packet/'receipt.json'),author=author,
        independent_assertions=27027,standards_findings=0,spec_findings=0,field_calibration='PENDING',registered_research_trials=0,llm_calls=0,training_calls=0,overall_goal='ACTIVE'))
    p=ROOT/'.scratch/full-facility-mainline/issues/21-heterogeneous-workers.md';s=p.read_text(encoding='utf-8');assert '**Status:** claimed' in s
    s=s.replace('**Status:** claimed','**Status:** resolved',1).replace('- [ ]','- [x]');s+='\nRoot acceptance: `docs/mainline/evidence/21-root.json`; actual source `'+SOURCE+'`, '+str(tests['executed'])+' tests all executed,27027 independentassertions. Original author indices and receipts remain historical.\n';p.write_text(s,encoding='utf-8',newline='\n')
    p=ROOT/'docs/mainline/progress.json';v=read(p);assert v['current_ticket']=='20';v['active_implementations']=[x for x in v['active_implementations'] if x['ticket']!='21'];m=next(x for x in v['milestones'] if x['id']=='M4');m['acceptance_evidence'].append('docs/mainline/evidence/21-root.json');m['progress_scope']='Ticket21 accepted; inspection results, intervention and closure remain pending.';write(p,v,False)
    p=ROOT/'docs/current-research.json';v=read(p);v['active_tickets']=['20'];v['implementation']='Tickets14–19 and21 accepted. Primary20 action value active;22 inspection execution newly ready. M3/M4 remain in progress.';v['runtime_verification_documents'].append((PACKET/'README.md').as_posix());write(p,v,False)
    p=ROOT/'docs/NEXT.md';s=p.read_text(encoding='utf-8');s+='\n第21票人员持续执行已通过[根验收与计时图](../evidence/mainline/engineering/21-root-acceptance/README.md)，主票20继续；22具备依赖但须单独实现和验收。\n';p.write_text(s,encoding='utf-8',newline='\n')
    print(json.dumps(dict(packet=PACKET.as_posix(),artifacts=len(declared),archive_members=sum(map(len,archives.values())),tests=tests,guarded_files=len(guard['actual_sources'])),ensure_ascii=False))

if __name__=='__main__':main()
