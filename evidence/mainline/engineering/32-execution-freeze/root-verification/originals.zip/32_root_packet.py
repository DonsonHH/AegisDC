import json,hashlib,subprocess
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
root=Path(__file__).resolve().parents[1]
files={n:(root/'.work'/n).read_bytes() for n in ['32-root-byte-admission-01.json','32_root_byte_admission.py',
    '32-root-freeze-proof-02.json','32-root-focused-01.log','32_root_packet.py']}
package=root/'evidence/mainline/engineering/32-execution-freeze/root-verification';package.mkdir()
with ZipFile(package/'originals.zip','x',compression=ZIP_DEFLATED) as z:
    for name,raw in files.items():z.writestr(name,raw)
sha=lambda raw:hashlib.sha256(raw).hexdigest()
manifest=dict(schema='aegisdc-root-saved-verification-v1',
    source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
    archive_sha256=sha((package/'originals.zip').read_bytes()),members={n:sha(v) for n,v in files.items()},
    physical_calls=0,selector_calls=0,registered_attempts=0,focused_tests=3)
(package/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8',newline='\n')
p=root/'docs/mainline/evidence/32-root.json';a=json.loads(p.read_bytes())
a.update(actual_root_source=manifest['source'],root_verification=package.relative_to(root).as_posix()+'/manifest.json')
p.write_text(json.dumps(a,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(dict(status='ROOT_SAVED_PROOF_PACKAGED',members=len(files))))
