import hashlib,json,subprocess
from pathlib import Path
root=Path(__file__).resolve().parents[1]
lock=json.loads((root/'docs/mainline/evidence/30-confirmation-execution-lock.json').read_bytes())
rows=[]
for name,expected in lock['execution_pins'].items():
    p=root/name;raw=p.read_bytes();actual=hashlib.sha256(raw).hexdigest()
    if actual!=expected:
        blob=subprocess.check_output(['git','cat-file','blob',f'HEAD:{name}'],cwd=root)
        assert hashlib.sha256(blob).hexdigest()==expected and raw.replace(b'\r\n',b'\n')==blob
        rows.append(dict(path=name,prior_sha256=actual,expected_sha256=expected,classification='EXISTING_CRLF_CHECKOUT_BYTES'))
        p.write_bytes(blob)
subprocess.run(['git','add','--renormalize','--','configs'],cwd=root,check=True)
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root)
value=dict(status='EXACT_GIT_BYTES_CLEAN',previous_verifier='FAILED_NO_PHYSICAL_CALLS',files=rows,
    source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
    physical_calls=0,selector_calls=0,nonce_reads=0)
with (root/'.work/32-root-byte-admission-01.json').open('x',encoding='utf-8') as f:json.dump(value,f,indent=2);f.write('\n')
print(json.dumps(dict(status=value['status'],files=len(rows))))
