import json,hashlib,subprocess
from pathlib import Path
root=Path(__file__).resolve().parents[1]
fresh=root/'.work/32-fresh-freeze-01'
lock=json.loads((fresh/'docs/mainline/evidence/30-confirmation-execution-lock.json').read_bytes())
changes=[]
for name,expected in lock['execution_pins'].items():
    path=fresh/name;raw=path.read_bytes();actual=hashlib.sha256(raw).hexdigest()
    if actual!=expected:
        blob=subprocess.check_output(['git','cat-file','blob',f'HEAD:{name}'],cwd=fresh)
        assert hashlib.sha256(blob).hexdigest()==expected and raw.replace(b'\r\n',b'\n')==blob
        changes.append(dict(path=name,checkout_sha256=actual,git_blob_sha256=expected,
                            classification='CRLF_CHECKOUT_TRANSLATION_ONLY'))
        path.write_bytes(blob)
value=dict(status='EXACT_COMMITTED_BYTES_MATERIALIZED',prior_verifier='FAILED_NO_EXECUTION',
    correction='Materialize exact Git blobs in fresh checkout; do not normalize original evidence.',
    files=changes,physical_calls=0,selector_calls=0,nonce_reads=0)
with (root/'.work/32-fresh-byte-admission-01.json').open('x',encoding='utf-8') as f:json.dump(value,f,indent=2);f.write('\n')
print(json.dumps(dict(status=value['status'],files=len(changes),physical_calls=0)))
