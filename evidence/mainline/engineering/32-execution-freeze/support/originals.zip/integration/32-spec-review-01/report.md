# Independent Spec review — original candidate

Base: `ef790a2efd5a05abb83aa12de4e8a865b65c8d81`.
Candidate: `9fc1b42207d4fa417cc91a55beaaf5a0fad51eff`.
Prospective execution source: `537317a56ec9389e349a7896c6d9531acb562b1c`.

**One P2 finding:** `scripts/analyze_registered_confirmation.py:38–67` skips validation of failed terminals, discards their failure reason, and supplies `hard_violations=[]` for every pair. The frozen protocol requires: “Any recorded actual hard constraint breach … protocol/source mismatch … Take precedence” (`comparison.outcome_rules`, `UNSAFE_OR_INVALID`). A run rejected by the native verifier for “Execution overrode local protection” is correctly archived and stopped by capture, but this analyzer reduces it to an ordinary missing primary outcome and reports `INCOMPLETE`. A failed reference arm can similarly disappear from validity classification. Preserve explicit invalidity or refuse classification pending a separate saved-failure audit. No physical rerun is required to repair this path.

Saved-input/source checks pass. The independent stdlib-only script verified exact Git blobs for 96 inputs, 16 distinct without-replacement assignments in four families, matching primary inputs except policy name, equal common conditions across six arms, compatible seed widths, and 269 executable/configuration pins. Primary metrics, costs, phase/global budgets, nonce commitments and runtime remain unchanged. The two hydraulic coordinates are exactly the declared correction and all 24 public held recipes satisfy the analytical flow ceiling. The original seed-width failure remains explicit with zero inputs/calls; replacement preparation is input-only. The confirmation capture AST matches the accepted development journal algorithm except declared held-read counters. Existing output/staging and reused runtime cache are refused.

The lock is deliberately `PENDING_REVIEW`; accepted32 authority and fresh-checkout proof remain root gates. There are no confirmation outcomes in this candidate. This review performed zero nonce-file reads, seed derivations, project imports, selector calls or physical calls.

Evidence: `receipt.json`, `review-02.py`. The first reviewer script failed because `git archive` applied Windows EOL conversion; its source and exact diagnosis are retained in `review.py` and `review-01-diagnostic.txt`. The corrected review reads committed blobs directly and does not regenerate inputs.
