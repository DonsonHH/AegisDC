"""Independent fixed-Git, saved-input Spec audit. No project imports or nonce IO."""
import ast
import copy
import hashlib
import io
import json
import subprocess
import sys
import zipfile
from pathlib import Path

REPO = Path('C:/Users/Donson/.codex/worktrees/mainline32-confirmation-freeze/Renly')
OUT = Path(__file__).resolve().parent
BASE = 'ef790a2efd5a05abb83aa12de4e8a865b65c8d81'
CANDIDATE = '9fc1b42207d4fa417cc91a55beaaf5a0fad51eff'
EXEC = '537317a56ec9389e349a7896c6d9531acb562b1c'
PREP = 'evidence/mainline/research/32-confirmation-freeze/prepared-02/'
OLD = 'evidence/mainline/research/32-confirmation-freeze/prepared-01/'
PROTOCOL = 'docs/mainline/30-comparison-protocol-v1.json'
LOCK = 'docs/mainline/evidence/30-protocol-lock.json'
checks = []

def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO)

def blob(ref, name):
    return git('cat-file', 'blob', ref + ':' + name)

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def check(ok, detail):
    if not ok:
        raise AssertionError(detail)
    checks.append(detail)

def paths(ref, *roots):
    return set(filter(None, git('ls-tree', '-rz', '--name-only', ref, *roots).decode().split('\0')))

def executable(ref):
    return {n for n in paths(ref, 'src', 'scripts', 'configs') if n.endswith(('.py', '.json'))}

def obj(name):
    return json.loads(files[name])

# Git archive is a byte-preserving read of already materialized, committed input originals.
roots = ['scripts', 'configs', 'docs/mainline', 'evidence/mainline/research/32-confirmation-freeze']
with zipfile.ZipFile(io.BytesIO(git('archive', '--format=zip', CANDIDATE, *roots))) as archive:
    files = {n: archive.read(n) for n in archive.namelist() if not n.endswith('/')}
subprocess.run(['git', 'merge-base', '--is-ancestor', BASE, CANDIDATE], cwd=REPO, check=True)
plan, lock = obj(PROTOCOL), obj(LOCK)
unchanged = git('diff', '--name-only', BASE, CANDIDATE, 'src', PROTOCOL, LOCK,
    'scripts/comparison_release.py', 'scripts/development_journal.py',
    'scripts/registered_development.py', 'scripts/development_run_evidence.py').decode().splitlines()
check(not unchanged, 'Accepted runtime, protocol, commitments, native verifier and durable journal are unchanged')

amendment = obj('docs/mainline/32-hydraulic-admission-amendment.json')
old = obj(amendment['original_blueprint'])
new = obj(amendment['corrected_blueprint'])
expected = copy.deepcopy(old)
check(len(amendment['changes']) == 2, 'Hydraulic amendment declares exactly two public coordinates')
for phase, variant, old_value in [('confirmation', 'mr-a', .875), ('ablation', 'am-a', .9375)]:
    recipe = next(r for r in expected[phase]['misleading-report'] if r['variant'] == variant)
    check(recipe['filter_multiplier'] == old_value, 'Original rejected coordinate retained: ' + variant)
    recipe['filter_multiplier'] = 1
check(expected == new and sha(files[amendment['original_blueprint']]) == amendment['original_sha256']
      and sha(files[amendment['corrected_blueprint']]) == amendment['corrected_sha256'],
      'Corrected blueprint differs only at the two explicitly amended coordinates')
check(all(150000 / (12000000 * r['filter_multiplier'] + 3000000) <= .1 ** 2 + 1e-14
          for phase in ('confirmation', 'ablation') for rows in new[phase].values() for r in rows),
      'All 24 corrected public recipes meet the declared full-head flow ceiling analytically')

failed = obj(OLD + 'receipt.json')
prepared = obj(PREP + 'receipt.json')
check(failed['status'] == 'FAIL' and failed['prepared_inputs'] == 0 and not failed['input_hashes']
      and failed['physical_calls'] == failed['selector_calls'] == failed['registered_research_trials'] == 0
      and failed['error'] == 'Private replay seed must be an unsigned 64-bit integer',
      'Original preparation failure is explicit and does not masquerade as research or successful inputs')
check(prepared['status'] == 'PASS_INPUT_ONLY' and prepared['prepared_inputs'] == 96
      and prepared['physical_calls'] == prepared['selector_calls'] == prepared['registered_research_trials'] == 0,
      'Replacement preparation is labeled input-only with zero research, selector and physical calls')
for prefix, receipt in [(OLD, failed), (PREP, prepared)]:
    actual = {n[len(prefix):] for n in files if n.startswith(prefix)}
    check(actual == set(receipt['artifacts']) | {'receipt.json'}
          and all(sha(files[prefix + n]) == h for n, h in receipt['artifacts'].items()),
          'Exact committed durable membership and SHA verified: ' + prefix.split('/')[-2])
    check(all(sha(blob(receipt['source'], n)) == h for n, h in receipt['pins'].items()),
          'Preparation source pin bytes verified: ' + prefix.split('/')[-2])
rows = [json.loads(line) for line in files[PREP + 'attempts.jsonl'].splitlines()]
check(len(rows) == 32 and [r['status'] for r in rows] == ['STARTED_INPUT_WORLD', 'COMPLETED_INPUT_WORLD'] * 16,
      'All 16 saved input preparation lifecycles have one start and completion')

execution = obj('docs/mainline/evidence/30-confirmation-execution-lock.json')
phase = plan['phases']['confirmation']
members = {w['id'] + '/' + a + '.json' for w in phase['worlds'] for a in phase['arms']}
check(set(execution['input_hashes']) == set(prepared['input_hashes']) == members
      and execution['input_hashes'] == prepared['input_hashes'], 'Exact 16 by 6 input denominator and SHA bindings')
check(execution['execution_source'] == EXEC and execution['status'] == 'PENDING_REVIEW'
      and execution['design_lock_sha256'] == sha(files[LOCK])
      and execution['budget'] == phase['budget'] == dict(attempts=96, simulated_charge_s=960, scheduled_decisions=960),
      'Execution lock retains original phase budget and cannot execute while pending review')
pins = execution['execution_pins']
check(set(pins) == executable(EXEC) == executable(CANDIDATE)
      and all(sha(files[n]) == h == sha(blob(EXEC, n)) for n, h in pins.items()),
      'Exact complete executable and configuration pin set matches execution ancestor and candidate')
check(sha(Path(sys.executable).read_bytes()) == execution['interpreter_sha256'], 'Exact interpreter identity matches lock')
assignments = {row['world_id']: row for row in prepared['assigned_worlds']}
check(len(assignments) == 16 and set(assignments) == {w['id'] for w in phase['worlds']},
      'All 16 registered worlds have one saved recipe assignment')
seeds = []
for world in phase['worlds']:
    assigned = assignments[world['id']]
    check(assigned['family'] == world['family'], 'Registered family retained: ' + world['id'])
    recipe = next(r for r in new['confirmation'][world['family']] if r['variant'] == assigned['variant'])
    docs, common, private = {}, [], set()
    for arm in phase['arms']:
        name = world['id'] + '/' + arm + '.json'
        raw = files[PREP + 'inputs/' + name]
        if sha(raw) != execution['input_hashes'][name]: raise AssertionError('Input SHA ' + name)
        doc = json.loads(raw)
        p = {r['id']: r['value'] for r in doc['model']['parameters']}
        program = doc['dispatch_program']
        assert doc['duration_s'] == 10 and doc['maximum_step_s'] == .01
        assert p['network_service_capacity'] == recipe['network_cap']
        assert p['filter_resistance_multiplier'] == recipe['filter_multiplier']
        assert doc['boundary_events'] == recipe['events']
        assert program['decision_times_s'] == plan['decision_times_s']
        assert program['policy_program']['policy'] == arm
        assert program['policy_program']['resource_budget'] == plan['comparison']['common_admission_budget']
        fixed = program['sensor_program']['realization']
        portable = program['inspection_program']['realizations']['lookahead-inspect']['seed']
        assert type(fixed['seed']) is int and 0 <= fixed['seed'] < 2**64
        assert type(portable) is int and 0 <= portable < 2**128
        assert all(v == 0 for key in ('biases', 'noise_bounds', 'dropout_probabilities') for v in fixed[key].values())
        private.add((portable, fixed['seed']))
        docs[arm] = copy.deepcopy(doc)
        for key in ('policy', 'options'): doc['dispatch_program']['policy_program'].pop(key)
        common.append(doc)
    check(len(private) == 1 and all(d == common[0] for d in common), 'Six arms share the exact common physical/evidence/action envelope: ' + world['id'])
    a, b = [docs[n] for n in plan['comparison']['primary']]
    a['dispatch_program']['policy_program']['policy'] = b['dispatch_program']['policy_program']['policy']
    assert a == b
    seeds.extend(private)
check(len(set(seeds)) == 16, 'Distinct seed pairs across all 16 worlds; values not disclosed or rederived')
for family in new['confirmation']:
    variants = [r['variant'] for r in assignments.values() if r['family'] == family]
    assert len(variants) == len(set(variants)) == 4
check(True, 'Four distinct recipes without replacement in each of four registered families')

def capture_ast(name):
    tree = ast.parse(files['scripts/' + name])
    fn = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'capture')
    for n in ast.walk(fn):
        if isinstance(n, ast.keyword) and n.arg in ('held_inputs_read', 'held_seed_reads'):
            n.value = ast.Constant(value=0)
    return ast.dump(fn, include_attributes=False)
check(capture_ast('registered_confirmation.py') == capture_ast('registered_development.py'),
      'Confirmation uses identical accepted durable charging, terminal, stop and UNRUN reconciliation algorithm')
runner = files['scripts/registered_confirmation.py'].decode()
seed_compiler = files['scripts/prepare_confirmation.py'].decode()
check("observation_seed(nonce,plan['id'],namespace,world['id'],'fixed') >> 64" in seed_compiler,
      'Fixed seed amendment is deterministic upper-64 truncation of the prior registered derivation')
check("not folder.exists() and not stage.exists()" in runner and "sys.dont_write_bytecode" in runner
      and "'Use -B and a fresh cache prefix'" in runner and "prepared['status']=='PASS_INPUT_ONLY'" in runner,
      'Execution refuses existing output/staging, runtime cache reuse and failed preparation')
check(not any(n.startswith('evidence/mainline/research/33-confirmation/') for n in paths(CANDIDATE))
      and obj('docs/mainline/progress.json')['research_trials']['confirmation']['attempts'] == 0,
      'Fixed candidate contains no confirmation outcomes and still records zero registered confirmation attempts')
result = dict(status='PASS_SPEC_SAVED_FREEZE', base=BASE, candidate=CANDIDATE, execution_source=EXEC,
              checks=checks, check_count=len(checks), worlds=16, inputs=96, executable_pins=len(pins),
              findings=[], nonce_reads=0, project_imports=0, selector_calls=0, physical_calls=0,
              scope='Static source and fixed committed saved inputs; acceptance authority and fresh-check proof remain root gates')
with (OUT / 'receipt.json').open('x', encoding='utf-8') as f: json.dump(result, f, ensure_ascii=False, indent=2); f.write('\n')
print(json.dumps({k:v for k,v in result.items() if k != 'checks'}, ensure_ascii=False))
