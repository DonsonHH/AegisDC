"""Bounded static correction review; reads only committed sources and saved public receipts."""
import ast
import hashlib
import json
import subprocess
from pathlib import Path

ROOT=Path('C:/Users/Donson/.codex/worktrees/mainline32-confirmation-freeze/Renly')
OUT=Path(__file__).resolve().parent
OLD='9fc1b42207d4fa417cc91a55beaaf5a0fad51eff'
NEW='d877fdb3c2225929a13936bf2983ff1d62adc337'
EXEC='81d309685529cbd01130f06048035bd457e749f1'
LOCK='docs/mainline/evidence/30-confirmation-execution-lock.json'
PREP='evidence/mainline/research/32-confirmation-freeze'
checks=[]
def git(*a):return subprocess.check_output(['git',*a],cwd=ROOT)
def blob(ref,path):return git('cat-file','blob',ref+':'+path)
def digest(raw):return hashlib.sha256(raw).hexdigest()
def check(value,message):
    if not value:raise AssertionError(message)
    checks.append(message)
def members(ref):
    return {p for p in git('ls-tree','-rz','--name-only',ref,'src','scripts','configs').decode().split('\0')
            if p.endswith(('.py','.json'))}
def pinned(ref,names):
    names=sorted(names)
    raw=subprocess.check_output(['git','cat-file','--batch'],cwd=ROOT,
        input=''.join(ref+':'+n+'\n' for n in names).encode())
    offset=0;result={}
    for name in names:
        end=raw.index(b'\n',offset);header=raw[offset:end].split()
        assert len(header)==3 and header[1]==b'blob'
        start=end+1;size=int(header[2]);result[name]=digest(raw[start:start+size]);offset=start+size+1
    assert offset==len(raw)
    return result

check(git('diff','--name-only',OLD,NEW,'src','docs/mainline/30-comparison-protocol-v1.json',
          'docs/mainline/evidence/30-protocol-lock.json',PREP)==b'',
      'All 96 original inputs, receipts, failed preparation, runtime, protocol and commitment bytes unchanged')
old=json.loads(blob(OLD,LOCK));new=json.loads(blob(NEW,LOCK))
check(blob(NEW,'evidence/mainline/engineering/32-execution-freeze/superseded-execution-lock-01.json')==blob(OLD,LOCK),
      'Superseded prospective execution lock preserved byte-for-byte')
check(new['execution_source']==EXEC and new['status']=='PENDING_REVIEW',
      'Corrected source pinned before any confirmation call and remains blocked pending acceptance')
check(new['input_hashes']==old['input_hashes'] and new['budget']==old['budget']
      and new['design_lock_sha256']==old['design_lock_sha256'] and new['interpreter_sha256']==old['interpreter_sha256'],
      'New prospective lock changes no input, budget, design or interpreter identity')
check(set(new['execution_pins'])==members(EXEC)==members(NEW)
      and new['execution_pins']==pinned(EXEC,new['execution_pins'])==pinned(NEW,new['execution_pins']),
      'Exact 269 executable pins match corrected source ancestor and candidate')
check(not git('diff','--name-only',OLD,NEW,'scripts/registered_confirmation.py','scripts/development_journal.py'),
      'Accepted charging, terminal, stop and UNRUN reconciliation algorithm unchanged')

analyzer=blob(NEW,'scripts/analyze_registered_confirmation.py').decode()
tree=ast.parse(analyzer)
fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='analyze')
guard=next(n for n in fn.body if isinstance(n,ast.Expr) and isinstance(n.value,ast.Call)
           and isinstance(n.value.func,ast.Name) and n.value.func.id=='require'
           and any(isinstance(a,ast.Constant) and a.value=='Failed or interrupted confirmation requires an explicit failure audit before classification'
                   for a in n.value.args))
expected=ast.parse("total['failed']==total['interrupted']==0",mode='eval').body
check(ast.dump(guard.value.args[0],include_attributes=False)==ast.dump(expected,include_attributes=False),
      'Classification refuses either failed or interrupted lifecycle before interpreting outcomes')
classifier=next(n for n in ast.walk(fn) if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='summarize')
reconcile=next(n for n in ast.walk(fn) if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='reconcile')
check(reconcile.lineno<guard.lineno<classifier.lineno,
      'Guard consumes reconciled durable journal and precedes category/fact generation')
for failed,interrupted in [(0,0),(1,0),(0,1),(1,1)]:
    actual=eval(compile(ast.Expression(guard.value.args[0]),'<static integer predicate>','eval'),
                {'__builtins__':{}},{'total':dict(failed=failed,interrupted=interrupted)})
    assert actual==(failed==interrupted==0)
check(True,'All four integer failure/interruption combinations have the required refusal behavior')
verifier=blob(NEW,'scripts/verify_confirmation_freeze.py').decode()
check("all(digest((ROOT/name).read_bytes())==sha for name,sha in execution['execution_pins'].items())" in verifier,
      'Saved-freeze verifier now verifies actual checkout bytes as well as committed source pins')
tests=blob(NEW,'tests/test_confirmation_freeze.py').decode()
check('test_failed_confirmation_is_not_classified_without_failure_audit' in tests
      and 'Execution overrode local protection' in tests and 'self.assertFalse((folder/\'analysis\').exists())' in tests,
      'CLI regression explicitly covers a retained failed reference arm and no emitted classification')
progress=json.loads(blob(NEW,'docs/mainline/progress.json'))
check(progress['research_trials']['confirmation']['attempts']==0
      and not git('ls-tree','-rz','--name-only',NEW,'evidence/mainline/research/33-confirmation'),
      'No registered confirmation attempt or outcome was introduced by the correction')
result=dict(status='PASS_FINAL_SPEC_REVIEW',original_candidate=OLD,candidate=NEW,execution_source=EXEC,
    original_finding='P2 failed-terminal invalidity erased by analyzer',finding_status='RESOLVED_BY_REFUSAL_PENDING_EXPLICIT_AUDIT',
    unresolved_findings=[],checks=checks,nonce_reads=0,seed_derivations=0,project_imports=0,selector_calls=0,physical_calls=0,
    required_root_gates=['accepted32 authority','fresh-checkout exact delivery proof','prospective reviewed lock before33'])
with (OUT/'final-receipt.json').open('x',encoding='utf-8') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps({k:v for k,v in result.items() if k!='checks'}))
