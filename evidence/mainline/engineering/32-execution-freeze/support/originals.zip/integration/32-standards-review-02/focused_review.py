"""Focused static closure of the two prospective ticket32 tool findings."""
import ast
from hashlib import sha256
import importlib.util
import json
from pathlib import Path
import sys

OUT = Path(__file__).resolve().parent
prior = OUT.parent/'32-standards-review-01'/'review.py'
spec = importlib.util.spec_from_file_location('saved_standards_helpers', prior)
review = importlib.util.module_from_spec(spec)
spec.loader.exec_module(review)
OLD = review.CANDIDATE
NEW = 'd877fdb3c2225929a13936bf2983ff1d62adc337'
EXECUTION = '81d309685529cbd01130f06048035bd457e749f1'
review.CANDIDATE = NEW
check,git = review.check,review.git
blob = lambda path, rev=NEW: review.blob(path,rev)
doc = lambda path, rev=NEW: review.doc(path,rev)


def main():
    check(git('merge-base','--is-ancestor',OLD,NEW) == b'', 'Original reviewed candidate retained as ancestor')
    check(git('merge-base','--is-ancestor',EXECUTION,NEW) == b'', 'Corrected execution source precedes final freeze')
    for path in (review.PREP, review.OLD):
        check(git('rev-parse',OLD+':'+path) == git('rev-parse',NEW+':'+path), 'Original preparation subtree byte-identical '+path.rsplit('/',1)[-1])
    for path in (review.PROTOCOL,review.LOCK,'docs/mainline/32-seed-interface-amendment.json','docs/mainline/32-hydraulic-admission-amendment.json'):
        check(blob(path,OLD) == blob(path,NEW), 'Frozen protocol or amendment unchanged '+path)
    correction = doc('docs/mainline/32-tool-review-correction.json')
    retained = correction['superseded_lock']
    check(blob(retained) == blob(review.EXEC_LOCK,OLD) and sha256(blob(retained)).hexdigest() == correction['superseded_lock_sha256'], 'Original execution lock retained exactly, never overwritten')
    check(correction['superseded_execution_source'] == review.EXECUTION and correction['confirmation_calls_before_correction'] == 0, 'Prospective correction keeps original execution identity and zero calls')
    execution = doc(review.EXEC_LOCK)
    check(execution['execution_source'] == EXECUTION and execution['status'] == 'PENDING_REVIEW', 'New execution lock names corrected frozen source and pending review')
    code = execution['execution_pins']
    check(set(code) == review.code_paths(EXECUTION) == review.code_paths(NEW), 'Complete execution pin universe retained', paths=len(code))
    review.pin_check(EXECUTION,code,'All corrected execution pins equal execution Git source')
    review.pin_check(NEW,code,'All corrected execution pins equal candidate Git source')
    check(all(sha256((review.ROOT/name).read_bytes()).hexdigest() == sha for name,sha in code.items()), 'All corrected execution pins equal actual working bytes')
    check(execution['input_hashes'] == doc(review.EXEC_LOCK,OLD)['input_hashes'] and execution['budget'] == doc(review.EXEC_LOCK,OLD)['budget'] and execution['design_lock_sha256'] == doc(review.EXEC_LOCK,OLD)['design_lock_sha256'], 'All96 inputs, budget and design lock remain exactly frozen')
    check(execution['interpreter_sha256'] == sha256(Path(sys.executable).read_bytes()).hexdigest(), 'Corrected lock interpreter is actual verification interpreter')
    changed = set(git('diff','--name-only',OLD,NEW,'--','src','scripts','configs').decode().splitlines())
    check(changed == {'scripts/verify_confirmation_freeze.py','scripts/analyze_registered_confirmation.py'}, 'Only the two reviewed tool functions changed in execution universe')
    verifier = review.function('scripts/verify_confirmation_freeze.py','verify',NEW)
    guards = [node for node in ast.walk(verifier) if isinstance(node,ast.Call) and isinstance(node.func,ast.Name) and node.func.id == 'all' and "execution['execution_pins'].items()" in ast.unparse(node)]
    check(len(guards) == 1, 'Standalone verifier checks all execution working bytes')
    expression = compile(ast.Expression(guards[0]),'<frozen-working-byte-guard>','eval')
    digest = lambda raw: sha256(raw).hexdigest()
    check(eval(expression,dict(execution=execution,ROOT=review.ROOT,digest=digest,all=all)), 'Working-byte guard admits actual exact snapshot')

    class VirtualPath:
        def __init__(self,path): self.path=path
        def read_bytes(self):
            if self.path.as_posix().endswith('/scripts/registered_confirmation.py'):
                return b'virtual incompatible local change; no file was modified'
            return self.path.read_bytes()

    class VirtualRoot:
        def __truediv__(self,path): return VirtualPath(review.ROOT/path)

    check(not eval(expression,dict(execution=execution,ROOT=VirtualRoot(),digest=digest,all=all)), 'Working-byte guard refuses virtual dirty new runner without modifying any file')
    analyzer = review.function('scripts/analyze_registered_confirmation.py','analyze',NEW)
    refusals = [node for node in ast.walk(analyzer) if isinstance(node,ast.Call) and isinstance(node.func,ast.Name) and node.func.id == 'require' and len(node.args)>1 and isinstance(node.args[1],ast.Constant) and node.args[1].value == 'Failed or interrupted confirmation requires an explicit failure audit before classification']
    check(len(refusals) == 1, 'Analyzer explicitly refuses unaudited failure classification')
    refusal = refusals[0]
    gate = compile(ast.Expression(refusal.args[0]),'<frozen-failure-audit-guard>','eval')
    check(eval(gate,dict(total=dict(failed=0,interrupted=0))), 'Failure-audit guard admits completed accounting')
    check(not eval(gate,dict(total=dict(failed=1,interrupted=0))), 'Failure-audit guard refuses failed accounting')
    check(not eval(gate,dict(total=dict(failed=0,interrupted=1))), 'Failure-audit guard refuses interrupted accounting')
    summarize = [node for node in ast.walk(analyzer) if isinstance(node,ast.Call) and isinstance(node.func,ast.Name) and node.func.id == 'summarize']
    check(len(summarize) == 1 and refusal.lineno < summarize[0].lineno, 'Failure refusal precedes any outcome classification')
    first = doc(review.OLD+'/receipt.json')
    check(first['status'] == 'FAIL' and first['prepared_inputs'] == first['physical_calls'] == first['selector_calls'] == 0, 'Original zero-input preparation refusal still explicitly failed')
    check(doc(review.PREP+'/receipt.json')['prepared_inputs'] == 96, 'Successful input-only package retains96 originals')
    report = dict(status='PASS_FOCUSED_STANDARDS_CLOSURE',axis='Standards',previous_candidate=OLD,candidate=NEW,execution_source=EXECUTION,closed_findings=[dict(original='verify_confirmation_freeze.py:36–38 omitted current execution working bytes',resolution='All269 working bytes are now checked; virtual dirty new runner is refused.')],remaining_hard_findings=[],advisory_smell_findings=[],checks=review.checks,scope=dict(nonce_reads=0,seed_derivations=0,facility_calls=0,selector_calls=0,held_inputs_generated=0,registered_trials=0,tracked_edits=0),authorization='Pending32 authority and REVIEWED_FOR_EXECUTION status remain required before33.')
    (OUT/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:v for k,v in report.items() if k != 'checks'},ensure_ascii=False))
    print('Focused checks:',len(review.checks))


if __name__ == '__main__': main()
