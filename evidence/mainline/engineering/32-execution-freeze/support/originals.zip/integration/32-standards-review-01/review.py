"""Independent, saved-only standards audit; never imports project execution code."""
import ast
from copy import deepcopy
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(r'C:\Users\Donson\.codex\worktrees\mainline32-confirmation-freeze\Renly')
OUT = Path(__file__).resolve().parent
BASE = 'ef790a2efd5a05abb83aa12de4e8a865b65c8d81'
CANDIDATE = '9fc1b42207d4fa417cc91a55beaaf5a0fad51eff'
EXECUTION = '537317a56ec9389e349a7896c6d9531acb562b1c'
PREPARATION = '23a129d434802404c9138ba7e1a2b3a703836874'
PREP = 'evidence/mainline/research/32-confirmation-freeze/prepared-02'
OLD = 'evidence/mainline/research/32-confirmation-freeze/prepared-01'
LOCK = 'docs/mainline/evidence/30-protocol-lock.json'
EXEC_LOCK = 'docs/mainline/evidence/30-confirmation-execution-lock.json'
PROTOCOL = 'docs/mainline/30-comparison-protocol-v1.json'
checks = []
cache = {}


def check(condition, label, **facts):
    if not condition:
        raise AssertionError(label)
    checks.append(dict(check=label, status='PASS', **facts))


def git(*args, input=None):
    return subprocess.run(['git', *args], cwd=ROOT, input=input, capture_output=True, check=True).stdout


def fetch(rev, paths):
    missing = sorted(set(paths) - set(cache.get(rev, {})))
    if not missing:
        return
    refs = ''.join(f'{rev}:{p}\n' for p in missing).encode()
    raw = git('cat-file', '--batch', input=refs)
    offset = 0
    for path in missing:
        end = raw.index(b'\n', offset)
        header = raw[offset:end].split()
        if len(header) != 3 or header[1] != b'blob':
            raise AssertionError(f'Missing immutable blob: {rev}:{path}')
        size = int(header[2])
        offset = end + 1
        cache.setdefault(rev, {})[path] = raw[offset:offset + size]
        offset += size + 1
    check(offset == len(raw), f'Exact Git batch read {rev[:8]}', blobs=len(missing))


def blob(path, rev=CANDIDATE):
    fetch(rev, [path])
    return cache[rev][path]


def doc(path, rev=CANDIDATE):
    return json.loads(blob(path, rev))


def digest(raw):
    return sha256(raw).hexdigest()


def tree(rev, *paths):
    return set(filter(None, git('ls-tree', '-r', '-z', '--name-only', rev, *paths).decode().split('\0')))


def code_paths(rev):
    return {p for p in tree(rev, 'src', 'scripts', 'configs') if p.endswith(('.py', '.json'))}


def pin_check(rev, pins, label):
    fetch(rev, pins)
    check(all(digest(blob(p, rev)) == h for p, h in pins.items()), label, paths=len(pins))


def function(path, name, rev=CANDIDATE):
    module = ast.parse(blob(path, rev).decode())
    return next(n for n in module.body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)) and n.name == name)


def main():
    before = git('rev-parse', 'HEAD').decode().strip()
    check(git('merge-base', '--is-ancestor', BASE, CANDIDATE) == b'', 'Accepted31 precedes final candidate')
    check(git('merge-base', '--is-ancestor', PREPARATION, EXECUTION) == b'', 'Preparation precedes execution source')
    check(git('merge-base', '--is-ancestor', EXECUTION, CANDIDATE) == b'', 'Execution source precedes freeze candidate')
    plan, lock, execution = doc(PROTOCOL), doc(LOCK), doc(EXEC_LOCK)
    check(blob(PROTOCOL) == blob(PROTOCOL, BASE) and blob(LOCK) == blob(LOCK, BASE), 'Preregistered design and private phase commitments unchanged')
    namespaces = plan['seed_policy']['namespaces']
    check(len(namespaces.values()) == len(set(namespaces.values())), 'Independent declared phase namespaces', phases=sorted(namespaces))
    check(len(lock['commitments_sha256']) == len(set(lock['commitments_sha256'].values())) == 3, 'Three separate retained phase commitments')
    pin_check(lock['design_commit'], lock['pins'], 'Original source lock exact Git blobs')
    pin_check(CANDIDATE, lock['pins'], 'All original frozen source preserved in candidate')
    check(execution['execution_source'] == EXECUTION and execution['status'] == 'PENDING_REVIEW', 'Prospective lock remains pending actual review')
    check(set(execution['execution_pins']) == code_paths(EXECUTION) == code_paths(CANDIDATE), 'Exact complete execution file universe', paths=len(execution['execution_pins']))
    pin_check(EXECUTION, execution['execution_pins'], 'Frozen execution source exact Git blobs')
    pin_check(CANDIDATE, execution['execution_pins'], 'Candidate runtime equals frozen execution source')
    check(execution['interpreter_sha256'] == digest(Path(sys.executable).read_bytes()), 'Actual verifier interpreter matches frozen interpreter')
    check(execution['design_lock_sha256'] == digest(blob(LOCK)), 'Execution lock binds unchanged design lock')
    budget = dict(attempts=96, simulated_charge_s=960, scheduled_decisions=960)
    check(execution['budget'] == plan['phases']['confirmation']['budget'] == budget, 'Budget remains96 attempts960 seconds960 decisions')
    old, prepared = doc(OLD + '/receipt.json'), doc(PREP + '/receipt.json')
    check(old['status'] == 'FAIL' and old['prepared_inputs'] == old['physical_calls'] == old['selector_calls'] == old['registered_research_trials'] == 0, 'Original failed input refusal remains zero physical work')
    check(set(old['artifacts']) == {'attempts.jsonl'} and not old['input_hashes'] and not old['assigned_worlds'], 'Old refusal never relabelled or supplied missing originals')
    check('seed' in old['error'].lower(), 'Original refusal retains its seed-interface error')
    check(prepared['status'] == 'PASS_INPUT_ONLY' and prepared['source'] == PREPARATION and prepared['prepared_inputs'] == 96 and prepared['physical_calls'] == prepared['selector_calls'] == prepared['registered_research_trials'] == 0, 'Second preparation is input-only with exact source and counts')
    pin_check(PREPARATION, prepared['pins'], 'Preparation receipt source pins equal actual preparation revision')
    check(prepared['nonce_commitment'] == lock['commitments_sha256']['confirmation'], 'Preparation commitment matches original confirmation commitment')
    entries = tree(CANDIDATE, PREP)
    relative = {p[len(PREP)+1:] for p in entries}
    check(relative == set(prepared['artifacts']) | {'receipt.json'}, 'Prepared delivered set equals declared durable manifest', artifacts=len(entries))
    fetch(CANDIDATE, entries)
    check(all(digest(blob(PREP + '/' + p)) == h for p, h in prepared['artifacts'].items()), 'Every prepared durable artifact matches its SHA')
    ledger = [json.loads(row) for row in blob(PREP + '/attempts.jsonl').splitlines()]
    worlds = plan['phases']['confirmation']['worlds']
    arms = plan['phases']['confirmation']['arms']
    check(len(ledger) == 32 and all(ledger[i*2]['status'] == 'STARTED_INPUT_WORLD' and ledger[i*2+1]['status'] == 'COMPLETED_INPUT_WORLD' and ledger[i*2]['world_id'] == ledger[i*2+1]['world_id'] == w['id'] for i,w in enumerate(worlds)), 'Saved input preparation journal reconciles16 starts16 completions')
    expected = {w['id']+'/'+a+'.json' for w in worlds for a in arms}
    check(set(prepared['input_hashes']) == set(execution['input_hashes']) == expected and prepared['input_hashes'] == execution['input_hashes'], 'Execution lock binds exact96 input names and hashes')
    amendment = doc('docs/mainline/32-hydraulic-admission-amendment.json')
    original = doc(amendment['original_blueprint'])
    corrected = doc(amendment['corrected_blueprint'])
    expected_blueprint = deepcopy(original)
    for phase, variant, oldvalue in [('confirmation','mr-a',.875), ('ablation','am-a',.9375)]:
        row = expected_blueprint[phase]['misleading-report'][0]
        check(row['variant'] == variant and row['filter_multiplier'] == oldvalue, 'Original retained public coordinate '+variant)
        row['filter_multiplier'] = 1
    check(expected_blueprint == corrected and digest(blob(amendment['original_blueprint'])) == amendment['original_sha256'] and digest(blob(amendment['corrected_blueprint'])) == amendment['corrected_sha256'], 'Hydraulic amendment changes exactly two declared prospective coordinates')
    assignments = {r['world_id']:r for r in prepared['assigned_worlds']}
    check(len(assignments) == 16, 'All independent world assignments retained')
    pairs = set()
    for world in worlds:
        row = assignments[world['id']]
        recipe = next(r for r in corrected['confirmation'][world['family']] if r['variant'] == row['variant'])
        common, seeds = [], set()
        for arm in arms:
            name = world['id']+'/'+arm+'.json'
            raw = blob(PREP+'/inputs/'+name)
            document = json.loads(raw)
            check(digest(raw) == execution['input_hashes'][name], 'Immutable saved input '+name)
            program = document['dispatch_program']
            params = {p['id']:p['value'] for p in document['model']['parameters']}
            check(document['duration_s'] == 10 and document['maximum_step_s'] == .01 and params['network_service_capacity'] == recipe['network_cap'] and params['filter_resistance_multiplier'] == recipe['filter_multiplier'] and document['boundary_events'] == recipe['events'], 'Declared physical recipe '+name)
            fixed = program['sensor_program']['realization']['seed']
            portable = program['inspection_program']['realizations']['lookahead-inspect']['seed']
            check(type(fixed) is int and 0 <= fixed < 2**64 and type(portable) is int and 0 <= portable < 2**128, 'Saved channel domains '+name)
            seeds.add((portable,fixed))
            policy = program['policy_program']
            check(policy['policy'] == arm and program['decision_times_s'] == plan['decision_times_s'] and policy['resource_budget'] == plan['comparison']['common_admission_budget'], 'Shared decision and resource law '+name)
            policy.pop('policy');policy.pop('options')
            common.append(digest(json.dumps(document,sort_keys=True,separators=(',',':')).encode()))
        check(len(set(common)) == len(seeds) == 1, 'All six arms share actual world and private seed pair '+world['id'])
        pairs.update(seeds)
    check(len(pairs) == 16, 'Independent worlds have16 distinct saved seed pairs')
    for family in corrected['confirmation']:
        variants = [r['variant'] for r in assignments.values() if r['family'] == family]
        check(len(variants) == len(set(variants)) == 4, 'No recipe duplication within family '+family)
    capture = function('scripts/registered_confirmation.py','capture')
    previous = function('scripts/registered_development.py','capture', BASE)
    for node in ast.walk(capture):
        if isinstance(node,ast.keyword) and node.arg in ('held_inputs_read','held_seed_reads'):
            node.value = ast.Constant(value=0)
    check(ast.dump(capture,include_attributes=False) == ast.dump(previous,include_attributes=False), 'Confirmation retains accepted31 journal and failure algorithm exactly except declared held-access counts')
    prepare = function('scripts/prepare_confirmation.py','prepare')
    calls = [n for n in ast.walk(prepare) if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id == 'observation_seed']
    check(len(calls) == 2 and {n.args[-1].value for n in calls} == {'portable','fixed'} and all(ast.unparse(n.args[1:5][0]) == "plan['id']" for n in calls), 'Static seed law has exactly one call per registered channel')
    shifts = [n for n in ast.walk(prepare) if isinstance(n,ast.BinOp) and isinstance(n.op,ast.RShift)]
    check(len(shifts) == 1 and shifts[0].right.value == 64 and shifts[0].left.args[-1].value == 'fixed', 'Only fixed channel uses explicitly amended upper64 projection')
    changes = git('diff','--name-only',BASE,CANDIDATE,'--','src','scripts').decode().splitlines()
    check(set(changes) == {'scripts/prepare_confirmation.py','scripts/registered_confirmation.py','scripts/analyze_registered_confirmation.py','scripts/verify_confirmation_freeze.py'}, 'Accepted physical and decision runtime untouched')
    workflow = blob('.github/workflows/acceptance.yml').decode()
    check('fetch-depth: 0' in workflow and 'persist-credentials: false' in workflow, 'CI preserves credentials isolation and retrieves immutable ancestor history')
    check(git('rev-parse','HEAD').decode().strip() == before, 'Reviewer changed no Git revision')
    result = dict(status='PASS_SAVED_STATIC_STANDARDS_REVIEW',axis='Standards',base=BASE,candidate=CANDIDATE,execution_source=EXECUTION,preparation_source=PREPARATION,checks=checks,hard_findings=[],advisory_smell_findings=[],scope=dict(nonce_reads=0,seed_derivations=0,facility_calls=0,selector_calls=0,held_inputs_generated=0,tracked_edits=0,registered_trials=0),limitations=['Prospective execution lock is intentionally pending review; authorization to run requires accepted32 authority and REVIEWED_FOR_EXECUTION status.','Saved seed pairing and static HMAC channel law verified without nonce access or seed regeneration.'])
    (OUT/'report.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:v for k,v in result.items() if k not in ('checks','limitations')},ensure_ascii=False))
    print('Independent bounded checks:',len(checks))


if __name__ == '__main__':
    main()
