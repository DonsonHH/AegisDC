import json,subprocess,sys
from pathlib import Path
root=Path(__file__).resolve().parents[1]
target=root/'scripts/analyze_registered_confirmation.py'
raw=target.read_bytes()
try:
    target.write_bytes(raw+b'\n# Working byte mismatch probe; never executed as a trial.\n')
    run=subprocess.run([sys.executable,'-B','-X','utf8','scripts/verify_confirmation_freeze.py'],
        cwd=root,capture_output=True,text=True,encoding='utf-8')
finally:
    target.write_bytes(raw)
print(json.dumps(dict(returncode=run.returncode,stdout=run.stdout,stderr=run.stderr,
                     restored_exact_bytes=target.read_bytes()==raw,physical_calls=0,selector_calls=0)))
