import json,sys,subprocess
from hashlib import sha256
from pathlib import Path
root=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root/'scripts'))
from inspection_delivery import hashes
lockpath=root/'docs/mainline/evidence/30-confirmation-execution-lock.json'
raw=lockpath.read_bytes();lock=json.loads(raw)
old=root/'evidence/mainline/engineering/32-execution-freeze/superseded-execution-lock-01.json'
if sys.argv[1]=='preserve':
    with old.open('xb') as f:f.write(raw)
    note=dict(schema='aegisdc-prospective-tool-correction-v1',date='2026-11-08',
        superseded_lock=old.relative_to(root).as_posix(),superseded_lock_sha256=sha256(raw).hexdigest(),
        superseded_execution_source=lock['execution_source'],confirmation_calls_before_correction=0,
        changes=['Reject classification of any failed/interrupted confirmation until an explicit failure audit.',
                 'Verify every frozen executable working byte in the no-execution freeze CLI.'],
        unchanged=['96 prepared inputs','original design/runtime/recipes/methods and metrics','budget and phase nonce'],
        evidence='Original reviewer findings and red/green checks are retained in the acceptance support archive.')
    (root/'docs/mainline/32-tool-review-correction.json').write_text(json.dumps(note,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
else:
    source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
    lock['execution_source']=source
    lock['execution_pins']=hashes(source,lock['execution_pins'])
    lockpath.write_text(json.dumps(lock,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
    print(json.dumps(dict(execution_source=source,pins=len(lock['execution_pins']),inputs=len(lock['input_hashes']),physical_calls=0)))
