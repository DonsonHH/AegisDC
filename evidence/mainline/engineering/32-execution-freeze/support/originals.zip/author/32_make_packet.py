import json,subprocess
from hashlib import sha256
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
root=Path(__file__).resolve().parents[1]
integration=Path('C:/Users/Donson/Documents/ChatGPT/Renly')
def read(path):return json.loads(path.read_bytes())
def write(path,obj):path.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
def sha(raw):return sha256(raw).hexdigest()
package=root/'evidence/mainline/engineering/32-execution-freeze/support'
package.mkdir()
files={}
for folder in ['32-spec-review-01','32-standards-review-01','32-standards-review-02','32-standards-delivery-note-01','31-shallow-ci-failure']:
    source=integration/'.work'/folder
    assert source.is_dir(),source
    for p in source.rglob('*'):
        if p.is_file() and p.suffix not in ('.pyc','.pyo') and '__pycache__' not in p.parts:
            files['integration/'+p.relative_to(integration/'.work').as_posix()]=p.read_bytes()
for name in ['31-main-publication-01.json','31-main-failure-refreshed-01.json',
             '31-history-fix-main-publication-01.json','31-history-fix-integration-publication-01.json',
             '32-fresh-byte-admission-01.json','32-fresh-byte-admission-01.log','32-fresh-freeze-proof-03.json',
             '32-fresh-freeze-proof-04.json','32_fresh_byte_admission.py']:
    files['integration/'+name]=(integration/'.work'/name).read_bytes()
for folder in ['32-static-preflight-01','32-input-launch-01','32-input-launch-02']:
    for p in (root/'.work'/folder).iterdir():
        if p.is_file():files['author/'+folder+'/'+p.name]=p.read_bytes()
for name in ['32_working_guard_probe.py','32-working-guard-red-01.json','32-working-guard-green-01.json',
             '32-failure-audit-red-01.log','32-failure-audit-green-01.log','32-freeze-proof-01.json',
             '32-freeze-proof-02.json','32_freeze_correction.py','32_make_packet.py']:
    files['author/'+name]=(root/'.work'/name).read_bytes()
with ZipFile(package/'originals.zip','x',compression=ZIP_DEFLATED,compresslevel=9) as archive:
    for name,raw in sorted(files.items()):archive.writestr(name,raw)
write(package/'manifest.json',dict(schema='aegisdc-preserved-review-originals-v1',
    archive_sha256=sha((package/'originals.zip').read_bytes()),members={n:sha(v) for n,v in sorted(files.items())},
    classification='ENGINEERING_INPUT_ONLY_AND_SAVED_REVIEW_NOT_RESEARCH_TRIALS',
    physical_calls=0,selector_calls=0,original_failed_input_preparations=1,
    original_spec_findings=1,original_standards_findings=1,unresolved_findings=0))
lockpath=root/'docs/mainline/evidence/30-confirmation-execution-lock.json'
lock=read(lockpath);lock['status']='REVIEWED_FOR_EXECUTION';write(lockpath,lock)
proof=read(integration/'.work/32-fresh-freeze-proof-04.json')
proof.update(delivery='5534d4258b7fc170cc35264eba802614f48f752b',
    exact_source_blobs=True,checkout_translation_correction='support/originals.zip:integration/32-fresh-byte-admission-01.json',
    working_tree_after_exact_index_refresh='CLEAN_NO_BLOB_CHANGES')
write(root/'docs/mainline/evidence/32-root-delivery.json',proof)
write(root/'docs/mainline/evidence/32-root.json',dict(status='ACCEPTED',ticket='32',milestone='M5',date='2026-11-08',
    scope='INDEPENDENT_CONFIRMATION_INPUT_AND_EXECUTION_FREEZE_ONLY',
    reviewed_candidate='5534d4258b7fc170cc35264eba802614f48f752b',execution_source=lock['execution_source'],
    execution_lock=lockpath.relative_to(root).as_posix(),execution_lock_sha256=sha(lockpath.read_bytes()),
    worlds=16,inputs=96,physical_calls=0,selector_calls=0,registered_confirmation_attempts=0,
    failed_input_preparations=1,failed_preparation_scope='INPUT_ONLY_ZERO_PHYSICAL_OR_SELECTOR_CALLS',
    preparation_source='23a129d434802404c9138ba7e1a2b3a703836874',
    original_failure='evidence/mainline/research/32-confirmation-freeze/prepared-01/receipt.json',
    input_delivery='evidence/mainline/research/32-confirmation-freeze/prepared-02/receipt.json',
    independent_reviews=dict(spec='PASS_0_UNRESOLVED',standards='PASS_0_UNRESOLVED'),
    support_manifest=package.relative_to(root).as_posix()+'/manifest.json',
    fresh_proof='docs/mainline/evidence/32-root-delivery.json',field_calibration='PENDING',next_ticket='33'))
write(root/'docs/mainline/evidence/31-publication.json',dict(status='PUBLISHED_WITH_PRESERVED_CI_CORRECTION',ticket='31',
    original_failed_push=read(integration/'.work/31-main-failure-refreshed-01.json'),
    reason='Shallow checkout lacked immutable source ancestry; registered development data unchanged.',
    correction_commit='3dc8778e1280bb3a3b4fc378726604f387ce68e4',
    main=read(integration/'.work/31-history-fix-main-publication-01.json'),
    integration=read(integration/'.work/31-history-fix-integration-publication-01.json'),
    failure_originals=package.relative_to(root).as_posix()+'/originals.zip',new_registered_runs=0))
progresspath=root/'docs/mainline/progress.json';progress=read(progresspath)
progress['current_ticket']='33'
progress['research_trials']['confirmation'].update(materialized=True,worlds=16,inputs=96,attempts=0)
progress['milestones'][5]['acceptance_evidence'].append('docs/mainline/evidence/32-root.json')
progress['milestones'][5]['progress_scope']='31 development complete;32 independently reviewed executable/input freeze accepted;33 original confirmation next.'
progress['liveness_refresh']='2026-11-08: root owns33 after32 acceptance; both32 reviewers passed,0 confirmation calls.'
progress['active_implementations']=[dict(ticket='33',owner='/root',worktree='mainline-33-confirmation',state='ready_after32')]
write(progresspath,progress)
ticket=root/'.scratch/full-facility-mainline/issues/32-freeze-execution.md'
text=ticket.read_text(encoding='utf-8').replace('**Status:** claimed','**Status:** resolved').replace('- [ ]','- [x]')
text=text.replace('Pending implementation and acceptance.','Accepted: docs/mainline/evidence/32-root.json; exact96 inputs and269 execution pins; no physical calls. One input-only failure, both review findings and all corrections retained.')
ticket.write_text(text,encoding='utf-8',newline='\n')
mainline=root/'docs/MAINLINE.md';text=mainline.read_text(encoding='utf-8')
text=text.replace('当前主票 32 核对独立确认输入与执行版本','第32项已接受96份独立确认输入与精确执行版本，当前主票33执行确认')
text += '\n[第32项确认输入与执行冻结](mainline/32-confirmation-freeze.md)保留输入准备失败、两项审查发现和修正；96份输入已核对，正式确认运行仍为零。第31项CI历史检出问题已修复，main与集成分支实际CI成功。\n'
mainline.write_text(text,encoding='utf-8',newline='\n')
report='''# 第32项：确认输入与执行版本冻结

16个独立工况、每个6种方法，共96份输入已冻结。四类工况各4个，主配对只改变策略名；实际设施、外生条件、资源和证据生成规则保持一致。预算固定96次、960秒模拟时间、960个调度时点。

执行版本为`81d309685529cbd01130f06048035bd457e749f1`。269个Python/JSON执行文件、解释器和96个输入SHA均受门槛核对；原30协议、61个设计源、原种子承诺不变。第33项开始前不得增删或改写执行文件。

公开水力准入检查发现两处原参数超出已有流量上限，因此在确认结果出现前显式修订为既有基线下限1；原蓝图和拒绝记录保留。第一次输入准备因固定测点64位种子接口失败，0份成功、0物理调用、0策略调用；另列接口修订后准备96份，便携测量种子仍128位，不重采样。两次输入准备不是效果试验。

Spec与Standards原各发现1项工具缺口，现均修复并独立关闭。分析遇到失败或中断必须先明确审计原因，不输出可能掩盖约束违规的结论；冻结核验也检查实际工作字节。保留原发现、红绿检查、旧锁和新锁。

Windows新检出对13份旧配置进行了CRLF转换，首次字节复核拒绝。精确分类与原哈希保留；加入JSON LF检出规则后，精确Git原件与冻结SHA一致。没有重跑输入或设施。

[权威记录](evidence/32-root.json) · [新检出证明](evidence/32-root-delivery.json) · [全部审查与失败原件清单](../../evidence/mainline/engineering/32-execution-freeze/support/manifest.json) · [第31项实际CI修复](evidence/31-publication.json)

正式确认尚未执行。已有注册效果尝试仍为36次开发运行，不能将本项冻结视为正收益。研究设施仍为郑州工程参照下的合成设施，现场标定待完成。
'''
(root/'docs/mainline/32-confirmation-freeze.md').write_text(report,encoding='utf-8',newline='\n')
print(json.dumps(dict(status='PACKET_WRITTEN',support_members=len(files),physical_calls=0,confirmation_attempts=0)))
