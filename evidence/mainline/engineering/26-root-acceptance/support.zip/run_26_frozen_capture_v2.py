"""Record the actual interpreter flags/cache isolation of the one frozen capture."""
from hashlib import sha256
import json
import os
from pathlib import Path
import subprocess
import sys
from datetime import datetime, timezone

ROOT = Path('C:/Users/Donson/.codex/worktrees/mainline23-intervention/Renly')
SOURCE = '35193647091f90d17c339976ae47ef69385e9a43'
RUN = ROOT / '.work/26-frozen-launch-20261107-02'
OUTPUT = 'evidence/mainline/engineering/26-candidate/capture-20261107-02'


def write(path, value):
    with path.open('x', encoding='utf-8', newline='\n') as stream:
        stream.write(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
        stream.flush()
        os.fsync(stream.fileno())


assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == SOURCE
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT)
assert not (ROOT / OUTPUT).exists()
assert not RUN.exists()
RUN.mkdir()
prefix = RUN / 'empty-python-cache-prefix'
assert not prefix.exists()
command = [sys.executable, '-B', '-X', 'utf8', 'scripts/candidate_delivery.py', 'capture', '--capture', OUTPUT]
env = dict(os.environ, PYTHONPATH=str(ROOT / 'src'), PYTHONPYCACHEPREFIX=str(prefix),
    PYTHONDONTWRITEBYTECODE='1', PYTHONHASHSEED='0')
start = dict(status='STARTED', source=SOURCE, command=command, cwd=str(ROOT),
    environment={key: env[key] for key in ('PYTHONPATH', 'PYTHONPYCACHEPREFIX', 'PYTHONDONTWRITEBYTECODE', 'PYTHONHASHSEED')},
    cache_prefix_existed_before=False, python_executable_sha256=sha256(Path(sys.executable).read_bytes()).hexdigest(),
    launcher_sha256=sha256(Path(__file__).read_bytes()).hexdigest(), utc=datetime.now(timezone.utc).isoformat(),
    classification='ONE_FROZEN_ENGINEERING_CAPTURE_NOT_EFFECT_EXPERIMENT')
write(RUN / 'launch.json', start)
with (RUN / 'stdout.txt').open('x', encoding='utf-8') as stdout, (RUN / 'stderr.txt').open('x', encoding='utf-8') as stderr:
    process = subprocess.Popen(command, cwd=ROOT, env=env, stdout=stdout, stderr=stderr)
    write(RUN / 'process.json', dict(pid=process.pid, source=SOURCE))
    returncode = process.wait()
write(RUN / 'terminal.json', dict(status='COMPLETED' if returncode == 0 else 'FAILED', returncode=returncode,
    source=SOURCE, utc=datetime.now(timezone.utc).isoformat(),
    output_receipt_exists=(ROOT / OUTPUT / 'receipt.json').exists(),
    stdout_sha256=sha256((RUN / 'stdout.txt').read_bytes()).hexdigest(), stderr_sha256=sha256((RUN / 'stderr.txt').read_bytes()).hexdigest()))
print((RUN / 'stdout.txt').read_text(encoding='utf-8'))
if returncode:
    print((RUN / 'stderr.txt').read_text(encoding='utf-8'))
raise SystemExit(returncode)
