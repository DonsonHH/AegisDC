const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const dependencyRoot = 'C:/Users/Donson/.cache/codex-runtimes/codex-primary-runtime/dependencies/node';
const sharp = require(dependencyRoot + '/node_modules/sharp');
const source = 'C:/Users/Donson/.codex/worktrees/mainline23-intervention/Renly/evidence/mainline/engineering/26-candidate/capture-20261107-02';
const output = path.resolve('.work/26-capture-visual-qa-01');
const sha = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
async function main() {
  fs.mkdirSync(output);
  const files = {};
  for (const name of ['actual-online', 'decision-values', 'candidate-boundary']) {
    const svg = fs.readFileSync(path.join(source, name + '.svg'));
    fs.writeFileSync(path.join(output, name + '.svg'), svg, {flag: 'wx'});
    const png = path.join(output, name + '.png');
    await sharp(svg, {density: 144}).png().toFile(png);
    const metadata = await sharp(png).metadata();
    files[name] = {svg_sha256: sha(svg), png_sha256: sha(fs.readFileSync(png)), width: metadata.width, height: metadata.height};
  }
  const result = {status: 'RENDERED_PENDING_ACTUAL_VIEW', source, execution: '35193647091f90d17c339976ae47ef69385e9a43',
    data_delivery: '53f09ff4e232ebfac6b64bd6e15bb8649146810b', node: process.version, node_executable: process.execPath,
    node_executable_sha256: sha(fs.readFileSync(process.execPath)), sharp_versions: sharp.versions,
    sharp_package_sha256: sha(fs.readFileSync(dependencyRoot + '/node_modules/sharp/package.json')),
    renderer_sha256: sha(fs.readFileSync(__filename)), files, new_selector_calls: 0, new_physical_runs: 0};
  fs.writeFileSync(path.join(output, 'render.json'), JSON.stringify(result, null, 2) + '\n', {flag: 'wx'});
  console.log(JSON.stringify(result));
}
main().catch(error => { console.error(error); process.exitCode = 1; });
