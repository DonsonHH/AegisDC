"""Independent literal arithmetic, with no AegisDC imports or physical calls."""
from fractions import Fraction as F
from hashlib import sha256
import json
from pathlib import Path

root=Path(__file__).resolve().parents[1]
contract=root.parent.parent.parent if False else Path('C:/Users/Donson/.codex/worktrees/mainline23-intervention/Renly/docs/mainline/26-evidence-consistent-candidate.md')
bad=F(1,4);good=F(3,4);horizon=F(6)
positive_bad=bad*F(4,5);positive_good=good*F(1,10)
negative_bad=bad-positive_bad
positive=positive_bad+positive_good
# For the named literal witness only: quarter-second wait followed by one
# second of unavailable capacity; inspection report at7/4, then action2..3.
defer=horizon*bad
direct=F(1,4)*bad+F(1)
adaptive_positive=F(2)*positive_bad+positive*F(1)
adaptive_negative=horizon*negative_bad
adaptive=adaptive_positive+adaptive_negative
nonadaptive_delayed_action=F(2)*bad+F(1)
assert defer==F(3,2) and direct==F(17,16) and adaptive==F(39,40)
assert nonadaptive_delayed_action==defer
assert adaptive<direct<defer
report_law_marginal=dict(bad=F(4,5)+F(1,5),good=F(1,10)+F(9,10))
assert all(mass==1 for mass in report_law_marginal.values())
def exact(value):return dict(numerator=value.numerator,denominator=value.denominator,value=float(value))
result=dict(schema='aegisdc-independent-literal-value-witness-v1',classification='PRE_IMPLEMENTATION_PURE_ARITHMETIC_NOT_POLICY_EFFECT_EVIDENCE',
 assumptions=['Six-second horizon with unit demand; impairment prior1/4, otherwise healthy.',
 'The same positive-report law:4/5 given impairment and1/10 otherwise.',
 'Inspection completion5/4, report7/4; direct action1/4..5/4, delayed action2..3.',
 'Intervention removes all service capacity during one second of work, then fully restores it.',
 'Prospective report cannot change the declared updater or continuation in the non-adaptive projection.',
 'No future background arrivals and no belief-epoch crossing in this finite projection.'],
 expected_service_deficit_s={name:exact(value) for name,value in dict(defer=defer,direct_intervention=direct,
 closest_baseline_informative_inspection=adaptive,nonadaptive_inspection_then_defer=defer,
 nonadaptive_inspection_then_intervene=nonadaptive_delayed_action).items()},
 original_report_marginal_by_state={k:exact(v) for k,v in report_law_marginal.items()},
 expected_selection=dict(closest_baseline='inspect',candidate='direct_intervention'),
 interpretation='Marginalization keeps the original state weights; it does not replace likelihoods, forge a report, or establish physical gain.',
 contract_at_observation_sha256=sha256(contract.read_bytes()).hexdigest(),script_sha256=sha256(Path(__file__).read_bytes()).hexdigest(),
 new_application_calls=0,new_simulate_calls=0,new_tests=0,new_inference=0,new_training=0,registered_research_trials=0)
with (root/'.work/26-independent-admission-value-witness-01.json').open('x',encoding='utf-8',newline='\n') as stream:
    stream.write(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
print(json.dumps(result,ensure_ascii=False))
