"""Literal probability witnesses independent of AegisDC project execution."""
from fractions import Fraction as F
from hashlib import sha256
import json
from pathlib import Path
import subprocess

root=Path(__file__).resolve().parents[1]
revision=subprocess.check_output(['git','rev-parse','aac1ccea'],cwd=root,text=True).strip()
contract=subprocess.check_output(['git','cat-file','blob',revision+':docs/mainline/26-projection-law-next-slice.md'],cwd=root)
bad=F(1,4);good=1-bad
positive=bad*F(4,5)+good*F(1,10)
negative=1-positive
positive_bad=bad*F(4,5)/positive
negative_bad=bad*F(1,5)/negative
assert positive_bad==F(8,11) and negative_bad==F(2,29)
# If success is a random event with different state probabilities, conditioning
# changes the world mixture. This is not the proposed per-world sure regime.
support=bad*F(1,2)+good*F(1)
bad_after_support=bad*F(1,2)/support
assert bad_after_support==F(1,7) and bad_after_support!=bad
# Independent two-hypothesis/two-outcome worked counterexample. Report law
# depends on outcome, while the updater retains only hypothesis probabilities.
prior_a=F(1,2);prior_b=F(1,2)
bad_given_a=F(4,5);bad_given_b=F(1,5)
bad_prior=prior_a*bad_given_a+prior_b*bad_given_b
positive_given_bad=F(4,5);positive_given_good=F(1,10)
positive_given_a=bad_given_a*positive_given_bad+(1-bad_given_a)*positive_given_good
positive_given_b=bad_given_b*positive_given_bad+(1-bad_given_b)*positive_given_good
positive_mass=prior_a*positive_given_a+prior_b*positive_given_b
true_bad_posterior=bad_prior*positive_given_bad/positive_mass
a_posterior=prior_a*positive_given_a/positive_mass
b_posterior=1-a_posterior
recombined_bad=a_posterior*bad_given_a+b_posterior*bad_given_b
assert positive_given_a==F(33,50) and positive_given_b==F(6,25)
assert true_bad_posterior==F(8,9) and recombined_bad==F(16,25)
assert true_bad_posterior!=recombined_bad
def exact(value):return dict(numerator=value.numerator,denominator=value.denominator,value=float(value))
result=dict(schema='aegisdc-independent-projection-law-witnesses-v1',classification='PURE_PROBABILITY_WORKED_EXAMPLES_NOT_PROJECT_RUNS_OR_EFFECT_RESULTS',
    design_revision=revision,design_sha256=sha256(contract).hexdigest(),script_sha256=sha256(Path(__file__).read_bytes()).hexdigest(),
    informative_reference=dict(bad_prior=exact(bad),positive_probability_given_bad=exact(F(4,5)),
        positive_probability_given_good=exact(F(1,10)),positive_mass=exact(positive),negative_mass=exact(negative),
        positive_bad_posterior=exact(positive_bad),negative_bad_posterior=exact(negative_bad)),
    random_support_counterexample=dict(bad_prior=exact(bad),success_given_bad=exact(F(1,2)),success_given_good=exact(F(1)),
        success_mass=exact(support),bad_posterior_given_success=exact(bad_after_support),
        interpretation='A conditional decisive-report law alone cannot preserve the current prior after random state-dependent support.'),
    coarse_hypothesis_counterexample=dict(hypothesis_priors=[exact(prior_a),exact(prior_b)],
        bad_outcome_given_hypothesis=[exact(bad_given_a),exact(bad_given_b)],
        positive_report_given_outcome=[exact(positive_given_bad),exact(positive_given_good)],
        marginal_positive_given_hypothesis=[exact(positive_given_a),exact(positive_given_b)],
        true_bad_outcome_posterior=exact(true_bad_posterior),hypothesis_posterior=[exact(a_posterior),exact(b_posterior)],
        bad_outcome_by_recombining_unchanged_catalog=exact(recombined_bad),
        interpretation='Correct hypothesis Bayes masses do not generally recover report-conditioned outcome masses by mixing the old outcome-given-hypothesis catalog.'),
    new_project_calls=0,new_tests=0,new_simulate_calls=0,new_inference_calls=0,registered_research_trials=0)
with (root/'.work/26-independent-projection-laws-01.json').open('x',encoding='utf-8',newline='\n') as stream:
    stream.write(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
print(json.dumps(dict(status='PASS',design_revision=revision,positive='8/11',negative='2/29',
    support_counterexample='1/4 becomes1/7',outcome_counterexample='8/9 differsfrom16/25',new_project_calls=0)))
