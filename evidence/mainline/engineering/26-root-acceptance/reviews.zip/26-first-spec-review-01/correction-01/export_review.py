"""Immutable Git export for correction01; no AegisDC imports or calls."""
from hashlib import sha256
import json
from pathlib import Path
import subprocess

REPO=Path('C:/Users/Donson/.codex/worktrees/mainline23-intervention/Renly')
OUT=Path(__file__).resolve().parent
BASE='e6b372aab3417b7b1020c30fa356badb54a4d746'
SOURCE='ce8f35f0975ef00fb10811472cde701d21f470a9'
RUNTIME='31fb3fd8ea985b7eaf89403e41e737ca8202e5d8'
def git(*args):return subprocess.check_output(['git',*args],cwd=REPO)
def sha(raw):return sha256(raw).hexdigest()
def save(name,raw):
    path=OUT/name;path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('xb') as stream:stream.write(raw)
for ref in (BASE,SOURCE,RUNTIME):assert git('rev-parse',ref).decode().strip()==ref
diff=git('diff',BASE+'...'+SOURCE);assert diff
save('correction.diff',diff)
save('commits.txt',git('log','--oneline',BASE+'..'+SOURCE))
old_pins=json.loads((OUT.parent/'source-pins.json').read_bytes())
changed=git('diff','--name-only',BASE+'...'+SOURCE).decode().splitlines()
names=sorted(set(old_pins['exports'])|set(changed))
exports={}
for name in names:
    raw=git('cat-file','blob',SOURCE+':'+name);save('export/'+name,raw)
    exports[name]=dict(sha256=sha(raw),bytes=len(raw))
prior=json.loads((OUT.parent/'manifest.json').read_bytes())['files']
preserved={}
for name,item in prior.items():
    raw=(OUT.parent/name).read_bytes();assert sha(raw)==item['sha256'],name
    preserved[name]=sha(raw)
preserved['manifest.json']=sha((OUT.parent/'manifest.json').read_bytes())
save('prior-preserved.json',(json.dumps(preserved,indent=2)+'\n').encode())
save('source-pins.json',(json.dumps(dict(base=BASE,source=SOURCE,runtime_source=RUNTIME,exports=exports,
    runtime_identical_to_recorded_revision=not bool(git('diff',RUNTIME,SOURCE,'--','src')),
    new_project_calls=0),ensure_ascii=False,indent=2)+'\n').encode())
print(json.dumps(dict(source=SOURCE,exports=len(exports),prior_files_preserved=len(preserved),new_project_calls=0)))
