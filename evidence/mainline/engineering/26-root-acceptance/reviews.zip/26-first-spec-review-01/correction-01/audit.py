"""Correction01 static source, saved-byte and literal probability audit only."""
import ast
from fractions import Fraction as F
from hashlib import sha256
import json
from pathlib import Path
import re
import subprocess

ROOT=Path(__file__).resolve().parent
REPO=Path('C:/Users/Donson/.codex/worktrees/mainline23-intervention/Renly')
SOURCE='ce8f35f0975ef00fb10811472cde701d21f470a9'
RUNTIME='31fb3fd8ea985b7eaf89403e41e737ca8202e5d8'
checks=[]
def check(ok,name):
    if not ok:raise AssertionError(name)
    checks.append(dict(name=name,passed=True))
def sha(raw):return sha256(raw).hexdigest()
def raw(name):return (ROOT/'export'/name).read_bytes()
def text(name):return raw(name).decode('utf-8')
def git(*args):return subprocess.check_output(['git',*args],cwd=REPO)
def save(name,value):
    with (ROOT/name).open('x',encoding='utf-8',newline='\n') as stream:
        stream.write(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n')

pins=json.loads((ROOT/'source-pins.json').read_bytes())
check(pins['source']==SOURCE and pins['runtime_source']==RUNTIME,'Exact correction and recorded runtime pins')
check(not git('diff',RUNTIME,SOURCE,'--','src'),'Runtime at correction candidate matches recorded31fb source')
for name,item in pins['exports'].items():
    check(sha(raw(name))==item['sha256'],'Export hash '+name)
    check(raw(name)==git('cat-file','blob',SOURCE+':'+name),'Exact Git blob '+name)
    if name.endswith('.py'):
        ast.parse(text(name),filename=name);check(True,'AST parse '+name)
prior=json.loads((ROOT/'prior-preserved.json').read_bytes())
for name,h in prior.items():check(sha((ROOT.parent/name).read_bytes())==h,'Prior187/3P2 review retained '+name)
protected=json.loads((ROOT.parent/'protected-before.json').read_bytes())
for name,h in protected.items():
    check(sha((REPO/name).read_bytes())==h,'Historical original file retained '+name)
    check(sha(git('cat-file','blob',SOURCE+':'+name))==h,'Historical committed blob retained '+name)

dispatch=text('src/aegis_dc/dispatch_policy.py')
look=text('src/aegis_dc/lookahead_policy.py')
projection=text('src/aegis_dc/evidence_projection.py')
value=text('src/aegis_dc/action_value.py')
tests=text('tests/test_evidence_consistent_policy.py')
contract=text('docs/mainline/26-evidence-consistent-candidate.md')
next_doc=text('docs/mainline/26-projection-law-next-slice.md')
evaluator=look[look.index('def evaluate('):]
validate_at=evaluator.index("_fields(options,OPTION_FIELDS")
model_at=evaluator.index("values=assess_action_value(frame,options['belief_model'],options['catalog'],options['value_model'])")
binding_fields_at=evaluator.index("_fields(binding,BIND_FIELDS")
execution_at=evaluator.index('validate_execution_bindings(policy_declaration')
projection_at=evaluator.index('project_inspections(frame,options,candidates,evidence_projection,history)')
check(validate_at<model_at<binding_fields_at<execution_at<projection_at,'Closed options and full nested model assessment precede binding/projection')
check("options['value_model']['cost_unit']" not in dispatch,'Removed the earlier unvalidated dispatch nested cost access')
check("_text(binding[key],'Forecast binding '+key)" in evaluator,'Binding identities validated before keyed lookups')
check("policy_declaration=program if version4 else None,history=history" in dispatch,'v4 routes validated declaration and arrived public history')
check("action_value=2 if policy_declaration is not None else 1" in look,'Extra v4 assessment is reported, legacy count retained')
check("if policy_declaration is not None:\n        values=assess_action_value" in evaluator,'Final v4 classified value is a separate real assessment')
check('except' not in projection and 'except' not in look,'No broad exception-to-unknown conversion introduced')
check("def _pending_inspections(frame,candidates,bindings,history):" in projection,'Pending inspection context explicitly receives public history')
check("r['status'] in {'aborted','rejected'}" in projection,'Only arrived failed terminal acknowledgments discard pending measurement uncertainty')
check("candidate['kind']!='inspect':continue" in projection,'Pending scan uses declared inspection intentions')
check("binding is None or binding['record_id'] not in visible" in projection,'Missing binding/result remains possible pending record')
check("if pending_tasks:reasons.append('PENDING_INSPECTION_RECORD_JOINT_LAW_UNMODELED')" in projection,'Pending result prevents invariant-information proof')
check("pending_inspection_task_ids=pending_tasks" in projection,'Pending task identities retained in decision audit')
check("observed=work_started+local['inspection']['work_s']" in projection,'Forecast work-completion coordinate is explicit')
check("if observed<=now or observed<=work_started:reasons.append('PROJECTED_MEASUREMENT_CLOCK_NOT_ADVANCING')" in projection,'Both non-advancing completion cases block proof')
check(projection.index("if observed<=now")<projection.index('if not reasons:'),'Clock refusal precedes invariant-factor proof')
check("_shared_registry(frame,background['ledger'],'Projection background')" in projection,'Fixed background profile binds to frame')
check("set(registry['entity_ids'])==set(static['entity_ids'])" in projection,'Background entity identity must match')
check("row==current[row['id']]" in projection,'Background source and observable declarations must match')
check("def _factor_signature" in projection and "r['observation_epoch']" in projection and "r['positive']" in projection,'Exact factor identity/epoch/polarity proof remains')
check("signature!=current_signature" in projection,'Changed future factors remain unknown')
check("priority[row['channel_id']]<priority[prospective['id']]" in projection,'Result-independent blocker still requires higher priority')
check("visible[key]['availability']=='current'" in projection,'Expired blocker is not used as a current blocker')
check("frozenset((row['channel_id'],prospective['id'])) not in independent" in projection,'Declared independence is respected')
check("PROSPECTIVE_PROVENANCE_INTERACTION_UNMODELED" in projection and "PROSPECTIVE_COMPONENT_INTERACTION_UNMODELED" in projection,'Provenance/component interacting contexts remain unmodeled')
check("CROSS_EPOCH_PROJECTION_UNMODELED" in projection and "BACKGROUND_ARRIVAL_JOINT_LAW_UNMODELED" in projection,'Epoch and scheduled background limits retained')
check("prospective_information_law_unmodeled" in value and "value=None" in value,'Unknown score remains null')
check("SUM_ORIGINAL_REPORT_MASS_PER_JOINT_OUTCOME_EQUALS_ONE" in projection and "else weights" in value,'Nonadaptive integration retains current joint weights')
check("reported2" not in look,'No placeholder assessment count replaces real invocation')

for name in ('test_malformed_v4_options_and_nested_models_are_rejected_before_binding_or_projection_access',
 'test_another_issued_inspection_with_no_arrived_result_is_not_an_empty_future_context',
 'test_positive_work_must_advance_the_actual_projected_binary64_measurement_clock',
 'test_background_profile_must_share_facility_entities_and_registry_for_every_v4_policy'):
    check('def '+name+'(' in tests,'Saved public regression source '+name)
check("for status in ('aborted','rejected')" in tests,'Pending test separately checks actual public failed terminal cases')
check("(1,float.fromhex('0x0.0000000000001p-1022')),(1e16,1)" in tests,'Clock test contains subnormal and large-coordinate literals')
sidecar=json.loads(raw('evidence/mainline/engineering/26-candidate/development-log-format-classification-01.json'))
check(len(sidecar['entries'])==3,'Exactly three failed native log classifications')
prefix='evidence/mainline/engineering/26-candidate/'
attributes=text(prefix+'.gitattributes')
for row in sidecar['entries']:
    payload=raw(prefix+row['path'])
    check(sha(payload)==row['sha256'] and len(payload)==row['bytes'],'Exact original native bytes '+row['path'])
    check(row['actual_result']=='FAIL' and b'FAILED' in payload,'Failed status not relabeled '+row['path'])
    for line in row['native_trailing_space_lines']:
        check(payload.splitlines(keepends=True)[line['line_number']-1].hex()==line['line_hex'],'Exact classified native line '+row['path'])
    check(row['path']+' -text whitespace=-blank-at-eol' in attributes,'Path-specific whitespace classification '+row['path'])
for number,stem in ((6,'v4-closed-model-validation'),(8,'pending-inspection-context'),(10,'projected-clock-advance'),(12,'background-identity')):
    log=raw(prefix+f'development/{number:02d}-{stem}-green.log')
    check(b'Ran 1 test' in log and log.rstrip().endswith(b'OK'),'Saved corrected public slice '+str(number))
compatibility=raw(prefix+'development/13-four-boundaries-targeted-compatibility.log')
check(b'Ran 43 tests in 25.391s' in compatibility and compatibility.rstrip().endswith(b'OK'),'Saved43-method targeted compatibility result')
check('also run actual engineering facility simulations' in contract,'Compatibility scope acknowledges actual development physics runs')
check('at source31fb3fd8' in contract,'Recorded development execution revision is explicit')
check('No new report law or informative candidate behavior is implemented' in next_doc,'Next-law proposal is not an implementation claim')
check('actual' in next_doc.lower() and 'missing' in next_doc and 'conditional' in next_doc,'Proposed support remains explicitly conditional and synthetic')

# Independent scalar arithmetic; no project interface is imported or executed.
bad=F(1,4);positive_bad=bad*F(4,5);positive_good=(1-bad)*F(1,10)
positive=positive_bad+positive_good;negative=1-positive
positive_posterior=positive_bad/positive;negative_posterior=(bad-positive_bad)/negative
check(positive_posterior==F(8,11),'Next witness positive posterior8/11')
check(negative_posterior==F(2,29),'Next witness negative posterior2/29')
expected=F(2)*positive_bad+positive+F(6)*(bad-positive_bad)
check(expected==F(39,40),'Next finite service witness39/40')
conditioned_bad=(bad*F(1,2))/(bad*F(1,2)+(1-bad))
check(conditioned_bad==F(1,7) and conditioned_bad!=bad,'Conditioning on state-dependent suitability can change current outcome weights')
# With P(o1|h1)=4/5 and P(o1|h2)=1/5, mixture report likelihoods
# can validate at hypothesis level while reset mixing loses outcome information.
posterior_h1=F(33,50)/(F(33,50)+F(6,25))
recombined_o1=posterior_h1*F(4,5)+(1-posterior_h1)*F(1,5)
direct_o1=F(4,5)/(F(4,5)+F(1,10))
check(posterior_h1==F(11,15) and recombined_o1==F(16,25) and direct_o1==F(8,9),'Hypothesis/outcome projection distinction is real')
proposal_review=dict(status='LOGICALLY_USABLE_AS_EXPLICIT_FINITE_MODEL_REVISION_NOT_YET_IMPLEMENTED',
 supported_witnesses=['State-uniform fixed evidence plus a declared independent handheld pair',
 'State-uniform fixed evidence expires before arrival, allowing exact cancellation'],
 necessary_conditions=['Treat suitable/completed/decisive support as an explicit forecast regime true for every modeled outcome, or supply and apply state-dependent P(support|outcome) instead of silently retaining the current prior after conditioning.',
 'Verify exact branch outcome masses produced by the declared updater and catalog, not merely rounded hypothesis posteriors; nondegenerate outcome-given-hypothesis mixtures can invalidate naive recombination.',
 'Cover every evaluated belief/value sensitivity combination, or retain incompatible combinations as unknown; a reference-only proof cannot justify a full assumption envelope.',
 'Keep both policies on identical public projection/support inputs and original positive report law. No unknown/straddling/missing mass is inferred as zero from engineering observations.',
 'Retain all current pending-arrival, epoch, provenance, clock, capability, resource and authority gates; original v1 stays closed.'],
 exact_literals=dict(positive_posterior='8/11',negative_posterior='2/29',inspection_deficit_s='39/40',
 state_dependent_support_counterexample_prior='1/4',state_dependent_support_conditioned='1/7',
 mixed_outcome_counterexample_true='8/9',mixed_outcome_counterexample_recombined='16/25'),
 current_correction_findings_added=0,new_project_calls=0)
save('next-slice-logic-review.json',proposal_review)
report='''# 第26项首审修订 Spec 复核

ce8f35f0：原3项P2修复通过，已审修订无残余。模型/绑定先闭合校验；已发未到检查进入未知门槛；工作观察坐标须严格前进。背景声明亦绑定当前注册表。强因子证明与未知null保留。

原187项/3问题报告和失败原件不改；43项仅为保存的开发回归，含原工程仿真，非本次执行或验收。本复核项目调用0。

下一v2可作显式模型提案：须说清适用域条件化是否改变当前分布，逐变体核对投影后结果质量，不能仅凭假设后验相同；39/40、8/11、2/29字面正确。此评论不等于下一片段已实现。26及根验收仍待完成。
'''
check(len(report.replace('\n',''))<=400,'Report within400characters')
with (ROOT/'SPEC.md').open('x',encoding='utf-8',newline='\n') as stream:stream.write(report)
save('checks.json',checks)
save('review.json',dict(schema='aegisdc-ticket26-first-spec-correction-review-v1',axis='Spec',status='PASS',
 base=pins['base'],source=SOURCE,recorded_development_runtime=RUNTIME,unresolved_findings=0,
 resolved_findings=['SPEC26-FIRST-01','SPEC26-FIRST-02','SPEC26-FIRST-03'],checks_passed=len(checks),
 prior_review_checks=187,prior_review_findings=3,prior_review_artifacts_preserved=len(prior),historical_original_files_preserved=len(protected),
 exact_exports=len(pins['exports']),saved_targeted_tests=43,saved_targeted_seconds=25.391,
 saved_test_scope='Developer run includes earlier engineering facility simulations; not independently executed, not new26formal/root/effect evidence.',
 next_slice_review='next-slice-logic-review.json',next_slice_status=proposal_review['status'],
 report_sha256=sha(report.encode()),new_selector_calls=0,new_assessments=0,new_tests=0,new_simulate_calls=0,
 new_inference=0,new_capture=0,root_acceptance_claimed=False,ticket_resolved=False,overall_goal='ACTIVE'))
files={p.relative_to(ROOT).as_posix():dict(sha256=sha(p.read_bytes()),bytes=len(p.read_bytes()))
       for p in ROOT.rglob('*') if p.is_file() and p.name!='manifest.json' and '__pycache__' not in p.parts and p.suffix not in {'.pyc','.pyo'}}
save('manifest.json',dict(files=files,terminal_manifest_excluded_from_self_hash=True))
print(json.dumps(dict(status='PASS',checks_passed=len(checks),source=SOURCE,unresolved_findings=0,prior_files=len(prior),
 artifacts=len(files)+1,report_sha256=sha(report.encode()),project_calls=0)))
