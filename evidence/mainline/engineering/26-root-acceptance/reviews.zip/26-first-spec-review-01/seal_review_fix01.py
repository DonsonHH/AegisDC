"""Static Spec audit and independent clock arithmetic; imports no project module."""
import ast
from fractions import Fraction
from hashlib import sha256
import json
import math
from pathlib import Path
import subprocess

ROOT=Path(__file__).resolve().parent
REPO=Path('C:/Users/Donson/.codex/worktrees/mainline23-intervention/Renly')
BASE='43fb2537afecdbadca20afb12d07d4649c798da1'
SOURCE='e6b372aab3417b7b1020c30fa356badb54a4d746'
checks=[]
def check(condition,name):
    if not condition:raise AssertionError(name)
    checks.append(dict(name=name,passed=True))
def raw(name):return (ROOT/'export'/name).read_bytes()
def text(name):return raw(name).decode('utf-8')
def digest(value):return sha256(value).hexdigest()
def save(name,value):
    with (ROOT/name).open('x',encoding='utf-8',newline='\n') as stream:
        stream.write(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n')

pins=json.loads((ROOT/'source-pins.json').read_bytes())
for name,item in pins['exports'].items():
    check(digest(raw(name))==item['sha256'],'Pinned exact export '+name)
    check(raw(name)==subprocess.check_output(['git','cat-file','blob',SOURCE+':'+name],cwd=REPO),'Git export matches '+name)
    if name.endswith('.py'):ast.parse(text(name),filename=name);check(True,'Static parse '+name)
projection=text('src/aegis_dc/evidence_projection.py')
dispatch=text('src/aegis_dc/dispatch_policy.py')
lookahead=text('src/aegis_dc/lookahead_policy.py')
values=text('src/aegis_dc/action_value.py')
belief=text('src/aegis_dc/belief.py')
ledger=text('src/aegis_dc/evidence_ledger.py')
contract=text('docs/mainline/26-evidence-consistent-candidate.md')
check("def project_inspections(frame,options,candidates,projection):" in projection,'Projection has no public issued-history argument')
check("_pending_background(projection['background_sensor_profile'],now,arrival)" in projection,'Only fixed profile drives pending-arrival gate')
check("NO_UNSCHEDULED_RECORD_ARRIVALS_UNTIL_PROJECTED_REPORT" in contract,'Contract excludes unscheduled records, not known issued inspections')
check("if version4:validate_execution_bindings" in dispatch,'v4 adds early public binding path')
check("for mapping in options['bindings']:" in lookahead,'Early binding reads unvalidated options bindings')
check(lookahead.index("_fields(options,OPTION_FIELDS")>lookahead.index("for mapping in options['bindings']:"),'Closed option validation resides in later evaluation')
check("information,projection_audit,projection_calls=project_inspections" in lookahead,'Candidate projects before action-value model validation')
check("def _factor_signature" in projection and "r['observation_epoch']" in projection and "r['positive']" in projection,'Proof compares exact factor identities, epochs, polarities')
check("signature!=current_signature" in projection,'Proof rejects known projected factor changes')
check("PROSPECTIVE_PROVENANCE_INTERACTION_UNMODELED" in projection,'Declared provenance interaction remains unmodeled')
check("PROSPECTIVE_COMPONENT_INTERACTION_UNMODELED" in projection,'Declared dependency component interaction remains unmodeled')
check("CROSS_EPOCH_PROJECTION_UNMODELED" in projection,'Cross-epoch prediction remains unmodeled')
check("NON_ADAPTIVE_UNDER_DECLARED_UPDATER" in values and "else weights" in values,'Nonadaptive integration preserves existing joint weights')
check("value=None" in values and "prospective_information_law_unmodeled" in values,'Unknown contingent value stays null')
check("report_label='marginalized_original_report_mass'" in values,'Nonadaptive report has explicit output label')
check("min(" in values and "all(a['expected']['service_deficit_time_s']['value'] is not None" in values,'Envelope does not compare unknown values')
check("for key in ('travel_s','wait_s','work_s'):observed+=local['inspection'][key]" in projection,'Observation clock uses sequential decoded-number addition')
check("observed>now" not in projection and "observed > now" not in projection,'No strict observation-clock advancement guard')
check("('source_id','target_id','observable_id')" in projection,'Binding guard includes source identity')
check("keys = ('target_id', 'observable_id', 'observed_at_s')" in ledger,'Conflict identity omits source and includes observation instant')

now=1e16
waited=now+.25
observed=waited+1
report_exact=Fraction(observed)+Fraction(.5)
report=float(report_exact)
if Fraction(report)<report_exact:report=math.nextafter(report,math.inf)
check(waited==now and observed==now,'Independent binary64 witness collapses positive work clock')
check(report==now+2 and (Fraction(report)-Fraction(now))//10==0,'Report remains future within one declared epoch')
check(Fraction(0)+Fraction(0)<Fraction(1)-Fraction(0),'Zero-bound positive flow record can conflict with same-time old flow1')

findings=[
 dict(id='SPEC26-FIRST-01',priority='P2',kind='new_input_validation_path',
      file='src/aegis_dc/dispatch_policy.py',line=169,related='src/aegis_dc/lookahead_policy.py:19',
      requirement='Earlier schemas retain their closed contracts and behavior; public input errors should be rejected before binding/projection.',
      counterexample='Starting with the valid first-slice v4 policy, delete only options.bindings. The cost-unit access still succeeds, then early validate_execution_bindings reads options[bindings] and raises KeyError. The corresponding existing v3 path first runs evaluate._fields and rejects with ValueError.',
      remedy='Perform closed and typed option/model/binding validation before early v4 execution-binding/projection reads; do not convert arbitrary exceptions into successful unknown plans.'),
 dict(id='SPEC26-FIRST-02',priority='P2',kind='missing_public_pending_context',
      file='src/aegis_dc/evidence_projection.py',line=82,related='src/aegis_dc/evidence_projection.py:103',
      requirement='Only when the projection covers every producer report class and has no unmodeled background arrival may it declare NON_ADAPTIVE_UNDER_DECLARED_UPDATER.',
      counterexample='Use the same current frame and public profiles, but include another already issued, unacknowledged inspection on independent crew/tools in the public history. Its declared measurement may arrive before the proposed report and replace/change a used factor. The projection receives no history and only scans fixed-sensor arrival times, so it can still certify invariant factors. This known issued task is not an unscheduled manual arrival.',
      remedy='Pass validated public issued history into projection and gate other pending inspection results as UNMODELED unless an adequate bounded arrival/context law exists, or explicitly reject that unsupported context at this public boundary.'),
 dict(id='SPEC26-FIRST-03',priority='P2',kind='insufficient_numeric_clock_condition',
      file='src/aegis_dc/evidence_projection.py',line=95,related='src/aegis_dc/evidence_projection.py:111; src/aegis_dc/evidence_ledger.py:194',
      requirement='The structural proof must cover all prospective producer values without changing any old admitted factor.',
      counterexample='Choose finite as_of_s=1e16 with matching belief scope starts_at_s=1e16 and epoch_s=10. With wait_s=.25/work_s=1, sequential binary64 additions leave predicted observation at now; the .5 report delay rounds upward to now+2. A current higher-priority record from a different source on the same target/observable observed at now is not excluded by the full-binding guard. A new positive flow reading0 with zero bound conflicts with old flow1 at that same observation time, removing the old used factor, whereas missing or agreeing readings do not. The code can nevertheless label all classes NON_ADAPTIVE.',
      remedy='Require strict representable observation advancement after positive work, and reject potential same-target/observable/time conflicts before applying the symbolic invariant-factor proof.')]
save('counterexamples.json',dict(findings=findings,execution='STATIC_SOURCE_PATHS_AND_INDEPENDENT_SCALAR_ARITHMETIC_ONLY',
 clock=dict(now=now,after_wait=waited,observed=observed,reported_at=report,elapsed_to_report_s=report-now),new_project_calls=0))

protected=json.loads((ROOT/'protected-before.json').read_bytes())
for name,expected in protected.items():check(digest((REPO/name).read_bytes())==expected,'Protected original preserved '+name)
for name in ('AGENTS.md','.scratch/full-facility-mainline/spec.md','docs/mainline/26-evidence-consistent-candidate.md'):
    check(bool(text(name)),'Reviewed requirement source '+name)
report='''# 第26项首切片 Spec 静态复核

e6b372aa 有3项P2，未执行项目。

1. v4提前绑定未先校验：仅删 options.bindings 即走到 KeyError；旧v3先闭合校验拒绝为 ValueError。
2. 投影不接已发历史，只扫固定测点。另一已发检查的待到记录可能改变因子，不能仍证明非自适应。
3. now=1e16、wait=.25/work=1时预测观察坐标坍缩为now；不同源同目标/量的新读数可与旧记录同刻冲突，推翻全部报告类因子不变。

需补前置校验、待到检查门槛和严格时钟前进/冲突门槛。具体源码与反例见 counterexamples.json。原件保留，已声明待做的在线等不另报；26未接受。
'''
check(len(report.replace('\n',''))<=400,'Report within400characters')
with (ROOT/'SPEC.md').open('x',encoding='utf-8',newline='\n') as stream:stream.write(report)
save('checks.json',checks)
save('review.json',dict(schema='aegisdc-ticket26-first-slice-independent-spec-review-v1',axis='Spec',status='CHANGES_REQUIRED',
 base=BASE,source=SOURCE,unresolved_findings=len(findings),checks_passed=len(checks),findings=findings,
 export_count=len(pins['exports']),protected_original_files=len(protected),report_sha256=digest(report.encode()),
 new_selector_calls=0,new_assessments=0,new_tests=0,new_simulate_calls=0,new_inference=0,new_capture=0,
 root_acceptance_claimed=False,ticket_resolved=False,overall_goal='ACTIVE',
 scope='Pure choose_work first-slice claims only; documented online/informative/expiry future work is not reported as a separate regression.'))
manifest={p.relative_to(ROOT).as_posix():dict(sha256=digest(p.read_bytes()),bytes=len(p.read_bytes()))
          for p in ROOT.rglob('*') if p.is_file() and p.name!='manifest.json' and '__pycache__' not in p.parts and p.suffix not in {'.pyc','.pyo'}}
save('manifest.json',dict(files=manifest,terminal_manifest_excluded_from_self_hash=True))
print(json.dumps(dict(status='CHANGES_REQUIRED',source=SOURCE,findings=len(findings),checks_passed=len(checks),artifacts=len(manifest)+1,
                     report_sha256=digest(report.encode()),project_calls=0)))
