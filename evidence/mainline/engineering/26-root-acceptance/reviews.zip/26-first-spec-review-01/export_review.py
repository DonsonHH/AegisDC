"""Exact read-only Git material for the ticket26 first-slice Spec review."""
from hashlib import sha256
import json
from pathlib import Path
import subprocess

REPO=Path('C:/Users/Donson/.codex/worktrees/mainline23-intervention/Renly')
OUT=Path(__file__).resolve().parent
BASE='43fb2537afecdbadca20afb12d07d4649c798da1'
SOURCE='e6b372aab3417b7b1020c30fa356badb54a4d746'
def git(*args):return subprocess.check_output(['git',*args],cwd=REPO)
def digest(raw):return sha256(raw).hexdigest()
def save(path,raw):
    path.parent.mkdir(exist_ok=True,parents=True)
    with path.open('xb') as stream:stream.write(raw)

assert git('rev-parse',BASE).decode().strip()==BASE
assert git('rev-parse',SOURCE).decode().strip()==SOURCE
diff=git('diff',BASE+'...'+SOURCE);assert diff
save(OUT/'change.diff',diff)
save(OUT/'commits.txt',git('log','--oneline',BASE+'..'+SOURCE))
changed=git('diff','--name-only',BASE+'...'+SOURCE).decode().splitlines()
extra=['AGENTS.md','GLOSSARY.md','docs/MAINLINE.md','docs/agents/domain.md',
 '.scratch/full-facility-mainline/spec.md','docs/adr/0003-complete-facility-mainline.md',
 'docs/adr/0002-sparse-evidence-not-sensor-free.md',
 *['src/aegis_dc/'+n+'.py' for n in ('belief','evidence_ledger','decision_view','inspection_execution',
 'nonfixed_evidence','sensor_channels','risk_scenarios','workforce_dispatch','policy_budget')],
 'tests/test_dispatch_policy.py','tests/test_action_value.py']
exports={}
for name in sorted(set(changed+extra)):
    raw=git('cat-file','blob',SOURCE+':'+name);save(OUT/'export'/name,raw)
    exports[name]=dict(sha256=digest(raw),bytes=len(raw))
protected={}
for prefix in ('evidence/mainline/engineering/25-baselines/capture-01',
               'evidence/mainline/engineering/25-baselines/capture-02',
               'evidence/mainline/engineering/25-baselines/metadata-capture-01'):
    for name in git('ls-tree','-rz','--name-only',SOURCE,prefix).decode().strip('\0').split('\0'):
        if name:
            raw=git('cat-file','blob',SOURCE+':'+name)
            assert (REPO/name).read_bytes()==raw,name
            protected[name]=digest(raw)
save(OUT/'source-pins.json',(json.dumps(dict(base=BASE,source=SOURCE,exports=exports,
    project_calls=0),ensure_ascii=False,indent=2)+'\n').encode())
save(OUT/'protected-before.json',(json.dumps(protected,ensure_ascii=False,indent=2)+'\n').encode())
print(json.dumps(dict(base=BASE,source=SOURCE,exported_files=len(exports),protected_original_files=len(protected),
                     new_project_calls=0)))
