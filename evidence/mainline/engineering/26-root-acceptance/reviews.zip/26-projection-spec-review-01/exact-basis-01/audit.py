"""Static numerical-path supplement; no project import, test or inference."""
import ast
from fractions import Fraction as F
from hashlib import sha256
import json
from pathlib import Path
import subprocess

HERE=Path(__file__).resolve().parent
PARENT=HERE.parent
REPO=Path('C:/Users/Donson/.codex/worktrees/mainline23-intervention/Renly')
ROOT=Path('C:/Users/Donson/Documents/ChatGPT/Renly')
SOURCE='4dee4488a274528de801b9c1475577b675c0d072'
BASE='7798ce9d854377175520331553abe93c5329b677'
checks=[]
def check(ok,name):
    if not ok:raise AssertionError(name)
    checks.append(dict(name=name,passed=True))
def digest(raw):return sha256(raw).hexdigest()
def read(p):return json.loads(p.read_bytes())
def text(n):return (HERE/'export'/n).read_text(encoding='utf-8')
def git(*a):return subprocess.check_output(['git',*a],cwd=REPO)

pins=read(HERE/'source-pins.json')
check(pins['base']==BASE and pins['source']==SOURCE,'fixed review revision')
for name,identity in pins['exports'].items():
    raw=(HERE/'export'/name).read_bytes()
    check(digest(raw)==identity['sha256'] and len(raw)==identity['bytes'],'fixed export bytes '+name)
    check(raw==git('cat-file','blob',SOURCE+':'+name),'fixed export Git source '+name)
    if name.endswith('.py'):
        ast.parse(raw.decode('utf-8'),filename=name)
        check(True,'static syntax '+name)
for name,identity in pins['base_exports'].items():
    raw=(HERE/'base'/name).read_bytes()
    check(digest(raw)==identity and raw==git('cat-file','blob',BASE+':'+name),'base comparison bytes '+name)
for name,identity in read(HERE/'prior-sealed-hashes.json').items():
    check(digest((PARENT/name).read_bytes())==identity,'prior584 sealed artifact unchanged '+name)
for unchanged in ('src/aegis_dc/belief.py','src/aegis_dc/risk_scenarios.py','src/aegis_dc/dispatch_policy.py','src/aegis_dc/policy_budget.py'):
    check(git('cat-file','blob',BASE+':'+unchanged)==git('cat-file','blob',SOURCE+':'+unchanged),'unchanged source boundary '+unchanged)

value=text('src/aegis_dc/action_value.py')
projection=text('src/aegis_dc/evidence_projection.py')
look=text('src/aegis_dc/lookahead_policy.py')
tests=text('tests/test_evidence_consistent_policy.py')
proposal=text('docs/mainline/26-exact-valuation-basis-proposal.md')
value_ast=ast.parse(value);function=next(n for n in value_ast.body if isinstance(n,ast.FunctionDef) and n.name=='assess_action_value')
kwdefaults={a.arg:ast.unparse(d) if d is not None else None for a,d in zip(function.args.kwonlyargs,function.args.kw_defaults)}
check(kwdefaults['valuation_mass_basis']=='SERIALIZED_MASS_BASIS','default remains explicit legacy serialized basis')
check("SERIALIZED_MASS_BASIS='SERIALIZED_PUBLIC_POSTERIOR_V1'" in value,'legacy enum identity')
check("EXACT_MASS_BASIS='EXACT_FINITE_PUBLIC_BELIEF_CONTEXT_V1'" in value,'new exact enum identity')
check(value.index("_text(valuation_mass_basis,'Valuation mass basis')")<value.index('valuation_mass_basis in {SERIALIZED_MASS_BASIS,EXACT_MASS_BASIS}'),'nontext bases refused before set membership')
check("if valuation_mass_basis==EXACT_MASS_BASIS:" in value and 'exact_context=exact_belief_context(frame,belief_model)' in value,'exact masses from same public frame and belief model')
check("else:masses=None if posterior is None else {h:Fraction(str(p)) for h,p in posterior.items()}" in value,'legacy serialized masses retained exactly')
check("total=sum(masses.values()) if masses is not None else None" in value,'same renormalization on represented or exact masses')
check("world_masses[identifier]=None if masses is None else {o['id']:sum(p/total*Fraction(str(o['conditional_probability'][h]))" in value,'world masses map through unchanged catalog')
check("weights=world_masses[belief_variant]" in value,'all alternatives and value variants use one common current world basis')
check(value.index('weights=world_masses[belief_variant]')<value.index("for kind in ('defer','direct_intervention','inspect_then_act'):"),'world basis not specific to inspection action')
check("if world_masses[belief_variant] is None:" in value,'conflicted variants retain unknown alternatives')
check("if exact_context is not None else {}" in value,'default response does not add exact metadata fields')
check("valuation_model_evaluations=dict(exact_belief_context=1)" in value,'exact valuation read accounted once per assessment')
check("if version3 else set()" in projection and "{'valuation_mass_basis'}" in projection,'projection exact basis belongs only to new closed schema')
check("_require(projection['valuation_mass_basis']==EXACT_MASS_BASIS" in projection,'projection v3 supports only exact public-context enum')
check("valuation_world=exact_world if mass_basis==EXACT_MASS_BASIS else represented_world" in projection,'prospective compatibility shares selected current numerical basis')
check("for o,p in valuation_world.items()" in projection,'branch joint weights use the shared valuation basis')
check("if valuation_world!=exact_world:" in projection and 'VALUATION_REPRESENTATION_UNSUPPORTED' in projection,'old v1/v2 representation limitation retained')
check("projected==expected" in projection,'context law compatibility remains exact OUTCOME equality')
check("projection.get('valuation_mass_basis',SERIALIZED_MASS_BASIS)" in projection,'old projection defaults remain serialized')
check("mass_basis=policy_declaration['evidence_projection'].get('valuation_mass_basis',SERIALIZED_MASS_BASIS)" in look,'baseline and candidate take common declared mass basis')
tree=ast.parse(look)
evaluation=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='evaluate')
calls=[n for n in ast.walk(evaluation) if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='assess_action_value']
check(len(calls)==3,'existing legacy assessment and two v4 value assessment sites retained')
explicit=[n for n in calls if any(k.arg=='valuation_mass_basis' for k in n.keywords)]
check(len(explicit)==2 and all(ast.unparse(next(k.value for k in n.keywords if k.arg=='valuation_mass_basis'))=='mass_basis' for n in explicit),'both v4 assessments receive same mass basis')
check("valuation_exact_calls=values.get('valuation_model_evaluations',{}).get('exact_belief_context',0)" in look,'validation exact computation counted')
check("valuation_exact_calls+=values.get('valuation_model_evaluations',{}).get('exact_belief_context',0)" in look,'final evaluation exact computation counted')
check('valuation_exact_belief_context=valuation_exact_calls' in look and '**projection_calls' in look,'valuation and prospective exact calls remain separate')
check("if mass_basis==EXACT_MASS_BASIS else {}" in look,'old choice output shape excludes unconditional exact metadata')
check("row.update(status='UNMODELED',reason='IMPLEMENTATION_CONTEXT_OUTCOME_MASS_UNSUPPORTED')" in projection,'nonneutral expiry never redraws current world law')
for method in ('test_valuation_default_and_older_projection_keep_the_serialized_contract',
               'test_projection_v3_exact_basis_is_closed_and_identical_for_both_value_policies',
               'test_exact_basis_does_not_replace_current_world_mass_with_nonneutral_expired_context',
               'test_new_shared_exact_basis_supports_nondyadic_worlds_for_baseline_and_candidate'):
    check('def '+method in tests,'saved public boundary witness '+method)
check('self.assertEqual(default,explicit)' in tests,'saved default versus explicit legacy response equality witness')
check("self.assertNotIn('valuation_mass_basis',default)" in tests and "self.assertNotIn('valuation_model_evaluations',default)" in tests,'saved default response shape witness')
check("for supplied in ([],{'cooling-limited':[1,4]},'UNREGISTERED_OR_SUPPLIED_MASS')" in tests,'caller supplied mass and invalid enum refusal witness')
check('Existing float presentation of final predictions and deterministic ranking remains shared' in proposal,'finite display ranking not claimed exact optimizer')
check('not an independent source of candidate gain' in proposal and 'not an extra scientific mechanism' in proposal,'numerical path revision not attributed as scientific gain')
check('Online execution and acceptance remain pending' in proposal,'stage acceptance boundary explicit')

# The old and default new serialized formulas are identically rational: all
# posterior components are converted in the same order, normalized by the same
# sum, and mapped through the same catalog. Here check independent concrete
# nondyadic and zero-mass inputs as arithmetic witnesses, without project calls.
post=[float(F(36,59)),float(F(16,59)),float(F(1,59)),float(F(6,59))]
catalog=[{0:F(1),1:F(0),2:F(0),3:F(0)},{0:F(0),1:F(1),2:F(0),3:F(0)},
         {0:F(0),1:F(0),2:F(1),3:F(0)},{0:F(0),1:F(0),2:F(0),3:F(1)}]
legacy_total=sum(F(str(p)) for p in post)
legacy=[sum(F(str(p))/legacy_total*c[i] for i,p in enumerate(post)) for c in catalog]
masses={i:F(str(p)) for i,p in enumerate(post)};new_total=sum(masses.values())
new=[sum(p/new_total*c[i] for i,p in masses.items()) for c in catalog]
check(legacy==new,'independent old/default exact formula equality')
check(sum(new)==1,'default world masses remain normalized')
exact=[F(36,59),F(16,59),F(1,59),F(6,59)]
check(exact!=new,'nondyadic exact difference remains an explicit revision')
positive_law=[F(1,10),F(4,5),F(1,10),F(1,10)]
positive_mass=sum(w*l for w,l in zip(exact,positive_law));negative_mass=1-positive_mass
check(positive_mass==F(171,590),'independent exact positive mass171/590')
check(negative_mass==F(419,590),'independent exact negative mass419/590')
check(exact[1]*F(4,5)/positive_mass==F(128,171),'independent positive impairment128/171')
check(exact[1]*F(1,5)/negative_mass==F(32,419),'independent negative impairment32/419')
check(F(6)*exact[1]==F(96,59),'independent defer loss96/59')
check(F(1,4)*exact[1]+1==F(63,59),'independent direct loss63/59')
check(F(2)*exact[1]*F(4,5)+positive_mass+F(6)*exact[1]*F(1,5)==F(619,590),'independent inspection loss619/590')
check(F(619,590)<F(63,59)<F(96,59),'literal ranking inspection before direct before defer')
check(F(8,11)!=F(128,171),'nonneutral expiry cannot substitute future handheld-only world mass')
oracle=ROOT/'.work/26-independent-nondyadic-value-witness-01.json'
check(read(oracle)['new_project_calls']==0,'parent independent oracle did not run project')
check(read(oracle)['expected_service_deficit_s']['compatible_inspection']['numerator']==619,'independent original oracle identity')
for number,stem,result in [(29,'shared-exact-nondyadic-basis-red','FAILED'),(30,'shared-exact-nondyadic-basis-green','OK'),
                            (31,'shared-exact-nonneutral-expiry-check','OK'),(32,'shared-exact-default-and-closed-input-check','OK')]:
    check(result in text(f'evidence/mainline/engineering/26-candidate/development/{number}-{stem}.log'),'saved original result '+str(number))
check('Ran 43 tests in 6.139s' in text('evidence/mainline/engineering/26-candidate/development/33-shared-exact-value-belief-compatibility.log'),'saved targeted43 methods not reviewer execution')

report='''# 第26项共享精确数值路径 Spec 补充复核

4dee4488：已审增量PASS，未解决发现0。显式v3数值基准从同一公开信念模型导出精确质量，基线和候选的所有动作/变体共用；不接受外部质量字典。默认旧序列化公式与响应形状保留，历史v1/v2的限制未改。最终浮点展示和排序仍不冒称精确优化器。

独立619/590、63/59、96/59及128/171、32/419算术一致。非中性过期的8/11不能替换当前128/171，仍未知；数值修订不修补缺失上下文法则。两次精确估值及三次候选精确投影分开计费。43项为保存的开发回归，本复核项目调用0。原584包保持，线上、正式捕获及26根验收仍待完成。
'''
(HERE/'SPEC.md').write_text(report,encoding='utf-8',newline='\n')
(HERE/'checks.json').write_text(json.dumps(dict(checks_passed=len(checks),checks=checks),ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
review=dict(schema='aegisdc-ticket26-exact-basis-spec-supplement-v1',axis='Spec',status='PASS',base=BASE,source=SOURCE,
    runtime_revision='4713c365',checks_passed=len(checks),unresolved_findings=0,findings=[],exact_exports=len(pins['exports']),
    prior_review_checks=584,prior_sealed_hashes_preserved=len(read(HERE/'prior-sealed-hashes.json')),
    saved_targeted_methods=43,saved_targeted_seconds=6.139,report_sha256=digest((HERE/'SPEC.md').read_bytes()),
    independent_oracle_sha256=digest(oracle.read_bytes()),new_selector_calls=0,new_assessments=0,new_tests=0,new_simulate_calls=0,new_inference=0,new_capture=0,
    ticket_resolved=False,root_acceptance_claimed=False,overall_goal='ACTIVE',scope='Shared exact numerical increment only; online/formal/root remain pending.')
(HERE/'review.json').write_text(json.dumps(review,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
manifest={p.relative_to(HERE).as_posix():dict(sha256=digest(p.read_bytes()),bytes=p.stat().st_size)
    for p in HERE.rglob('*') if p.is_file() and p.name!='manifest.json' and '__pycache__' not in p.parts and p.suffix not in {'.pyc','.pyo'}}
(HERE/'manifest.json').write_text(json.dumps(dict(artifacts=manifest,terminal_manifest='manifest.json'),ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(dict(status='PASS',source=SOURCE,checks_passed=len(checks),unresolved_findings=0,report_sha256=review['report_sha256'],review_sha256=digest((HERE/'review.json').read_bytes()),manifest_members=len(manifest),new_project_calls=0)))
