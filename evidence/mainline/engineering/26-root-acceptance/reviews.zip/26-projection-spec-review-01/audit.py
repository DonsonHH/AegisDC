"""Pinned static Spec review; no AegisDC imports or project execution."""
import ast
from fractions import Fraction as F
from hashlib import sha256
import json
from pathlib import Path
import subprocess

HERE=Path(__file__).resolve().parent
REPO=Path('C:/Users/Donson/.codex/worktrees/mainline23-intervention/Renly')
ROOT=Path('C:/Users/Donson/Documents/ChatGPT/Renly')
SOURCE='7798ce9d854377175520331553abe93c5329b677'
BASE='ce8f35f0975ef00fb10811472cde701d21f470a9'
checks=[]

def check(ok,name):
    if not ok:raise AssertionError(name)
    checks.append(dict(name=name,passed=True))

def git(*args):return subprocess.check_output(['git',*args],cwd=REPO)
def digest(raw):return sha256(raw).hexdigest()
def read(path):return json.loads(path.read_bytes())
def text(name):return (HERE/'export'/name).read_text(encoding='utf-8')

pins=read(HERE/'source-pins.json')
check(pins['base']==BASE and pins['source']==SOURCE,'fixed base and reviewed source')
check(git('rev-parse',SOURCE).decode().strip()==SOURCE,'review source exists')
check(bool(git('diff',BASE+'...'+SOURCE)),'nonempty scoped change')
for name,identity in pins['exports'].items():
    raw=(HERE/'export'/name).read_bytes()
    check(digest(raw)==identity['sha256'] and len(raw)==identity['bytes'],'export hash '+name)
    check(raw==git('cat-file','blob',SOURCE+':'+name),'exact reviewed Git blob '+name)
    if name.endswith('.py'):
        ast.parse(raw.decode('utf-8'),filename=name)
        check(True,'static AST parse '+name)
for name,identity in read(HERE/'prior-preserved.json').items():
    check(digest((ROOT/name).read_bytes())==identity,'earlier sealed review unchanged '+name)
old=read(HERE/'historical-originals.json')
check(len(old)==82,'declared historical capture originals82')
for name,identity in old.items():
    check(digest((REPO/name).read_bytes())==identity,'historical original bytes '+name)
    check(digest(git('cat-file','blob',SOURCE+':'+name))==identity,'historical original Git source '+name)

contract=text('docs/mainline/26-projection-law-next-slice.md')
main=text('docs/mainline/26-evidence-consistent-candidate.md')
projection=text('src/aegis_dc/evidence_projection.py')
belief=text('src/aegis_dc/belief.py')
value=text('src/aegis_dc/action_value.py')
look=text('src/aegis_dc/lookahead_policy.py')
dispatch=text('src/aegis_dc/dispatch_policy.py')
tests=text('tests/test_evidence_consistent_policy.py')
for word in ('probability1 separately for every enumerated joint world outcome','not conditioning on an unknown random success event',
             'every evaluated belief/value sensitivity pair','OUTCOME','VALUATION_REPRESENTATION_UNSUPPORTED'):
    check(word.lower() in contract.lower(),'explicit finite-domain contract '+word)
for word in ('algorithmic novelty claim','fully specified rational','No second solver or predictor','final acceptance'):
    check(word in main,'declared interpretation and remaining scope '+word)
check('read actual state' not in projection,'projection no direct actual-state read expression')
check('INFORMATIVE_COMPATIBLE_WITH_DECLARED_UPDATER' in projection,'explicit compatible classification')
check("_text(projection['schema'],'Projection schema')" in projection,'schema type before set membership')
check("FIELDS|({'report_class_support'} if version2 else set())" in projection,'v1 and v2 closed shapes')
check('EVERY_MODELED_OUTCOME_COMPLETES_SUITABLY_AT_DECLARED_TIME_WITH_DECISIVE_BINARY_REPORT' in projection,'certainty label in validated support rows')
for phrase in ("binding['record_id']==row['record_id']","row['question_id'] not in questions","row['inspection_task_id'] not in supported_tasks"):
    check(phrase in projection,'support identity uniqueness '+phrase)
check('validate_value_projection_bindings(options,candidates,policy_declaration' in look,'same baseline/candidate support binding validation')
check("measured['target_id']==task['target_id']" in look,'public inspection target equality')
check("binding['tool_id'] in interface['tool_ids']" in look,'public actual tool occupation binding')
check("binding['qualification_id']==interface['qualification_id']" in look,'public actual qualification binding')
check('DECLARED_WORK_BELOW_MEASUREMENT_MINIMUM' in projection,'insufficient work remains unknown projection')
for reason in ('PROJECTED_MEASUREMENT_CLOCK_NOT_ADVANCING','CROSS_EPOCH_PROJECTION_UNMODELED','BACKGROUND_ARRIVAL_JOINT_LAW_UNMODELED',
               'PENDING_INSPECTION_RECORD_JOINT_LAW_UNMODELED','PROSPECTIVE_PROVENANCE_INTERACTION_UNMODELED',
               'PROSPECTIVE_BINDING_CONFLICT_OR_REPLACEMENT_UNMODELED','PROSPECTIVE_COMPONENT_INTERACTION_UNMODELED'):
    check(reason in projection,'retained finite proof gate '+reason)
check('observed<=now or observed<=work_started' in projection,'strict representable observation advancement')
check('signature==current_signature' in projection,'nonadaptive exact factor identity sufficient condition')
check('SUM_ORIGINAL_REPORT_MASS_PER_JOINT_OUTCOME_EQUALS_ONE' in projection,'nonadaptive original report marginalization')
check("for belief_id,exact in initial['posterior_mass_by_variant'].items():" in projection,'all belief assumptions enumerated')
check("for variant in local['variants']:" in projection,'all value assumptions enumerated')
check("for name,positive in (('positive',True),('negative',False)):" in projection,'both decisive report branches enumerated')
check('represented_world!=exact_world' in projection,'representation mismatch checked separately')
check("exact_current_outcome_mass=_ratios(exact_world)" in projection and "valuation_current_outcome_mass=_ratios(represented_world)" in projection,'representation mismatch exposes exact masses')
check('projected==expected' in projection,'exact OUTCOME distribution equality')
check("expected={o:p/probability for o,p in joint.items()} if probability else None" in projection,'joint report posterior normalized on original worlds')
check('matched=not probability or used and projected==expected' in projection,'zero-support and actual symbolic factor admission guarded')
check('exact_calls+=count' in projection and 'return all_matched,rows,3' in projection,'three exact counterfactual context calls counted')
check('dict(prospective_belief=calls,exact_belief_context=exact_calls)' in projection,'ordinary and exact modeling calls separate')
check("action_value=2 if policy_declaration is not None else 1" in look,'v4 validation assessment counted')
for phrase in ("schema']=='aegisdc-symbolic-report-token-v1'","type(positive) is bool",'strictly follow every currently supplied record',
               'fresh noncopy origin',"_choose_records(evidence,candidates,channels,independent)","_filter(prior,transition,likelihood,epoch,factors)"):
    check(phrase in belief,'detached symbolic context contract '+phrase)
symbolic=ast.parse(belief).body
symbolic=next(n for n in symbolic if isinstance(n,ast.FunctionDef) and n.name=='exact_belief_context')
calls={ast.unparse(n.func) for n in ast.walk(symbolic) if isinstance(n,ast.Call)}
check(not any('ingest' in name or 'simulate' in name or 'private' in name for name in calls),'symbolic context does not invoke live ledger/plant/private state')
check("{'schema','id','source_id','target_id','observable_id','unit','observed_at_s'," in belief,'value-free symbolic token closed fields')
check("physical_actions=[],execution_permission=False" in belief,'symbolic calculation has no execution authority')
check("information=='UNMODELED'" in value and 'value=None' in value,'unknown information keeps null value')
check("not nonadaptive and report_at<horizon" in value,'only nonadaptive mode marginalizes unchanged report law')
check("all(a['expected']['service_deficit_time_s']['value'] is not None" in value,'no numeric envelope from unknown values')
check("Fraction(str(variant['positive_likelihood'][key]))" in value,'original prospective likelihood retained')
check("Fraction(str(p))/mass" in value,'original serialized valuation basis retained in this slice')
check("'prospective_evidence_audit':projection_audit" in look,'public audit exposes projection scope')
check("history=history" in dispatch,'projection receives public history only')
for method in ('test_explicit_certain_report_domain_allows_compatible_independent_information',
               'test_neutral_fixed_expiry_rebuilds_current_priority_at_the_exact_projected_arrival',
               'test_coarse_hypothesis_update_cannot_claim_incompatible_report_conditioned_outcome_value',
               'test_roundtrip_valuation_representation_difference_is_audited_separately_from_missing_law',
               'test_shared_report_support_rejects_unknown_questions_and_wrong_bindings_in_both_policies',
               'test_projection_schema_type_is_rejected_at_the_shared_public_contract'):
    check('def '+method in tests,'saved public witness '+method)
test_ast=ast.parse(tests)
check(not any(isinstance(n,ast.Call) and ('simulate' in ast.unparse(n.func)) for n in ast.walk(test_ast)),'new public candidate tests contain no facility simulation calls')
logbase='evidence/mainline/engineering/26-candidate/'
for number,name,result in [(14,'public-inspection-binding-red','FAILED'),(15,'public-inspection-binding-green','OK'),
                           (16,'minimum-work-information-red','FAILED'),(17,'minimum-work-information-green','OK'),
                           (18,'declared-informative-domain-red','FAILED'),(19,'declared-informative-domain-green','OK'),
                           (20,'neutral-fixed-expiry-boundary-check','OK'),(21,'incompatible-outcome-mass-check','OK'),
                           (22,'shared-support-closed-bindings-red','FAILED'),(23,'shared-support-closed-bindings-green','OK'),
                           (24,'valuation-representation-audit-red','FAILED'),(25,'valuation-representation-audit-green','OK'),
                           (26,'projection-schema-type-red','FAILED'),(27,'projection-schema-type-green','OK')]:
    raw=text(logbase+f'development/{number:02d}-{name}.log')
    check(result in raw,'actual saved result preserved '+str(number))
saved=text(logbase+'development/28-projection-belief-action-value-compatibility.log')
check('Ran 39 tests in 6.834s' in saved and saved.rstrip().endswith('OK'),'saved39-method compatibility PASS only, not reviewer execution')
attrs=text(logbase+'.gitattributes')
for suffix in ('02','03'):
    classification=json.loads(text(logbase+'development-log-format-classification-'+suffix+'.json'))
    for row in classification['entries']:
        raw=(HERE/'export'/logbase/row['path']).read_bytes()
        check(digest(raw)==row['sha256'] and len(raw)==row['bytes'],'exact native failure hash '+row['path'])
        check(row['actual_result']=='FAIL','failure never relabeled '+row['path'])
        for line in row['native_trailing_space_lines']:
            actual=raw.splitlines(keepends=True)[line['line_number']-1]
            check(actual.hex()==line['line_hex'] and actual.endswith(b' \r\n'),'exact native failed line '+row['path'])
        check(row['path']+' -text whitespace=-blank-at-eol,blank-at-eof,space-before-tab,cr-at-eol' in attrs,'only necessary native path exception '+row['path'])

# Independent exact arithmetic, not a call to the implementation under review.
bad=F(1,4);positive=bad*F(4,5)+(1-bad)*F(1,10);negative=1-positive
check(positive==F(11,40),'positive branch mass11/40')
check(negative==F(29,40),'negative branch mass29/40')
check(bad*F(4,5)/positive==F(8,11),'positive posterior8/11')
check(bad*F(1,5)/negative==F(2,29),'negative posterior2/29')
check(F(2)*bad*F(4,5)+positive+F(6)*bad*F(1,5)==F(39,40),'six-second contingent loss39/40')
check(F(1,4)*bad+1==F(17,16),'direct loss17/16')
check(F(6)*bad==F(3,2),'defer loss3/2')
check(F(2)*bad+1==F(3,2),'nonadaptive delayed action loss3/2')
check((bad*F(1,2))/(bad*F(1,2)+(1-bad))==F(1,7),'random support counterexample1/7')
qa,qb=F(4,5),F(1,5);la=qa*F(4,5)+(1-qa)*F(1,10);lb=qb*F(4,5)+(1-qb)*F(1,10)
mass=F(1,2)*(la+lb);pa=F(1,2)*la/mass
check(F(1,2)*F(4,5)/mass==F(8,9),'true mixed outcome mass8/9')
check(pa*qa+(1-pa)*qb==F(16,25),'unchanged catalog recombination16/25 differs')
true=[F(36,59),F(16,59),F(1,59),F(6,59)];shown=[F(str(float(p))) for p in true];represented=[p/sum(shown) for p in shown]
check(represented!=true and represented[1]-true[1]==F(-23,983333333333333412),'representation difference classified separately')

report='''# 第26项A/B投影 Spec 静态复核

7798ce9d：已审A/B范围PASS，未解决发现0。公共目标/工具/资格绑定与合法短工时未知值分开；v2逐世界确定支持域、正负报告及全部假设组合的精确结果质量兼容条件实现一致。符号报告无测量值，不进入真实账；已知到达、来源、时钟和权限门槛保留。表示舍入不等同缺模型，未知值不产生数值包络。

39项仅为保存的开发接口回归；本复核项目调用0。独立39/40、17/16、8/11、2/29和8/9≠16/25算术通过，原失败日志及前评审不改。非二进制后验的数值支持仍有限，线上桥接、冻结原件和根验收明确待做，不据此接受26或声称收益。
'''
(HERE/'SPEC.md').write_text(report,encoding='utf-8',newline='\n')
(HERE/'checks.json').write_text(json.dumps(dict(checks_passed=len(checks),checks=checks),ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
review=dict(schema='aegisdc-ticket26-projection-independent-spec-review-v1',axis='Spec',status='PASS',base=BASE,source=SOURCE,
    runtime_revision='8454cff5',checks_passed=len(checks),unresolved_findings=0,findings=[],exact_exports=len(pins['exports']),
    prior_review_files_preserved=len(read(HERE/'prior-preserved.json')),historical_originals_preserved=len(old),
    saved_targeted_methods=39,saved_targeted_seconds=6.834,saved_targeted_scope='Developer public selection/value/belief/CLI checks; no new simulation; not independently executed here.',
    report_sha256=digest((HERE/'SPEC.md').read_bytes()),new_selector_calls=0,new_assessments=0,new_tests=0,new_simulate_calls=0,
    new_inference=0,new_capture=0,root_acceptance_claimed=False,ticket_resolved=False,overall_goal='ACTIVE',
    scope='A/B projection implementation only; declared online, general numerical support, formal capture and root acceptance remain pending.')
(HERE/'review.json').write_text(json.dumps(review,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
manifest={p.relative_to(HERE).as_posix():dict(sha256=digest(p.read_bytes()),bytes=p.stat().st_size)
    for p in HERE.rglob('*') if p.is_file() and p.name!='manifest.json' and '__pycache__' not in p.parts and p.suffix not in {'.pyc','.pyo'}}
(HERE/'manifest.json').write_text(json.dumps(dict(artifacts=manifest,terminal_manifest='manifest.json'),ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(dict(status='PASS',source=SOURCE,checks_passed=len(checks),unresolved_findings=0,report_sha256=review['report_sha256'],review_sha256=digest((HERE/'review.json').read_bytes()),manifest_members=len(manifest),new_project_calls=0)))
