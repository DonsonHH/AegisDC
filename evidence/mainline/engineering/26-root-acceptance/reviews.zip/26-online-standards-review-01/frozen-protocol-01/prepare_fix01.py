"""Retain reviewer-tool failures and fix a branch-token assertion only."""
from hashlib import sha256
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parent
old=(ROOT/'seal_review.py').read_text(encoding='utf-8')
record=dict(classification='STATIC_REVIEW_TOOL_ASSERTION_FAILURE_NOT_APPLICATION_FAILURE',
    script='seal_review.py',sha256=sha256((ROOT/'seal_review.py').read_bytes()).hexdigest(),exit_code=1,line=154,
    error='AssertionError: frozen exact expected fields depend on this loop',
    cause='Reviewer token assumed literal positive/negative subscripts, while application source uses expected[branch]. The independent empty-compatibility coverage finding remains.',new_project_calls=0)
with (ROOT/'static-audit-failure-01.json').open('x',encoding='utf-8') as stream:json.dump(record,stream,ensure_ascii=False,indent=2)
orchestration=dict(classification='REVIEWER_SHELL_PREPARATION_FAILURES_NOT_APPLICATION_FAILURES',
    entries=[dict(exit_code=1,error="PowerShell ParserError: Unexpected token 'not' in expression or statement.",
        effect='Python repair command did not start; no repair script or record was written.'),
        dict(exit_code=1,error="Python cannot open seal_review_fix01.py: [Errno 2] No such file or directory",effect='Repair script had not been created; no application execution.')],new_project_calls=0)
with (ROOT/'review-tool-preparation-failure-01.json').open('x',encoding='utf-8') as stream:json.dump(orchestration,stream,ensure_ascii=False,indent=2)
a="all(\"expected[\"+repr(k)+\"]\" in loop_text for k in ('exact_current','positive','negative','projected_positive','original_positive'))"
b="all(\"expected[\"+repr(k)+\"]\" in loop_text for k in ('exact_current','projected_positive','original_positive')) and 'expected[branch]' in loop_text"
assert old.count(a)==1
fixed=old.replace(a,b)
a="check('proper actual versus forecast horizons documented','not the same object' not in source or True)"
b="check('proper actual versus forecast horizons documented','Each catalog horizon is relative to the decision.' in protocol['forecast_scope'] and 'Actual physical horizon is six seconds' in protocol['forecast_scope'])"
assert fixed.count(a)==1
fixed=fixed.replace(a,b)
with (ROOT/'seal_review_fix01.py').open('x',encoding='utf-8',newline='\n') as stream:stream.write(fixed)
print('Prepared corrected static audit; original tool and failures retained; zero project calls.')
