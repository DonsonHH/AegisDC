Standards：CHANGES_REQUIRED（860f0ca…93b7ad99）。

硬标准风险P2：candidate_delivery.py:75用空列表兜底遍历兼容性审计。审计缺失/为空时，冻结的positive、negative、exact_current等独立预期不会被核对。应先要求覆盖声明的belief×value组合，再检查两个分支；见AGENTS独立预期及有限交付文档。

其余静态范围未见阻断：16输入、5原始见证、10公开选择＋6×6秒设施＋21在线决策、三对相同输入、fsynced STARTED、失败即停、源守卫及50件输出＋终态声明一致。保存verify可达链不导入应用或重算决策。实际图与预测图分别标示。启发性异味无须另扩范围。原核心及860包未变，新增项目调用0；正式捕获与第26项接受仍待完成。
