"""Static Standards review of frozen protocol/tools, without importing them."""
import ast
from copy import deepcopy
from fractions import Fraction as F
from hashlib import sha256
import json
import math
from pathlib import Path
import subprocess

OUT=Path(__file__).resolve().parent
REPO=Path('C:/Users/Donson/.codex/worktrees/mainline23-intervention/Renly')
BASE='860f0ca39f5e866ad2531466360cc7ce95f64ded'
SOURCE='93b7ad992fe233068521c10decc3c85756c806d1'
PREFIX='evidence/mainline/engineering/26-candidate/'
checks=[]
def check(name,ok):
    checks.append(dict(name=name,passed=bool(ok)))
    if not ok:raise AssertionError(name)
def digest(raw):return sha256(raw).hexdigest()
def read(name):return json.loads((OUT/name).read_bytes())
def text(name):return (OUT/'export'/name).read_text(encoding='utf-8')
def encode(v):return (json.dumps(v,ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode()
def write(name,raw):
    with (OUT/name).open('xb') as stream:stream.write(raw)
def git(*args):return subprocess.check_output(['git',*args],cwd=REPO)
def top_functions(source):return {n.name:n for n in ast.parse(source).body if isinstance(n,ast.FunctionDef)}
def imports(node):return [n for n in ast.walk(node) if isinstance(n,(ast.Import,ast.ImportFrom))]
def app_imports(node):
    return [n for n in imports(node) if (getattr(n,'module','') or '').startswith('aegis_dc') or any(a.name.startswith('aegis_dc') for a in getattr(n,'names',[]))]

pins=read('source-manifest.json');dep=read('dependency-manifest.json');before=read('prior-reviews-before.json')
check('fixed source and base',pins['source']==SOURCE and pins['base']==BASE)
check('nonempty fixed diff',bool((OUT/'candidate.diff').read_bytes()))
check('metadata/tool-only source delta',not any(n.startswith('src/') for n in pins['changed_files']))
for name,expected in before.items():check('prior D reviews sealed '+name,digest((OUT.parent/name).read_bytes())==expected)
identities={**pins['files'],**dep};ordered=sorted(identities)
batch=subprocess.check_output(['git','cat-file','--batch'],cwd=REPO,input=''.join(SOURCE+':'+n+'\n' for n in ordered).encode())
offset=0
for name in ordered:
    end=batch.index(b'\n',offset);header=batch[offset:end].split();assert len(header)==3 and header[1]==b'blob'
    start=end+1;size=int(header[2]);raw=batch[start:start+size];offset=start+size+1
    check('fixed committed export '+name,raw==(OUT/'export'/name).read_bytes() and digest(raw)==identities[name]['sha256'])
    if name.endswith('.py'):ast.parse(raw.decode(),filename=name);check('static AST parse '+name,True)
check('one complete batch',offset==len(batch))
for name in ('src/aegis_dc/plant.py','src/aegis_dc/policy_execution.py'):
    check('a08 runtime preserved '+name,(OUT/'export'/name).read_bytes()==(OUT.parent/'export'/name).read_bytes())
protocol=json.loads(text('docs/mainline/26-candidate-engineering-protocol.json'))
cases=protocol['pure_cases']+protocol['physical_cases'];case_ids=[c['id'] for c in cases]
check('frozen finite engineering identity',protocol['schema']=='aegisdc-candidate-engineering-protocol-v1' and protocol['status']=='FROZEN_ON_COMMIT_BEFORE_CAPTURE' and protocol['classification']=='FINITE_ENGINEERING_INTERFACES_NOT_EFFECT_COMPARISON')
check('10 pure cases',len(protocol['pure_cases'])==protocol['pure_selector_calls']==10)
check('6 physical cases total36s',len(protocol['physical_cases'])==protocol['physical_runs']==6 and sum(c['duration_s'] for c in protocol['physical_cases'])==protocol['total_simulated_duration_s']==36)
check('all cases unique',len(set(case_ids))==16)
references={c['id']:json.loads(text(c['input'])) for c in cases}
check('16 exact referenced inputs',len({c['input'] for c in cases})==16 and sum('/reference/' in n and n.endswith('.json') for n in identities)==16)
check('5 independent oracle originals',sum('/oracles/' in n and n.endswith('.json') for n in identities)==5)
online_calls=sum(len(references[c['id']]['dispatch_program']['decision_times_s']) for c in protocol['physical_cases'])
check('21 scheduled online calls distinct from10 pure',online_calls==protocol['scheduled_online_decision_calls']==21)
check('declared maximum step',protocol['maximum_step_s']==.01)
check('stop no retry with separate correction source and output','Any failure stops. No automatic retry or overwriting' in protocol['retry_rule'] and 'new explicit frozen protocol/source/output' in protocol['retry_rule'])
check('engineering only field pending',protocol['registered_research_trials']==protocol['llm_calls']==protocol['training_calls']==0 and protocol['field_calibration']=='PENDING')
for pair_name in ('same_public_pair','same_exact_pair','same_online_pair'):
    pair=deepcopy([references[n] for n in protocol[pair_name]])
    for document in pair:document.get('dispatch_program',document)['policy_program'].pop('policy')
    check('same public/model/resource pair '+pair_name,pair[0]==pair[1])
models=[references[c['id']]['model'] for c in protocol['physical_cases']]
check('same actual model across all six',all(m==models[0] for m in models))
check('eight declared domains four graphs',len(models[0]['domains'])==8 and set(models[0]['graphs'])=={'physical','functional','control_information','access'})
for case in protocol['physical_cases']:
    document=references[case['id']];program=document['dispatch_program'];projection=program['policy_program']['evidence_projection'];expected=case['expected']
    check('public inspection profile same executor '+case['id'],projection['inspection_profile']==program['inspection_program']['profile'])
    check('public sparse fixed profile same executor '+case['id'],projection['background_sensor_profile']==program['sensor_program']['profile'])
    check('all physical horizons six '+case['id'],case['duration_s']==6)
    check('literal service integrals '+case['id'],expected['demand_service_unit_s']==6 and expected['delivered_service_unit_s']==F(3,2) and expected['service_deficit_time_s']==F(9,2))
    check('closed public selection input has no expected field '+case['id'],'expected' not in document)
for case in protocol['pure_cases']:check('pure input expectation separate '+case['id'],'expected' not in references[case['id']])
declared=set(protocol['durable_root'])|{c['id']+'/'+n for c in protocol['pure_cases'] for n in protocol['durable_pure']}|{c['id']+'/'+n for c in protocol['physical_cases'] for n in protocol['durable_physical']}
check('exact50 durable outputs before terminal',len(declared)==50 and protocol['terminal_receipt']=='receipt.json' and 'receipt.json' not in declared)
check('caches not durable',all('__pycache__' not in n and not n.endswith(('.pyc','.pyo')) for n in declared))

source=text('scripts/candidate_delivery.py');helper=text('scripts/inspection_delivery.py');prep=text('scripts/prepare_candidate_inputs.py')
functions=top_functions(source);helper_functions=top_functions(helper)
capture=ast.get_source_segment(source,functions['capture']);verify=ast.get_source_segment(source,functions['verify'])
check('main capture uses clean committed revision',"require(not git('status', '--porcelain')" in capture and "source = git('rev-parse', 'HEAD')" in capture)
check('new output never overwrite',"folder.mkdir(exist_ok=False)" in capture)
check('interpreter executable/version pinned','executable_sha256=digest(Path(sys.executable).read_bytes()), python=sys.version' in capture)
check('initial source guard before project import',capture.index('Initial source pins differ')<capture.index('from aegis_dc.dispatch_policy import'))
append=ast.get_source_segment(source,functions['append'])
check('STARTED append flush and fsync','stream.flush()' in append and 'os.fsync(stream.fileno())' in append)
check('STARTED journal before both application calls',capture.index("status='STARTED'")<capture.index('result = choose_work(')<capture.index('result = simulate_scenario('))
check('each case source guarded first',capture.index("'Source changed before case'")<capture.index("status='STARTED'"))
check('completion only after saved check',capture.index('check_decision(folder, case, protocol)')<capture.index("status='COMPLETED'") and capture.index('check_physical(folder, case, protocol)')<capture.index("status='COMPLETED'"))
check('failure appends original error then reraises',"status='FAILED'" in capture and 'error_type=type(error).__name__, error=str(error)' in capture and 'raise' in capture)
check('terminal finally rechecks source bytes','finally:' in capture and "receipt['source_head_and_bytes_unchanged'] = unchanged(source, identities)" in capture)
check('source guard refusal cannot pass','source_guard_error' in capture and "require(receipt['status'] == 'PASS'" in capture)
check('durable exact set checked before PASS',capture.index('durable(folder) == declared(protocol)')<capture.index("receipt['status'] = 'PASS'"))
check('receipt hashes all original durable members',"receipt['artifacts'] = {name: digest((folder / name).read_bytes()) for name in sorted(durable(folder))}" in capture)
check('fixed16 loop only one selector and simulator site',capture.count('result = choose_work(')==capture.count('result = simulate_scenario(')==1)
pin_source=ast.get_source_segment(source,functions['pins'])
check('all three authoring helper/preparation tools pinned',"[protocol['authoring_tool'], protocol['helper_tool'], protocol['input_preparation_tool']]" in pin_source)
check('source/test/config/reference/oracle/historical roles declared',all(t in pin_source for t in ('runtime=','tools=tools','inputs=inputs','historical_development=','/reference/','/oracles/','/development-originals-')))
check('cache names excluded source pins',"'__pycache__' not in name and not name.endswith(('.pyc', '.pyo'))" in pin_source)
check('helper durable classification excludes cache',"'__pycache__' not in p.parts and p.suffix not in {'.pyc','.pyo'}" in helper)
check('helper hashes batch Git blobs',"['git','cat-file','--batch']" in helper)
check('verify clean requested delivery',"git('rev-parse', 'HEAD').decode().strip() == delivery and not git('status', '--porcelain')" in verify)
check('verify exact durable role and actual set',"set(receipt['artifacts']) == declared(protocol) and durable(folder) == declared(protocol) | {protocol['terminal_receipt']}" in verify)
check('verify each committed delivery artifact','Committed delivery blob differs' in verify)
check('verify execution and delivery pin equivalence',"receipt['pinned'] == pins(protocol, source)" in verify and "identities == hashes(delivery, identities)" in verify)
check('verify original runtime revision and change flag',"identity['git_commit'] == source and not identity['implementation_has_changes']" in verify)
check('verify original runtime hash anchored','Actual runtime files differ from source guard' in verify)
check('verify original attempt count/order/source',"len(ledger) == 2 * len(all_cases)" in verify and "['STARTED', 'COMPLETED']" in verify and "row['execution_commit'] == source" in verify)
check('verify saved checks and deterministic figures','checks == read(folder / \'checks.json\')' in verify and "raw == (folder / name).read_bytes()" in verify)

# Build the saved-only reachable function graph without calling any function.
all_functions={**helper_functions,**functions};pending=['verify'];reachable=set()
while pending:
    name=pending.pop()
    if name in reachable:continue
    reachable.add(name);node=all_functions[name]
    check('saved-only reachable no app import '+name,not app_imports(node))
    for call in (n for n in ast.walk(node) if isinstance(n,ast.Call) and isinstance(n.func,ast.Name)):
        if call.func.id in all_functions and call.func.id not in reachable:pending.append(call.func.id)
check('capture unreachable from verification','capture' not in reachable and 'snapshots' not in reachable)
top_level_imports=[n for tree in (ast.parse(source),ast.parse(helper)) for n in tree.body if isinstance(n,(ast.Import,ast.ImportFrom))]
check('top-level helper/application imports absent',not any((getattr(n,'module','') or '').startswith('aegis_dc') for n in top_level_imports))
check('input preparation never calls selector or simulator','choose_work(' not in prep and 'simulate_scenario(' not in prep)
check('preparation exclusive writes and no overwrite',"path.open('x'" in prep and 'folder.mkdir(exist_ok=False)' in prep)
check('preparation rejects nonfinite JSON','allow_nan=False' in prep)
check('forecast chart labelled model not measured','These bars are not measured plant outcomes.' in source)
check('actual flow chart derives saved trace',"trace = rows(folder / identifier / 'private-state.jsonl')" in source)
check('boundary private truth and forecast regime separate','Explicit uncalibrated per-world report-support assumption' in source and 'Only actual arrived records and task-local feedback return' in source)
check('actual service literal not filter restoration','network capacity 0.25 remains limiting' in source)
check('proper actual versus forecast horizons documented','Each catalog horizon is relative to the decision.' in protocol['forecast_scope'] and 'Actual physical horizon is six seconds' in protocol['forecast_scope'])

# Independent arithmetic only, never application expectations computed by a model.
check('physical service deficit analytic',F(6)-F(6)*F(1,4)==F(9,2))
check('hydraulic before literal',F(150000,12000000*4+3000000)==F(1,340))
check('hydraulic residual literal',F(150000,12000000*2+3000000)==F(1,180))
world=[F(36,59),F(16,59),F(1,59),F(6,59)];law=[F(1,10),F(4,5),F(1,10),F(1,10)]
positive=sum(p*l for p,l in zip(world,law));negative=1-positive
check('nondyadic literal report probabilities',positive==F(171,590) and negative==F(419,590))
check('nondyadic branch masses independent',world[1]*law[1]/positive==F(128,171) and world[1]*(1-law[1])/negative==F(32,419))
check('nonneutral epoch mismatch stays distinct',F(8,11)!=F(128,171))
oracles=[json.loads(text(n)) for n in identities if '/oracles/' in n]
check('oracle original claims remain engineering',all(o.get('registered_research_trials')==0 for o in oracles))
values={c['id']:c['expected'] for c in protocol['pure_cases']}
check('frozen exact oracle ratios retained',values['exact-candidate']['values']==dict(inspect_then_act=[619,590],direct_intervention=[63,59],defer=[96,59]))
check('legacy incompatible null retained',values['legacy-representation-boundary']['values']['inspect_then_act'] is None)

decision=ast.get_source_segment(source,functions['check_decision'])
loop=next(n for n in ast.walk(functions['check_decision']) if isinstance(n,ast.For) and isinstance(n.iter,ast.Call) and isinstance(n.iter.func,ast.Name) and n.iter.func.id=='enumerate')
loop_text=ast.get_source_segment(source,loop)
check('documented verifier gap exists in fixed source',"audit.get('compatibility_by_assumption', [])" in loop_text)
check('frozen exact expected fields depend on this loop',all("expected["+repr(k)+"]" in loop_text for k in ('exact_current','projected_positive','original_positive')) and 'expected[branch]' in loop_text)
witness=dict(classification='STATIC_CONTROL_FLOW_WITNESS_NOT_APPLICATION_CALL',
    source=SOURCE,file='scripts/candidate_delivery.py',line=loop.lineno,
    expected_keys=['classification','positive','negative'],audit=dict(classification='INFORMATIVE_COMPATIBLE_WITH_DECLARED_UPDATER',compatibility_by_assumption=[]),
    loop_iterations=0,skipped_checks=['positive projected mass','negative projected mass'],new_project_calls=0)
write('empty-compatibility-static-witness.json',encode(witness))
finding=dict(id='STD-D-FROZEN-01',priority=2,kind='verification_contract',
    file='scripts/candidate_delivery.py',line=loop.lineno,
    title='Require compatibility audit coverage before checking the frozen posterior literals',
    detail='An absent or empty compatibility_by_assumption produces zero loop iterations. Frozen positive/negative/exact_current/projected_positive/original_positive assertions are then skipped while classification and aggregate values may still pass. Require the expected belief-by-value audit set before its branch checks.',
    standard='AGENTS.md Interfaces and verification: independently specified outcomes; docs/mainline/26-finite-engineering-delivery.md saved verification must check independent expectations',
    remediation='When these expected fields exist, require nonempty complete declared belief×value coverage and required positive/negative fields before exact comparison.',
    application_runtime_defect=False,requires_new_frozen_tool_pin=True)
after={p.relative_to(OUT.parent).as_posix():digest(p.read_bytes()) for p in sorted(OUT.parent.rglob('*')) if p.is_file() and OUT not in p.parents}
check('prior D core and archive file sets unchanged',before==after)
write('prior-reviews-after.json',encode(after));write('checks.json',encode(checks))
report='''Standards：CHANGES_REQUIRED（860f0ca…93b7ad99）。\n\n硬标准风险P2：candidate_delivery.py:75用空列表兜底遍历兼容性审计。审计缺失/为空时，冻结的positive、negative、exact_current等独立预期不会被核对。应先要求覆盖声明的belief×value组合，再检查两个分支；见AGENTS独立预期及有限交付文档。\n\n其余静态范围未见阻断：16输入、5原始见证、10公开选择＋6×6秒设施＋21在线决策、三对相同输入、fsynced STARTED、失败即停、源守卫及50件输出＋终态声明一致。保存verify可达链不导入应用或重算决策。实际图与预测图分别标示。启发性异味无须另扩范围。原核心及860包未变，新增项目调用0；正式捕获与第26项接受仍待完成。\n'''
write('report.md',report.encode('utf-8'))
review=dict(schema='aegisdc-independent-standards-review-v1',axis='Standards',status='CHANGES_REQUIRED',base=BASE,source=SOURCE,
    scope='Frozen engineering protocol, authoring/preparation tools, helper reachable saved-only graph, fixed16 reference inputs and5 independent oracles; static only',
    checks=len(checks),exports=len(identities),pure_cases=10,physical_cases=6,declared_physical_duration_s=36,scheduled_online_decisions=21,
    durable_outputs=50,terminal_receipts=1,reachable_saved_only_functions=sorted(reachable),hard_findings=[finding],heuristic_findings=[],unresolved=[finding['id']],
    prior_review_files_preserved=len(before),new_project_calls=0,tests_run=0,selectors_run=0,assessments_run=0,inference_calls=0,simulation_calls=0,
    formal_capture=False,ticket_acceptance=False,
    launch_note='Root declares -B -X utf8 and a new nonexistent ignored PYTHONPYCACHEPREFIX for actual capture; preserve this command/environment in root execution records. Script sys.argv alone omits interpreter flags/environment.',
    limits=['Original93 exports preserved; resolve the verification gap at a new frozen pin before formal capture','No protocol preflight/capture or saved project verifier invoked'])
write('review.json',encode(review))
artifacts={p.relative_to(OUT).as_posix():dict(sha256=digest(p.read_bytes()),bytes=p.stat().st_size) for p in sorted(OUT.rglob('*')) if p.is_file()}
write('delivery-manifest.json',encode(dict(schema='aegisdc-static-review-delivery-manifest-v1',source=SOURCE,artifacts=artifacts,terminal_receipt='delivery-manifest.json',new_project_calls=0)))
print(json.dumps(dict(status='CHANGES_REQUIRED',checks=len(checks),findings=1,new_project_calls=0,report_sha256=digest((OUT/'report.md').read_bytes()),review_sha256=digest((OUT/'review.json').read_bytes()))))
