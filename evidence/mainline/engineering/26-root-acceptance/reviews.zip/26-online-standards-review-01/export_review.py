"""Fixed Git export for the D Standards review; no project imports or calls."""
from hashlib import sha256
import json
from pathlib import Path
import subprocess

OUT=Path(__file__).resolve().parent
REPO=Path('C:/Users/Donson/.codex/worktrees/mainline23-intervention/Renly')
PRIOR=Path('C:/Users/Donson/Documents/ChatGPT/Renly/.work/26-projection-standards-review-01')
BASE='4dee4488a274528de801b9c1475577b675c0d072'
SOURCE='a08dc371f85570f20ce486401f1427ade0a76a3a'

def git(*args):return subprocess.check_output(['git',*args],cwd=REPO)
def write(name,raw):
    path=OUT/name;path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('xb') as stream:stream.write(raw)
def encode(value):return (json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode()
def digest(raw):return sha256(raw).hexdigest()

assert git('rev-parse',BASE).decode().strip()==BASE
assert git('rev-parse',SOURCE).decode().strip()==SOURCE
assert git('merge-base',BASE,SOURCE).decode().strip()==BASE
diff=git('diff',BASE+'...'+SOURCE);assert diff
prior={p.relative_to(PRIOR).as_posix():digest(p.read_bytes()) for p in sorted(PRIOR.rglob('*')) if p.is_file()}
write('prior-reviews-before.json',encode(prior))
write('candidate.diff',diff)
write('commits.txt',git('log','--format=%H %s',BASE+'..'+SOURCE))
tree=set(git('ls-tree','-r','--name-only',SOURCE).decode().splitlines())
changed=git('diff','--name-only',BASE+'...'+SOURCE).decode().splitlines()
standards=['AGENTS.md','GLOSSARY.md','docs/agents/domain.md','docs/agents/issue-tracker.md',
    'docs/agents/triage-labels.md','docs/adr/0001-preserve-premeeting-and-reset-research.md',
    'docs/adr/0002-sparse-evidence-not-sensor-free.md','docs/adr/0003-complete-facility-mainline.md',
    '.scratch/full-facility-mainline/spec.md','docs/MAINLINE.md','docs/mainline/progress.json',
    '.scratch/full-facility-mainline/issues/26-candidate-policy.md',
    'docs/mainline/26-evidence-consistent-candidate.md','docs/mainline/26-online-policy-bridge-plan.md',
    'docs/mainline/26-projection-law-next-slice.md','docs/mainline/26-exact-valuation-basis-proposal.md']
related=['src/aegis_dc/'+n+'.py' for n in ['__main__','action_value','belief','dispatch_policy',
    'evidence_ledger','evidence_projection','inspection_execution','lookahead_policy','policy_budget',
    'sensor_channels','workforce','workforce_dispatch','intervention_execution','risk_closure']]
related=[p for p in related if p in tree]
standard_names=[p for p in tree if Path(p).name.upper() in {'CODING_STANDARDS.MD','CONTRIBUTING.MD'}]
paths=sorted(set(changed+standards+related+standard_names))
assert all(p in tree for p in paths)
base_paths=sorted(set(p for p in paths if p.startswith('src/') or p in standard_names or p in standards))
keys=[SOURCE+':'+p for p in paths]+[BASE+':'+p for p in base_paths]
raw=git('cat-file','--batch') if False else subprocess.check_output(['git','cat-file','--batch'],cwd=REPO,input=''.join(k+'\n' for k in keys).encode())
offset=0;blobs={};ids={}
for key in keys:
    end=raw.index(b'\n',offset);header=raw[offset:end].split();assert len(header)==3 and header[1]==b'blob',key
    size=int(header[2]);start=end+1;blobs[key]=raw[start:start+size];ids[key]=header[0].decode();offset=start+size+1
assert offset==len(raw)
files={}
for path in paths:
    key=SOURCE+':'+path;data=blobs[key];write('export/'+path,data)
    files[path]=dict(git_blob=ids[key],sha256=digest(data),bytes=len(data))
for path in base_paths:write('base-export/'+path,blobs[BASE+':'+path])
write('source-manifest.json',encode(dict(schema='aegisdc-static-review-source-export-v1',axis='Standards',
    base=BASE,source=SOURCE,diff_command='git diff '+BASE+'...'+SOURCE,changed_files=changed,
    files=files,base_exports=base_paths,documented_coding_files=standard_names,new_project_calls=0,
    tool_scope='Git export, JSON and hashes only; no project imports')))
print(json.dumps(dict(source=SOURCE,changed_files=len(changed),exports=len(paths),base_exports=len(base_paths),
    preserved_prior_files=len(prior),coding_standards_files=standard_names,new_project_calls=0)))
