"""D fixed-source Standards audit; AST, Git, JSON, hashes and literals only."""
import ast
from fractions import Fraction
from hashlib import sha256
import json
from pathlib import Path
import subprocess

OUT=Path(__file__).resolve().parent
REPO=Path('C:/Users/Donson/.codex/worktrees/mainline23-intervention/Renly')
PRIOR=OUT.parent/'26-projection-standards-review-01'
BASE='4dee4488a274528de801b9c1475577b675c0d072'
SOURCE='a08dc371f85570f20ce486401f1427ade0a76a3a'
checks=[]
def check(name,ok):
    checks.append(dict(name=name,passed=bool(ok)))
    if not ok:raise AssertionError(name)
def digest(raw):return sha256(raw).hexdigest()
def read(name):return json.loads((OUT/name).read_bytes())
def text(name,folder='export'):return (OUT/folder/name).read_text(encoding='utf-8')
def write(name,raw):
    with (OUT/name).open('xb') as stream:stream.write(raw)
def encoded(value):return (json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode()
def git(*args):return subprocess.check_output(['git',*args],cwd=REPO)
def function(source,name):
    return next(n for n in ast.walk(ast.parse(source)) if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name==name)

manifest=read('source-manifest.json');prior=read('prior-reviews-before.json')
check('source pin',manifest['source']==SOURCE and manifest['base']==BASE)
check('fixed merge base',git('merge-base',BASE,SOURCE).decode().strip()==BASE)
check('nonempty triple-dot diff',bool((OUT/'candidate.diff').read_bytes()))
commits=(OUT/'commits.txt').read_text()
for commit in ('13e9725a11063e1eddba2b53a208c0f0c898492f',SOURCE):check('commit range includes '+commit,commit in commits)
check('no documented CODING_STANDARDS or CONTRIBUTING file',manifest['documented_coding_files']==[])
for name,expected in prior.items():check('prior sealed review preserved '+name,digest((PRIOR/name).read_bytes())==expected)
keys=[SOURCE+':'+n for n in manifest['files']]+[BASE+':'+n for n in manifest['base_exports']]
batch=subprocess.check_output(['git','cat-file','--batch'],cwd=REPO,input=''.join(k+'\n' for k in keys).encode())
offset=0;blobs={}
for key in keys:
    end=batch.index(b'\n',offset);header=batch[offset:end].split();assert len(header)==3 and header[1]==b'blob',key
    start=end+1;size=int(header[2]);blobs[key]=batch[start:start+size];offset=start+size+1
check('single batch complete',offset==len(batch))
for name,identity in manifest['files'].items():
    raw=(OUT/'export'/name).read_bytes()
    check('exact candidate export '+name,raw==blobs[SOURCE+':'+name] and digest(raw)==identity['sha256'] and len(raw)==identity['bytes'])
    if name.endswith('.py'):
        ast.parse(raw.decode('utf-8'),filename=name);check('AST parse '+name,True)
for name in manifest['base_exports']:
    check('exact base export '+name,(OUT/'base-export'/name).read_bytes()==blobs[BASE+':'+name])
    if name not in {'src/aegis_dc/plant.py','src/aegis_dc/policy_execution.py'}:
        check('unchanged shared model or standards '+name,blobs[BASE+':'+name]==blobs[SOURCE+':'+name])
check('only declared two runtime files changed',
    {n for n in manifest['changed_files'] if n.startswith('src/')}=={'src/aegis_dc/plant.py','src/aegis_dc/policy_execution.py'})

policy=text('src/aegis_dc/policy_execution.py');old=text('src/aegis_dc/policy_execution.py','base-export')
constructor=ast.get_source_segment(policy,function(policy,'__init__'))
for name in ('_frame','process','next_event'):
    check('unchanged execution clock boundary '+name,ast.dump(function(policy,name))==ast.dump(function(old,name)))
check('v4 public profile declarations required',"type(projection) is dict and type(self.inspection_program) is dict and 'profile' in self.inspection_program" in constructor)
check('background profile presence type required',"background is None or type(background) is dict and 'profile' in background" in constructor)
check('exact inspection public identity equality',"projection.get('inspection_profile')==self.inspection_program['profile']" in constructor)
check('exact background public identity including null',"projection.get('background_sensor_profile')==(background['profile'] if background is not None else None)" in constructor)
check('profile validation before actual sensor construction',constructor.index("projection.get('inspection_profile')")<constructor.index('self.sensors=LiveSensorSession'))
new_gate=constructor[constructor.index("if program['policy_program']['schema']=='aegisdc-dispatch-policy-program-v4':"):constructor.index('self.closure_template=')]
check('new profile gate no private or future oracle',all(x not in new_gate for x in ('realization','InspectionSession','LiveSensorSession','choose_work','snapshot(','simulate_scenario','biases','noise_bounds','seed')))
check('v4 inherits action declaration identity',"if program['policy_program']['schema'] in {'aegisdc-dispatch-policy-program-v3','aegisdc-dispatch-policy-program-v4'}:" in constructor and "program['policy_program']['intervention_declaration']==self.intervention_program" in constructor)
check('v4 inherits inspection intervention kind exclusivity',"{'aegisdc-dispatch-policy-program-v2','aegisdc-dispatch-policy-program-v3','aegisdc-dispatch-policy-program-v4'}:" in constructor and "not inspection_ids&intervention_ids" in constructor)
check('kind binds actual public task set',"candidate['task']['id'] in expected" in constructor)
check('legacy constructor lookup retained only for nonv4',"program['policy_program']['schema']!='aegisdc-dispatch-policy-program-v4'" in constructor)
check('constructor never makes policy choice','choose_work(' not in constructor)
process=ast.get_source_segment(policy,function(policy,'process'))
check('exact actual decision instant enforced',"time_s==self.times[self.index]" in process)
check('selector consumes only current frame and public history',"choice=choose_work(frame,self.program['policy_program'],history,intervention_declaration=self.intervention_program,closure_program=closure)" in process)
check('closure only arrived intervention feedback',"interventions.public_feedback(time_s)" in process)
check('work feedback only actual current time','workforce.public_feedback(time_s)' in process)
check('selector model computation retained in audit',"model_evaluations=deepcopy(choice['model_evaluations'])" in process)
check('clock wall time diagnostic only','DIAGNOSTIC_WALL_TIME_ONLY_NOT_PHYSICAL_TIME_OR_POLICY_INPUT' in process)
resource=ast.get_source_segment(policy,function(policy,'resource_ledger'))
check('v4 final ledger enabled',"not in {'aegisdc-dispatch-policy-program-v3','aegisdc-dispatch-policy-program-v4'}" in resource)
check('final ledger uses actual issued and current public feedback',"dict(issued=self.issued,work_feedback=workforce.public_feedback(time_s))" in resource)
plant=text('src/aegis_dc/plant.py');oldplant=text('src/aegis_dc/plant.py','base-export')
old_condition="dispatch.program['policy_program']['schema']=='aegisdc-dispatch-policy-program-v3'"
new_condition="dispatch.program['policy_program']['schema'] in {'aegisdc-dispatch-policy-program-v3','aegisdc-dispatch-policy-program-v4'}"
check('plant delta only final ledger extension',oldplant.count(old_condition)==1 and oldplant.replace(old_condition,new_condition)==plant)
check('same advancing plant schedules public decisions',plant.index('inspections.process(time_s, workforce, snapshot)')<plant.index('dispatch.sensors.process(time_s,snapshot)')<plant.index('dispatch.process(time_s,workforce,inspections,interventions)'))
dispatch=text('src/aegis_dc/dispatch_policy.py');lookahead=text('src/aegis_dc/lookahead_policy.py');budget=text('src/aegis_dc/policy_budget.py')
check('public projection validated before candidate binding',dispatch.index("validate_projection(frame,program['evidence_projection'])")<dispatch.index("candidates=_registry(program['candidates']"))
check('v4 same closest baseline and candidate evaluator',"program['policy'] in {'one_observation_lookahead','evidence_consistent_contingent'}" in dispatch)
check('v4 actual frame reused for public binding validation',"validate_execution_bindings(policy_declaration,dict(profile=policy_declaration['evidence_projection']['inspection_profile']),frame=frame)" in lookahead)
check('existing extra model assessments counted','action_value=2 if policy_declaration is not None else 1' in lookahead)
check('public history excludes future feedback',"row['arrived_at_s']<=frame['as_of_s']" in dispatch)
check('permanent cumulative envelope no terminal refund','terminal_report_refund=False' in budget and "for row in history['issued']" in budget)
check('future authorization still checked','FORECAST_ACTION_AUTHORITY_UNAVAILABLE_AT_COMPLETION' in lookahead)

tests=text('tests/test_evidence_consistent_execution.py');test_ast=ast.parse(tests)
methods=[n.name for n in ast.walk(test_ast) if isinstance(n,ast.FunctionDef) and n.name.startswith('test_')]
check('nine online development behavior methods declared',len(methods)==9)
for name in ('test_online_v4_rejects_public_projection_profile_mismatch_before_deciding',
    'test_online_v4_inherits_the_public_action_declaration_and_task_kind_gates',
    'test_known_pending_fixed_report_keeps_the_contingent_value_unknown_but_direct_work_defined',
    'test_actual_unsuitable_measurement_remains_missing_in_spite_of_the_forecast_support_domain',
    'test_closest_v4_baseline_uses_the_same_public_profiles_and_only_arrived_closure_feedback',
    'test_online_zero_modeled_impairment_allows_defer_without_creating_a_tour'):
    check('declared behavior '+name,name in methods)
inputs=ast.get_source_segment(tests,function(tests,'development_inputs'))
run=ast.get_source_segment(tests,function(tests,'development_run'))
check('development unique attempt identity','uuid4().hex' in inputs and 'exist_ok=False' in inputs)
check('inputs and tools written before invocation',tests.index('folder=development_inputs(model,program,label=label')<tests.index('result=simulate_scenario(model'))
check('runtime snapshots verified before stored','sha256(raw).hexdigest()==expected' in inputs)
check('development status explicitly not research','DEVELOPMENT_ENGINEERING_TEST_NOT_FROZEN_CAPTURE_OR_RESEARCH_TRIAL' in inputs)
check('failure terminal saved in finally',"finally:" in run and "terminal.update(status='FAILED'" in run and "folder/'terminal.json'" in run)
check('completed integration not assertion pass',"PHYSICAL_CALL_COMPLETED_NOT_TEST_ACCEPTANCE" in run)
check('test tools explicitly pinned',"folder/'test-tools.json'" in inputs)
check('CLI guards preserve existing output identity','Output directory already exists' in tests and "self.assertEqual({p.name:sha256(p.read_bytes()).hexdigest() for p in output.iterdir()},before)" in tests)
check('independent service literal deficit',Fraction(6)-Fraction(6)*Fraction(1,4)==Fraction(9,2))
check('forecast assumption never conflated with actual healthy plant',"self.assertEqual(result['summary']['service_deficit_time_s'],4.5)" in tests and "self.assertEqual(reading['availability'],'missing')" in tests)

package=text('scripts/package_candidate_development.py');verify=text('scripts/verify_candidate_development.py')
for name,source in [('package',package),('verify',verify)]:
    imports=[n for n in ast.walk(ast.parse(source)) if isinstance(n,(ast.Import,ast.ImportFrom))]
    check(name+' has no project import',not any((getattr(n,'module','') or '').startswith('aegis_dc') or any(a.name.startswith('aegis_dc') for a in getattr(n,'names',[])) for n in imports))
    check(name+' has no project execution',all(t not in source for t in ('simulate_scenario(','choose_work(','assess_action_value(','python.exe','-m\',\'aegis_dc')))
check('package unique output under declared engineering parent',"not output.exists() and output.parent==ROOT/'evidence/mainline/engineering/26-candidate'" in package)
check('runtime caches excluded from durable set',"'__pycache__' not in p.parts and p.suffix not in {'.pyc','.pyo'}" in package)
check('source reconstruction hash equality required','if digest(raw)==expected:' in package)
check('reconstructed source distinct from original snapshot','EXPLICIT_INVERSE_PATCH_HASH_MATCH' in package and 'not_claimed_as_original_precall_snapshots=True' in package)
check('refusal input and test tool gaps explicitly retained','HISTORICAL_DEVELOPMENT_REFUSAL_INPUTS_NOT_CAPTURED_AND_NOT_RECONSTRUCTED' in package and 'HISTORICAL_DEVELOPMENT_TEST_AUTHORING_TOOLS_NOT_CAPTURED' in package)
check('original statuses preserved',"status_not_rewritten=True" in package and "Original statuses and bytes preserved" in package)
check('transport unknown remains unknown',"completed_integration='UNKNOWN_NOT_ASSUMED_FALSE'" in package and 'TRANSPORT_INTERRUPTED_OUTCOME_UNOBSERVED' in package)
check('saved-only oracle correction no physical retry','no physical retry for that correction' in package)
check('package declares before hashing and receipt',package.index("(output/'declaration.json').write_bytes")<package.index("(output/'receipt.json').write_bytes"))
check('verify exact member set and identities',"set(archive.namelist())==set(members)" in verify and "digest(raw)==identity['sha256'] and len(raw)==identity['bytes']" in verify)
check('verify committed delivery clean checkout',"Use a clean delivery checkout" in verify and "Committed package blob differs" in verify)
check('verify original attempt runtime anchors',"source['sha256']==attempt['source_files'][source['path']]" in verify)
check('verification cannot upgrade ticket acceptance','formal_capture=False,ticket_acceptance=False' in verify)

prefix='evidence/mainline/engineering/26-candidate/'
classification=json.loads(text(prefix+'development-log-format-classification-04.json'))
attrs=text(prefix+'.gitattributes')
for row in classification['entries']:
    raw=(OUT/'export'/prefix/row['path']).read_bytes()
    check('native failure identity '+row['path'],digest(raw)==row['sha256'] and len(raw)==row['bytes'])
    check('native failure remains failed '+row['path'],row['actual_result']=='FAIL' and b'FAILED (' in raw)
    for line in row['native_trailing_space_lines']:
        check('exact original native line '+row['path']+':'+str(line['line_number']),raw.splitlines(keepends=True)[line['line_number']-1].hex()==line['line_hex'])
    check('only per-path exception '+row['path'],row['path']+' -text whitespace=-blank-at-eol,blank-at-eof,space-before-tab,cr-at-eol' in attrs)
for name in ('34-v4-online-clock-and-ledger-red.log','44-online-baseline-closure-check.log'):
    check('original failed log retained '+name,b'FAILED (' in (OUT/'export'/prefix/'development'/name).read_bytes())
check('interrupted CLI log remains byte-empty',not (OUT/'export'/prefix/'development/46-online-v4-cli-no-overwrite-check.log').read_bytes())
saved=json.loads(text(prefix+'development/45-online-baseline-closure-saved-oracle-correction.log'))
check('saved oracle correction explicit no execution',saved['status']=='SAVED_ONLY_CORRECTED_LITERAL_PASS' and saved['new_physical_calls']==0 and saved['original_log_unchanged'] is True)
def tree(rev):
    rows=git('ls-tree','-r',rev,'--',prefix).decode().splitlines()
    return {r.split('\t',1)[1]:r.split()[2] for r in rows}
oldtree=tree(BASE);newtree=tree(SOURCE)
for name,identity in oldtree.items():
    if name!=prefix+'.gitattributes':check('previous candidate evidence unchanged '+name,newtree.get(name)==identity)
progress=json.loads(text('docs/mainline/progress.json'))
check('research remains active',progress['status']=='active' and progress['current_ticket']=='26' and progress['research_trials']['attempts']==0)
check('ticket remains claimed','**Status:** claimed' in text('.scratch/full-facility-mainline/issues/26-candidate-policy.md'))
check('plan preserves final gates','root integrated checks and publication are still required' in text('docs/mainline/26-online-policy-bridge-plan.md'))
after={p.relative_to(PRIOR).as_posix():digest(p.read_bytes()) for p in sorted(PRIOR.rglob('*')) if p.is_file()}
check('prior review set and all hashes unchanged',prior==after)
write('prior-reviews-after.json',encoded(after));write('checks.json',encoded(checks))
report='''Standards：PASS（固定4dee4488…a08dc371，13e9725a与a08两提交）。\n\n硬标准：未发现违反AGENTS、规格私有边界及在线桥接契约的问题。v4先核对公共检查/固定测点profile（含null），继承处置声明、任务种类、累计资源账及最终账输出；实际时刻的公共校验、到达证据、关闭反馈和模型调用计数保留。未调用未来/私有状态作可行性预言。\n\n启发性风险：未发现需扩大本次范围处理的代码异味。\n\n保存工具区分完成运行、断言失败、拒绝与未知中断，重构源码仅按原哈希验证，不冒称原快照。失败34/36/38/44及空46、45保存复核均保留；旧508+183审阅包未变。仅静态复核，新增项目调用0；归档交付补充另pin，正式封存、根验收和第26项接受仍待完成。\n'''
write('report.md',report.encode('utf-8'))
review=dict(schema='aegisdc-independent-standards-review-v1',axis='Standards',status='PASS',base=BASE,source=SOURCE,
    commits=['13e9725a11063e1eddba2b53a208c0f0c898492f',SOURCE],scope='D online v4 public declaration gates, inherited clock/resource boundary, development preservation tools at fixed a08; later archive metadata separately pinned',
    documented_standards=['AGENTS.md','docs/agents/domain.md','docs/agents/issue-tracker.md','GLOSSARY.md','docs/adr/0003-complete-facility-mainline.md','.scratch/full-facility-mainline/spec.md','docs/mainline/26-online-policy-bridge-plan.md'],
    smell_baseline='Fowler judgement heuristics, repository overrides, skip tooling-enforced issues; no actionable new smell',
    checks=len(checks),exports=len(manifest['files']),prior_review_files_preserved=len(prior),hard_findings=[],heuristic_findings=[],unresolved=[],
    new_project_calls=0,tests_run=0,selectors_run=0,assessments_run=0,inference_calls=0,simulation_calls=0,formal_capture=False,ticket_acceptance=False,
    limits=['Static review only; saved development logs are not a reviewer rerun or scientific gain','New archive/package metadata after a08 requires a distinct fixed supplement','Final frozen protocol, root integrated verification and publication remain pending'])
write('review.json',encoded(review))
members={p.relative_to(OUT).as_posix():dict(sha256=digest(p.read_bytes()),bytes=p.stat().st_size) for p in sorted(OUT.rglob('*')) if p.is_file()}
write('delivery-manifest.json',encoded(dict(schema='aegisdc-static-review-delivery-manifest-v1',source=SOURCE,artifacts=members,terminal_receipt='delivery-manifest.json',excluded_runtime_caches=True,new_project_calls=0)))
for name,identity in members.items():assert digest((OUT/name).read_bytes())==identity['sha256']
print(json.dumps(dict(status='PASS',checks=len(checks),exports=len(manifest['files']),prior_review_files=len(prior),new_project_calls=0,report_sha256=digest((OUT/'report.md').read_bytes()),review_sha256=digest((OUT/'review.json').read_bytes()))))
