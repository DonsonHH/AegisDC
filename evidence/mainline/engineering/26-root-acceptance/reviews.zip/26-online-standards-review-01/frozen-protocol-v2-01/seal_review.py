"""V2 static supplement: Git/AST/JSON/hashes only, zero project calls."""
import ast
from copy import deepcopy
from hashlib import sha256
import json
from pathlib import Path
import subprocess

OUT=Path(__file__).resolve().parent
REPO=Path('C:/Users/Donson/.codex/worktrees/mainline23-intervention/Renly')
BASE='93b7ad992fe233068521c10decc3c85756c806d1'
SOURCE='35193647091f90d17c339976ae47ef69385e9a43'
RUNTIME='a08dc371f85570f20ce486401f1427ade0a76a3a'
PREFIX='evidence/mainline/engineering/26-candidate'
checks=[]
def check(name,ok):
    checks.append(dict(name=name,passed=bool(ok)))
    if not ok:raise AssertionError(name)
def digest(raw):return sha256(raw).hexdigest()
def read(path):return json.loads(path.read_bytes())
def text(name):return (OUT/'export'/name).read_text(encoding='utf-8')
def encode(v):return (json.dumps(v,ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode()
def write(name,raw):
    with (OUT/name).open('xb') as stream:stream.write(raw)
def git(*args):return subprocess.check_output(['git',*args],cwd=REPO)
def functions(source):return {n.name:n for n in ast.parse(source).body if isinstance(n,ast.FunctionDef)}
def app_imports(node):
    imports=[n for n in ast.walk(node) if isinstance(n,(ast.Import,ast.ImportFrom))]
    return [n for n in imports if (getattr(n,'module','') or '').startswith('aegis_dc') or any(a.name.startswith('aegis_dc') for a in getattr(n,'names',[]))]
def tree(revision,*paths):
    return {r.split('\t',1)[1]:r.split()[2] for r in git('ls-tree','-r',revision,'--',*paths).decode().splitlines()}

pins=read(OUT/'source-manifest.json');before=read(OUT/'prior-reviews-before.json')
check('fixed supplement source/base',pins['source']==SOURCE and pins['base']==BASE)
check('nonempty reviewed diff',bool((OUT/'candidate.diff').read_bytes()))
check('all runtime identical to accepted D core',not git('diff','--name-only',RUNTIME,SOURCE,'--','src').strip())
for name,expected in before.items():check('prior review preserved '+name,digest((OUT.parent/name).read_bytes())==expected)
keys=[SOURCE+':'+n for n in pins['files']]
old_manifest_name=PREFIX+'/pre-capture-v1-preservation/manifest.json'
keys.append('35d3169b3aa8857c9812558a81789114d1d2e6ba:'+old_manifest_name)
batch=subprocess.check_output(['git','cat-file','--batch'],cwd=REPO,input=''.join(k+'\n' for k in keys).encode())
offset=0;blobs={}
for key in keys:
    end=batch.index(b'\n',offset);header=batch[offset:end].split();assert len(header)==3 and header[1]==b'blob'
    start=end+1;size=int(header[2]);blobs[key]=batch[start:start+size];offset=start+size+1
check('all fixed exports batched',offset==len(batch))
for name,identity in pins['files'].items():
    raw=(OUT/'export'/name).read_bytes()
    check('exact export '+name,raw==blobs[SOURCE+':'+name] and digest(raw)==identity['sha256'] and len(raw)==identity['bytes'])
    if name.endswith('.py'):ast.parse(raw.decode(),filename=name);check('parse AST '+name,True)

preservation=read(OUT/'export'/old_manifest_name)
check('original frozen93 unexecuted explicitly retained',preservation['source']==BASE and preservation['executed_selector_calls']==preservation['executed_physical_calls']==0)
for name,identity in preservation['files'].items():
    raw=(OUT/'export'/PREFIX/'pre-capture-v1-preservation'/name).read_bytes()
    original=(OUT.parent/'frozen-protocol-01/export'/name).read_bytes()
    check('original93 exact preserved '+name,raw==original and digest(raw)==identity['sha256'] and len(raw)==identity['bytes'])
check('original93 frozen protocol root unchanged',(OUT/'export/docs/mainline/26-candidate-engineering-protocol.json').read_bytes()==(OUT.parent/'frozen-protocol-01/export/docs/mainline/26-candidate-engineering-protocol.json').read_bytes())
old_review=read(OUT.parent/'frozen-protocol-01/review.json')
check('original finding remains CHANGES_REQUIRED record',old_review['status']=='CHANGES_REQUIRED' and old_review['unresolved']==['STD-D-FROZEN-01'])

protocol=read(OUT/'export/docs/mainline/26-candidate-engineering-protocol-v2.json')
v1=read(OUT/'export/docs/mainline/26-candidate-engineering-protocol.json')
check('explicit frozen v2 identity',protocol['schema']=='aegisdc-candidate-engineering-protocol-v2' and protocol['status']=='FROZEN_ON_COMMIT_BEFORE_CAPTURE')
check('unexecuted prior revision recorded',protocol['revision_of']==dict(source=BASE,protocol='docs/mainline/26-candidate-engineering-protocol.json',executed_selector_calls=0,executed_physical_calls=0))
check('new output02 explicitly declared',protocol['output_directory']==PREFIX+'/capture-20261107-02')
normalized=deepcopy(protocol)
for key in ('revision_of','correction_record','output_directory'):normalized.pop(key)
normalized['schema']=v1['schema'];normalized['contracts'].remove('docs/mainline/26-pre-capture-tool-correction-01.md')
pending=next(c for c in normalized['pure_cases'] if c['id']=='pending-issued-inspection')
check('pending expected selection now null',pending['expected']['chosen'] is None)
pending['expected']['chosen']='first-action'
check('only protocol expectation changed pending selection',normalized==v1)
check('finite budgets exactly retained',len(protocol['pure_cases'])==protocol['pure_selector_calls']==10 and len(protocol['physical_cases'])==protocol['physical_runs']==6 and protocol['total_simulated_duration_s']==36 and protocol['scheduled_online_decision_calls']==21)
check('new protocol does not claim gain or acceptance',protocol['registered_research_trials']==protocol['llm_calls']==protocol['training_calls']==0 and protocol['field_calibration']=='PENDING')
old_inputs=tree(BASE,PREFIX+'/reference',PREFIX+'/oracles');new_inputs=tree(SOURCE,PREFIX+'/reference',PREFIX+'/oracles')
check('16 reference inputs and5 oracle exact Git blobs unchanged',old_inputs==new_inputs and sum('/reference/' in n for n in old_inputs)==16 and sum('/oracles/' in n for n in old_inputs)==5)
references={c['id']:read(OUT.parent/'frozen-protocol-01/export'/c['input']) for c in protocol['pure_cases']+protocol['physical_cases']}
for pair_name in ('same_public_pair','same_exact_pair','same_online_pair'):
    documents=deepcopy([references[n] for n in protocol[pair_name]])
    for document in documents:document.get('dispatch_program',document)['policy_program'].pop('policy')
    check('same paired declarations '+pair_name,documents[0]==documents[1])
pending_input=references['pending-issued-inspection'];candidates={c['id']:c for c in pending_input['policy_program']['candidates']}
issued=pending_input['history']['issued'];interfaces={i['id']:i for i in pending_input['frame']['nominal_knowledge']['work_interfaces']}
def resources(candidate):
    task=candidate['task'];return {r['worker_id'] for r in task['crew']}|set(interfaces[task['work_interface_id']]['tool_ids'])
occupied=set().union(*(resources(candidates[r['candidate_id']]) for r in issued))
check('pending input retains unresolved actual resource occupancy',bool(issued) and not pending_input['history']['work_feedback'] and bool(resources(candidates['first-action'])&occupied))
check('no fake pending termination or changed world',new_inputs==old_inputs)

source=text('scripts/candidate_delivery.py');prep=text('scripts/prepare_candidate_inputs.py');helper=text('scripts/inspection_delivery.py')
fs=functions(source);old_source=(OUT.parent/'frozen-protocol-01/export/scripts/candidate_delivery.py').read_text(encoding='utf-8');old_fs=functions(old_source)
decision=ast.get_source_segment(source,fs['check_decision']);capture=ast.get_source_segment(source,fs['capture']);verify=ast.get_source_segment(source,fs['verify']);pin_source=ast.get_source_segment(source,fs['pins'])
check('v2 tool protocol constant active',"PROTOCOL = 'docs/mainline/26-candidate-engineering-protocol-v2.json'" in source and "PROTOCOL = 'docs/mainline/26-candidate-engineering-protocol-v2.json'" in prep)
check('quantitative expectations trigger exact audit coverage',"quantitative = {'exact_current', 'positive', 'negative', 'projected_positive', 'original_positive'} & set(expected)" in decision)
check('required cross product from declared IDs',"required_pairs = {(belief['id'], value['id']) for belief in belief_variants for value in local['variants']}" in decision)
check('coverage list type length and exact ID set',"type(comparisons) is list and len(comparisons) == len(required_pairs)" in decision and "{(row['belief_variant_id'], row['value_variant_id']) for row in comparisons} == required_pairs" in decision)
check('coverage before any branch literal checks',decision.index('Compatibility audit must cover every declared belief/value variant exactly once')<decision.index('for item in comparisons:'))
check('exact_current robust to comparison row order',"item['belief_variant_id'] == belief_variants[0]['id']" in decision)
for expected_key in ('projected_positive','original_positive'):
    check('independent literal still checked '+expected_key,"expected["+repr(expected_key)+"]" in decision)
check('both branch literal expectations remain',"for branch in ('positive', 'negative'):" in decision and "== expected[branch]" in decision)
check('common exact current mass complete belief ID set',"set(choice['valuation_current_outcome_mass_by_belief_variant']) == {" in decision and "row['id'] for row in document['policy_program']['options']['belief_model']['variants']" in decision)
check('common exact values then checked','for value in\n            choice[\'valuation_current_outcome_mass_by_belief_variant\'].values()' in decision)
check('missing source file OS and Git errors caught in finally','except (OSError, subprocess.SubprocessError) as error:' in capture and "receipt['source_head_and_bytes_unchanged'] = False" in capture)
check('source guard error retained without overwriting original error',"receipt['source_guard_error'] = dict(error_type=type(error).__name__, error=str(error))" in capture and "receipt.setdefault('source_guard_error', 'Source changed during capture')" in capture)
check('source mismatch always FAIL before terminal write',capture.index("receipt.update(status='FAIL', failures=1)\n")<capture.index("write(folder / protocol['terminal_receipt'], receipt)"))
check('per-call STARTED journal fsync retained',ast.dump(fs['append'])==ast.dump(old_fs['append']) and 'os.fsync(stream.fileno())' in source)
check('exact durable declaration unchanged',ast.dump(fs['declared'])==ast.dump(old_fs['declared']))
check('saved-only verification function unchanged',ast.dump(fs['verify'])==ast.dump(old_fs['verify']))
check('physical saved checks and deterministic figures unchanged',ast.dump(fs['check_physical'])==ast.dump(old_fs['check_physical']) and ast.dump(fs['figures'])==ast.dump(old_fs['figures']))
check('old preservation now full historical pin role',"PACKAGE + '/pre-capture-v1-preservation/'" in pin_source)
check('all3 tools pinned including preparation',"[protocol['authoring_tool'], protocol['helper_tool'], protocol['input_preparation_tool']]" in pin_source)
check('runtime/input/history separation retained',all(n in pin_source for n in ('runtime=','tools=tools','inputs=inputs','historical_development=')))
check('cache exclusions remain exact',"'__pycache__' not in name and not name.endswith(('.pyc', '.pyo'))" in pin_source and "'__pycache__' not in p.parts and p.suffix not in {'.pyc','.pyo'}" in helper)
check('no same-output retry',"folder.mkdir(exist_ok=False)" in capture and 'No automatic retry or overwriting' in protocol['retry_rule'])
check('per-case source guard and terminal guard both retained',"'Source changed before case'" in capture and "finally:" in capture)
check('verify clean checkout exact committed delivery',"Committed delivery blob differs" in verify and "identities == hashes(delivery, identities)" in verify)
check('verify original execution revision and runtime','Actual execution source differs' in verify and 'Actual runtime files differ from source guard' in verify)
check('verify exact case and attempt accounting','Selector attempt budget differs' in verify and 'Physical attempt budget differs' in verify and 'Attempt/source order differs' in verify)
declared=set(protocol['durable_root'])|{c['id']+'/'+n for c in protocol['pure_cases'] for n in protocol['durable_pure']}|{c['id']+'/'+n for c in protocol['physical_cases'] for n in protocol['durable_physical']}
check('50 outputs plus1 terminal unchanged',len(declared)==50 and protocol['terminal_receipt']=='receipt.json')

all_functions={**functions(helper),**fs};pending_names=['verify'];reachable=set()
while pending_names:
    name=pending_names.pop()
    if name in reachable:continue
    reachable.add(name);node=all_functions[name]
    check('saved mode no application imports '+name,not app_imports(node))
    for call in (n for n in ast.walk(node) if isinstance(n,ast.Call) and isinstance(n.func,ast.Name)):
        if call.func.id in all_functions and call.func.id not in reachable:pending_names.append(call.func.id)
check('saved mode cannot call capture or old22 snapshots','capture' not in reachable and 'snapshots' not in reachable)
check('same forecast versus measured-data figure labels','These bars are not measured plant outcomes.' in source and "trace = rows(folder / identifier / 'private-state.jsonl')" in source)

# Derive declared role membership from fixed Git paths, without calling the project pins function.
names=git('ls-tree','-rz','--name-only',SOURCE,'src','tests','configs',PREFIX,'evidence/mainline/engineering/18-beliefs/capture-01','evidence/mainline/engineering/23-interventions/reference').decode().strip('\0').split('\0')
names=[n for n in names if '__pycache__' not in n and not n.endswith(('.pyc','.pyo'))]
roles=dict(runtime=sorted(n for n in names if n.startswith('src/') and n.endswith('.py')),
    tools=[protocol['authoring_tool'],protocol['helper_tool'],protocol['input_preparation_tool']],
    inputs=sorted(set(['docs/mainline/26-candidate-engineering-protocol-v2.json',*protocol['contracts'],
        *[n for n in names if n.startswith(('tests/','configs/full-facility','configs/materials/',PREFIX+'/development/',PREFIX+'/reference/',PREFIX+'/oracles/','evidence/mainline/engineering/18-beliefs/capture-01/','evidence/mainline/engineering/23-interventions/reference/'))],PREFIX+'/.gitattributes'])),
    historical_development=sorted(n for n in names if n.startswith((PREFIX+'/development-originals-',PREFIX+'/pre-capture-v1-preservation/'))))
check('all runtime paths represented',set(roles['runtime'])==set(tree(SOURCE,'src')))
check('preserved V1 three originals plus manifest pinned',len([n for n in roles['historical_development'] if '/pre-capture-v1-preservation/' in n])==4)
check('16 inputs5 oracles all in guarded inputs',set(old_inputs)<=set(roles['inputs']))
check('V2 protocol and correction contract guarded','docs/mainline/26-candidate-engineering-protocol-v2.json' in roles['inputs'] and 'docs/mainline/26-pre-capture-tool-correction-01.md' in roles['inputs'])
write('declared-role-paths.json',encode(dict(source=SOURCE,roles=roles,counts={k:len(v) for k,v in roles.items()},new_project_calls=0)))

saved=read(OUT/'export'/PREFIX/'pre-capture-v2-tool-checks.json')
check('saved author tool checks pin current tool',saved['source_tool_sha256']==digest((OUT/'export/scripts/candidate_delivery.py').read_bytes()))
check('saved7 tool probes PASS1 positive6 negative',saved['status']=='PASS' and len(saved['results'])==7 and all(r['pass'] is True for r in saved['results']) and sum(r.get('result')=='ACCEPTED' for r in saved['results'])==1)
check('saved tool checks contain no selector or plant calls',saved['new_selector_calls']==saved['new_plant_calls']==saved['new_full_regressions']==saved['registered_research_trials']==0)
check('saved negative terminal preservation proofs',all(next(r for r in saved['results'] if r['mutation']==name)['terminal_status']=='FAIL' for name in ('source-mismatch','missing-pinned-file')))
native=read(OUT/'export'/PREFIX/'pre-capture-v2-format-classification.json')
raw=(OUT/'export'/old_manifest_name).read_bytes()
check('35d original20CRLF bytes not rewritten',raw==blobs['35d3169b3aa8857c9812558a81789114d1d2e6ba:'+old_manifest_name] and digest(raw)==native['sha256'])
crlf=[i for i,line in enumerate(raw.splitlines(keepends=True),1) if line.endswith(b'\r\n')]
check('exact CRLF line numbers classified',crlf==native['line_numbers'] and len(crlf)==native['crlf_lines']==20)
attrs=text(PREFIX+'/.gitattributes');old_attrs=(OUT.parent/'export'/PREFIX/'.gitattributes').read_text(encoding='utf-8')
added=attrs[len(old_attrs):]
check('attributes original rules untouched',attrs.startswith(old_attrs))
check('only exact preservation manifest added CR recognition',[n for n in added.splitlines() if n and not n.startswith('#')]==['pre-capture-v1-preservation/manifest.json -text whitespace=blank-at-eol,blank-at-eof,space-before-tab,cr-at-eol'])
diffcheck=subprocess.run(['git','diff','--check',BASE+'...'+SOURCE],cwd=REPO,capture_output=True)
check('full fixed range diff check PASS without path skipping',diffcheck.returncode==0 and not diffcheck.stdout and not diffcheck.stderr)
write('diff-check.json',encode(dict(command=['git','diff','--check',BASE+'...'+SOURCE],exit_code=diffcheck.returncode,stdout=diffcheck.stdout.decode(),stderr=diffcheck.stderr.decode(),new_project_calls=0)))
correction=text('docs/mainline/26-pre-capture-tool-correction-01.md')
check('old failures and three corrections described','三处P2' in correction and '原审阅和原版本保留' in correction and '16个输入' in correction)
after={p.relative_to(OUT.parent).as_posix():digest(p.read_bytes()) for p in sorted(OUT.parent.rglob('*')) if p.is_file() and OUT not in p.parents}
check('all previous core archive v1 review files unchanged',before==after)
write('prior-reviews-after.json',encode(after));write('checks.json',encode(checks))
report='''Standards补充：PASS（93b7ad99…35193647，运行源码仍为a08）。\n\n原STD-D-FROZEN-01已关闭：兼容性审计须以声明belief×value ID集合及等长约束完整、无重复覆盖后，核对分支字面概率；common_exact变体集合也闭合。源码缺文件/Git错误在finally转为FAIL并保留终态。pending案例只纠正选择为null，原输入和占用约束保留。\n\nV1三件工具/协议与原发现原样保存；V2新源/输出02、10次纯选择＋6×6秒＋21在线决策、16输入及5见证未变。完整pin角色、50输出＋终态、源守卫和保存verify边界保留。保存工具检查为7例（1正向＋6负向），非本审阅执行。20行CRLF原件未改，仅指定路径识别；全差异检查通过。无新增硬标准/启发性问题。新增项目调用0；正式捕获、根验收及第26项接受仍待完成。\n'''
write('report.md',report.encode('utf-8'))
review=dict(schema='aegisdc-independent-standards-review-v1',axis='Standards',status='PASS',base=BASE,source=SOURCE,runtime_unchanged=RUNTIME,
    scope='Pre-capture V2 tool/protocol corrections, full static source/pin/durable/saved-mode boundaries and exact unexecutedV1 preservation',
    checks=len(checks),exports=len(pins['files']),resolved_findings=['STD-D-FROZEN-01'],hard_findings=[],heuristic_findings=[],unresolved=[],
    pure_cases=10,physical_cases=6,declared_physical_duration_s=36,scheduled_online_decisions=21,unchanged_reference_inputs=16,unchanged_oracles=5,
    declared_role_counts={k:len(v) for k,v in roles.items()},durable_outputs=50,terminal_receipts=1,prior_review_files_preserved=len(before),
    saved_tool_checks=dict(total=7,positive=1,negative=6,not_rerun_by_reviewer=True),
    preserved_failed_diff_check_source='35d3169b3aa8857c9812558a81789114d1d2e6ba',native_crlf_lines=20,
    new_project_calls=0,tests_run=0,selectors_run=0,assessments_run=0,inference_calls=0,simulation_calls=0,formal_capture=False,ticket_acceptance=False,
    limits=['Static-only conclusions; no project/tool preflight or application calls','Launch command/interpreter flags and isolated pycache are root execution records, not inferred from sys.argv','Formal capture saved outcomes, rendered figures, fresh delivery and root acceptance remain pending'])
write('review.json',encode(review))
artifacts={p.relative_to(OUT).as_posix():dict(sha256=digest(p.read_bytes()),bytes=p.stat().st_size) for p in sorted(OUT.rglob('*')) if p.is_file()}
write('delivery-manifest.json',encode(dict(schema='aegisdc-static-review-delivery-manifest-v1',source=SOURCE,artifacts=artifacts,terminal_receipt='delivery-manifest.json',new_project_calls=0)))
print(json.dumps(dict(status='PASS',checks=len(checks),new_project_calls=0,role_counts={k:len(v) for k,v in roles.items()},report_sha256=digest((OUT/'report.md').read_bytes()),review_sha256=digest((OUT/'review.json').read_bytes()))))
