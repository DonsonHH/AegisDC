"""Pure static review of copied root packet tools, no imports of those tools."""
import ast
from hashlib import sha256
import json
from pathlib import Path

OUT=Path(__file__).resolve().parent
FOLDER=OUT/'root-tools-revision-02'
checks=[]
def check(name,ok):
    checks.append(dict(name=name,passed=bool(ok)))
    if not ok:raise AssertionError(name)
def write(name,value):
    with (OUT/name).open('x',encoding='utf-8',newline='\n') as stream:json.dump(value,stream,ensure_ascii=False,indent=2)
sources={name:(FOLDER/name).read_text(encoding='utf-8') for name in ('build_26_root_packet.py','26-verify_packet.py','run_26_root_acceptance.py')}
for name,source in sources.items():ast.parse(source,filename=name);check('copied root tool AST '+name,True)
b=sources['build_26_root_packet.py'];v=sources['26-verify_packet.py'];r=sources['run_26_root_acceptance.py']
manifest=json.loads((FOLDER/'manifest.json').read_bytes())
for name,item in manifest.items():check('root tool fixed-copy hash '+name,sha256((FOLDER/name).read_bytes()).hexdigest()==item['sha256'])
check('builder accepts clean actual integration source',"['git', 'rev-parse', 'HEAD']" in b and "['git', 'status', '--porcelain']" in b)
check('builder requires full gate zero skipfailerror',"tests['skipped'] == tests['failures'] == tests['errors'] == 0" in b and "tests['executed'] == tests['run'] > 538" in b)
check('builder root source guard source and byte unchanged',"guard['source_commit_before'] == guard['source_commit_after'] == source" in b and "guard['head_unchanged'] and guard['sources_unchanged']" in b)
check('builder checks formal capture10/6/36 not repeated',"saved['pure_attempts'] == saved['pure_completed'] == 10" in b and "saved['physical_attempts'] == saved['physical_completed'] == 6" in b and "saved['simulated_duration_attempted_s'] == 36" in b)
check('builder exact3 root visual review count',"visual_qa['actually_viewed_pngs'] == 3" in b and "visual_qa['open_findings'] == 0" in b)
check('beforefresh authority only pending',b.count("status='CANDIDATE_PENDING_FRESH_DELIVERY'")==2 and 'FRESH_COMMITTED_DELIVERY_VERIFICATION_BEFORE_RESOLVING26' in b)
check('builder does not resolve tickets',not any(t in b for t in ('**Status:** resolved','update_goal(','git push','git merge')))
check('builder preserves exact bytes and excludes runtime caches',"target.write_bytes(path.read_bytes())" in b and "'__pycache__' not in path.parts" in b and "path.suffix not in {'.pyc', '.pyo'}" in b)
check('root logs CRLF exception restricted raw actual path',"name.startswith('raw/') and b'\\r\\n' in path.read_bytes()" in b and "whitespace=blank-at-eol,blank-at-eof,space-before-tab,cr-at-eol" in b)
check('builder unique packet/archive output',"assert not packet.exists()" in b and "zipfile.ZipFile(packet / name, 'x'" in b)
check('root fixture archive separately labelled','SEPARATE_ENGINEERING_TEST_FIXTURES_NOT_FORMAL_CAPTURE_BUDGET' in b)
check('first rootfull observed not accepted','TWO_ROOT_FULL_ATTEMPTS_WITH_ONE_INTERRUPTED_AND_ONE_COMPLETED' in b and 'root_full_pass_proven=False' in b)
check('first and second disjoint case identity sets',"new_cases = regression_cases - old_cases" in b and "not old_cases & new_cases" in b)
check('second rootfull terminal checked before packet',"pass_terminal['status'] == 'COMPLETED' and pass_terminal['returncode'] == 0" in b)
check('builder actually preserves case run input identity',"read(folder / 'dispatch-program.json') == result['inputs']['dispatch_program']" in b)
check('root metadata active and field pending',"field_calibration='PENDING', overall_goal='ACTIVE'" in b)
check('verifier committed clean exact delivery',"git(root, 'rev-parse', 'HEAD').decode().strip() == delivery and not git(root, 'status', '--porcelain')" in v)
check('verifier exact durable set no arbitrary hash skipping',"actual == set(declaration['artifacts']) | {'receipt.json'}" in v and "set(receipt['artifacts']) == set(declaration['artifacts'])" in v and 'Root artifact differs:' in v)
check('all root packet committed blobs checked',"blobs(root, delivery, [PACKET + '/' + name for name in actual])" in v)
check('root ZIP member unique exact set',"len(archive.namelist()) == len(set(archive.namelist()))" in v and "set(archive.namelist()) == set(members)" in v)
check('ZIP paths safe no cache',"not path.is_absolute() and '..' not in path.parts" in v and "path.suffix not in {'.pyc', '.pyo'}" in v)
check('ZIP exact sha and size',"digest(raw) == expected['sha256'] and len(raw) == expected['bytes']" in v)
check('root tested/delivery guard all blobs',"identities == blobs(root, source, identities) == blobs(root, delivery, identities)" in v)
check('CRLF checkout exact reconstruction only',"name in CHECKOUT_CRLF and b'\\r' not in original and raw == original.replace(b'\\n', b'\\r\\n')" in v)
check('original author data commit and execution bound',"saved['execution_commit'] == author['execution']" in v and "blobs(root, author['data_delivery'], names)" in v)
check('authority correction both author revisions',"gate['author_source'] == author['execution'] and gate['author_data_delivery'] == author['data_delivery']" in v)
check('original first source/terminal no false completion',"not lifecycle['first']['root_full_pass_proven']" in v and "not lifecycle['first']['original_terminal_exists']" in v)
check('root original archive all cases attributed',"record['root_full_attempt'] == ('01_INTERRUPTED' if record['case'] in old_cases else '02_COMPLETED')" in v)
check('D historical gap and unknown remain explicit',"development_check['unobserved_outcomes'] == 1" in v and "development_check['historical_input_or_tool_gap_cases'] == 26" in v)
check('visuals original source and rendered png hashes bound',"identity['png_sha256']" in v and "identity['svg_sha256']" in v)
check('oldpremeeting tag preserved',"076d9aa15c5bc99a5b7985f296e15543b7b0f3d7" in v)
check('saved root verifier no new selector/plant',"new_selector_calls=0, new_physical_runs=0" in v and 'simulate_scenario(' not in v and 'choose_work(' not in v)
check('root runner source pins before actual acceptance',r.index('before = identities()')<r.index('result = verify(ROOT, output)'))
check('root runner sourcepins after actual acceptance',r.index('result = verify(ROOT, output)')<r.index('after = identities()'))
check('root runner exact four checkout CRLF allowed only',"CHECKOUT_CRLF = {'configs/candidate-example.json', 'configs/demo.json'," in r and "assert b'\\r' not in blob and checkout_bytes == blob.replace(b'\\n', b'\\r\\n')" in r)
check('root runner unique runs output no overwrite',"output.parent == ROOT / 'runs' and not output.exists()" in r)
check('root runner separate integrated gate not effect','Integrated engineering and historical evidence checks; no registered research, training or LLM experiment.' in r)
check('unfixed runtime binding exists in original rev02',"guard['actual_sources'][name]" not in v and "run['code_identity']['files']" not in v and "guard['actual_sources'][name]" not in b)
write('root-revision02-checks.json',checks)
write('root-revision02-review.json',dict(status='CHANGES_REQUIRED',scope='Copied root packet draft revision02 only',checks=len(checks),unresolved=['STD-ROOT-RUNTIME-01'],new_project_calls=0,requires_followup_fixed_copy=True))
print(json.dumps(dict(status='CHANGES_REQUIRED',checks=len(checks),finding='STD-ROOT-RUNTIME-01',new_project_calls=0)))
