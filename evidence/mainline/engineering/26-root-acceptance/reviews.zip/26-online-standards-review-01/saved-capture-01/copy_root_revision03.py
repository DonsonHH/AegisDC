"""Pin the root runtime-byte-chain correction; never execute root tools."""
from hashlib import sha256
import difflib
import json
from pathlib import Path
OUT=Path(__file__).resolve().parent
ROOT=Path('C:/Users/Donson/Documents/ChatGPT/Renly/.work')
folder=OUT/'root-tools-revision-03';folder.mkdir(exist_ok=False)
expected={'build_26_root_packet.py':'27b30c7d4179aa1cc19ef6910a0b8866a880c5a15f28231276803e33a09df5e4',
    '26-verify_packet.py':'d47266d24d7b67373a39ef394712e76d0437daea3e0fd3fab6edfabcea71fc06'}
copies={}
for name in (*expected,'26-root-bytechain-correction-01.json'):
    raw=(ROOT/name).read_bytes()
    if name in expected:assert sha256(raw).hexdigest()==expected[name]
    with (folder/name).open('xb') as stream:stream.write(raw)
    copies[name]=dict(sha256=sha256(raw).hexdigest(),bytes=len(raw))
    if name in expected:
        old=(OUT/'root-tools-revision-02'/name).read_text(encoding='utf-8');new=raw.decode('utf-8')
        diff=''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='rev02-fixed',tofile='bytechain-revision03'))
        with (folder/(name+'.diff')).open('x',encoding='utf-8',newline='\n') as stream:stream.write(diff)
with (folder/'manifest.json').open('x',encoding='utf-8') as stream:json.dump(copies,stream,indent=2)
print(json.dumps(copies))
