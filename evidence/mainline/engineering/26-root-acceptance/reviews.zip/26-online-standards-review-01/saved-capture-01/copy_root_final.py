"""Final root packet drafts pinned after both source-identity corrections."""
from hashlib import sha256
import difflib
import json
from pathlib import Path
OUT=Path(__file__).resolve().parent
ROOT=Path('C:/Users/Donson/Documents/ChatGPT/Renly/.work')
folder=OUT/'root-tools-final';folder.mkdir(exist_ok=False)
expected={'build_26_root_packet.py':'9ab3895d745345e85405cbf649765db86a015fa71ca69e34eacf8ebde52365b2',
    '26-verify_packet.py':'bb8747279163ce8cfcbca6efdf364b10c9911c47d4df42f7e5ab50a9abc0bf18'}
copies={}
for name in expected:
    raw=(ROOT/name).read_bytes();assert sha256(raw).hexdigest()==expected[name]
    with (folder/name).open('xb') as stream:stream.write(raw)
    copies[name]=dict(sha256=sha256(raw).hexdigest(),bytes=len(raw))
    old=(OUT/'root-tools-revision-04'/name).read_text(encoding='utf-8');new=raw.decode('utf-8')
    with (folder/(name+'.diff')).open('x',encoding='utf-8',newline='\n') as stream:stream.write(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='rev04-fixed',tofile='final-guard-chain-rev05')))
with (folder/'manifest.json').open('x',encoding='utf-8') as stream:json.dump(copies,stream,indent=2)
print(json.dumps(copies))
