"""Seal the saved-capture review and fixed final root-tool static supplement."""
import ast
from hashlib import sha256
import json
from pathlib import Path

OUT=Path(__file__).resolve().parent
checks=[]
def check(name,ok):
    checks.append(dict(name=name,passed=bool(ok)))
    if not ok:raise AssertionError(name)
def digest(raw):return sha256(raw).hexdigest()
def read(path):return json.loads(path.read_bytes())
def encode(v):return (json.dumps(v,ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode()
def write(name,raw):
    with (OUT/name).open('xb') as stream:stream.write(raw)

saved=read(OUT/'saved-review.json');prior=read(OUT/'prior-reviews-before.json')
check('saved351/53f independently PASS',saved['status']=='PASS' and saved['new_project_calls']==0 and saved['checks']==1235)
for name,expected in prior.items():check('earlier sealed review unchanged '+name,digest((OUT.parent/name).read_bytes())==expected)
pin=read(OUT/'root-tools-final/manifest.json')
b=(OUT/'root-tools-final/build_26_root_packet.py').read_text(encoding='utf-8')
v=(OUT/'root-tools-final/26-verify_packet.py').read_text(encoding='utf-8')
for name,item in pin.items():check('final root tool pin '+name,digest((OUT/'root-tools-final'/name).read_bytes())==item['sha256'])
for name,source in [('builder',b),('verifier',v)]:ast.parse(source);check('final '+name+' AST',True)
check('builder exact source snapshot set equals actual guard',"attempt['source_files'] == expected_runtime" in b and "guard['actual_sources'].items()" in b)
check('verifier exact source snapshot set equals actual guard',"attempt['source_files'] == expected_runtime" in v and "execution_guard['actual_sources'].items()" in v)
check('builder actual run36 source set equals runtime guard',"result['code_identity']['files'] == expected_run_identity" in b)
check('verifier actual run36 source set equals runtime guard',"run['code_identity']['files'] == expected_run_identity" in v)
check('final actual runtime bound to committed blob guard','expected_runtime ==' in b and 'committed_sources' in b and 'expected_runtime ==' in v and 'committed_sources' in v)
check('all sourceguard actual keys bound to committed set',"set(guard['actual_sources']) == set(identities)" in v)
check('original execution conversions require exact bytes and classification',"digest(original.replace(b'\\n', b'\\r\\n')) == guard['actual_sources'][name]" in v and "guard['checkout_classification'] == original_conversions" in v)
check('verifier root execution/delivery commit trees anchored',"identities == blobs(root, source, identities) == blobs(root, delivery, identities)" in v)
check('interrupted first-run snapshot kept exact full member set',"set(interrupted_archive.namelist()) == set(interrupted_members)" in b and "set(interrupted_archive.namelist()) == set(interrupted_members)" in v)
check('interrupted fixture exact byte identity in builder',"(regression / name.removeprefix('development/')).read_bytes() == original" in b)
check('interrupted fixture exact member hash size mapping verifier',"archive_members['root-regression-originals.zip'][current_name] == identity" in v)
check('original snapshot SHA and sizes verified',"digest(original) == identity['sha256'] and len(original) == identity['bytes']" in v)
check('original root attempt not relabeled success',"not lifecycle['first']['root_full_pass_proven']" in v and "not lifecycle['first']['summary_exists']" in v and "not lifecycle['first']['original_terminal_exists']" in v)
check('root attempt attribution is disjoint',"not old_cases & new_cases" in v and "'01_INTERRUPTED' if record['case'] in old_cases else '02_COMPLETED'" in v)
check('lifecycle original observation terminal execution source bound',"lifecycle['source'] == lifecycle['second']['source'] == manifest['tested_source']" in v and "observation['source'] == manifest['tested_source']" in v and "terminal['source'] == manifest['tested_source']" in v)
check('root fixtures have separate accounting','SEPARATE_ENGINEERING_TEST_FIXTURES_NOT_FORMAL_CAPTURE_BUDGET' in b and "finite_frozen_capture_repeated=False" in b)
check('author source and data authority correction retained',"gate['author_source'] == author['execution'] and gate['author_data_delivery'] == author['data_delivery']" in v)
check('pending fresh gate no premature resolution',"status='CANDIDATE_PENDING_FRESH_DELIVERY'" in b and 'FRESH_COMMITTED_DELIVERY_VERIFICATION_BEFORE_RESOLVING26' in b and '**Status:** resolved' not in b)
check('verifier clean committed checkout and exact allpacket blobs',"not git(root, 'status', '--porcelain')" in v and "blobs(root, delivery, [PACKET + '/' + name for name in actual])" in v)
check('ZIP no duplicate/member escape/cache',"len(archive.namelist()) == len(set(archive.namelist()))" in v and "not path.is_absolute() and '..' not in path.parts" in v and "path.suffix not in {'.pyc', '.pyo'}" in v)
check('declared artifacts exact no hash skipping',"actual == set(declaration['artifacts']) | {'receipt.json'}" in v and "set(receipt['artifacts']) == set(declaration['artifacts'])" in v)
check('only exact checkout CRLF recognized',"name in CHECKOUT_CRLF and b'\\r' not in original and raw == original.replace(b'\\n', b'\\r\\n')" in v)
check('saved root verification no application invocation','simulate_scenario(' not in v and 'choose_work(' not in v)
check('saved root verification modules use saved paths',"candidate_delivery.verify(capture" in v and "verify_candidate_development.verify(root" in v)
check('current saved project verify scripts unchanged execution351',saved['exact_role_counts']==dict(runtime=67,tools=3,inputs=175,historical_development=10))
check('root visual/formal source checks unchanged',"identity['png_sha256']" in v and "identity['svg_sha256']" in v)
check('developer gap/unknowns remain declared',"development_check['unobserved_outcomes'] == 1" in v and "development_check['historical_input_or_tool_gap_cases'] == 26" in v)
check('root source edits not science acceptance','field_calibration=\'PENDING\', overall_goal=\'ACTIVE\'' in v and 'full_regression_rerun=False' in v)
root_calls=[n for n in ast.walk(ast.parse(v)) if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id in {'capture','simulate_scenario','choose_work','assess_action_value'}]
check('no root capture selector or inference call AST',not root_calls)
old=read(OUT/'root-revision02-review.json')
check('oldP2 preserved as original finding',old['status']=='CHANGES_REQUIRED' and old['unresolved']==['STD-ROOT-RUNTIME-01'])
check('reported rootguard finding remediation explicit',read(OUT/'root-tool-findings-01.json')['findings'][0]['id']=='STD-ROOT-RUNTIME-01')
after={p.relative_to(OUT.parent).as_posix():digest(p.read_bytes()) for p in sorted(OUT.parent.rglob('*')) if p.is_file() and OUT not in p.parents}
check('all earlier sealed review set/hashes unchanged',after==prior)
write('prior-reviews-after.json',encode(after));write('final-checks.json',encode(checks))
report='''Standards保存复核：PASS（执行35193647，数据53f09ff4）。\n\n50件原件＋终态、32条尝试、10次独立选择＋6×6秒＋21在线决策及67/3/175/10来源角色相符。6份真实运行的36文件执行身份与Git一致；概率、当前时刻、服务/流量及缺失结果按冻结字面核对。原V1未执行、30开发目录、26缺口和46未知状态保留。\n\n根工具草稿的源码字节链P2已补：快照/执行文件集合绑定实际源守卫，再绑定提交；旧发现和副本保留。首次根回归中断及部分夹具单列，第二次须有真实终态，均不计入正式捕获预算。原中断ZIP与最终原件逐字节绑定。声明集合、缓存排除、CRLF、ZIP及全Git交付核对保留，正式接受仍受fresh gate约束。\n\n无剩余硬标准或启发性问题；新增项目调用0。三张PNG观看结论属于root已保存记录，本审阅核其来源哈希；未冒称重新观看。\n'''
write('report.md',report.encode('utf-8'))
review=dict(schema='aegisdc-independent-standards-review-v1',axis='Standards',status='PASS',execution=saved['execution'],data=saved['data'],
    scope='Fixed53f saved capture plus fixed final root packet builder/verifier and unchanged root runner static review; no project execution',
    checks=saved['checks']+44+len(checks),check_breakdown=dict(saved_originals=saved['checks'],root_revision02=44,final=len(checks)),
    exact_role_counts=saved['exact_role_counts'],artifacts=50,terminal_receipts=1,ledger_rows=32,pure_calls=10,physical_runs=6,simulated_duration_s=36,online_decisions=21,
    original_runtime_files_per_run=36,root_tool_pins=pin,resolved_findings=['STD-ROOT-RUNTIME-01'],hard_findings=[],heuristic_findings=[],unresolved=[],
    preserved_original_review_files=len(prior),historic_attempts=30,historical_gap_cases=26,historical_unknowns=1,
    root_visual_review_recorded=True,reviewer_images_viewed=False,new_project_calls=0,tests_run=0,selectors_run=0,assessments_run=0,inference_calls=0,simulation_calls=0,
    formal_capture_rerun=False,full_regression_rerun=False,ticket_acceptance=False,
    limits=['Root full lifecycle tools reviewed statically; actual completed terminal/root packet/fresh checkout need their later evidence','First interrupted rootfull is not PASS and partial calls remain separate accounting','No new physical or selector calls; actual root visual review record hash-checked only'])
write('review.json',encode(review))
artifacts={p.relative_to(OUT).as_posix():dict(sha256=digest(p.read_bytes()),bytes=p.stat().st_size) for p in sorted(OUT.rglob('*')) if p.is_file() and '__pycache__' not in p.parts and p.suffix not in {'.pyc','.pyo'}}
write('delivery-manifest.json',encode(dict(schema='aegisdc-static-review-delivery-manifest-v1',execution=saved['execution'],data=saved['data'],artifacts=artifacts,terminal_receipt='delivery-manifest.json',new_project_calls=0)))
print(json.dumps(dict(status='PASS',checks=review['checks'],new_project_calls=0,report_sha256=digest((OUT/'report.md').read_bytes()),review_sha256=digest((OUT/'review.json').read_bytes()),manifest_sha256=digest((OUT/'delivery-manifest.json').read_bytes()))))
