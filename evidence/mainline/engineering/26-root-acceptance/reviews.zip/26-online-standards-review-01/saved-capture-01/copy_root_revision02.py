"""Pin second root packet lifecycle correction without executing it."""
from hashlib import sha256
import difflib
import json
from pathlib import Path
OUT=Path(__file__).resolve().parent
ROOT=Path('C:/Users/Donson/Documents/ChatGPT/Renly/.work')
folder=OUT/'root-tools-revision-02';folder.mkdir(exist_ok=False)
copies={}
for name in ('build_26_root_packet.py','26-verify_packet.py','run_26_root_acceptance.py'):
    raw=(ROOT/name).read_bytes()
    with (folder/name).open('xb') as stream:stream.write(raw)
    copies[name]=dict(sha256=sha256(raw).hexdigest(),bytes=len(raw))
    old=(OUT/'root-tools'/name).read_text(encoding='utf-8');new=raw.decode('utf-8')
    with (folder/(name+'.diff')).open('x',encoding='utf-8',newline='\n') as stream:
        stream.write(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='first-fixed',tofile='lifecycle-revision02')))
with (folder/'manifest.json').open('x',encoding='utf-8') as stream:json.dump(copies,stream,indent=2)
print(json.dumps(copies))
