"""Export fixed execution/delivery blobs and copy proposed root tools; never run them."""
from hashlib import sha256
import json
from pathlib import Path
import subprocess
OUT=Path(__file__).resolve().parent
REPO=Path('C:/Users/Donson/.codex/worktrees/mainline23-intervention/Renly')
ROOT=Path('C:/Users/Donson/Documents/ChatGPT/Renly')
EXECUTION='35193647091f90d17c339976ae47ef69385e9a43'
DATA='53f09ff4e232ebfac6b64bd6e15bb8649146810b'
CAPTURE='evidence/mainline/engineering/26-candidate/capture-20261107-02'
def git(*args):return subprocess.check_output(['git',*args],cwd=REPO)
def digest(raw):return sha256(raw).hexdigest()
def encode(v):return (json.dumps(v,ensure_ascii=False,indent=2)+'\n').encode()
def write(name,raw):
    path=OUT/name;path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('xb') as stream:stream.write(raw)
before={p.relative_to(OUT.parent).as_posix():digest(p.read_bytes()) for p in sorted(OUT.parent.rglob('*')) if p.is_file() and OUT not in p.parents}
write('prior-reviews-before.json',encode(before))
receipt=json.loads(git('cat-file','blob',DATA+':'+CAPTURE+'/receipt.json'))
roles=receipt['pinned'];source_paths=sorted({n for group in roles.values() for n in group})
capture_paths=git('ls-tree','-r','--name-only',DATA,'--',CAPTURE).decode().splitlines()
keys=[EXECUTION+':'+n for n in source_paths]+[DATA+':'+n for n in source_paths+capture_paths]
raw=subprocess.check_output(['git','cat-file','--batch'],cwd=REPO,input=''.join(k+'\n' for k in keys).encode())
offset=0;blobs={};ids={}
for key in keys:
    end=raw.index(b'\n',offset);header=raw[offset:end].split();assert len(header)==3 and header[1]==b'blob',key
    start=end+1;size=int(header[2]);blobs[key]=raw[start:start+size];ids[key]=header[0].decode();offset=start+size+1
assert offset==len(raw)
files={}
for name in source_paths:
    original=blobs[EXECUTION+':'+name];delivered=blobs[DATA+':'+name];assert original==delivered,name
    write('execution-export/'+name,original)
    files[name]=dict(sha256=digest(original),bytes=len(original),execution_blob=ids[EXECUTION+':'+name],data_blob=ids[DATA+':'+name])
outputs={}
for name in capture_paths:
    data=blobs[DATA+':'+name];write('data-export/'+name,data)
    outputs[name]=dict(sha256=digest(data),bytes=len(data),git_blob=ids[DATA+':'+name])
write('source-manifest.json',encode(dict(execution=EXECUTION,data=DATA,roles=roles,execution_files=files,data_files=outputs,new_project_calls=0)))
write('commits.txt',git('log','--format=%H %s',EXECUTION+'..'+DATA))
write('changed-files.json',encode(git('diff','--name-only',EXECUTION+'...'+DATA).decode().splitlines()))
copies={}
for name in ('build_26_root_packet.py','26-verify_packet.py','run_26_root_acceptance.py'):
    path=ROOT/'.work'/name;data=path.read_bytes();write('root-tools/'+name,data)
    copies[str(path)]=dict(copy='root-tools/'+name,sha256=digest(data),bytes=len(data))
for folder in ('26-frozen-launch-records-01','26-capture-visual-qa-01'):
    for path in sorted((ROOT/'.work'/folder).rglob('*')):
        if not path.is_file() or '__pycache__' in path.parts or path.suffix in {'.pyc','.pyo'}:continue
        data=path.read_bytes();copy='root-support/'+folder+'/'+path.relative_to(ROOT/'.work'/folder).as_posix();write(copy,data)
        copies[str(path)]=dict(copy=copy,sha256=digest(data),bytes=len(data))
write('root-copies-manifest.json',encode(copies))
print(json.dumps(dict(execution=EXECUTION,data=DATA,role_counts={k:len(v) for k,v in roles.items()},source_exports=len(files),capture_exports=len(outputs),root_support_copies=len(copies),prior_files=len(before),new_project_calls=0)))
