"""Independent saved-only Standards checks; no application/tool imports or calls."""
import ast
from collections import Counter
from copy import deepcopy
from fractions import Fraction as F
from hashlib import sha256
import json
import math
from pathlib import Path
import struct
import subprocess
import zipfile

OUT=Path(__file__).resolve().parent
EXECUTION='35193647091f90d17c339976ae47ef69385e9a43'
DATA='53f09ff4e232ebfac6b64bd6e15bb8649146810b'
CAPTURE='evidence/mainline/engineering/26-candidate/capture-20261107-02'
REPO=Path('C:/Users/Donson/.codex/worktrees/mainline23-intervention/Renly')
checks=[]
def check(name,ok):
    checks.append(dict(name=name,passed=bool(ok)))
    if not ok:raise AssertionError(name)
def digest(raw):return sha256(raw).hexdigest()
def read(path):return json.loads(path.read_bytes())
def source(name):return OUT/'execution-export'/name
def output(name):return OUT/'data-export'/CAPTURE/name
def encode(v):return (json.dumps(v,ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode()
def write(name,raw):
    with (OUT/name).open('xb') as stream:stream.write(raw)
def close(a,b):return type(a) in (int,float) and math.isfinite(a) and math.isclose(a,b,rel_tol=0,abs_tol=1e-9)
def jsonl(path):return [json.loads(line) for line in path.read_text(encoding='utf-8').splitlines()]
def git(*args):return subprocess.check_output(['git',*args],cwd=REPO)

manifest=read(OUT/'source-manifest.json');protocol=read(source('docs/mainline/26-candidate-engineering-protocol-v2.json'))
receipt=read(output('receipt.json'));attempt=read(output('attempt.json'));saved_checks=read(output('checks.json'))
check('fixed execution/data identity',manifest['execution']==EXECUTION and manifest['data']==DATA and receipt['execution_commit']==attempt['execution_commit']==EXECUTION)
check('255 exact role exports',len(manifest['execution_files'])==255)
check('exact role counts', {k:len(v) for k,v in manifest['roles'].items()}==dict(runtime=67,tools=3,inputs=175,historical_development=10))
for name,identity in manifest['execution_files'].items():
    check('guarded source/tool/input/history hash '+name,digest(source(name).read_bytes())==identity['sha256'])
    if name.endswith('.py'):ast.parse(source(name).read_text(encoding='utf-8'),filename=name)
for role,group in receipt['pinned'].items():
    check('role exact '+role,group==manifest['roles'][role])
    for name,expected in group.items():check('original execution role hash '+role+'/'+name,digest(source(name).read_bytes())==expected)
declared=set(protocol['durable_root'])|{c['id']+'/'+n for c in protocol['pure_cases'] for n in protocol['durable_pure']}|{c['id']+'/'+n for c in protocol['physical_cases'] for n in protocol['durable_physical']}
check('50 artifacts plus receipt exact set',set(receipt['artifacts'])==declared and len(declared)==50 and set(manifest['data_files'])=={CAPTURE+'/'+n for n in declared|{'receipt.json'}})
for name,expected in receipt['artifacts'].items():check('exact original durable artifact '+name,digest(output(name).read_bytes())==expected)
for name,identity in manifest['data_files'].items():check('exact committed output '+name,digest((OUT/'data-export'/name).read_bytes())==identity['sha256'])
changed=read(OUT/'changed-files.json')
check('data commit only51 new original capture blobs',set(changed)==set(manifest['data_files']))
check('capture terminal PASS exact budget',receipt['status']=='PASS' and receipt['failures']==0 and receipt['pure_attempts']==receipt['pure_completed']==10 and receipt['physical_attempts']==receipt['physical_completed']==6 and receipt['validated_cases']==16 and receipt['simulated_duration_attempted_s']==36 and receipt['source_head_and_bytes_unchanged'] is True)
check('scope retains pending root and field',receipt['global_regression_gate']=='PENDING_ROOT_INTEGRATED_FULL' and receipt['field_calibration']=='PENDING' and receipt['registered_research_trials']==receipt['llm_calls']==receipt['training_calls']==0)
ledger=jsonl(output('attempts.jsonl'));all_cases=[('pure',c) for c in protocol['pure_cases']]+[('physical',c) for c in protocol['physical_cases']]
check('32ledger rows16unique attempts',len(ledger)==32 and len({c['id'] for _,c in all_cases})==16)
for index,(kind,case) in enumerate(all_cases):
    pair=ledger[2*index:2*index+2]
    check('attempt/source/order '+case['id'],[r['status'] for r in pair]==['STARTED','COMPLETED'] and all(r['kind']==kind and r['case']==case['id'] and r['execution_commit']==EXECUTION for r in pair))
references={c['id']:read(source(c['input'])) for _,c in all_cases}
for pair_name in ('same_public_pair','same_exact_pair','same_online_pair'):
    docs=deepcopy([references[n] for n in protocol[pair_name]])
    for doc in docs:doc.get('dispatch_program',doc)['policy_program'].pop('policy')
    check('same world public models/resources '+pair_name,docs[0]==docs[1])

for case in protocol['pure_cases']:
    identifier=case['id'];choice=read(output(identifier+'/decision.json'));computation=read(output(identifier+'/computation.json'))
    document=references[identifier];expected=case['expected'];saved=saved_checks['pure'][identifier]
    check('pure actual public identity '+identifier,choice['as_of_s']==document['frame']['as_of_s'] and choice['facility_id']==document['frame']['facility_id'])
    check('pure expected choice '+identifier,choice['chosen_candidate_id']==expected['chosen']==saved['chosen'])
    check('pure no execution authority '+identifier,choice['execution_permission'] is False and choice['generated_tour'] is False and choice['forecast_is_actual_observation'] is False)
    plans={a['kind']:a for a in choice['forecast_plans'][0]['alternatives']}
    for kind,ratio in expected.get('values',{}).items():
        actual=plans[kind]['expected_service_deficit_s'];check('independent literal '+identifier+'/'+kind,actual is None if ratio is None else close(actual,float(F(*ratio))))
    check('actual computation counters/time '+identifier,computation['model_evaluations']==choice['model_evaluations']==saved['model_evaluations'] and type(computation['elapsed_ns']) is int and computation['elapsed_ns']>=0 and saved['measured_elapsed_ns']==computation['elapsed_ns'])
    if expected.get('classification'):
        audit=choice['prospective_evidence_audit'][0]
        check('exact classification '+identifier,audit['classification']==expected['classification'])
        if expected.get('reason'):check('unknown reason retained '+identifier,expected['reason'] in audit['reasons'])
        quantitative={'exact_current','positive','negative','projected_positive','original_positive'}&set(expected)
        comparisons=audit.get('compatibility_by_assumption',[])
        if quantitative:
            local=next(q for q in document['policy_program']['options']['value_model']['question_models'] if q['question_id']==audit['question_id'])
            beliefs=document['policy_program']['options']['belief_model']['variants']
            required={(b['id'],v['id']) for b in beliefs for v in local['variants']}
            check('full no duplicate compatibility set '+identifier,len(comparisons)==len(required) and {(r['belief_variant_id'],r['value_variant_id']) for r in comparisons}==required)
            for row in comparisons:
                if 'exact_current' in expected and row['belief_variant_id']==beliefs[0]['id']:check('exact_current literal '+identifier,row['exact_current_outcome_mass']['cooling-limited']==expected['exact_current'])
                for branch in ('positive','negative'):
                    if expected.get(branch):check('exact '+identifier+'/'+branch,row['branches'][branch]['projected_outcome_mass']['cooling-limited']==expected[branch])
                if 'projected_positive' in expected:
                    check('incompatible projection literal '+identifier,row['branches']['positive']['projected_outcome_mass']['cooling-limited']==expected['projected_positive'])
                    check('original report posterior retained '+identifier,row['branches']['positive']['original_joint_report_posterior']['cooling-limited']==expected['original_positive'])
    if 'common_exact' in expected:
        current=choice['valuation_current_outcome_mass_by_belief_variant'];beliefs=document['policy_program']['options']['belief_model']['variants']
        check('shared exact basis complete '+identifier,choice['valuation_mass_basis']=='EXACT_FINITE_PUBLIC_BELIEF_CONTEXT_V1' and set(current)=={b['id'] for b in beliefs} and all(v['cooling-limited']==expected['common_exact'] for v in current.values()) and choice['model_evaluations']['valuation_exact_belief_context']==2)
check('pending case remains no selection',read(output('pending-issued-inspection/decision.json'))['chosen_candidate_id'] is None)

online=0;trace_counts={};code_hash_counts={}
for case in protocol['physical_cases']:
    identifier=case['id'];document=references[identifier];run=read(output(identifier+'/run.json'));expected=case['expected'];identity=run['code_identity']
    trace=jsonl(output(identifier+'/private-state.jsonl'));balances=jsonl(output(identifier+'/balances.jsonl'));decisions=run['policy_public_decisions'];online+=len(decisions)
    check('physical input exact '+identifier,read(output(identifier+'/scenario.json'))==document['model'] and run['inputs']['dispatch_program']==document['dispatch_program'])
    check('actual execution committed source '+identifier,identity['git_commit']==EXECUTION and identity['implementation_has_changes'] is False)
    expected_files={n:h for n,h in receipt['pinned']['runtime'].items() if n.startswith('src/aegis_dc/') or n=='src/patrol_rsi/contracts.py'}
    check('actual code identity exact36runtime files '+identifier,identity['files']==expected_files and len(expected_files)==36)
    for name,expected_hash in identity['files'].items():check('actual execution bytes '+identifier+'/'+name,digest(source(name).read_bytes())==expected_hash)
    code_hash_counts[identifier]=len(identity['files'])
    check('actual decision clock sequence '+identifier,[d['frame']['as_of_s'] for d in decisions]==document['dispatch_program']['decision_times_s'])
    check('actual choice sequence '+identifier,[d['choice']['chosen_candidate_id'] for d in decisions]==expected['chosen'])
    for index,d in enumerate(decisions):
        now=d['frame']['as_of_s'];choice=d['choice']
        check('no future public record '+identifier+'/'+str(index),all(r['observed_at_s']<=r['arrived_at_s']<=now for r in d['frame']['evidence']['records']))
        check('no future public feedback '+identifier+'/'+str(index),all(r['observed_at_s']<=r['arrived_at_s']<=now for r in d['history']['work_feedback']))
        check('online no physical permission '+identifier+'/'+str(index),choice['execution_permission'] is False and choice['generated_tour'] is False and choice['as_of_s']==now)
        check('online common valuation basis '+identifier+'/'+str(index),choice['valuation_mass_basis']=='EXACT_FINITE_PUBLIC_BELIEF_CONTEXT_V1')
    work=run['work_records'];effects=run['intervention_private_audit']['events']
    check('paid completed work clocks '+identifier,[r['work_started_at_s'] for r in work]==expected['work_started_at_s'] and [r['completed_at_s'] for r in work]==expected['completed_at_s'] and all(r['status']=='completed' for r in work))
    check('actual named residual effect '+identifier,[r['applied_at_s'] for r in effects]==expected['effect_at_s'] and all(r['old_value']==4 and r['new_value']==2 and r['outcome']=='APPLIED' for r in effects))
    check('action never closes risk '+identifier,all(r['risk_closed'] is False for r in run['intervention_public_feedback']))
    check('fixed sensing continues declared schedule '+identifier,[r['polled_at_s'] for r in run['policy_sensor_private_audit']]==expected['polls'])
    records=run['inspection_public_snapshot']['records']
    if expected['handheld'] is None:check('no performed inspection no evidence '+identifier,records==[])
    else:
        check('actual one handheld original '+identifier,len(records)==1)
        record=records[0]
        check('actual observation and arrival separated '+identifier,record['observed_at_s']==2.25 and record['arrived_at_s']==2.75 and record['provenance']['origin_id']=='post-clean-flow')
        check('before arrival no handheld '+identifier,not any(r['source_id']=='portable-intake-meter' for r in decisions[1]['frame']['evidence']['records']))
        if expected['handheld']=='missing':
            check('actual unsupported record remains missing '+identifier,record['value'] is None and record['availability']=='missing' and record['quality']['status']=='unknown' and run['inspection_public_feedback'][0]['confirmation']=='UNCONFIRMED')
        else:check('actual handheld analytic flow '+identifier,close(record['value'],math.sqrt(float(F(1,340)))))
    if expected.get('closure_pending'):
        check('only arrived closure feedback pending '+identifier,decisions[2]['choice']['question_lifecycle']['questions'][0]['status']=='OPEN_UNCONFIRMED' and decisions[3]['choice']['question_lifecycle']['questions'][0]['status']=='ACTION_COMPLETED_PENDING_VERIFICATION' and decisions[3]['choice']['question_lifecycle']['questions'][0]['risk_closed'] is False)
    if expected.get('first_reason'):
        audit=decisions[0]['choice']['prospective_evidence_audit'][0]
        check('known pending fixed remains null '+identifier,audit['classification']=='UNMODELED' and expected['first_reason'] in audit['reasons'] and next(a for a in decisions[0]['choice']['forecast_plans'][0]['alternatives'] if a['kind']=='inspect_then_act')['expected_service_deficit_s'] is None)
    summary=run['summary']
    for name in ('demand_service_unit_s','delivered_service_unit_s','service_deficit_time_s'):check('independent service literal '+identifier+'/'+name,close(summary[name],expected[name]))
    check('actual work cost separate from envelope '+identifier,close(summary['worker_work_person_s'],expected['work_person_s']) and run['policy_public_resource_ledger']['spent_or_reserved']==expected['spent'])
    check('same world remaining service bottleneck '+identifier,all(r['domains']['it_service']['delivered']==.25 and r['domains']['it_service']['demand']==1 for r in trace))
    check('full finite trace and step '+identifier,len(trace)==len(balances)+1 and trace[0]['time_s']==0 and trace[-1]['time_s']==6 and all(0<r['end_s']-r['start_s']<=.01+1e-9 for r in balances))
    check('hydraulic literal before after every saved point '+identifier,all(close(r['domains']['facility_cooling']['lake_pump']['volume_flow_m3_s'],math.sqrt(1/(180 if effects and r['time_s']>=effects[0]['applied_at_s'] else 340))) for r in trace))
    check('saved conservation bound '+identifier,abs(summary['whole_run_energy_residual_J'])<1e-4 and summary['max_mass_residual_kg']<=1e-9)
    audits=run['policy_computation_audit']
    check('online cost counters actual and aligned '+identifier,len(audits)==len(decisions) and all(a['model_evaluations']==d['choice']['model_evaluations'] and type(a['elapsed_ns']) is int and a['elapsed_ns']>=0 for a,d in zip(audits,decisions)))
    check('physical engineering only scope '+identifier,run['research_trials']==run['model_calls']==run['training_calls']==0 and run['field_calibration']=='PENDING')
    for name,row in run['artifacts'].items():check('original saved physical artifact '+identifier+'/'+name,digest(output(identifier+'/'+name).read_bytes())==row['sha256'])
    trace_counts[identifier]=len(trace)
check('21 exact online decisions',online==21)

history='evidence/mainline/engineering/26-candidate/development-originals-20261107-01/'
classification=read(source(history+'classification.json'))
check('historical30attempts original counts',classification['public_call_attempt_directories']==30 and classification['original_terminal_counts']=={'FAILED':12,'PHYSICAL_CALL_COMPLETED_NOT_TEST_ACCEPTANCE':16,'NO_TERMINAL':1,'REJECTED_EXISTING_OUTPUT':1})
check('historical26gaps and46unknown retained',sum(bool(c['provenance_gaps']) for c in classification['cases'])==26 and classification['call_outcome_unknown']==1)
check('V1original unexecuted retained',read(source('evidence/mainline/engineering/26-candidate/pre-capture-v1-preservation/manifest.json'))['executed_selector_calls']==0)
launch_dir=OUT/'root-support/26-frozen-launch-records-01';launch=read(launch_dir/'launch.json');terminal=read(launch_dir/'terminal.json');process=read(launch_dir/'process.json')
check('actual launch source execution identity',launch['source']==process['source']==terminal['source']==EXECUTION and process['pid']>0)
check('launch flags exact and cache isolated',launch['command'][1:4]==['-B','-X','utf8'] and launch['cache_prefix_existed_before'] is False and launch['environment']['PYTHONDONTWRITEBYTECODE']=='1' and launch['environment']['PYTHONHASHSEED']=='0' and launch['environment']['PYTHONPYCACHEPREFIX'].endswith('empty-python-cache-prefix'))
check('actual interpreter pin same attempt',launch['python_executable_sha256']==attempt['executable_sha256'])
check('external terminal success original stdout stderr hashes',terminal['status']=='COMPLETED' and terminal['returncode']==0 and digest((launch_dir/'stdout.txt').read_bytes())==terminal['stdout_sha256'] and digest((launch_dir/'stderr.txt').read_bytes())==terminal['stderr_sha256'])
visual_dir=OUT/'root-support/26-capture-visual-qa-01';visual=read(visual_dir/'visual-review.json');render=read(visual_dir/'render.json')
check('root actual visual review source identity',visual['status']=='PASS' and visual['actually_viewed_pngs']==3 and visual['open_findings']==0 and visual['execution']==EXECUTION and visual['source_data_delivery']==DATA)
for stem,row in visual['files'].items():
    png=(visual_dir/(stem+'.png')).read_bytes();svg=(visual_dir/(stem+'.svg')).read_bytes()
    check('renderer source SVG matches formal original '+stem,svg==output(stem+'.svg').read_bytes() and digest(svg)==row['svg_sha256'])
    check('render PNG hash and PNG dimensions '+stem,digest(png)==row['png_sha256'] and png[:8]==b'\x89PNG\r\n\x1a\n' and struct.unpack('>II',png[16:24])==(row['width'],row['height']))
    check('render metadata exact same files '+stem,render['files'][stem]==row)
check('forecast SVG labelled predictions not plant outcomes',b'These bars are not measured plant outcomes.' in output('decision-values.svg').read_bytes())
check('actual SVG service bottleneck remains explicit',b'network capacity 0.25 remains limiting.' in output('actual-online.svg').read_bytes())
write('saved-checks.json',encode(checks))
result=dict(status='PASS',scope='Saved original53f and execution351 independent byte/JSON/literal review only',checks=len(checks),
    exact_role_counts={k:len(v) for k,v in receipt['pinned'].items()},artifacts=50,terminal_receipts=1,ledger_rows=32,pure_calls=10,physical_runs=6,simulated_duration_s=36,online_decisions=21,
    trace_counts=trace_counts,actual_runtime_identity_counts=code_hash_counts,root_visual_review_recorded=True,reviewer_images_viewed=False,
    historic_attempts=30,historical_gap_cases=26,historical_unknowns=1,execution=EXECUTION,data=DATA,new_project_calls=0,formal_capture_rerun=False,full_regression_rerun=False,ticket_acceptance=False)
write('saved-review.json',encode(result))
print(json.dumps(result))
