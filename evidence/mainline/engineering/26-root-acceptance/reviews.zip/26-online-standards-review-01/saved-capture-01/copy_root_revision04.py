"""Pin confirmed bytechain plus original-interruption preservation correction."""
from hashlib import sha256
import difflib
import json
from pathlib import Path
OUT=Path(__file__).resolve().parent
ROOT=Path('C:/Users/Donson/Documents/ChatGPT/Renly/.work')
folder=OUT/'root-tools-revision-04';folder.mkdir(exist_ok=False)
expected={'build_26_root_packet.py':'038c70adc30deb56e5dacfab14bc9e2a3c44134849a3f6af8c45765ca7ef3616',
    '26-verify_packet.py':'0ef2fe8eec82e13c6c1ed1a0d0c9d7626e322ec1a453248e318e159d0aa2c875'}
failure=dict(classification='STATIC_DRAFT_COPY_PIN_REFUSAL_NOT_APPLICATION_FAILURE',
    attempted_script='copy_root_revision03.py',error='AssertionError: copied draft bytes changed from announced27b3/d472 before export',
    parent_confirmed_cause='Root added original interruption ZIP and member hash binding after the bytechain correction; runtime443 and formal351/53f unchanged.',
    next_fixed_copy='root-tools-revision-04',old_expected_pins_recorded_in_original_script=True,new_project_calls=0)
with (OUT/'root-copy-pin-refusal-01.json').open('x',encoding='utf-8') as stream:json.dump(failure,stream,indent=2)
copies={}
for name in (*expected,'26-root-bytechain-correction-01.json'):
    raw=(ROOT/name).read_bytes()
    if name in expected:assert sha256(raw).hexdigest()==expected[name]
    with (folder/name).open('xb') as stream:stream.write(raw)
    copies[name]=dict(sha256=sha256(raw).hexdigest(),bytes=len(raw))
    if name in expected:
        old=(OUT/'root-tools-revision-02'/name).read_text(encoding='utf-8');new=raw.decode('utf-8')
        with (folder/(name+'.diff')).open('x',encoding='utf-8',newline='\n') as stream:stream.write(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='rev02-fixed',tofile='bytechain-and-interruption-revision04')))
with (folder/'manifest.json').open('x',encoding='utf-8') as stream:json.dump(copies,stream,indent=2)
print(json.dumps(copies))
