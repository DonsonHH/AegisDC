"""Independent saved-byte/hash review of the fixed development archive."""
from collections import Counter
from hashlib import sha256
import json
from pathlib import Path,PurePosixPath
import subprocess
import zipfile

OUT=Path(__file__).resolve().parent
REPO=Path('C:/Users/Donson/.codex/worktrees/mainline23-intervention/Renly')
BASE='a08dc371f85570f20ce486401f1427ade0a76a3a'
SOURCE='860f0ca39f5e866ad2531466360cc7ce95f64ded'
PREFIX='evidence/mainline/engineering/26-candidate/development-originals-20261107-01/'
checks=[]
def check(name,ok):
    checks.append(dict(name=name,passed=bool(ok)))
    if not ok:raise AssertionError(name)
def digest(raw):return sha256(raw).hexdigest()
def read(path):return json.loads(path.read_bytes())
def encode(v):return (json.dumps(v,ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode()
def write(name,raw):
    with (OUT/name).open('xb') as stream:stream.write(raw)
def export(name):return OUT/'export'/name
def git(*args):return subprocess.check_output(['git',*args],cwd=REPO)

pins=read(OUT/'source-manifest.json');before=read(OUT/'core-review-before.json')
check('fixed source and base',pins['source']==SOURCE and pins['base']==BASE)
for name,expected in before.items():check('core review remains sealed '+name,digest((OUT.parent/name).read_bytes())==expected)
for name,identity in pins['files'].items():
    raw=export(name).read_bytes();check('export identity '+name,digest(raw)==identity['sha256'] and len(raw)==identity['bytes'])
check('no runtime or preservation tool delta',not any(n.startswith(('src/','scripts/')) for n in pins['changed_files']))
for name in ('src/aegis_dc/policy_execution.py','src/aegis_dc/plant.py','scripts/package_candidate_development.py','scripts/verify_candidate_development.py'):
    check('same reviewed bytes '+name,export(name).read_bytes()==(OUT.parent/'export'/name).read_bytes())
declaration=read(export(PREFIX+'declaration.json'));receipt=read(export(PREFIX+'receipt.json'))
members=read(export(PREFIX+'archive-members.json'));classification=read(export(PREFIX+'classification.json'))
reconstructions=read(export(PREFIX+'source-reconstructions.json'))
check('durable set is exactly six including receipt',set(receipt['artifacts'])==set(declaration['artifacts']) and len(declaration['artifacts'])==5)
for name,expected in receipt['artifacts'].items():check('declared artifact hash '+name,digest(export(PREFIX+name).read_bytes())==expected)
check('packager identity exact',digest(export(receipt['authoring_tool']).read_bytes())==receipt['authoring_tool_sha256'])
check('not formal or scientific archive',classification['formal_capture'] is False and classification['registered_research_trials']==0 and classification['no_extra_project_runs'] is True)
check('exact recorded attempt count',len(classification['cases'])==classification['public_call_attempt_directories']==receipt['attempts']==30)
check('exact source recovery not original snapshot claim',reconstructions['no_execution'] is True and reconstructions['no_manifest_rewriting'] is True and reconstructions['not_claimed_as_original_precall_snapshots'] is True)
recipes={}
for recipe in reconstructions['recipes']:
    raw=export(recipe['path']).read_text(encoding='utf-8')
    for step in recipe['replacement_steps']:
        check('unique inverse patch '+step['before'][:48],raw.count(step['before'])==1)
        raw=raw.replace(step['before'],step['after'])
    recipes[recipe['path']]=raw.encode()
    check('exact declared inverse patch result',digest(raw.encode())==recipe['output_sha256'])
counts=Counter();runtime_hashes=0;duration=0;gap_cases=0;reconstructed=0;original_snapshots=0
with zipfile.ZipFile(export(PREFIX+'originals.zip')) as archive:
    names=archive.namelist()
    check('529 unique declared ZIP members',len(names)==len(set(names))==len(members)==receipt['archive_members']==529 and set(names)==set(members))
    cache={}
    for name,identity in members.items():
        path=PurePosixPath(name)
        check('durable member safe no cache '+name,not path.is_absolute() and '..' not in path.parts and '__pycache__' not in path.parts and path.suffix not in {'.pyc','.pyo'})
        raw=archive.read(name);cache[name]=raw
        check('exact original ZIP hash '+name,digest(raw)==identity['sha256'] and len(raw)==identity['bytes'])
    def saved(name):return json.loads(cache[name])
    cases=classification['cases'];check('unique attempt directory identities',len({c['case'] for c in cases})==30)
    attempt_names={n.removeprefix('original/').removesuffix('/attempt.json') for n in names if n.startswith('original/') and n.endswith('/attempt.json')}
    check('all original attempt directories classified',attempt_names=={c['case'] for c in cases})
    for case in cases:
        prefix='original/'+case['case']+'/'
        attempt=saved(prefix+'attempt.json');status=case['original_terminal_status'];counts[status]+=1
        check('original attempt source head '+case['case'],attempt['source_commit']==case['recorded_head'])
        check('original terminal retained '+case['case'],(prefix+'terminal.json' not in cache if status=='NO_TERMINAL' else saved(prefix+'terminal.json')['status']==status) and case['status_not_rewritten'] is True)
        check('complete runtime set '+case['case'],{s['path'] for s in case['source_recovery']}==set(attempt['source_files']) and case['runtime_bytes_hash_verified'] is True)
        for source in case['source_recovery']:
            runtime_hashes+=1;raw=cache[source['member']]
            check('original runtime hash '+case['case']+'/'+source['path'],digest(raw)==source['sha256']==attempt['source_files'][source['path']])
            if source['basis']=='ORIGINAL_CAPTURED_RUNTIME_SNAPSHOT':
                original_snapshots+=1
                check('original source snapshot identified '+case['case']+'/'+source['path'],source['member']==prefix+'runtime-source/'+source['path'])
            elif source['basis']=='EXPLICIT_INVERSE_PATCH_HASH_MATCH':
                reconstructed+=1;check('inverse recovery exact original hash '+case['case'],raw==recipes[source['path']])
        gaps=case['provenance_gaps'];gap_cases+=bool(gaps)
        tools_missing=prefix+'test-tools.json' not in cache
        check('historical tool gap explicitly declared '+case['case'],('HISTORICAL_DEVELOPMENT_TEST_AUTHORING_TOOLS_NOT_CAPTURED' in gaps)==tools_missing)
        if not tools_missing:
            for name,expected in saved(prefix+'test-tools.json').items():check('captured authoring tool hash '+case['case']+'/'+name,digest(cache[prefix+'test-tools/'+name])==expected)
        if status=='PHYSICAL_CALL_COMPLETED_NOT_TEST_ACCEPTANCE':
            run=saved(prefix+'original/run.json');duration+=run['inputs']['duration_s']
            check('completed run not test assertion accepted '+case['case'],case['classification']=='COMPLETED_DEVELOPMENT_INTEGRATION_NOT_TEST_ASSERTION_PASS')
            check('actual saved execution revision '+case['case'],run['code_identity']['git_commit']==attempt['source_commit'])
            for name,expected in run['code_identity']['files'].items():check('saved execution runtime anchored '+case['case']+'/'+name,attempt['source_files'][name]==expected)
            for name,identity in run['artifacts'].items():check('completed original artifact '+case['case']+'/'+name,digest(cache[prefix+'original/'+name])==identity['sha256'])
        elif status=='FAILED':
            check('original error no completed run claim '+case['case'],case['classification']=='PUBLIC_DEVELOPMENT_CALL_RAISED_ERROR_NO_COMPLETED_RUN' and case['completed_integration'] is False and prefix+'original/run.json' not in cache)
            missing_inputs=prefix+'model.json' not in cache or prefix+'dispatch-program.json' not in cache
            check('missing refusal inputs explicit not fabricated '+case['case'],('HISTORICAL_DEVELOPMENT_REFUSAL_INPUTS_NOT_CAPTURED_AND_NOT_RECONSTRUCTED' in gaps)==missing_inputs)
        elif status=='NO_TERMINAL':
            check('transport unknown not inferred zero '+case['case'],case['classification']=='TRANSPORT_INTERRUPTED_OUTCOME_UNOBSERVED' and case['completed_integration']=='UNKNOWN_NOT_ASSUMED_FALSE')
            observation=saved(case['observation_member'])
            check('unknown observation retained',observation['status']=='TRANSPORT_INTERRUPTED_OUTCOME_UNOBSERVED' and observation['original_terminal_exists'] is False)
            for name,identity in observation['files'].items():check('observed interrupted original identity '+name,digest(cache[prefix+name])==identity['sha256'])
        elif status=='REJECTED_EXISTING_OUTPUT':check('CLI overwrite refusal separate original',case['classification']=='CLI_REFUSED_OVERWRITE_BEFORE_SIMULATION' and case['completed_integration'] is False)
        else:check('no unexpected status',False)
    for row in reconstructions['pooled_original_hash_matched_files']:
        check('pooled recovered bytes hash '+row['path'],digest(cache[row['member']])==row['sha256'])
        if row['basis']=='EXPLICIT_INVERSE_PATCH_HASH_MATCH':check('pooled reconstruction labelled',cache[row['member']]==recipes[row['path']])
expected={'PHYSICAL_CALL_COMPLETED_NOT_TEST_ACCEPTANCE':16,'FAILED':12,'REJECTED_EXISTING_OUTPUT':1,'NO_TERMINAL':1}
check('literal terminal counts',dict(counts)==expected==classification['original_terminal_counts'])
check('2010 original runtime hashes accounted',runtime_hashes==2010 and receipt['all_recorded_runtime_hashes_recovered'] is True)
check('26 historical gap cases retained',gap_cases==receipt['cases_with_historical_input_or_tool_gaps']==26)
check('known completed durations exact saved sum',duration==classification['known_completed_duration_s'])
check('explicit reconstruction actually present',reconstructed>0 and original_snapshots>0)
plan=export('docs/mainline/26-online-policy-bridge-plan.md').read_text(encoding='utf-8')
ticket=export('.scratch/full-facility-mainline/issues/26-candidate-policy.md').read_text(encoding='utf-8')
for literal in ('Thirty',):pass
check('docs current D status updated','Status: implemented D-stage development' in plan)
check('docs expose all finite accounting','16 known completed integrations,12 original error terminals' in plan and 'one unobserved interruption' in plan and 'Twenty-six cases' in plan)
check('docs recovered not original preflight bytes','without claiming original preflight input bytes' in plan and 'not represented as an original pre-call snapshot' in plan)
check('docs physical horizon not forecast extension','not an implied extension of the saved physical run' in plan)
check('ticket remains claimed and formal pending','**Status:** claimed' in ticket and 'no26 formal capture' in ticket)
after={p.relative_to(OUT.parent).as_posix():digest(p.read_bytes()) for p in sorted(OUT.parent.rglob('*')) if p.is_file() and OUT not in p.parents}
check('prior D core set and bytes unchanged',before==after)
write('core-review-after.json',encode(after));write('checks.json',encode(checks))
report='''Standards补充：PASS（a08dc371…860f0ca，仅保存归档与文档）。\n\n硬标准：六件耐久交付、529个ZIP成员和全部2010个原执行源码哈希相符。30目录保留16次完成、12次错误、1次覆盖拒绝、1次未知中断；26例历史输入或工具缺口明列。逆补丁恢复与原快照分开，原状态和失败不重写，未知耗时未当零。执行头与源码哈希分别保留，完成运行未升级为断言通过。\n\n启发性风险：无本增量必须处理的异味。实际8文件增量不改运行源码/保存工具；a08核心包保持不变。静态保存核对新增项目调用0，不替代正式工程封存、鲜取交付、根验收或第26项接受。\n'''
write('report.md',report.encode())
review=dict(schema='aegisdc-independent-standards-review-v1',axis='Standards',status='PASS',base=BASE,source=SOURCE,
    scope='Fixed development archive and current-status documentation supplement; no project execution',checks=len(checks),exports=len(pins['files']),
    archive_members=529,attempt_directories=30,terminal_counts=expected,runtime_hashes=runtime_hashes,original_source_snapshot_hashes=original_snapshots,
    exact_inverse_reconstruction_hashes=reconstructed,historical_gap_cases=gap_cases,known_completed_duration_s=duration,
    hard_findings=[],heuristic_findings=[],unresolved=[],new_project_calls=0,tests_run=0,selectors_run=0,assessments_run=0,inference_calls=0,simulation_calls=0,
    prior_core_files_preserved=len(before),formal_capture=False,ticket_acceptance=False,
    limits=['Historic capture gaps remain explicit; recovery does not create pre-call snapshots','Actual archived bytes checked independently; project verifier was not invoked','Formal capture/root/publication remain pending'])
write('review.json',encode(review))
artifacts={p.relative_to(OUT).as_posix():dict(sha256=digest(p.read_bytes()),bytes=p.stat().st_size) for p in sorted(OUT.rglob('*')) if p.is_file()}
write('delivery-manifest.json',encode(dict(schema='aegisdc-static-review-delivery-manifest-v1',source=SOURCE,artifacts=artifacts,terminal_receipt='delivery-manifest.json',new_project_calls=0)))
print(json.dumps(dict(status='PASS',checks=len(checks),runtime_hashes=runtime_hashes,gap_cases=gap_cases,archive_members=529,new_project_calls=0,report_sha256=digest((OUT/'report.md').read_bytes()),review_sha256=digest((OUT/'review.json').read_bytes()))))
