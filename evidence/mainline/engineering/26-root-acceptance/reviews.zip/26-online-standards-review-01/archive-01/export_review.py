"""Export the fixed D archive supplement without any project execution."""
from hashlib import sha256
import json
from pathlib import Path
import subprocess
OUT=Path(__file__).resolve().parent
REPO=Path('C:/Users/Donson/.codex/worktrees/mainline23-intervention/Renly')
BASE='a08dc371f85570f20ce486401f1427ade0a76a3a'
SOURCE='860f0ca39f5e866ad2531466360cc7ce95f64ded'
def git(*args):return subprocess.check_output(['git',*args],cwd=REPO)
def digest(raw):return sha256(raw).hexdigest()
def encode(v):return (json.dumps(v,ensure_ascii=False,indent=2)+'\n').encode()
def write(name,raw):
    path=OUT/name;path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('xb') as stream:stream.write(raw)
prior={p.relative_to(OUT.parent).as_posix():digest(p.read_bytes()) for p in sorted(OUT.parent.rglob('*')) if p.is_file() and OUT not in p.parents}
write('core-review-before.json',encode(prior))
assert git('merge-base',BASE,SOURCE).decode().strip()==BASE
changed=git('diff','--name-only',BASE+'...'+SOURCE).decode().splitlines()
write('candidate.diff',git('diff',BASE+'...'+SOURCE))
write('commits.txt',git('log','--format=%H %s',BASE+'..'+SOURCE))
paths=sorted(set(changed+['src/aegis_dc/policy_execution.py','src/aegis_dc/plant.py','scripts/package_candidate_development.py','scripts/verify_candidate_development.py']))
keys=[SOURCE+':'+p for p in paths]
raw=subprocess.check_output(['git','cat-file','--batch'],cwd=REPO,input=''.join(k+'\n' for k in keys).encode())
offset=0;files={}
for path,key in zip(paths,keys):
    end=raw.index(b'\n',offset);header=raw[offset:end].split();assert len(header)==3 and header[1]==b'blob'
    start=end+1;size=int(header[2]);data=raw[start:start+size];offset=start+size+1
    write('export/'+path,data);files[path]=dict(git_blob=header[0].decode(),sha256=digest(data),bytes=len(data))
assert offset==len(raw)
write('source-manifest.json',encode(dict(base=BASE,source=SOURCE,files=files,changed_files=changed,new_project_calls=0)))
print(json.dumps(dict(exports=len(files),prior_core_files=len(prior),source=SOURCE)))
