"""Static Git/JSON/AST correction review; never import or call project code."""
import ast
from fractions import Fraction
from hashlib import sha256
import json
from pathlib import Path
import subprocess

ROOT=Path(__file__).resolve().parents[3]
OUT=Path(__file__).resolve().parent
PRIOR=OUT.parent
OLD='e6b372aab3417b7b1020c30fa356badb54a4d746'
SOURCE='ce8f35f0975ef00fb10811472cde701d21f470a9'
RUNTIME='31fb3fd8'
checks=[]

def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT)
def raw(name,revision=SOURCE):return git('cat-file','blob',revision+':'+name)
def sha(value):return sha256(value).hexdigest()
def write(name,value):
    path=OUT/name;path.parent.mkdir(parents=True,exist_ok=True)
    content=value if isinstance(value,bytes) else (json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode()
    with path.open('xb') as stream:stream.write(content)
def check(name,valid):
    if not valid:raise AssertionError(name)
    checks.append(dict(name=name,passed=True))

assert not (OUT/'review.json').exists()
prior_manifest=json.loads((PRIOR/'delivery-manifest.json').read_bytes())
prior_hashes={}
for name,identity in prior_manifest['artifacts'].items():
    content=(PRIOR/name).read_bytes();check('prior review preserved '+name,sha(content)==identity['sha256'])
    prior_hashes[name]=sha(content)
prior_hashes['delivery-manifest.json']=sha((PRIOR/'delivery-manifest.json').read_bytes())
write('prior-preservation.json',dict(source=OLD,artifacts=prior_hashes))
changed=git('diff','--name-only',OLD+'..'+SOURCE).decode().splitlines()
dependencies=['src/aegis_dc/action_value.py','src/aegis_dc/belief.py','src/aegis_dc/evidence_ledger.py',
              'src/aegis_dc/nonfixed_evidence.py','src/aegis_dc/sensor_channels.py','src/aegis_dc/policy_budget.py']
names=sorted(set(changed+dependencies));exports={}
for name in names:
    content=raw(name);write('export/'+name,content);exports[name]=dict(sha256=sha(content),bytes=len(content))
    check('exact correction export '+name,(OUT/'export'/name).read_bytes()==content)
    if name.endswith('.py'):
        ast.parse(content,filename=name);check('AST parse '+name,True)
write('correction.diff',git('diff',OLD+'..'+SOURCE))
check('metadata source retains runtime31',not git('diff','--name-only',RUNTIME+'..'+SOURCE,'--','src'))
p=raw('src/aegis_dc/evidence_projection.py').decode()
look=raw('src/aegis_dc/lookahead_policy.py').decode()
dispatch=raw('src/aegis_dc/dispatch_policy.py').decode()
contract=raw('docs/mainline/26-evidence-consistent-candidate.md').decode()
test=raw('tests/test_evidence_consistent_policy.py').decode()
check('STD26-01 shared helper compares current facility',"registry['facility_id']==frame['facility_id']" in p)
check('STD26-01 compares complete entity set',"set(registry['entity_ids'])==set(static['entity_ids'])" in p)
check('STD26-01 exact source and observable definitions',"for field in ('sources','observables'):" in p and "row==current[row['id']]" in p)
check('STD26-01 both profile types share identity helper',"_shared_registry(frame,validated['registry'],'Projection inspection')" in p and "_shared_registry(frame,background['ledger'],'Projection background')" in p)
check('STD26-02 guards observed strictly after now and work start',"if observed<=now or observed<=work_started:reasons.append('PROJECTED_MEASUREMENT_CLOCK_NOT_ADVANCING')" in p)
check('STD26-02 guard dominates invariant proof',p.index('if observed<=now')<p.index('if not reasons:')<p.index("classification='NON_ADAPTIVE_UNDER_DECLARED_UPDATER'"))
check('unchanged factors still exact identities',"r['record_id'],r['observation_epoch'],r['channel_id'],r['positive']" in p and 'signature!=current_signature' in p)
tiny=float.fromhex('0x0.0000000000001p-1022')
check('independent original clock counterexample remains positive',tiny>0 and Fraction(1)+Fraction(tiny)>1)
check('independent collapsed case is caught by declared guard',1+tiny<=1)
check('independent ordinary clock can progress',1+1>1)
check('input validation before value-model child indexing',look.index('_fields(options,OPTION_FIELDS')<look.index('values=assess_action_value(')<look.index("for local in model['question_models']"))
check('nested validation before execution binding',look.index('values=assess_action_value(')<look.index('validate_execution_bindings(policy_declaration'))
check('mapping text validation before binding index consumer',look.index("_text(binding[key],'Forecast binding '")<look.index('validate_execution_bindings(policy_declaration'))
check('v4 extra assessment is explicit',"action_value=2 if policy_declaration is not None else 1" in look)
check('shared cost unit still checked',"_require(model['cost_unit']==admission_budget.cost_unit" in look)
check('v4 routes validated public history',"policy_declaration=program if version4 else None,history=history" in dispatch)
check('pending issued measurements not suppressed by completion acknowledgment',"if r['status'] in {'aborted','rejected'}" in p and "if task not in stopped and (binding is None or binding['record_id'] not in visible)" in p)
check('pending measurements force unknown prospective value',"if pending_tasks:reasons.append('PENDING_INSPECTION_RECORD_JOINT_LAW_UNMODELED')" in p)
check('pending task audit is public',"pending_inspection_task_ids=pending_tasks" in p)
check('original model report law is not rewritten','positive_likelihood' not in p)
check('frame projection uses already arrived record fields','records=[{k:deepcopy(r[k]) for k in RECORD_FIELDS}' in p)
check('developer assertions cover four correction routes',all(name in test for name in ('test_background_profile_must_share_facility_entities_and_registry_for_every_v4_policy','test_positive_work_must_advance_the_actual_projected_binary64_measurement_clock','test_already_issued_inspection_without_arrived_measurement_prevents_a_no_background_prediction','test_malformed_v4_options_and_nested_models_are_rejected_before_binding_or_projection_access')))
basepath='evidence/mainline/engineering/26-candidate/'
classification=json.loads(raw(basepath+'development-log-format-classification-01.json'))
expected={'development/04-v4-closed-model-validation-red.log','development/05-v4-closed-model-validation-green.log','development/11-background-identity-red.log'}
check('only three native failed originals receive extra classification',{e['path'] for e in classification['entries']}==expected)
for entry in classification['entries']:
    content=raw(basepath+entry['path']);lines=content.splitlines(keepends=True)
    check('native original SHA '+entry['path'],sha(content)==entry['sha256'] and len(content)==entry['bytes'])
    actual=[i+1 for i,line in enumerate(lines) if line.rstrip(b'\r\n').endswith((b' ',b'\t'))]
    check('all and only classified trailing-space lines '+entry['path'],actual==[r['line_number'] for r in entry['native_trailing_space_lines']])
    for row in entry['native_trailing_space_lines']:
        check('exact native line bytes '+entry['path'],lines[row['line_number']-1].hex()==row['line_hex'])
    check('failed result never relabelled '+entry['path'],entry['actual_result']=='FAIL' and b'FAILED (' in content)
attrs=raw(basepath+'.gitattributes').decode().splitlines()
exceptions={line.split()[0] for line in attrs if not line.startswith('#') and '-blank-at-eol' in line}
check('whitespace exception only exact three paths',exceptions==expected)
for line in attrs:
    if not line or line.startswith('#'):continue
    check('other whitespace checks retained '+line.split()[0],all(token in line for token in ('-text','blank-at-eof','space-before-tab','cr-at-eol')))
for suffix in ('01-nonadaptive-public-choice-red.log','02-nonadaptive-public-choice-green-attempt.log','03-public-candidate-action-value-compatibility.log'):
    name=basepath+'development/'+suffix
    check('original first red/green unchanged '+suffix,raw(name)==raw(name,OLD))
final=raw(basepath+'development/13-four-boundaries-targeted-compatibility.log')
check('saved targeted development log really says43PASS',b'Ran 43 tests in 25.391s' in final and final.rstrip().endswith(b'OK'))
check('physical compatibility scope disclosed honestly','not a zero-plant-call check' in contract and 'does not repeat the thirteen sealed25 policy captures' in contract)
check('later acceptance scope remains pending','Informative/expiry modeling, public execution binding completeness, online v4 inheritance and all final acceptance gates remain pending.' in contract)
report='''ce8f35f0修订静态复核通过，已审修复未解决项0。

STD26-01：固定背景和检查profile共用设施、完整实体集及source/observable定义校验。STD26-02：正工时若未推进当前及开工坐标，直接标UNMODELED，原同刻冲突反例不再进入不变性证明。

嵌套输入先验证再索引，v4额外assessment按2次计；已发检查尚无到达记录时保持未知，普通完成确认不能提前清除。

04/05/11原生失败日志SHA、行号和hex逐项一致，仅三路径放宽blank-at-eol，其他检查保留。原首审57项、2个P2和40份文件未改；43项开发兼容日志有真实物理运行，未冒称零调用。本文仅做静态/Git/JSON/算术复核，新增项目调用0；在线和冻结验收仍待完成。
'''
write('report.md',report.encode())
write('source-manifest.json',dict(source=SOURCE,runtime_revision=git('rev-parse',RUNTIME).decode().strip(),prior_source=OLD,exports=exports))
write('checks.json',dict(checks_passed=len(checks),checks=checks,new_project_calls=0))
write('review.json',dict(schema='aegisdc-ticket26-first-standards-correction-review-v1',axis='Standards',status='PASS',source=SOURCE,
    runtime_revision=git('rev-parse',RUNTIME).decode().strip(),prior_source=OLD,checks_passed=len(checks),unresolved_findings=0,
    resolved_findings=['STD26-01','STD26-02'],prior_review_artifacts_preserved=len(prior_hashes),
    report_sha256=sha((OUT/'report.md').read_bytes()),new_selector_calls=0,new_assessments=0,new_tests=0,new_physical_runs=0,new_inference=0,new_capture=0,
    scope='Reviewed correction paths only; full ticket26 and root acceptance remain pending.',ticket_resolved=False,root_acceptance_claimed=False,overall_goal='ACTIVE'))
files=sorted(p.relative_to(OUT).as_posix() for p in OUT.rglob('*') if p.is_file())
write('declaration.json',dict(artifacts=files,terminal_receipt='delivery-manifest.json'))
files.append('declaration.json')
write('delivery-manifest.json',dict(source=SOURCE,artifacts={name:dict(sha256=sha((OUT/name).read_bytes()),bytes=(OUT/name).stat().st_size) for name in sorted(files)}))
print(json.dumps(dict(status='PASS',checks_passed=len(checks),unresolved_findings=0,prior_artifacts_preserved=len(prior_hashes),exported_files=len(exports),new_project_calls=0,
    report_sha256=sha((OUT/'report.md').read_bytes()),review_sha256=sha((OUT/'review.json').read_bytes()))))
