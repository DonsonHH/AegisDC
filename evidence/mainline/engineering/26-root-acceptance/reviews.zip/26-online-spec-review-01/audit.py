"""Independent D review: static exports, AST, saved JSON, Fraction and hashes only.

Never imports or calls project code. The original development calls are read only.
"""
import ast
from collections import Counter
from fractions import Fraction as F
from hashlib import sha256
import json
from pathlib import Path, PurePosixPath
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parent
REPO = Path(r'C:\Users\Donson\.codex\worktrees\mainline23-intervention\Renly')
INTEGRATION = Path(r'C:\Users\Donson\Documents\ChatGPT\Renly')
BASE = '4dee4488a274528de801b9c1475577b675c0d072'
SOURCE = 'a08dc371f85570f20ce486401f1427ade0a76a3a'
DELIVERY = '860f0ca39f5e866ad2531466360cc7ce95f64ded'
checks = []


def check(name, okay, detail=None):
    checks.append(dict(name=name, passed=bool(okay), detail=detail))
    if not okay:
        raise AssertionError(name)


def digest(raw):
    return sha256(raw).hexdigest()


def read(path):
    return json.loads(path.read_bytes())


def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO)


def source(name):
    return (ROOT / 'export' / name).read_text(encoding='utf-8')


def dump(text):
    return ast.dump(ast.parse(text), include_attributes=False)


def method(text, name):
    cls = next(n for n in ast.parse(text).body if isinstance(n, ast.ClassDef) and n.name == 'PolicySession')
    return next(n for n in cls.body if isinstance(n, ast.FunctionDef) and n.name == name)


for subdir, revision, field in [('', SOURCE, 'exports'), ('', BASE, 'base_exports'), ('packaging-01', DELIVERY, 'exports')]:
    pins = read(ROOT / subdir / 'source-pins.json')
    for name, identity in pins[field].items():
        target = ROOT / subdir / ('base-export' if field == 'base_exports' else 'export') / name
        raw = target.read_bytes()
        check('export identity ' + revision[:8] + ':' + name,
              digest(raw) == identity['sha256'] and len(raw) == identity['bytes'])
        check('exact Git blob ' + revision[:8] + ':' + name, raw == git('cat-file', 'blob', revision + ':' + name))

for name, identity in read(ROOT / 'prior-sealed-hashes.json').items():
    check('prior sealed package unchanged ' + name, digest((INTEGRATION / name).read_bytes()) == identity)

check('D commit list', git('rev-list', BASE + '..' + SOURCE).decode().splitlines() ==
      [SOURCE, '13e9725a11063e1eddba2b53a208c0f0c898492f'])
check('runtime delta limited to two files', set(git('diff', '--name-only', BASE, SOURCE, '--', 'src').decode().splitlines()) ==
      {'src/aegis_dc/policy_execution.py', 'src/aegis_dc/plant.py'})
check('packaging changes no runtime or tools', git('diff', '--name-only', SOURCE, DELIVERY, '--', 'src', 'scripts', 'tests') == b'')
for name in ['src/aegis_dc/dispatch_policy.py', 'src/aegis_dc/lookahead_policy.py',
             'src/aegis_dc/evidence_projection.py', 'src/aegis_dc/policy_budget.py',
             'src/aegis_dc/live_sensor_execution.py', 'src/aegis_dc/inspection_execution.py',
             'src/aegis_dc/intervention_execution.py', 'src/aegis_dc/workforce_dispatch.py',
             'src/aegis_dc/verified_closure.py', 'src/aegis_dc/__main__.py']:
    check('accepted C consumer unchanged ' + name, git('cat-file', 'blob', BASE + ':' + name) == git('cat-file', 'blob', SOURCE + ':' + name))

current = source('src/aegis_dc/policy_execution.py')
old = (ROOT / 'base-export/src/aegis_dc/policy_execution.py').read_text(encoding='utf-8')
init = method(current, '__init__')
v4block = next(n for n in init.body if isinstance(n, ast.If) and ast.unparse(n.test) ==
               "program['policy_program']['schema'] == 'aegisdc-dispatch-policy-program-v4'")
check('public profile gate precedes live sampling and declared crew setup', v4block.lineno <
      min(n.lineno for n in ast.walk(init) if isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id == 'LiveSensorSession'))
check('no hypothetical selector or private inspection validation call in constructor',
      not any(isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id in
              {'choose_work', 'project_inspections', 'infer_belief', 'assess_action_value', 'InspectionSession'} for n in ast.walk(init)))
v4source = '\n'.join(current.splitlines()[v4block.lineno - 1:v4block.end_lineno])
check('same gate independent of selected policy name', not any(isinstance(n, ast.Constant) and n.value in
      {'one_observation_lookahead', 'evidence_consistent_contingent'} for n in ast.walk(v4block)))
check('null is compared with actual absent sensor identity', any(
      isinstance(n, ast.IfExp) and isinstance(n.orelse, ast.Constant) and n.orelse.value is None for n in ast.walk(v4block)))
normalized = '\n'.join(current.splitlines()[:v4block.lineno - 1] + current.splitlines()[v4block.end_lineno:]) + '\n'
replacements = [
    ("if program['policy_program']['schema'] in {'aegisdc-dispatch-policy-program-v3','aegisdc-dispatch-policy-program-v4'}:",
     "if program['policy_program']['schema']=='aegisdc-dispatch-policy-program-v3':"),
    ("{'aegisdc-dispatch-policy-program-v2','aegisdc-dispatch-policy-program-v3','aegisdc-dispatch-policy-program-v4'}:",
     "{'aegisdc-dispatch-policy-program-v2','aegisdc-dispatch-policy-program-v3'}:"),
    ("if program['policy_program']['policy']=='one_observation_lookahead' and program['policy_program']['schema']!='aegisdc-dispatch-policy-program-v4':",
     "if program['policy_program']['policy']=='one_observation_lookahead':"),
    ("if self.program['policy_program']['schema'] not in {'aegisdc-dispatch-policy-program-v3','aegisdc-dispatch-policy-program-v4'}:return None",
     "if self.program['policy_program']['schema']!='aegisdc-dispatch-policy-program-v3':return None"),
]
for before, after in replacements:
    check('exact one intended D replacement ' + before[:55], normalized.count(before) == 1)
    normalized = normalized.replace(before, after)
check('entire orchestration AST otherwise equals C', dump(normalized) == dump(old))
for name in ['_frame', 'process', 'next_event']:
    check('inherited implementation unchanged ' + name, ast.dump(method(current, name), include_attributes=False) ==
          ast.dump(method(old, name), include_attributes=False))
plant = source('src/aegis_dc/plant.py')
plant_replaced = plant.replace("dispatch.program['policy_program']['schema'] in {'aegisdc-dispatch-policy-program-v3','aegisdc-dispatch-policy-program-v4'}",
                               "dispatch.program['policy_program']['schema']=='aegisdc-dispatch-policy-program-v3'")
check('entire plant AST otherwise equals C', dump(plant_replaced) == dump((ROOT / 'base-export/src/aegis_dc/plant.py').read_text(encoding='utf-8')))

archive_folder = ROOT / 'packaging-01/export/evidence/mainline/engineering/26-candidate/development-originals-20261107-01'
declaration = read(archive_folder / 'declaration.json')
receipt = read(archive_folder / 'receipt.json')
classified = read(archive_folder / 'classification.json')
members = read(archive_folder / 'archive-members.json')
check('six declared durable artifacts', set(p.name for p in archive_folder.iterdir()) == set(declaration['artifacts']) | {'receipt.json'})
for name, expected in receipt['artifacts'].items():
    check('development artifact hash ' + name, digest((archive_folder / name).read_bytes()) == expected)
check('archive author tool fixed', digest((ROOT / 'export' / receipt['authoring_tool']).read_bytes()) == receipt['authoring_tool_sha256'])
cases = classified['cases']
check('unique thirty attempt identities', len(cases) == len({c['case'] for c in cases}) == receipt['attempts'] == 30)
counts = Counter(c['original_terminal_status'] for c in cases)
check('literal 16 completed 12 error 1 refused 1 unknown', counts == dict(PHYSICAL_CALL_COMPLETED_NOT_TEST_ACCEPTANCE=16, FAILED=12, REJECTED_EXISTING_OUTPUT=1, NO_TERMINAL=1))
check('classification counts agree', counts == classified['original_terminal_counts'])
check('26 historical gap cases explicit', sum(bool(c['provenance_gaps']) for c in cases) == receipt['cases_with_historical_input_or_tool_gaps'] == 26)
runs = {}
source_hashes = 0
with zipfile.ZipFile(archive_folder / 'originals.zip') as archive:
    check('ZIP exact member set', len(archive.namelist()) == len(set(archive.namelist())) == 529 and set(archive.namelist()) == set(members))
    for name, identity in members.items():
        path = PurePosixPath(name)
        raw = archive.read(name)
        check('durable ZIP member ' + name, not path.is_absolute() and '..' not in path.parts and
              '__pycache__' not in path.parts and path.suffix not in {'.pyc', '.pyo'} and
              digest(raw) == identity['sha256'] and len(raw) == identity['bytes'])
    for case in cases:
        prefix = 'original/' + case['case'] + '/'
        attempt = json.loads(archive.read(prefix + 'attempt.json'))
        status = case['original_terminal_status']
        check('runtime recovery exact key set ' + case['case'], {s['path'] for s in case['source_recovery']} == set(attempt['source_files']))
        for item in case['source_recovery']:
            check('recorded runtime hash ' + case['case'] + ':' + item['path'],
                  digest(archive.read(item['member'])) == item['sha256'] == attempt['source_files'][item['path']])
            source_hashes += 1
        if status == 'NO_TERMINAL':
            check('unknown original not relabeled', prefix + 'terminal.json' not in members and
                  case['completed_integration'] == 'UNKNOWN_NOT_ASSUMED_FALSE')
        else:
            terminal = json.loads(archive.read(prefix + 'terminal.json'))
            check('original terminal retained ' + case['case'], terminal['status'] == status)
        if case.get('saved_run_member'):
            run = json.loads(archive.read(case['saved_run_member']));runs[case['case']] = run
            check('saved result actual source head ' + case['case'], run['code_identity']['git_commit'] == attempt['source_commit'])
            check('saved result actual runtime hashes ' + case['case'], all(attempt['source_files'][n] == h for n, h in run['code_identity']['files'].items()))
            for name, identity in run['artifacts'].items():
                check('saved run artifact ' + case['case'] + ':' + name, digest(archive.read(prefix + 'original/' + name)) == identity['sha256'])
            for decision in run['policy_public_decisions']:
                now = decision['frame']['as_of_s']
                check('saved decision has no unarrived records ' + case['case'] + ':' + str(now),
                      all(r['observed_at_s'] <= r['arrived_at_s'] <= now for r in decision['frame']['evidence']['records']))
                check('actual decision exact declared epoch ' + case['case'] + ':' + str(now), now in run['inputs']['dispatch_program']['decision_times_s'])
    correction = json.loads((ROOT / 'export/evidence/mainline/engineering/26-candidate/development/45-online-baseline-closure-saved-oracle-correction.log').read_bytes())
    closure_case = next(c for c in cases if c['case'].startswith('closest-baseline-closure-'))
    check('44 correction pins same physical original', digest(archive.read(closure_case['saved_run_member'])) == correction['sha256'] and correction['new_physical_calls'] == 0)
    unknown = next(c for c in cases if c['original_terminal_status'] == 'NO_TERMINAL')
    observation = json.loads(archive.read(unknown['observation_member']))
    check('46 interruption observation literal unknown', observation['status'] == 'TRANSPORT_INTERRUPTED_OUTCOME_UNOBSERVED' and observation['original_terminal_exists'] is False)
    for name, identity in observation['files'].items():
        check('46 observed original file ' + name, digest(archive.read('original/' + unknown['case'] + '/' + name)) == identity['sha256'])

check('2010 original attempt hashes accounted', source_hashes == 2010)
check('completed time exact literal', sum(F(str(r['inputs']['duration_s'])) for r in runs.values()) == F(1202, 25))
check('completed count literal', len(runs) == 16)
for name, run in runs.items():
    duration = F(str(run['inputs']['duration_s']))
    for key, expected in [('demand_service_unit_s', duration), ('delivered_service_unit_s', duration / 4), ('service_deficit_time_s', 3 * duration / 4)]:
        check('independent fixed bottleneck integral ' + name + ':' + key, F(str(run['summary'][key])) == expected)


def case_run(prefix):
    return next(v for k, v in runs.items() if k.startswith(prefix))


online = case_run('first-online-08')
check('real clock trajectory', [d['frame']['as_of_s'] for d in online['policy_public_decisions']] == [1, 2.5, 2.75, 4.5])
check('arrived report precedes optional action', [d['choice']['chosen_candidate_id'] for d in online['policy_public_decisions']] == ['first-inspection', None, 'first-action', None])
check('actual work then report timing', [w['completed_at_s'] for w in online['work_records']] == [2.25, 4] and
      [(r['observed_at_s'], r['arrived_at_s']) for r in online['inspection_public_snapshot']['records']] == [(2.25, 2.75)])
check('paid full admission envelope distinct from measured work', online['policy_public_resource_ledger']['spent_or_reserved'] == dict(person_s=20, tool_s=20, cost=2) and online['summary']['worker_work_person_s'] == 2)
check('continued sparse fixed sampling', [r['polled_at_s'] for r in online['policy_sensor_private_audit']] == [0])
check('residual effect not closure', online['intervention_private_audit']['events'][0]['new_value'] == 2 and not online['intervention_public_feedback'][0]['risk_closed'])
missing = case_run('actual-unsuitable-')
reading = next(r for r in missing['policy_public_decisions'][2]['frame']['evidence']['records'] if r['id'] == 'post-clean-flow')
check('actual unsuitable record is missing', reading['value'] is None and reading['availability'] == 'missing' and reading['quality']['status'] == 'unknown')
check('actual unsuitable feedback unconfirmed', missing['inspection_public_feedback'][0]['confirmation'] == 'UNCONFIRMED' and not missing['inspection_public_feedback'][0]['current_confirmation'])
pending = case_run('known-pending-fixed-')
plans = {p['kind']: p for p in pending['policy_public_decisions'][0]['choice']['forecast_plans'][0]['alternatives']}
check('pending arrival contingent value null', plans['inspect_then_act']['expected_service_deficit_s'] is None and plans['direct_intervention']['eligible'] and plans['defer']['eligible'])
check('fixed sampling not suppressed for direct case', [r['polled_at_s'] for r in pending['policy_sensor_private_audit']] == list(range(7)))
direct = case_run('constant-report-direct-')
check('constant law may prefer direct', [d['choice']['chosen_candidate_id'] for d in direct['policy_public_decisions']] == ['first-action', None, None, None] and direct['inspection_public_snapshot']['records'] == [])
defer = case_run('zero-modeled-deficit-defer-')
check('defer no tour no work', all(d['choice']['chosen_candidate_id'] is None and not d['choice']['generated_tour'] for d in defer['policy_public_decisions']) and defer['work_records'] == [])
check('defer mistaken model not healthy actual facility', defer['summary']['service_deficit_time_s'] == 4.5 and defer['policy_public_resource_ledger']['spent_or_reserved'] == dict(person_s=0, tool_s=0, cost=0))
closure = case_run('closest-baseline-closure-')
check('actual arrived closure states only', [d['choice']['question_lifecycle']['questions'][0]['status'] for d in closure['policy_public_decisions']] == ['OPEN_UNCONFIRMED'] * 3 + ['ACTION_COMPLETED_PENDING_VERIFICATION'])
check('closest baseline same final ledger', closure['policy_public_resource_ledger'] == online['policy_public_resource_ledger'])

dev = ROOT / 'export/evidence/mainline/engineering/26-candidate/development'
for prefix in ['34-', '36-', '38-', '44-']:
    check('original failed log retained ' + prefix, b'FAILED' in next(dev.glob(prefix + '*.log')).read_bytes())
check('empty original46 retained', next(dev.glob('46-*.log')).read_bytes() == b'')
for p in (ROOT / 'export/scripts').glob('*candidate_development.py'):
    tree = ast.parse(p.read_text(encoding='utf-8'))
    check('saved-only tool imports no project code ' + p.name, not any(
          isinstance(n, ast.ImportFrom) and (n.level or n.module.startswith(('aegis_dc', 'patrol_rsi'))) or
          isinstance(n, ast.Import) and any(a.name.startswith(('aegis_dc', 'patrol_rsi')) for a in n.names)
          for n in ast.walk(tree)))

result = dict(status='PASS', checks=len(checks), failures=0, unresolved=0, source=SOURCE, base=BASE,
              packaging_source=DELIVERY, prior_files_unchanged=len(read(ROOT / 'prior-sealed-hashes.json')),
              archive_members=529, runtime_hashes=source_hashes, public_attempt_directories=30,
              known_completed=16, error_terminals=12, overwrite_refusals=1, unknown=1,
              historical_input_or_tool_gap_cases=26, project_calls=0, selector_calls=0,
              simulation_calls=0, test_calls=0, inference_calls=0, research_trials=0,
              scope='STATIC_D_RUNTIME_AND_SAVED_DEVELOPMENT_PRESERVATION_NOT_TICKET_ACCEPTANCE')
(ROOT / 'checks.json').write_text(json.dumps(dict(summary=result, checks=checks), ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps(result, ensure_ascii=False))
