"""Independent static351 correction review. Never imports project/capture tools."""
import ast
from copy import deepcopy
from hashlib import sha256
import json
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parent
PARENT = ROOT.parent
REPO = Path(r'C:\Users\Donson\.codex\worktrees\mainline23-intervention\Renly')
SOURCE = '35193647091f90d17c339976ae47ef69385e9a43'
BASE = '93b7ad992fe233068521c10decc3c85756c806d1'
PACKAGE = 'evidence/mainline/engineering/26-candidate'
checks = []


def check(name, okay, detail=None):
    checks.append(dict(name=name, passed=bool(okay), detail=detail))
    if not okay:
        raise AssertionError(name)


def raw(name):
    return (ROOT / 'export' / name).read_bytes()


def read(name):
    return json.loads(raw(name))


def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO)


def function(text, name):
    return next(n for n in ast.parse(text).body if isinstance(n, ast.FunctionDef) and n.name == name)


def dump(node):
    return ast.dump(node, include_attributes=False)


pins = json.loads((ROOT / 'source-pins.json').read_bytes())
for name, identity in pins['exports'].items():
    data = raw(name)
    check('fixed exact export ' + name, data == git('cat-file', 'blob', SOURCE + ':' + name) and
          sha256(data).hexdigest() == identity['sha256'] and len(data) == identity['bytes'])
prior = json.loads((ROOT / 'prior-sealed-hashes.json').read_bytes())
for name, identity in prior.items():
    check('old review unchanged ' + name, sha256((PARENT / name).read_bytes()).hexdigest() == identity)
check('runtime still reviewed a08', git('diff', '--name-only', 'a08dc371f85570f20ce486401f1427ade0a76a3a', SOURCE, '--', 'src') == b'')
for name, identity in json.loads((ROOT / 'reference-pins.json').read_bytes())['references'].items():
    v1 = git('cat-file', 'blob', BASE + ':' + name)
    v2 = git('cat-file', 'blob', SOURCE + ':' + name)
    check('frozen input unchanged ' + name, v1 == v2 and sha256(v2).hexdigest() == identity['sha256'] and len(v2) == identity['bytes'])
old_protocol_path = 'docs/mainline/26-candidate-engineering-protocol.json'
check('v1 main protocol remains exact', git('cat-file', 'blob', BASE + ':' + old_protocol_path) == git('cat-file', 'blob', SOURCE + ':' + old_protocol_path))
preservation = read(PACKAGE + '/pre-capture-v1-preservation/manifest.json')
check('v1 preservation identity and zero recorded calls', preservation['source'] == BASE and
      preservation['executed_selector_calls'] == preservation['executed_physical_calls'] == 0)
for name, identity in preservation['files'].items():
    data = raw(PACKAGE + '/pre-capture-v1-preservation/' + name)
    check('v1 preservation exact Git blob ' + name, data == git('cat-file', 'blob', BASE + ':' + name) and
          sha256(data).hexdigest() == identity['sha256'] and len(data) == identity['bytes'])

v1 = json.loads(git('cat-file', 'blob', BASE + ':' + old_protocol_path))
v2 = read('docs/mainline/26-candidate-engineering-protocol-v2.json')
check('v2 explicit zero-call prior revision', v2['revision_of'] == dict(source=BASE, protocol=old_protocol_path,
      executed_selector_calls=0, executed_physical_calls=0))
check('new output directory', v2['output_directory'] == PACKAGE + '/capture-20261107-02')
normal = deepcopy(v2)
for name in ['revision_of', 'output_directory', 'correction_record']:
    normal.pop(name)
normal['schema'] = v1['schema']
normal['contracts'].remove('docs/mainline/26-pre-capture-tool-correction-01.md')
pending = next(c for c in normal['pure_cases'] if c['id'] == 'pending-issued-inspection')
check('S2 corrected pending chosen literal', pending['expected']['chosen'] is None)
pending['expected']['chosen'] = 'first-action'
check('only intended protocol metadata and pending literal changed', normal == v1)
check('all budgets retained', v2['pure_selector_calls'] == 10 and v2['physical_runs'] == 6 and
      v2['total_simulated_duration_s'] == 36 and v2['scheduled_online_decision_calls'] == 21)
for label in ['same_public_pair', 'same_exact_pair', 'same_online_pair']:
    cases = {c['id']: c for c in v2['pure_cases'] + v2['physical_cases']}
    documents = [json.loads(git('cat-file', 'blob', SOURCE + ':' + cases[n]['input'])) for n in v2[label]]
    for d in documents:
        d.get('dispatch_program', d)['policy_program'].pop('policy')
    check('same input pair except policy ' + label, documents[0] == documents[1])

tool = raw('scripts/candidate_delivery.py').decode()
old_tool = git('cat-file', 'blob', BASE + ':scripts/candidate_delivery.py').decode()
for name in ['declared', 'rows', 'close', 'plans', 'check_physical', 'check_pairs', 'check_saved', 'figures', 'append', 'verify']:
    check('unaffected workflow AST ' + name, dump(function(tool, name)) == dump(function(old_tool, name)))
capture = function(tool, 'capture')
old_capture = function(old_tool, 'capture')
outer = next(n for n in capture.body if isinstance(n, ast.Try))
old_outer = next(n for n in old_capture.body if isinstance(n, ast.Try))
check('capture call bodies and stop-on-failure unchanged', [dump(n) for n in outer.body] == [dump(n) for n in old_outer.body] and
      [dump(n) for n in outer.handlers] == [dump(n) for n in old_outer.handlers])
guard = outer.finalbody[0]
check('S1 guard has dedicated exception handler', isinstance(guard, ast.Try) and len(guard.handlers) == 1 and
      ast.unparse(guard.handlers[0].type) == '(OSError, subprocess.SubprocessError)')
handler = guard.handlers[0]
check('S1 guard sets unchanged false and error diagnostic', isinstance(handler.body[0], ast.Assign) and
      ast.unparse(handler.body[0].targets[0]) == "receipt['source_head_and_bytes_unchanged']" and
      isinstance(handler.body[0].value, ast.Constant) and handler.body[0].value.value is False and
      ast.unparse(handler.body[1].targets[0]) == "receipt['source_guard_error']")
check('S1 terminal write follows handled guard', isinstance(outer.finalbody[-1], ast.Expr) and
      isinstance(outer.finalbody[-1].value, ast.Call) and outer.finalbody[-1].value.func.id == 'write')
check('capture no new selector or simulation invocation', sum(isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id == 'choose_work' for n in ast.walk(capture)) == 1 and
      sum(isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id == 'simulate_scenario' for n in ast.walk(capture)) == 1)
check('current tool and preparation select v2 protocol', "PROTOCOL = 'docs/mainline/26-candidate-engineering-protocol-v2.json'" in tool and
      "PROTOCOL = 'docs/mainline/26-candidate-engineering-protocol-v2.json'" in raw('scripts/prepare_candidate_inputs.py').decode())

decision = function(tool, 'check_decision')
coverage = [n for n in ast.walk(decision) if isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id == 'require' and n.args and
            len(n.args) > 1 and isinstance(n.args[1], ast.Constant) and n.args[1].value == 'Compatibility audit must cover every declared belief/value variant exactly once']
check('full coverage assertion exists once', len(coverage) == 1)
condition = coverage[0].args[0]
check('coverage has type cardinality and equality gates', isinstance(condition, ast.BoolOp) and isinstance(condition.op, ast.And) and
      len(condition.values) == 3 and 'len(comparisons) == len(required_pairs)' in ast.unparse(condition) and
      "{(row['belief_variant_id'], row['value_variant_id']) for row in comparisons} == required_pairs" in ast.unparse(condition))
required = next(n for n in ast.walk(decision) if isinstance(n, ast.Assign) and isinstance(n.targets[0], ast.Name) and n.targets[0].id == 'required_pairs')
check('required audit pairs use full Cartesian product', isinstance(required.value, ast.SetComp) and len(required.value.generators) == 2 and
      ast.unparse(required.value.generators[0].iter) == 'belief_variants' and ast.unparse(required.value.generators[1].iter) == "local['variants']")
exact_gate = [n for n in ast.walk(decision) if isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id == 'require' and
              len(n.args) > 1 and isinstance(n.args[1], ast.Constant) and n.args[1].value == 'Shared exact current mass coverage differs']
check('exact mass coverage nonvacuous gate', len(exact_gate) == 1 and isinstance(exact_gate[0].args[0], ast.Compare) and
      isinstance(exact_gate[0].args[0].comparators[0], ast.SetComp))

prechecks = read(PACKAGE + '/pre-capture-v2-tool-checks.json')
check('saved seven tool-only results', len(prechecks['results']) == 7 and all(r['pass'] for r in prechecks['results']) and prechecks['status'] == 'PASS')
check('saved tool-only report source identity', prechecks['source_tool_sha256'] == sha256(raw('scripts/candidate_delivery.py')).hexdigest())
check('saved report declares zero project/full calls', prechecks['new_selector_calls'] == prechecks['new_plant_calls'] == prechecks['new_full_regressions'] == prechecks['registered_research_trials'] == 0)
check('saved missing and mismatch cases retain FAIL', all(r['terminal_status'] == 'FAIL' for r in prechecks['results'] if r['mutation'] in {'source-mismatch', 'missing-pinned-file'}))
fmt = read(PACKAGE + '/pre-capture-v2-format-classification.json')
manifest = raw(PACKAGE + '/pre-capture-v1-preservation/manifest.json')
check('preserved twenty CRLF lines exact', manifest.count(b'\r\n') == fmt['crlf_lines'] == 20 and
      fmt['line_numbers'] == list(range(1, 21)) and sha256(manifest).hexdigest() == fmt['sha256'])
attrs = raw(PACKAGE + '/.gitattributes').decode().splitlines()
check('manifest CRLF exception is one explicit path', sum(line.startswith('pre-capture-v1-preservation/manifest.json ') for line in attrs) == 1 and
      next(line for line in attrs if line.startswith('pre-capture-v1-preservation/manifest.json ')) ==
      'pre-capture-v1-preservation/manifest.json -text whitespace=blank-at-eol,blank-at-eof,space-before-tab,cr-at-eol')
summary = dict(source=SOURCE, base=BASE, checks=len(checks), check_failures=0, findings=0, unresolved=0,
              resolved=['26-D-FROZEN-SPEC-01', '26-D-FROZEN-SPEC-02'], prior_files_unchanged=len(prior),
              project_calls=0, selector_calls=0, assessment_calls=0, simulation_calls=0, test_calls=0,
              inference_calls=0, formal_capture=False, scope='V2_PRE_CAPTURE_TOOL_AND_ORACLE_CORRECTION_STATIC_REVIEW')
(ROOT / 'checks.json').write_text(json.dumps(dict(summary=summary, checks=checks), indent=2) + '\n', encoding='utf-8')
print(json.dumps(summary))
