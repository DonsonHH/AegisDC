"""93b7 protocol supplement. Only AST, static JSON, Fraction and Git/hash reads.

Project code, selectors, assessments, tests and simulations are never imported.
"""
import ast
from copy import deepcopy
from fractions import Fraction as F
from hashlib import sha256
import json
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parent
PARENT = ROOT.parent
REPO = Path(r'C:\Users\Donson\.codex\worktrees\mainline23-intervention\Renly')
SOURCE = '93b7ad992fe233068521c10decc3c85756c806d1'
BASE = '860f0ca39f5e866ad2531466360cc7ce95f64ded'
PACKAGE = 'evidence/mainline/engineering/26-candidate'
checks = []


def check(name, okay, detail=None):
    checks.append(dict(name=name, passed=bool(okay), detail=detail))
    if not okay:
        raise AssertionError(name)


def read(name):
    return json.loads((ROOT / 'export' / name).read_bytes())


def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO)


def ratio(pair):
    return F(*pair)


def document(name):
    return read(PACKAGE + '/reference/' + name + '.json')


def static_function(name):
    tree = ast.parse((ROOT / 'export/scripts/candidate_delivery.py').read_text(encoding='utf-8'))
    return next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == name)


for name, identity in json.loads((ROOT / 'source-pins.json').read_bytes())['exports'].items():
    raw = (ROOT / 'export' / name).read_bytes()
    check('export exact fixed Git blob ' + name, raw == git('cat-file', 'blob', SOURCE + ':' + name) and
          sha256(raw).hexdigest() == identity['sha256'] and len(raw) == identity['bytes'])
for name, expected in json.loads((ROOT / 'prior-sealed-hashes.json').read_bytes()).items():
    check('D sealed artifact unchanged ' + name, sha256((PARENT / name).read_bytes()).hexdigest() == expected)
check('runtime unchanged by frozen tooling', git('diff', '--name-only', BASE, SOURCE, '--', 'src') == b'')
protocol = read('docs/mainline/26-candidate-engineering-protocol.json')
pure = {c['id']: c for c in protocol['pure_cases']}
physical = {c['id']: c for c in protocol['physical_cases']}
check('ten pure cases', len(pure) == len(protocol['pure_cases']) == protocol['pure_selector_calls'] == 10)
check('six six-second physical cases', len(physical) == protocol['physical_runs'] == 6 and all(c['duration_s'] == 6 for c in physical.values()))
check('36 second physical budget', sum(c['duration_s'] for c in physical.values()) == protocol['total_simulated_duration_s'] == 36)
check('21 declared actual online decisions', sum(len(document(name)['dispatch_program']['decision_times_s']) for name in physical) == protocol['scheduled_online_decision_calls'] == 21)
check('unique16 declared references', len(list((ROOT / 'export' / PACKAGE / 'reference').glob('*.json'))) == len(pure) + len(physical) == 16)
for pair in ['same_public_pair', 'same_exact_pair', 'same_online_pair']:
    docs = [deepcopy(document(name)) for name in protocol[pair]]
    for d in docs:
        d.get('dispatch_program', d)['policy_program'].pop('policy')
    check('literal identical pair except policy ' + pair, docs[0] == docs[1])

arithmetic = {}
for name in ['nonadaptive-baseline', 'nonadaptive-candidate', 'informative-candidate',
             'neutral-expiry-boundary', 'exact-baseline', 'exact-candidate']:
    d = document(name);policy = d['policy_program'];options = policy['options']
    local = options['value_model']['question_models'][0]
    expected = pure[name]['expected']
    check('finite six-second consequence law ' + name, options['catalog']['horizon_s'] == 6 and
          all(o['capacity_profile'][0]['start_s'] == 0 and o['capacity_profile'][0]['end_s'] == 6 for o in options['catalog']['outcomes']))
    check('independent forecast timing declarations ' + name,
          local['inspection'] == dict(travel_s=0, wait_s=.25, work_s=1, report_latency_s=.5, cost=1) and
          local['intervention'] == dict(travel_s=0, wait_s=.25, work_s=1, cost=1))
    arithmetic[name] = []
    for variant in options['belief_model']['variants']:
        weights = [F(str(p)) * (1 - F(str(l))) for p, l in zip(variant['prior'], variant['positive_likelihood']['fixed-low-power'])]
        current = [w / sum(weights) for w in weights]
        p = current[1]
        for value_variant in local['variants']:
            law = value_variant['positive_likelihood']
            masses = [F(str(law[h['id']])) for h in options['belief_model']['hypotheses']]
            report = sum(w * l for w, l in zip(current, masses))
            pos = p * masses[1] / report
            neg = p * (1 - masses[1]) / (1 - report)
            # One work second is a full outage; then service is restored.
            direct = 1 + p / 4
            defer = 6 * p
            inspect = report * min(6 * pos, 1 + 2 * pos) + (1 - report) * min(6 * neg, 1 + 2 * neg)
            if name == 'nonadaptive-candidate':
                inspect = min(6 * p, 1 + 2 * p)
            for kind, actual in [('direct_intervention', direct), ('defer', defer), ('inspect_then_act', inspect)]:
                if kind in expected['values']:
                    check('independent literal ' + name + ':' + variant['id'] + ':' + value_variant['id'] + ':' + kind,
                          actual == ratio(expected['values'][kind]))
            if expected.get('positive'):
                check('independent report posterior ' + name + ':' + variant['id'] + ':' + value_variant['id'],
                      pos == ratio(expected['positive']) and neg == ratio(expected['negative']))
            if expected.get('common_exact'):
                check('shared exact current impairment ' + name + ':' + variant['id'], p == ratio(expected['common_exact']))
            arithmetic[name].append(dict(belief_variant=variant['id'], value_variant=value_variant['id'],
                current=[str(x) for x in current], direct=str(direct), defer=str(defer), inspection=str(inspect),
                positive=str(pos), negative=str(neg)))

coarse = pure['coarse-outcome-mismatch']['expected']
check('coarse true posterior literal', ratio(coarse['original_positive']) == F(1, 2) * F(4, 5) / (F(1, 2) * F(4, 5) + F(1, 2) * F(1, 10)) == F(8, 9))
check('coarse unchanged catalog re-mixture literal', ratio(coarse['projected_positive']) == F(11, 15) * F(4, 5) + F(4, 15) * F(1, 5) == F(16, 25))
expiry = pure['nonneutral-expiry-context']['expected']
check('nonneutral forgetting is a real mismatch', ratio(expiry['projected_positive']) == F(8, 11) and ratio(expiry['original_positive']) == F(128, 171) and F(8, 11) != F(128, 171))
for name, case in physical.items():
    d = document(name);program = d['dispatch_program'];expected = case['expected']
    check('public projection equals executor ' + name,
          program['policy_program']['evidence_projection']['inspection_profile'] == program['inspection_program']['profile'] and
          program['policy_program']['evidence_projection']['background_sensor_profile'] == program['sensor_program']['profile'])
    params = {r['id']: r['value'] for r in d['model']['parameters']}
    check('independent service bottleneck ' + name, params['service_demand'] == 1 and params['network_service_capacity'] == .25 and
          expected['demand_service_unit_s'] == 6 and expected['delivered_service_unit_s'] == 6 / 4 and expected['service_deficit_time_s'] == 6 * 3 / 4)
    check('actual filter action with residual ' + name, params['filter_resistance_multiplier'] == 4 and program['intervention_program']['bindings'][0]['setting'] == 2)
    check('no precall closure feedback ' + name, program['closure_program'] is None or program['closure_program']['intervention_feedback'] == [])
    if expected['handheld'] is not None:
        check('work and report independent literal times ' + name,
              expected['work_started_at_s'] == [1.25, 3] and expected['completed_at_s'] == [2.25, 4] and expected['effect_at_s'] == [4])
check('hydraulic preclean ratio', F(150000, 12000000 * 4 + 3000000) == F(1, 340))
check('hydraulic residual ratio', F(150000, 12000000 * 2 + 3000000) == F(1, 180))
missing = document('online-actual-indeterminate')['dispatch_program']
check('actual unsuitable range excludes pre-action flow', missing['inspection_program']['profile']['bindings'][0]['condition_range'] == [0, .01] and F(1, 340) > F(1, 10000))
check('actual indeterminate literal remains missing', physical['online-actual-indeterminate']['expected']['handheld'] == 'missing')
oracles = list((ROOT / 'export' / PACKAGE / 'oracles').glob('*.json'))
check('five independent oracle documents', len(oracles) == 5)
check('no dynamic calls in input preparation function', not any(isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id in
      {'choose_work', 'simulate_scenario', 'assess_action_value', 'infer_belief'} for n in ast.walk(ast.parse((ROOT / 'export/scripts/prepare_candidate_inputs.py').read_text()))))
verify = static_function('verify')
check('saved verification function contains no project entry call', not any(isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id in
      {'choose_work', 'simulate_scenario', 'assess_action_value', 'infer_belief', 'capture'} for n in ast.walk(verify)))

# Finding S1 is a control-flow proof, not a destructive probe.
capture = static_function('capture')
outer = next(n for n in capture.body if isinstance(n, ast.Try))
check('S1 final source guard is unhandled in finally', isinstance(outer.finalbody[0], ast.Assign) and
      isinstance(outer.finalbody[0].value, ast.Call) and isinstance(outer.finalbody[0].value.func, ast.Name) and
      outer.finalbody[0].value.func.id == 'unchanged' and not any(isinstance(n, ast.Try) for n in outer.finalbody))

# Finding S2 is a public resource intersection, no selector execution.
pending = document('pending-issued-inspection')
candidates = {c['id']: c for c in pending['policy_program']['candidates']}
held = {w['worker_id'] for w in candidates['other-inspection']['task']['crew']}
requested = {w['worker_id'] for w in candidates['first-action']['task']['crew']}
check('S2 pending original has no terminal release', pending['history']['issued'] == [dict(candidate_id='other-inspection', issued_at_s=0)] and pending['history']['work_feedback'] == [])
check('S2 requested actor necessarily occupied', held & requested == {'worker_cooling'})
check('S2 incompatible chosen literal is present', pure['pending-issued-inspection']['expected']['chosen'] == 'first-action')

(ROOT / 'arithmetic.json').write_text(json.dumps(arithmetic, indent=2) + '\n', encoding='utf-8')
summary = dict(source=SOURCE, base=BASE, static_checks=len(checks), static_check_failures=0, findings=2,
               unresolved=2, project_calls=0, selector_calls=0, assessment_calls=0, simulation_calls=0,
               test_calls=0, inference_calls=0, formal_capture=False, scope='PRE_CAPTURE_FROZEN_PROTOCOL_REVIEW')
(ROOT / 'checks.json').write_text(json.dumps(dict(summary=summary, checks=checks), indent=2) + '\n', encoding='utf-8')
print(json.dumps(summary))
