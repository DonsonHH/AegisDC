93b7ad99冻结协议补审：发现2项P2，尚不能执行。

1. candidate_delivery.py:342的finally直接调用unchanged；helper:43若读取已移走的固定文件会抛异常，终态receipt写入被跳过。违反协议510的完整失败记账和512的源码守卫要求。应将guard异常写为FAIL并继续保存终态。

2. pending-issued-inspection预期chosen为first-action（协议225），但已发other-inspection且无终态反馈，共用worker_cooling。既有占用门槛必拒绝first-action，应暂缓、chosen=null；不能为了预期删除占用规则。

246项静态/独立分数核对通过，三对输入仅策略名不同，10选择/6运行/36秒/21在线决策预算一致。五份独立见证、真实缺失与预测值边界正确；0项目调用。原D包未改。
