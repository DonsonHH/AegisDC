"""Independent saved351/53f capture review. No project modules or calls.

Only fixed Git blobs, SHA256, JSON, AST and literal Fraction arithmetic are used.
Root tool source is reviewed as captured snapshots; no root acceptance is run.
"""
import ast
from copy import deepcopy
from fractions import Fraction as F
from hashlib import sha256
import json
import math
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parent
PARENT = ROOT.parent
REPO = Path(r'C:\Users\Donson\.codex\worktrees\mainline23-intervention\Renly')
SOURCE = '35193647091f90d17c339976ae47ef69385e9a43'
DATA = '53f09ff4e232ebfac6b64bd6e15bb8649146810b'
CAPTURE = 'evidence/mainline/engineering/26-candidate/capture-20261107-02'
checks = []


def check(name, okay, detail=None):
    checks.append(dict(name=name, passed=bool(okay), detail=detail))
    if not okay:
        raise AssertionError(name)


def read(path):
    return json.loads(path.read_bytes())


def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO)


def digest(raw):
    return sha256(raw).hexdigest()


def read_source(name):
    return read(ROOT / 'source-export' / name)


def rows(path):
    return [json.loads(line) for line in path.read_text(encoding='utf-8').splitlines()]


def close(actual, expected, tolerance=1e-9):
    return type(actual) in (int, float) and math.isfinite(actual) and abs(actual - float(expected)) <= tolerance


def fractions(mapping):
    return {k: F(*v) for k, v in mapping.items()}


def blob_hashes(revision, names):
    names = sorted(names)
    raw = subprocess.check_output(['git', 'cat-file', '--batch'], cwd=REPO,
        input=''.join(revision + ':' + n + '\n' for n in names).encode())
    results = {};offset = 0
    for name in names:
        end = raw.index(b'\n', offset);header = raw[offset:end].split()
        check('Git batch contains declared blob ' + revision[:8] + ':' + name, len(header) == 3 and header[1] == b'blob')
        size = int(header[2]);start = end + 1
        results[name] = digest(raw[start:start + size]);offset = start + size + 1
    check('Git batch exact end ' + revision[:8], offset == len(raw))
    return results


pins = read(ROOT / 'source-pins.json')
for name, item in pins['exports'].items():
    raw = (ROOT / name).read_bytes()
    check('fixed exact exported blob ' + name, digest(raw) == item['sha256'] and len(raw) == item['bytes'] and
          raw == git('cat-file', 'blob', item['revision'] + ':' + item['path']))
for name, item in pins['root_snapshots'].items():
    if item['status'].startswith('COPIED'):
        raw = (ROOT / item['snapshot']).read_bytes()
        check('root tool fixed snapshot ' + name, digest(raw) == item['sha256'] and len(raw) == item['bytes'])
for name, item in pins['root_tool_correction']['files'].items():
    raw = (ROOT / 'root-tool-correction-01' / name).read_bytes()
    check('root correction fixed snapshot ' + name, digest(raw) == item['sha256'] and len(raw) == item['bytes'])
prior = read(ROOT / 'prior-sealed-hashes.json')
for name, expected in prior.items():
    check('prior review remains unchanged ' + name, digest((PARENT / name).read_bytes()) == expected)
check('data commit changes no runtime or author tools', git('diff', '--name-only', SOURCE, DATA, '--', 'src', 'scripts', 'tests') == b'')

protocol = read_source('docs/mainline/26-candidate-engineering-protocol-v2.json')
cap = ROOT / 'export' / CAPTURE
receipt = read(cap / 'receipt.json')
attempt = read(cap / 'attempt.json')
ledger = rows(cap / 'attempts.jsonl')
pure = protocol['pure_cases'];physical = protocol['physical_cases']
all_cases = [('pure', c) for c in pure] + [('physical', c) for c in physical]
declared = set(protocol['durable_root']) | {c['id'] + '/' + n for c in pure for n in protocol['durable_pure']} | {
    c['id'] + '/' + n for c in physical for n in protocol['durable_physical']}
actual = {p.relative_to(cap).as_posix() for p in cap.rglob('*') if p.is_file()}
check('exact 50 durable members plus terminal', len(declared) == 50 and actual == declared | {'receipt.json'} and set(receipt['artifacts']) == declared)
check('all source pins exact role counts', {role: len(items) for role, items in receipt['pinned'].items()} == dict(runtime=67, tools=3, inputs=175, historical_development=10))
combined = {n: h for role in receipt['pinned'].values() for n, h in role.items()}
for revision in [SOURCE, DATA]:
    observed = blob_hashes(revision, combined)
    check('all execution/data pinned blobs agree ' + revision[:8], observed == combined)
for name, expected in receipt['artifacts'].items():
    check('original artifact hash ' + name, digest((cap / name).read_bytes()) == expected)
check('receipt successful finite engineering execution', receipt['status'] == 'PASS' and receipt['execution_commit'] == SOURCE and
      receipt['source_head_and_bytes_unchanged'] and receipt['failures'] == 0 and receipt['validated_cases'] == 16)
check('ten pure six physical complete', receipt['pure_attempts'] == receipt['pure_completed'] == len(pure) == 10 and
      receipt['physical_attempts'] == receipt['physical_completed'] == len(physical) == 6 and receipt['simulated_duration_attempted_s'] == 36)
check('attempt source and declared budget', attempt['execution_commit'] == SOURCE and attempt['declared_selector_calls'] == 10 and
      attempt['declared_physical_runs'] == 6 and attempt['declared_simulated_duration_s'] == 36)
check('32 ledger rows in frozen order', len(ledger) == 32)
for index, (kind, case) in enumerate(all_cases):
    pair = ledger[2 * index:2 * index + 2]
    check('exact actual attempt pair ' + case['id'], [r['status'] for r in pair] == ['STARTED', 'COMPLETED'] and
          all(r['case'] == case['id'] and r['kind'] == kind and r['execution_commit'] == SOURCE for r in pair))
check('no scientific or regression upgrade', receipt['registered_research_trials'] == receipt['llm_calls'] == receipt['training_calls'] == 0 and
      receipt['field_calibration'] == 'PENDING' and receipt['global_regression_gate'] == 'PENDING_ROOT_INTEGRATED_FULL')

pure_results = {};arithmetic = {}
for case in pure:
    name = case['id'];doc = read_source(case['input']);choice = read(cap / name / 'decision.json');pure_results[name] = choice
    comp = read(cap / name / 'computation.json');expected = case['expected']
    alternatives = {a['kind']: a for a in choice['forecast_plans'][0]['alternatives']}
    check('pure choice literal ' + name, choice['chosen_candidate_id'] == expected['chosen'])
    check('pure public clock and identity ' + name, choice['as_of_s'] == doc['frame']['as_of_s'] and choice['facility_id'] == doc['frame']['facility_id'])
    check('pure selection has no execution authority ' + name, not choice['execution_permission'] and not choice['generated_tour'] and not choice['forecast_is_actual_observation'])
    check('measured pure cost and counters ' + name, type(comp['elapsed_ns']) is int and comp['elapsed_ns'] >= 0 and comp['model_evaluations'] == choice['model_evaluations'])
    for kind, expected_ratio in expected['values'].items():
        value = alternatives[kind]['expected_service_deficit_s']
        check('pure value literal ' + name + ':' + kind, value is None if expected_ratio is None else close(value, F(*expected_ratio)))
    if expected.get('classification'):
        audit = choice['prospective_evidence_audit'][0]
        check('pure projection classification ' + name, audit['classification'] == expected['classification'])
        if expected.get('reason'):
            check('unknown reason ' + name, expected['reason'] in audit['reasons'])
        if {'positive', 'negative', 'exact_current', 'projected_positive', 'original_positive'} & set(expected):
            policy = doc['policy_program'];beliefs = policy['options']['belief_model']['variants']
            values = policy['options']['value_model']['question_models'][0]['variants']
            audit_rows = audit['compatibility_by_assumption']
            required = {(b['id'], v['id']) for b in beliefs for v in values}
            check('all declared assumption pairs actual ' + name, len(audit_rows) == len(required) and {(a['belief_variant_id'], a['value_variant_id']) for a in audit_rows} == required)
            for audit_row in audit_rows:
                identifier = name + ':' + audit_row['belief_variant_id'] + ':' + audit_row['value_variant_id']
                if expected.get('positive'):
                    check('exact positive posterior ' + identifier, audit_row['branches']['positive']['projected_outcome_mass']['cooling-limited'] == expected['positive'])
                    check('exact negative posterior ' + identifier, audit_row['branches']['negative']['projected_outcome_mass']['cooling-limited'] == expected['negative'])
                if expected.get('projected_positive'):
                    check('explicit unsupported mixture ' + identifier, audit_row['branches']['positive']['projected_outcome_mass']['cooling-limited'] == expected['projected_positive'] and
                          audit_row['branches']['positive']['original_joint_report_posterior']['cooling-limited'] == expected['original_positive'])
                if expected.get('exact_current') and audit_row['belief_variant_id'] == beliefs[0]['id']:
                    check('pure representation exact current ' + identifier, audit_row['exact_current_outcome_mass']['cooling-limited'] == expected['exact_current'])
        if name == 'nonadaptive-candidate':
            check('all symbolic report classes retained', audit['covered_report_classes'] == ['positive', 'negative', 'threshold_straddled', 'missing'] and
                  audit['marginalization'] == 'SUM_ORIGINAL_REPORT_MASS_PER_JOINT_OUTCOME_EQUALS_ONE' and audit['unchanged_factor_record_ids'] == ['current-power'])
    if name in ['nonadaptive-baseline', 'nonadaptive-candidate', 'informative-candidate', 'neutral-expiry-boundary', 'exact-baseline', 'exact-candidate']:
        pmodel = doc['policy_program']['options'];local = pmodel['value_model']['question_models'][0]
        arithmetic[name] = []
        for b in pmodel['belief_model']['variants']:
            weights = [F(str(p)) * (1 - F(str(l))) for p, l in zip(b['prior'], b['positive_likelihood']['fixed-low-power'])]
            weights = [w / sum(weights) for w in weights];impairment = weights[1]
            for v in local['variants']:
                likelihood = [F(str(v['positive_likelihood'][h['id']])) for h in pmodel['belief_model']['hypotheses']]
                positive_mass = sum(w * l for w, l in zip(weights, likelihood))
                pos = impairment * likelihood[1] / positive_mass;neg = impairment * (1 - likelihood[1]) / (1 - positive_mass)
                inspect = positive_mass * min(6 * pos, 1 + 2 * pos) + (1 - positive_mass) * min(6 * neg, 1 + 2 * neg)
                if name == 'nonadaptive-candidate':inspect = min(6 * impairment, 1 + 2 * impairment)
                for kind, value in [('defer', 6 * impairment), ('direct_intervention', 1 + impairment / 4), ('inspect_then_act', inspect)]:
                    check('independent Fraction prediction ' + name + ':' + b['id'] + ':' + v['id'] + ':' + kind,
                          close(alternatives[kind]['expected_service_deficit_s'], value))
                arithmetic[name].append(dict(belief=b['id'], value=v['id'], current=[str(w) for w in weights], positive=str(pos), negative=str(neg), inspection=str(inspect)))
        if expected.get('common_exact'):
            check('exact basis current variant coverage ' + name, set(choice['valuation_current_outcome_mass_by_belief_variant']) == {b['id'] for b in pmodel['belief_model']['variants']} and
                  all(v['cooling-limited'] == [16, 59] for v in choice['valuation_current_outcome_mass_by_belief_variant'].values()) and
                  choice['model_evaluations']['valuation_exact_belief_context'] == 2)

pending = pure_results['pending-issued-inspection']
check('pending human occupation remains real', pending['chosen_candidate_id'] is None and all(not c['eligible'] for c in pending['candidates']) and
      all('PUBLIC_UNACKNOWLEDGED_RESOURCE_OCCUPATION' in c['reasons'] or 'ALREADY_ISSUED' in c['reasons'] for c in pending['candidates']))
check('independent coarse contrast', F(8, 9) != F(16, 25))
check('independent nonneutral contrast', F(128, 171) != F(8, 11))

runs = {};online_count = 0;trace_count = 0
for case in physical:
    name = case['id'];path = cap / name;run = read(path / 'run.json');runs[name] = run
    doc = read_source(case['input']);expected = case['expected'];decisions = run['policy_public_decisions']
    trace = rows(path / 'private-state.jsonl');balances = rows(path / 'balances.jsonl');trace_count += len(trace);online_count += len(decisions)
    check('actual source identity ' + name, run['code_identity']['git_commit'] == SOURCE and not run['code_identity']['implementation_has_changes'] and
          all(receipt['pinned']['runtime'][n] == h for n, h in run['code_identity']['files'].items()))
    check('actual inputs preserved ' + name, read(path / 'scenario.json') == doc['model'] and run['inputs']['dispatch_program'] == doc['dispatch_program'])
    check('actual choices and decision instants ' + name, [r['frame']['as_of_s'] for r in decisions] == doc['dispatch_program']['decision_times_s'] and
          [r['choice']['chosen_candidate_id'] for r in decisions] == expected['chosen'])
    for index, row in enumerate(decisions):
        now = row['frame']['as_of_s'];choice = row['choice'];identifier = name + ':' + str(now)
        check('actual evidence availability ' + identifier, all(r['observed_at_s'] <= r['arrived_at_s'] <= now for r in row['frame']['evidence']['records']))
        check('actual task feedback availability ' + identifier, all(r['observed_at_s'] <= r['arrived_at_s'] <= now for r in row['history']['work_feedback']))
        check('actual decision shared numeric basis and cost ' + identifier, choice['valuation_mass_basis'] == 'EXACT_FINITE_PUBLIC_BELIEF_CONTEXT_V1' and
              choice['model_evaluations']['valuation_exact_belief_context'] == 2 and run['policy_computation_audit'][index]['model_evaluations'] == choice['model_evaluations'] and
              type(run['policy_computation_audit'][index]['elapsed_ns']) is int and run['policy_computation_audit'][index]['elapsed_ns'] >= 0)
        check('actual forecast window distinct from six-second plant horizon ' + identifier, choice['forecast_window_s'] == [now, now + 6] and
              not choice['execution_permission'] and not choice['forecast_is_actual_observation'] and not choice['generated_tour'])
    work = run['work_records'];effects = run['intervention_private_audit']['events']
    check('actual crew completed timings ' + name, all(w['status'] == 'completed' for w in work) and [w['completed_at_s'] for w in work] == expected['completed_at_s'] and
          [w['work_started_at_s'] for w in work] == expected['work_started_at_s'])
    check('actual effect and residual ' + name, [e['applied_at_s'] for e in effects] == expected['effect_at_s'] and
          all(e['outcome'] == 'APPLIED' and e['old_value'] == 4 and e['new_value'] == 2 and e['parameter_id'] == 'filter_resistance_multiplier' for e in effects))
    check('actual effect authorized at completion ' + name, all(0 <= e['applied_at_s'] < 10 for e in effects))
    check('actual action feedback delayed and no closure ' + name, all(f['arrived_at_s'] == f['observed_at_s'] + .5 and not f['risk_closed'] for f in run['intervention_public_feedback']))
    check('actual continuing sparse polls ' + name, [r['polled_at_s'] for r in run['policy_sensor_private_audit']] == expected['polls'])
    records = run['inspection_public_snapshot']['records']
    if expected['handheld'] is None:
        check('no unperformed inspection reading ' + name, records == [])
    else:
        check('one actual inspection reading ' + name, len(records) == 1)
        record = records[0]
        check('actual handheld provenance and arrival ' + name, (record['observed_at_s'], record['arrived_at_s'], record['provenance']['origin_id']) == (2.25, 2.75, 'post-clean-flow') and
              all(r['source_id'] != 'portable-intake-meter' for r in decisions[1]['frame']['evidence']['records']))
        if expected['handheld'] == 'missing':
            check('actual failure not overwritten by model support ' + name, record['value'] is None and record['availability'] == 'missing' and record['quality']['status'] == 'unknown' and
                  run['inspection_public_feedback'][0]['confirmation'] == 'UNCONFIRMED' and not run['inspection_public_feedback'][0]['current_confirmation'] and
                  run['inspection_private_audit']['events'][0]['disposition'] == 'CONDITION_OUTSIDE_DECLARED_RANGE')
        else:
            check('actual independent initial hydraulic reading ' + name, close(record['value'] ** 2, F(1, 340)))
    if expected.get('closure_pending'):
        check('actual arrived closure pending only ' + name, [d['choice']['question_lifecycle']['questions'][0]['status'] for d in decisions] == ['OPEN_UNCONFIRMED'] * 3 + ['ACTION_COMPLETED_PENDING_VERIFICATION'] and
              not decisions[-1]['choice']['question_lifecycle']['questions'][0]['risk_closed'])
    if expected.get('first_reason'):
        first = decisions[0]['choice'];audit = first['prospective_evidence_audit'][0]
        check('known future fixed report stays unmodeled ' + name, audit['classification'] == 'UNMODELED' and expected['first_reason'] in audit['reasons'] and
              next(a for a in first['forecast_plans'][0]['alternatives'] if a['kind'] == 'inspect_then_act')['expected_service_deficit_s'] is None)
    summary = run['summary']
    check('independent fixed service integrals ' + name, summary['demand_service_unit_s'] == 6 and summary['delivered_service_unit_s'] == F(3, 2) and summary['service_deficit_time_s'] == F(9, 2))
    check('actual paid work matches literal and task intervals ' + name, close(summary['worker_work_person_s'], expected['work_person_s']) and
          sum(F(str(w['completed_at_s'])) - F(str(w['work_started_at_s'])) for w in work) == expected['work_person_s'])
    check('permanent admission envelope ' + name, run['policy_public_resource_ledger']['spent_or_reserved'] == expected['spent'] and not run['policy_public_resource_ledger']['terminal_report_refund'])
    check('complete bounded trace and balances ' + name, len(trace) == len(balances) + 1 and trace[0]['time_s'] == 0 and trace[-1]['time_s'] == 6 and
          all(0 < b['end_s'] - b['start_s'] <= .01 + 1e-9 for b in balances))
    check('each hydraulic point retains residual law ' + name, all(close(point['domains']['facility_cooling']['lake_pump']['volume_flow_m3_s'] ** 2,
          F(150000, 12000000 * (2 if expected['effect_at_s'] and point['time_s'] >= expected['effect_at_s'][0] else 4) + 3000000)) for point in trace))
    check('physical conservation ' + name, abs(summary['whole_run_energy_residual_J']) < 1e-4 and summary['max_mass_residual_kg'] <= 1e-9)
    check('engineering privacy and no gain claim ' + name, run['state_visibility'] == 'PRIVATE_PLANT_EVALUATOR_ONLY' and run['research_trials'] == run['model_calls'] == run['training_calls'] == 0 and
          run['research_gain_claim'] == 'NOT_ESTABLISHED' and run['field_calibration'] == 'PENDING')
    for filename, item in run['artifacts'].items():
        check('run saved member hash ' + name + ':' + filename, digest((path / filename).read_bytes()) == item['sha256'])
check('exact 21 actual online decisions', online_count == protocol['scheduled_online_decision_calls'] == 21)
for pair in ['same_public_pair', 'same_exact_pair', 'same_online_pair']:
    cases = {c['id']: c for _, c in all_cases};documents = [deepcopy(read_source(cases[n]['input'])) for n in protocol[pair]]
    for d in documents:d.get('dispatch_program', d)['policy_program'].pop('policy')
    check('identical frozen pair except name ' + pair, documents[0] == documents[1])
check('same actual baseline and candidate physical trace', (cap / 'online-candidate-inspect/private-state.jsonl').read_bytes() == (cap / 'online-baseline-inspect/private-state.jsonl').read_bytes())

fresh = read(ROOT / 'root-tool-snapshot/26-author-fresh-delivery-01.json')
check('root saved fresh proof identities and counts', fresh['status'] == 'PASS' and fresh['execution'] == SOURCE and fresh['delivery'] == DATA and
      fresh['selector_calls'] == 10 and fresh['physical_runs'] == 6 and fresh['simulated_duration_s'] == 36 and fresh['artifacts'] == 50 and
      fresh['new_selector_calls'] == fresh['new_physical_runs'] == 0)
qa = read(ROOT / 'root-tool-snapshot/visual-review.json');visuals = read(ROOT / 'visual-identities.json')
check('root actual visual review identity', qa['status'] == 'PASS' and qa['source_data_delivery'] == DATA and qa['execution'] == SOURCE and
      qa['actually_viewed_pngs'] == 3 and qa['open_findings'] == 0)
for name, item in qa['files'].items():
    check('render source and PNG identity ' + name, item['svg_sha256'] == digest((cap / (name + '.svg')).read_bytes()) == visuals[name]['svg'] and
          item['png_sha256'] == visuals[name]['png'])

old_verifier = (ROOT / 'root-tool-snapshot/26-verify_packet.py').read_text()
fixed_verifier = (ROOT / 'root-tool-correction-01/26-verify_packet.py').read_text()
fixed_ast = ast.parse(fixed_verifier)
gate_checks = [n for n in ast.walk(fixed_ast) if isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id == 'require' and
               len(n.args) > 1 and isinstance(n.args[1], ast.Constant) and n.args[1].value == 'Root authority differs']
check('packet S3 correction source hash', digest(fixed_verifier.encode()) == 'bd3fe06665b740653b8f7ac6397d8c730f1c54c68adf1a544a81b1b94454465e')
check('packet S3 author/source/data binding fixed', len(gate_checks) == 1 and all(text in ast.unparse(gate_checks[0].args[0]) for text in [
    "gate['author_source'] == author['execution']", "gate['author_data_delivery'] == author['data_delivery']"]))
normalized = fixed_verifier.replace("\n        and gate['author_source'] == author['execution'] and gate['author_data_delivery'] == author['data_delivery']", '')
check('packet correction otherwise same AST', ast.dump(ast.parse(normalized), include_attributes=False) == ast.dump(ast.parse(old_verifier), include_attributes=False))
builder = (ROOT / 'root-tool-snapshot/build_26_root_packet.py').read_text()
check('builder only creates pending authority', "write(ROOT / 'docs/mainline/evidence/26-root.json', gate)" in builder and
      "status='CANDIDATE_PENDING_FRESH_DELIVERY'" in builder and "FRESH_COMMITTED_DELIVERY_VERIFICATION_BEFORE_RESOLVING26" in builder and
      "write(ROOT / 'docs/mainline/progress.json'" not in builder and '.scratch/full-facility-mainline/issues' not in builder)
check('saved packet verifier has no project/simulation call', not any(isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id in
      {'simulate_scenario', 'choose_work', 'assess_action_value', 'infer_belief', 'capture'} for n in ast.walk(fixed_ast)))
runner = ast.parse((ROOT / 'root-tool-snapshot/run_26_root_acceptance.py').read_text())
check('root acceptance script has one acceptance invocation', sum(isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id == 'verify' for n in ast.walk(runner)) == 1)
check('root acceptance source branch clean gate', all(t in ast.unparse(runner) for t in ["'donson/full-facility-mainline'", "git('status', '--porcelain')", "git('rev-parse', 'HEAD')"]))

(ROOT / 'arithmetic.json').write_text(json.dumps(arithmetic, indent=2) + '\n', encoding='utf-8')
summary = dict(status='PASS', execution=SOURCE, data_delivery=DATA, checks=len(checks), check_failures=0,
    capture_findings=0, root_tool_findings_resolved=['26-SAVED-SPEC-ROOT-01'], unresolved=0,
    pure_selector_calls=10, physical_runs=6, physical_duration_s=36, online_decisions=21,
    ledger_rows=32, durable_artifacts=50, runtime_pins=67, tool_pins=3, input_pins=175, history_pins=10,
    trace_points=trace_count, prior_files_unchanged=len(prior), project_calls=0, selector_calls=0,
    assessment_calls=0, simulation_calls=0, test_calls=0, full_calls=0, registered_research_trials=0,
    limitation='Root interrupted-full/second-attempt packaging is a later fixed-tool supplement, not accepted by this snapshot review.')
(ROOT / 'checks.json').write_text(json.dumps(dict(summary=summary, checks=checks), indent=2) + '\n', encoding='utf-8')
print(json.dumps(summary))
