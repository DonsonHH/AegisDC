"""Static correction9ab/bb874, original sealed root/tool/capture evidence untouched."""
import ast
from hashlib import sha256
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PARENT = ROOT.parent
checks = []


def check(name, okay):
    checks.append(dict(name=name, passed=bool(okay)))
    assert okay, name


def tree(name):
    return ast.parse((ROOT / name).read_text())


def functions(parsed):
    return {node.name: node for node in parsed.body if isinstance(node, ast.FunctionDef)}


def literals(parsed):
    return [node.value for node in ast.walk(parsed) if isinstance(node, ast.Constant) and type(node.value) is str]


pins = json.loads((ROOT / 'source-pins.json').read_bytes())
for name, identity in pins['files'].items():
    raw = (ROOT / name).read_bytes()
    check('fixed latest tool ' + name, sha256(raw).hexdigest() == identity['sha256'] and len(raw) == identity['bytes'])
prior = json.loads((ROOT / 'prior-sealed-hashes.json').read_bytes())
for name, expected in prior.items():
    check('original finding package unchanged ' + name, sha256((PARENT / name).read_bytes()).hexdigest() == expected)
builder = tree('build_26_root_packet.py');verifier = tree('26-verify_packet.py')
bs = (ROOT / 'build_26_root_packet.py').read_text();vs = (ROOT / '26-verify_packet.py').read_text()
old_builder = ast.parse((PARENT / 'build_26_root_packet.py').read_text())
old_verifier = ast.parse((PARENT / '26-verify_packet.py').read_text())
for name, func in functions(builder).items():
    if name != 'main':
        check('builder helper unchanged ' + name, ast.dump(func, include_attributes=False) == ast.dump(functions(old_builder)[name], include_attributes=False))
for name, func in functions(verifier).items():
    if name != 'verify':
        check('verifier helper unchanged ' + name, ast.dump(func, include_attributes=False) == ast.dump(functions(old_verifier)[name], include_attributes=False))
check('builder consumes original member manifest', '26-root-full-interruption-01/members.json' in literals(builder))
check('builder consumes original ZIP', '26-root-full-interruption-01/originals.zip' in literals(builder))
member_loop = next(node for node in ast.walk(builder) if isinstance(node, ast.For) and ast.unparse(node.iter) == 'interrupted_members.items()')
loop_text = ast.unparse(member_loop)
check('builder hashes original bytes and sizes', "sha256(original).hexdigest() == identity['sha256']" in loop_text and "len(original) == identity['bytes']" in loop_text)
check('builder compares all old development current bytes', "(regression / name.removeprefix('development/')).read_bytes() == original" in loop_text)
check('verifier consumes original manifests from support', '26-root-full-interruption-01/members.json' in literals(verifier) and '26-root-full-interruption-01/originals.zip' in literals(verifier))
vloop = next(node for node in ast.walk(verifier) if isinstance(node, ast.For) and ast.unparse(node.iter) == 'interrupted_members.items()')
vloop_text = ast.unparse(vloop)
check('verifier checks hash and size of each original', "digest(original) == identity['sha256']" in vloop_text and "len(original) == identity['bytes']" in vloop_text)
check('verifier binds interrupted identity to new root archive', "current_name = 'original/' + name.removeprefix('development/')" in vloop_text and
      "archive_members['root-regression-originals.zip'][current_name] == identity" in vloop_text)
check('nested original ZIP exact unique set required', 'len(interrupted_archive.namelist()) == len(set(interrupted_archive.namelist()))' in vs and
      'set(interrupted_archive.namelist()) == set(interrupted_members)' in vs)
check('actual and committed runtime exact map', "expected_runtime == {name: value for name, value in execution_guard['committed_sources'].items()" in vs and
      "expected_runtime == {name: value for name, value in guard['committed_sources'].items()" in bs)
check('all actual source map keys are committed keys', "set(guard['actual_sources']) == set(identities)" in vs)
check('original conversion map compared exactly', "guard['checkout_classification'] == original_conversions" in vs and
      "digest(original.replace(b'\\n', b'\\r\\n')) == guard['actual_sources'][name]" in vs)
check('lifecycle sources tied to actual tested source', "lifecycle['source'] == lifecycle['second']['source'] == manifest['tested_source']" in vs and
      "observation['source'] == manifest['tested_source']" in vs and "terminal['source'] == manifest['tested_source']" in vs)
check('author source/data authority fix remains', "gate['author_source'] == author['execution']" in vs and "gate['author_data_delivery'] == author['data_delivery']" in vs)
check('interruption not relabeled accepted', "not lifecycle['first']['root_full_pass_proven']" in vs and "not lifecycle['first']['original_terminal_exists']" in vs and
      "not lifecycle['finite_frozen_capture_repeated']" in vs)
check('builder freshgate remains pending only', "status='CANDIDATE_PENDING_FRESH_DELIVERY'" in bs and
      'FRESH_COMMITTED_DELIVERY_VERIFICATION_BEFORE_RESOLVING26' in bs and "write(ROOT / 'docs/mainline/progress.json'" not in bs)
for name, parsed in [('builder', builder), ('verifier', verifier)]:
    check('no project call in corrected tool ' + name, not any(isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id in
          {'simulate_scenario', 'choose_work', 'capture', 'infer_belief', 'assess_action_value'} for node in ast.walk(parsed)))
summary = dict(status='PASS', checks=len(checks), check_failures=0, findings=0, unresolved=0,
               resolves=['26-SAVED-SPEC-LIFECYCLE-01'], prior_sealed_artifacts=len(prior), project_calls=0,
               selector_calls=0, simulation_calls=0, full_calls=0, test_calls=0,
               builder_sha256=pins['files']['build_26_root_packet.py']['sha256'],
               verifier_sha256=pins['files']['26-verify_packet.py']['sha256'],
               scope='FIXED_ROOT_LIFECYCLE_TOOL_CORRECTION_STATIC_ONLY_NOT_PACKET_ACCEPTANCE')
(ROOT / 'checks.json').write_text(json.dumps(dict(summary=summary, checks=checks), indent=2) + '\n', encoding='utf-8')
print(json.dumps(summary))
