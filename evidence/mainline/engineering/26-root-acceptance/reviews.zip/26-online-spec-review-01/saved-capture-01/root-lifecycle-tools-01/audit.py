"""Original27b/d472 lifecycle static review, no project import or execution."""
import ast
from hashlib import sha256
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
checks = []


def check(name, okay):
    checks.append(dict(name=name, passed=bool(okay)))
    assert okay, name


pins = json.loads((ROOT / 'source-pins.json').read_bytes())
for name, item in pins['files'].items():
    if item['status'] == 'EXACT_FIXED_SNAPSHOT':
        path = ROOT / item.get('snapshot', name)
        check('fixed original snapshot ' + name, sha256(path.read_bytes()).hexdigest() == item['sha256'] and path.stat().st_size == item['bytes'])
for name, expected in json.loads((ROOT / 'prior-sealed-hashes.json').read_bytes()).items():
    check('sealed saved capture unchanged ' + name, sha256((ROOT.parent / name).read_bytes()).hexdigest() == expected)
builder = (ROOT / 'build_26_root_packet.py').read_text()
verifier = (ROOT / '26-verify_packet.py').read_text()
for name, text in [('builder', builder), ('verifier', verifier)]:
    tree = ast.parse(text)
    check('no project invocation ' + name, not any(isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id in
          {'choose_work', 'simulate_scenario', 'capture', 'infer_belief', 'assess_action_value'} for node in ast.walk(tree)))
check('pending fresh authority only', "status='CANDIDATE_PENDING_FRESH_DELIVERY'" in builder and
      "FRESH_COMMITTED_DELIVERY_VERIFICATION_BEFORE_RESOLVING26" in builder and "write(ROOT / 'docs/mainline/progress.json'" not in builder)
check('exact runtime set bound in both tools', "attempt['source_files'] == expected_runtime" in builder and "attempt['source_files'] == expected_runtime" in verifier)
check('exact run runtime set bound in both tools', "result['code_identity']['files'] == expected_run_identity" in builder and "run['code_identity']['files'] == expected_run_identity" in verifier)
observation = json.loads((ROOT / 'lifecycle-records/26-root-full-interruption-01/observation.json').read_bytes())
members = json.loads((ROOT / 'lifecycle-records/26-root-full-interruption-01/members.json').read_bytes())
check('interrupted root not accepted or empty', not observation['root_full_pass_proven'] and not observation['summary_exists'] and
      not observation['original_terminal_exists'] and len(observation['cases']) == 18 and observation['development_terminal_counts'] ==
      dict(PHYSICAL_CALL_COMPLETED_NOT_TEST_ACCEPTANCE=7, REJECTED_EXISTING_OUTPUT=1, FAILED=10))
check('1422 original member identities exist', len(members) == observation['archive_members'] == 1422)
check('interruption exact member path is unconsumed', '26-root-full-interruption-01/members.json' not in builder and
      '26-root-full-interruption-01/members.json' not in verifier and '26-root-full-interruption-01/originals.zip' not in verifier)
summary = dict(status='CHANGES_REQUESTED', checks=len(checks), check_failures=0, findings=1, unresolved=1,
               project_calls=0, selector_calls=0, simulation_calls=0, full_calls=0, test_calls=0,
               builder_sha256=pins['files']['build_26_root_packet.py']['sha256'],
               verifier_sha256=pins['files']['26-verify_packet.py']['sha256'])
(ROOT / 'checks.json').write_text(json.dumps(dict(summary=summary, checks=checks), indent=2) + '\n', encoding='utf-8')
print(json.dumps(summary))
