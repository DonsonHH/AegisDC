"""Prepare ticket26 root packet; acceptance waits for fresh committed verification."""
import argparse
from collections import Counter
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parents[1]
WORK = ROOT / '.work'
PACKET = 'evidence/mainline/engineering/26-root-acceptance'


def read(path):
    return json.loads(path.read_bytes())


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x', encoding='utf-8', newline='\n') as stream:
        stream.write(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n')


def files(folder):
    return [path for path in folder.rglob('*') if path.is_file() and '__pycache__' not in path.parts and path.suffix not in {'.pyc', '.pyo'}]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--settings', required=True, type=Path)
    args = parser.parse_args()
    settings = read(args.settings)
    source = settings['source']
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == source
    assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT)
    raw = ROOT / settings['raw']
    summary, guard = read(raw / 'summary.json'), read(raw / 'source-guard.json')
    tests = summary['tests']
    assert summary['overall'] == 'PASS' and tests['executed'] == tests['run'] > 538
    assert tests['skipped'] == tests['failures'] == tests['errors'] == 0 and summary['verified_original_files'] == 20
    assert guard['source_commit_before'] == guard['source_commit_after'] == source and guard['head_unchanged'] and guard['sources_unchanged']
    author = dict(settings['author'])
    capture = ROOT / author['folder']
    saved = read(capture / 'receipt.json')
    assert saved['status'] == 'PASS' and saved['execution_commit'] == author['execution']
    assert saved['pure_attempts'] == saved['pure_completed'] == 10 and saved['physical_attempts'] == saved['physical_completed'] == 6
    assert saved['validated_cases'] == 16 and saved['simulated_duration_attempted_s'] == 36 and saved['failures'] == 0
    author['receipt_sha256'] = digest(capture / 'receipt.json')
    visual_folder = WORK / settings['visual_folder']
    visual_qa = read(visual_folder / 'visual-review.json')
    assert visual_qa['status'] == 'PASS' and visual_qa['actually_viewed_pngs'] == 3 and visual_qa['open_findings'] == 0
    packet = ROOT / PACKET
    assert not packet.exists()
    copies = {'raw/' + name: raw / name for name in ('summary.json', 'tests.log', 'evidence.json', 'source-guard.json')}
    visuals = {}
    for stem in ('actual-online', 'decision-values', 'candidate-boundary'):
        svg = capture / (stem + '.svg')
        png = visual_folder / (stem + '.png')
        assert digest(svg) == digest(visual_folder / svg.name)
        name = 'figures/' + png.name
        copies[name] = png
        visuals[name] = dict(svg=svg.relative_to(ROOT).as_posix(), svg_sha256=digest(svg), png_sha256=digest(png))
    review_files = {}
    for folder_name in settings['review_folders']:
        folder = WORK / folder_name
        for path in files(folder):
            review_files[folder_name + '/' + path.relative_to(folder).as_posix()] = path
    accepted_reviews = []
    for spec in settings['accepted_reviews']:
        path = WORK / spec['path']
        review = read(path)
        unresolved = review.get('unresolved', review.get('unresolved_findings', []))
        assert unresolved in ([], 0) and str(review['status']).startswith('PASS')
        count = review.get('checks', review.get('checks_passed', review.get('evidence', {}).get('checks')))
        assert type(count) is int and count > 0
        accepted_reviews.append(dict(axis=spec['axis'], checks=count, unresolved=0,
            member=spec['path'], sha256=digest(path), scope=spec['scope']))
    support = {name: WORK / name for name in settings['support']}
    support['visual-review.json'] = visual_folder / 'visual-review.json'
    support['packet-settings.json'] = args.settings
    support['packet-builder.py'] = Path(__file__)
    regression = WORK / '26-online-development'
    regression_members = {'original/' + path.relative_to(regression).as_posix(): path for path in files(regression)}
    assert regression_members
    terminal_counts = Counter()
    regression_attempts = []
    expected_runtime = {name: value for name, value in guard['actual_sources'].items()
        if name.startswith('src/') and name.endswith('.py')}
    assert expected_runtime == {name: value for name, value in guard['committed_sources'].items()
        if name.startswith('src/') and name.endswith('.py')}
    expected_run_identity = {name: value for name, value in expected_runtime.items()
        if name.startswith('src/aegis_dc/') or name == 'src/patrol_rsi/contracts.py'}
    for folder in sorted(path for path in regression.iterdir() if path.is_dir()):
        attempt, terminal = read(folder / 'attempt.json'), read(folder / 'terminal.json')
        assert attempt['source_commit'] == source
        assert attempt['source_files'] == expected_runtime
        terminal_counts[terminal['status']] += 1
        for name, expected in attempt['source_files'].items():
            assert digest(folder / 'runtime-source' / name) == expected
        if (folder / 'original/run.json').exists():
            result = read(folder / 'original/run.json')
            assert result['code_identity']['git_commit'] == source and not result['code_identity']['implementation_has_changes']
            assert result['code_identity']['files'] == expected_run_identity
            assert read(folder / 'model.json') == read(folder / 'original/scenario.json')
            assert read(folder / 'dispatch-program.json') == result['inputs']['dispatch_program']
        regression_attempts.append(dict(case=folder.name, terminal_status=terminal['status'], source=source))
    interruption = read(WORK / '26-root-full-interruption-01/observation.json')
    assert interruption['source'] == source and not interruption['root_full_pass_proven']
    old_cases = {row['case'] for row in interruption['cases']}
    regression_cases = {row['case'] for row in regression_attempts}
    assert old_cases <= regression_cases
    interrupted_members = read(WORK / '26-root-full-interruption-01/members.json')
    with zipfile.ZipFile(WORK / '26-root-full-interruption-01/originals.zip') as interrupted_archive:
        assert set(interrupted_archive.namelist()) == set(interrupted_members)
        for name, identity in interrupted_members.items():
            original = interrupted_archive.read(name)
            assert sha256(original).hexdigest() == identity['sha256'] and len(original) == identity['bytes']
            if name.startswith('development/'):
                assert (regression / name.removeprefix('development/')).read_bytes() == original
    new_cases = regression_cases - old_cases
    assert new_cases and not old_cases & new_cases
    pass_launch = WORK / '26-root-full-launch-02'
    pass_attempt, pass_terminal = read(pass_launch / 'attempt.json'), read(pass_launch / 'terminal.json')
    assert pass_attempt['source'] == pass_terminal['source'] == source
    assert pass_terminal['status'] == 'COMPLETED' and pass_terminal['returncode'] == 0
    assert pass_terminal['summary_exists']
    assert digest(pass_launch / 'stdout.txt') == pass_terminal['stdout_sha256']
    assert digest(pass_launch / 'stderr.txt') == pass_terminal['stderr_sha256']
    regression_lifecycle = dict(classification='TWO_ROOT_FULL_ATTEMPTS_WITH_ONE_INTERRUPTED_AND_ONE_COMPLETED',
        source=source, full_attempts=2, fully_accepted_runs=1, interrupted_runs=1,
        first=dict(status=interruption['status'], root_full_pass_proven=False,
            summary_exists=interruption['summary_exists'], original_terminal_exists=interruption['original_terminal_exists'],
            observed_case_directories=sorted(old_cases), terminal_counts=interruption['development_terminal_counts'],
            observation_sha256=digest(WORK / '26-root-full-interruption-01/observation.json')),
        second=dict(status=pass_terminal['status'], returncode=0, source=source, raw=settings['raw'],
            new_case_directories=sorted(new_cases), attempt_sha256=digest(pass_launch / 'attempt.json'),
            terminal_sha256=digest(pass_launch / 'terminal.json')),
        finite_frozen_capture_repeated=False, root_fixtures_not_effect_trials=True)
    for row in regression_attempts:
        row['root_full_attempt'] = '01_INTERRUPTED' if row['case'] in old_cases else '02_COMPLETED'
    declared = sorted(set(copies) | {'.gitattributes', 'README.md', 'declaration.json', 'source-manifest.json',
        'archive-members.json', 'reviews.zip', 'support.zip', 'root-regression-originals.zip', 'root-regression-lifecycle.json', 'verify_packet.py'})
    write(packet / 'declaration.json', dict(artifacts=declared, terminal_receipt='receipt.json',
        cache_classification='__pycache__, pyc and pyo are runtime caches, not delivered evidence'))
    for name, path in copies.items():
        target = packet / name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(path.read_bytes())
    attrs = ['# Preserve exact native root execution logs; retain other whitespace checks.']
    for name, path in copies.items():
        if name.startswith('raw/') and b'\r\n' in path.read_bytes():
            attrs.append(name + ' -text whitespace=blank-at-eol,blank-at-eof,space-before-tab,cr-at-eol')
    (packet / '.gitattributes').write_text('\n'.join(attrs) + '\n', encoding='utf-8', newline='\n')
    archives = {}
    for name, members in (('reviews.zip', review_files), ('support.zip', support), ('root-regression-originals.zip', regression_members)):
        archives[name] = {}
        with zipfile.ZipFile(packet / name, 'x', zipfile.ZIP_DEFLATED) as archive:
            for member, path in sorted(members.items()):
                raw_bytes = path.read_bytes()
                archive.writestr(member, raw_bytes)
                archives[name][member] = dict(sha256=sha256(raw_bytes).hexdigest(), bytes=len(raw_bytes))
    write(packet / 'archive-members.json', archives)
    write(packet / 'root-regression-lifecycle.json', regression_lifecycle)
    manifest = dict(tested_source=source, author=author, development=dict(
        folder='evidence/mainline/engineering/26-candidate/development-originals-20261107-01',
        attempt_directories=30, known_completed=16, error_terminals=12, overwrite_refusals=1, unknown=1,
        historical_input_or_tool_gap_cases=26), visuals=visuals, visual_review=visual_qa, reviews=accepted_reviews,
        root_regression_original_members=len(regression_members), root_regression_attempts=regression_attempts,
        root_regression_terminal_counts=dict(terminal_counts), root_regression_scope='SEPARATE_ENGINEERING_TEST_FIXTURES_NOT_FORMAL_CAPTURE_BUDGET',
        root_full_attempts=2, root_full_completed=1, root_full_interrupted=1,
        selector_calls=10, physical_runs=6, simulated_duration_s=36, scheduled_online_decisions=21,
        registered_research_trials=0, field_calibration='PENDING', overall_goal='ACTIVE')
    write(packet / 'source-manifest.json', manifest)
    (packet / 'verify_packet.py').write_bytes((WORK / '26-verify_packet.py').read_bytes())
    body = f'''# 第26项根证据包：检查、直接处置与暂缓

实际集成源 `{source}` 完成 {tests['executed']} 项回归，零失败、零错误、零跳过；20份历史原件及{len(guard['actual_sources'])}份Python/JSON源码身份核对通过。此包接受还待干净Git交付复核；当前不是完整研究目标完成。

![实际在线执行、流量、服务与工时](figures/actual-online.png)

候选在同一个八域合成设施中运行。10次独立公开选择及6次各6秒的实际设施运行全部保存，另有21个预定在线决策。检查在2.25秒采样、2.75秒到达，后续处置4秒完成、4.5秒反馈到达；滤阻4降至2，流量平方由1/340升至1/180。网络0.25仍是服务瓶颈：六个工况需求均6、交付1.5、缺额4.5。人员实际工作分别为0、1或2人秒；这些结果不构成方法优越性。

![公开模型预测及共同数值口径](figures/decision-values.png)

模型价值与实际结果分别展示。同一输入仅更换策略名称；两种价值策略共享概率、损失、人员工具及精确数值口径。当前候选检验预期报告是否会进入现有证据更新，允许检查、直接处置和暂缓。迟到或无法建模的报告保持未知，实际不适用测量保持缺失；错误认识造成的暂缓仍保留真实服务缺额。

![公共决策与私有执行架构](figures/candidate-boundary.png)

实际状态和误差实现留在设施执行器。调度只读到时证据及静态声明；固定测点持续轮询，处置完成保持待复检。原V1协议未执行，审阅发现的两处验证工具缺陷和一个占用资源预期错误已通过显式V2修订处理；原V1源码、发现和协议保留。

开发的30个原调用目录另封存：16次确定完成、12次错误终态、1次覆盖拒绝、1次结果未知，26项历史输入/工具缺口明列。根完整回归共两次尝试：首次工具中断，没有终态与完整报告，已产生的18个在线夹具目录保留；第二次在同一源码新目录完成本页所述完整回归。两次根夹具原件及中断观察分别记账，不并入10/6/36冻结工程预算。所有失败与未知状态保持。

正式原件：`{author['folder']}`；执行源 `{author['execution']}`。本包含全部两轴审阅、源码守卫、实际运行日志、三张实际渲染并观看的图以及保存交付验证器。运行 `verify_packet.py --delivery-commit <commit> --output <new-json>` 只读保存字节和Git，不重跑设施或选择。

第27项跨系统闭环和第28项完整负例仍待执行，M4尚未完成。第30项前不运行效果研究，第38项前不启动AI/RSI；现场标定PENDING，完整研究目标持续active。
'''
    (packet / 'README.md').write_text(body, encoding='utf-8', newline='\n')
    actual = {path.relative_to(packet).as_posix() for path in files(packet)}
    assert actual == set(declared)
    write(packet / 'receipt.json', dict(status='CANDIDATE_PENDING_FRESH_DELIVERY',
        artifacts={name: digest(packet / name) for name in declared}, tested_source=source, registered_research_trials=0))
    gate = dict(status='CANDIDATE_PENDING_FRESH_DELIVERY', ticket='26', milestone='M4',
        actual_root_source=source, author_source=author['execution'], author_data_delivery=author['data_delivery'],
        root_tests=tests, guarded_files=len(guard['actual_sources']), historical_originals=20,
        packet=PACKET, packet_receipt_sha256=digest(packet / 'receipt.json'),
        remaining_gate='FRESH_COMMITTED_DELIVERY_VERIFICATION_BEFORE_RESOLVING26',
        registered_research_trials=0, field_calibration='PENDING', overall_goal='ACTIVE')
    write(ROOT / 'docs/mainline/evidence/26-root.json', gate)
    print(json.dumps(dict(status=gate['status'], packet_artifacts=len(declared),
        root_tests=tests, archive_members=sum(len(members) for members in archives.values()),
        root_regression_originals=len(regression_members)), ensure_ascii=False))


if __name__ == '__main__':
    main()
