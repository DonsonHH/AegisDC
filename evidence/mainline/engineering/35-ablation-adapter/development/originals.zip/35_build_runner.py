from pathlib import Path
root=Path(__file__).resolve().parents[1]
old=(root/'scripts/registered_confirmation.py').read_text(encoding='utf-8')
capture=old[old.index('def capture('):old.index('\ndef main():')]
capture=capture.replace("from aegis_dc.plant import simulate_scenario","from ablation_planner import simulate_masked, audit_document")
capture=capture.replace("result=simulate_scenario(program['model'],duration_s=program['duration_s'],\n                    step_s=program['maximum_step_s'],boundary_events=program['boundary_events'],\n                    dispatch_program=program['dispatch_program'])","result=simulate_masked(program)")
capture=capture.replace("_save_native(stage/f'{index:02}',folder_slot,program,result,source)","_save_native(stage/f'{index:02}',folder_slot,audit_document(program),result,source)")
require_old="held_inputs_read=len(originals),held_seed_reads=1"
assert require_old in capture
header='''"""Run the32 preregistered ablation slots with unchanged private physical execution."""
import argparse,json,sys
from pathlib import Path
from comparison_release import ROOT,LOCK,PROTOCOL,audit_release,audit_lock
from inspection_delivery import read,require,git,hashes,digest,durable,write
from development_journal import append as journal_append,write_record as journal_write,reconcile as reconcile_journal
from registered_development import _guard,_save_native
from prepare_ablation import verify,PREP,EXECUTION_LOCK,EXTENSION
PHASE='ablation'
PACKAGE='evidence/mainline/research/35-ablation'
RUNBOOK='docs/mainline/35-ablation-execution.json'
AUTHORIZATION='docs/mainline/evidence/35-execution-authorization.json'
def head():return git('rev-parse','HEAD').decode().strip()

def load_roster():
    verify();plan=read(ROOT/PROTOCOL);phase=plan['phases'][PHASE];prepared=read(ROOT/PREP/'receipt.json')
    originals,slots={},[]
    for world in phase['worlds']:
        arms=phase['arms'];shift=(world['slot']-1)%len(arms)
        for arm in arms[shift:]+arms[:shift]:
            name=world['id']+'/'+arm+'.json';raw=(ROOT/PREP/'inputs'/name).read_bytes()
            require(digest(raw)==prepared['input_hashes'][name],'Frozen ablation input differs')
            originals[name]=raw
            slots.append(dict(index=len(slots)+1,world_id=world['id'],family=world['family'],arm=arm,
                duration_s=world['duration_s'],scheduled_decisions=len(plan['decision_times_s']),input_member=name,input_sha256=digest(raw)))
    return plan,slots,originals

def _begin(folder,stage,source,plan,slots):
    require(head()==source and not git('status','--porcelain'),'Use clean exact ablation execution checkout')
    require(folder==ROOT/PACKAGE/'capture-01' and stage==ROOT/'.work/35-ablation-native-01'
        and not folder.exists() and not stage.exists(),'Use unique original ablation output paths')
    progress=read(ROOT/'docs/mainline/progress.json')
    require(progress['current_ticket']=='35' and progress['research_trials']['ablation']['attempts']==0,'Wrong frontier or ablation already attempted')
    authorization=read(ROOT/AUTHORIZATION)
    require(authorization['status']=='REVIEWED_TO_EXECUTE' and authorization['execution_lock']==EXECUTION_LOCK
        and authorization['execution_lock_sha256']==digest((ROOT/EXECUTION_LOCK).read_bytes()),'Missing exact independent ablation authorization')
    book=read(ROOT/RUNBOOK);nonce=Path(book['nonce_directory'])/'ablation.bin'
    audit_release(PHASE,'execute',ROOT/LOCK,nonce,ROOT/PREP/'inputs',folder)
    require(sys.dont_write_bytecode and sys.pycache_prefix is not None and not Path(sys.pycache_prefix).exists(),'Use -B and unused cache prefix')
    names=set(read(ROOT/EXECUTION_LOCK)['execution_pins'])|set(read(ROOT/LOCK)['pins'])
    names.update({RUNBOOK,LOCK,PROTOCOL,EXTENSION,EXECUTION_LOCK,AUTHORIZATION,'docs/mainline/evidence/34-root.json'})
    names.update((ROOT/PREP/n).relative_to(ROOT).as_posix() for n in set(read(ROOT/PREP/'receipt.json')['artifacts'])|{'receipt.json'})
    pins=hashes(source,names);_guard(source,pins);folder.mkdir(parents=True);stage.mkdir(parents=True)
    write(folder/'batch.json',dict(schema='aegisdc-registered-ablation-batch-v1',phase=PHASE,
        classification='REGISTERED_INDEPENDENT_MECHANISM_ABLATION',execution_commit=source,pins=pins,slots=slots,
        budget=plan['phases'][PHASE]['budget'],protocol_sha256=digest((ROOT/PROTOCOL).read_bytes()),
        design_lock_sha256=digest((ROOT/LOCK).read_bytes()),interpreter_sha256=digest(Path(sys.executable).read_bytes()),
        unused_cache_prefix=True,automatic_retries=0,phase_nonce_commitment=read(ROOT/LOCK)['commitments_sha256'][PHASE]))
    return pins

'''
main=old[old.index('def main():'):].replace('PASS_CONFIRMATION_ROSTER_ONLY','PASS_ABLATION_ROSTER_ONLY')
with (root/'scripts/registered_ablation.py').open('x',encoding='utf-8',newline='\n') as f:f.write(header+capture+main)
print('Created additive ablation capture; inherited tested append-only accounting unchanged.')
