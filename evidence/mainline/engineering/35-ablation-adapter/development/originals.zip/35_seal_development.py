import hashlib,json
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
root=Path(__file__).resolve().parents[1];out=root/'evidence/mainline/engineering/35-ablation-adapter/development';out.mkdir()
names=['35-public-mask-red-01.log','35-public-mask-green-01.log','35-public-mask-green-02.log',
       '35-public-mask-green-03.log','35-public-mask-green-04.log','35-engineering-fixture-01.log',
       '35_build_runner.py','35_seal_development.py']
files={n:(root/'.work'/n).read_bytes() for n in names}
with ZipFile(out/'originals.zip','x',compression=ZIP_DEFLATED) as z:
    for n,b in sorted(files.items()):z.writestr(n,b)
sha=lambda b:hashlib.sha256(b).hexdigest()
value=dict(schema='aegisdc-mask-development-originals-v1',archive_sha256=sha((out/'originals.zip').read_bytes()),
    members={n:sha(b) for n,b in sorted(files.items())},
    scope='Unfrozen public CLI red/green development and one separately frozen3s interface witness, not effect trials.',
    original_failed_tests=['35-public-mask-red-01.log','35-public-mask-green-01.log'],
    successful_public_test_calls=3,public_selectors_per_success=1,development_physical_calls=0,
    engineering_witness_source='62856b3936a84f48d600258fe6fe0267b593dad8',engineering_witness_calls=1,
    engineering_witness_simulated_s=3,registered_ablation_runs=0,nonce_reads=0,
    note='Original development filenames and failed content are retained. Later private submission mapping is independently source-reviewed; the old witness was not rerun.')
(out/'manifest.json').write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(dict(status='DEVELOPMENT_AND_SINGLE_ENGINEERING_WITNESS_PRESERVED',members=len(files))))
