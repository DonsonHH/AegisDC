import {spawn} from 'node:child_process';
import {existsSync,readFileSync,writeFileSync,mkdirSync} from 'node:fs';
import {resolve,join} from 'node:path';
import {pathToFileURL} from 'node:url';
const base=resolve('evidence/mainline/research/checkpoint35'),qa=join(base,'qa');mkdirSync(qa);
const profile=resolve('.work/checkpoint35-cdp-01'),portFile=join(profile,'DevToolsActivePort');
if(existsSync(profile))throw Error('Use a fresh QA browser profile');
const browser=spawn('C:/Program Files/Google/Chrome/Application/chrome.exe',[
  '--headless=new','--disable-gpu','--disable-background-networking','--no-first-run','--no-default-browser-check',
  '--remote-debugging-port=0','--remote-debugging-address=127.0.0.1','--user-data-dir='+profile,'about:blank'],{windowsHide:true,stdio:'ignore'});
const wait=ms=>new Promise(r=>setTimeout(r,ms));let ws;
try{
 for(let i=0;i<70&&!existsSync(portFile);i++)await wait(100);
 const port=readFileSync(portFile,'utf8').split(/\r?\n/)[0];
 const tabs=await(await fetch('http://127.0.0.1:'+port+'/json/list')).json();
 ws=new WebSocket(tabs.find(t=>t.type==='page').webSocketDebuggerUrl);
 await new Promise((r,j)=>{ws.addEventListener('open',r,{once:true});ws.addEventListener('error',j,{once:true})});
 let id=0;const pending=new Map(),events=new Map(),errors=[];
 ws.addEventListener('message',ev=>{const m=JSON.parse(ev.data);if(m.id){const p=pending.get(m.id);if(p){pending.delete(m.id);m.error?p.reject(m.error):p.resolve(m.result)}}
   else if(m.method==='Runtime.exceptionThrown')errors.push(m.params.exceptionDetails.text);
   else if(events.has(m.method)){events.get(m.method)(m.params);events.delete(m.method)}});
 const call=(method,params={})=>new Promise((r,j)=>{const next=++id;pending.set(next,{resolve:r,reject:j});ws.send(JSON.stringify({id:next,method,params}))});
 const evaluate=async expression=>{const r=await call('Runtime.evaluate',{expression,awaitPromise:true,returnByValue:true});if(r.exceptionDetails)throw Error(JSON.stringify(r));return r.result.value};
 const shot=async name=>{const s=await call('Page.captureScreenshot',{format:'png',fromSurface:true});writeFileSync(join(qa,name),Buffer.from(s.data,'base64'),{flag:'wx'})};
 await call('Page.enable');await call('Runtime.enable');const results=[];
 for(const[name,width,height,mobile]of[['desktop',1440,1100,false],['phone',412,1050,true],['wide',1920,1200,false]]){
  await call('Emulation.setDeviceMetricsOverride',{width,height,deviceScaleFactor:1,mobile,screenWidth:width,screenHeight:height});
  const loaded=new Promise(r=>events.set('Page.loadEventFired',r));
  await call('Page.navigate',{url:pathToFileURL(join(base,'AegisDC-35-阶段研究成果.html')).href});await Promise.race([loaded,wait(3500)]);
  const facts=await evaluate(`(async()=>{await document.fonts.ready;await Promise.all([...document.images].map(i=>i.decode()));return{viewport:innerWidth,clientWidth:document.documentElement.clientWidth,pageWidth:document.documentElement.scrollWidth,images:[...document.images].map(i=>i.naturalWidth),pairs:document.querySelectorAll('#pairs tbody tr').length,downloads:document.querySelectorAll('a[download]').length,externalRuntime:document.querySelectorAll('script[src],link[rel=stylesheet],iframe').length}})()`);
  if(facts.viewport!==width||facts.pageWidth!==facts.clientWidth||facts.images.length!==9||facts.images.some(v=>!v)||facts.pairs!==16||facts.downloads!==13||facts.externalRuntime!==0)throw Error('Layout:'+JSON.stringify(facts));
  if(name!=='wide')await shot(name+'-top.png');
  await evaluate(`document.getElementById('primary').scrollIntoView();true`);await wait(100);
  if(name!=='wide')await shot(name+'-primary.png');
  const interactions=await evaluate(`(()=>{const details=document.querySelector('details');details.open=true;const s=document.getElementById('family');s.value='network-restorable';s.dispatchEvent(new Event('change'));const filtered=[...document.querySelectorAll('#pairs tbody tr')].filter(r=>!r.hidden).length;s.value='all';s.dispatchEvent(new Event('change'));const restored=[...document.querySelectorAll('#pairs tbody tr')].filter(r=>!r.hidden).length;details.open=false;document.querySelector('#primary [data-zoom]').click();return{filtered,restored,zoomOpen:document.getElementById('zoom').open}})()`);
  if(interactions.filtered!==4||interactions.restored!==16||!interactions.zoomOpen)throw Error('Interaction:'+JSON.stringify(interactions));
  await evaluate(`(async()=>{await document.querySelector('#zoom img').decode();return true})()`);
  if(name==='phone')await shot('phone-zoom.png');
  await evaluate(`document.getElementById('zoom-close').click();window.scrollTo(0,0);true`);
  results.push({name,...facts,...interactions});
 }
 if(errors.length)throw Error('JavaScript:'+errors.join(','));
 writeFileSync(join(qa,'responsive-qa.json'),JSON.stringify({status:'PASS_THREE_VIEWPORTS_AND_READING_CONTROLS',results,javascript_errors:errors,physical_calls:0,selector_calls:0},null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify({status:'PASS_THREE_VIEWPORTS_AND_READING_CONTROLS',viewports:results.map(r=>[r.name,r.viewport]),images:9,downloads:13}));ws.close();
}finally{browser.kill()}
