"""Draw the implemented information boundary, independently of experiment outcomes."""
import hashlib,json,subprocess,sys
from pathlib import Path
sys.path.insert(0,'C:/Users/Donson/Documents/ChatGPT/Renly/.work/paper-writing-deps')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch,FancyArrowPatch
from matplotlib import font_manager
root=Path(__file__).resolve().parents[1]
out=root/'.work/checkpoint35-architecture-02';out.mkdir()
font=Path('C:/Windows/Fonts/msyh.ttc');font_manager.fontManager.addfont(str(font))
plt.rcParams.update({'font.family':font_manager.FontProperties(fname=str(font)).get_name(),
    'svg.fonttype':'path','svg.hashsalt':'aegisdc-checkpoint35'})
navy,teal,muted='#183449','#087f79','#536d80'
fig,ax=plt.subplots(figsize=(13.6,9.2),facecolor='#f7fafc');ax.set(xlim=(0,14),ylim=(0,9.2));ax.axis('off')
def box(x,y,w,h,text,edge='#9bb4c5',face='white',size=11,weight='normal'):
    ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0.03,rounding_size=.08',
        linewidth=1.4,edgecolor=edge,facecolor=face))
    ax.text(x+w/2,y+h/2,text,ha='center',va='center',fontsize=size,color=navy,weight=weight,linespacing=1.6)
def arrow(a,b,text=None,color=teal,connection='arc3'):
    ax.add_patch(FancyArrowPatch(a,b,arrowstyle='-|>',mutation_scale=13,lw=1.7,color=color,connectionstyle=connection))
    if text:
        vertical=abs(a[0]-b[0])<.01
        ax.text((a[0]+b[0])/2+(.18 if vertical else 0),
                (a[1]+b[1])/2+(0 if vertical else .12),text,
                ha='left' if vertical else 'center',va='center' if vertical else 'baseline',fontsize=9,color=color)
ax.text(.35,8.72,'完整设施中的核查、处置与独立评价',fontsize=23,color=navy,weight='bold')
ax.text(.35,8.24,'八个行为域共同运行；调度只使用到时证据，评价器独立核对实际结果。',fontsize=12,color=muted)
box(.4,2.65,6.0,5.15,'',face='#edf3f8')
ax.text(.7,7.42,'设施与实际执行',fontsize=15,weight='bold',color=navy)
labels=['供配电','后备能源','设施冷却','设备冷却与房间','计算、网络、存储','本地控制与保护','空间与访问','专业人员与工具']
for i,label in enumerate(labels):box(.75+(i%2)*2.8,6.37-(i//2)*.84,2.55,.65,label,size=11)
ax.text(.75,3.34,'四类关系共用实体身份',fontsize=11,weight='bold',color=navy)
ax.text(.75,2.96,'物理  /  功能依赖  /  控制与信息  /  人员访问',fontsize=10,color=muted)
box(7.6,6.38,5.9,1.15,'设计与资产、历史与工单、人工报告\n稀疏固定测点、现场手持测量',edge=teal,face='#eaf7f4',size=12)
ax.text(7.62,7.75,'调度可用信息',fontsize=15,color=teal,weight='bold')
box(7.6,4.54,5.9,1.08,'证据账与风险认识\n到达时刻、质量、同源关系、剩余疑点',edge=teal,face='#eaf7f4',size=12)
box(7.6,2.65,5.9,1.12,'核查 / 直接处置 / 暂缓\n能力、工具、路径、授权和时间约束',edge=teal,face='#eaf7f4',size=12)
arrow((10.55,6.38),(10.55,5.64))
arrow((10.55,4.54),(10.55,3.79))
arrow((6.45,6.94),(7.55,6.94),'已到达记录')
arrow((7.55,3.18),(6.45,3.18),'派工',color='#3156a3')
box(.4,.55,13.1,1.42,'',edge='#3156a3',face='#edf1fb')
ax.text(.74,1.53,'独立评价与完整原件账',fontsize=14,color=navy,weight='bold')
ax.text(.74,1.05,'相同外生条件与权限  →  冻结方法比较  →  服务缺额 / 人工与工具成本 / 硬约束',fontsize=11,color=navy)
ax.text(.74,.72,'保存输入、执行源、STARTED与终态、私有轨迹和平衡账；失败保留，评价结果不返给调度。',fontsize=10,color=muted)
arrow((3.25,2.61),(3.25,2.02),'实际轨迹',color='#3156a3')
arrow((10.55,2.61),(10.55,2.02),'决策与作业记录',color='#3156a3')
fig.subplots_adjust(left=.02,right=.99,top=.99,bottom=.02)
for suffix in ('png','svg'):fig.savefig(out/('35-facility-and-evaluation-architecture.'+suffix),dpi=165,
    metadata={'Creator':'AegisDC','Date':None} if suffix=='svg' else {'Software':'AegisDC'})
plt.close(fig)
sources=['src/aegis_dc/plant.py','src/aegis_dc/evidence_ledger.py','src/aegis_dc/decision_view.py',
    'src/aegis_dc/policy_execution.py','docs/MAINLINE.md','docs/mainline/30-comparison-protocol-v1.json']
sha=lambda b:hashlib.sha256(b).hexdigest()
manifest=dict(scope='Implemented architecture; no outcome or scientific gain encoded.',
    source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
    sources={n:sha((root/n).read_bytes()) for n in sources},authoring_sha256=sha(Path(__file__).read_bytes()),
    font_sha256=sha(font.read_bytes()),matplotlib=matplotlib.__version__,physical_calls=0,selector_calls=0,
    artifacts={p.name:sha(p.read_bytes()) for p in out.iterdir()})
(out/'architecture-source.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(dict(status='ARCHITECTURE_RENDERED',artifacts=2)))
