"""Seal a reading deliverable; no facility/selector/seed calls."""
import hashlib,json,zipfile
from datetime import datetime,timezone
from pathlib import Path
root=Path(__file__).resolve().parents[1]
out=root/'evidence/mainline/research/checkpoint35'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
write=lambda p,d:p.open('x',encoding='utf-8',newline='\n').write(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
html=out/'AegisDC-35-阶段研究成果.html'
shots=['desktop-top.png','desktop-primary.png','phone-top.png','phone-primary.png','phone-zoom.png']
write(out/'qa/visual-review.json',dict(status='PASS_ACTUALLY_VIEWED_FIVE_SCREENSHOTS',reviewer='/root',reviewed_utc=datetime.now(timezone.utc).isoformat(),html_sha256=sha(html.read_bytes()),screenshots={s:sha((out/'qa'/s).read_bytes()) for s in shots},observed=['Desktop title, results, plot labels and reading order are legible.','Phone text reflows and the page has no horizontal overflow.','Phone plot enlargement opens an intentionally scrollable full-size image.'],physical_calls=0,selector_calls=0))
tools=['.work/build_checkpoint35.py','.work/check_checkpoint35.mjs','.work/render_checkpoint_architecture.py','.work/seal_checkpoint35.py','.work/verify_checkpoint35_fresh.py']
members={}
with zipfile.ZipFile(out/'authoring-originals.zip','x',zipfile.ZIP_DEFLATED) as z:
 for name in tools:
  data=(root/name).read_bytes();members[name]=dict(sha256=sha(data),bytes=len(data))
  info=zipfile.ZipInfo(name,date_time=(2026,11,8,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;z.writestr(info,data)
write(out/'authoring-manifest.json',dict(schema='aegisdc-checkpoint35-authoring-originals-v1',archive='authoring-originals.zip',sha256=sha((out/'authoring-originals.zip').read_bytes()),members=members,tool_scope='Existing accepted data rendered/read only; no new research executions.',environment=dict(python='3.11+',node='22+',browser='Local Google Chrome headless CDP',plotting='Matplotlib 3.10.7, Microsoft YaHei; exact font/source identities in architecture-source.json'),replay_note='Tools retain their original .work paths and fail on existing one-shot QA/profile/seal outputs. Use a new independent workspace/output version for a replay; never overwrite accepted evidence.'))
paths=[p for p in out.rglob('*') if p.is_file()]
paths += [root/p for p in ['README.md','docs/NEXT.md','docs/MAINLINE.md','docs/mainline/checkpoint35.md','evidence/mainline/research/34-paired-analysis/README.md','.gitattributes']]
artifacts={p.relative_to(root).as_posix():dict(sha256=sha(p.read_bytes()),bytes=p.stat().st_size) for p in sorted(paths)}
write(out/'delivery-manifest.json',dict(schema='aegisdc-checkpoint35-delivery-v1',source_commit='4cfab6c8a2f3fe4c501f9afb6739342d78e25fc7',accepted_through=35,full_goal='INCOMPLETE',research_execution='AWAITING_USER_REVIEW',registered_runs=164,new_physical_calls=0,new_selector_calls=0,new_seed_reads=0,artifacts=artifacts,excluded=['This manifest: self-hashing is not defined.','Automatic __pycache__, .pyc, .pyo, browser profiles and other runtime caches.'],format_classification='Architecture SVG retains Matplotlib original bytes; only its exact path receives the existing SVG whitespace classification.',documentation_correction='34 README now distinguishes shared exogenous measurement law/seed from action-dependent actual arrival records; raw inputs and results are unchanged.'))
print(json.dumps(dict(status='SEALED_CHECKPOINT35_READING_DELIVERY',artifacts=len(artifacts),authoring_members=len(members),registered_runs=164,new_physical_calls=0)))
