"""Exact fresh Git verification of an already authored reading copy."""
import argparse,base64,hashlib,json,re,subprocess,zipfile
from html.parser import HTMLParser
from pathlib import Path
parser=argparse.ArgumentParser();parser.add_argument('--checkout',type=Path,required=True);parser.add_argument('--revision',required=True);parser.add_argument('--output',type=Path,required=True);args=parser.parse_args()
root=args.checkout;prefix='evidence/mainline/research/checkpoint35/'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
git=lambda *v:subprocess.check_output(['git',*v],cwd=root)
assert git('rev-parse','HEAD').decode().strip()==args.revision
assert not git('status','--porcelain','--untracked-files=no').strip()
assert git('rev-parse','pre-meeting-20261103^{}').decode().strip()=='076d9aa15c5bc99a5b7985f296e15543b7b0f3d7'
def exact(path,expected=None):
 data=(root/path).read_bytes();assert data==git('show',args.revision+':'+path),path+' differs from committed blob'
 if expected is not None:assert sha(data)==expected,path+' hash mismatch'
 return data
manifest=json.loads(exact(prefix+'delivery-manifest.json'))
assert manifest['registered_runs']==164 and manifest['full_goal']=='INCOMPLETE'
for p,spec in manifest['artifacts'].items():assert len(exact(p,spec['sha256']))==spec['bytes']
source=json.loads(exact(prefix+'source-manifest.json'))
assert source['source_commit']==manifest['source_commit'] and source['figure_count']==9 and source['primary_status']=='NO_PRACTICAL_GAIN'
for p,digest in source['source_files'].items():exact(p,digest)
html=exact(prefix+'AegisDC-35-阶段研究成果.html',source['html_sha256']).decode('utf-8')
class Embeds(HTMLParser):
 def __init__(self):super().__init__();self.images=[];self.downloads=[]
 def handle_starttag(self,tag,attrs):
  a=dict(attrs)
  if tag=='img':self.images.append(a['src'])
  if tag=='a' and 'download' in a:self.downloads.append((a['download'],a['href']))
  if tag in ('script','link'):assert not a.get('src',a.get('href','')).startswith(('https:','http:'))
parsed=Embeds();parsed.feed(html)
assert len(parsed.images)==9 and len(parsed.downloads)==13
for uri,fig in zip(parsed.images,source['figures']):assert sha(base64.b64decode(uri.split(',',1)[1]))==fig['sha256']
for filename,uri in parsed.downloads:
 candidates=[p for p in source['source_files'] if Path(p).name==filename];assert len(candidates)==1,filename
 assert sha(base64.b64decode(uri.split(',',1)[1]))==source['source_files'][candidates[0]]
qa=json.loads(exact(prefix+'qa/responsive-qa.json'));assert qa['status']=='PASS_THREE_VIEWPORTS_AND_READING_CONTROLS' and not qa['javascript_errors']
assert sorted(r['viewport'] for r in qa['results'])==[412,1440,1920]
visual=json.loads(exact(prefix+'qa/visual-review.json'));assert visual['html_sha256']==source['html_sha256']
for p,digest in visual['screenshots'].items():exact(prefix+'qa/'+p,digest)
am=json.loads(exact(prefix+'authoring-manifest.json'));exact(prefix+am['archive'],am['sha256'])
with zipfile.ZipFile(root/prefix/am['archive']) as z:
 assert set(z.namelist())==set(am['members'])
 for name,spec in am['members'].items():assert sha(z.read(name))==spec['sha256'] and len(z.read(name))==spec['bytes']
 assert sha(z.read('.work/build_checkpoint35.py'))==source['authoring_sha256']
for p in manifest['artifacts']:
 if p.endswith('.md'):
  for target in re.findall(r'\]\(([^)]+)\)',(root/p).read_text(encoding='utf-8')):
   if '://' in target or target.startswith('#'):continue
   target=target.split('#')[0];assert (root/p).parent.joinpath(target).exists(),(p,target)
receipt=dict(status='PASS_EXACT_FRESH_CHECKPOINT35_DELIVERY',commit=args.revision,source_commit=source['source_commit'],declared_artifacts=len(manifest['artifacts']),source_files=len(source['source_files']),figures=9,downloads=13,viewports=[412,1440,1920],authoring_members=len(am['members']),premeeting_tag_preserved=True,new_physical_calls=0,new_selector_calls=0,new_seed_reads=0)
with args.output.open('x',encoding='utf-8',newline='\n') as f:f.write(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
