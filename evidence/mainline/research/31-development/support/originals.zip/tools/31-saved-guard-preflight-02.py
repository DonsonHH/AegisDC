from copy import deepcopy
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys

root=Path.cwd()
sys.path.insert(0,str(root/'scripts'))
from development_run_evidence import check_run

source=subprocess.check_output(['git','rev-parse','HEAD']).decode().strip()
assert not subprocess.check_output(['git','status','--porcelain'])
base=root/'evidence/mainline/engineering/26-candidate'
folder=root/'.work/31-saved-guard-preflight-02'
folder.mkdir()
receipt={'classification':'EXISTING_ENGINEERING_ORIGINALS_ONLY','source':source,
    'facility_calls':0,'selector_calls':0,'registered_research_trials':0,'read_cases':{},'refusals':{},'status':'FAIL'}
try:
    for name in ('online-candidate-inspect','online-baseline-inspect'):
        original=base/'capture-20261107-02'/name
        paths=[base/'reference'/f'{name}.json',*[original/f for f in ('run.json','private-state.jsonl','balances.jsonl')]]
        document=json.loads(paths[0].read_bytes())
        document.update(duration_s=6,maximum_step_s=.01)
        run=json.loads(paths[1].read_bytes())
        trace,balances=([json.loads(line) for line in path.read_bytes().splitlines()] for path in paths[2:])
        checked=check_run(document,run,trace,balances)
        assert checked['completed_inspections']==1 and checked['completed_interventions']==1
        receipt['read_cases'][name]={'source_inputs':{path.relative_to(root).as_posix():sha256(path.read_bytes()).hexdigest()
                for path in paths},'trace_points':checked['trace_points'],'totals':checked['totals']}
    for key,expected in (('future_record','Future evidence leaked'),('double_booking','overlapping or missing reservations'),
                         ('unsafe_compute','overrode local protection')):
        altered=deepcopy(run)
        changed_trace=deepcopy(trace)
        if key=='future_record':
            d=altered['policy_public_decisions'][0]
            d['frame']['evidence']['records'][0]['arrived_at_s']=d['frame']['as_of_s']+1
        elif key=='double_booking':
            state=next(row for row in changed_trace if row['domains']['people_tools_work']['active_requests'])
            state['domains']['people_tools_work']['tools']['tool_flow_meter']['reserved_by']=None
        else:
            changed_trace[0]['domains']['control_monitoring']['compute_permitted']=False
        try:
            check_run(document,altered,changed_trace,balances)
        except ValueError as e:
            assert expected in str(e),str(e)
            receipt['refusals'][key]=str(e)
        else:
            raise AssertionError('Tampered original was not refused')
    receipt['status']='PASS'
except BaseException as e:
    receipt['error']=str(e)
    raise
finally:
    with (folder/'receipt.json').open('x',encoding='utf-8',newline='\n') as f:
        json.dump(receipt,f,indent=2,allow_nan=False)
        f.write('\n')
print(json.dumps({k:len(v) if isinstance(v,dict) else v for k,v in receipt.items()}))
