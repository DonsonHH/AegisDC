"""Save the registered-development launch and static correction evidence."""

from hashlib import sha256
import json
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED

ROOT=Path('C:/Users/Donson/.codex/worktrees/mainline31-development/Renly')
WORK=ROOT/'.work'
OUT=ROOT/'evidence/mainline/research/31-development/support'
ROOTWORK=Path('C:/Users/Donson/Documents/ChatGPT/Renly/.work')
CHECKS=('31-plan-red-01','31-plan-green-01','31-corrected-static-01','31-saved-guard-preflight-01',
        '31-saved-guard-preflight-02','31-saved-guard-preflight-03','31-development-launch-01')

def sha(raw):return sha256(raw).hexdigest()
members={}
for name in CHECKS:
    folder=WORK/name
    for path in folder.iterdir():
        if path.is_file():
            members[f'{name}/{path.name}']=path.read_bytes()
for name in ('31-saved-guard-preflight-01.py','31-saved-guard-preflight-02.py','31-saved-guard-preflight-03.py'):
    members['tools/'+name]=(WORK/name).read_bytes()
for axis in ('spec','standards'):
    folder=ROOTWORK/f'31-{axis}-fixed-01'
    manifest=json.loads((folder/'manifest.json').read_bytes())
    entries=manifest.get('files',manifest.get('artifacts'))
    assert isinstance(entries,dict)
    for name,entry in entries.items():
        h=entry if isinstance(entry,str) else entry['sha256']
        raw=(folder/name).read_bytes()
        assert sha(raw)==h,(axis,name)
        members[f'reviews/{axis}/{name}']=raw
    members[f'reviews/{axis}/manifest.json']=(folder/'manifest.json').read_bytes()
members['tools/seal_31_support.py']=Path(__file__).read_bytes()
OUT.mkdir()
archive=OUT/'originals.zip'
with ZipFile(archive,'x',compression=ZIP_DEFLATED) as z:
    for name,raw in sorted(members.items()):z.writestr(name,raw)
with (OUT/'manifest.json').open('x',encoding='utf-8',newline='\n') as file:
    json.dump(dict(status='RETAINED_EXACT_ORIGINALS',scope='Static checks, saved-only guard tests and immutable launch originals.',
        archive_sha256=sha(archive.read_bytes()),members={name:sha(raw) for name,raw in members.items()}),file,indent=2)
    file.write('\n')
print(len(members))
