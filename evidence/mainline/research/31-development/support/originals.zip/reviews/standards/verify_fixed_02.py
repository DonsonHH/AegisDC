"""Independent fixed-source Standards review; saved input and journal bytes only."""
from hashlib import sha256
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
from tempfile import TemporaryDirectory

ROOT=Path('C:/Users/Donson/.codex/worktrees/mainline31-development/Renly')
OUT=Path('C:/Users/Donson/Documents/ChatGPT/Renly/.work/31-standards-fixed-01')
BASE='a7f43af2cbbb52042c6aaf1b807f4cd8044968e1'
CANDIDATE='c48a8f548c1690d8d15eb74890a269589839ac40'
checks=0
groups={}
def require(value,label):
    global checks
    if not value:
        raise AssertionError(label)
    checks+=1
    groups[label]=groups.get(label,0)+1

def git(*args):
    return subprocess.check_output(['git',*args],cwd=ROOT)

def sha(raw):
    return sha256(raw).hexdigest()

paths=[p for p in git('diff','--name-only',BASE+'...'+CANDIDATE).decode().splitlines()]
execution_head=git('rev-parse','HEAD').decode().strip()
require(not git('diff','--name-only',CANDIDATE,execution_head,'--',*paths),'Fixed reviewed files unchanged at additive execution head')
require(not git('status','--porcelain','--',*paths),'Reviewed tracked paths unchanged')
require(len(paths)==6,'Six declared changed files')
pins={}
for name in paths:
    raw=git('cat-file','blob',f'{CANDIDATE}:{name}')
    require((ROOT/name).read_bytes()==raw,'Working bytes equal reviewed committed blob')
    pins[name]=sha(raw)
require(git('rev-parse','pre-meeting-20261103^{}').decode().strip()=='076d9aa15c5bc99a5b7985f296e15543b7b0f3d7',
        'Historic tag preserved')
source=(ROOT/'scripts/registered_development.py').read_text(encoding='utf-8')
journal=(ROOT/'scripts/development_journal.py').read_text(encoding='utf-8')
audit=(ROOT/'scripts/development_run_evidence.py').read_text(encoding='utf-8')
require(source.index('journal_append(ledger,start)')<source.index("journal_write(folder_slot/'start.json',start)")<
        source.index('result=simulate_scenario('),'Durable STARTED precedes physical invocation')
require(source.index('journal_write(folder_slot/\'terminal.json\',terminal)')<
        source.index('journal_append(ledger,terminal)')<source.index('total=reconcile_journal'),
        'Normal journal terminal reconciliation order')
failure=source[source.index("unknown=dict(status='RECORDER_INCOMPLETE'"):source.index("return 4")]
require('authoritative_totals=None' in failure and 'UNRUN' not in failure and 'total=' not in failure,
        'Recorder ambiguity does not synthesize authoritative counts')
require(source.index("with ZipFile(originals,'x'")<source.index('audit=check_run'),
        'Returned original archive precedes saved audit')
require('validate_current_frame(frame)' in audit and "set(history)=={'issued','work_feedback'}" in audit,
        'Current public frame and history roles closed')
require("event_effects==applied" in audit and "engineering_control_command" in audit,
        'Physical effect log cross-check')
require('unused PYTHONPYCACHEPREFIX' in source and 'sys.dont_write_bytecode' in source,
        'Execution cache isolation precondition')
require("held_inputs_read=0,held_seed_reads=0" in source and 'secrets' not in source and 'nonce' not in source,
        'No held phase or nonce API in runner')
require('runtime_caches' not in paths and all('__pycache__' not in p and not p.endswith(('.pyc','.pyo')) for p in paths),
        'No cache artifact delivered')
book=json.loads((ROOT/'docs/mainline/31-development-execution.json').read_bytes())
require(book['budget']==dict(attempts=36,simulated_charge_s=360,scheduled_decisions=360),'Exact frozen development budget')
require(book['automatic_retries']==0 and book['phase']=='development','No retry or other phase')
require(book['durable_native_members']==['scenario.json','run.json','private-state.jsonl','balances.jsonl'],
        'Exact native durable set')
require('full-facility-comparison-held-blueprints' not in source and 'held_nonce' not in source,
        'Runner addresses only prepared development archive')

sys.path.insert(0,str(ROOT/'scripts'))
from development_journal import RecorderIncomplete, append, reconcile, write_record
import development_journal as module

with TemporaryDirectory() as tmp:
    folder=Path(tmp)
    path=folder/'journal.jsonl'
    original_fsync=module.os.fsync
    def failed_fsync(_):
        raise OSError('synthetic-fsync-refusal')
    module.os.fsync=failed_fsync
    try:
        try:
            append(path,dict(index=1,status='STARTED'))
        except RecorderIncomplete:
            pass
        else:
            raise AssertionError('Uncommitted journal was accepted')
    finally:
        module.os.fsync=original_fsync
    require(path.exists() and json.loads(path.read_bytes())['status']=='STARTED',
            'Ambiguous append preserves observed STARTED bytes')
    probe=folder/'record.json'
    module.os.fsync=failed_fsync
    try:
        try:
            write_record(probe,dict(index=1,status='STARTED'))
        except RecorderIncomplete:
            pass
        else:
            raise AssertionError('Uncommitted per-slot record was accepted')
    finally:
        module.os.fsync=original_fsync
    require(json.loads(probe.read_bytes())['status']=='STARTED',
            'Ambiguous per-slot write preserves bytes and refuses commit')

    source_id='1'*40
    slots=[dict(index=i,world_id=f'development-{i:02}',arm='fifo',duration_s=10,scheduled_decisions=10) for i in (1,2)]
    case=folder/'01-development-01-fifo'
    case.mkdir()
    start=dict(slots[0],status='STARTED',source=source_id,charged_simulated_s=10,charged_scheduled_decisions=10)
    terminal=dict(slots[0],status='FAILED',source=source_id,physical_call_started=True,physical_returned=False)
    unrun=dict(slots[1],status='UNRUN',source=source_id)
    write_record(case/'start.json',start)
    write_record(case/'terminal.json',terminal)
    jp=folder/'attempts.jsonl'
    append(jp,start); append(jp,terminal); append(jp,unrun)
    totals=reconcile(folder,slots,source_id)
    require(totals==dict(started=1,completed=0,failed=1,interrupted=0,unrun=1,charged_simulated_s=10,
        charged_scheduled_decisions=10,returned_decisions=0),'Reconcile physical failure with remaining unrun slots')
    raw=jp.read_bytes()
    for name,bad in (
        ('partial-tail',raw+b'{"partial":'),
        ('started-unrun',b''.join((json.dumps(dict(row,recorded_at_utc='fixture'))+'\n').encode()
            for row in (start,dict(slots[0],status='UNRUN',source=source_id),unrun))),
        ('missing-terminal',b''.join((json.dumps(dict(row,recorded_at_utc='fixture'))+'\n').encode() for row in (start,unrun))),
    ):
        jp.write_bytes(bad)
        try:
            reconcile(folder,slots,source_id)
        except ValueError:
            pass
        else:
            raise AssertionError('Invalid journal accepted: '+name)
        require(True,'Malformed journal refused: '+name)

require(not git('diff','--name-only',CANDIDATE,'HEAD','--',*paths) and not git('status','--porcelain','--',*paths),
        'Review leaves tracked source intact')
OUT.mkdir(exist_ok=True)
proof=dict(status='PASS_FIXED_PRECAPTURE_STANDARDS',base=BASE,candidate=CANDIDATE,checks=checks,check_groups=groups,
    observed_additive_head=execution_head,source_pins=pins,unresolved_findings=[],facility_calls=0,selector_calls=0,nonce_reads=0,held_inputs_materialized=0,
    scope='Static and generic synthetic journaling checks only. No registered attempt run or expected service result inferred.')
with (OUT/'proof.json').open('x',encoding='utf-8',newline='\n') as f:
    json.dump(proof,f,ensure_ascii=False,indent=2);f.write('\n')
print(json.dumps({k:v for k,v in proof.items() if k not in ('source_pins','check_groups')}))
