Standards: fixed pre-capture development source

PASS at reviewed candidate c48a8f548c1690d8d15eb74890a269589839ac40, compared with a7f43af2cbbb52042c6aaf1b807f4cd8044968e1. The six reviewed changed paths remain exact committed bytes at additive observed head 44675cde4e34ad699837187e2554f8bcc59e097c. No unresolved documented-standard finding or actionable advisory smell was found.

The previous recording ambiguity is closed. The fsynced STARTED append commits the charge before the physical call. Ambiguous journal or per-slot record writes exit through RECORDER_INCOMPLETE, preserve observed bytes and report authoritative_totals=null; no synthetic UNRUN rows follow that path. Normal totals are derived from the actual disk ledger and its matching per-slot start and terminal files. Returned native originals are archived before saved-result validation. Current-frame validation closes public frame fields; history roles and physical event/effect rows are explicitly cross-checked.

Thirty independent static and generic I/O checks passed. Forced fsync failures after bytes were visible both raised RecorderIncomplete and preserved STARTED bytes. A complete one-failure/one-unrun fixture charged exactly one attempt and ten seconds. A partial final row, STARTED rewritten as UNRUN and a missing terminal were all refused.

No facility, selector, held input, or nonce operation was performed. This review does not establish real journaling completion, scientific gain, or delivered capture validity; inspect the actual capture originals afterward.

The first observation helper required unchanged HEAD and stopped when the parent added an unrelated saved analyzer. Its original helper and refusal note are retained; the corrected helper checks exact reviewed Git blobs instead.
