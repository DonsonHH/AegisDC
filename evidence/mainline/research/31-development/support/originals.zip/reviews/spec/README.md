# Ticket 31 pre-capture Spec review

**PASS, zero unresolved pre-capture findings.** Fixed candidate: `c48a8f548c1690d8d15eb74890a269589839ac40`; base: `a7f43af2cbbb52042c6aaf1b807f4cd8044968e1`.

The corrected runner charges a slot only through a flushed, fsynced and read-back STARTED journal record before invoking the facility. A failed or ambiguous recorder operation stops as RECORDER_INCOMPLETE, retains partial originals and does not manufacture UNRUN rows or authoritative totals. A normal stopped batch reconciles the on-disk per-slot start/terminal records and journal against the fixed roster.

Saved-return validation now closes the frame, evidence and history schemas, checks arrived records against declared acquisition and actual issued work, and reconciles APPLIED actions with actual plant intervention events. Local protection, qualified crew, safe access, tools and the unchanged common admission envelope remain execution constraints.

The independent saved-only audit completed **230 checks**: exact fixed source bytes, 81 archived members, 36 complete eight-domain development inputs, primary and six-arm parity, two earlier ticket 26 returned trajectories, and ten tampered saved-return refusals. No simulator, selector, held input or nonce was read or executed by this review.

The later candidate `44675cde4e34ad699837187e2554f8bcc59e097c` differs only by additive `scripts/analyze_registered_development.py`. Its addition does not change the reviewed capture/runtime path. This review does not establish developmental results or method discrimination; those must be assessed from the original registered batch after capture. It does not accept ticket 31 by itself.
