"""Independent saved-only fixed-source Spec review of ticket 31."""
from collections import Counter
from copy import deepcopy
from hashlib import sha256
import importlib.util
import io
import json
from pathlib import Path
import subprocess
import sys
from zipfile import ZipFile

WT=Path('C:/Users/Donson/.codex/worktrees/mainline31-development/Renly')
OUT=Path('C:/Users/Donson/Documents/ChatGPT/Renly/.work/31-spec-fixed-01')
CANDIDATE='c48a8f548c1690d8d15eb74890a269589839ac40'
BASE='a7f43af2cbbb52042c6aaf1b807f4cd8044968e1'
def git(*a): return subprocess.check_output(['git',*a],cwd=WT)
def blob(p): return git('cat-file','blob',CANDIDATE+':'+p)
def sha(raw): return sha256(raw).hexdigest()
def obj(p): return json.loads(blob(p))
count=Counter()
def check(ok,name):
    if not ok: raise AssertionError(name)
    count[name]+=1

OUT.mkdir()
snap=OUT/'snapshot'
snap.mkdir()
paths=('scripts/development_journal.py','scripts/development_run_evidence.py','scripts/registered_development.py',
       'scripts/registered_comparison.py','docs/mainline/31-development-execution.json',
       'docs/mainline/30-comparison-protocol-v1.json','tests/test_registered_development.py')
pins={}
for p in paths:
    raw=blob(p)
    pins[p]=sha(raw)
    check((WT/p).read_bytes()==raw,'Working fixed source equals Git blob')
    if p.startswith('scripts/'):
        (snap/Path(p).name).write_bytes(raw)
check(not git('diff','--name-only',BASE,CANDIDATE,'--','src'),'Physical runtime unchanged')
source=blob('scripts/registered_development.py').decode()
capture=source[source.index('def capture('):]
check(capture.index('journal_append(ledger,start)')<capture.index("journal_write(folder_slot/'start.json',start)")<
      capture.index('result=simulate_scenario('),'Fsynced STARTED before physical invocation')
check(capture.index('journal_write(folder_slot/\'terminal.json\',terminal)')<
      capture.index('journal_append(ledger,terminal)')<capture.index('total=reconcile_journal'),
      'Terminal files precede reconciliation')
failure=capture[capture.index('except BaseException as exc:\n        # This is explicitly'):capture.index('    try:\n        _guard(source,pins)')]
check("status='RECORDER_INCOMPLETE'" in failure and 'authoritative_totals=None' in failure
      and 'UNRUN' not in failure and 'return 4' in failure,'Ambiguous recorder path never claims reconciled totals or UNRUN')
check("for slot in slots:\n            if slot['index'] not in attempted:" in capture
      and "journal_append(ledger,dict(slot,status='UNRUN'" in capture,'Stopped planned slots retained')
check("held_inputs_read=0,held_seed_reads=0" in source and "read_bytes()" not in source.split('def load_roster')[0].split('def committed')[0],
      'No held nonce access in runner imports')
protocol=obj('docs/mainline/30-comparison-protocol-v1.json')
book=obj('docs/mainline/31-development-execution.json')
check(book['budget']==protocol['phases']['development']['budget']==dict(attempts=36,simulated_charge_s=360,scheduled_decisions=360),
      'Exact registered development budget')
check(book['automatic_retries']==0 and book['classification']=='REGISTERED_DEVELOPMENT_NOT_CONFIRMATION','No retry or confirmation reclassification')
archive='evidence/mainline/engineering/30-comparison-preparation/preparation-originals.zip'
manifest=obj('evidence/mainline/engineering/30-comparison-preparation/manifest.json')
raw=blob(archive)
check(sha(raw)==manifest['archive_sha256'],'Archived input package identity')
documents={}
with ZipFile(io.BytesIO(raw)) as z:
    check(len(z.namelist())==len(set(z.namelist()))==81,'Original member denominator')
    for name in z.namelist():
        check(sha(z.read(name))==manifest['members'][name],'Original archived member bytes')
    for world in protocol['phases']['development']['worlds']:
        common=[]
        primary=[]
        for arm in protocol['phases']['development']['arms']:
            name=f"input-preparation/30-development-inputs-02/{world['id']}/{arm}.json"
            document=json.loads(z.read(name)); documents[(world['id'],arm)]=document
            check(document['duration_s']==10 and document['maximum_step_s']==.01,'Frozen run clocks')
            p=document['dispatch_program']
            check(p['decision_times_s']==list(range(10)) and p['policy_program']['policy']==arm,'Frozen decision clocks and assigned arm')
            check(len(document['model']['domains'])==8 and set(document['model']['graphs'])=={'physical','functional','control_information','access'},
                  'Complete same-facility scope')
            policy=p['policy_program']; policy.pop('policy')
            canon=lambda v: json.dumps(v,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
            if arm in ('one_observation_lookahead','evidence_consistent_contingent'): primary.append(sha(canon(document)))
            policy.pop('options')
            common.append(sha(canon(document)))
        check(len(set(primary))==1,'Primary pair differs only in policy name')
        check(len(set(common))==1,'Six-arm common physical and permission inputs')
# The exported saved checker calls current-frame validation, not selection.
sys.path[:0]=[str(snap),str(WT/'src')]
spec=importlib.util.spec_from_file_location('fixed_evidence',snap/'development_run_evidence.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
original_root='evidence/mainline/engineering/26-candidate'
saved={}
for name in ('online-candidate-inspect','online-baseline-inspect'):
    document=obj(original_root+'/reference/'+name+'.json')
    document.update(duration_s=6,maximum_step_s=.01)
    prefix=original_root+'/capture-20261107-02/'+name+'/'
    run=obj(prefix+'run.json')
    trace=[json.loads(l) for l in blob(prefix+'private-state.jsonl').splitlines()]
    balances=[json.loads(l) for l in blob(prefix+'balances.jsonl').splitlines()]
    audit=module.check_run(document,run,trace,balances)
    check(audit['status']=='PASS_RETURNED_DEVELOPMENT_EVIDENCE' and audit['completed_inspections']==audit['completed_interventions']==1,
          'Existing returned originals accepted without rerun')
    saved[name]=dict(trace_points=len(trace),deficit_s=audit['totals']['service_deficit_time_s'])
    for fault in ('frame-private','history-private','missing-effect-audit','future-evidence','unreserved-tool'):
        changed=deepcopy(run); changed_trace=deepcopy(trace)
        if fault=='frame-private':
            changed['policy_public_decisions'][0]['frame']['private_network_state']=.25
        elif fault=='history-private':
            changed['policy_public_decisions'][0]['history']['hidden_future']={}
        elif fault=='missing-effect-audit':
            changed['intervention_private_audit']['events']=[]
        elif fault=='future-evidence':
            dec=changed['policy_public_decisions'][0];dec['frame']['evidence']['records'][0]['arrived_at_s']=dec['frame']['as_of_s']+1
        else:
            t=next(t for t in changed_trace if t['domains']['people_tools_work']['active_requests'])
            t['domains']['people_tools_work']['tools']['tool_flow_meter']['reserved_by']=None
        try: module.check_run(document,changed,changed_trace,balances)
        except ValueError as exc:
            check(bool(str(exc)),'Saved mutation specifically refused')
        else: raise AssertionError(f'Accepted tampered original: {fault}')
result=dict(status='PASS_FIXED_PRECAPTURE_SPEC',base=BASE,candidate=CANDIDATE,checks=sum(count.values()),
            groups=dict(count),source_pins=pins,saved_original_checks=saved,findings=[],
            facility_calls=0,selector_calls=0,held_input_reads=0,nonce_reads=0,
            scope='Pre-capture source and saved evidence review, not a development result.')
(OUT/'audit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({k:v for k,v in result.items() if k not in ('groups','source_pins','saved_original_checks')},ensure_ascii=False))
