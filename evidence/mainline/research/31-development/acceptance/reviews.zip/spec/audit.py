"""Independent raw-original Spec audit of the completed registered development batch."""
from collections import Counter
from copy import deepcopy
from hashlib import sha256
import io,json,math
from pathlib import Path
import subprocess
from zipfile import ZipFile

WT=Path('C:/Users/Donson/.codex/worktrees/mainline31-development/Renly')
OUT=Path('C:/Users/Donson/Documents/ChatGPT/Renly/.work/31-spec-saved-01')
DELIVERY='e74c8affbf4b7dc9f698c8478f66ed26d624ceec'
SOURCE='44675cde4e34ad699837187e2554f8bcc59e097c'
BASE='evidence/mainline/research/31-development'
CAP=BASE+'/capture-01'
COUNTS=Counter()
def check(ok,group):
    if not ok: raise AssertionError(group)
    COUNTS[group]+=1
def close(a,b,tol,group): check(math.isclose(a,b,rel_tol=0,abs_tol=tol),group)
def git(*args): return subprocess.check_output(['git',*args],cwd=WT)
def sha(raw): return sha256(raw).hexdigest()
def canonical(value): return json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False)
def blobs(rev,paths):
    names=sorted(set(paths))
    raw=subprocess.run(['git','cat-file','--batch'],input=''.join(rev+':'+n+'\n' for n in names).encode(),
                       cwd=WT,capture_output=True,check=True).stdout
    result={};offset=0
    for name in names:
        e=raw.index(b'\n',offset);header=raw[offset:e].split()
        check(len(header)==3 and header[1]==b'blob','Exact Git source/delivery blob exists')
        n=int(header[2]);b=e+1
        result[name]=raw[b:b+n];offset=b+n+1
    check(offset==len(raw),'Complete Git batch')
    return result
def list_paths(rev,path): return set(git('ls-tree','-rz','--name-only',rev,'--',path).decode().split('\0'))-{''}
def read(path): return json.loads(data[path])
OUT.mkdir(exist_ok=True)
paths=list_paths(DELIVERY,BASE)|{
 'evidence/mainline/engineering/30-comparison-preparation/preparation-originals.zip',
 'evidence/mainline/engineering/30-comparison-preparation/manifest.json',
 'docs/mainline/30-comparison-protocol-v1.json'}
data=blobs(DELIVERY,paths)
batch=read(CAP+'/batch.json');receipt=read(CAP+'/receipt.json');report=read(BASE+'/results.json')
check(batch['execution_commit']==receipt['execution_commit']==report['execution_commit']==SOURCE,'Execution revision identity')
check(batch['phase']==receipt['phase']=='development' and batch['classification']=='REGISTERED_DEVELOPMENT_NOT_CONFIRMATION','Registered development identity')
check(receipt['status']=='PASS' and receipt['source_unchanged'] and receipt['stop'] is None,'Completed immutable batch')
check(receipt['held_inputs_read']==receipt['held_seed_reads']==receipt['automatic_retries']==0,'No held exposure or retry')
check({k:sha(v) for k,v in blobs(SOURCE,batch['pins']).items()}==batch['pins'],'Recorded execution pins match source Git blobs')
check(set(receipt['artifacts'])=={p[len(CAP)+1:] for p in paths if p.startswith(CAP+'/')}-{'receipt.json'},'Complete declared durable capture set')
for name,h in receipt['artifacts'].items(): check(sha(data[CAP+'/'+name])==h,'Exact delivered capture fingerprint')
protocol=read('docs/mainline/30-comparison-protocol-v1.json')
phase=protocol['phases']['development']
expected=[]
for world in phase['worlds']:
 arms=phase['arms'];shift=(world['slot']-1)%len(arms)
 for arm in arms[shift:]+arms[:shift]:
  expected.append((world['id'],world['family'],arm))
slots=batch['slots']
check(len(slots)==36 and [(r['world_id'],r['family'],r['arm']) for r in slots]==expected,'Frozen world/arm rotation and denominator')
rows=[json.loads(line) for line in data[CAP+'/attempts.jsonl'].splitlines()]
check(len(rows)==72,'One start and terminal per attempted run')
check(receipt['total']==dict(started=36,completed=36,failed=0,interrupted=0,unrun=0,
 charged_simulated_s=360,charged_scheduled_decisions=360,returned_decisions=360),'Exact actual charges and counts')
prep=data['evidence/mainline/engineering/30-comparison-preparation/preparation-originals.zip']
prep_manifest=read('evidence/mainline/engineering/30-comparison-preparation/manifest.json')
check(sha(prep)==prep_manifest['archive_sha256'],'Prepared source archive fingerprint')
compiled={}
runs={}
metrics={}
maxima=Counter()
intervals=states=0
groups_by_run={}
with ZipFile(io.BytesIO(prep)) as z:
 for slot in slots:
  raw=z.read(slot['input_member'])
  check(sha(raw)==slot['input_sha256']==prep_manifest['members'][slot['input_member']],'Exact registered input bytes')
  compiled[(slot['world_id'],slot['arm'])]=json.loads(raw)

def get_epoch_events(run):
    return sorted([r for r in run['events'] if r['kind'] in ('exogenous_boundary_input','completed_research_intervention')],
                  key=lambda r:r['applied_at_s'])

def common_options(document,decision):
    program=document['dispatch_program'];policy=program['policy_program'];frame=decision['frame'];history=decision['history']
    at=frame['as_of_s'];knowledge=frame['nominal_knowledge']
    entities={r['id']:r for r in knowledge['entities']};interfaces={r['id']:r for r in knowledge['work_interfaces']}
    candidates={r['id']:r for r in policy['candidates']}
    issued={r['candidate_id'] for r in history['issued']};terminal={r['task_id'] for r in history['work_feedback'] if r['status'] in ('completed','aborted','rejected')}
    resources=lambda t:{r['worker_id'] for r in t['crew']}|set(interfaces[t['work_interface_id']]['tool_ids'])
    occupied=set().union(*(resources(candidates[k]['task']) for k in issued if candidates[k]['task']['id'] not in terminal))
    reservations={k:dict(person_s=(r['task']['deadline_s']-r['available_at_s'])*len(r['task']['crew']),
        tool_s=(r['task']['deadline_s']-r['available_at_s'])*len(interfaces[r['task']['work_interface_id']]['tool_ids']),
        cost=r['issue_cost']) for k,r in candidates.items()}
    spent={key:math.fsum(reservations[k][key] for k in issued) for key in ('person_s','tool_s','cost')}
    options=[]
    for k,r in candidates.items():
        task=r['task'];interface=interfaces[task['work_interface_id']]
        if k in issued or resources(task)&occupied or not r['available_at_s']<=at<=task['deadline_s']: continue
        if not all(spent[key]+reservations[k][key]<=policy['resource_budget'][key] for key in spent): continue
        check(all(role['qualification_id'] in entities[role['worker_id']]['qualification_ids'] for role in task['crew'])
            and interface['qualification_id'] in entities[task['tool_carrier_id']]['qualification_ids']
            and set(interface['tool_ids'])<=set(entities[task['tool_carrier_id']]['tool_ids']),'Independent nominal crew/tool capability')
        location=entities[task['target_id']]['nominal_location_id']
        records=frame['evidence']['records']
        blockers=[rec for constraint in knowledge['reported_constraints'] if constraint['location_id']==location
            for rec in records if rec['availability']=='current' and
            all(rec[key]==constraint[key] for key in ('source_id','target_id','observable_id')) and rec['value'] is constraint['blocking_value']]
        if blockers:continue
        if r['kind']=='intervene':
            binding=next(x for x in program['intervention_program']['bindings'] if x['task_id']==task['id'])
            op=next(x for x in program['intervention_program']['profile']['operations'] if x['id']==binding['operation_id'])
            grant=next(x for x in program['intervention_program']['profile']['authorizations'] if x['id']==binding['authorization_id'])
            if not grant['starts_at_s']<=at<grant['expires_at_s']:continue
            check(op['id'] in grant['operation_ids'] and task['target_id'] in grant['target_ids'],'Independent action issue authority')
            if policy['workforce_profile']['work_times_s'][task['work_interface_id']]<op['minimum_work_s']:continue
        options.append(k)
    return sorted(options)

for index,slot in enumerate(slots,1):
    check(slot['index']==index and slot['duration_s']==slot['scheduled_decisions']==10,'Per-slot frozen runtime budget')
    folder=f"{CAP}/{index:02}-{slot['world_id']}-{slot['arm']}"
    start,terminal=(read(folder+'/'+n) for n in ('start.json','terminal.json'))
    for i,record in enumerate((start,terminal)):
        observed={k:v for k,v in rows[2*(index-1)+i].items() if k!='recorded_at_utc'}
        check(observed==record and record['source']==SOURCE and all(record[k]==v for k,v in slot.items()),'Exact start/terminal journal binding')
    check(start['status']=='STARTED' and terminal['status']=='COMPLETED' and
          terminal['physical_call_started'] and terminal['physical_returned'] and terminal['returned_decisions']==10,
          'Actual registered lifecycle and full returned decisions')
    manifest=read(folder+'/originals.json');zipraw=data[folder+'/originals.zip']
    check(sha(zipraw)==manifest['archive_sha256'],'Native archive SHA')
    with ZipFile(io.BytesIO(zipraw)) as z:
        names=z.namelist()
        check(len(names)==len(set(names))==4 and set(names)=={'scenario.json','run.json','private-state.jsonl','balances.jsonl'},'Exact native originals set')
        raw={n:z.read(n) for n in names}
    for n,h in manifest['members'].items(): check(sha(raw[n])==h,'Native member SHA')
    document=compiled[(slot['world_id'],slot['arm'])]
    run=json.loads(raw['run.json']);model=json.loads(raw['scenario.json'])
    trace=[json.loads(l) for l in raw['private-state.jsonl'].splitlines()]
    balances=[json.loads(l) for l in raw['balances.jsonl'].splitlines()]
    check(model==document['model'],'Actual scenario equals frozen input')
    check(run['code_identity']['git_commit']==SOURCE and run['code_identity']['implementation_has_changes'] is False
          and run['code_identity']['files']=={k:v for k,v in batch['pins'].items() if k.startswith('src/aegis_dc/') or k=='src/patrol_rsi/contracts.py'},
          'Actual plant source identity')
    check(run['inputs']['dispatch_program']==document['dispatch_program'] and run['inputs']['boundary_events']==document['boundary_events']
          and run['inputs']['duration_s']==10 and run['inputs']['maximum_step_s']==.01,'Actual timed physical/decision inputs')
    for n,item in run['artifacts'].items():check(sha(raw[n])==item['sha256'],'Native plant artifact identity')
    p={r['id']:r['value'] for r in model['parameters']}
    events=get_epoch_events(run);ei=0
    integrals={k:[] for k in ('demand_service_unit_s','delivered_service_unit_s','service_deficit_time_s',
        'worker_travel_person_s','worker_work_person_s','worker_wait_person_s','tool_occupation_tool_s')}
    check(trace[0]['time_s']==0 and trace[-1]['time_s']==10 and len(trace)==len(balances)+1,'Full real trajectory endpoints')
    before=None
    for a,b,row in zip(trace,trace[1:],balances):
        t=a['time_s'];dt=b['time_s']-t
        check(row['start_s']==t and row['end_s']==b['time_s'] and 0<dt<=.01+1e-8,'Continuous declared timestep')
        d=a['domains']
        check(set(d)=={'power','backup','facility_cooling','equipment_environment','it_service','control_monitoring','space_access','people_tools_work'},'Eight actual domains in every interval')
        while ei<len(events) and events[ei]['applied_at_s']<=t:
            e=events[ei]
            p[e['parameter_id']]=e['new_value'] if e['kind']=='completed_research_intervention' else e['value'];ei+=1
        pw=d['power'];service=d['it_service']
        capacities={k:min(p[k+'_service_capacity'],pw['actual_powers_W'][k]/p[k+'_nominal_power']) for k in ('compute','network','storage')}
        delivery=min(p['service_demand'],*capacities.values())
        close(service['demand'],p['service_demand'],0,'External demand retained')
        for k,val in capacities.items():close(service['capacities'][k],val,1e-12,'Capacity follows actual supplied power and named ceiling')
        close(service['delivered'],delivery,1e-12,'Joint service is bottlenecked actual delivery')
        contributions=dict(demand_service_unit_s=p['service_demand']*dt,delivered_service_unit_s=delivery*dt,
                           service_deficit_time_s=(p['service_demand']-delivery)/p['service_demand']*dt if p['service_demand'] else 0)
        crew=d['people_tools_work'];workers=crew['workers'];tools=crew['tools']
        contributions.update(worker_travel_person_s=sum(w['status']=='travelling' for w in workers.values())*dt,
            worker_work_person_s=sum(w['status']=='working' for w in workers.values())*dt,
            tool_occupation_tool_s=sum(w['reserved_by'] is not None for w in tools.values())*dt)
        # Queue wait is separately declared; inspect additive identity rather than count idle queued twice.
        contributions['worker_wait_person_s']=row['access_check_person_s']+row['rendezvous_wait_person_s']+row['queue_wait_person_s']
        for k,v in contributions.items():
            close(row[k],v,1e-8,'Independent per-interval service/resource integral')
            integrals[k].append(v)
        check(d['control_monitoring']['compute_permitted'] or pw['actual_powers_W']['compute']==0,'No local protection bypass')
        check(min(row['capacity_slack_W'].values())>=-1e-6,'No electrical capacity overdraw')
        electrical=math.fsum((pw['grid_draw_W'],pw['generator_output_W'],pw['ups_output_W'],pw.get('starter_output_W',0),
                             -math.fsum(pw['actual_powers_W'].values()),-pw['rectifier_loss_W']))
        maxima['electrical_W']=max(maxima['electrical_W'],abs(electrical))
        close(electrical,0,1e-6,'Independent electrical allocation conservation')
        for name,m in row['mass_accounts_kg'].items():
            residual=math.fsum((m['before_kg'],m['in_kg'],-m['out_kg'],-m['after_kg']))
            maxima['mass_kg']=max(maxima['mass_kg'],abs(residual))
            close(residual,0,p['mass_absolute_tolerance'],'Independent raw mass conservation')
            close(residual,row['mass_residuals_kg'][name],1e-12,'Raw mass residual matches declared account')
        if before is not None:check(before==row['storage_before_J'],'Adjacent stored energies remain continuous')
        before=row['storage_after_J']
        for name,rate in row['component_energy_rates_W'].items():
            residual=row['storage_after_J'][name]-row['storage_before_J'][name]-rate*dt
            maxima['component_J']=max(maxima['component_J'],abs(residual))
            close(residual,0,p['energy_absolute_tolerance'],'Independent raw component energy balance')
        facility=math.fsum(row['storage_after_J'].values())-math.fsum(row['storage_before_J'].values())-(row['boundary_input_J']-row['boundary_output_J'])
        maxima['facility_interval_J']=max(maxima['facility_interval_J'],abs(facility))
        close(facility,0,p['energy_absolute_tolerance'],'Independent facility boundary energy balance')
        refrigerant=d['equipment_environment']['refrigerant'];x=refrigerant['quality']
        check(0<=x<=1 and 100000<=refrigerant['pressure_Pa']<=3000000,'Valid finite pure-fluid phase domain')
        close(refrigerant['mass_kg']*((1-x)*refrigerant['v_l_m3_kg']+x*refrigerant['v_v_m3_kg']),p['coolant_control_volume'],1e-9,'Independent phase mixture volume')
        close((1-x)*refrigerant['u_l_J_kg']+x*refrigerant['u_v_J_kg'],refrigerant['internal_energy_J']/refrigerant['mass_kg'],1e-6,'Independent phase mixture energy')
    intervals+=len(balances);states+=len(trace)
    totals={k:math.fsum(v) for k,v in integrals.items()}
    for k,v in totals.items():close(v,run['summary'][k],1e-8,'Native summary is raw-integral result')
    totals['paid_person_s']=math.fsum(totals[k] for k in ('worker_travel_person_s','worker_work_person_s','worker_wait_person_s'))
    whole=math.fsum(balances[-1]['storage_after_J'].values())-math.fsum(balances[0]['storage_before_J'].values())-math.fsum(r['boundary_input_J']-r['boundary_output_J'] for r in balances)
    maxima['whole_J']=max(maxima['whole_J'],abs(whole))
    close(whole,0,p['energy_absolute_tolerance'],'Whole raw energy balance')
    decisions=run['policy_public_decisions']
    check([r['frame']['as_of_s'] for r in decisions]==list(range(10)),'Actual 10 scheduled decision instants')
    for dec in decisions:
        check(dec['choice']['policy']==slot['arm'] and dec['choice']['execution_permission'] is False,'Actual named selector and authority boundary')
        at=dec['frame']['as_of_s']
        check(all(r['arrived_at_s']<=at for r in dec['frame']['evidence']['records']),'Only arrived evidence visible')
    saved_audit=read(folder+'/audit.json')
    for k in totals:close(totals[k],saved_audit['totals'][k],1e-8,'Audit facts agree with independent raw sums')
    metrics[(slot['world_id'],slot['arm'])]=totals
    runs[(slot['world_id'],slot['arm'])]=run
    groups_by_run[f"{slot['world_id']}/{slot['arm']}"]=dict(intervals=len(balances),states=len(trace),totals=totals,whole_residual_J=whole)

pairs=[]
for world in phase['worlds']:
    name,family=world['id'],world['family']
    b,c=(runs[(name,a)] for a in ('one_observation_lookahead','evidence_consistent_contingent'))
    bm,cm=(metrics[(name,a)] for a in ('one_observation_lookahead','evidence_consistent_contingent'))
    delta=bm['service_deficit_time_s']-cm['service_deficit_time_s']
    identification=None
    for br,cr in zip(b['policy_public_decisions'],c['policy_public_decisions']):
        same=canonical(br['frame'])==canonical(cr['frame']) and canonical(br['history'])==canonical(cr['history'])
        if br['choice']['chosen_candidate_id']!=cr['choice']['chosen_candidate_id']:
            left=common_options(compiled[(name,'one_observation_lookahead')],br)
            right=common_options(compiled[(name,'evidence_consistent_contingent')],cr)
            identification=dict(first_different_s=br['frame']['as_of_s'],same_public_frame_and_history=same,
                baseline_intent=br['choice']['chosen_candidate_id'],candidate_intent=cr['choice']['chosen_candidate_id'],
                common_eligible_paid=sorted(set(left)&set(right)),identified=same and left==right and len(left)>=2)
            break
        check(same,'Common histories identical before first different intention')
    if identification is None:
        identification=dict(first_different_s=None,identified=False,baseline_intent=None,candidate_intent=None,
                            common_eligible_paid=[],same_public_frame_and_history=True)
    stored=next(r for r in report['pairs'] if r['world_id']==name)
    check(stored['opportunity']==identification,'Independent first shared-history divergence diagnostic')
    close(stored['delta_service_deficit_s'],delta,1e-9,'Independent per-world primary service delta')
    for cost in ('paid_person_s','worker_travel_person_s','tool_occupation_tool_s'):
        close(stored['extra_costs'][cost],cm[cost]-bm[cost],1e-9,'Independent per-world signed cost delta')
    pairs.append(dict(world_id=name,family=family,delta_service_deficit_s=delta,identified=identification['identified']))
mean=math.fsum(p['delta_service_deficit_s'] for p in pairs)/6
close(mean,-1/24,1e-12,'Negative development mean literal retained')
close(report['primary_mean_delta_service_s'],mean,1e-12,'Reported mean matches independent six-pair arithmetic')
identified=[p for p in pairs if p['identified']]
check(len(identified)==report['identified_shared_history_worlds']==5 and
      sorted({p['family'] for p in identified})==report['observed_identified_families'] and len(report['observed_identified_families'])==3,
      'Five diagnostic worlds in three families')
result=dict(status='PASS_INDEPENDENT_SAVED_DEVELOPMENT_SPEC',delivery=DELIVERY,execution_source=SOURCE,
    checks=sum(COUNTS.values()),check_groups=dict(COUNTS),runs=36,intervals=intervals,state_rows=states,
    mean_primary_delta_service_s=mean,identified_worlds=len(identified),identified_families=report['observed_identified_families'],
    pairs=pairs,raw_max_residuals=dict(maxima),run_summaries=groups_by_run,findings=[],
    facility_calls=0,selector_calls=0,held_input_reads=0,nonce_reads=0,
    scope='Development result and exact original audit; not confirmation or field effectiveness.')
(OUT/'audit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({k:v for k,v in result.items() if k not in ('check_groups','run_summaries','pairs')},ensure_ascii=False))
