# Ticket 31 independent saved-data Spec review

**PASS; no unresolved saved-evidence findings.** Data delivery `e74c8affbf4b7dc9f698c8478f66ed26d624ceec`; physical execution `44675cde4e34ad699837187e2554f8bcc59e097c`.

The independent audit completed 1,564,787 assertions over all 36 returned runs, 36,333 adjacent balance intervals and 36,369 eight-domain state rows. It read original Git blobs and native ZIP members, checked exact archive/input/runtime identities, and matched 36 charged STARTED records with 36 completed terminals. There were no failed or repeated registered calls; the charged budgets were 360 simulated seconds and 360 actual decisions.

Service was independently reconstructed from each interval's external demand, actual supplied component power and currently applied capacity limits. Raw storage/boundary energy, electrical supply versus real loads, mass ledgers, phase mixture geometry and energy, actual travel/work/tool occupancy and signed paired costs reconcile. The maximum reconstructed whole-run energy residual was 4.119e-5 J; maximum raw mass residual was 4.547e-13 kg.

The six primary service differences are [-0.5, 0, +0.25, 0, 0, 0] seconds, averaging -1/24 second. Five worlds have a first differing intention at the same public frame/history with two independently admissible paid tasks; these span three declared families. Thus the saved diagnostic is not a case of universally identical actions. It is a contextual developmental result, without an overall gain or a confirmation claim.

No new facility run, selector call, held-input read or nonce read occurred. An independent helper initially failed after its raw-run loop because a local phase-state variable shadowed the roster variable; its exact source and failure receipt are retained. The corrected helper only reread these same committed originals.
