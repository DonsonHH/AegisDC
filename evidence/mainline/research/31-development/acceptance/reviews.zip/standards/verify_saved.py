"""Independent saved-data Standards proof; no facility, selector or nonce calls."""
from datetime import datetime
from hashlib import sha256
import json
from math import fsum
from pathlib import Path, PurePosixPath
import subprocess
from zipfile import ZipFile

ROOT=Path('C:/Users/Donson/.codex/worktrees/mainline31-development/Renly')
OUT=Path('C:/Users/Donson/Documents/ChatGPT/Renly/.work/31-standards-saved-01')
EXEC='44675cde4e34ad699837187e2554f8bcc59e097c'
DATA='e74c8affbf4b7dc9f698c8478f66ed26d624ceec'
SCOPE='evidence/mainline/research/31-development'
CAPTURE=f'{SCOPE}/capture-01'
NATIVE={'scenario.json','run.json','private-state.jsonl','balances.jsonl'}
FRAME={'schema','plan_id','facility_id','time_unit','as_of_s','nominal_knowledge','evidence','requests'}
EVIDENCE={'schema','ledger_id','facility_id','time_unit','as_of_s','static_knowledge','records','correlation_groups',
          'provenance_issues','independence','conflicts','current_record_ids'}
RECORD={'id','source_id','target_id','observable_id','unit','value','observed_at_s','arrived_at_s','valid_until_s',
        'quality','provenance','age_s','availability'}
DOMAINS={'power','backup','facility_cooling','equipment_environment','it_service','control_monitoring','space_access','people_tools_work'}
checks=0;groups={}
def require(value,label):
    global checks
    if not value: raise AssertionError(label)
    checks+=1;groups[label]=groups.get(label,0)+1
def git(*args):
    return subprocess.check_output(['git',*args],cwd=ROOT)
def digest(raw):
    return sha256(raw).hexdigest()
def read(path):
    return json.loads(path.read_bytes())
def blob_pins(rev,names):
    names=sorted(names)
    raw=subprocess.check_output(['git','cat-file','--batch'],cwd=ROOT,
        input=''.join(rev+':'+name+'\n' for name in names).encode())
    offset=0; result={}
    for name in names:
        end=raw.index(b'\n',offset);header=raw[offset:end].split()
        require(len(header)==3 and header[1]==b'blob','Exact Git blob role')
        start=end+1;size=int(header[2])
        result[name]=digest(raw[start:start+size]);offset=start+size+1
    require(offset==len(raw),'Git batch bytes complete')
    return result
def canonical(value):
    return json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
def safe_archive(path,manifest):
    require(digest(path.read_bytes())==manifest['archive_sha256'],'Archive fingerprint')
    with ZipFile(path) as source:
        names=source.namelist()
        require(len(names)==len(set(names)) and set(names)==set(manifest['members']),'Exact unique archive members')
        values={name:source.read(name) for name in names}
    for name,raw in values.items():
        pure=PurePosixPath(name)
        require(not pure.is_absolute() and '..' not in pure.parts and '__pycache__' not in pure.parts
                and pure.suffix not in ('.pyc','.pyo') and digest(raw)==manifest['members'][name],
                'Safe durable original member bytes')
    return values

capture=ROOT/CAPTURE
batch=read(capture/'batch.json');receipt=read(capture/'receipt.json')
require(batch['execution_commit']==receipt['execution_commit']==EXEC,'Original execution identity')
require(batch['phase']==receipt['phase']=='development' and batch['classification']=='REGISTERED_DEVELOPMENT_NOT_CONFIRMATION',
        'Outer registered phase classification')
require(receipt['status']=='PASS' and receipt['source_unchanged'] and receipt['stop'] is None,
        'Original completed terminal')
slots=batch['slots']
require(len(slots)==36 and len({(s['world_id'],s['arm']) for s in slots})==36,'36 unique registered slots')
require(batch['budget']==dict(attempts=36,simulated_charge_s=360,scheduled_decisions=360),'Exact registered budget')
require(batch['unused_cache_prefix'] and batch['automatic_retries']==receipt['automatic_retries']==0,
        'Unused cache prefix and no retry')
require(batch['held_inputs_read']==batch['held_seed_reads']==receipt['held_inputs_read']==receipt['held_seed_reads']==0,
        'Recorded no held inputs or seeds')
require(receipt['registered_research_trials']==36 and receipt['llm_calls']==receipt['training_calls']==0,
        'Registered attempt count and no AI calls')
require(batch['pins']==blob_pins(EXEC,batch['pins'])==blob_pins(DATA,batch['pins']),
        'Exact execution and delivered pinned source')
for name,sha in batch['pins'].items():
    require(digest((ROOT/name).read_bytes())==sha,'Working source remains pinned')
src=git('ls-tree','-rz','--name-only',EXEC,'src/aegis_dc').decode().split('\0')
runtime={name:batch['pins'][name] for name in src if name.endswith('.py')}
runtime['src/patrol_rsi/contracts.py']=batch['pins']['src/patrol_rsi/contracts.py']
require(len(runtime)==39,'Runtime implementation file set')
require(not git('diff','--name-only',EXEC,DATA,'--','src','scripts','configs','tests'),
        'Data delivery did not mutate execution inputs or tools')
lock=read(ROOT/'docs/mainline/evidence/30-protocol-lock.json')
require(batch['protocol_sha256']==batch['pins']['docs/mainline/30-comparison-protocol-v1.json']
        and batch['design_lock_sha256']==digest((ROOT/'docs/mainline/evidence/30-protocol-lock.json').read_bytes()),
        'Exact frozen protocol and commitment lock')
require(set(lock['commitments_sha256'])=={'confirmation','ablation','robustness'} and lock['held_inputs_materialized']==0,
        'Held commitments present, no generated held input')

expected=set(receipt['artifacts'])|{'receipt.json'}
actual={p.relative_to(capture).as_posix() for p in capture.rglob('*') if p.is_file()}
require(actual==expected and len(expected)==183,'Complete capture durable set')
full={f'{CAPTURE}/{name}' for name in expected}
require(blob_pins(DATA,full)=={name:digest((ROOT/name).read_bytes()) for name in full},
        'All capture originals equal delivered Git blobs')
for name,sha in receipt['artifacts'].items():
    require(digest((capture/name).read_bytes())==sha,'Terminal artifact fingerprint')

prep=ROOT/'evidence/mainline/engineering/30-comparison-preparation'
original_members=safe_archive(prep/'preparation-originals.zip',read(prep/'manifest.json'))
plan=read(ROOT/'docs/mainline/30-comparison-protocol-v1.json')
phase=plan['phases']['development']
expected_roster=[]
for world in phase['worlds']:
    arms=phase['arms'];shift=(world['slot']-1)%len(arms)
    for arm in arms[shift:]+arms[:shift]:
        expected_roster.append(dict(index=len(expected_roster)+1,world_id=world['id'],family=world['family'],
            arm=arm,duration_s=world['duration_s'],scheduled_decisions=10,
            input_member=f"input-preparation/30-development-inputs-02/{world['id']}/{arm}.json"))
for saved,ref in zip(slots,expected_roster,strict=True):
    require({k:saved[k] for k in ref}==ref and saved['input_sha256']==digest(original_members[ref['input_member']]),
            'Frozen input-only archive and rotated slot')
raw=(capture/'attempts.jsonl').read_bytes()
require(raw.endswith(b'\n'),'Complete final journal newline')
journal=[json.loads(line) for line in raw.splitlines()]
require(len(journal)==72,'Exactly 36 start and terminal journal pairs')
last_time=None
decisions_count=points=intervals=native_members=0
cases={}
for i,slot in enumerate(slots):
    name=f"{slot['index']:02}-{slot['world_id']}-{slot['arm']}"
    folder=capture/name
    require(set(p.name for p in folder.iterdir())=={'start.json','terminal.json','originals.zip','originals.json','audit.json'},
            'Per-slot exact durable set')
    start=read(folder/'start.json');terminal=read(folder/'terminal.json')
    require(start['status']=='STARTED' and terminal['status']=='COMPLETED'
            and start['source']==terminal['source']==EXEC and terminal['physical_call_started']
            and terminal['physical_returned'] and terminal['returned_decisions']==10,
            'One actually returned complete slot lifecycle')
    require(all(start[k]==terminal[k]==v for k,v in slot.items()),'Start terminal matches unique slot')
    for record,saved in zip((start,terminal),journal[2*i:2*i+2],strict=True):
        require(record=={k:v for k,v in saved.items() if k!='recorded_at_utc'},'Journal and slot original equality')
        instant=datetime.fromisoformat(saved['recorded_at_utc'])
        require(last_time is None or instant>=last_time,'Journal chronological ordering')
        last_time=instant
    require(start['charged_simulated_s']==slot['duration_s']==10 and start['charged_scheduled_decisions']==10,
            'Fixed upfront attempt charge')
    require(set(terminal['artifacts'])=={'start.json','originals.zip','originals.json','audit.json'},'Terminal declared return roles')
    for key,sha in terminal['artifacts'].items():
        require(digest((folder/key).read_bytes())==sha,'Per-slot terminal original fingerprint')
    native=safe_archive(folder/'originals.zip',read(folder/'originals.json'))
    require(set(native)==NATIVE,'Four exact native durable members')
    native_members+=len(native)
    document=json.loads(original_members[slot['input_member']])
    scenario=json.loads(native['scenario.json']);run=json.loads(native['run.json'])
    trace=[json.loads(line) for line in native['private-state.jsonl'].splitlines()]
    balances=[json.loads(line) for line in native['balances.jsonl'].splitlines()]
    require(scenario==document['model'],'Actual private scenario exactly matches registered input')
    require(run['code_identity']['git_commit']==EXEC and run['code_identity']['implementation_has_changes'] is False
            and run['code_identity']['files']==runtime,'Actual runtime source identity')
    require(run['scenario_sha256']==digest(canonical(scenario))
            and run['code_identity']['source_tree_sha256']==digest(canonical(runtime)),'Canonical physical source identities')
    require(run['inputs']['dispatch_program']==document['dispatch_program']
            and run['inputs']['duration_s']==10 and run['inputs']['maximum_step_s']==.01
            and run['inputs']['boundary_events']==document['boundary_events']
            and not run['inputs']['work_requests'] and 'action_commands' not in run['inputs'],
            'Actual private/public input separation')
    require(run['state_visibility']=='PRIVATE_PLANT_EVALUATOR_ONLY'
            and run['dispatch_interface']=='PUBLIC_SELECTION_WITH_PRIVATE_EXECUTION'
            and run['field_calibration']=='PENDING' and run['research_gain_claim']=='NOT_ESTABLISHED'
            and run['model_calls']==run['training_calls']==0,'Native provenance and no field/gain/AI claim')
    require(set(run['artifacts'])==NATIVE-{'run.json'},'Native run artifact set')
    for key,ref in run['artifacts'].items():
        require(digest(native[key])==ref['sha256'],'Native artifact source hash')
    require(len(trace)==len(balances)+1 and trace[0]['time_s']==0 and trace[-1]['time_s']==10
            and len(balances)==run['summary']['integration_steps'],'Complete physical row coverage')
    for t in trace:
        require(set(t['domains'])==DOMAINS,'Private trace retains all eight domains')
    for j,row in enumerate(balances):
        require(row['start_s']==trace[j]['time_s'] and row['end_s']==trace[j+1]['time_s']
                and 0<row['end_s']-row['start_s']<=.01+1e-8,'Adjacent physical balance interval')
    pts,ints=len(trace),len(balances)
    points+=pts;intervals+=ints
    program=document['dispatch_program']
    decisions=run['policy_public_decisions']
    require(len(decisions)==10 and [r['frame']['as_of_s'] for r in decisions]==list(range(10)),
            'Ten scheduled and returned public decisions')
    decisions_count+=len(decisions)
    for decision in decisions:
        require(set(decision)=={'frame','history','choice'} and set(decision['frame'])==FRAME
                and set(decision['frame']['evidence'])==EVIDENCE and set(decision['history'])=={'issued','work_feedback'},
                'Closed public decision and history field boundaries')
        frame=decision['frame'];t=frame['as_of_s']
        require(frame['nominal_knowledge']==program['nominal_knowledge']
                and frame['requests']==program['preparation_requests']
                and frame['evidence']['as_of_s']==t,'Only declared static knowledge and current requests')
        for record in frame['evidence']['records']:
            require(set(record)==RECORD and record['observed_at_s']<=record['arrived_at_s']<=t,
                    'Current public observation excludes future and extra private fields')
        require(decision['choice']['policy']==slot['arm'] and decision['choice']['execution_permission'] is False,
                'Selection stays separate from physical authority')
    audit=read(folder/'audit.json')
    require(audit['status']=='PASS_RETURNED_DEVELOPMENT_EVIDENCE' and audit['arm']==slot['arm']
            and audit['hard_violations']==[] and audit['verified_closure']=='NOT_EVALUATED_WITHOUT_POST_ACTION_PROTOCOL',
            'Saved audit scope and hard constraints')
    require(audit['trace_points']==pts and audit['balance_intervals']==ints and len(audit['opportunities'])==10,
            'Saved audit actual denominators')
    cases[(slot['world_id'],slot['arm'])]=(run,audit,document)
totals=dict(started=36,completed=36,failed=0,interrupted=0,unrun=0,charged_simulated_s=360,
            charged_scheduled_decisions=360,returned_decisions=decisions_count)
require(receipt['total']==totals and native_members==144,'Exact charged and completed aggregate')
support=ROOT/SCOPE/'support'
support_manifest=read(support/'manifest.json')
support_members=safe_archive(support/'originals.zip',support_manifest)
require(len(support_members)==34,'Retained support originals and failures')
stdout=json.loads(support_members['31-development-launch-01/stdout.raw'])
require(stdout['execution_commit']==EXEC and stdout['status']=='PASS' and stdout['total']==totals,
        'Outer launch terminal matches batch original')
require(support_members['31-development-launch-01/stderr.raw']==b'','Outer launch native stderr empty')
require(json.loads(support_members['31-plan-red-01/terminal.json'])['returncode']!=0
        and json.loads(support_members['31-saved-guard-preflight-02/receipt.json'])['status']=='FAIL',
        'Original pre-capture refusals retained')
report=read(ROOT/SCOPE/'results.json')
require(report['execution_commit']==EXEC and report['batch_status']=='PASS' and report['ledger_totals']==totals
        and report['new_facility_calls']==report['new_selector_calls']==report['held_inputs_read']==0,
        'Saved report belongs to this actual batch without replay')
deltas=[]
for world in phase['worlds']:
    base=cells=cases[(world['id'],'one_observation_lookahead')]
    cand=cases[(world['id'],'evidence_consistent_contingent')]
    delta=base[0]['summary']['service_deficit_time_s']-cand[0]['summary']['service_deficit_time_s']
    deltas.append(delta)
    row=next(r for r in report['pairs'] if r['world_id']==world['id'])
    require(abs(row['delta_service_deficit_s']-delta)<=1e-9,'Primary saved pair delta uses actual originals')
require(abs(report['primary_mean_delta_service_s']-fsum(deltas)/6)<=1e-12,'Mean retains six development pairs')
current=git('rev-parse','HEAD').decode().strip()
require(not git('diff','--name-only',DATA,current,'--',SCOPE),'Saved reviewed package unchanged during review')
OUT.mkdir(exist_ok=True)
proof=dict(status='PASS_SAVED_DEVELOPMENT_STANDARDS',execution=EXEC,delivery=DATA,
    checks=checks,check_groups=groups,source_pins=len(batch['pins']),capture_artifacts=len(expected),
    complete_attempts=36,charged_simulated_s=360,actual_decisions=decisions_count,
    native_archive_members=native_members,private_trace_rows=points,balance_intervals=intervals,
    support_members=len(support_members),unresolved_findings=0,facility_calls=0,selector_calls=0,
    nonce_reads=0,held_inputs_materialized=0,
    scope='Independent exact Git/ZIP/journal and public boundary readback; no new run, field or effectiveness claim.')
with (OUT/'proof.json').open('x',encoding='utf-8',newline='\n') as stream:
    json.dump(proof,stream,ensure_ascii=False,indent=2,allow_nan=False);stream.write('\n')
print(json.dumps({k:v for k,v in proof.items() if k!='check_groups'}))
