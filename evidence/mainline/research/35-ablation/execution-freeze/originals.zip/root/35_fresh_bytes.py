import argparse,hashlib,json,subprocess
from pathlib import Path
from zipfile import ZipFile
p=argparse.ArgumentParser();p.add_argument('checkout',type=Path);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
root=a.checkout.resolve();read=lambda p:json.loads(p.read_bytes());sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*v):return subprocess.check_output(['git',*v],cwd=root)
head=git('rev-parse','HEAD').decode().strip();assert not git('status','--porcelain')
lock=read(root/'docs/mainline/evidence/30-ablation-execution-lock.json')
names=set(lock['execution_pins'])|{'docs/mainline/evidence/30-ablation-execution-lock.json',
    'docs/mainline/35-planner-executor-extension.json','docs/mainline/35-ablation-execution.json'}
for prefix in ('evidence/mainline/research/35-ablation','evidence/mainline/engineering/35-ablation-adapter'):
    names.update(p.relative_to(root).as_posix() for p in (root/prefix).rglob('*') if p.is_file())
names=sorted(names);raw=subprocess.check_output(['git','cat-file','--batch'],cwd=root,input=''.join(head+':'+n+'\n' for n in names).encode())
offset=0
for name in names:
    end=raw.index(b'\n',offset);header=raw[offset:end].split();assert len(header)==3 and header[1]==b'blob'
    start=end+1;size=int(header[2]);assert raw[start:start+size]==(root/name).read_bytes(),name;offset=start+size+1
assert offset==len(raw)
for directory in ('evidence/mainline/research/35-ablation/preparation-support','evidence/mainline/engineering/35-ablation-adapter/development'):
    folder=root/directory;manifest=read(folder/'manifest.json');assert sha((folder/'originals.zip').read_bytes())==manifest['archive_sha256']
    with ZipFile(folder/'originals.zip') as z:
        assert len(z.namelist())==len(manifest['members']) and set(z.namelist())==set(manifest['members'])
        assert all(sha(z.read(n))==h for n,h in manifest['members'].items())
fixture=root/'evidence/mainline/engineering/35-ablation-adapter/fixture-01'
attempt=read(fixture/'attempt.json');oldsource=attempt['source']
for name,expected in attempt['pins'].items():assert sha(git('cat-file','blob',oldsource+':'+name))==expected,name
receipt=read(fixture/'receipt.json');assert receipt['status']=='PASS_ENGINEERING_VIEW_WITNESS'
assert all(sha((fixture/n).read_bytes())==h for n,h in receipt['artifacts'].items())
originals=read(fixture/'originals.json');assert sha((fixture/'originals.zip').read_bytes())==originals['archive_sha256']
with ZipFile(fixture/'originals.zip') as z:
    assert len(z.namelist())==4 and all(sha(z.read(n))==h for n,h in originals['members'].items())
    run=json.loads(z.read('run.json'))
assert run['code_identity']['git_commit']==oldsource
assert run['ablation_execution_audit']['adapter_sha256']==sha(git('cat-file','blob',oldsource+':scripts/ablation_planner.py'))
value=dict(status='PASS_EXACT_FRESH_ABLATION_FREEZE_BYTES',delivery=head,declared_files=len(names),
    source_pins=len(lock['execution_pins']),inputs=len(lock['input_hashes']),
    prior_engineering_execution_source=oldsource,prior_engineering_scope='Only original628 joint witness; no claim about later mapping dynamics.',
    nonce_reads=0,physical_calls=0,selector_calls=0)
with a.output.open('x',encoding='utf-8',newline='\n') as f:json.dump(value,f,indent=2);f.write('\n')
print(json.dumps(value))
