import hashlib,json
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
root=Path(__file__).resolve().parents[1];integration=Path('C:/Users/Donson/Documents/ChatGPT/Renly')
read=lambda p:json.loads(p.read_bytes());sha=lambda b:hashlib.sha256(b).hexdigest()
def write(p,obj):p.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
spec=read(integration/'.work/35-spec-freeze-01/receipt.json');standard=read(integration/'.work/35-standards-freeze-01/report.json')
assert not spec.get('findings',[]) and not standard.get('hard_findings',[]) and not standard.get('advisory_smell_findings',[])
assert spec['candidate']==standard['candidate']=='8bf7ae975b105995f0b620c207a1234bfcd61753'
files={}
for directory in ('35-spec-freeze-01','35-standards-freeze-01'):
    folder=integration/'.work'/directory;assert (folder/'manifest.json').is_file()
    for p in folder.iterdir():
        if p.is_file():files['review/'+directory+'/'+p.name]=p.read_bytes()
for name in ('35-fresh-freeze-proof-01.json','35-fresh-byte-proof-01.json','35_fresh_bytes.py'):
    files['root/'+name]=(integration/'.work'/name).read_bytes()
files['author/35_authorize_execution.py']=Path(__file__).read_bytes()
out=root/'evidence/mainline/research/35-ablation/execution-freeze';out.mkdir()
with ZipFile(out/'originals.zip','x',compression=ZIP_DEFLATED) as z:
    for n,b in sorted(files.items()):z.writestr(n,b)
manifest=dict(schema='aegisdc-reviewed-ablation-execution-freeze-v1',archive_sha256=sha((out/'originals.zip').read_bytes()),
    members={n:sha(b) for n,b in sorted(files.items())},review_physical_calls=0,review_selector_calls=0,review_nonce_reads=0,
    unresolved_findings=0,prepared_inputs=32,registered_ablation_attempts=0)
write(out/'manifest.json',manifest)
lockpath=root/'docs/mainline/evidence/30-ablation-execution-lock.json';lock=read(lockpath)
lock['status']='REVIEWED_FOR_EXECUTION';write(lockpath,lock)
write(root/'docs/mainline/evidence/35-execution-authorization.json',dict(status='REVIEWED_TO_EXECUTE',ticket='35',date='2026-11-08',
    scope='Only original32 ablation slots; not acceptance of their future outcomes.',
    reviewed_candidate='8bf7ae975b105995f0b620c207a1234bfcd61753',execution_source=lock['execution_source'],
    execution_lock=lockpath.relative_to(root).as_posix(),execution_lock_sha256=sha(lockpath.read_bytes()),
    inputs=32,worlds=8,budget=lock['budget'],automatic_retries=0,
    reviews=dict(spec='PASS_0_UNRESOLVED',standards='PASS_0_UNRESOLVED'),
    freeze_originals=out.relative_to(root).as_posix()+'/manifest.json',freeze_originals_sha256=sha((out/'manifest.json').read_bytes()),
    fresh_proof=read(integration/'.work/35-fresh-byte-proof-01.json'),
    primary_confirmation_result='NO_PRACTICAL_GAIN',field_calibration='PENDING'))
p=root/'docs/mainline/progress.json';progress=read(p);progress['active_implementations'][0]['state']='authorized_unique32slot_capture'
progress['liveness_refresh']='2026-11-08:35 exact32 inputs/274 files and fresh delivery passed both independent review axes; authorized one original32slot capture,0attempts before launch.'
write(p,progress)
print(json.dumps(dict(status='REVIEWED_TO_EXECUTE',registered_ablation_attempts=0,inputs=32,execution_source=lock['execution_source'])))
