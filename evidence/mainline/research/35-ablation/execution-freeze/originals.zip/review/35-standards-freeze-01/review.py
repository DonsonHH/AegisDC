"""Saved-only final ablation freeze audit, without importing project code."""
from hashlib import sha256
import importlib.util
import json
from pathlib import Path
import sys

OUT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('immutable_standards_helpers',OUT.parent/'32-standards-review-01'/'review.py')
r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r)
r.ROOT=Path(r'C:\Users\Donson\.codex\worktrees\mainline35-ablation\Renly')
CANDIDATE='8bf7ae975b105995f0b620c207a1234bfcd61753'
SOURCE='6c98bee2404c8a4694ce334204ca6e2d996f6bae'
CODE='6255fad792218790d3433df42f84d3d495e3b4d8'
PREP='evidence/mainline/research/35-ablation/prepared-01'
LOCK='docs/mainline/evidence/30-ablation-execution-lock.json'
blob=lambda p,rev=CANDIDATE:r.blob(p,rev)
doc=lambda p,rev=CANDIDATE:r.doc(p,rev)
check=r.check
fingerprint=lambda value:sha256(json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()


def main():
    check(r.git('merge-base','--is-ancestor',SOURCE,CANDIDATE)==b'','Reviewed preparation/execution source precedes input freeze')
    lock=doc(LOCK);receipt=doc(PREP+'/receipt.json');plan=doc(r.PROTOCOL);phase=plan['phases']['ablation']
    check(lock['schema']=='aegisdc-comparison-execution-lock-v1' and lock['status']=='PENDING_REVIEW' and lock['phase']=='ablation' and lock['execution_source']==SOURCE,'Prospective ablation lock names reviewed source and remains pending authorization')
    pins=lock['execution_pins']
    check(len(pins)==274 and set(pins)==r.code_paths(SOURCE)==r.code_paths(CANDIDATE),'Complete274-file execution source universe exact')
    r.pin_check(SOURCE,pins,'All execution pins equal reviewed source Git blobs')
    r.pin_check(CANDIDATE,pins,'All execution pins equal frozen candidate Git blobs')
    r.pin_check(CODE,pins,'All execution code/config bytes unchanged from corrected adapter')
    check(all(sha256((r.ROOT/p).read_bytes()).hexdigest()==h for p,h in pins.items()),'All274 working execution bytes exact')
    check(lock['interpreter_sha256']==sha256(Path(sys.executable).read_bytes()).hexdigest(),'Actual audit interpreter equals frozen interpreter')
    check(lock['design_lock_sha256']==sha256(blob(r.LOCK)).hexdigest() and blob(r.LOCK)==blob(r.LOCK,SOURCE) and blob(r.PROTOCOL)==blob(r.PROTOCOL,SOURCE),'Unchanged design lock and preregistered protocol bound exactly')
    budget=dict(attempts=32,simulated_charge_s=320,scheduled_decisions=320)
    check(lock['budget']==phase['budget']==budget,'Exact32 attempts320 seconds320 decisions retained')
    check(receipt['status']=='PASS_INPUT_ONLY' and receipt['source']==SOURCE and receipt['prepared_inputs']==32 and receipt['physical_calls']==receipt['selector_calls']==receipt['registered_research_trials']==0 and receipt['nonce_reads']==2,'One successful input-only preparation declares two nonce reads and zero actual/selector trials')
    r.pin_check(SOURCE,receipt['pins'],'Preparation receipt tools and inputs equal actual preparation revision')
    source_lock=doc(r.LOCK)
    check(receipt['nonce_commitment']==source_lock['commitments_sha256']['ablation'],'Preparation binds original independent ablation commitment without nonce access')
    gate=receipt['gate']
    check(gate['checked_commit']==SOURCE and gate['phase']=='ablation' and gate['stage']=='prepare' and gate['facility_calls']==gate['selector_calls']==0,'Retained phase gate was input-only at recorded source')
    paths=r.tree(CANDIDATE,PREP);r.fetch(CANDIDATE,paths)
    check({p[len(PREP)+1:] for p in paths}==set(receipt['artifacts'])|{'receipt.json'} and all(sha256(blob(PREP+'/'+p)).hexdigest()==h for p,h in receipt['artifacts'].items()),'Complete34-file prepared durable set and manifest hashes exact',files=len(paths))
    check(all((r.ROOT/p).read_bytes()==blob(p) for p in paths),'Prepared current bytes match immutable delivery blobs')
    arms=('full','without_nonfixed_context','without_dependency_context','without_joint_crew_planning')
    check(tuple(phase['arms'])==arms and len(phase['worlds'])==8,'Original eight-world/four-mask roster unchanged')
    expected={w['id']+'/'+a+'.json' for w in phase['worlds'] for a in arms}
    check(set(receipt['input_hashes'])==set(lock['input_hashes'])==expected and receipt['input_hashes']==lock['input_hashes'],'Exact32 names/hashes bound jointly by preparation and execution lock')
    rows=[json.loads(row) for row in blob(PREP+'/attempts.jsonl').splitlines()]
    check(len(rows)==16 and all(rows[i*2]['status']=='STARTED_INPUT_WORLD' and rows[i*2+1]['status']=='COMPLETED_INPUT_WORLD' and rows[i*2]['world_id']==rows[i*2+1]['world_id']==w['id'] and rows[i*2]['variant']==rows[i*2+1]['variant'] and rows[i*2+1]['arms']==4 for i,w in enumerate(phase['worlds'])),'Complete16-row preparation ledger reconciles eight unique world lifecycles')
    assignments={row['world_id']:row for row in receipt['assigned_worlds']}
    blueprint=doc('configs/full-facility-comparison-held-blueprints-admission-v1.json')['ablation']
    check(len(assignments)==8,'All eight actual recipe assignments retained')
    seed_pairs=set();world_summaries=[]
    for world in phase['worlds']:
        assignment=assignments[world['id']];recipe=next(x for x in blueprint[world['family']] if x['variant']==assignment['variant'])
        common=[];seeds=set()
        for arm in arms:
            name=world['id']+'/'+arm+'.json';raw=blob(PREP+'/inputs/'+name);document=json.loads(raw)
            check(sha256(raw).hexdigest()==lock['input_hashes'][name] and document.pop('ablation_mask')==arm,'Exact frozen input and mask '+name)
            program=document['dispatch_program'];policy=program['policy_program'];params={p['id']:p['value'] for p in document['model']['parameters']}
            check(document['duration_s']==10 and document['maximum_step_s']==.01 and document['boundary_events']==recipe['events'] and params['network_service_capacity']==recipe['network_cap'] and params['filter_resistance_multiplier']==recipe['filter_multiplier'] and assignment['family']==world['family'],'Preregistered actual physical recipe and clocks '+name)
            check(policy['policy']=='evidence_consistent_contingent' and program['decision_times_s']==plan['decision_times_s'] and policy['resource_budget']==plan['comparison']['common_admission_budget'] and policy['intervention_declaration']==program['intervention_program'],'Unchanged full candidate and actual permissions/budget '+name)
            fixed=program['sensor_program']['realization']['seed'];portable=program['inspection_program']['realizations']['lookahead-inspect']['seed']
            check(type(fixed) is int and 0<=fixed<2**64 and type(portable) is int and 0<=portable<2**128,'Fixed64/portable128 channel domains '+name)
            seeds.add((fixed,portable));common.append(fingerprint(document))
        check(len(set(common))==len(seeds)==1,'All four actual documents identical except declared mask '+world['id'])
        seed_pairs.update(seeds);world_summaries.append(dict(world_id=world['id'],family=world['family'],variant=assignment['variant'],common_actual_sha256=common[0]))
    check(len(seed_pairs)==8,'Eight independent worlds have distinct saved channel pairs')
    for family,recipes in blueprint.items():
        used=[row['variant'] for row in assignments.values() if row['family']==family]
        check(len(used)==len(set(used))==2 and set(used)=={row['variant'] for row in recipes},'No family recipe duplication or outcome-based replacement '+family)
    for subtree in ('evidence/mainline/engineering/35-ablation-adapter',r.OLD,r.PREP,'evidence/mainline/research/33-confirmation/capture-01'):
        check(r.git('rev-parse',SOURCE+':'+subtree)==r.git('rev-parse',CANDIDATE+':'+subtree),'Earlier evidence remains byte-identical '+subtree)
    progress=doc('docs/mainline/progress.json')
    check(progress['research_trials']['ablation']['attempts']==0 and progress['research_trials']['ablation']['materialized'] is True and not r.tree(CANDIDATE,'evidence/mainline/research/35-ablation/capture-01'),'No registered ablation execution or added budget charge yet')
    report=dict(status='PASS_FINAL_ABLATION_FREEZE_STANDARDS',axis='Standards',candidate=CANDIDATE,preparation_source=SOURCE,execution_source=SOURCE,source_files=274,worlds=8,inputs=32,budget=budget,hard_findings=[],advisory_smell_findings=[],checks=r.checks,world_provenance=world_summaries,scope=dict(reviewer_nonce_reads=0,seed_derivations=0,physical_calls=0,selector_calls=0,tests=0,project_code_imports=0,tracked_edits=0),limit='Prospective PENDING_REVIEW lock requires separate exact review authorization before actual execution; prior pre-execution findings and original witness remain unchanged.')
    (OUT/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:v for k,v in report.items() if k not in ('checks','world_provenance')},ensure_ascii=False))
    print('Bounded saved/static checks:',len(r.checks))


if __name__=='__main__':main()
