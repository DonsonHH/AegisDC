"""Independent35 exact input/source freeze audit. No project imports or nonce/seed derivation."""
import hashlib
import json
import subprocess
import sys
from pathlib import Path

REPO=Path('C:/Users/Donson/.codex/worktrees/mainline35-ablation/Renly')
OUT=Path(__file__).resolve().parent
REF='8bf7ae975b105995f0b620c207a1234bfcd61753'
SOURCE='6c98bee2404c8a4694ce334204ca6e2d996f6bae'
BASE='4b5f0b34'
PREP='evidence/mainline/research/35-ablation/prepared-01/'
LOCK='docs/mainline/evidence/30-ablation-execution-lock.json'
PROTOCOL='docs/mainline/30-comparison-protocol-v1.json'
DESIGN='docs/mainline/evidence/30-protocol-lock.json'
ARMS=['full','without_nonfixed_context','without_dependency_context','without_joint_crew_planning']
checks=[]
def git(*a):return subprocess.check_output(['git',*a],cwd=REPO)
def sha(raw):return hashlib.sha256(raw).hexdigest()
def names(ref,*paths):return set(filter(None,git('ls-tree','-rz','--name-only',ref,*paths).decode().split('\0')))
def batch(ref,paths):
    paths=sorted(paths);offset=0;result={}
    raw=subprocess.check_output(['git','cat-file','--batch'],cwd=REPO,input=''.join(ref+':'+n+'\n' for n in paths).encode())
    for n in paths:
        end=raw.index(b'\n',offset);header=raw[offset:end].split();assert len(header)==3 and header[1]==b'blob'
        start=end+1;size=int(header[2]);result[n]=raw[start:start+size];offset=start+size+1
    assert offset==len(raw);return result
def read(n):return json.loads(files[n])
def check(ok,message):
    if not ok:raise AssertionError(message)
    checks.append(message)
paths=names(REF,PREP,'src','scripts','configs')|{LOCK,PROTOCOL,DESIGN,'docs/mainline/progress.json'}
files=batch(REF,paths);lock=read(LOCK);plan=read(PROTOCOL);design=read(DESIGN);receipt=read(PREP+'receipt.json')
phase=plan['phases']['ablation'];blueprints=read('configs/full-facility-comparison-held-blueprints-admission-v1.json')
check(lock['schema']=='aegisdc-comparison-execution-lock-v1' and lock['status']=='PENDING_REVIEW'
      and lock['phase']=='ablation' and lock['execution_source']==SOURCE
      and lock['design_lock_sha256']==sha(files[DESIGN]),
      'Prospective ablation lock binds original design and reviewed code source, blocked pending review')
expected={w['id']+'/'+a+'.json' for w in phase['worlds'] for a in ARMS}
check(phase['arms']==ARMS and len(phase['worlds'])==8 and len(expected)==32
      and lock['budget']==phase['budget']==dict(attempts=32,simulated_charge_s=320,scheduled_decisions=320),
      'Original four literal masks,8 independent worlds and32/320/320 phase budget retained')
check(receipt['status']=='PASS_INPUT_ONLY' and receipt['source']==SOURCE and receipt['prepared_inputs']==32
      and receipt['physical_calls']==receipt['selector_calls']==receipt['registered_research_trials']==0
      and receipt['nonce_reads']==2 and receipt['nonce_commitment']==design['commitments_sha256']['ablation'],
      'One completed input-only preparation records two prior nonce reads and zero selector/physical/research calls')
check(set(lock['input_hashes'])==set(receipt['input_hashes'])==expected and lock['input_hashes']==receipt['input_hashes'],
      'All32 input identities have one exact phase roster and raw SHA')
check({n[len(PREP):] for n in files if n.startswith(PREP)}==set(receipt['artifacts'])|{'receipt.json'}
      and all(sha(files[PREP+n])==h for n,h in receipt['artifacts'].items()),
      'Exact durable prepared membership and every committed original SHA verified')
source_files=batch(SOURCE,set(receipt['pins'])|set(lock['execution_pins']))
check(all(sha(source_files[n])==h for n,h in receipt['pins'].items()),
      'All280 preparation source/configuration/authority pins match actual preparation revision')
code={n for n in names(SOURCE,'src','scripts','configs') if n.endswith(('.py','.json'))}
check(set(lock['execution_pins'])==code=={n for n in names(REF,'src','scripts','configs') if n.endswith(('.py','.json'))}
      and len(code)==274 and all(sha(source_files[n])==sha(files[n])==h for n,h in lock['execution_pins'].items()),
      'All274 executable/configuration members and bytes match source6c98 and final candidate')
old_code={n for n in names(BASE,'src','scripts','configs') if n.endswith(('.py','.json'))}
old=batch(BASE,old_code)
check(len(old_code)==269 and all(old[n]==source_files[n] for n in old_code),
      'Every original269 executable/configuration blob remains immutable; no candidate tuning')
check(sha(Path(sys.executable).read_bytes())==lock['interpreter_sha256'],
      'Exact interpreter binary matches prospective execution lock')
assignments={r['world_id']:r for r in receipt['assigned_worlds']}
check(len(assignments)==8 and set(assignments)=={w['id'] for w in phase['worlds']},
      'Every original independent world has one saved family/variant assignment')
all_seeds=[]
for world in phase['worlds']:
    assignment=assignments[world['id']]
    assert assignment['family']==world['family']
    recipe=next(r for r in blueprints['ablation'][world['family']] if r['variant']==assignment['variant'])
    actual=[];literal=[];seeds=set()
    for arm in ARMS:
        name=world['id']+'/'+arm+'.json';raw=files[PREP+'inputs/'+name]
        assert sha(raw)==lock['input_hashes'][name]
        token=('"ablation_mask": "'+arm+'"').encode();assert raw.count(token)==1
        literal.append(raw.replace(token,b'"ablation_mask": "MASK"'))
        document=json.loads(raw);assert document.pop('ablation_mask')==arm;actual.append(document)
        p={r['id']:r['value'] for r in document['model']['parameters']};program=document['dispatch_program']
        assert document['duration_s']==10 and document['maximum_step_s']==.01
        assert document['boundary_events']==recipe['events'] and p['network_service_capacity']==recipe['network_cap']
        assert p['filter_resistance_multiplier']==recipe['filter_multiplier']
        assert program['decision_times_s']==plan['decision_times_s']
        assert program['policy_program']['policy']=='evidence_consistent_contingent'
        assert program['policy_program']['resource_budget']==plan['comparison']['common_admission_budget']
        assert set(program['nominal_knowledge']['graphs'])=={'physical','functional','control_information','access'}
        assert {'f12','f13','f14'}<={e['id'] for e in program['nominal_knowledge']['graphs']['functional']}
        fixed=program['sensor_program']['realization']['seed']
        portable=program['inspection_program']['realizations']['lookahead-inspect']['seed']
        assert type(fixed) is int and 0<=fixed<2**64 and type(portable) is int and 0<=portable<2**128
        seeds.add((fixed,portable))
    assert all(d==actual[0] for d in actual) and len(set(literal))==1 and len(seeds)==1
    all_seeds.extend(seeds)
check(True,'Each four-arm group has byte-identical full actual document except its top mask literal; actual graph/evidence/crew/actions/resources remain complete')
check(len(set(all_seeds))==8,'Same compatible private realization within each world; eight distinct seed pairs across worlds, values not disclosed or derived')
for family,recipes in blueprints['ablation'].items():
    variants=[r['variant'] for r in assignments.values() if r['family']==family]
    assert len(variants)==len(set(variants))==2 and set(variants)=={r['variant'] for r in recipes}
check(True,'Exactly two original variants per family appear once each without replacement')
rows=[json.loads(r) for r in files[PREP+'attempts.jsonl'].splitlines()]
check(len(rows)==16 and [r['status'] for r in rows]==['STARTED_INPUT_WORLD','COMPLETED_INPUT_WORLD']*8,
      'All eight input preparation lifecycles have one durable start and terminal completion')
compiler=files['scripts/prepare_ablation.py'].decode()
check("namespace=plan['seed_policy']['namespaces']['ablation']" in compiler
      and "assignment_key(nonce,plan['id'],namespace,f,r['variant'])" in compiler
      and "observation_seed(nonce,plan['id'],namespace,world['id'],'portable')" in compiler
      and "observation_seed(nonce,plan['id'],namespace,world['id'],'fixed')>>64" in compiler
      and plan['seed_policy']['namespaces']['ablation']=='V6-M5-ablate-v1',
      'Source retains original HMAC assignment/namespace/portable128 law and declared fixed upper64 interface rule; no rederivation performed')
progress=read('docs/mainline/progress.json')
check(progress['current_ticket']=='35' and progress['research_trials']['ablation']['attempts']==0
      and progress['research_trials']['primary_confirmation_status']=='NO_PRACTICAL_GAIN'
      and not names(REF,'evidence/mainline/research/35-ablation/capture-01'),
      'Primary negative result preserved and no registered ablation attempt/outcome exists before authorization')
result=dict(status='PASS_EXACT_35_FREEZE_0_UNRESOLVED',candidate=REF,execution_source=SOURCE,findings=[],
    checks=checks,worlds=8,inputs=32,executable_pins=274,original_immutable_blobs=269,
    prior_interface_verdict='6255 corrected source review remains applicable;6c98 has identical code',
    remaining_execution_gates=['Root fresh-checkout proof','Review lock to REVIEWED_FOR_EXECUTION','Committed exact35 execution authorization'],
    reviewer_nonce_reads=0,reviewer_seed_derivations=0,reviewer_project_imports=0,reviewer_tests=0,reviewer_physical_calls=0,reviewer_selectors=0)
with (OUT/'receipt.json').open('x',encoding='utf-8') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps({k:v for k,v in result.items() if k!='checks'}))
