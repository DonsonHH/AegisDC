import hashlib,json,sys
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
root=Path(__file__).resolve().parents[1];sys.path.insert(0,str(root/'scripts'))
from development_journal import reconcile
from inspection_delivery import durable,hashes
read=lambda p:json.loads(p.read_bytes());sha=lambda b:hashlib.sha256(b).hexdigest()
capture=root/'evidence/mainline/research/35-ablation/capture-01';receipt=read(capture/'receipt.json');batch=read(capture/'batch.json')
assert read(root/'.work/35-capture-launch-01/terminal.json')['returncode']==0
assert receipt['status']=='PASS' and receipt['source_unchanged'] and receipt['automatic_retries']==0
assert reconcile(capture,batch['slots'],batch['execution_commit'])==receipt['total']==dict(started=32,completed=32,failed=0,interrupted=0,unrun=0,
    charged_simulated_s=320,charged_scheduled_decisions=320,returned_decisions=320)
assert durable(capture)==set(receipt['artifacts'])|{'receipt.json'}
assert all(sha((capture/n).read_bytes())==h for n,h in receipt['artifacts'].items())
assert batch['pins']==hashes(batch['execution_commit'],batch['pins']) and all(sha((root/n).read_bytes())==h for n,h in batch['pins'].items())
files={n:(root/'.work'/n).read_bytes() for n in ('run_35_capture.py','35_seal_capture.py')}
for p in (root/'.work/35-capture-launch-01').iterdir():
    if p.is_file():files['launch/'+p.name]=p.read_bytes()
out=root/'evidence/mainline/research/35-ablation/capture-support';out.mkdir()
with ZipFile(out/'originals.zip','x',compression=ZIP_DEFLATED) as z:
    for n,b in sorted(files.items()):z.writestr(n,b)
manifest=dict(schema='aegisdc-original-ablation-capture-support-v1',archive_sha256=sha((out/'originals.zip').read_bytes()),
    members={n:sha(b) for n,b in sorted(files.items())},new_physical_calls=0,new_selector_calls=0)
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8',newline='\n')
record=dict(status='CAPTURED_PENDING_INDEPENDENT_ACCEPTANCE',ticket='35',phase='ablation',
    execution_source=batch['execution_commit'],frozen_execution_source='6c98bee2404c8a4694ce334204ca6e2d996f6bae',
    totals=receipt['total'],worlds=8,arms=4,native_archives=32,native_members=128,
    registered_global_attempts=164,primary_confirmation_result_unchanged='NO_PRACTICAL_GAIN',field_calibration='PENDING')
(root/'docs/mainline/evidence/35.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(dict(status='ABLATION_ORIGINALS_SEALED',runs=32,native_members=128,capture_files=len(durable(capture)))))
