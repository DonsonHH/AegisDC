import json,subprocess,sys,os
from datetime import datetime,timezone
from hashlib import sha256
from pathlib import Path
root=Path(__file__).resolve().parents[1];source='d102173f2a8c31402f70dbf4522371aa18070ed9'
launch=root/'.work/35-capture-launch-01';launch.mkdir()
cmd=[sys.executable,'-B','-X','utf8','-X','pycache_prefix='+str(root/'.work/35-capture-unused-cache-01'),
    'scripts/registered_ablation.py','capture','--source',source,
    '--output',str(root/'evidence/mainline/research/35-ablation/capture-01'),
    '--native-staging',str(root/'.work/35-ablation-native-01')]
def write(n,obj):
    with (launch/n).open('x',encoding='utf-8',newline='\n') as f:json.dump(obj,f,indent=2);f.write('\n')
write('attempt.json',dict(source=source,command=cmd,started_utc=datetime.now(timezone.utc).isoformat(),
    launcher_sha256=sha256(Path(__file__).read_bytes()).hexdigest(),automatic_retries=0,classification='REGISTERED_MECHANISM_ABLATION'))
env=os.environ.copy();env['PYTHONPATH']=str(root/'src')
try:
    with (launch/'stdio.log').open('xb') as out:run=subprocess.run(cmd,cwd=root,env=env,stdout=out,stderr=subprocess.STDOUT)
    code=run.returncode
except BaseException as exc:
    write('launcher-error.json',dict(error_type=type(exc).__name__,error=str(exc)));code=255
write('terminal.json',dict(returncode=code,finished_utc=datetime.now(timezone.utc).isoformat(),automatic_retries=0))
raise SystemExit(code)
