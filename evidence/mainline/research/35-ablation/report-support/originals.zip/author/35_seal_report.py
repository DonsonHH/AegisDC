import hashlib,json
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
root=Path(__file__).resolve().parents[1];integration=Path('C:/Users/Donson/Documents/ChatGPT/Renly')
out=root/'evidence/mainline/research/35-ablation/report-support';out.mkdir()
files={'author/render_35_results.py':(integration/'.work/render_35_results.py').read_bytes(),
    'author/35_seal_report.py':Path(__file__).read_bytes(),'author/35-saved-analysis-01.log':(root/'.work/35-saved-analysis-01.log').read_bytes()}
for directory in ('35-spec-saved-01','35-standards-saved-01'):
    folder=integration/'.work'/directory;assert (folder/'manifest.json').is_file()
    for p in folder.iterdir():
        if p.is_file():files['review/'+directory+'/'+p.name]=p.read_bytes()
with ZipFile(out/'originals.zip','x',compression=ZIP_DEFLATED) as z:
    for n,b in sorted(files.items()):z.writestr(n,b)
sha=lambda b:hashlib.sha256(b).hexdigest()
manifest=dict(schema='aegisdc-saved-ablation-report-artifacts-v1',archive_sha256=sha((out/'originals.zip').read_bytes()),
    members={n:sha(b) for n,b in sorted(files.items())},new_physical_calls=0,new_selector_calls=0,new_seed_reads=0,
    primary_confirmation_unchanged='NO_PRACTICAL_GAIN',independent_review_findings=0)
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(dict(status='ABLATION_REPORT_SUPPORT_SEALED',members=len(files))))
