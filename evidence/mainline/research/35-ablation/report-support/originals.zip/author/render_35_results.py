"""Plot the complete fixed ablation design without selecting favorable units."""
import argparse,csv,hashlib,json,sys
from pathlib import Path
from math import fsum
sys.path.insert(0,'C:/Users/Donson/Documents/ChatGPT/Renly/.work/paper-writing-deps')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
import numpy as np
p=argparse.ArgumentParser();p.add_argument('data',type=Path);a=p.parse_args();folder=a.data.parent;out=folder/'figures';out.mkdir(exist_ok=True)
d=json.loads(a.data.read_bytes());assert d['completed_runs']==32 and d['planned_worlds']==8
font=Path('C:/Windows/Fonts/msyh.ttc');font_manager.fontManager.addfont(str(font))
INK,GRAY,TEAL,ORANGE='#183449','#536d80','#087f79','#b05021'
plt.rcParams.update({'font.family':font_manager.FontProperties(fname=str(font)).get_name(),
    'axes.spines.top':False,'axes.spines.right':False,'axes.edgecolor':'#b6c7d4','axes.labelcolor':INK,
    'xtick.color':GRAY,'ytick.color':INK,'svg.fonttype':'path','svg.hashsalt':'aegisdc-35'})
arms=['full','without_nonfixed_context','without_dependency_context','without_joint_crew_planning']
labels=['完整候选','屏蔽非固定线索','屏蔽依赖后果知识','屏蔽团队任务选择']
families={'network-restorable':'网络可恢复','cooling-masked':'冷却改善被遮蔽','misleading-report':'误导报告','protection-or-access':'保护／访问限制'}
worlds=sorted({r['world_id'] for r in d['runs']});rows={(r['world_id'],r['arm']):r for r in d['runs']}
def save(fig,name):
    fig.savefig(out/(name+'.png'),dpi=170,metadata={'Software':'AegisDC fixed ablation'})
    fig.savefig(out/(name+'.svg'),metadata={'Creator':'AegisDC','Date':None});plt.close(fig)
fig,ax=plt.subplots(figsize=(12.4,7.2),facecolor='#f7fafc');fig.subplots_adjust(left=.22,bottom=.15,top=.79,right=.90)
values=np.array([[rows[(w,arm)]['totals']['service_deficit_time_s'] for arm in arms] for w in worlds])
im=ax.imshow(values,vmin=0,vmax=10,cmap='YlGnBu',aspect='auto')
ax.set_xticks(range(4),labels,fontsize=9.8)
ax.set_yticks(range(8),[w[-2:]+'  '+families[rows[(w,'full')]['family']] for w in worlds],fontsize=10)
ax.tick_params(length=0,pad=9)
for i in range(8):
    for j in range(4):ax.text(j,i,f'{values[i,j]:.4f}',ha='center',va='center',fontsize=10,color='white' if values[i,j]>5 else INK)
for y in np.arange(.5,7.5):ax.axhline(y,color='white',lw=1)
fig.colorbar(im,ax=ax,fraction=.027,pad=.03).set_label('服务缺额（秒，越低越好）',fontsize=10)
fig.text(.05,.93,'机制消融：八个独立工况、四种规划视图',fontsize=21,weight='bold',color=INK)
fig.text(.05,.86,'实际设施、外生事件、人员工具和原始权限保持一致；屏蔽发生在规划侧。',fontsize=11,color=GRAY)
fig.text(.05,.055,'32次原始运行；每个工况10秒；同一工况内四臂使用相同实际输入和观测随机种子。',fontsize=9.5,color=GRAY)
save(fig,'35-ablation-all-methods')
fig,(left,right)=plt.subplots(1,2,figsize=(12.4,6.3),facecolor='#f7fafc');fig.subplots_adjust(left=.22,bottom=.20,top=.77,right=.94,wspace=.36)
for axis in (left,right):
    axis.set_yticks(range(3),labels[1:] if axis is left else []);axis.set_ylim(2.6,-.6)
    axis.axvline(0,color='#91a7b7');axis.grid(axis='x',color='#dfe8ef');axis.set_axisbelow(True);axis.tick_params(length=0)
for i,arm in enumerate(arms[1:]):
    for axis,key in ((left,'mask_minus_full_deficit_s'),(right,'full_minus_mask_paid_person_s')):
        v=d['summary'][arm][key];good=v>=0 if axis is left else v<=0
        axis.barh(i,v,height=.5,color=TEAL if good else ORANGE)
        axis.annotate(f'{v:+.4f}',(v,i),xytext=(5 if v>=0 else -5,0),textcoords='offset points',ha='left' if v>=0 else 'right',va='center',fontsize=10)
for axis in (left,right):
    lo,hi=axis.get_xlim();pad=max(hi-lo,.04)*.35;axis.set_xlim(lo-pad,hi+pad)
left.set_xlabel('屏蔽 − 完整缺额（秒）\n正值表示保留该因素有利',fontsize=10)
right.set_xlabel('完整 − 屏蔽付费人时（人秒）\n正值表示保留该因素多花人工',fontsize=10)
fig.text(.05,.93,'知识和协作选项没有自动转化为服务收益',fontsize=21,weight='bold',color=INK)
fig.text(.05,.86,'每项为固定八工况的配对均值；分别报告服务和人工，保留反向结果。',fontsize=11,color=GRAY)
fig.text(.05,.055,'依赖项同时屏蔽边声明与串联容量后果；团队项比较能否选择联合任务，不代表最优班组分配。',fontsize=9.4,color=GRAY)
save(fig,'35-ablation-service-cost')
with (folder/'paired-mask-effects.csv').open('w',encoding='utf-8',newline='') as f:
    fields=list(d['pairs'][0]);writer=csv.DictWriter(f,fields,lineterminator='\n');writer.writeheader();writer.writerows(d['pairs'])
summary=[]
with (folder/'arm-summary.csv').open('w',encoding='utf-8',newline='') as f:
    writer=csv.writer(f,lineterminator='\n');writer.writerow(['arm','worlds','mean_deficit_s','mean_paid_person_s','mean_travel_person_s','mean_tool_s','mean_unique_records','mean_diagnostic_choose_ms','mean_component_shape_validations','model_evaluation_totals_json'])
    for arm in arms:
        selected=[r for r in d['runs'] if r['arm']==arm];t=[r['totals'] for r in selected]
        calls={key:sum(r['model_evaluations'].get(key,0) for r in selected) for key in sorted({k for r in selected for k in r['model_evaluations']})}
        row=[arm,8,fsum(v['service_deficit_time_s'] for v in t)/8,fsum(v['paid_person_s'] for v in t)/8,
            fsum(v['worker_travel_person_s'] for v in t)/8,fsum(v['tool_occupation_tool_s'] for v in t)/8,
            fsum(len(r['public_record_ids']) for r in selected)/8,fsum(r['diagnostic_policy_elapsed_ms'] for r in selected)/8,
            fsum(r['adapter']['schema_component_identity_validations'] for r in selected)/8,json.dumps(calls,sort_keys=True)]
        writer.writerow(row);summary.append(row)
sha=lambda b:hashlib.sha256(b).hexdigest()
manifest=dict(scope='Saved32 ablation originals only; no new physical, selector or seed calls.',
    input_sha256=sha(a.data.read_bytes()),authoring_sha256=sha(Path(__file__).read_bytes()),
    font_sha256=sha(font.read_bytes()),matplotlib=matplotlib.__version__,
    artifacts={p.name:sha(p.read_bytes()) for p in out.iterdir() if p.name!='figure-source.json'})
(out/'figure-source.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(dict(status='ALL8_ABLATION_UNITS_RENDERED',figures=2,arm_summary=summary)))
