"""Complete immutable ablation data audit; no project imports or active model calls."""
import argparse
from collections import Counter
from copy import deepcopy
from hashlib import sha256
import importlib.util
from io import BytesIO
import json
from math import fsum,isclose,isfinite
from pathlib import Path
from zipfile import ZipFile

OUT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('saved_standards_helpers',OUT.parent/'32-standards-review-01'/'review.py')
r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r)
r.ROOT=Path(r'C:\Users\Donson\.codex\worktrees\mainline35-ablation\Renly')
SOURCE='d102173f2a8c31402f70dbf4522371aa18070ed9'
PREP='evidence/mainline/research/35-ablation/prepared-01'
CAPTURE='evidence/mainline/research/35-ablation/capture-01'
LOCK='docs/mainline/evidence/30-ablation-execution-lock.json'
AUTH='docs/mainline/evidence/35-execution-authorization.json'
RUNBOOK='docs/mainline/35-ablation-execution.json'
EXTENSION='docs/mainline/35-planner-executor-extension.json'
METRICS=('demand_service_unit_s','delivered_service_unit_s','service_deficit_time_s',
         'worker_travel_person_s','worker_work_person_s','worker_wait_person_s','access_check_person_s',
         'rendezvous_wait_person_s','queue_wait_person_s','tool_occupation_tool_s')
FRAME={'schema','plan_id','facility_id','time_unit','as_of_s','nominal_knowledge','evidence','requests'}
source_blob=lambda p:r.blob(p,SOURCE)
source_doc=lambda p:r.doc(p,SOURCE)
fingerprint=lambda v:sha256(json.dumps(v,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()


def declared_planner(program,mask,masks):
    """Literal data transformations from the original registered mask definitions."""
    value=deepcopy(program);policy=value['policy_program'];options=policy['options'];removed_records=set()
    if mask=='without_nonfixed_context':
        records=value['evidence_ledger']['records']
        removed_records={x['id'] for x in records if x['source_id'] in masks[mask]['remove_source_ids']}
        previous=None
        while previous!=removed_records:
            previous=set(removed_records)
            removed_records.update(x['id'] for x in records if x['provenance']['copied_from_record_id'] in previous)
        value['evidence_ledger']['records']=[x for x in records if x['id'] not in removed_records]
    elif mask=='without_dependency_context':
        removed=set(masks[mask]['remove_edge_ids'])
        value['nominal_knowledge']['graphs']['functional']=[x for x in value['nominal_knowledge']['graphs']['functional'] if x['id'] not in removed]
        for question in options['catalog']['questions']:
            question['dependency_edge_ids']=[x for x in question['dependency_edge_ids'] if x not in removed]
        capacities=[row['capacities'] for outcome in options['catalog']['outcomes'] for row in outcome['capacity_profile']]
        capacities += [c for q in options['value_model']['question_models'] for v in q['variants'] for stage in ('during_capacity','after_capacity') for c in v[stage].values()]
        for c in capacities:
            for key in ('network','storage'):c[key]=c['compute']
    elif mask=='without_joint_crew_planning':
        removed={x['id'] for x in policy['candidates'] if len(x['task']['crew'])>1}
        questions={b['question_id'] for b in options['bindings'] if b['intervention_candidate_id'] in removed}
        policy['candidates']=[x for x in policy['candidates'] if x['id'] not in removed]
        options['bindings']=[x for x in options['bindings'] if x['question_id'] not in questions]
        options['value_model']['question_models']=[x for x in options['value_model']['question_models'] if x['question_id'] not in questions]
        for q in options['catalog']['questions']:
            if q['id'] in questions:
                q['quantification']='UNMODELED';q['outcome_ids']=[]
                q['evidence_gaps'].append('Joint intervention is unavailable to this planner; its incremental value remains unknown.')
        tasks={x['task']['id'] for x in policy['candidates']}
        policy['intervention_declaration']['bindings']=[b for b in policy['intervention_declaration']['bindings'] if b['task_id'] in tasks]
        value['intervention_program']=deepcopy(policy['intervention_declaration'])
        policy['evidence_projection']['report_class_support']=[x for x in policy['evidence_projection']['report_class_support'] if x['question_id'] not in questions]
    elif mask!='full':raise AssertionError('Unregistered mask')
    return value,removed_records


def main(delivery):
    check=r.check
    blob=lambda p:r.blob(p,delivery)
    doc=lambda p:r.doc(p,delivery)
    check(r.git('merge-base','--is-ancestor',SOURCE,delivery)==b'','Actual registered execution source precedes immutable data delivery')
    plan=source_doc(r.PROTOCOL);phase=plan['phases']['ablation'];frozen=source_doc(LOCK);prep=source_doc(PREP+'/receipt.json');design=source_doc(r.LOCK)
    authorization=source_doc(AUTH)
    check(authorization['status']=='REVIEWED_TO_EXECUTE' and authorization['execution_lock_sha256']==sha256(source_blob(LOCK)).hexdigest() and frozen['status']=='REVIEWED_FOR_EXECUTION','Actual execution preceded by exact reviewed authorization')
    paths=r.tree(delivery,CAPTURE);r.fetch(delivery,paths)
    receipt=doc(CAPTURE+'/receipt.json');batch=doc(CAPTURE+'/batch.json')
    check(receipt['status']=='PASS' and receipt['source_unchanged'] is True and receipt['stop'] is None,'Final actual ablation capture complete and unchanged')
    check({p[len(CAPTURE)+1:] for p in paths}==set(receipt['artifacts'])|{'receipt.json'} and all(sha256(blob(CAPTURE+'/'+p)).hexdigest()==h for p,h in receipt['artifacts'].items()),'Complete163-file capture membership and every manifest hash exact',files=len(paths))
    expected=[]
    for w in phase['worlds']:
        arms=phase['arms'];shift=(w['slot']-1)%len(arms)
        for arm in arms[shift:]+arms[:shift]:
            member=w['id']+'/'+arm+'.json'
            expected.append(dict(index=len(expected)+1,world_id=w['id'],family=w['family'],arm=arm,duration_s=w['duration_s'],scheduled_decisions=len(plan['decision_times_s']),input_member=member,input_sha256=prep['input_hashes'][member]))
    check(batch['slots']==expected and len(expected)==32 and batch['execution_commit']==receipt['execution_commit']==SOURCE,'Every actual slot equals the frozen rotated32-slot roster and execution source')
    budget=dict(attempts=32,simulated_charge_s=320,scheduled_decisions=320)
    check(batch['budget']==phase['budget']==frozen['budget']==budget and batch['automatic_retries']==receipt['automatic_retries']==0,'Exact original32/320/320 budget and zero automatic retries retained')
    check(receipt['registered_research_trials']==receipt['held_inputs_read']==32 and receipt['held_seed_reads']==1 and receipt['llm_calls']==receipt['training_calls']==0 and receipt['field_calibration']=='PENDING','Actual registered/held/AI/field accounting explicit')
    check(batch['interpreter_sha256']==frozen['interpreter_sha256'] and batch['unused_cache_prefix'] is True and batch['protocol_sha256']==sha256(source_blob(r.PROTOCOL)).hexdigest() and batch['design_lock_sha256']==sha256(source_blob(r.LOCK)).hexdigest() and batch['phase_nonce_commitment']==design['commitments_sha256']['ablation'],'Original source environment, protocol and phase commitment bound exactly')
    pins=set(frozen['execution_pins'])|set(design['pins'])|{RUNBOOK,r.LOCK,r.PROTOCOL,EXTENSION,LOCK,AUTH,'docs/mainline/evidence/34-root.json'}
    pins|={PREP+'/'+n for n in set(prep['artifacts'])|{'receipt.json'}}
    check(set(batch['pins'])==pins and len(frozen['execution_pins'])==274,'Outer adapter and full prepared/governance source pin universe exact')
    r.pin_check(SOURCE,batch['pins'],'All outer execution pins match actuald102 source')
    r.pin_check(delivery,batch['pins'],'Immutable data delivery retains every actual source/input pin')
    for subtree in (PREP,'evidence/mainline/engineering/35-ablation-adapter',r.OLD,r.PREP,'evidence/mainline/research/33-confirmation/capture-01'):
        check(r.git('rev-parse',SOURCE+':'+subtree)==r.git('rev-parse',delivery+':'+subtree),'Earlier frozen inputs/failures/originals unchanged '+subtree)
    check(source_doc('docs/mainline/evidence/34-root.json')['result']=='NO_PRACTICAL_GAIN','Primary confirmatory result remains independently fixed')
    ledger=[json.loads(row) for row in blob(CAPTURE+'/attempts.jsonl').splitlines()]
    check(len(ledger)==64 and blob(CAPTURE+'/attempts.jsonl').endswith(b'\n'),'Exactly64 whole durable journal rows')
    runtime={p:h for p,h in batch['pins'].items() if p.startswith('src/aegis_dc/') and p.endswith('.py') or p=='src/patrol_rsi/contracts.py'}
    masks=source_doc('configs/full-facility-comparison-held-blueprints-v1.json')['masks']
    total=dict(started=0,completed=0,failed=0,interrupted=0,unrun=0,charged_simulated_s=0,charged_scheduled_decisions=0,returned_decisions=0)
    common={};seed_pairs={};summaries=[];decision_count=intervals=points=submission_count=0
    for i,slot in enumerate(expected):
        label=f"{slot['index']:02}-{slot['world_id']}-{slot['arm']}";prefix=CAPTURE+'/'+label
        start,terminal=doc(prefix+'/start.json'),doc(prefix+'/terminal.json')
        check({k:v for k,v in ledger[i*2].items() if k!='recorded_at_utc'}==start and {k:v for k,v in ledger[i*2+1].items() if k!='recorded_at_utc'}==terminal and all(start[k]==terminal[k]==v for k,v in slot.items()),'Per-slot journals and original identities '+label)
        check(start['source']==terminal['source']==SOURCE and start['status']=='STARTED' and terminal['status']=='COMPLETED' and terminal['physical_call_started'] is True and terminal['physical_returned'] is True and start['charged_simulated_s']==10 and start['charged_scheduled_decisions']==terminal['returned_decisions']==10,'Actual complete physical lifecycle and charges '+label)
        memberset={p[len(prefix)+1:] for p in paths if p.startswith(prefix+'/')}
        check(memberset==set(terminal['artifacts'])|{'terminal.json'} and all(sha256(blob(prefix+'/'+p)).hexdigest()==h for p,h in terminal['artifacts'].items()),'Per-slot immutable artifact membership and SHA '+label)
        original=doc(prefix+'/originals.json');raw=blob(prefix+'/originals.zip')
        check(sha256(raw).hexdigest()==original['archive_sha256'],'Native archive SHA '+label)
        with ZipFile(BytesIO(raw)) as z:
            names=z.namelist();native={p:z.read(p) for p in names}
        check(len(names)==len(set(names))==4 and set(names)==set(original['members'])=={'scenario.json','run.json','private-state.jsonl','balances.jsonl'} and all(sha256(v).hexdigest()==original['members'][p] for p,v in native.items()),'Four exact unique native members '+label)
        document=source_doc(PREP+'/inputs/'+slot['input_member']);plain=deepcopy(document);mask=plain.pop('ablation_mask');program=document['dispatch_program'];policy=program['policy_program']
        check(mask==slot['arm'] and sha256(source_blob(PREP+'/inputs/'+slot['input_member'])).hexdigest()==slot['input_sha256']==frozen['input_hashes'][slot['input_member']],'Actual mask/input frozen byte identity '+label)
        common.setdefault(slot['world_id'],set()).add(fingerprint(plain))
        fixed=program['sensor_program']['realization']['seed'];portable=program['inspection_program']['realizations']['lookahead-inspect']['seed']
        check(type(fixed) is int and 0<=fixed<2**64 and type(portable) is int and 0<=portable<2**128,'Actual fixed64 and portable128 domains '+label)
        seed_pairs.setdefault(slot['world_id'],set()).add((fixed,portable))
        run=json.loads(native['run.json']);marker=run['ablation_execution_audit'];audit=doc(prefix+'/audit.json')
        planning,removed=declared_planner(program,mask,masks)
        check(json.loads(native['scenario.json'])==document['model'] and run['inputs']['dispatch_program']==program and run['inputs']['duration_s']==10 and run['inputs']['maximum_step_s']==.01 and run['inputs']['boundary_events']==document['boundary_events'] and run['inputs']['work_requests']==[] and 'action_commands' not in run['inputs'],'Full actual model and execution declaration unchanged '+label)
        check(run['code_identity']['git_commit']==SOURCE and run['code_identity']['files']==runtime and run['code_identity']['implementation_has_changes'] is False and all(original['members'][p]==v['sha256'] for p,v in run['artifacts'].items()),'Native original runtime identity and inner member manifest '+label)
        check(marker['mask']==mask and marker['adapter_sha256']==sha256(source_blob('scripts/ablation_planner.py')).hexdigest() and marker['actual_program_sha256']==fingerprint(program) and marker['planner_program_sha256']==fingerprint(planning) and marker['actual_plant_sha256']==fingerprint(document['model']),'Actual adapter, full program, declared mask view and plant hashes '+label)
        check(marker['actual_catalog_task_ids']==sorted(x['task']['id'] for x in policy['candidates']) and marker['actual_binding_task_ids']==sorted(x['task_id'] for x in program['intervention_program']['bindings']) and marker['planner_candidate_ids']==sorted(x['id'] for x in planning['policy_program']['candidates']) and marker['planner_binding_task_ids']==sorted(x['task_id'] for x in planning['intervention_program']['bindings']),'Actual capability and masked planning bindings independently exact '+label)
        count=marker['schema_component_identity_validations']
        check(type(count) is int and (count>0 if mask=='without_dependency_context' else count==0),'Declared validation-only identity lifecycle '+label)
        decisions=run['policy_public_decisions'];decision_count+=len(decisions)
        check([d['frame']['as_of_s'] for d in decisions]==program['decision_times_s'] and len(decisions)==10 and all(set(d)=={'frame','history','choice'} and set(d['frame'])==FRAME and set(d['history'])=={'issued','work_feedback'} and d['frame']['nominal_knowledge']==planning['nominal_knowledge'] and d['frame']['requests']==planning['preparation_requests'] and d['choice']['policy']=='evidence_consistent_contingent' and d['choice']['execution_permission'] is False for d in decisions),'Exact current public clocks, closed fields and masked nominal knowledge '+label)
        check(all(rec['observed_at_s']<=rec['arrived_at_s']<=d['frame']['as_of_s'] and rec['id'] not in removed for d in decisions for rec in d['frame']['evidence']['records']) and all(f['arrived_at_s']<=d['frame']['as_of_s'] for d in decisions for f in d['history']['work_feedback']),'No future, undelivered or removed copied evidence in decisions '+label)
        tasks={x['task']['id']:x['task'] for x in policy['candidates']};selected=[d for d in decisions if d['choice']['work_intention'] is not None]
        check(all(d['choice']['work_intention']==tasks[d['choice']['work_intention']['id']] and (mask!='without_joint_crew_planning' or len(d['choice']['work_intention']['crew'])==1) for d in selected),'Selected actual tasks unchanged and joint choices unavailable only to masked planner '+label)
        desired=Counter((d['frame']['as_of_s'],d['choice']['work_intention']['id'],channel) for d in selected for channel in ('WORK_SUBMIT','ACTION_ISSUE'))
        actual=marker['private_submission_frames'];by_time={d['frame']['as_of_s']:d for d in decisions}
        check(Counter((x['as_of_s'],x['task_id'],x['channel']) for x in actual)==desired and all(x['evidence_sha256']==fingerprint(by_time[x['as_of_s']]['frame']['evidence']) and x['actual_nominal_sha256']==fingerprint(program['nominal_knowledge']) and x['planner_nominal_sha256']==fingerprint(planning['nominal_knowledge']) for x in actual),'Exactly two private submission channels per intention with same time/task/evidence '+label)
        submission_count+=len(actual)
        check({x['id'] for x in run['work_records']}=={d['choice']['work_intention']['id'] for d in selected} and all(all(work[k]==v for k,v in tasks[work['id']].items()) for work in run['work_records']),'Actual work records equal only issued frozen tasks '+label)
        check(run['state_visibility']=='PRIVATE_PLANT_EVALUATOR_ONLY' and run['dispatch_interface']=='PUBLIC_SELECTION_WITH_PRIVATE_EXECUTION' and run['model_calls']==run['training_calls']==0 and run['field_calibration']=='PENDING','Private/public non-AI scope unchanged '+label)
        trace=[json.loads(x) for x in native['private-state.jsonl'].splitlines()];balances=[json.loads(x) for x in native['balances.jsonl'].splitlines()]
        check(len(trace)==len(balances)+1 and trace[0]['time_s']==0 and trace[-1]['time_s']==10 and all(b['start_s']==left['time_s'] and b['end_s']==right['time_s'] and 0<right['time_s']-left['time_s']<=.01+1e-8 for left,right,b in zip(trace[:-1],trace[1:],balances)),'Full contiguous actual horizon and balance intervals '+label)
        domains={x['id'] for x in document['model']['domains']}
        check(len(domains)==8 and all(set(x['domains'])==domains for x in trace),'Complete eight-domain actual state preserved '+label)
        check(audit['status']=='PASS_RETURNED_DEVELOPMENT_EVIDENCE' and audit['arm']=='evidence_consistent_contingent' and audit['hard_violations']==[] and audit['trace_points']==len(trace) and audit['balance_intervals']==len(balances) and audit['ablation_view_verification']['status']=='PASS_EXACT_ACTUAL_AND_PLANNER_VIEWS' and audit['ablation_view_verification']['mask']==mask,'Saved actual/planner audit complete and no hard violation recorded '+label)
        check(all(all(type(b[k]) in (int,float) and isfinite(b[k]) and b[k]>=0 for b in balances) and isclose(fsum(b[k] for b in balances),audit['totals'][k],abs_tol=1e-8,rel_tol=0) and isclose(audit['totals'][k],run['summary'][k],abs_tol=1e-8,rel_tol=0) for k in METRICS),'Saved actual SI metrics reproduce balances and native summary '+label)
        check(isclose(audit['totals']['paid_person_s'],fsum(audit['totals'][k] for k in ('worker_travel_person_s','worker_work_person_s','worker_wait_person_s')),abs_tol=1e-8,rel_tol=0) and all(x['risk_closed'] is False for x in run['intervention_public_feedback']),'Actual paid work avoids waiting double-count and effect is not risk closure '+label)
        intervals+=len(balances);points+=len(trace)
        total['started']+=1;total['completed']+=1;total['charged_simulated_s']+=10;total['charged_scheduled_decisions']+=10;total['returned_decisions']+=len(decisions)
        summaries.append(dict(index=slot['index'],world_id=slot['world_id'],mask=mask,private_submission_frames=len(actual),trace_points=len(trace),balance_intervals=len(balances),archive_sha256=original['archive_sha256']))
    check(len(common)==8 and all(len(x)==1 for x in common.values()) and all(len(x)==1 for x in seed_pairs.values()) and len({next(iter(x)) for x in seed_pairs.values()})==8,'All four actual documents share only-mask differences and paired seeds; eight worlds distinct')
    check(total==receipt['total'] and total['started']==total['completed']==32 and decision_count==320,'Independent complete lifecycle and full budget accounting exactly matches receipt',total=total)
    report=dict(status='PASS_COMPLETE_SAVED_ABLATION_STANDARDS',axis='Standards',execution_source=SOURCE,delivery=delivery,hard_findings=[],advisory_smell_findings=[],total=total,native_archives=32,native_members=128,actual_public_decisions=decision_count,private_submission_frames=submission_count,private_trace_points=points,balance_intervals=intervals,checks=r.checks,slots=summaries,scope=dict(reviewer_nonce_reads=0,seed_derivations=0,physical_calls=0,selector_calls=0,tests=0,project_code_imports=0,tracked_edits=0),result_boundary='Complete actual execution, privacy, source and accounting review. Descriptive mechanism interpretation is separate and primary confirmation result remains unchanged.')
    (OUT/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:v for k,v in report.items() if k not in ('checks','slots')},ensure_ascii=False))
    print('Bounded saved checks:',len(r.checks))


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--delivery',required=True)
    main(parser.parse_args().delivery)
