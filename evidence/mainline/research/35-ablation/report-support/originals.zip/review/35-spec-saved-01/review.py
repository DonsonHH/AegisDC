"""Saved-only35 audit: one final data SHA required; no project imports or live reads."""
import copy
from collections import Counter
import hashlib
import io
import json
import math
import subprocess
import sys
import zipfile
from pathlib import Path

REPO=Path('C:/Users/Donson/.codex/worktrees/mainline35-ablation/Renly')
OUT=Path(__file__).resolve().parent
SOURCE='d102173f2a8c31402f70dbf4522371aa18070ed9'
BASE='4b5f0b34'
ROOT='evidence/mainline/research/35-ablation/capture-01/'
PREP='evidence/mainline/research/35-ablation/prepared-01/inputs/'
LOCK='docs/mainline/evidence/30-ablation-execution-lock.json'
PRIMARY='evidence/mainline/research/34-paired-analysis/results.json'
ARMS=['full','without_nonfixed_context','without_dependency_context','without_joint_crew_planning']
DOMAINS={'power','backup','facility_cooling','equipment_environment','it_service','control_monitoring','space_access','people_tools_work'}
FRAME={'schema','plan_id','facility_id','time_unit','as_of_s','nominal_knowledge','evidence','requests'}
RF={'id','source_id','target_id','observable_id','unit','value','observed_at_s','arrived_at_s','valid_until_s','quality','provenance'}
TOL=1e-8
def sha(raw):return hashlib.sha256(raw).hexdigest()
def fp(value):return sha(json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False).encode())
def close(a,b):return math.isclose(a,b,rel_tol=0,abs_tol=TOL)
def git(*a):return subprocess.check_output(['git',*a],cwd=REPO)
class Blobs:
    def __init__(self):self.p=subprocess.Popen(['git','cat-file','--batch'],cwd=REPO,stdin=subprocess.PIPE,stdout=subprocess.PIPE)
    def get(self,ref,name):
        self.p.stdin.write((ref+':'+name+'\n').encode());self.p.stdin.flush()
        h=self.p.stdout.readline().split();assert len(h)==3 and h[1]==b'blob',(ref,name)
        size=int(h[2]);raw=self.p.stdout.read(size);assert len(raw)==size and self.p.stdout.read(1)==b'\n';return raw
    def read(self,ref,name):return json.loads(self.get(ref,name))
    def close(self):self.p.stdin.close();self.p.stdout.close();self.p.wait()

def expected_view(actual,mask,rules):
    """Literal blueprint projection of saved JSON, independent of project code."""
    view=copy.deepcopy(actual);policy=view['policy_program'];options=policy['options']
    if mask=='without_nonfixed_context':
        rows=view['evidence_ledger']['records'];sources=set(rules[mask]['remove_source_ids'])
        removed={r['id'] for r in rows if r['source_id'] in sources}
        while True:
            following={r['id'] for r in rows if r['provenance']['copied_from_record_id'] in removed}
            if following<=removed:break
            removed.update(following)
        view['evidence_ledger']['records']=[r for r in rows if r['id'] not in removed]
    elif mask=='without_dependency_context':
        removed=set(rules[mask]['remove_edge_ids'])
        view['nominal_knowledge']['graphs']['functional']=[e for e in view['nominal_knowledge']['graphs']['functional'] if e['id'] not in removed]
        for q in options['catalog']['questions']:q['dependency_edge_ids']=[e for e in q['dependency_edge_ids'] if e not in removed]
        capacities=[r['capacities'] for outcome in options['catalog']['outcomes'] for r in outcome['capacity_profile']]
        capacities.extend(c for q in options['value_model']['question_models'] for v in q['variants'] for stage in ('during_capacity','after_capacity') for c in v[stage].values())
        for c in capacities:c.update(network=c['compute'],storage=c['compute'])
    elif mask=='without_joint_crew_planning':
        removed={c['id'] for c in policy['candidates'] if len(c['task']['crew'])>1}
        affected={b['question_id'] for b in options['bindings'] if b['intervention_candidate_id'] in removed}
        policy['candidates']=[c for c in policy['candidates'] if c['id'] not in removed]
        options['bindings']=[b for b in options['bindings'] if b['question_id'] not in affected]
        options['value_model']['question_models']=[q for q in options['value_model']['question_models'] if q['question_id'] not in affected]
        for q in options['catalog']['questions']:
            if q['id'] in affected:
                q.update(quantification='UNMODELED',outcome_ids=[])
                q['evidence_gaps'].append('Joint intervention is unavailable to this planner; its incremental value remains unknown.')
        task_ids={c['task']['id'] for c in policy['candidates']}
        policy['intervention_declaration']['bindings']=[b for b in policy['intervention_declaration']['bindings'] if b['task_id'] in task_ids]
        view['intervention_program']=copy.deepcopy(policy['intervention_declaration'])
        policy['evidence_projection']['report_class_support']=[r for r in policy['evidence_projection']['report_class_support'] if r['question_id'] not in affected]
    else:assert mask=='full'
    return view

def verify(delivery):
    g=Blobs()
    try:
        plan=g.read(SOURCE,'docs/mainline/30-comparison-protocol-v1.json');phase=plan['phases']['ablation']
        rules=g.read(SOURCE,'configs/full-facility-comparison-held-blueprints-v1.json')['masks']
        lock=g.read(SOURCE,LOCK);authorization=g.read(SOURCE,'docs/mainline/evidence/35-execution-authorization.json')
        assert lock['status']=='REVIEWED_FOR_EXECUTION' and authorization['status']=='REVIEWED_TO_EXECUTE'
        assert authorization['execution_lock_sha256']==sha(g.get(SOURCE,LOCK))
        assert len(lock['execution_pins'])==274
        for n,h in lock['execution_pins'].items():assert sha(g.get(SOURCE,n))==h
        original={n for n in git('ls-tree','-rz','--name-only',BASE,'src','scripts','configs').decode().split('\0') if n.endswith(('.py','.json'))}
        assert len(original)==269
        for n in original:assert g.get(SOURCE,n)==g.get(BASE,n)
        primary=g.get(SOURCE,PRIMARY);assert json.loads(primary)['status']=='NO_PRACTICAL_GAIN'
        assert g.get(delivery,PRIMARY)==primary
        batch=g.read(delivery,ROOT+'batch.json');receipt=g.read(delivery,ROOT+'receipt.json')
        assert batch['execution_commit']==receipt['execution_commit']==SOURCE and receipt['source_unchanged']
        assert batch['budget']==phase['budget']==dict(attempts=32,simulated_charge_s=320,scheduled_decisions=320)
        assert receipt['automatic_retries']==batch['automatic_retries']==0 and batch['unused_cache_prefix']
        assert batch['interpreter_sha256']==lock['interpreter_sha256']
        assert receipt['held_inputs_read']==32 and receipt['held_seed_reads']==1
        assert receipt['llm_calls']==receipt['training_calls']==0 and receipt['field_calibration']=='PENDING'
        names=set(filter(None,git('ls-tree','-rz','--name-only',delivery,ROOT).decode().split('\0')))
        assert names=={ROOT+n for n in receipt['artifacts']}|{ROOT+'receipt.json'}
        for n,h in receipt['artifacts'].items():assert sha(g.get(delivery,ROOT+n))==h
        for n,h in batch['pins'].items():assert sha(g.get(SOURCE,n))==h
        runtime={n:h for n,h in batch['pins'].items() if n.startswith('src/aegis_dc/') and n.endswith('.py') or n=='src/patrol_rsi/contracts.py'}
        expected=[]
        for w in phase['worlds']:
            shift=(w['slot']-1)%4
            for arm in ARMS[shift:]+ARMS[:shift]:expected.append((w['id'],arm))
        assert len(batch['slots'])==32 and [(s['world_id'],s['arm']) for s in batch['slots']]==expected
        journal=[json.loads(x) for x in g.get(delivery,ROOT+'attempts.jsonl').splitlines()];assert len(journal)==64
        total=dict(started=32,completed=32,failed=0,interrupted=0,unrun=0,charged_simulated_s=320,charged_scheduled_decisions=320,returned_decisions=320)
        saved={};actuals={};mappings=0;domain_points=0
        for number,slot in enumerate(batch['slots'],1):
            assert slot['index']==number and slot['duration_s']==slot['scheduled_decisions']==10
            case=ROOT+f"{number:02}-{slot['world_id']}-{slot['arm']}/"
            start=g.read(delivery,case+'start.json');terminal=g.read(delivery,case+'terminal.json')
            a,b=journal[(number-1)*2:number*2]
            assert {k:v for k,v in a.items() if k!='recorded_at_utc'}==start
            assert {k:v for k,v in b.items() if k!='recorded_at_utc'}==terminal
            assert a['status']=='STARTED' and b['status']=='COMPLETED'
            for row in (a,b):assert row['source']==SOURCE and all(row[k]==v for k,v in slot.items())
            assert start['charged_simulated_s']==start['charged_scheduled_decisions']==10
            assert terminal['physical_call_started'] and terminal['physical_returned'] and terminal['returned_decisions']==10
            for n,h in terminal['artifacts'].items():assert sha(g.get(delivery,case+n))==h
            raw=g.get(SOURCE,PREP+slot['input_member']);assert sha(raw)==slot['input_sha256']==lock['input_hashes'][slot['input_member']]
            document=json.loads(raw);assert document['ablation_mask']==slot['arm']
            actual=copy.deepcopy(document);actual.pop('ablation_mask')
            if slot['world_id'] in actuals:assert actual==actuals[slot['world_id']]
            else:actuals[slot['world_id']]=actual
            program=document['dispatch_program'];planning=expected_view(program,slot['arm'],rules)
            original=g.read(delivery,case+'originals.json');raw=g.get(delivery,case+'originals.zip')
            assert sha(raw)==original['archive_sha256']
            with zipfile.ZipFile(io.BytesIO(raw)) as archive:
                assert len(archive.namelist())==4 and set(archive.namelist())==set(original['members'])=={'run.json','scenario.json','private-state.jsonl','balances.jsonl'}
                members={n:archive.read(n) for n in archive.namelist()}
            assert all(sha(raw)==original['members'][n] for n,raw in members.items())
            run=json.loads(members['run.json']);audit=g.read(delivery,case+'audit.json')
            assert run['code_identity']['git_commit']==SOURCE and run['code_identity']['files']==runtime and not run['code_identity']['implementation_has_changes']
            assert json.loads(members['scenario.json'])==document['model'] and run['inputs']['dispatch_program']==program
            assert run['inputs']['duration_s']==10 and run['inputs']['maximum_step_s']==.01 and run['inputs']['boundary_events']==document['boundary_events']
            assert run['model_calls']==run['training_calls']==0 and run['field_calibration']=='PENDING'
            marker=run['ablation_execution_audit'];assert marker['mask']==slot['arm']
            assert marker['adapter_source']=='scripts/ablation_planner.py' and marker['adapter_sha256']==lock['execution_pins'][marker['adapter_source']]
            assert marker['actual_program_sha256']==fp(program) and marker['planner_program_sha256']==fp(planning) and marker['actual_plant_sha256']==fp(document['model'])
            assert marker['actual_catalog_task_ids']==sorted(c['task']['id'] for c in program['policy_program']['candidates'])
            assert marker['actual_binding_task_ids']==sorted(b['task_id'] for b in program['intervention_program']['bindings'])
            assert marker['planner_candidate_ids']==sorted(c['id'] for c in planning['policy_program']['candidates'])
            assert marker['planner_binding_task_ids']==sorted(b['task_id'] for b in planning['intervention_program']['bindings'])
            count=marker['schema_component_identity_validations'];assert type(count) is int and (count>0 if slot['arm']=='without_dependency_context' else count==0)
            decisions=run['policy_public_decisions'];assert [d['frame']['as_of_s'] for d in decisions]==plan['decision_times_s']
            selected={c['id']:c for c in planning['policy_program']['candidates']};tasks={c['task']['id']:c['task'] for c in program['policy_program']['candidates']}
            arrived={r['id']:r for r in planning['evidence_ledger']['records']+run['inspection_public_snapshot']['records']}
            removed={r['id'] for r in program['evidence_ledger']['records']}-set(arrived)
            issued=[]
            for decision in decisions:
                assert set(decision)=={'frame','history','choice'};frame=decision['frame'];at=frame['as_of_s']
                assert set(frame)==FRAME and frame['nominal_knowledge']==planning['nominal_knowledge']
                assert frame['evidence']['as_of_s']==at and frame['time_unit']=='s'
                assert decision['history']==dict(issued=issued,work_feedback=[r for r in run['workforce_public_feedback'] if r['arrived_at_s']<=at])
                for record in frame['evidence']['records']:
                    assert set(record)==RF|{'age_s','availability'}
                    assert record['observed_at_s']<=record['arrived_at_s']<=at and close(record['age_s'],at-record['observed_at_s'])
                    assert record['id'] not in removed
                    if record['id'] in arrived:assert {k:record[k] for k in RF}=={k:arrived[record['id']][k] for k in RF}
                    if slot['arm']=='without_nonfixed_context':assert record['source_id']!='operator-report' and record['provenance']['copied_from_record_id'] not in removed
                chosen=decision['choice']['chosen_candidate_id'];task=decision['choice']['work_intention']
                if chosen is None:assert task is None
                else:
                    assert chosen in selected and task==selected[chosen]['task']==tasks[task['id']]
                    issued.append(dict(candidate_id=chosen,issued_at_s=at))
            counter=Counter((d['frame']['as_of_s'],d['choice']['work_intention']['id'],channel)
                for d in decisions if d['choice']['work_intention'] is not None for channel in ('WORK_SUBMIT','ACTION_ISSUE'))
            assert Counter((r['as_of_s'],r['task_id'],r['channel']) for r in marker['private_submission_frames'])==counter
            mappings+=len(marker['private_submission_frames'])
            for item in marker['private_submission_frames']:
                decision=next(d for d in decisions if d['frame']['as_of_s']==item['as_of_s'])
                assert item['task_id']==decision['choice']['work_intention']['id']
                assert item['evidence_sha256']==fp(decision['frame']['evidence'])
                assert item['planner_nominal_sha256']==fp(planning['nominal_knowledge']) and item['actual_nominal_sha256']==fp(program['nominal_knowledge'])
            trace=[json.loads(x) for x in members['private-state.jsonl'].splitlines()];balances=[json.loads(x) for x in members['balances.jsonl'].splitlines()]
            assert len(trace)==len(balances)+1 and trace[0]['time_s']==0 and trace[-1]['time_s']==10
            values={k:[] for k in ['service_deficit_time_s','worker_travel_person_s','worker_work_person_s','worker_wait_person_s','tool_occupation_tool_s']}
            shifts=program['policy_program']['workforce_profile']['shifts']
            offered=next(p['value'] for p in document['model']['parameters'] if p['id']=='service_demand')
            for left,right,balance in zip(trace[:-1],trace[1:],balances):
                start,end=left['time_s'],right['time_s'];dt=end-start
                assert balance['start_s']==start and balance['end_s']==end and 0<dt<=.01+TOL
                domains=left['domains'];assert set(domains)==DOMAINS;domain_points+=1
                service=domains['it_service'];assert service['demand']==offered
                assert 0<=service['delivered']<=offered and service['delivered']<=min(service['capacities'].values())+TOL
                assert domains['control_monitoring']['compute_permitted'] or domains['power']['actual_powers_W']['compute']==0
                assert min(balance['capacity_slack_W'].values())>=-1e-6
                deficit=(offered-service['delivered'])/offered*dt if offered else 0
                assert close(deficit,balance['service_deficit_time_s']);values['service_deficit_time_s'].append(deficit)
                crew=domains['people_tools_work'];workers=crew['workers'];tools=crew['tools']
                waiting={w for w,state in workers.items() if state['status']=='waiting'}
                waiting.update(role['worker_id'] for name in crew['queued_requests'] for role in tasks[name]['crew']
                    if workers[role['worker_id']]['status']=='idle' and shifts[role['worker_id']][0]<=start<shifts[role['worker_id']][1])
                counts=dict(worker_travel_person_s=sum(w['status']=='travelling' for w in workers.values()),
                    worker_work_person_s=sum(w['status']=='working' for w in workers.values()),worker_wait_person_s=len(waiting),
                    tool_occupation_tool_s=sum(t['reserved_by'] is not None for t in tools.values()))
                for key,count in counts.items():assert close(balance[key],count*dt);values[key].append(count*dt)
                assert close(balance['worker_wait_person_s'],math.fsum(balance[k] for k in ['access_check_person_s','rendezvous_wait_person_s','queue_wait_person_s']))
            metrics={k:math.fsum(v) for k,v in values.items()}
            metrics['paid_person_s']=math.fsum(metrics[k] for k in ['worker_travel_person_s','worker_work_person_s','worker_wait_person_s'])
            for k,value in metrics.items():assert close(value,audit['totals'][k]),(number,k,value,audit['totals'][k])
            assert audit['hard_violations']==[] and audit['ablation_view_verification']['status']=='PASS_EXACT_ACTUAL_AND_PLANNER_VIEWS'
            saved[(slot['world_id'],slot['arm'])]=dict(world_id=slot['world_id'],family=slot['family'],arm=slot['arm'],metrics=metrics,
                selected_tasks=len(issued),private_mappings=len(marker['private_submission_frames']))
        assert total==receipt['total'] and receipt['status']=='PASS' and receipt['stop'] is None and receipt['registered_research_trials']==32
        pairs=[]
        for w in phase['worlds']:
            full=saved[(w['id'],'full')]['metrics']
            for mask in ARMS[1:]:
                masked=saved[(w['id'],mask)]['metrics']
                pairs.append(dict(world_id=w['id'],family=w['family'],mask=mask,
                    mask_minus_full_deficit_s=masked['service_deficit_time_s']-full['service_deficit_time_s'],
                    full_minus_mask_paid_person_s=full['paid_person_s']-masked['paid_person_s'],
                    full_minus_mask_travel_person_s=full['worker_travel_person_s']-masked['worker_travel_person_s'],
                    full_minus_mask_tool_s=full['tool_occupation_tool_s']-masked['tool_occupation_tool_s']))
        columns=['mask_minus_full_deficit_s','full_minus_mask_paid_person_s','full_minus_mask_travel_person_s','full_minus_mask_tool_s']
        means={mask:{k:math.fsum(p[k] for p in pairs if p['mask']==mask)/8 for k in columns} for mask in ARMS[1:]}
        return dict(status='PASS_SAVED35_SPEC_0_UNRESOLVED',source=SOURCE,delivery=delivery,findings=[],totals=total,
            native_archives=32,native_members=128,private_submission_mappings=mappings,balance_intervals=domain_points,
            independent_unit='8 paired worlds per mask;24 contrasts are not24 independent worlds',runs=list(saved.values()),pairs=pairs,means=means,
            primary_confirmation_result_unchanged='NO_PRACTICAL_GAIN',reviewer_nonce_reads=0,reviewer_seed_derivations=0,
            reviewer_project_imports=0,reviewer_tests=0,reviewer_physical_calls=0,reviewer_selectors=0)
    finally:g.close()

if __name__=='__main__':
    if len(sys.argv)!=2:raise SystemExit('Requires parent-supplied immutable final data-delivery SHA')
    result=verify(sys.argv[1])
    with (OUT/'receipt.json').open('x',encoding='utf-8') as f:json.dump(result,f,indent=2);f.write('\n')
    print(json.dumps({k:v for k,v in result.items() if k not in ['runs','pairs']}))
