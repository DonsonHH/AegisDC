"""Bounded final report audit; no native ZIP re-audit or project imports."""
from collections import Counter
import csv
from hashlib import sha256
import importlib.util
from io import BytesIO,StringIO
import json
from math import fsum,isclose
from pathlib import Path
from zipfile import ZipFile

OUT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('saved_git_helpers',OUT.parent/'32-standards-review-01'/'review.py')
r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r)
r.ROOT=Path(r'C:\Users\Donson\.codex\worktrees\mainline35-ablation\Renly')
CANDIDATE='4df52534b562b15c3cf4bce582d1b4089ef366da'
DELIVERY='ab0efed85621947875469674f2dfcab26bd158bf'
SOURCE='d102173f2a8c31402f70dbf4522371aa18070ed9'
PACKAGE='evidence/mainline/research/35-ablation'
CAPTURE=PACKAGE+'/capture-01'
blob=lambda p,rev=CANDIDATE:r.blob(p,rev)
doc=lambda p,rev=CANDIDATE:r.doc(p,rev)
check=r.check
same=lambda a,b:isclose(a,b,abs_tol=1e-10,rel_tol=0)


def main():
    suffixes={'README.md','results.json','arm-summary.csv','paired-mask-effects.csv','figures/figure-source.json',
        'figures/35-ablation-all-methods.png','figures/35-ablation-all-methods.svg','figures/35-ablation-service-cost.png','figures/35-ablation-service-cost.svg','report-support/manifest.json','report-support/originals.zip'}
    paths={PACKAGE+'/'+p for p in suffixes};r.fetch(CANDIDATE,paths)
    check(all((r.ROOT/p).read_bytes()==blob(p) for p in paths),'All11 report-artifact working bytes equal immutable delivery')
    for subtree in (CAPTURE,PACKAGE+'/prepared-01','evidence/mainline/engineering/35-ablation-adapter','evidence/mainline/research/34-paired-analysis'):
        check(r.git('rev-parse',DELIVERY+':'+subtree)==r.git('rev-parse',CANDIDATE+':'+subtree),'All original source evidence remains unchanged '+subtree)
    frozen=doc('docs/mainline/evidence/30-ablation-execution-lock.json')
    r.pin_check(CANDIDATE,frozen['execution_pins'],'All274 execution code/config blobs unchanged by report authoring')
    check(len(frozen['execution_pins'])==274,'Exact full274-file executed universe retained')
    data=doc(PACKAGE+'/results.json');plan=doc(r.PROTOCOL);worlds=plan['phases']['ablation']['worlds'];arms=plan['phases']['ablation']['arms']
    check(data['status']=='COMPLETE_REGISTERED_ABLATION_DESCRIPTIVE' and data['execution_source']==SOURCE and data['planned_worlds']==8 and data['completed_runs']==32,'Report binds actual source and finite eight-world descriptive scope')
    check(data['primary_confirmation_result_unchanged']=='NO_PRACTICAL_GAIN' and data['new_physical_calls']==data['new_selector_calls']==data['new_seed_reads']==0,'Primary result unchanged; saved interpretation adds no calls')
    check(data['ledger_totals']==doc(CAPTURE+'/receipt.json')['total'],'Reported lifecycle equals previously accepted immutable original')
    runs={(x['world_id'],x['arm']):x for x in data['runs']}
    check(len(data['runs'])==len(runs)==32 and set(runs)=={(w['id'],a) for w in worlds for a in arms},'All four arms and eight worlds retained exactly once')
    for slot in doc(CAPTURE+'/batch.json')['slots']:
        audit=doc(CAPTURE+f"/{slot['index']:02}-{slot['world_id']}-{slot['arm']}/audit.json")
        row=runs[(slot['world_id'],slot['arm'])]
        check(row['status']=='COMPLETED' and row['totals']==audit['totals'] and row['work']==audit['task_dispositions'],'Reported actual metrics equal frozen saved audit '+str(slot['index']))
    effects=list(csv.DictReader(StringIO(blob(PACKAGE+'/paired-mask-effects.csv').decode())))
    pairs={(p['world_id'],p['mask']):p for p in data['pairs']}
    check(len(effects)==len(pairs)==24 and set(pairs)=={(w['id'],a) for w in worlds for a in arms[1:]} and {(x['world_id'],x['mask']) for x in effects}==set(pairs),'All24 paired mask contrasts preserved without selection')
    keys=('mask_minus_full_deficit_s','full_minus_mask_paid_person_s','full_minus_mask_travel_person_s','full_minus_mask_tool_s')
    for effect in effects:
        pair=pairs[(effect['world_id'],effect['mask'])]
        check(effect['family']==pair['family'] and all(same(float(effect[k]),pair[k]) for k in keys),'Every positive/negative/zero CSV contrast retained '+effect['world_id']+'/'+effect['mask'])
    check(all(all(same(data['summary'][arm][k],fsum(p[k] for p in pairs.values() if p['mask']==arm)/8) for k in keys) for arm in arms[1:]),'All three reported mask means use exact eight-world denominator')
    summary=list(csv.DictReader(StringIO(blob(PACKAGE+'/arm-summary.csv').decode())))
    check([x['arm'] for x in summary]==arms and all(int(x['worlds'])==8 for x in summary),'Arm summary preserves all four arms and independent denominator')
    for row in summary:
        selected=[v for (world,arm),v in runs.items() if arm==row['arm']];totals=[v['totals'] for v in selected]
        expected=dict(mean_deficit_s=fsum(t['service_deficit_time_s'] for t in totals)/8,mean_paid_person_s=fsum(t['paid_person_s'] for t in totals)/8,mean_travel_person_s=fsum(t['worker_travel_person_s'] for t in totals)/8,mean_tool_s=fsum(t['tool_occupation_tool_s'] for t in totals)/8,mean_unique_records=fsum(len(v['public_record_ids']) for v in selected)/8,mean_diagnostic_choose_ms=fsum(v['diagnostic_policy_elapsed_ms'] for v in selected)/8,mean_component_shape_validations=fsum(v['adapter']['schema_component_identity_validations'] for v in selected)/8)
        model=Counter()
        for v in selected:model.update(v['model_evaluations'])
        check(all(same(float(row[k]),v) for k,v in expected.items()) and json.loads(row['model_evaluation_totals_json'])==dict(model),'Actual SI, record and diagnostic compute columns remain distinct '+row['arm'])
    support=doc(PACKAGE+'/report-support/manifest.json');raw=blob(PACKAGE+'/report-support/originals.zip')
    check(sha256(raw).hexdigest()==support['archive_sha256'],'Report support archive exact SHA')
    with ZipFile(BytesIO(raw)) as z:
        names=z.namelist();members={p:z.read(p) for p in names}
    check(len(names)==len(set(names))==len(support['members']) and set(names)==set(support['members']) and all(sha256(v).hexdigest()==support['members'][p] for p,v in members.items()),'Every declared author/reviewer source/log/manifest support member exact')
    check(support['new_physical_calls']==support['new_selector_calls']==support['new_seed_reads']==0 and support['primary_confirmation_unchanged']=='NO_PRACTICAL_GAIN' and support['independent_review_findings']==0,'Support explicitly retains non-execution and primary-result scope')
    independent=json.loads(members['review/35-spec-saved-01/independent-paired-facts.json'])
    check(independent.get('execution_source',independent.get('source'))==SOURCE,'Independent saved facts retain actual execution source')
    figure=doc(PACKAGE+'/figures/figure-source.json')
    check(figure['input_sha256']==sha256(blob(PACKAGE+'/results.json')).hexdigest() and figure['authoring_sha256']==sha256(members['author/render_35_results.py']).hexdigest(),'Figure provenance binds results and preserved authoring tool')
    check(len(figure['artifacts'])==4 and all(sha256(blob(PACKAGE+'/figures/'+p)).hexdigest()==h for p,h in figure['artifacts'].items()),'Both actually viewed PNG/SVG figure pairs match recorded source hashes')
    check(figure['font_sha256']==sha256(Path('C:/Windows/Fonts/msyh.ttc').read_bytes()).hexdigest(),'Render font identity matches preserved provenance')
    old_manifest=doc('evidence/mainline/engineering/32-execution-freeze/support/manifest.json')
    helper='integration/32-standards-review-01/review.py'
    check(old_manifest['members'][helper]==sha256((OUT.parent/'32-standards-review-01/review.py').read_bytes()).hexdigest(),'Reused review helper already durably delivered in original32 support archive')
    readme=blob(PACKAGE+'/README.md').decode()
    check(all(x in readme for x in ('NO_PRACTICAL_GAIN','8个固定条件的配对有限均值','不能把32条方法轨迹','选择阶段墙钟仅作诊断','不是现场响应延迟','不与人秒、工具秒混算','唯一3秒工程见证按原628版本封存，未升级','164次注册运行','第36项稳健性和第37–42项仍待完成')),'Reading entry preserves finite units, diagnostic timing, original witness and user checkpoint scope')
    check('没有显示平均服务收益，且多花人工' in readme and len(data['summary'])==3 and any(p['mask_minus_full_deficit_s']<0 for p in pairs.values()) and any(p['mask_minus_full_deficit_s']>0 for p in pairs.values()),'Negative mechanism effects and all three factors remain visible')
    report=dict(status='PASS_FINAL_ABLATION_REPORT_STANDARDS',axis='Standards',candidate=CANDIDATE,original_data=DELIVERY,execution_source=SOURCE,hard_findings=[],advisory_smell_findings=[],checks=r.checks,actual_PNGs_viewed=['35-ablation-all-methods.png','35-ablation-service-cost.png'],scope=dict(physical_calls=0,selector_calls=0,nonce_reads=0,seed_derivations=0,tests=0,project_code_imports=0,native_archives_reaudited=0,tracked_edits=0),boundary='Final report/artifact closure only, supplements complete32-native execution audit; root fresh proof and ticket35 acceptance remain separate.')
    (OUT/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:v for k,v in report.items() if k!='checks'},ensure_ascii=False))
    print('Bounded report/artifact checks:',len(r.checks))


if __name__=='__main__':main()
