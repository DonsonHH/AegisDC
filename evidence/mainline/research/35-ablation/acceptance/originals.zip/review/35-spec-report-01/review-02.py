"""Focused saved-report closure using prior independent facts; no native archive reads."""
from collections import Counter
import csv
import hashlib
import io
import json
import math
import subprocess
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path

REPO=Path('C:/Users/Donson/.codex/worktrees/mainline35-ablation/Renly')
OUT=Path(__file__).resolve().parent
PRIOR=Path('C:/Users/Donson/Documents/ChatGPT/Renly/.work/35-spec-saved-01')
REF='4df52534b562b15c3cf4bce582d1b4089ef366da'
DATA='ab0efed85621947875469674f2dfcab26bd158bf'
ROOT='evidence/mainline/research/35-ablation/'
ARMS=['full','without_nonfixed_context','without_dependency_context','without_joint_crew_planning']
checks=[]
def git(*a):return subprocess.check_output(['git',*a],cwd=REPO)
def blob(n):return git('cat-file','blob',REF+':'+n)
def read(n):return json.loads(blob(n))
def sha(raw):return hashlib.sha256(raw).hexdigest()
def close(a,b):return math.isclose(a,b,rel_tol=0,abs_tol=1e-8)
def check(ok,message):
    if not ok:raise AssertionError(message)
    checks.append(message)

r=read(ROOT+'results.json');old=json.loads((PRIOR/'independent-paired-facts.json').read_bytes())
prior=json.loads((PRIOR/'receipt.json').read_bytes())
check(git('diff','--name-only',DATA,REF,'src','scripts','configs',ROOT+'capture-01',
          'evidence/mainline/research/34-paired-analysis/results.json')==b'',
      'Report is additive; original32-run data,274 executable/configuration blobs and primary confirmation results are unchanged')
check(r['status']=='COMPLETE_REGISTERED_ABLATION_DESCRIPTIVE' and r['planned_worlds']==8 and r['completed_runs']==32
      and r['execution_source']==old['execution_source']=='d102173f2a8c31402f70dbf4522371aa18070ed9'
      and r['ledger_totals']==prior['totals'],
      'Report binds the accepted original capture and exact eight-world/32-run denominator')
pairs={(p['world_id'],p['mask']):p for p in r['pairs']};independent={(p['world_id'],p['mask']):p for p in old['pairs']}
check(len(r['pairs'])==len(pairs)==24 and set(pairs)==set(independent),
      'All24 within-world contrasts are retained once, eight per original mask')
columns=['mask_minus_full_deficit_s','full_minus_mask_paid_person_s','full_minus_mask_travel_person_s','full_minus_mask_tool_s']
for key,p in pairs.items():
    assert p['family']==independent[key]['family']
    for k in columns:assert close(p[k],independent[key][k]),(key,k)
for arm in ARMS[1:]:
    for k in columns:
        value=math.fsum(p[k] for p in pairs.values() if p['mask']==arm)/8
        assert close(value,r['summary'][arm][k]) and close(value,old['means'][arm][k])
check(True,'Every service/paid/travel/tool contrast and eight-world mean matches independent saved-native arithmetic')
runs={(x['world_id'],x['arm']):x for x in r['runs']};saved={(x['world_id'],x['arm']):x for x in old['runs']}
check(len(runs)==32 and set(runs)==set(saved),'Every original run appears once in four-arm reporting')
for key,row in runs.items():
    assert row['status']=='COMPLETED'
    for k,v in saved[key]['metrics'].items():assert close(v,row['totals'][k])
    assert row['model_evaluations']['action_value']==20
    assert row['adapter']['schema_component_identity_validations']==(20 if row['arm']=='without_dependency_context' else 0)
summaries={}
for arm in ARMS:
    rows=[x for x in r['runs'] if x['arm']==arm];assert len(rows)==8
    counter=Counter()
    for row in rows:counter.update(row['model_evaluations'])
    summaries[arm]=dict(mean_deficit_s=math.fsum(x['totals']['service_deficit_time_s'] for x in rows)/8,
        mean_paid_person_s=math.fsum(x['totals']['paid_person_s'] for x in rows)/8,
        mean_travel_person_s=math.fsum(x['totals']['worker_travel_person_s'] for x in rows)/8,
        mean_tool_s=math.fsum(x['totals']['tool_occupation_tool_s'] for x in rows)/8,
        mean_unique_records=math.fsum(len(x['public_record_ids']) for x in rows)/8,
        mean_diagnostic_choose_ms=math.fsum(x['diagnostic_policy_elapsed_ms'] for x in rows)/8,
        mean_component_shape_validations=math.fsum(x['adapter']['schema_component_identity_validations'] for x in rows)/8,
        model_evaluation_totals_json=dict(counter))
for filename,expected in [('arm-summary.csv',4),('paired-mask-effects.csv',24)]:
    raw=blob(ROOT+filename);assert b'\r' not in raw and raw.endswith(b'\n') and raw.count(b'\n')==expected+1
    rows=list(csv.DictReader(io.StringIO(raw.decode(),newline='')));assert len(rows)==expected
    if filename=='arm-summary.csv':
        assert {row['arm'] for row in rows}==set(ARMS)
        for row in rows:
            assert int(row['worlds'])==8
            for k,value in summaries[row['arm']].items():
                if k=='model_evaluation_totals_json':assert json.loads(row[k])==value
                else:assert close(float(row[k]),value)
    else:
        assert {(x['world_id'],x['mask']) for x in rows}==set(pairs)
        for row in rows:
            p=pairs[(row['world_id'],row['mask'])];assert row['family']==p['family']
            for k in columns:assert close(float(row[k]),p[k])
check(True,'Both exact-LF CSVs reproduce all outcome, record, model-call, identity-validation and diagnostic-wall rows without mixing units')
support=read(ROOT+'report-support/manifest.json');raw=blob(ROOT+'report-support/originals.zip')
assert sha(raw)==support['archive_sha256']
with zipfile.ZipFile(io.BytesIO(raw)) as archive:
    assert len(archive.namelist())==len(support['members']) and set(archive.namelist())==set(support['members'])
    members={n:archive.read(n) for n in archive.namelist()}
assert all(sha(raw)==support['members'][n] for n,raw in members.items())
check(json.loads(members['review/35-spec-saved-01/independent-paired-facts.json'])==old
      and sha(members['review/35-spec-saved-01/manifest.json'])==sha((PRIOR/'manifest.json').read_bytes()),
      'Support archive preserves exact prior independent evidence and its manifest')
fig=read(ROOT+'figures/figure-source.json')
check(fig['input_sha256']==sha(blob(ROOT+'results.json'))
      and fig['authoring_sha256']==sha(members['author/render_35_results.py']),
      'Figures bind exact saved analysis and preserved authoring source')
assert len(fig['artifacts'])==4
for name,h in fig['artifacts'].items():
    raw=blob(ROOT+'figures/'+name);assert sha(raw)==h
    if name.endswith('.svg'):assert ET.fromstring(raw).tag.endswith('svg')
    else:assert raw.startswith(b'\x89PNG\r\n\x1a\n') and sha((REPO/ROOT/'figures'/name).read_bytes())==h
check(True,'Two actually viewed PNGs match committed bytes; both companion SVGs have valid XML and exact provenance SHA')
text=blob(ROOT+'README.md').decode()
check(all(s in text for s in ['NO_PRACTICAL_GAIN','8个独立封存工况','不能把32条方法轨迹','组合知识因素',
      '未评价最优班组分配算法','唯一3秒工程见证按原628版本封存','本轮共164次注册运行','第36项稳健性和第37–42项仍待完成']),
      'Narrative retains primary negative result, finite unit, bundled mask meaning, original engineering truth and unfinished scope')
check('正值表示屏蔽后更差' in text and '人工列正值表示完整候选多付人工' in text
      and '墙钟仅作诊断' in text and '不是现场响应延迟' in text,
      'All service/cost signs and wall-clock limitations are explicit and agree with viewed figures')
result=dict(status='PASS35_REPORT_SPEC_0_UNRESOLVED',candidate=REF,raw_data=DATA,execution_source=r['execution_source'],
    findings=[],checks=checks,denominator=8,contrasts=24,mean_facts=r['summary'],viewed_pngs=2,verified_svgs=2,
    primary_result_unchanged=r['primary_confirmation_result_unchanged'],
    reviewer_native_rereads=0,reviewer_nonce_reads=0,reviewer_seed_derivations=0,reviewer_project_imports=0,
    reviewer_tests=0,reviewer_physical_calls=0,reviewer_selectors=0)
assert result['primary_result_unchanged']=='NO_PRACTICAL_GAIN'
with (OUT/'receipt.json').open('x',encoding='utf-8') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps({k:v for k,v in result.items() if k!='checks'}))
