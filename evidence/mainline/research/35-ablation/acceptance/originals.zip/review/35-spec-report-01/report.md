# Ticket35 report and figure closure — Spec

Candidate: `4df52534b562b15c3cf4bce582d1b4089ef366da`.
Original data: `ab0efed85621947875469674f2dfcab26bd158bf`; execution: `d102173f2a8c31402f70dbf4522371aa18070ed9`.

**Pass: zero unresolved Spec findings.** The report is additive: original32-run data,274 executable/configuration blobs and primary confirmation results are unchanged. Every24 contrast and all eight-world mean service/paid/travel/tool differences match the prior independent saved-native facts. Denominators remain eight paired worlds per mask; the32 method runs and individual state points are not promoted to independent field samples.

Signs and interpretation are correct. Mask-minus-full service differences are +0.07324218750000022s for nonfixed context and −0.0146484375s for dependency/team masks. Full-minus-mask paid time is respectively −1.375, +5.09375 and +4.15625 person-s. The report preserves the opposite effects, cost tradeoffs and original `NO_PRACTICAL_GAIN` confirmation conclusion.

Both CSVs reproduce all paired and four-arm rows, including actual record counts, model-call counters, component-identity validation counts and diagnostic wall time. Wall time is explicitly separated from physical response and person/tool costs. The CSV originals use exact LF bytes. The first reviewer check incorrectly inherited ticket34's CRLF-only expectation; that script and diagnostic are preserved, and the corrected check validates the current LF format without changing artifacts.

Two PNGs were actually viewed. Their values, labels, color direction, units and limitations agree with the data. Viewed files match committed SHA values; both matching SVGs have valid XML and exact provenance. The support archive binds authoring source, results and the exact preceding independent review packet.

Mask scope remains precise: dependency is a bundled edge/consequence factor; team choice is not optimal crew assignment. The old628 three-second witness retains its original source scope, while current mapping evidence comes from the actual registered batch. The report explicitly leaves36–42 unfinished and introduces the requested checkpoint35 direction review.

No native members were reread for this closure. Reviewer made zero tests, project imports, physical/selector calls or nonce/seed operations, and changed no tracked file. Evidence: `receipt.json`, `review-02.py`, original review diagnostic and `manifest.json`.
