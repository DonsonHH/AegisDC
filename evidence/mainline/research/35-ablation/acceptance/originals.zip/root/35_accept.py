import hashlib,json,subprocess
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
root=Path(__file__).resolve().parents[1];read=lambda p:json.loads(p.read_bytes());sha=lambda b:hashlib.sha256(b).hexdigest()
def write(p,obj):p.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
spec=read(root/'.work/35-spec-report-01/receipt.json');standard=read(root/'.work/35-standards-report-01/report.json')
assert spec['findings']==standard['hard_findings']==standard['advisory_smell_findings']==[]
assert spec['candidate']==standard['candidate']=='4df52534b562b15c3cf4bce582d1b4089ef366da'
data=read(root/'evidence/mainline/research/35-ablation/results.json')
assert data['completed_runs']==32 and data['primary_confirmation_result_unchanged']=='NO_PRACTICAL_GAIN'
assert '\nOK\n' in (root/'.work/35-root-focused-01.log').read_text(encoding='utf-8').replace('\r\n','\n')
files={}
for directory in ('35-spec-report-01','35-standards-report-01'):
    folder=root/'.work'/directory;assert (folder/'manifest.json').is_file()
    for p in folder.iterdir():
        if p.is_file():files['review/'+directory+'/'+p.name]=p.read_bytes()
for name in ('35-fresh-delivery-proof-01.json','35_fresh_delivery.py','35-root-focused-01.log','35_accept.py'):
    files['root/'+name]=(root/'.work'/name).read_bytes()
out=root/'evidence/mainline/research/35-ablation/acceptance';out.mkdir()
with ZipFile(out/'originals.zip','x',compression=ZIP_DEFLATED) as z:
    for n,b in sorted(files.items()):z.writestr(n,b)
write(out/'manifest.json',dict(schema='aegisdc-accepted-registered-ablation-v1',archive_sha256=sha((out/'originals.zip').read_bytes()),
    members={n:sha(b) for n,b in sorted(files.items())},unresolved_findings=0,root_focused_tests=1,
    root_new_physical_calls=0,root_registered_attempts=0,root_public_engineering_selector_calls=1))
write(root/'docs/mainline/evidence/35-root-delivery.json',read(root/'.work/35-fresh-delivery-proof-01.json'))
source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
write(root/'docs/mainline/evidence/35-root.json',dict(status='ACCEPTED',ticket='35',milestone='M6',date='2026-11-08',
    scope='REGISTERED_EIGHT_WORLD_MECHANISM_ABLATION_AND_COMPLETE_SOURCE_EVIDENCE',actual_root_source=source,
    execution_source='d102173f2a8c31402f70dbf4522371aa18070ed9',source_freeze='6c98bee2404c8a4694ce334204ca6e2d996f6bae',
    original_data_delivery='ab0efed85621947875469674f2dfcab26bd158bf',report_delivery=spec['candidate'],
    original_runs=32,independent_worlds=8,arms=4,simulated_seconds=320,scheduled_decisions=320,
    failed=0,interrupted=0,unrun=0,retries=0,native_members=128,trace_points=32344,balance_intervals=32312,
    actual_intentions=28,private_submission_mapping_records=56,observed_hard_violations=0,
    mechanism_effects=data['summary'],primary_confirmation_result_unchanged='NO_PRACTICAL_GAIN',
    global_registered_runs=164,global_registered_simulated_s=1640,
    separate_engineering_witness=dict(source='62856b3936a84f48d600258fe6fe0267b593dad8',calls=1,simulated_s=3,not_registered=True),
    reviews=dict(spec='PASS_0_UNRESOLVED',standards='PASS_0_UNRESOLVED'),figures=2,
    fresh_proof='docs/mainline/evidence/35-root-delivery.json',acceptance_manifest=out.relative_to(root).as_posix()+'/manifest.json',
    field_calibration='PENDING',research_goal='INCOMPLETE',next_ticket='36',user_review_checkpoint='35'))
p=root/'docs/mainline/progress.json';progress=read(p);assert progress['current_ticket']=='35'
progress['current_ticket']='36';progress['research_execution_status']='awaiting_user_review_at_checkpoint35'
progress['milestones'][6]['acceptance_evidence'].append('docs/mainline/evidence/35-root.json')
progress['milestones'][6]['progress_scope']='34 primary analysis and35 independent masks accepted.36robustness and37baseline closeout pending; user review checkpoint35.'
r=progress['research_trials'];r.update(status='ablation_completed_pending_robustness',attempts=164,completed=164,failure_records=0,
    charged_s=1640,planned_attempts=180,remaining_registered_attempts=16)
r['ablation'].update(attempts=32,completed=32,failed=0,interrupted=0,unrun=0,charged_s=320,scheduled_decisions=320)
r['robustness']=dict(attempts=0,materialized=False,planned_attempts=16)
progress['active_implementations']=[];progress['user_review_checkpoint'].update(status='ready_for_user_review',accepted_through='35',remaining_tickets=[str(i) for i in range(36,43)])
progress['liveness_refresh']='2026-11-08:35accepted after all original data, both review axes, actual plots, focused integration and fresh delivery. No36owner or run; checkpoint delivery finishing.'
write(p,progress)
p=root/'.scratch/full-facility-mainline/issues/35-knowledge-ablation.md';s=p.read_text(encoding='utf-8').replace('**Status:** claimed','**Status:** resolved').replace('- [ ]','- [x]')
s=s.replace('Pending implementation and acceptance.','Accepted: docs/mainline/evidence/35-root.json;8worlds32originalruns, complete masks/private execution proof, both independent reviews,2data figures and fresh delivery. Primary NO_PRACTICAL_GAIN unchanged; usercheckpoint35 before36.')
p.write_text(s,encoding='utf-8',newline='\n')
p=root/'docs/MAINLINE.md';s=p.read_text(encoding='utf-8').replace('M0–M4 已按声明的有限工程范围接受。','M0–M5已按各自有限范围接受。')
s=s.replace('第34项独立配对分析已接受，当前主票35机制消融','第35项机制消融已接受，下一主票36稳健性待用户阶段复核后推进')
s=s.replace('已完成 36 次注册开发运行，独立确认96次已完成','已完成36次开发、96次独立确认和32次消融，共164次注册运行')
s+='\n[第35项消融数据与两张新图](../evidence/mainline/research/35-ablation/README.md)保留非固定线索、依赖后果和团队选项的正/反向作用及实际代价。按用户要求在35后进行阶段方向复核；36–42未完成，M6/M7及总研究目标未关闭。\n'
p.write_text(s,encoding='utf-8',newline='\n')
main=read(root/'.work/34-main-publication-01.json');integration=read(root/'.work/34-integration-publication-01.json')
assert main['ci']['conclusion']==integration['ci']['conclusion']=='success'
write(root/'docs/mainline/evidence/34-publication.json',dict(status='PUBLISHED_EXACT_REMOTE_AND_SUCCESSFUL_PUSH_CI',ticket='34',main=main,integration=integration,new_registered_runs=0))
hint=root/'.work/mainline-continuation-hints.json';h=read(hint);h.update(status='CHECKPOINT35_DELIVERY_FINISHING',root_head=source,
    primary_ticket='36',accepted_tickets=[f'{i:02}' for i in range(1,36)],active=[],registered_attempts=164,
    ablation_attempts=32,user_review_checkpoint=dict(ticket='35',status='research_waiting_user_review_delivery_finishing',full42_goal='INCOMPLETE'),
    next='Build source-bound offline checkpoint35HTML/README/NEXT, renderphone+desktop,finalfreshproof,pushmain+integrationnonforce,verifyexactremote/CI,thenpausegoalperuser. Do notstart36.')
write(hint,h)
print(json.dumps(dict(status='ACCEPTED35',current_ticket='36_NOT_STARTED',registered_runs=164,full_goal='INCOMPLETE',checkpoint='USER_REVIEW35')))
