import argparse,hashlib,json,subprocess
from pathlib import Path
from zipfile import ZipFile
p=argparse.ArgumentParser();p.add_argument('checkout',type=Path);p.add_argument('--delivery',required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
root=a.checkout.resolve();sha=lambda b:hashlib.sha256(b).hexdigest();read=lambda p:json.loads(p.read_bytes())
def git(*v):return subprocess.check_output(['git',*v],cwd=root)
assert git('rev-parse','HEAD').decode().strip()==a.delivery and not git('status','--porcelain')
base=root/'evidence/mainline/research/35-ablation';capture=base/'capture-01';batch=read(capture/'batch.json');receipt=read(capture/'receipt.json')
names=set(batch['pins'])|{p.relative_to(root).as_posix() for p in base.rglob('*') if p.is_file()}
names=sorted(names);raw=subprocess.check_output(['git','cat-file','--batch'],cwd=root,input=''.join(a.delivery+':'+n+'\n' for n in names).encode())
offset=0
for name in names:
    end=raw.index(b'\n',offset);header=raw[offset:end].split();assert len(header)==3 and header[1]==b'blob'
    start=end+1;size=int(header[2]);blob=raw[start:start+size];offset=start+size+1
    assert blob==(root/name).read_bytes(),name
    if name in batch['pins']:assert sha(blob)==batch['pins'][name],name
assert offset==len(raw)
assert {p.relative_to(capture).as_posix() for p in capture.rglob('*') if p.is_file()}==set(receipt['artifacts'])|{'receipt.json'}
assert all(sha((capture/n).read_bytes())==h for n,h in receipt['artifacts'].items())
runtime={n:h for n,h in batch['pins'].items() if n.startswith('src/aegis_dc/') and n.endswith('.py') or n=='src/patrol_rsi/contracts.py'}
native_members=0
for slot in batch['slots']:
    case=capture/f"{slot['index']:02}-{slot['world_id']}-{slot['arm']}";manifest=read(case/'originals.json')
    assert read(case/'terminal.json')['status']=='COMPLETED' and sha((case/'originals.zip').read_bytes())==manifest['archive_sha256']
    with ZipFile(case/'originals.zip') as z:
        assert len(z.namelist())==4 and set(z.namelist())==set(manifest['members']);members={n:z.read(n) for n in z.namelist()}
    assert all(sha(b)==manifest['members'][n] for n,b in members.items());native_members+=4
    run=json.loads(members['run.json']);assert run['code_identity']['git_commit']==batch['execution_commit']
    assert run['code_identity']['files']==runtime and run['code_identity']['implementation_has_changes'] is False
    assert run['ablation_execution_audit']['mask']==slot['arm']
    assert run['ablation_execution_audit']['adapter_sha256']==batch['pins']['scripts/ablation_planner.py']
    for n,v in run['artifacts'].items():assert sha(members[n])==v['sha256']
for directory in ('preparation-support','execution-freeze','capture-support','report-support'):
    folder=base/directory;manifest=read(folder/'manifest.json');assert sha((folder/'originals.zip').read_bytes())==manifest['archive_sha256']
    with ZipFile(folder/'originals.zip') as z:
        assert len(z.namelist())==len(manifest['members']) and set(z.namelist())==set(manifest['members'])
        assert all(sha(z.read(n))==h for n,h in manifest['members'].items())
        if directory=='report-support':renderer=z.read('author/render_35_results.py')
figures=read(base/'figures/figure-source.json');assert figures['input_sha256']==sha((base/'results.json').read_bytes())
assert figures['authoring_sha256']==sha(renderer) and all(sha((base/'figures'/n).read_bytes())==h for n,h in figures['artifacts'].items())
result=read(base/'results.json');assert result['completed_runs']==32 and result['planned_worlds']==8
value=dict(status='PASS_EXACT_FRESH_ABLATION_DATA_AND_REPORT',delivery=a.delivery,execution_source=batch['execution_commit'],
    declared_files=len(names),native_archives=32,native_members=native_members,figures=2,
    new_physical_calls=0,new_selector_calls=0,new_seed_reads=0)
with a.output.open('x',encoding='utf-8',newline='\n') as f:json.dump(value,f,indent=2);f.write('\n')
print(json.dumps(value))
