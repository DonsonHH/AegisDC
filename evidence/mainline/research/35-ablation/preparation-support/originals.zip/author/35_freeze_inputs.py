import hashlib,json,sys
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
root=Path(__file__).resolve().parents[1];integration=Path('C:/Users/Donson/Documents/ChatGPT/Renly')
sys.path.insert(0,str(root/'scripts'))
from comparison_release import _execution_files
from inspection_delivery import hashes
read=lambda p:json.loads(p.read_bytes());sha=lambda b:hashlib.sha256(b).hexdigest()
def write(p,obj):p.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
files={}
for directory in ('35-spec-pre-01','35-standards-pre-01'):
    folder=integration/'.work'/directory;assert (folder/'manifest.json').is_file()
    for p in folder.iterdir():
        if p.is_file():files['review/'+directory+'/'+p.name]=p.read_bytes()
for p in (root/'.work/35-input-launch-01').iterdir():
    if p.is_file():files['input-launch/'+p.name]=p.read_bytes()
for name in ('run_35_prepare.py','35_freeze_inputs.py'):files['author/'+name]=(root/'.work'/name).read_bytes()
out=root/'evidence/mainline/research/35-ablation/preparation-support';out.mkdir()
with ZipFile(out/'originals.zip','x',compression=ZIP_DEFLATED) as z:
    for n,b in sorted(files.items()):z.writestr(n,b)
write(out/'manifest.json',dict(schema='aegisdc-reviewed-mask-preparation-artifacts-v1',
    archive_sha256=sha((out/'originals.zip').read_bytes()),members={n:sha(b) for n,b in sorted(files.items())},
    registered_physical_calls=0,preparation_physical_calls=0,preparation_selector_calls=0,
    preparation_nonce_reads=2,review_physical_calls=0,review_selector_calls=0,review_nonce_reads=0))
receipt=read(root/'evidence/mainline/research/35-ablation/prepared-01/receipt.json');assert receipt['status']=='PASS_INPUT_ONLY'
source='6c98bee2404c8a4694ce334204ca6e2d996f6bae'
lock=dict(schema='aegisdc-comparison-execution-lock-v1',status='PENDING_REVIEW',phase='ablation',
    design_lock_sha256=sha((root/'docs/mainline/evidence/30-protocol-lock.json').read_bytes()),
    execution_source=source,execution_pins=hashes(source,_execution_files(source)),
    interpreter_sha256=sha(Path(sys.executable).read_bytes()),input_hashes=receipt['input_hashes'],
    budget=read(root/'docs/mainline/30-comparison-protocol-v1.json')['phases']['ablation']['budget'])
write(root/'docs/mainline/evidence/30-ablation-execution-lock.json',lock)
p=root/'docs/mainline/progress.json';progress=read(p)
progress['research_trials']['ablation'].update(materialized=True,worlds=8,inputs=32,attempts=0)
progress['active_implementations'][0]['state']='prepared_inputs_pending_final_execution_authorization'
progress['liveness_refresh']='2026-11-08:35 pre-preparation source review passed;32 independent inputs prepared once,0registered ablation calls.'
write(p,progress)
print(json.dumps(dict(status='PENDING_EXACT_ABLATION_FREEZE_REVIEW',source=source,pins=len(lock['execution_pins']),inputs=len(lock['input_hashes']),support_members=len(files))))
