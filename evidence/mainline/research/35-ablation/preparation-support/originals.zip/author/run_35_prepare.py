import json,subprocess,sys,os
from datetime import datetime,timezone
from pathlib import Path
root=Path(__file__).resolve().parents[1];launch=root/'.work/35-input-launch-01';launch.mkdir()
source='6c98bee2404c8a4694ce334204ca6e2d996f6bae'
cmd=[sys.executable,'-B','-X','utf8','-X','pycache_prefix='+str(root/'.work/35-input-unused-cache-01'),
    'scripts/prepare_ablation.py','prepare','--source',source,
    '--nonce','C:/Users/Donson/.codex/private-research/AegisDC/30-comparison-v1/ablation.bin',
    '--output',str(root/'evidence/mainline/research/35-ablation/prepared-01')]
def write(n,obj):
    with (launch/n).open('x',encoding='utf-8',newline='\n') as f:json.dump(obj,f,indent=2);f.write('\n')
write('attempt.json',dict(source=source,command=cmd,started_utc=datetime.now(timezone.utc).isoformat(),
    classification='INPUT_ONLY_PREPARATION_NOT_REGISTERED_EFFECT_ATTEMPT',physical_calls=0,selector_calls=0))
env=os.environ.copy();env['PYTHONPATH']=str(root/'src')
with (launch/'stdio.log').open('xb') as out:run=subprocess.run(cmd,cwd=root,env=env,stdout=out,stderr=subprocess.STDOUT)
write('terminal.json',dict(returncode=run.returncode,finished_utc=datetime.now(timezone.utc).isoformat(),physical_calls=0,selector_calls=0))
print((launch/'stdio.log').read_text(encoding='utf-8'))
raise SystemExit(run.returncode)
