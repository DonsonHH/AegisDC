# Ticket35 Spec review — original interface finding

Candidate: `62856b3936a84f48d600258fe6fe0267b593dad8`; base accepted34: `4b5f0b34`.

**Execution blocker:** `without_dependency_context` correctly removes f12/f13/f14 from the public planner frame, but `MaskedSession.process` passes that same masked frame into the unchanged `PolicySession.process`. Once a task is selected, the inherited process calls the actual `CrewWorkforce.submit(frame, task)`. Its closed gate (`src/aegis_dc/workforce_dispatch.py:132–135`) requires exact equality with the full nominal registry bound when the actual executor was constructed. A masked nominal frame cannot satisfy it. The registered dependency arm would therefore stop at its first selected task rather than evaluate the intended knowledge factor.

This conflicts with ticket35's requirement to keep the actual facility/executor and permissions intact while deleting planner knowledge. Add an explicit private submission-frame mapping that restores only the actual executor's declared static nominal registry, preserving current time, arrived evidence, request/task identity, access/qualification/tool and authorization gates. Keep the recorded public choice frame masked; do not remove the typed executor's equality or safety checks.

The three mask transformations otherwise match the original held-blueprint declarations. The dependency catalog's validation-only identity copy preserves compute-only consequences and does not insert edges into the planner's recorded frame. Preparation defaults to no selector calls, and registered capture preserves durable charging/stopping/no-retry accounting. The unchanged original source/configuration identity and prospective source/input lock still require final verification before preparation/execution.

The separately frozen joint-choice engineering witness is reported complete by root, but its immutable delivery has not yet been supplied to this reviewer. That witness does not establish the dependency arm's submission path. No reviewer test, selector, physical, nonce or seed call was made. Original source/finding retained pending a corrected candidate and saved engineering evidence.
