# Ticket35 pre-preparation Spec review

Corrected source: `6255fad792218790d3433df42f84d3d495e3b4d8`.
Engineering delivery: `6c98bee2404c8a4694ce334204ca6e2d996f6bae`.
Base accepted34: `4b5f0b34`.

**Pass for input preparation: zero unresolved Spec findings.** The original628 finding is preserved in `original-628-finding.md` and resolved by an explicit private issue adapter. It deep-copies the selected public frame and restores only the executor's declared static nominal registry. The task, evidence, requests and current clock remain unchanged. Calls still reach the original typed crew/intervention methods, retaining their nominal-equality, qualification, access, tool, authorization and timing gates. Recorded public decision frames remain masked.

The native marker now requires exactly one WORK_SUBMIT and ACTION_ISSUE mapping per selected task, with current time/task identity and evidence/planner-nominal/actual-nominal hashes. The saved evaluator checks full actual inputs and both view identities before projecting a local copy for public-choice checks; raw native inputs are not waived. The dependency catalog uses an isolated validation-only identity copy, while planner graph and compute-only consequences remain masked.

The original three mask transforms match the frozen blueprint and are unchanged by this correction. All269 accepted executable/configuration blobs remain identical; only five new scoped scripts are added. Capture preserves the accepted durable STARTED/terminal/stop/UNRUN/no-retry algorithm. Protocol, commitments, independent8-world/32-run budget and primary negative result are unchanged.

The original one-call3s/three-decision joint-choice engineering witness is intact. Its four native members, exact actual inputs, full catalog2/planner1 split, completed singleton inspection and zero interventions were verified against its **actual628 source and old adapter SHA**. It is not presented as physical validation of the later mapping. Two failed development logs and three later successful logs remain preserved.

This is a prospective interface review, not acceptance of unmaterialized phase inputs or scientific gain. Exact32 input-only originals, prospective source lock, both freeze reviews, fresh checkout and committed execution authorization remain required before the registered batch. Reviewer performed zero project imports, tests, nonce/seed operations, selectors or physical calls. No tracked file changed.

Evidence: `review.py`, `receipt.json`, `manifest.json`.
