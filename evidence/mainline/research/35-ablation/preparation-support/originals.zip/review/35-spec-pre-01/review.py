"""Static35 interface closure and saved old-source engineering audit; no project imports."""
import ast
import copy
import hashlib
import io
import json
import subprocess
import zipfile
from pathlib import Path

REPO=Path('C:/Users/Donson/.codex/worktrees/mainline35-ablation/Renly')
OUT=Path(__file__).resolve().parent
BASE='4b5f0b34';OLD='62856b3936a84f48d600258fe6fe0267b593dad8'
SOURCE='6255fad792218790d3433df42f84d3d495e3b4d8'
DELIVERY='6c98bee2404c8a4694ce334204ca6e2d996f6bae'
PACKAGE='evidence/mainline/engineering/35-ablation-adapter/'
checks=[]
def git(*a):return subprocess.check_output(['git',*a],cwd=REPO)
def blob(ref,n):return git('cat-file','blob',ref+':'+n)
def read(ref,n):return json.loads(blob(ref,n))
def sha(raw):return hashlib.sha256(raw).hexdigest()
def fp(obj):return sha(json.dumps(obj,sort_keys=True,separators=(',',':'),allow_nan=False).encode())
def check(value,message):
    if not value:raise AssertionError(message)
    checks.append(message)
def fn(raw,name):return next(n for n in ast.parse(raw).body if isinstance(n,ast.FunctionDef) and n.name==name)
def code_paths(ref):return {n for n in git('ls-tree','-rz','--name-only',ref,'src','scripts','configs').decode().split('\0') if n.endswith(('.py','.json'))}
def hashes(ref,names):
    names=sorted(names);offset=0;result={}
    raw=subprocess.check_output(['git','cat-file','--batch'],cwd=REPO,input=''.join(ref+':'+n+'\n' for n in names).encode())
    for n in names:
        end=raw.index(b'\n',offset);header=raw[offset:end].split();assert len(header)==3 and header[1]==b'blob'
        start=end+1;size=int(header[2]);result[n]=sha(raw[start:start+size]);offset=start+size+1
    assert offset==len(raw);return result

original=code_paths(BASE);current=code_paths(SOURCE)
check(len(original)==269 and hashes(BASE,original)==hashes(SOURCE,original)==hashes(DELIVERY,original),
      'All269 accepted executable/configuration blobs remain byte-identical')
check(current-original=={'scripts/'+n+'.py' for n in ['ablation_planner','ablation_run_evidence','prepare_ablation','registered_ablation','analyze_registered_ablation']}
      and hashes(SOURCE,current)==hashes(DELIVERY,current),
      'Exactly five new scripts are prospectively added; delivery is data-only')
check(git('diff','--name-only',BASE,SOURCE,'docs/mainline/30-comparison-protocol-v1.json','docs/mainline/evidence/30-protocol-lock.json')==b'',
      'Frozen methods, ablation recipes/masks, budgets, commitments and primary negative result are not revised')
planner=blob(SOURCE,'scripts/ablation_planner.py').decode();audit=blob(SOURCE,'scripts/ablation_run_evidence.py').decode()
check(ast.dump(fn(planner,'planner_view'),include_attributes=False)==ast.dump(fn(blob(OLD,'scripts/ablation_planner.py'),'planner_view'),include_attributes=False),
      'Private submission correction changes none of the original three planner mask transforms')
scope=fn(planner,'planning_scope')
check('validation_frame=deepcopy(frame)' in planner and 'original_validator(catalog,validation_frame,belief)' in planner
      and 'risk_scenarios._catalog_for_frame=original_validator' in planner,
      'Dependency component identities exist only in validation copy; actual planner graph and compute-only consequences remain masked')
tree=ast.parse(planner)
actual=next(n for n in ast.walk(tree) if isinstance(n,ast.FunctionDef) and n.name=='actual_frame')
subscript_assignments=[n.targets[0] for n in ast.walk(actual) if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Subscript)]
check(len(subscript_assignments)==1 and ast.unparse(subscript_assignments[0])=="value['nominal_knowledge']"
      and 'value=deepcopy(frame)' in planner and "deepcopy(session.execution_program['nominal_knowledge'])" in planner,
      'Private issue frame restores only full declared static nominal registry; current evidence, requests and clock are unchanged')
check("workforce.submit(actual_frame(frame,task,'WORK_SUBMIT'),task)" in planner
      and "interventions.record_issue(actual_frame(frame,task,'ACTION_ISSUE'),profile,task)" in planner
      and 'validate_current_frame(value)' in planner,
      'Unchanged task goes to original typed crew/intervention methods; original equality, clock and safety gates remain active')
check("private_submission_frames=deepcopy(session.private_submission_frames)" in planner
      and "for channel in ('WORK_SUBMIT','ACTION_ISSUE')" in audit
      and "for r in marker['private_submission_frames'])==expected" in audit
      and all(s in audit for s in ["row['evidence_sha256']==fingerprint(decision['frame']['evidence'])",
         "row['planner_nominal_sha256']==fingerprint(planning['nominal_knowledge'])",
         "row['actual_nominal_sha256']==fingerprint(actual['nominal_knowledge'])"]),
      'Mandatory private audit has exactly two mappings per selected task with exact time/task/evidence/both-nominal identities')
check("projected=deepcopy(run)" in audit and "run['inputs']['dispatch_program']==actual" in audit
      and audit.index("run['inputs']['dispatch_program']==actual")<audit.index('projected=deepcopy(run)'),
      'Evaluator projects only its local copy after strict full actual input and view identities; native bytes are not waived')
def capture(raw):
    node=fn(raw,'capture')
    class Normalize(ast.NodeTransformer):
        def visit_ImportFrom(self,n):return ast.copy_location(ast.Pass(),n)
        def visit_Call(self,n):
            self.generic_visit(n)
            if isinstance(n.func,ast.Name) and n.func.id in ['simulate_scenario','simulate_masked']:
                return ast.copy_location(ast.Call(func=ast.Name(id='DECLARED_PHYSICAL_ADAPTER',ctx=ast.Load()),args=[],keywords=[]),n)
            return n
    return ast.dump(Normalize().visit(node),include_attributes=False)
check(capture(blob(SOURCE,'scripts/registered_ablation.py'))==capture(blob(BASE,'scripts/registered_confirmation.py')),
      'Capture retains accepted append/fsync/readback/start-before-call/terminal/stop/UNRUN/no-retry algorithm apart from declared adapter invocation')
prepare=blob(SOURCE,'scripts/prepare_ablation.py').decode();runner=blob(SOURCE,'scripts/registered_ablation.py').decode()
check("def validate_view(document,mask,*,choose=False)" in prepare and 'validate_view(document,arm)' in prepare
      and "audit_release('ablation','prepare'" in prepare and "'Use clean exact ablation preparation source'" in prepare,
      'Input preparation defaults to no selector and gates accepted34, clean exact source and unique unused outputs')
check("authorization['status']=='REVIEWED_TO_EXECUTE'" in runner
      and "authorization['execution_lock_sha256']==digest((ROOT/EXECUTION_LOCK).read_bytes())" in runner
      and "audit_release(PHASE,'execute'" in runner,
      'Actual32-slot phase remains blocked on exact reviewed input/source lock and independent authorization')

prefix=PACKAGE+'fixture-01/'
receipt=read(DELIVERY,prefix+'receipt.json');attempt=read(DELIVERY,prefix+'attempt.json')
check(receipt['status']=='PASS_ENGINEERING_VIEW_WITNESS' and receipt['source']==attempt['source']==OLD
      and receipt['physical_calls']==1 and receipt['charged_s']==receipt['scheduled_decisions']==3
      and receipt['registered_research_trials']==receipt['automatic_retries']==0,
      'Original separately frozen3s engineering witness retains source628 and is not relabeled as corrected-source or research evidence')
for n,h in receipt['artifacts'].items():assert sha(blob(DELIVERY,prefix+n))==h
for n,h in attempt['pins'].items():assert sha(blob(OLD,n))==h
originals=read(DELIVERY,prefix+'originals.json');raw=blob(DELIVERY,prefix+'originals.zip')
assert sha(raw)==originals['archive_sha256']
with zipfile.ZipFile(io.BytesIO(raw)) as z:
    assert len(z.namelist())==4 and set(z.namelist())==set(originals['members'])
    members={n:z.read(n) for n in z.namelist()}
assert all(sha(raw)==originals['members'][n] for n,raw in members.items())
run=json.loads(members['run.json']);doc=read(DELIVERY,prefix+'input.json');marker=run['ablation_execution_audit']
check(run['code_identity']['git_commit']==OLD and not run['code_identity']['implementation_has_changes']
      and marker['adapter_sha256']==sha(blob(OLD,'scripts/ablation_planner.py'))
      and marker['adapter_sha256']!=sha(blob(SOURCE,'scripts/ablation_planner.py')),
      'Old native runtime and adapter identity verified against their actual old source, not current corrected source')
native_runtime={n:h for n,h in attempt['pins'].items() if n.startswith('src/aegis_dc/') and n.endswith('.py') or n=='src/patrol_rsi/contracts.py'}
assert run['code_identity']['files']==native_runtime
check(run['inputs']['dispatch_program']==doc['dispatch_program'] and json.loads(members['scenario.json'])==doc['model']
      and marker['actual_program_sha256']==fp(doc['dispatch_program']) and marker['actual_plant_sha256']==fp(doc['model']),
      'Engineering native original retains exact full private executor and actual model inputs')
expected=copy.deepcopy(doc['dispatch_program']);policy=expected['policy_program'];options=policy['options']
removed={c['id'] for c in policy['candidates'] if len(c['task']['crew'])>1}
affected={b['question_id'] for b in options['bindings'] if b['intervention_candidate_id'] in removed}
policy['candidates']=[c for c in policy['candidates'] if c['id'] not in removed]
options['bindings']=[b for b in options['bindings'] if b['question_id'] not in affected]
options['value_model']['question_models']=[q for q in options['value_model']['question_models'] if q['question_id'] not in affected]
for q in options['catalog']['questions']:
    if q['id'] in affected:
        q.update(quantification='UNMODELED',outcome_ids=[])
        q['evidence_gaps'].append('Joint intervention is unavailable to this planner; its incremental value remains unknown.')
tasks={c['task']['id'] for c in policy['candidates']}
policy['intervention_declaration']['bindings']=[b for b in policy['intervention_declaration']['bindings'] if b['task_id'] in tasks]
expected['intervention_program']=copy.deepcopy(policy['intervention_declaration'])
policy['evidence_projection']['report_class_support']=[r for r in policy['evidence_projection']['report_class_support'] if r['question_id'] not in affected]
check(fp(expected)==marker['planner_program_sha256'] and len(marker['actual_catalog_task_ids'])==2
      and len(marker['planner_candidate_ids'])==1 and len(marker['actual_binding_task_ids'])==1
      and marker['planner_binding_task_ids']==[],
      'Independent saved-JSON projection matches original joint mask; actual catalog/permission remain complete')
decisions=run['policy_public_decisions'];work=run['work_records']
check([r['frame']['as_of_s'] for r in decisions]==[0,1,2]
      and all(r['choice']['work_intention'] is None or len(r['choice']['work_intention']['crew'])==1 for r in decisions)
      and any(r['status']=='completed' for r in work)
      and not read(DELIVERY,prefix+'audit.json')['applied_effects'],
      'Saved engineering witness has current clocks, completed actual singleton inspection and zero removed interventions')
dev=read(DELIVERY,PACKAGE+'development/manifest.json');raw=blob(DELIVERY,PACKAGE+'development/originals.zip')
assert sha(raw)==dev['archive_sha256']
with zipfile.ZipFile(io.BytesIO(raw)) as z:
    assert set(z.namelist())==set(dev['members']) and all(sha(z.read(n))==h for n,h in dev['members'].items())
check(len(dev['original_failed_tests'])==2 and dev['successful_public_test_calls']==3
      and dev['registered_ablation_runs']==dev['nonce_reads']==0,
      'Both failed public development logs and all three later successful logs are preserved without new reviewer tests')
progress=read(DELIVERY,'docs/mainline/progress.json')
check(progress['current_ticket']=='35' and progress['research_trials']['ablation']['attempts']==0
      and not git('ls-tree','-rz','--name-only',DELIVERY,'evidence/mainline/research/35-ablation'),
      'Prospective correction precedes every held input, nonce release and registered ablation attempt')
result=dict(status='PASS_PREPARATION_SPEC_0_UNRESOLVED',base=BASE,original_candidate=OLD,
    corrected_source=SOURCE,engineering_data_delivery=DELIVERY,original_finding_status='RESOLVED_BY_PRIVATE_STATIC_NOMINAL_MAPPING',
    findings=[],checks=checks,original_executable_blobs=269,new_scripts=5,
    saved_engineering_source=OLD,saved_engineering_calls=1,saved_engineering_s=3,
    engineering_scope='Original joint-choice interface witness only; not a physical validation of the later private submission mapping.',
    remaining_gates=['Exact32 input-only originals and prospective source lock','Both independent freeze reviews and fresh checkout','Committed execution authorization before32 phase attempts'],
    reviewer_nonce_reads=0,reviewer_seed_derivations=0,reviewer_project_imports=0,reviewer_tests=0,reviewer_selectors=0,reviewer_physical_calls=0)
with (OUT/'receipt.json').open('x',encoding='utf-8') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps({k:v for k,v in result.items() if k!='checks'}))
