# Preserved pre-execution finding at 62856b39

Candidate: `62856b3936a84f48d600258fe6fe0267b593dad8`; base accepted34: `4b5f0b34`.

**Execution boundary finding (identified by root, independently confirmed statically):** under `without_dependency_context`, `MaskedSession.process()` invokes the original `PolicySession.process()` while `planning_scope()` installs the masked nominal knowledge. The original policy then passes that same frame to the actual workforce. `src/aegis_dc/workforce_dispatch.py:135` requires the submitted nominal knowledge to equal the unchanged full executor registry, so an otherwise valid selected task is refused at the private execution boundary. The frozen joint-choice engineering witness does not exercise this dependency-mask mismatch and cannot close it.

The correction must keep the public decision frame masked and map only the private submission's nominal registry back to the original full declared executor identity. Task, evidence, current time and the original typed worker/intervention rules must stay unchanged. This is an interface correction before any registered ablation inputs or outcomes, not permission to weaken the actual executor gate.

The initial dual-view design and validation-only component copy otherwise retain the frozen mask semantics: no private plant read in `planner_view`, no removed edge in planning frames or risk bindings, compute-only public capacities, full actual task/permission catalog retained, and the original risk validator still invoked on a declared local validation copy. Both class and validator overrides are scoped by restoration paths. The pre-existing269 source/config files remain part of the immutable baseline; additive adapter identity must be separately pinned.

This record was produced by source inspection only. No engineering output, held nonce, seed derivation, selector, facility or test call was used. The original joint engineering witness remains separate evidence at its original source and must not be overwritten or represented as executed under a later correction.
