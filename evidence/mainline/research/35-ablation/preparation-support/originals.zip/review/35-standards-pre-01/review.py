"""Static pre-execution closure and saved engineering provenance; no project imports."""
import ast
from hashlib import sha256
import importlib.util
from io import BytesIO
import json
from pathlib import Path
from zipfile import ZipFile

OUT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('saved_review_helpers',OUT.parent/'32-standards-review-01'/'review.py')
r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r)
r.ROOT=Path(r'C:\Users\Donson\.codex\worktrees\mainline35-ablation\Renly')
CANDIDATE='6c98bee2404c8a4694ce334204ca6e2d996f6bae'
CORRECTION='6255fad792218790d3433df42f84d3d495e3b4d8'
ORIGINAL='62856b3936a84f48d600258fe6fe0267b593dad8'
PACKAGE='evidence/mainline/engineering/35-ablation-adapter'
blob=lambda p,rev=CANDIDATE:r.blob(p,rev)
doc=lambda p,rev=CANDIDATE:r.doc(p,rev)
check=r.check
fingerprint=lambda d:sha256(json.dumps(d,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()


def function(path,name):return r.function(path,name,CANDIDATE)


def main():
    base=r.git('rev-parse','4b5f0b34').decode().strip()
    check(r.git('merge-base','--is-ancestor',base,CANDIDATE)==b'','Accepted34 precedes adapter work')
    check(r.git('merge-base','--is-ancestor',ORIGINAL,CORRECTION)==b'' and r.git('merge-base','--is-ancestor',CORRECTION,CANDIDATE)==b'','Original adapter and both corrections remain in immutable history')
    old=doc(r.EXEC_LOCK)['execution_pins'];r.pin_check(CANDIDATE,old,'All original269 code/config Git blobs unchanged')
    check(len(old)==269 and all(sha256((r.ROOT/p).read_bytes()).hexdigest()==h for p,h in old.items()),'Original269 working bytes unchanged')
    additions={'scripts/ablation_planner.py','scripts/ablation_run_evidence.py','scripts/prepare_ablation.py','scripts/registered_ablation.py','scripts/analyze_registered_ablation.py'}
    check(r.code_paths(CANDIDATE)==set(old)|additions,'Only five explicit additive execution scripts',files=274)
    check(all(blob(p,CANDIDATE)==blob(p,CORRECTION) for p in additions),'Data handoff did not alter reviewed correction scripts')
    check(blob(r.PROTOCOL)==blob(r.PROTOCOL,base) and blob(r.LOCK)==blob(r.LOCK,base),'Original protocol and independent phase commitments unchanged')
    plan=doc(r.PROTOCOL);phase=plan['phases']['ablation'];blueprint=doc('configs/full-facility-comparison-held-blueprints-v1.json')
    arms=('full','without_nonfixed_context','without_dependency_context','without_joint_crew_planning')
    budget=dict(attempts=32,simulated_charge_s=320,scheduled_decisions=320)
    check(tuple(phase['arms'])==arms and len(phase['worlds'])==8 and phase['budget']==budget,'Original four masks, eight independent worlds and32-slot budget retained')
    extension=doc('docs/mainline/35-planner-executor-extension.json')
    check(extension['primary_method_changes']==extension['original_runtime_changes']==extension['actual_facility_changes']==extension['mask_selection_changes']==[] and extension['registered_budget']==budget and extension['registered_ablation_attempts_before_extension']==extension['nonce_reads_before_extension']==0,'Explicit prospective extension makes no tuning, physical or budget change')
    check('private_submission_binding' in extension and 'validation-only copy' in extension['dependency_validation'],'Private nominal mapping and component-only validation copy explicitly declared')
    view=ast.unparse(function('scripts/ablation_planner.py','planner_view'))
    view_function=function('scripts/ablation_planner.py','planner_view')
    check('result = deepcopy(program)' in view and 'return result' in view and [a.arg for a in view_function.args.args]==['program','mask'] and not {'simulate_scenario','read','Path','open'}&{n.id for n in ast.walk(view_function) if isinstance(n,ast.Name)},'Planner transformation copies only public program argument; no actual plant read or execution call')
    check("'operator-report'" in view and "['copied_from_record_id']" in view and 'removed |= descendants' in view,'Information mask retains transitive copied-record removal')
    check("{'f12', 'f13', 'f14'}" in view and "question['dependency_edge_ids']" in view and 'compute=value, network=value, storage=value' in view,'Dependency mask removes exactly registered edge bindings and applies compute-only public consequence law')
    check("question.update(quantification='UNMODELED', outcome_ids=[])" in view and 'consequence_bounds' not in view and "len(c['task']['crew']) > 1" in view,'Joint mask preserves unknown bounds and removes only team planning choices')
    scope=function('scripts/ablation_planner.py','planning_scope');scope_text=ast.unparse(scope)
    check('validation_frame = deepcopy(frame)' in scope_text and "validation_frame['nominal_knowledge']['graphs']['functional'].extend(identity_edges)" in scope_text and 'return original_validator(catalog, validation_frame, belief)' in scope_text,'Original catalog validator is invoked on local identity-only copy')
    check('Masked dependency edge reached planning' in scope_text and 'Masked question regained its removed dependency bindings' in scope_text and 'Masked consequence is not compute-only' in scope_text,'Removed knowledge cannot enter the planning validator input or consequence values')
    check(any(isinstance(n,ast.Try) and 'risk_scenarios._catalog_for_frame = original_validator' in '\n'.join(ast.unparse(v) for v in n.finalbody) and 'session.program, session.nominal, session.ledger, session.intervention_program = previous' in '\n'.join(ast.unparse(v) for v in n.finalbody) for n in ast.walk(scope)),'Validator and session declarations restored in finally')
    adapter=function('scripts/ablation_planner.py','session_type');text=ast.unparse(adapter)
    actual=next(n for n in ast.walk(adapter) if isinstance(n,ast.FunctionDef) and n.name=='actual_frame')
    writes=[n for n in ast.walk(actual) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Subscript) and isinstance(t.value,ast.Name) and t.value.id=='value' for t in n.targets)]
    check(len(writes)==1 and ast.unparse(writes[0].targets[0])=="value['nominal_knowledge']" and 'value = deepcopy(frame)' in ast.unparse(actual),'Private submission changes only nominal registry in a detached copy')
    check("workforce.submit(actual_frame(frame, task, 'WORK_SUBMIT'), task)" in text and "interventions.record_issue(actual_frame(frame, task, 'ACTION_ISSUE'), profile, task)" in text,'Unchanged task/profile/evidence/time passed to real executor methods with explicit channels')
    check(text.index('super().__init__(program, duration_s)')<text.index('self.planner_program = planner_view(program, mask)'),'Full actual constructor gates run before any planning mask')
    simulate=function('scripts/ablation_planner.py','simulate_masked')
    check(any(isinstance(n,ast.Try) and 'policy_execution.PolicySession = original' in '\n'.join(ast.unparse(v) for v in n.finalbody) for n in ast.walk(simulate)),'Original PolicySession restored even on run failure')
    checker=ast.unparse(function('scripts/ablation_run_evidence.py','check_ablation_run'))
    check("marker['private_submission_frames']" in checker and "marker.get('private_submission_frames'" not in checker and 'Private issue audit lacks exactly one actual mapping for each declared submission channel' in checker and "for channel in ('WORK_SUBMIT', 'ACTION_ISSUE')" in checker,'Private issue audit field mandatory with exact per-intention channel multiplicity')
    check("row['evidence_sha256'] == fingerprint(decision['frame']['evidence'])" in checker and "row['planner_nominal_sha256'] == fingerprint(planning['nominal_knowledge'])" in checker and "row['actual_nominal_sha256'] == fingerprint(actual['nominal_knowledge'])" in checker,'Private mapping audit binds original clock/task/evidence and both nominal identities')
    check(checker.index("run['inputs']['dispatch_program'] == actual")<checker.index('projected = deepcopy(run)')<checker.index('audit = original_check('),'Exact actual-input validation precedes explicit local planning-check projection')
    check("task == actual_tasks[task['id']]" in checker and 'Native actual execution input differs' in checker,'Projection cannot change issued actual task or native input provenance')
    saved=ast.unparse(function('scripts/ablation_run_evidence.py','save_native'))
    check(saved.index("write(folder / 'originals.json'")<saved.index('audit = check_ablation_run('),'Original native bytes and archive manifest preserved before ablation audit')
    capture=ast.unparse(function('scripts/registered_ablation.py','capture'))
    check(capture.index('journal_append(ledger, start)')<capture.index('result = simulate_masked(program)') and 'authoritative_totals=None' in capture,'Unchanged durable pre-call charge and incomplete-recorder boundary retained')
    begin=ast.unparse(function('scripts/registered_ablation.py','_begin'))
    check("not git('status', '--porcelain')" in begin and 'not folder.exists()' in begin and 'not stage.exists()' in begin and "authorization['execution_lock_sha256'] == digest((ROOT / EXECUTION_LOCK).read_bytes())" in begin,'Actual registered execution still requires clean unique output and separately reviewed exact lock authorization')
    prepare=ast.unparse(function('scripts/prepare_ablation.py','prepare'))
    check("namespace = plan['seed_policy']['namespaces']['ablation']" in prepare and "observation_seed(nonce, plan['id'], namespace, world['id'], 'fixed') >> 64" in prepare and "item = deepcopy(document)" in prepare and "item['ablation_mask'] = arm" in prepare,'Paired independent ablation seeds and actual documents are shared across masks without extra draws')
    progress=doc('docs/mainline/progress.json')
    check(progress['research_trials']['ablation']['attempts']==0 and progress['research_trials']['ablation']['materialized'] is False and not r.tree(CANDIDATE,'evidence/mainline/research/35-ablation'),'No registered held input or ablation outcome delivered at pre-review')
    fixture=PACKAGE+'/fixture-01';receipt=doc(fixture+'/receipt.json');attempt=doc(fixture+'/attempt.json')
    check(receipt['source']==attempt['source']==ORIGINAL and receipt['status']=='PASS_ENGINEERING_VIEW_WITNESS' and receipt['physical_calls']==1 and receipt['charged_s']==3 and receipt['scheduled_decisions']==3 and receipt['registered_research_trials']==receipt['automatic_retries']==0,'Sole saved witness remains engineering only at original628 source')
    fixture_paths=r.tree(CANDIDATE,fixture);r.fetch(CANDIDATE,fixture_paths)
    check({p[len(fixture)+1:] for p in fixture_paths}==set(receipt['artifacts'])|{'receipt.json'} and all(sha256(blob(fixture+'/'+p)).hexdigest()==h for p,h in receipt['artifacts'].items()),'Original engineering durable set and all hashes exact')
    r.pin_check(ORIGINAL,attempt['pins'],'Engineering actual execution pins match original628 Git source')
    original=doc(fixture+'/originals.json');raw=blob(fixture+'/originals.zip')
    check(sha256(raw).hexdigest()==original['archive_sha256'],'Engineering native archive SHA exact')
    with ZipFile(BytesIO(raw)) as z:
        names=z.namelist();members={p:z.read(p) for p in names}
    check(len(names)==len(set(names))==4 and set(names)==set(original['members']) and all(sha256(v).hexdigest()==original['members'][p] for p,v in members.items()),'Four immutable engineering native members match recorded identities')
    run=json.loads(members['run.json']);document=doc(fixture+'/input.json');marker=run['ablation_execution_audit']
    check(run['code_identity']['git_commit']==ORIGINAL and marker['adapter_sha256']==sha256(blob('scripts/ablation_planner.py',ORIGINAL)).hexdigest(),'Old native adapter identity checked against old628 blob, not later correction')
    check(run['inputs']['dispatch_program']==document['dispatch_program'] and json.loads(members['scenario.json'])==document['model'] and marker['actual_program_sha256']==fingerprint(document['dispatch_program']) and marker['actual_plant_sha256']==fingerprint(document['model']),'Engineering full actual input, model and recorded hashes exact')
    audit=doc(fixture+'/audit.json')
    check(len(run['policy_public_decisions'])==3 and len(marker['actual_catalog_task_ids'])==2 and len(marker['planner_candidate_ids'])==1 and len(marker['actual_binding_task_ids'])==1 and marker['planner_binding_task_ids']==[] and audit['applied_effects']==[],'Old witness proves only declared joint-view separation and zero physical interventions')
    development=doc(PACKAGE+'/development/manifest.json');raw=blob(PACKAGE+'/development/originals.zip')
    check(sha256(raw).hexdigest()==development['archive_sha256'],'Preserved public-development archive SHA exact')
    with ZipFile(BytesIO(raw)) as z:
        names=z.namelist();members={p:z.read(p) for p in names}
    check(len(names)==len(set(names))==len(development['members']) and set(names)==set(development['members']) and all(sha256(v).hexdigest()==development['members'][p] for p,v in members.items()),'Every original public-development failure/pass/log/tool member retained exactly')
    failed=development['original_failed_tests']
    check(len(failed)==2 and all('FAILED' in members[p].decode() for p in failed),'Both original failed public tests retained under unchanged names')
    check(development['successful_public_test_calls']==3 and development['public_selectors_per_success']==1 and development['development_physical_calls']==development['registered_ablation_runs']==development['nonce_reads']==0,'Public test selectors and sole engineering physical run are separately accounted, not registered trials')
    report=dict(status='PASS_FOCUSED_PREEXECUTION_STANDARDS_WITH_FROZEN_LIMITS',axis='Standards',candidate=CANDIDATE,corrected_adapter_source=CORRECTION,original_witness_source=ORIGINAL,closed_findings=['Original628 masked dependency frame could not pass unchanged actual executor nominal gate.','Private submission evidence previously optional and without exact intention/channel coverage.'],unresolved_hard_findings=[],advisory_smell_findings=[],checks=r.checks,scope=dict(reviewer_physical_calls=0,reviewer_selector_calls=0,reviewer_nonce_reads=0,seed_derivations=0,tests=0,tracked_edits=0),limits=['Single sequential research process only; scoped module replacements are not a concurrent service API.','628 engineering witness was not rerun and is not claimed as behavior evidence for the later private issue correction.','Registered input preparation and execution still require exact frozen source/input lock, review and separate authorization; this is not an execution receipt or scientific result.'])
    (OUT/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:v for k,v in report.items() if k not in ('checks','limits')},ensure_ascii=False))
    print('Bounded saved/static checks:',len(r.checks))


if __name__=='__main__':main()
