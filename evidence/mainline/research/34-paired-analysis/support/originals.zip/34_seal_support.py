import json,hashlib
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
root=Path(__file__).resolve().parents[1]
folder=root/'evidence/mainline/research/34-paired-analysis/support';folder.mkdir()
files={name:(root/'.work'/name).read_bytes() for name in ['34_saved_analysis.py','render_34_results.py','34_seal_support.py']}
for directory in ['34-analysis-launch-01','34-analysis-launch-02']:
    for path in (root/'.work'/directory).iterdir():
        if path.is_file():files[directory+'/'+path.name]=path.read_bytes()
files['independent33-paired-facts.json']=(root/'.work/33-spec-review-01/independent-paired-facts.json').read_bytes()
with ZipFile(folder/'originals.zip','x',compression=ZIP_DEFLATED) as z:
    for n,b in sorted(files.items()):z.writestr(n,b)
sha=lambda b:hashlib.sha256(b).hexdigest()
manifest=dict(schema='aegisdc-saved-analysis-support-v1',archive_sha256=sha((folder/'originals.zip').read_bytes()),
    members={n:sha(b) for n,b in sorted(files.items())},physical_calls=0,selector_calls=0,registered_attempts=0,
    preserved_entry_failures=1,successful_saved_analysis_calls=1,figure_count=3)
(folder/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(dict(status='SAVED_ANALYSIS_SUPPORT_SEALED',members=len(files))))
