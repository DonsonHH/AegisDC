"""Render every independent confirmation unit from saved and verified facts."""
import csv,hashlib,json,sys
from pathlib import Path
from math import fsum
sys.path.insert(0,'C:/Users/Donson/Documents/ChatGPT/Renly/.work/paper-writing-deps')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
import numpy as np
root=Path(__file__).resolve().parents[1];folder=root/'evidence/mainline/research/34-paired-analysis'
data=json.loads((folder/'results.json').read_bytes());out=folder/'figures';out.mkdir(exist_ok=True)
font=Path('C:/Windows/Fonts/msyh.ttc');font_manager.fontManager.addfont(str(font))
INK,GRAY,TEAL,BLUE,ORANGE='#183449','#536d80','#087f79','#3156a3','#b05021'
plt.rcParams.update({'font.family':font_manager.FontProperties(fname=str(font)).get_name(),
    'axes.spines.top':False,'axes.spines.right':False,'axes.edgecolor':'#b6c7d4','axes.labelcolor':INK,
    'xtick.color':GRAY,'ytick.color':INK,'svg.fonttype':'path','svg.hashsalt':'aegisdc-34'})
arms=['no_human','periodic','fifo','risk_condition_priority_adapted','one_observation_lookahead','evidence_consistent_contingent']
labels=['仅自动保护','到期检查','FIFO','风险／状态优先','一步观察前瞻','证据一致候选']
families=['network-restorable','cooling-masked','misleading-report','protection-or-access']
family_names=['网络可恢复','冷却改善被遮蔽','误导报告','保护／访问限制']
family_label=dict(zip(families,family_names));pairs=data['pairs'];runs={(r['world_id'],r['arm']):r for r in data['runs']}
def save(fig,name):
    fig.savefig(out/(name+'.png'),dpi=170,metadata={'Software':'AegisDC saved confirmation'})
    fig.savefig(out/(name+'.svg'),metadata={'Creator':'AegisDC','Date':None});plt.close(fig)
def heading(fig,title,subtitle):
    fig.text(.05,.94,title,fontsize=21,weight='bold',color=INK)
    fig.text(.05,.885,subtitle,fontsize=10.5,color=GRAY)
fig,ax=plt.subplots(figsize=(12.4,9.2),facecolor='#f7fafc')
fig.subplots_adjust(left=.21,bottom=.10,top=.82,right=.91)
matrix=np.array([[runs[(p['world_id'],arm)]['totals']['service_deficit_time_s'] for arm in arms] for p in pairs])
image=ax.imshow(matrix,vmin=0,vmax=10,cmap='YlGnBu',aspect='auto')
ax.set_xticks(range(6),labels,fontsize=9);ax.set_yticks(range(16),
    [p['world_id'][-2:]+'  '+family_label[p['family']] for p in pairs],fontsize=9)
ax.tick_params(length=0,pad=7)
for i in range(16):
    for j in range(6):ax.text(j,i,f'{matrix[i,j]:.3f}',ha='center',va='center',fontsize=8.6,color='white' if matrix[i,j]>5 else INK)
for y in (3.5,7.5,11.5):ax.axhline(y,color='white',lw=3)
fig.colorbar(image,ax=ax,fraction=.026,pad=.025).set_label('服务缺额（秒，越低越好）',fontsize=9)
heading(fig,'独立确认：16个工况的六方法全量结果','96次原始运行，无失败或重试；同一工况共用设施、外生条件、人员与工具权限。')
fig.text(.05,.035,'每个工况10秒；同一工况的六种方法构成配对比较，独立单位为16个工况。',fontsize=9.5,color=GRAY)
save(fig,'34-confirmation-all-methods')
fig,(a,b)=plt.subplots(1,2,figsize=(12.4,8.2),facecolor='#f7fafc')
fig.subplots_adjust(left=.21,bottom=.13,top=.80,right=.94,wspace=.30)
names=[p['world_id'][-2:]+'  '+family_label[p['family']] for p in pairs]
for axis in (a,b):
    axis.set_yticks(range(16),names if axis is a else []);axis.set_ylim(15.6,-.6)
    axis.axvline(0,color='#91a7b7');axis.grid(axis='x',color='#dfE8ef');axis.set_axisbelow(True);axis.tick_params(length=0,labelsize=9)
for i,p in enumerate(pairs):
    for axis,value in ((a,p['service_delta_s']),(b,p['extra_costs']['paid_person_s'])):
        axis.barh(i,value,height=.57,color=TEAL if (axis is a and value>=0) or (axis is b and value<=0) else ORANGE)
        axis.annotate(f'{value:+.3f}',(value,i),xytext=(4 if value>=0 else -4,0),textcoords='offset points',
            ha='left' if value>=0 else 'right',va='center',fontsize=8)
for axis in (a,b):
    lo,hi=axis.get_xlim();pad=max(hi-lo,.5)*.23;axis.set_xlim(lo-pad,hi+pad)
a.set_xlabel('基线 − 候选缺额（秒）\n正值表示候选改善服务',fontsize=10)
b.set_xlabel('候选 − 基线付费人时（人秒）\n负值表示候选节约人工',fontsize=10)
heading(fig,'主配对：平均改善0.0352秒，平均省0.9688人秒','一步观察前瞻 vs 证据一致候选；保留所有正值、反向值和零差异。')
fig.text(.05,.035,'付费人时=行走+作业+等待；访问检查是等待分项。平均服务改善未达到预定0.25秒门槛。',fontsize=9.5,color=GRAY)
save(fig,'34-confirmation-paired-service-cost')
fig,(a,b)=plt.subplots(1,2,figsize=(12.4,6.0),facecolor='#f7fafc')
fig.subplots_adjust(left=.22,bottom=.20,top=.77,right=.94,wspace=.35)
means=[data['strata'][f]['mean_delta_s'] for f in families]
paid=[fsum(p['extra_costs']['paid_person_s'] for p in pairs if p['family']==f)/4 for f in families]
for axis,values in ((a,means),(b,paid)):
    axis.set_yticks(range(4),family_names if axis is a else []);axis.set_ylim(3.6,-.6)
    axis.axvline(0,color='#91a7b7');axis.grid(axis='x',color='#dfe8ef');axis.set_axisbelow(True)
    for i,v in enumerate(values):
        axis.barh(i,v,height=.5,color=TEAL if (axis is a and v>=0) or (axis is b and v<=0) else ORANGE)
        axis.annotate(f'{v:+.4f}',(v,i),xytext=(5 if v>=0 else -5,0),textcoords='offset points',ha='left' if v>=0 else 'right',va='center',fontsize=10)
    lo,hi=axis.get_xlim();pad=max(hi-lo,.4)*.35;axis.set_xlim(lo-pad,hi+pad);axis.tick_params(length=0)
a.axvline(.25,color=BLUE,ls='--',lw=1.2);a.text(.25,-.73,'总体门槛0.25秒',ha='center',va='bottom',fontsize=9,color=BLUE)
a.set_xlabel('各工况族平均服务改善（秒）',fontsize=10);b.set_xlabel('各工况族平均额外付费人时（人秒）',fontsize=10)
heading(fig,'分层结果：收益方向随工况改变','四类各4个工况，等权；虚线为预定总体门槛，不是各层单独的成功判据。')
fig.text(.05,.055,'去掉“误导报告”一层后，其余12个工况平均改善−0.0625秒。这里报告有限设计均值，不构造总体置信区间。',fontsize=9.3,color=GRAY)
save(fig,'34-confirmation-family-effects')
with (folder/'paired-worlds.csv').open('w',encoding='utf-8',newline='') as file:
    writer=csv.writer(file);writer.writerow(['world_id','family','baseline_deficit_s','candidate_deficit_s','service_gain_s','extra_paid_person_s','extra_travel_person_s','extra_tool_s'])
    for p in pairs:
        writer.writerow([p['world_id'],p['family'],runs[(p['world_id'],arms[4])]['totals']['service_deficit_time_s'],
            runs[(p['world_id'],arms[5])]['totals']['service_deficit_time_s'],p['service_delta_s'],
            *[p['extra_costs'][k] for k in ('paid_person_s','travel_person_s','tool_occupation_s')]])
method_summary=[]
with (folder/'method-summary.csv').open('w',encoding='utf-8',newline='') as file:
    writer=csv.writer(file);writer.writerow(['method','worlds','mean_deficit_s','mean_paid_person_s','mean_travel_person_s','mean_tool_s'])
    for arm in arms:
        totals=[runs[(p['world_id'],arm)]['totals'] for p in pairs]
        row=[arm,16,fsum(t['service_deficit_time_s'] for t in totals)/16,
            fsum(t['worker_travel_person_s']+t['worker_work_person_s']+t['worker_wait_person_s'] for t in totals)/16,
            fsum(t['worker_travel_person_s'] for t in totals)/16,fsum(t['tool_occupation_tool_s'] for t in totals)/16]
        writer.writerow(row);method_summary.append(row)
sha=lambda b:hashlib.sha256(b).hexdigest()
manifest=dict(scope='Verified saved confirmation facts only; no new facility, selector or seed calls.',
    input_sha256=sha((folder/'results.json').read_bytes()),facts_sha256=sha((folder/'verified-facts.json').read_bytes()),
    authoring_sha256=sha(Path(__file__).read_bytes()),font_sha256=sha(font.read_bytes()),matplotlib=matplotlib.__version__,
    artifacts={p.name:sha(p.read_bytes()) for p in out.iterdir() if p.name!='figure-source.json'})
(out/'figure-source.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(dict(status='ALL16_CONFIRMATION_UNITS_RENDERED',figures=3,method_summary=method_summary)))
