import json,subprocess,sys,os
from pathlib import Path
from datetime import datetime,timezone
root=Path(__file__).resolve().parents[1]
source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
first=root/'.work/34-analysis-launch-01';first.mkdir()
failure=dict(status='OBSERVER_RECORDED_ENTRY_FAILURE',recorded_utc=datetime.now(timezone.utc).isoformat(),
    source=source,command=[sys.executable,'-B','-X','utf8','scripts/analyze_registered_confirmation.py',
    'evidence/mainline/research/33-confirmation/capture-01','--output','evidence/mainline/research/34-paired-analysis'],
    error_type='ModuleNotFoundError',error="No module named 'aegis_dc'",returncode=1,
    classification='SAVED_ANALYSIS_ENTRY_NOT_RESEARCH_TRIAL',physical_calls=0,selector_calls=0,
    correction='Explicit PYTHONPATH=src for saved validation imports; frozen source/input/outcomes unchanged.')
(first/'receipt.json').write_text(json.dumps(failure,indent=2)+'\n',encoding='utf-8',newline='\n')
second=root/'.work/34-analysis-launch-02';second.mkdir()
cmd=failure['command'];env=os.environ.copy();env['PYTHONPATH']=str(root/'src')
(second/'attempt.json').write_text(json.dumps(dict(command=cmd,source=source,PYTHONPATH=str(root/'src'),
    started_utc=datetime.now(timezone.utc).isoformat(),physical_calls=0,selector_calls=0),indent=2)+'\n',encoding='utf-8',newline='\n')
with (second/'stdio.log').open('xb') as out:run=subprocess.run(cmd,cwd=root,env=env,stdout=out,stderr=subprocess.STDOUT)
(second/'terminal.json').write_text(json.dumps(dict(returncode=run.returncode,
    finished_utc=datetime.now(timezone.utc).isoformat(),physical_calls=0,selector_calls=0),indent=2)+'\n',encoding='utf-8',newline='\n')
print((second/'stdio.log').read_text(encoding='utf-8'))
raise SystemExit(run.returncode)
