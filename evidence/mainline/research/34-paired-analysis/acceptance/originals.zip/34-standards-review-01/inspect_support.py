from io import BytesIO
import json
from pathlib import Path
from zipfile import ZipFile

root=Path(r'C:\Users\Donson\Documents\ChatGPT\Renly')
folder=root/'evidence/mainline/research/34-paired-analysis/support'
with ZipFile(BytesIO((folder/'originals.zip').read_bytes())) as z:
    for name in ('34-analysis-launch-01/receipt.json','34-analysis-launch-02/attempt.json','34-analysis-launch-02/terminal.json','34_saved_analysis.py','34_seal_support.py','render_34_results.py'):
        print('\nFILE:',name)
        print(z.read(name).decode())
    fact=json.loads(z.read('independent33-paired-facts.json'))
    print('Independent33 fact type/keys:',type(fact).__name__,list(fact)[:12])
    if type(fact) is dict:
        print('Independent33 metadata:',{k:v for k,v in fact.items() if k not in ('pairs','runs','opportunities','worlds')})
