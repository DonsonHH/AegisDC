"""Bounded Standards audit of saved ticket34 analysis, figures and source closure."""
import csv
from hashlib import sha256
import importlib.util
from io import BytesIO,StringIO
import json
from math import fsum,isclose
from pathlib import Path
from zipfile import ZipFile

OUT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('immutable_review_helpers',OUT.parent/'32-standards-review-01'/'review.py')
r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r)
r.ROOT=Path(r'C:\Users\Donson\Documents\ChatGPT\Renly')
CANDIDATE='321565686cbc2b168ef86a89e2ff5378ec6a8eb5'
SOURCE='fc747fb1a579e678c5e88753d110d4875b4899b2'
DELIVERY='bcc3c42cdd6842a1d7ff3fdbc4e89e756f29ffdc'
PACKAGE='evidence/mainline/research/34-paired-analysis'
CAPTURE='evidence/mainline/research/33-confirmation/capture-01'
blob=lambda p,rev=CANDIDATE:r.blob(p,rev)
doc=lambda p,rev=CANDIDATE:r.doc(p,rev)
check=r.check


def main():
    paths=r.tree(CANDIDATE,PACKAGE);r.fetch(CANDIDATE,paths)
    check(len(paths)==14,'Exactly14 declared analysis delivery files',files=len(paths))
    check(all((r.ROOT/p).read_bytes()==blob(p) for p in paths),'All analysis working bytes equal fixed committed delivery')
    check(r.git('rev-parse',DELIVERY+':'+CAPTURE)==r.git('rev-parse',CANDIDATE+':'+CAPTURE),'Original96-run capture Git subtree unchanged; no native archive repetition')
    for subtree in (r.PREP,r.OLD):
        check(r.git('rev-parse',SOURCE+':'+subtree)==r.git('rev-parse',CANDIDATE+':'+subtree),'Original input subtree unchanged '+subtree.rsplit('/',1)[-1])
    execution=doc(r.EXEC_LOCK);code=execution['execution_pins']
    check(set(code)==r.code_paths(SOURCE)==r.code_paths(CANDIDATE) and len(code)==269,'Full269 executable membership unchanged')
    r.pin_check(CANDIDATE,code,'Original269 execution Git blobs unchanged')
    check(blob(r.PROTOCOL)==blob(r.PROTOCOL,SOURCE) and blob(r.LOCK)==blob(r.LOCK,SOURCE),'Protocol and phase commitments unchanged')
    plan=doc(r.PROTOCOL);phase=plan['phases']['confirmation'];worlds=phase['worlds'];arms=phase['arms']
    data=doc(PACKAGE+'/results.json');facts=doc(PACKAGE+'/verified-facts.json')
    check(data['execution_commit']==SOURCE and data['source_verification']=='PASS_EXACT_SAVED_NATIVE_INPUTS_AND_CODE','Analysis explicitly binds actual immutable execution source')
    check(data['planned_denominator']==data['completed_primary_pairs']==len(worlds)==16 and len(data['pairs'])==len(facts['pairs'])==16,'Independent denominator is16 worlds and16 primary pairs')
    check(data['ledger_totals']==doc(CAPTURE+'/receipt.json')['total'] and data['batch_status']=='PASS','Analysis retains accepted complete lifecycle and exact budget')
    check(len(data['runs'])==96 and {(x['world_id'],x['arm']) for x in data['runs']}=={(w['id'],a) for w in worlds for a in arms},'All six methods retained for all16 matched worlds')
    rows={(x['world_id'],x['arm']):x for x in data['runs']}
    pairs={p['world_id']:p for p in data['pairs']};fact_rows={p['world_id']:p for p in facts['pairs']}
    check(all(x['status']=='COMPLETED' for x in rows.values()),'No failed or missing run converted to complete observations')
    support=doc(PACKAGE+'/support/manifest.json');raw=blob(PACKAGE+'/support/originals.zip')
    check(sha256(raw).hexdigest()==support['archive_sha256'],'Support archive exact SHA')
    with ZipFile(BytesIO(raw)) as z:
        names=z.namelist();members={p:z.read(p) for p in names}
    check(len(names)==len(set(names))==len(support['members'])==8 and set(names)==set(support['members']),'Eight declared unique support members, no cache substitutes')
    check(all(sha256(raw).hexdigest()==support['members'][p] for p,raw in members.items()),'Every support member exact SHA')
    failed=json.loads(members['34-analysis-launch-01/receipt.json'])
    attempt=json.loads(members['34-analysis-launch-02/attempt.json'])
    terminal=json.loads(members['34-analysis-launch-02/terminal.json'])
    check(failed['status']=='OBSERVER_RECORDED_ENTRY_FAILURE' and failed['classification']=='SAVED_ANALYSIS_ENTRY_NOT_RESEARCH_TRIAL' and failed['returncode']!=0 and failed['error_type']=='ModuleNotFoundError','Original entry refusal honestly retained as observer-recorded failure')
    check(failed['physical_calls']==failed['selector_calls']==attempt['physical_calls']==attempt['selector_calls']==terminal['physical_calls']==terminal['selector_calls']==support['registered_attempts']==0 and terminal['returncode']==0,'Saved entry retry is not a physical trial or added budget charge')
    check(support['preserved_entry_failures']==support['successful_saved_analysis_calls']==1,'One failed entry and one successful saved-only analysis recorded separately')
    independent=json.loads(members['independent33-paired-facts.json'])
    check(independent['source']==SOURCE and independent['data_delivery']==DELIVERY and independent['planned_denominator']==16 and independent['primary_pair']==plan['comparison']['primary'],'Previous independent33 facts bind same source, data and prespecified pair')
    check(independent['mean_service_delta_s']==data['mean_service_delta_s'] and independent['stratum_means']=={f:v['mean_delta_s'] for f,v in data['strata'].items()} and independent['identified_worlds']==data['identified_world_ids'],'Analysis matches previous independent paired/family/opportunity facts')
    paired=list(csv.DictReader(StringIO(blob(PACKAGE+'/paired-worlds.csv').decode())))
    methods=list(csv.DictReader(StringIO(blob(PACKAGE+'/method-summary.csv').decode())))
    check(len(paired)==len({p['world_id'] for p in paired})==16 and {p['world_id'] for p in paired}==set(pairs),'Paired CSV retains every independent world exactly once')
    for p in paired:
        name=p['world_id'];pair=pairs[name];f=fact_rows[name]
        baseline=rows[(name,arms[4])]['totals'];candidate=rows[(name,arms[5])]['totals']
        check(f['baseline']==baseline and f['candidate']==candidate and p['family']==pair['family'] and float(p['baseline_deficit_s'])==baseline['service_deficit_time_s'] and float(p['candidate_deficit_s'])==candidate['service_deficit_time_s'] and float(p['service_gain_s'])==pair['service_delta_s'] and all(float(p[c])==pair['extra_costs'][k] for c,k in [('extra_paid_person_s','paid_person_s'),('extra_travel_person_s','travel_person_s'),('extra_tool_s','tool_occupation_s')]),'CSV and frozen facts preserve exact paired result '+name)
    check(len(methods)==6 and [m['method'] for m in methods]==arms and all(int(m['worlds'])==16 for m in methods),'Method CSV retains all six methods with16-world denominator')
    for method in methods:
        totals=[row['totals'] for (world,arm),row in rows.items() if arm==method['method']]
        expected=[fsum(t['service_deficit_time_s'] for t in totals)/16,fsum(t['worker_travel_person_s']+t['worker_work_person_s']+t['worker_wait_person_s'] for t in totals)/16,fsum(t['worker_travel_person_s'] for t in totals)/16,fsum(t['tool_occupation_tool_s'] for t in totals)/16]
        check(all(float(method[k])==v for k,v in zip(('mean_deficit_s','mean_paid_person_s','mean_travel_person_s','mean_tool_s'),expected)),'Descriptive method summary preserves all saved units '+method['method'])
    gain=data['mean_service_delta_s'];costs=data['mean_extra_paid_person_s'],data['mean_extra_travel_person_s'],data['mean_extra_tool_occupation_s']
    check(data['status']=='NO_PRACTICAL_GAIN' and gain==0.03515625 and gain<plan['comparison']['minimum_worthwhile_gain_s']==.25 and costs==(-.96875,-.25,-.609375),'Bounded no-practical-gain claim uses frozen threshold and separate SI costs')
    check(data['mean_service_delta_bounds_s']==[gain,gain] and all(p['service_delta_bounds_s']==[p['service_delta_s']]*2 for p in pairs.values()),'Complete outcomes collapse missing-data bounds; no population confidence interval constructed')
    check(sum(p['service_delta_s']<0 for p in pairs.values())==2 and sum(p['service_delta_s']==0 for p in pairs.values())==10 and sum(p['service_delta_s']>0 for p in pairs.values())==4,'All negative, zero and positive paired rows retained',negative=2,zero=10,positive=4)
    figure=doc(PACKAGE+'/figures/figure-source.json')
    check(figure['input_sha256']==sha256(blob(PACKAGE+'/results.json')).hexdigest() and figure['facts_sha256']==sha256(blob(PACKAGE+'/verified-facts.json')).hexdigest(),'Figures bind exact analyzed results and verified facts')
    check(figure['authoring_sha256']==sha256(members['render_34_results.py']).hexdigest(),'Figure authoring source preserved and hashed in support archive')
    check(len(figure['artifacts'])==6 and all(sha256(blob(PACKAGE+'/figures/'+p)).hexdigest()==h for p,h in figure['artifacts'].items()),'All three PNG/SVG figure pairs match provenance hashes')
    check(figure['font_sha256']==sha256(Path('C:/Windows/Fonts/msyh.ttc').read_bytes()).hexdigest(),'Declared render font bytes available and match preserved identity')
    readme=blob(PACKAGE+'/README.md').decode()
    check(all(text in readme for text in ('NO_PRACTICAL_GAIN','独立比较单位是16个工况','不能把96条方法轨迹','不是总体置信区间','零违规不等于方法有效','累计132次','没有追加设施、策略、模型或训练调用')),'Reading entry preserves units, negative conclusion and synthetic scope')
    attrs=blob('.gitattributes').decode()
    check('evidence/mainline/research/34-paired-analysis/*.csv -text whitespace=blank-at-eol,blank-at-eof,space-before-tab,cr-at-eol' in attrs and r.git('diff','--name-only',CANDIDATE+'^',CANDIDATE).decode().splitlines()==['.gitattributes'],'CSV correction is declared format metadata only')
    for p in ('paired-worlds.csv','method-summary.csv'):
        raw=blob(PACKAGE+'/'+p)
        check(raw==blob(PACKAGE+'/'+p,CANDIDATE+'^') and b'\r\n' in raw and raw.replace(b'\r\n',b'').find(b'\r')<0,'Original CSV numeric and CRLF bytes preserved '+p)
    check(doc('docs/mainline/progress.json')['research_trials']['attempts']==132,'Registered research count stays132; analysis is uncharged')
    result=dict(status='PASS_SAVED_STANDARDS_REVIEW',axis='Standards',candidate=CANDIDATE,execution_source=SOURCE,original_data_delivery=DELIVERY,hard_findings=[],advisory_smell_findings=[],checks=r.checks,figures_actually_viewed=['34-confirmation-paired-service-cost.png','34-confirmation-family-effects.png','34-confirmation-all-methods.png'],scope=dict(physical_calls=0,selector_calls=0,nonce_reads=0,seed_derivations=0,tests=0,tracked_edits=0,native_archives_reaudited=0),acceptance_note='Root will archive retained raw format-check logs in a separate immutable acceptance support packet before acceptance; this report does not relabel those logs as already delivered.')
    (OUT/'report.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:v for k,v in result.items() if k!='checks'},ensure_ascii=False))
    print('Bounded checks:',len(r.checks))


if __name__=='__main__':main()
