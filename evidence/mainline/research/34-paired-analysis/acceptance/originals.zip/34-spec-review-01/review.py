"""Bounded ticket34 saved arithmetic/provenance review; no project imports or native rerun."""
import csv
import hashlib
import io
import json
import math
import subprocess
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path

REPO=Path('C:/Users/Donson/Documents/ChatGPT/Renly')
OUT=Path(__file__).resolve().parent
REF='321565686cbc2b168ef86a89e2ff5378ec6a8eb5'
BASE='483f4bb8'
ROOT='evidence/mainline/research/34-paired-analysis/'
checks=[]
def git(*args):return subprocess.check_output(['git',*args],cwd=REPO)
def blob(path):return git('cat-file','blob',REF+':'+path)
def read(path):return json.loads(blob(path))
def sha(raw):return hashlib.sha256(raw).hexdigest()
def close(a,b):return math.isclose(a,b,rel_tol=0,abs_tol=1e-8)
def check(ok,message):
    if not ok:raise AssertionError(message)
    checks.append(message)

r=read(ROOT+'results.json');facts=read(ROOT+'verified-facts.json')
independent=json.loads((REPO/'.work/33-spec-review-01/independent-paired-facts.json').read_bytes())
previous=json.loads((REPO/'.work/33-spec-review-01/saved-receipt.json').read_bytes())
plan=read('docs/mainline/30-comparison-protocol-v1.json')
check(git('diff','--name-only',BASE,REF,'src','scripts','configs','docs/mainline/30-comparison-protocol-v1.json')==b'',
      'Analysis changes no frozen runtime, methods, inputs or protocol')
check(r['execution_commit']==previous['source']=='fc747fb1a579e678c5e88753d110d4875b4899b2'
      and independent['data_delivery']=='bcc3c42cdd6842a1d7ff3fdbc4e89e756f29ffdc',
      'Analysis binds the independently reviewed execution and original data delivery')
worlds={w['id']:w for w in plan['phases']['confirmation']['worlds']}
pairs={p['world_id']:p for p in r['pairs']};old={p['world_id']:p for p in independent['pairs']}
check(len(pairs)==r['planned_denominator']==r['completed_primary_pairs']==16 and set(pairs)==set(worlds)==set(old),
      'Fixed denominator is16 worlds, four per family;96 method runs are not independent units')
for name,p in pairs.items():
    assert close(p['service_delta_s'],old[name]['service_delta_s'])
    assert p['service_delta_bounds_s']==[p['service_delta_s']]*2
    assert close(p['extra_costs']['paid_person_s'],old[name]['extra']['paid_person_s'])
    assert close(p['extra_costs']['travel_person_s'],old[name]['extra']['worker_travel_person_s'])
    assert close(p['extra_costs']['tool_occupation_s'],old[name]['extra']['tool_occupation_tool_s'])
check(True,'Every primary service/cost pair matches the independent33 saved-native arithmetic')
fact_rows={row['world_id']:row for row in facts['pairs']}
check(set(fact_rows)==set(worlds) and len(facts['pairs'])==16,
      'Frozen arithmetic facts retain all16 registered primary pairs')
for name,row in fact_rows.items():
    assert row['hard_violations']==[]
    assert close(row['baseline']['service_deficit_time_s']-row['candidate']['service_deficit_time_s'],pairs[name]['service_delta_s'])
    assert row['identified_first_difference']==(name in independent['identified_worlds'])
gain=math.fsum(p['service_delta_s'] for p in pairs.values())/16
check(close(gain,r['mean_service_delta_s']) and gain==.03515625
      and r['mean_service_delta_bounds_s']==[gain,gain],
      'Complete-outcome bounds collapse to the exact finite-design mean, not a population confidence interval')
costs={k:math.fsum(p['extra_costs'][k] for p in pairs.values())/16 for k in ['paid_person_s','travel_person_s','tool_occupation_s']}
for key,value in costs.items():
    assert close(value,r['mean_extra_'+key])
    assert value<=plan['comparison']['cost_bounds']['extra_mean_'+key]+1e-8
check(costs==dict(paid_person_s=-.96875,travel_person_s=-.25,tool_occupation_s=-.609375),
      'Paid/travel/tool deltas and their separate frozen cost bounds are correct')
families={w['family'] for w in worlds.values()}
for family in families:
    members=[p for p in pairs.values() if p['family']==family]
    assert len(members)==4
    mean=math.fsum(p['service_delta_s'] for p in members)/4
    lofo=math.fsum(p['service_delta_s'] for p in pairs.values() if p['family']!=family)/12
    assert mean==r['strata'][family]['mean_delta_s']==independent['stratum_means'][family]
    assert lofo==r['leave_one_family_out_mean_delta_s'][family]
check(r['leave_one_family_out_mean_delta_s']['misleading-report']==-.0625,
      'All four family means and leave-one-family-out means retain adverse and zero results')
check(r['identified_world_ids']==independent['identified_worlds'] and len(r['identified_world_ids'])==12
      and len({worlds[w]['family'] for w in r['identified_world_ids']})==3
      and not r['hard_violations'] and not any(r['diagnostic_flags'].values()),
      'Identification and independent safety/missing/cost flags are retained without treating zero violations as effectiveness')
check(r['status']=='NO_PRACTICAL_GAIN' and -.25<gain<plan['comparison']['minimum_worthwhile_gain_s']==.25,
      'Registered category is correct under the unchanged ordered outcome rules')
runs={(row['world_id'],row['arm']):row for row in r['runs']}
arms=plan['phases']['confirmation']['arms']
check(set(runs)=={(name,arm) for name in worlds for arm in arms}
      and all(row['status']=='COMPLETED' for row in runs.values()),
      'All96 descriptive outcomes appear once across six methods and16 worlds')
for name,row in fact_rows.items():
    assert row['baseline']==runs[(name,'one_observation_lookahead')]['totals']
    assert row['candidate']==runs[(name,'evidence_consistent_contingent')]['totals']
summaries={}
for arm in arms:
    rows=[runs[(name,arm)]['totals'] for name in worlds]
    for row in rows:assert close(row['paid_person_s'],math.fsum(row[k] for k in ['worker_travel_person_s','worker_work_person_s','worker_wait_person_s']))
    summaries[arm]=dict(mean_deficit_s=math.fsum(row['service_deficit_time_s'] for row in rows)/16,
        mean_paid_person_s=math.fsum(row['paid_person_s'] for row in rows)/16,
        mean_travel_person_s=math.fsum(row['worker_travel_person_s'] for row in rows)/16,
        mean_tool_s=math.fsum(row['tool_occupation_tool_s'] for row in rows)/16)
check(summaries['no_human']['mean_deficit_s']==summaries['evidence_consistent_contingent']['mean_deficit_s']==3.8125
      and summaries['no_human']['mean_paid_person_s']==0
      and summaries['evidence_consistent_contingent']['mean_paid_person_s']==1.40625,
      'No-human ties candidate mean service while candidate consumes1.40625 person-s; secondary comparison stays descriptive')
offsets={family:math.fsum(runs[(name,'no_human')]['totals']['service_deficit_time_s']-
    runs[(name,'evidence_consistent_contingent')]['totals']['service_deficit_time_s']
    for name,w in worlds.items() if w['family']==family)/4 for family in families}
check(offsets['network-restorable']==1.078125 and offsets['misleading-report']==-1.078125
      and offsets['cooling-masked']==offsets['protection-or-access']==0,
      'Opposite family offsets, rather than uniform method equivalence, explain the no-human mean tie')
for filename,expected_rows in [('method-summary.csv',6),('paired-worlds.csv',16)]:
    raw=blob(ROOT+filename);rest=raw.replace(b'\r\n',b'')
    assert b'\r' not in rest and b'\n' not in rest
    parsed=list(csv.DictReader(io.StringIO(raw.decode(),newline='')))
    assert len(parsed)==expected_rows
    if filename=='method-summary.csv':
        assert {row['method'] for row in parsed}==set(arms)
        for row in parsed:
            assert int(row['worlds'])==16
            for key,value in summaries[row['method']].items():assert close(float(row[key]),value)
    else:
        assert {row['world_id'] for row in parsed}==set(worlds)
        for row in parsed:
            p=pairs[row['world_id']]
            assert row['family']==p['family'] and close(float(row['service_gain_s']),p['service_delta_s'])
            assert close(float(row['baseline_deficit_s']),fact_rows[row['world_id']]['baseline']['service_deficit_time_s'])
            assert close(float(row['candidate_deficit_s']),fact_rows[row['world_id']]['candidate']['service_deficit_time_s'])
            for column,key in [('extra_paid_person_s','paid_person_s'),('extra_travel_person_s','travel_person_s'),('extra_tool_s','tool_occupation_s')]:
                assert close(float(row[column]),p['extra_costs'][key])
check(True,'Both CSVs preserve declared exact CRLF bytes and reproduce every numeric method/pair row')
support=read(ROOT+'support/manifest.json');raw=blob(ROOT+'support/originals.zip')
assert sha(raw)==support['archive_sha256']
with zipfile.ZipFile(io.BytesIO(raw)) as archive:
    assert set(archive.namelist())==set(support['members']) and len(archive.namelist())==len(support['members'])
    members={n:archive.read(n) for n in archive.namelist()}
    assert all(sha(raw)==support['members'][name] for name,raw in members.items())
    assert json.loads(members['independent33-paired-facts.json'])==independent
    failure=json.loads(members['34-analysis-launch-01/receipt.json'])
    success=json.loads(members['34-analysis-launch-02/terminal.json'])
    assert failure['status']=='OBSERVER_RECORDED_ENTRY_FAILURE' and failure['physical_calls']==failure['selector_calls']==0
    assert failure['error_type']=='ModuleNotFoundError' and success['returncode']==0
check(True,'Support archive preserves the observer-recorded import failure, successful saved-only entry, independent facts and pinned tooling')
fig=read(ROOT+'figures/figure-source.json')
check(fig['input_sha256']==sha(blob(ROOT+'results.json')) and fig['facts_sha256']==sha(blob(ROOT+'verified-facts.json'))
      and fig['authoring_sha256']==sha(members['render_34_results.py']),
      'Figure provenance binds exact results, facts and archived authoring source')
assert len(fig['artifacts'])==6
for name,h in fig['artifacts'].items():
    raw=blob(ROOT+'figures/'+name);assert sha(raw)==h
    if name.endswith('.svg'):assert ET.fromstring(raw).tag.endswith('svg')
    else:assert raw.startswith(b'\x89PNG\r\n\x1a\n')
check(True,'All three PNG and matching SVG bytes match provenance; SVG XML is valid')
report=blob(ROOT+'README.md').decode()
check(all(s in report for s in ['NO_PRACTICAL_GAIN','不能把96','候选的平均服务缺额与“仅自动保护”相同','不是总体置信区间','现场校准','原错误另存']),
      'Narrative retains the negative category, full denominator, no-human tie, failures and finite/synthetic scope')
result=dict(status='PASS_0_UNRESOLVED_SPEC',candidate=REF,base=BASE,execution_source=previous['source'],
    data_delivery=previous['delivery'],findings=[],checks=checks,category=r['status'],denominator=16,
    mean_service_delta_s=gain,mean_extra_costs=costs,method_summaries=summaries,no_human_family_offsets=offsets,
    viewed_pngs=3,verified_svgs=3,nonce_reads=0,seed_derivations=0,project_imports=0,test_runs=0,
    physical_calls=0,selector_calls=0,native_reruns=0)
with (OUT/'receipt.json').open('x',encoding='utf-8') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['checks','method_summaries']}))
