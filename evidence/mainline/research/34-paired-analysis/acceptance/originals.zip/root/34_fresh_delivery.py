import argparse,hashlib,json,subprocess,sys
from pathlib import Path
from zipfile import ZipFile
p=argparse.ArgumentParser();p.add_argument('checkout',type=Path);p.add_argument('--delivery',required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
root=a.checkout.resolve();prefix='evidence/mainline/research/34-paired-analysis'
def git(*v):return subprocess.check_output(['git',*v],cwd=root)
def sha(b):return hashlib.sha256(b).hexdigest()
read=lambda p:json.loads(p.read_bytes())
assert git('rev-parse','HEAD').decode().strip()==a.delivery and not git('status','--porcelain')
names={p.relative_to(root).as_posix() for p in (root/prefix).rglob('*') if p.is_file()}
assert names==set(git('ls-tree','-rz','--name-only',a.delivery,prefix).decode().strip('\0').split('\0'))
for name in names:assert git('cat-file','blob',a.delivery+':'+name)==(root/name).read_bytes()
support=read(root/prefix/'support/manifest.json')
assert sha((root/prefix/'support/originals.zip').read_bytes())==support['archive_sha256']
with ZipFile(root/prefix/'support/originals.zip') as z:
    assert len(z.namelist())==len(support['members']) and set(z.namelist())==set(support['members'])
    assert all(sha(z.read(n))==h for n,h in support['members'].items())
    renderer=z.read('render_34_results.py')
figures=read(root/prefix/'figures/figure-source.json')
assert figures['authoring_sha256']==sha(renderer) and figures['input_sha256']==sha((root/prefix/'results.json').read_bytes())
assert figures['facts_sha256']==sha((root/prefix/'verified-facts.json').read_bytes())
assert all(sha((root/prefix/'figures'/n).read_bytes())==h for n,h in figures['artifacts'].items())
sys.path.insert(0,str(root/'scripts'))
from summarize_comparison_facts import summarize
expected=summarize(read(root/'docs/mainline/30-comparison-protocol-v1.json'),read(root/prefix/'verified-facts.json'))
result=read(root/prefix/'results.json')
for k,v in expected.items():
    if k not in ('scope','source_verification'):assert result[k]==v,k
value=dict(status='PASS_EXACT_FRESH_PRIMARY_ANALYSIS',delivery=a.delivery,declared_files=len(names),
    figures=3,native_calls=0,selector_calls=0,seed_reads=0,planned_pairs=16,
    result=result['status'],mean_service_delta_s=result['mean_service_delta_s'])
with a.output.open('x',encoding='utf-8',newline='\n') as f:json.dump(value,f,indent=2);f.write('\n')
print(json.dumps(value))
