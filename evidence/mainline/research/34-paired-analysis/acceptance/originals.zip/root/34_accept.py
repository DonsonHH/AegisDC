import hashlib,json,subprocess
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
root=Path(__file__).resolve().parents[1];read=lambda p:json.loads(p.read_bytes());sha=lambda b:hashlib.sha256(b).hexdigest()
def write(p,obj):p.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
spec=read(root/'.work/34-spec-review-01/receipt.json');standard=read(root/'.work/34-standards-review-01/report.json')
assert spec['status']=='PASS_0_UNRESOLVED_SPEC' and spec['findings']==standard['hard_findings']==standard['advisory_smell_findings']==[]
result=read(root/'evidence/mainline/research/34-paired-analysis/results.json')
assert result['status']=='NO_PRACTICAL_GAIN' and result['mean_service_delta_s']==.03515625
files={}
for name in ('34-spec-review-01','34-standards-review-01'):
    assert (root/'.work'/name/'manifest.json').is_file()
    for p in (root/'.work'/name).iterdir():
        if p.is_file():files[name+'/'+p.name]=p.read_bytes()
for name in ('34-fresh-proof-01.json','34_fresh_delivery.py','34-csv-format-red-01.log','34-csv-format-green-01.log','34_accept.py'):
    files['root/'+name]=(root/'.work'/name).read_bytes()
out=root/'evidence/mainline/research/34-paired-analysis/acceptance';out.mkdir()
with ZipFile(out/'originals.zip','x',compression=ZIP_DEFLATED) as z:
    for n,b in sorted(files.items()):z.writestr(n,b)
write(out/'manifest.json',dict(schema='aegisdc-reviewed-primary-analysis-v1',archive_sha256=sha((out/'originals.zip').read_bytes()),
    members={n:sha(b) for n,b in sorted(files.items())},physical_calls=0,selector_calls=0,seed_reads=0,unresolved_findings=0,
    format_correction='Classified exact CRLF generated CSV; original numeric bytes unchanged.'))
write(root/'docs/mainline/evidence/34-root-delivery.json',read(root/'.work/34-fresh-proof-01.json'))
write(root/'docs/mainline/evidence/34-root.json',dict(status='ACCEPTED',ticket='34',milestone='M6',date='2026-11-08',
    actual_root_source='321565686cbc2b168ef86a89e2ff5378ec6a8eb5',
    execution_source=result['execution_commit'],data_delivery='bcc3c42cdd6842a1d7ff3fdbc4e89e756f29ffdc',
    result=result['status'],planned_pairs=16,complete_pairs=16,confirmation_runs=96,
    mean_service_delta_s=result['mean_service_delta_s'],mean_extra_paid_person_s=result['mean_extra_paid_person_s'],
    mean_extra_travel_person_s=result['mean_extra_travel_person_s'],mean_extra_tool_s=result['mean_extra_tool_occupation_s'],
    identified_worlds=12,identified_families=3,observed_hard_violations=0,figures=3,
    interpretation='Frozen finite-design result; practical service gain not established. No-human mean ties candidate.',
    reviews=dict(spec='PASS_0_UNRESOLVED',standards='PASS_0_UNRESOLVED'),
    fresh_proof='docs/mainline/evidence/34-root-delivery.json',originals=out.relative_to(root).as_posix()+'/manifest.json',
    new_registered_attempts=0,new_facility_calls=0,new_selector_calls=0,field_calibration='PENDING',next_ticket='35'))
write(root/'docs/mainline/evidence/M5.json',dict(status='ACCEPTED',milestone='M5',date='2026-11-08',
    scope='Frozen finite synthetic comparison: registered development, independent input/source freeze, original confirmation and paired facts.',
    required_acceptances=[f'docs/mainline/evidence/{i}-root.json' for i in range(29,35)],
    development_runs=36,confirmation_runs=96,confirmation_independent_units=16,
    primary_result='NO_PRACTICAL_GAIN',mean_service_delta_s=.03515625,field_calibration='PENDING',
    remaining='35 mechanism ablations,36 robustness,37 baseline scope report,38–42 conditional increments and final audit.'))
p=root/'docs/mainline/progress.json';progress=read(p);assert progress['current_ticket']=='34'
progress['current_ticket']='35';progress['milestones'][5].update(status='accepted',progress_scope='Finite independent comparison accepted through34; practical gain not established.')
progress['milestones'][5]['acceptance_evidence'].extend(['docs/mainline/evidence/34-root.json','docs/mainline/evidence/M5.json'])
progress['milestones'][6]['acceptance_evidence'].append('docs/mainline/evidence/34-root.json')
progress['milestones'][6]['progress_scope']='34 primary result accepted;35 ablation next;36,37 pending.'
progress['research_trials'].update(status='confirmation_analyzed_no_practical_gain',primary_confirmation_status='NO_PRACTICAL_GAIN',
    primary_mean_service_delta_s=.03515625)
progress['active_implementations']=[dict(ticket='35',owner='/root',worktree='mainline35-ablation',state='ready_after34')]
progress['liveness_refresh']='2026-11-08:33 execution complete,34 saved analysis accepted by both review axes and fresh proof; root proceeds35 before user checkpoint.'
write(p,progress)
p=root/'.scratch/full-facility-mainline/issues/34-paired-analysis.md';s=p.read_text(encoding='utf-8').replace('**Status:** claimed','**Status:** resolved').replace('- [ ]','- [x]')
s=s.replace('Pending implementation and acceptance.','Accepted: docs/mainline/evidence/34-root.json; all16pairs, NO_PRACTICAL_GAIN,3actual data figures, independent reviews and exact fresh delivery. No new physical/selector calls.')
p.write_text(s,encoding='utf-8',newline='\n')
p=root/'docs/MAINLINE.md';s=p.read_text(encoding='utf-8').replace('第33项96次确认原件已接受，当前主票34配对分析','第34项独立配对分析已接受，当前主票35机制消融')
s=s.replace('主要结论待第34项配对分析','主配对结论NO_PRACTICAL_GAIN，平均改善0.03515625秒未达0.25秒门槛')
s+='\n[第34项主要结果与三张数据图](../evidence/mainline/research/34-paired-analysis/README.md)接受完整16配对及成本、负例与无人工参照；第35项按原定条件检验机制，不调整候选方法。\n'
p.write_text(s,encoding='utf-8',newline='\n')
print(json.dumps(dict(status='ACCEPTED34',M5='ACCEPTED_WITH_NO_PRACTICAL_GAIN',current_ticket='35',new_registered_runs=0)))
