"""Close only the prospective preparation/accounting corrections statically."""
import hashlib
import json
from pathlib import Path
import subprocess

ROOT=Path('C:/Users/Donson/.codex/worktrees/mainline36-robustness/Renly')
OUT=Path(__file__).resolve().parent
FINAL='6485de76a7421d743b527a33ac218c17c5493ce4'
META='4bc4323afe600707762b2e0e271b8327e794dc07'
PRIOR='cfbc6ce2f1c80839d64b0bf5c5ddd901b82d864d'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
git=lambda *args:subprocess.check_output(['git',*args],cwd=ROOT)
hashes={}

def blob(path,source=FINAL):
    raw=git('show',source+':'+path)
    hashes[source+':'+path]=dict(sha256=sha(raw),bytes=len(raw))
    return raw

def save(name,data):
    with (OUT/name).open('x',encoding='utf-8',newline='\n') as stream:
        stream.write(json.dumps(data,ensure_ascii=False,indent=2,allow_nan=False)+'\n')

release=blob('scripts/robustness_release.py').decode()
capture=blob('scripts/registered_robustness.py').decode()
classification=json.loads(blob('docs/mainline/36-pure-input-classification.json'))
assert "nonce_read_attempts=0,nonce_reads=0" in release
assert "receipt['nonce_read_attempts']=1" in release
assert "nonce_read_completion='NOT_STARTED'" in release
assert "receipt['nonce_read_completion']='UNKNOWN_OR_FAILED'" in release
assert "receipt['nonce_read_completion']='VALIDATED_RETURN'" in release
assert release.index("append(folder/'attempts.jsonl',dict(status='STARTED_NONCE_READ'") < release.index("nonce=_read_nonce(NONCE")
assert "receipt['finite_admission_calls']+=1;_admit(item,arm)" in release
for path in ('docs/mainline/progress.json','evidence/mainline/engineering/36-public-admission/preflight-01.json',
             'evidence/mainline/engineering/36-public-admission/preflight-01.start.json'):
    assert path in release
assert 'pins=dict(preparation_pins(source),**hashes(source,{PREPARATION_AUTHORIZATION' in release
assert "approval['public_preflight_sha256']==digest(" in release
assert "git('cat-file','blob',source+':'+PREPARATION_AUTHORIZATION)" in release
assert "execution-validation-01" in capture and 'REFUSED_BEFORE_PHYSICAL_SLOTS' in capture
assert capture.index("journal_write(gate/'start.json'") < capture.index('_read_nonce(NONCE')
assert 'VALIDATED_RETURN' in capture and 'UNKNOWN_OR_FAILED' in capture
assert "'docs/mainline/progress.json'" in capture
scope=['src','scripts','configs','tests','docs/mainline/36-*.json','docs/mainline/progress.json',
       'docs/mainline/evidence/30-protocol-lock.json','docs/mainline/30-comparison-protocol-v1.json',
       'docs/mainline/evidence/pre36-alignment.json','docs/mainline/evidence/34-root.json','docs/mainline/evidence/35-root.json',
       'evidence/mainline/engineering/26-candidate/reference/online-baseline-inspect.json',
       'evidence/mainline/engineering/23-interventions/reference/network-full.json']
assert not git('diff','--name-only',FINAL,META,'--',*scope).strip()
templates=[]
for path in classification['templates']:
    current=blob(path)
    for source in ('636b51bacd57e2aef7f4cc6142e1282da10789c3',
                   '1b3d70aa9c620d129f9f1c5081e91b43ace3bad8',
                   '63df4f172d5ecee17a5e68847fa5b0204b73845b'):
        assert blob(path,source)==current
    templates.append(dict(path=path,sha256=sha(current),classification='POST_EXECUTION_SAVED_GIT_IDENTITY_ONLY_NOT_CONTEMPORANEOUS_GUARD'))
with (OUT/'final-correction.diff').open('x',encoding='utf-8',newline='\n') as stream:
    stream.write(git('diff',PRIOR,FINAL,'--','scripts','docs/mainline/36-pure-input-classification.json').decode())
save('final-closure-review.json',dict(source=FINAL,metadata_only_compatible_source=META,status='PASS',
    closed_findings=['36SPEC-01','36SPEC-02'],unresolved_findings=[],
    nonce_semantics='Record and fsync a read attempt before invocation. nonce_reads counts validated returns only; failed/uncertain completion is explicit, not zero actual access.',
    metadata_inputs='Public receipt/start, exact committed preparation authority and progress now join the preparation receipt pins; authority binds source_pins and public preflight SHA.',
    prephysical_gate='Unique nonce-validation start/terminal evidence retains rejection before any chargeable physical slot. Physical starts still require their separate exact execution authorization.',
    original_pure_template_scope=templates,source_hashes=hashes,
    reviewer_project_calls=0,reviewer_test_calls=0,reviewer_admission_calls=0,reviewer_selector_calls=0,
    reviewer_physical_calls=0,reviewer_inference_calls=0,reviewer_nonce_file_reads=0))
report='''Spec：PASS（6485de76；4bc4323a准备相关字节一致）。

四轴仅改冻结负荷、测点、UPS和公开预测，实际动作仍.75；4区组/8工况/16槽、HMAC接口和旧主要负结果保持。新源/解释器/输入冻结，NA不改为零。

两项记账发现均闭合：admission先计数，nonce尝试先持久记录并区分校验成功与失败未知。失败、原件及旧守卫边界保留，原生审计兼容。

可执行唯一16-call无nonce公开预检；通过并提交相同source_pins授权后，可准备16份held输入。物理执行仍须实际输入与执行锁另行独立复核。本审查零项目、测试、准入、选择器、物理或nonce调用。
'''
assert len(report)<400
with (OUT/'report.md').open('x',encoding='utf-8',newline='\n') as stream:stream.write(report)
save('receipt.json',dict(status='PASS_SPEC_PREPARATION_CODE_ONLY',source=FINAL,metadata_only_compatible_source=META,
    unresolved_findings=0,original_findings_preserved=2,
    public_preflight='May perform exactly one defined16-admission, no-nonce public preflight.',
    held_prepare='Only after passing saved public preflight and committed exact-source preparation authorization, may prepare16 inputs with one phase-nonce read attempt and16 admissions.',
    physical_execution_authorized=False,held_inputs_accepted=False,
    next_gate='Independent saved review of actual16 inputs and full execution/source lock is still required.',
    project_calls=0,tests=0,admissions=0,selectors=0,physical_calls=0,inference=0,nonce_file_reads=0,new_registered_trials=0))
manifest=dict(schema='aegisdc-independent-spec-preparation-review-v1',source=FINAL,
    metadata_only_compatible_source=META,artifacts={path.name:dict(sha256=sha(path.read_bytes()),bytes=path.stat().st_size)
        for path in sorted(OUT.iterdir()) if path.is_file() and path.name!='manifest.json'},excluded=['Self-hash','Runtime caches'])
save('manifest.json',manifest)
print(json.dumps(dict(status='PASS',source=FINAL,artifacts=len(manifest['artifacts']),report_characters=len(report),
    manifest_sha256=sha((OUT/'manifest.json').read_bytes()),project_calls=0)))
