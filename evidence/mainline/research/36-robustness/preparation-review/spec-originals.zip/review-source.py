"""Static/Git and saved-record Spec review; no project imports or execution."""
import ast
from datetime import datetime,timezone
import hashlib
import json
from pathlib import Path
import subprocess

ROOT=Path('C:/Users/Donson/.codex/worktrees/mainline36-robustness/Renly')
OUT=Path(__file__).resolve().parent
BASE='f5e00759215e4cbb22bb8f3e9726e81286eba078'
INITIAL='e192e5d055cc275a3ebe141d07c843a0f0272b54'
CORRECTION='cfbc6ce2f1c80839d64b0bf5c5ddd901b82d864d'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
git=lambda *args:subprocess.check_output(['git',*args],cwd=ROOT)
hashes={}

def blob(source,path):
    raw=git('show',source+':'+path)
    hashes[source+':'+path]=dict(sha256=sha(raw),bytes=len(raw))
    return raw

def save(name,data):
    with (OUT/name).open('x',encoding='utf-8',newline='\n') as stream:
        stream.write(json.dumps(data,ensure_ascii=False,indent=2,allow_nan=False)+'\n')

def batch_verify(source,expected):
    refs=''.join(source+':'+path+'\n' for path in expected).encode()
    raw=subprocess.check_output(['git','cat-file','--batch'],input=refs,cwd=ROOT)
    offset=0
    for path,expected_sha in expected.items():
        end=raw.index(b'\n',offset);header=raw[offset:end].split()
        assert len(header)==3 and header[1]==b'blob'
        size=int(header[2]);value=raw[end+1:end+1+size]
        assert sha(value)==expected_sha,(source,path)
        offset=end+2+size
    assert offset==len(raw)
    return len(expected)

save('start.json',dict(base=BASE,initial=INITIAL,correction=CORRECTION,
    started_utc=datetime.now(timezone.utc).isoformat(),scope='STATIC_AND_SAVED_PURE_CONTRACT_RECORDS_ONLY'))
paths=['scripts/robustness_release.py','scripts/registered_robustness.py',
    'scripts/analyze_registered_robustness.py','scripts/render_robustness_figures.py',
    'scripts/check_robustness_contracts.py','tests/test_robustness_release.py',
    'scripts/comparison_release.py','scripts/prepare_comparison_worlds.py',
    'scripts/registered_comparison.py','scripts/registered_development.py',
    'scripts/development_run_evidence.py','scripts/development_journal.py',
    'scripts/inspection_delivery.py','docs/mainline/36-prospective-extension.json',
    'docs/mainline/36-robustness-execution.json','docs/mainline/36-public-contract-correction-01.json',
    'docs/mainline/30-comparison-protocol-v1.json','docs/mainline/32-seed-interface-amendment.json',
    'configs/full-facility-comparison-held-blueprints-admission-v1.json',
    'docs/mainline/evidence/30-protocol-lock.json',
    '.scratch/full-facility-mainline/issues/36-robustness-study.md']
texts={path:blob(CORRECTION,path).decode() for path in paths}
plan=json.loads(texts['docs/mainline/30-comparison-protocol-v1.json'])
phase=plan['phases']['robustness'];worlds=phase['worlds']
assert len(worlds)==8 and len(phase['arms'])==2
assert phase['budget']==dict(attempts=16,simulated_charge_s=160,scheduled_decisions=160)
assert plan['global_budget']['attempts']==180
assert [world['comparison'] for world in worlds]==['R1','R1','R2','R2','R3','R3','R4','R4']
assert [world['level'] for world in worlds]==['reference','perturbed']*4
assert len(plan['decision_times_s'])==10
blueprints=json.loads(texts['configs/full-facility-comparison-held-blueprints-admission-v1.json'])['robustness']
assert [blueprints['load-level'][level]['offered_demand'] for level in ('reference','perturbed')]==[.75,1.25]
assert [blueprints['sensor-coverage'][level]['rectifier_meter_enabled'] for level in ('reference','perturbed')]==[True,False]
assert [blueprints['reserve-path'][level]['ups_in_service'] for level in ('reference','perturbed')]==[1,0]
assert [blueprints['model-error'][level]['declared_fallback_capacity'] for level in ('reference','perturbed')]==[.75,1]
lock=json.loads(texts['docs/mainline/evidence/30-protocol-lock.json'])
original=lock['design_commit'];pins=lock['pins']
batch_verify(original,pins)
current_pin_hashes={}
for path in pins: current_pin_hashes[path]=sha(blob(CORRECTION,path))
changed=[path for path in pins if current_pin_hashes[path]!=pins[path]]
assert changed==['src/aegis_dc/verified_closure.py']
extension=json.loads(texts['docs/mainline/36-prospective-extension.json'])
closure=extension['changed_original_pins']['src/aegis_dc/verified_closure.py']
assert sha(blob('62affc55f7c3f08366fb241faa21560c94f1965c','src/aegis_dc/verified_closure.py'))==closure['corrected_sha256']==current_pin_hashes['src/aegis_dc/verified_closure.py']
assert not git('diff','--name-only',BASE,CORRECTION,'--','src','configs').strip()
for path in ('scripts/prepare_comparison_worlds.py','scripts/registered_development.py',
             'scripts/development_run_evidence.py','scripts/development_journal.py'):
    assert blob(BASE,path).decode()==texts[path]
pure=[]
for directory,expected in [('red-01',(2,2)),('green-01',(2,1)),('green-02',(2,0))]:
    prefix='evidence/mainline/engineering/36-public-admission/'+directory+'/'
    began=json.loads(blob(CORRECTION,prefix+'start.json'))
    receipt=json.loads(blob(CORRECTION,prefix+'receipt.json'))
    log=blob(CORRECTION,prefix+'tests.log').decode()
    assert receipt['source']==began['source']
    assert (receipt['tests'],receipt['failures'])==expected and receipt['errors']==receipt['skipped']==0
    assert receipt['source_guard']=='PASS'
    for key in ('admission_calls','physical_calls','selector_calls','nonce_reads','registered_research_trials'):
        assert receipt[key]==0
    count=batch_verify(receipt['source'],began['pins'])
    pure.append(dict(directory=directory,source=receipt['source'],tests=receipt['tests'],failures=receipt['failures'],
        errors=0,source_guard_blobs=count,log_sha256=sha(log.encode()),scope='Existing pure CLI records; no reviewer rerun.'))
release=texts['scripts/robustness_release.py'];capture=texts['scripts/registered_robustness.py']
initial=blob(INITIAL,'scripts/robustness_release.py').decode()
assert "_admit(item,arm);receipt['finite_admission_calls']+=1" in initial
assert "receipt['finite_admission_calls']+=1;_admit(item,arm)" in release
assert "observation_seed(nonce,plan['id'],namespace,world['comparison'],'portable')" in release
assert "observation_seed(nonce,plan['id'],namespace,world['comparison'],'fixed')>>64" in release
assert 'not folder.exists()' in release and 'PENDING_INDEPENDENT_REVIEW' in release
assert "read(ROOT/'docs/mainline/progress.json')" in release
assert 'STARTED_INPUT_PREPARATION' in release
assert "public_start['pins']==preparation_pins(public['source'])==preparation_pins(source)" in release
assert "approval['source_pins']==preparation_pins(source)" in release
assert "receipt['pins'].items()),'Preparation working source/input differs before nonce'" in release
assert "journal_append(ledger,start)" in capture and "result=simulate_scenario" in capture
assert capture.index('journal_append(ledger,start)')<capture.index('result=simulate_scenario')
assert 'RECORDER_INCOMPLETE' in capture and 'authoritative_totals=None' in capture
assert "authorization['execution_lock_sha256']==digest((ROOT/EXECUTION_LOCK).read_bytes())" in capture
assert "progress['research_trials']['attempts']==164" in capture
assert "progress['research_trials']['charged_s']==1640" in capture
for path in paths:
    if path.endswith('.py'):ast.parse(texts[path])
with (OUT/'changes.diff').open('x',encoding='utf-8',newline='\n') as stream:
    stream.write(git('diff',BASE+'...'+CORRECTION,'--','scripts','tests','docs/mainline/36-prospective-extension.json',
        'docs/mainline/36-robustness-execution.json','docs/mainline/36-public-contract-correction-01.json').decode())
observations=dict(base=BASE,initial_source=INITIAL,reviewed_source=CORRECTION,
    original_design_source=original,original_design_pins=len(pins),only_changed_original_pin=changed,
    phase=dict(worlds=8,arms=phase['arms'],contrast_blocks=4,slots=16,simulated_charge_s=160,scheduled_decisions=160),
    axes=blueprints,pure_saved_records=pure,
    native_evaluator='Unchanged _save_native archives raw return before checking; check_run checks current native code/input, evidence clock/history, actual service and costs without an obsolete design-lock pin check. No hard-coded demand1 or fixed forecast capacity; varied offered demand and declared forecasts remain separate from actual effects.',
    failure_account='STARTED append/fsync charges each physical slot before invocation; no retries; partial recorder writes retain RECORDER_INCOMPLETE and no synthetic authoritative total. Analyzer refuses failed/missing slots pending explicit failure audit.',
    analysis='8 world-paired deltas and 4 within-axis differences; no population CI, no replacement/reclassification of primary16world NO_PRACTICAL_GAIN. Cost sign candidate-minus-baseline, service baseline-minus-candidate. Generic fault/miss/prevention/closure remain NA.',
    release='One16-admission public preflight allowed at reviewed source. Held prepare requires exact public receipt, matching source_pins/authorization, clean current36 frontier, and one read of committed phase nonce. Actual prepared input/source freeze still needs separate independent saved review before physical authorization.',
    independent_project_calls=0,tests=0,admission_calls=0,selectors=0,physical_calls=0,inference_calls=0,nonce_file_reads=0)
save('observations.json',observations)
save('findings-initial-and-closure.json',dict(initial_source=INITIAL,reviewed_source=CORRECTION,findings=[
    dict(id='36SPEC-01',severity='P2',status='CLOSED_AT_CFBC',path='scripts/robustness_release.py',line_at_initial=168,
        finding='Held preparation counted admission only after success, so an invoked failing admission was omitted.',
        requirement='Preserve every failed finite preparation call and its attempt accounting.',
        correction='Increment finite_admission_calls before invoking _admit; no actual admission had run.'),
    dict(id='36SPEC-02',severity='P2',status='OPEN_HELD_PREPARATION_ACCOUNT_ONLY',path='scripts/robustness_release.py',
        finding='nonce_reads is assigned only after _read_nonce returns. A raw nonce read followed by commitment rejection can leave the failed receipt at zero.',
        requirement='Declared one-attempt preparation and honest failure accounting.',
        requested_correction='Record nonce_read_attempts before helper invocation and validated nonce_reads after success, or equivalently distinguish attempted and validated reads without reading/rerunning a nonce.')]))
save('source-and-evidence-hashes.json',hashes)
print(json.dumps(dict(status='STATIC_REVIEW_SAVED',source=CORRECTION,original_pins=len(pins),
    pure_guard_blobs=[row['source_guard_blobs'] for row in pure],project_calls=0)))
