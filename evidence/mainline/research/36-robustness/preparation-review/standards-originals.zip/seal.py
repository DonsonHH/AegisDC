"""Seal the Standards preparation review without executing project code."""
from pathlib import Path
import ast
import hashlib
import json
import subprocess

ROOT=Path(r"C:\Users\Donson\Documents\ChatGPT\Renly")
OUT=Path(__file__).resolve().parent
sha=lambda raw:hashlib.sha256(raw).hexdigest()
assert not (OUT/'manifest.json').exists()
result=json.loads((OUT/'result.json').read_bytes())
assert result['check_count']==1385 and result['remaining_blockers']==[]
source=result['candidate']
functions={'scripts/robustness_release.py':['preparation_pins','audit_design','public_audit','prepare','verify_freeze'],'scripts/registered_robustness.py':['_begin','capture'],'scripts/analyze_registered_robustness.py':['analyze']}
references=[]
for path,names in functions.items():
    raw=subprocess.check_output(['git','-C',str(ROOT),'cat-file','blob',source+':'+path])
    tree=ast.parse(raw)
    for name in names:
        node=next(n for n in ast.walk(tree) if isinstance(n,ast.FunctionDef) and n.name==name)
        references.append({'path':path,'function':name,'line':node.lineno,'sha256':sha(raw)})
(OUT/'source-map.json').write_text(json.dumps(references,indent=2)+'\n',encoding='utf-8')
receipt={'schema':'aegisdc-independent-preparation-standards-v1','status':result['status'],'source':source,'corrected_core':result['corrected_core'],'checks':1385,'remaining_blockers':[],'public_and_held_preparation_scope':result['permission_scope'],'resolved_findings':result['resolved_findings'],'heuristic_review':{'baseline_smells_considered':12,'meaningful_additional_findings':0,'documented_repo_contracts_take_precedence':True},'reviewer_activity':result['reviewer_activity'],'runtime_evidence_limit':'New guards reviewed statically; existing pure suites retain their original exact source and incomplete whole-input-guard classification. No project execution by reviewer.'}
(OUT/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
files=[]
for path in sorted(OUT.iterdir()):
    if path.is_file() and path.name not in {'manifest.json','seal-verification.json'}:
        raw=path.read_bytes();files.append({'path':path.name,'sha256':sha(raw),'bytes':len(raw)})
manifest={'schema':'aegisdc-independent-review-manifest-v1','source':source,'corrected_core':result['corrected_core'],'files':files,'excluded':['manifest.json (self)','seal-verification.json (post-seal proof)','runtime caches (none declared)']}
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
for row in json.loads((OUT/'manifest.json').read_bytes())['files']:
    raw=(OUT/row['path']).read_bytes();assert sha(raw)==row['sha256'] and len(raw)==row['bytes']
proof={'status':'PASS','manifest_sha256':sha((OUT/'manifest.json').read_bytes()),'fresh_read_artifacts':len(files),'reviewer_project_calls':0}
(OUT/'seal-verification.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf-8')
print(json.dumps(proof))
