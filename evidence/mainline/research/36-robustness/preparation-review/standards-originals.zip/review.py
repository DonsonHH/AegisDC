"""Immutable Git/AST review only; never import or execute project code."""
from pathlib import Path
import ast
import hashlib
import json
import re
import subprocess

ROOT=Path(r"C:\Users\Donson\Documents\ChatGPT\Renly")
OUT=Path(__file__).resolve().parent
BASE="f5e00759"
INITIAL="e192e5d055cc275a3ebe141d07c843a0f0272b54"
FIX="6485de76a7421d743b527a33ac218c17c5493ce4"
SOURCE="4bc4323afe600707762b2e0e271b8327e794dc07"
checks=[]
def ck(ok,label):
    checks.append({"label":label,"passed":bool(ok)});assert ok,label
def sha(raw):return hashlib.sha256(raw).hexdigest()
def git(*a):return subprocess.check_output(["git","-C",str(ROOT),*a])
def fetch(rev,paths):
    paths=list(dict.fromkeys(paths));raw=subprocess.check_output(["git","-C",str(ROOT),"cat-file","--batch"],input="".join(rev+":"+p+"\n" for p in paths).encode())
    result={};offset=0
    for p in paths:
        end=raw.index(b"\n",offset);header=raw[offset:end].split();assert header[1]==b"blob",(rev,p,header)
        size=int(header[2]);offset=end+1;result[p]=raw[offset:offset+size];offset+=size+1
    assert offset==len(raw);return result
def blob(rev,p):return fetch(rev,[p])[p]
def doc(rev,p):return json.loads(blob(rev,p))
def function(text,name):
    n=next(n for n in ast.walk(ast.parse(text)) if isinstance(n,ast.FunctionDef) and n.name==name)
    return '\n'.join(text.splitlines()[n.lineno-1:n.end_lineno]),n.lineno

base=git('rev-parse',BASE).decode().strip()
ck(git('merge-base',BASE,SOURCE).decode().strip()==base,'fixed baseline is merge-base')
paths=['scripts/robustness_release.py','scripts/registered_robustness.py','scripts/analyze_registered_robustness.py','scripts/render_robustness_figures.py','scripts/check_robustness_contracts.py','tests/test_robustness_release.py']
code=fetch(SOURCE,paths)
for p,raw in code.items():ast.parse(raw);ck(raw==blob(FIX,p),'last metadata merge preserves reviewed executable '+p)
standards=['AGENTS.md','docs/agents/issue-tracker.md','docs/agents/domain.md','docs/MAINLINE.md','GLOSSARY.md','.scratch/full-facility-mainline/spec.md','docs/adr/0003-complete-facility-mainline.md','.scratch/full-facility-mainline/issues/36-robustness-study.md']
standard_identities=[{'path':p,'sha256':sha(blob(SOURCE,p))} for p in standards]
ck(not git('diff','--name-only',BASE,SOURCE,'--','src','configs','scripts/comparison_release.py','scripts/development_journal.py','scripts/registered_development.py','scripts/prepare_comparison_worlds.py').strip(),'original plant, methods, nonce law and recorder unchanged by36')
original_execution=doc(SOURCE,'docs/mainline/evidence/30-confirmation-execution-lock.json')
oldpins=original_execution['execution_pins'];oldsource=original_execution['execution_source']
ck(len(oldpins)==269,'original269 execution pins retained')
oldbytes=fetch(oldsource,oldpins);newbytes=fetch(SOURCE,oldpins)
changed=[]
for p,digest in oldpins.items():
    ck(sha(oldbytes[p])==digest,'unchanged original recorded execution pin '+p)
    if sha(newbytes[p])!=digest:changed.append(p)
ck(changed==['src/aegis_dc/verified_closure.py'],'only explicitly corrected closure differs among original269')
extension=doc(SOURCE,'docs/mainline/36-prospective-extension.json')
change=extension['changed_original_pins'][changed[0]]
ck(change['original_sha256']==oldpins[changed[0]] and change['corrected_sha256']==sha(newbytes[changed[0]])==sha(blob(change['accepted_correction_source'],changed[0])),'prospective closure bridge binds old/new/accepted source without waiver')
ck(blob(SOURCE,'docs/mainline/30-comparison-protocol-v1.json')==blob(BASE,'docs/mainline/30-comparison-protocol-v1.json'),'original protocol/budget/methods unchanged')
ck(blob(SOURCE,'evidence/mainline/research/34-paired-analysis/results.json')==blob(BASE,'evidence/mainline/research/34-paired-analysis/results.json'),'original primary source/result unchanged')
plan=doc(SOURCE,'docs/mainline/30-comparison-protocol-v1.json');phase=plan['phases']['robustness']
ck(phase['budget']=={'attempts':16,'simulated_charge_s':160,'scheduled_decisions':160} and len(phase['worlds'])==8 and len(phase['arms'])==2,'original16-slot finite design')
ck(len({w['comparison'] for w in phase['worlds']})==4 and all(phase['worlds'][i]['comparison']==phase['worlds'][i+1]['comparison'] for i in range(0,8,2)),'four paired contrast blocks')

release=code[paths[0]].decode();capture=code[paths[1]].decode();analysis=code[paths[2]].decode();renderer=code[paths[3]].decode()
fns={name:function(release,name) for name in ['preparation_pins','audit_design','compile_world','check_contrast','public_audit','prepare','verify_freeze','freeze']}
prep=fns['prepare'][0];public=fns['public_audit'][0];pins=fns['preparation_pins'][0]
templates=['evidence/mainline/engineering/26-candidate/reference/online-baseline-inspect.json','evidence/mainline/engineering/23-interventions/reference/network-full.json']
for p in templates:ck(p in pins,'actual compilation template included in future guard '+p)
ck(all(p in pins for p in ['pre36-alignment.json','34-root.json','35-root.json']) and '_execution_files(source)' in pins and 'EXTENSION,LOCK,PROTOCOL' in pins,'source/protocol/authority preparation guard scope')
ck("output==ROOT/'evidence/mainline/engineering/36-public-admission/preflight-01.json'" in public and 'sys.dont_write_bytecode' in public,'one canonical no-cache public preflight')
ck(public.index('all(digest((ROOT/n).read_bytes())==h for n,h in pins.items())')<public.index('_admit(item,arm)') and public.index('calls+=1')<public.index('_admit(item,arm)'),'public complete input guard and admission count before call')
ck("public_start['pins']==preparation_pins(public['source'])==preparation_pins(source)" in prep and "approval['public_preflight_sha256']" in prep,'held preparation bound to reviewed source and exact passed preflight')
metadata=['PREPARATION_AUTHORIZATION','docs/mainline/progress.json','evidence/mainline/engineering/36-public-admission/preflight-01.json','evidence/mainline/engineering/36-public-admission/preflight-01.start.json']
ck(all(p in prep for p in metadata) and 'pins=dict(preparation_pins(source),**hashes(source,' in prep,'all four phase metadata artifacts in actual preparation pins')
ck(prep.index("all(digest((ROOT/n).read_bytes())==h for n,h in receipt['pins'].items())")<prep.index('nonce=_read_nonce'),'exact actual working inputs guarded before private access')
ck(prep.index("receipt['nonce_read_attempts']=1")<prep.index("status='STARTED_NONCE_READ'")<prep.index('nonce=_read_nonce'),'private read attempt durably declared before reader')
ck("nonce_reads_scope='VALIDATED_READ_RETURNS_ONLY; actual completion unknown on failure'" in prep and "receipt['nonce_read_completion']='UNKNOWN_OR_FAILED'" in prep and "receipt['nonce_read_completion']='VALIDATED_RETURN'" in prep,'nonce failed completion is unknown, not an invented zero read')
ck(prep.index("receipt['finite_admission_calls']+=1")<prep.index('_admit(item,arm)'),'held admission failure attempt counted before call')
ck('observation_seed(nonce,plan[\'id\'],namespace,world[\'comparison\']' in prep,'held paired realization uses registered contrast key and private namespace')
ck("pins==hashes(source,pins)==hashes(head(),pins)" in fns['verify_freeze'][0] and 'interpreter_sha256' in fns['verify_freeze'][0] and 'all(digest((ROOT/n).read_bytes())==h for n,h in pins.items())' in fns['verify_freeze'][0],'prospective full executable/interpreter/working-source freeze')
ck("set(lock['input_hashes'])==set(prep['input_hashes'])==expected" in fns['verify_freeze'][0] and "durable(ROOT/PREP)==set(prep['artifacts'])|{'receipt.json'}" in fns['verify_freeze'][0],'complete unique16 prepared input set verified')
body,capture_line=function(capture,'capture');begin,begin_line=function(capture,'_begin')
ck("progress['research_trials']['attempts']==164" in begin and "progress['research_trials']['charged_s']==1640" in begin and 'docs/mainline/progress.json' in begin,'capture exact old cumulative budget and actual progress pin')
ck("authorization['execution_lock_sha256']==digest" in begin and "status='STARTED_NONCE_VALIDATION'" in begin and "nonce_read_completion='UNKNOWN_OR_FAILED'" in begin,'separate execution authorization/private-validation failure original')
ck(body.index('journal_append(ledger,start)')<body.index('journal_write(folder_slot/\'start.json\',start)')<body.index('result=simulate_scenario('),'fsynced existing recorder charge precedes physical invocation')
ck("status='RECORDER_INCOMPLETE'" in body and 'authoritative_totals=None' in body and 'return 4' in body and "BATCH_STOPPED_WITHOUT_NEW_ATTEMPT" in body,'uncertain recorder never synthesizes an authoritative reconciled zero or retries')
ck("total['failed']==total['interrupted']==total['unrun']==0" in analysis and 'explicit failure audit and fixed-denominator partial-outcome report' in analysis,'saved analyzer fails closed on unsuccessful or missing slots')
ck('contrast_blocks=4' in analysis and 'Four matched reference/perturbed blocks; not16 independent replications. No population interval.' in analysis and 'original_primary_unchanged' in analysis,'finite independent units and original primary retained')
ck('new_model_calls' in renderer and 'input_sha256' in renderer and 'tool_sha256' in renderer and 'font_sha256' in renderer,'saved-only figure provenance')

attempts=[];fixture_checks=[]
for name,tests,failures in [('red-01',2,2),('green-01',2,1),('green-02',2,0)]:
    prefix='evidence/mainline/engineering/36-public-admission/'+name+'/'
    saved=fetch(SOURCE,[prefix+p for p in ['start.json','receipt.json','tests.log']]);start=json.loads(saved[prefix+'start.json']);receipt=json.loads(saved[prefix+'receipt.json']);log=saved[prefix+'tests.log'].decode()
    revision=receipt['source'];recorded=start['pins'];originals=fetch(revision,recorded)
    ck(start['source']==revision and receipt['tests']==tests and receipt['failures']==failures and receipt['errors']==receipt['skipped']==0,'pure attempt source/count '+name)
    for p,h in recorded.items():ck(sha(originals[p])==h,'pure declared execution guard '+name+' '+p)
    ck(f'Ran {tests} tests' in log and (f'FAILED (failures={failures})' in log if failures else log.rstrip().endswith('OK')),'pure original raw outcome retained '+name)
    ck(all(receipt[k]==0 for k in ['admission_calls','physical_calls','selector_calls','nonce_reads','registered_research_trials']),'pure engineering no model/unsealing work '+name)
    attempts.append({'attempt':name,'source':revision,'failures':failures,'guarded_files':len(recorded),'artifacts':[{'path':p,'sha256':sha(v),'bytes':len(v)} for p,v in saved.items()]})
    for p in templates:
        raw=blob(revision,p);ck(raw==blob(SOURCE,p),'post-execution fixed template identity '+name+' '+p)
        fixture_checks.append({'attempt':name,'path':p,'execution_source':revision,'sha256':sha(raw),'bytes':len(raw),'classification':'POST_EXECUTION_SAVED_GIT_IDENTITY_NOT_ORIGINAL_WHOLE_SET_GUARD'})
classification=doc(SOURCE,'docs/mainline/36-pure-input-classification.json')
ck(classification['new_calls']==classification['new_nonce_reads']==classification['new_registered_runs']==0 and 'not rewritten' in classification['boundary'],'pure input-guard omission classified without retrospective upgrade or rerun')
progress=doc(SOURCE,'docs/mainline/progress.json')
ck(progress['research_trials']['robustness']['attempts']==0 and progress['current_ticket']=='36','no actual36 research accepted at reviewed candidate')
ck(not git('ls-tree','-r','--name-only',SOURCE,'--','evidence/mainline/research/36-robustness').strip(),'no held preparation or physical capture materialized at source')
result={'status':'PASS_ONCE_PUBLIC_PREFLIGHT_AND_CONDITIONAL_HELD_PREPARATION_ONLY','base':base,'initial_candidate':INITIAL,'corrected_core':FIX,'candidate':SOURCE,'check_count':len(checks),'checks':checks,'standards_sources':standard_identities,'reviewed_source':[{'path':p,'sha256':sha(v),'bytes':len(v)} for p,v in code.items()],'original269_source':oldsource,'original269_changed_paths':changed,'pure_attempts':attempts,'post_execution_template_identities':fixture_checks,'resolved_findings':[{'id':'S36-01','initial_source':'cfbc6ce2f1c80839d64b0bf5c5ddd901b82d864d','issue':'Four actual preparation phase metadata files missing from before/after pin map; capture progress absent','resolution':'Exact prospective metadata pins added at6485 before any admission/private access'},{'id':'S36-02','initial_source':'cfbc6ce2f1c80839d64b0bf5c5ddd901b82d864d','issue':'Private reader failure could be mistaken for zero reads','resolution':'Durable read attempt and unknown completion separated from validated returns; execution validation failure retained'},{'id':'S36-03','issue':'Original pure suites did not guard whole actual evidence/governance input set','resolution':'Originals preserved with explicit retrospective identity-only classification; no pure suite repeated'}],'remaining_blockers':[],'permission_scope':{'public_preflight':'ONE original16 finite admissions, zero nonce/selector/physical','held_preparation':'ONLY after exact preflight PASS, committed same-source-pins approval, one private nonce attempt and16 finite admissions','physical_execution':'NOT_AUTHORIZED_BY_THIS_REVIEW; requires new exact execution lock, complete input review and independent execution authorization'},'reviewer_activity':{'tests':0,'models':0,'plant':0,'selectors':0,'inference':0,'rng':0,'nonce':0,'captures':0,'project_imports':0,'tracked_edits':0}}
(OUT/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:result[k] for k in ['status','check_count','candidate','remaining_blockers','permission_scope','reviewer_activity']}))
