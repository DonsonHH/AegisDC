"""Audit the saved16 robustness inputs; no project imports or nonce/HMAC calls."""
from collections import Counter
from copy import deepcopy
from datetime import datetime,timezone
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import traceback

ROOT=Path('C:/Users/Donson/.codex/worktrees/mainline36-robustness/Renly')
OUT=Path(__file__).resolve().parent
SOURCE='f101531642f5808f1af553f4b926dda92341ab42'
EXEC='f834ea4de71a175fc4fa341cc29ed1694280ae0e'
REVIEWED='6485de76a7421d743b527a33ac218c17c5493ce4'
PREP='evidence/mainline/research/36-robustness/prepared-01/'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
git=lambda *args:subprocess.check_output(['git',*args],cwd=ROOT)
hashes={}

def blob(path,source=SOURCE):
    raw=git('show',source+':'+path)
    hashes[source+':'+path]=dict(sha256=sha(raw),bytes=len(raw))
    return raw

def read(path,source=SOURCE):return json.loads(blob(path,source))

def save(name,value):
    with (OUT/name).open('x',encoding='utf-8',newline='\n') as stream:
        stream.write(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n')

def batch(source,expected,working=False):
    raw=subprocess.check_output(['git','cat-file','--batch'],cwd=ROOT,
        input=''.join(source+':'+path+'\n' for path in expected).encode())
    offset=0
    for path,value in expected.items():
        end=raw.index(b'\n',offset);header=raw[offset:end].split()
        assert len(header)==3 and header[1]==b'blob',(source,path)
        length=int(header[2]);body=raw[end+1:end+1+length]
        assert sha(body)==value,(source,path)
        if working:assert (ROOT/path).read_bytes()==body,path
        offset=end+2+length
    assert offset==len(raw)
    return len(expected)

def changed(left,right,path=()):
    if type(left) is not type(right):
        assert type(left) in (int,float) and type(right) in (int,float),(path,type(left),type(right))
        return set() if left==right else {path}
    if isinstance(left,dict):
        assert left.keys()==right.keys(),path
        return set().union(*(changed(left[key],right[key],path+(key,)) for key in left))
    if isinstance(left,list):
        assert len(left)==len(right),path
        return set().union(*(changed(a,b,path+(i,)) for i,(a,b) in enumerate(zip(left,right))))
    return set() if left==right else {path}

def canonical(document):return json.dumps(document,sort_keys=True,separators=(',',':'),allow_nan=False).encode()

save('start.json',dict(source=SOURCE,execution_source=EXEC,started_utc=datetime.now(timezone.utc).isoformat(),
    scope='SAVED_JSON/GIT/HASH/STATIC_SOURCE_ONLY; NO_NONCE_READ_OR_HMAC_RECOMPUTATION'))
try:
    plan=read('docs/mainline/30-comparison-protocol-v1.json');phase=plan['phases']['robustness']
    design=read('docs/mainline/evidence/30-protocol-lock.json')
    lock=read('docs/mainline/evidence/30-robustness-execution-lock.json')
    prep=read(PREP+'receipt.json')
    authority=read('docs/mainline/evidence/36-preparation-authorization.json')
    public=read('evidence/mainline/engineering/36-public-admission/preflight-01.json')
    public_start=read('evidence/mainline/engineering/36-public-admission/preflight-01.start.json')
    extension=read('docs/mainline/36-prospective-extension.json')
    blueprint=read('configs/full-facility-comparison-held-blueprints-admission-v1.json')['robustness']
    reference=read('evidence/mainline/engineering/26-candidate/reference/online-baseline-inspect.json')
    baseline=read('configs/full-facility-mainline-reserve-v6.json')
    shared=read('configs/full-facility-comparison-development-v1.json')['shared']
    progress=read('docs/mainline/progress.json')
    original_primary=read('evidence/mainline/research/34-paired-analysis/results.json')
    old_execution=read('docs/mainline/evidence/30-confirmation-execution-lock.json')
    worlds=phase['worlds'];arms=phase['arms']
    assert len(worlds)==8 and len(arms)==2
    assert lock['execution_source']==EXEC and lock['status']=='PENDING_INDEPENDENT_REVIEW'
    assert lock['budget']==phase['budget']==dict(attempts=16,simulated_charge_s=160,scheduled_decisions=160)
    assert lock['design_lock_sha256']==sha(blob('docs/mainline/evidence/30-protocol-lock.json'))
    assert lock['extension_sha256']==sha(blob('docs/mainline/36-prospective-extension.json'))
    assert lock['interpreter_sha256']==sha(Path(sys.executable).read_bytes())
    executable={path for path in git('ls-tree','-r','-z','--name-only',EXEC,'src','scripts','configs').decode().split('\0') if path.endswith(('.py','.json'))}
    assert executable==set(lock['execution_pins']) and len(executable)==286
    batch(EXEC,lock['execution_pins']);batch(SOURCE,lock['execution_pins'],working=True)
    assert not git('diff','--name-only',REVIEWED,EXEC,'--','src','scripts','configs').strip()
    assert len(old_execution['execution_pins'])==269
    batch(old_execution['execution_source'],old_execution['execution_pins'])
    assert set(old_execution['execution_pins'])<=executable
    bridge_changes={path for path,value in old_execution['execution_pins'].items() if lock['execution_pins'][path]!=value}
    assert bridge_changes=={'src/aegis_dc/verified_closure.py'}
    assert len(design['pins'])==61;batch(design['design_commit'],design['pins'])
    design_changes={path for path,value in design['pins'].items() if sha(blob(path))!=value}
    assert design_changes==bridge_changes==set(extension['changed_original_pins'])
    assert sha(blob('src/aegis_dc/verified_closure.py','62affc55f7c3f08366fb241faa21560c94f1965c'))==lock['execution_pins']['src/aegis_dc/verified_closure.py']
    assert prep['status']=='PASS_INPUT_ONLY' and prep['prepared_inputs']==16
    assert (prep['finite_admission_calls'],prep['nonce_read_attempts'],prep['nonce_reads'])==(16,1,1)
    assert prep['nonce_read_completion']=='VALIDATED_RETURN'
    assert prep['physical_calls']==prep['selector_calls']==prep['registered_research_trials']==0
    assert len(prep['pins'])==300 and len(authority['source_pins'])==296
    batch(prep['source'],prep['pins'])
    assert all(prep['pins'][path]==value for path,value in authority['source_pins'].items())
    assert {path:prep['pins'][path] for path in executable}==lock['execution_pins']
    assert authority['status']=='REVIEWED_FOR_INPUT_PREPARATION'
    assert authority['source_pins']==public_start['pins'] and public_start['source']==public['source']
    batch(public['source'],public_start['pins'])
    assert authority['public_preflight_sha256']==sha(blob('evidence/mainline/engineering/36-public-admission/preflight-01.json'))
    for path in ('docs/mainline/evidence/36-preparation-authorization.json','docs/mainline/progress.json',
                 'evidence/mainline/engineering/36-public-admission/preflight-01.json',
                 'evidence/mainline/engineering/36-public-admission/preflight-01.start.json'):
        assert prep['pins'][path]==sha(blob(path,prep['source']))
    assert public['status']=='PASS_PUBLIC_ROBUSTNESS_ADMISSION' and public['source_guard']=='PASS'
    assert public['finite_admission_calls']==16 and public['nonce_reads']==public['physical_calls']==public['selector_calls']==0
    public_rows={(row['world_id'],row['arm']):row for row in public['rows']}
    assert len(public_rows)==16
    release=blob('scripts/robustness_release.py',prep['source']).decode()
    assert "receipt['pins'].items()),'Preparation working source/input differs before nonce'" in release
    assert "for n,h in receipt['pins'].items()),'Preparation working source changed'" in release
    assert "observation_seed(nonce,plan['id'],namespace,world['comparison'],'portable')" in release
    assert "observation_seed(nonce,plan['id'],namespace,world['comparison'],'fixed')>>64" in release
    derivation_source=blob('scripts/comparison_release.py',prep['source']).decode()
    assert 'hmac.compare_digest(digest(raw),expected)' in derivation_source
    assert "hmac.digest(nonce,canonical(['seed',protocol_id,namespace,seed_key,channel]),'sha256')" in derivation_source
    journal=[json.loads(line) for line in blob(PREP+'attempts.jsonl').decode().splitlines()]
    assert [row['status'] for row in journal]==['STARTED_INPUT_PREPARATION','STARTED_NONCE_READ']+['COMPLETED_INPUT_WORLD']*8
    assert journal[0]['source']==journal[1]['source']==prep['source']
    assert journal[1]['expected_commitment']==design['commitments_sha256']['robustness']
    assert [row['world_id'] for row in journal[2:]]==[world['id'] for world in worlds]
    assert all(row['arms']==2 for row in journal[2:])
    actual_names={path[len(PREP):] for path in git('ls-tree','-r','-z','--name-only',SOURCE,PREP).decode().split('\0') if path}
    assert actual_names==set(prep['artifacts'])|{'receipt.json'}
    for path,value in prep['artifacts'].items():assert sha(blob(PREP+path))==value
    expected_names={world['id']+'/'+arm+'.json' for world in worlds for arm in arms}
    assert set(lock['input_hashes'])==set(prep['input_hashes'])==expected_names
    assert lock['input_hashes']==prep['input_hashes']
    docs={};seed_pairs={};world_records=[]
    ref_parameters={row['id']:row for row in reference['model']['parameters']}
    domains={'power','backup','facility_cooling','equipment_environment','it_service','control_monitoring','space_access','people_tools_work'}
    for world in worlds:
        pair=[]
        for arm in arms:
            name=world['id']+'/'+arm+'.json';raw=blob(PREP+'inputs/'+name)
            assert sha(raw)==lock['input_hashes'][name] and (ROOT/PREP/'inputs'/name).read_bytes()==raw
            doc=json.loads(raw);program=doc['dispatch_program'];policy=program['policy_program']
            assert policy['policy']==arm and program['closure_program'] is None
            without_method=deepcopy(doc);without_method['dispatch_program']['policy_program'].pop('policy')
            pair.append(without_method)
            assert doc['duration_s']==world['duration_s']==10 and doc['maximum_step_s']==plan['maximum_step_s']==.01
            assert program['decision_times_s']==plan['decision_times_s']
            model=doc['model'];parameters={row['id']:row for row in model['parameters']}
            assert len(parameters)==113 and len(model['entities'])==45
            assert model['id']==baseline['id'] and {row['id'] for row in model['domains']}==domains
            for field in ('entities','domains','graphs','site_gaps'):assert model[field]==baseline[field]
            assert set(model['graphs'])=={'physical','functional','control_information','access'}
            block=blueprint[world['family']];level=block[world['level']];recipe=block['shared']
            assert doc['boundary_events']==recipe['events']
            overrides=dict(network_service_capacity=recipe['network_cap'],filter_resistance_multiplier=recipe['filter_multiplier'],
                pump_min_speed=shared['pump_min_speed'],walk_short=shared['walk_short_s'],walk_long=shared['walk_long_s'],inspection_time=shared['professional_work_s'])
            if world['family']=='load-level':overrides['service_demand']=level['offered_demand']
            if world['family']=='reserve-path':overrides['ups_in_service']=level['ups_in_service']
            assert set(parameters)==set(ref_parameters)
            for name,actual in parameters.items():
                expected=ref_parameters[name]
                assert actual['value']==overrides.get(name,expected['value']),(world['id'],name)
                if name not in overrides:assert actual==expected,(world['id'],name)
                else:
                    for field in set(actual)-{'value','basis','source_refs','source_note'}:assert actual[field]==expected[field]
            assert program['sensor_program']['profile']==policy['evidence_projection']['background_sensor_profile']
            assert program['inspection_program']['profile']==policy['evidence_projection']['inspection_profile']
            assert program['intervention_program']==policy['intervention_declaration']
            assert program['intervention_program']['bindings'][0]['setting']==.75
            demand=parameters['service_demand']['value']
            assert all(row['rate']==demand for row in policy['options']['catalog']['demand'])
            assert all(row['consequence_bounds']['unserved_service_unit_s']['interval']==[0,10*demand] for row in policy['options']['catalog']['questions'])
            forecast=level['declared_fallback_capacity'] if world['family']=='model-error' else .75
            assert all(capacity['network']==forecast for local in policy['options']['value_model']['question_models']
                for variant in local['variants'] for capacity in variant['after_capacity'].values())
            meter=next(row for row in program['sensor_program']['profile']['measurements'] if row['id']=='rectifier-meter')
            assert meter['enabled'] is (level['rectifier_meter_enabled'] if world['family']=='sensor-coverage' else True)
            sensor=program['sensor_program']['realization'];portable=program['inspection_program']['realizations']['lookahead-inspect']['seed'];fixed=sensor['seed']
            assert type(portable) is type(fixed) is int and 0<=portable<2**128 and 0<=fixed<2**64
            assert all(value==0 for field in ('biases','noise_bounds','dropout_probabilities') for value in sensor[field].values())
            seeds=(portable,fixed)
            if world['id'] in seed_pairs:assert seed_pairs[world['id']]==seeds
            seed_pairs[world['id']]=seeds
            assert sha(canonical(model))==public_rows[(world['id'],arm)]['model_sha256']
        assert pair[0]==pair[1],world['id']
        docs[world['id']]=pair[0]
        world_records.append(dict(world_id=world['id'],comparison=world['comparison'],family=world['family'],level=world['level'],
            method_difference='dispatch_program.policy_program.policy ONLY',offered_demand=demand,actual_action_capacity=.75,
            forecast_capacity=forecast,rectifier_meter_enabled=meter['enabled'],ups_in_service=parameters['ups_in_service']['value'],
            graphs_sha256=sha(canonical(model['graphs'])),closure_program=None))
    contrasts=[]
    for i in range(0,8,2):
        left,right=worlds[i:i+2];a,b=docs[left['id']],docs[right['id']]
        assert left['comparison']==right['comparison'] and seed_pairs[left['id']]==seed_pairs[right['id']]
        actual=changed(a,b);family=left['family']
        if family=='load-level':
            index=next(i for i,row in enumerate(a['model']['parameters']) if row['id']=='service_demand')
            expected={('model','parameters',index,'value'),('dispatch_program','policy_program','options','catalog','demand',0,'rate'),
                ('dispatch_program','policy_program','options','catalog','questions',0,'consequence_bounds','unserved_service_unit_s','interval',1)}
        elif family=='sensor-coverage':
            index=next(i for i,row in enumerate(a['dispatch_program']['sensor_program']['profile']['measurements']) if row['id']=='rectifier-meter')
            expected={('dispatch_program','sensor_program','profile','measurements',index,'enabled'),
                ('dispatch_program','policy_program','evidence_projection','background_sensor_profile','measurements',index,'enabled')}
        elif family=='reserve-path':
            index=next(i for i,row in enumerate(a['model']['parameters']) if row['id']=='ups_in_service')
            expected={('model','parameters',index,'value')}
        else:
            expected={('dispatch_program','policy_program','options','value_model','question_models',m,'variants',v,'after_capacity',state,'network')
                for m,local in enumerate(a['dispatch_program']['policy_program']['options']['value_model']['question_models'])
                for v,variant in enumerate(local['variants']) for state in variant['after_capacity']}
        assert actual==expected,(family,actual,expected)
        contrasts.append(dict(comparison=left['comparison'],family=family,changed_paths=['/'.join(map(str,path)) for path in sorted(actual,key=str)],
            shared_saved_seed_pair=True))
    block_seeds=[seed_pairs[worlds[i]['id']] for i in range(0,8,2)]
    assert len(set(block_seeds))==len({pair[0] for pair in block_seeds})==len({pair[1] for pair in block_seeds})==4
    assert progress['current_ticket']=='36' and progress['research_trials']['robustness']['attempts']==0
    assert progress['research_trials']['attempts']==164 and progress['research_trials']['charged_s']==1640
    assert progress['research_trials']['remaining_registered_attempts']==16
    assert 164+lock['budget']['attempts']==plan['global_budget']['attempts']==180
    assert 1640+lock['budget']['simulated_charge_s']==plan['global_budget']['simulated_charge_s']==1800
    assert original_primary['status']=='NO_PRACTICAL_GAIN' and original_primary['mean_service_delta_s']==.03515625
    assert not git('diff','--name-only',REVIEWED,SOURCE,'--',
        'evidence/mainline/engineering/36-public-admission/red-01','evidence/mainline/engineering/36-public-admission/green-01',
        'evidence/mainline/engineering/36-public-admission/green-02','docs/mainline/30-comparison-protocol-v1.json',
        'evidence/mainline/research/34-paired-analysis','evidence/mainline/research/35-ablation').strip()
    assert not git('ls-tree','-r','--name-only',SOURCE,'--','evidence/mainline/research/36-robustness/capture-01').strip()
    source_gate=dict(source=SOURCE,execution_source=EXEC,prepared_author_source=prep['source'],
        source_pins=286,original_execution_pins=269,added_executable_paths=sorted(executable-set(old_execution['execution_pins'])),
        original_269_changed_only=sorted(bridge_changes),original_design_pins=61,original_61_changed_only=sorted(design_changes),
        author_preparation_guard_items=300,public_and_authorized_preparation_pins=296,
        interpreter_matches=True,input_hashes=16,complete_prepared_artifacts=18,
        prep_receipt=dict(finite_admission_calls=16,nonce_read_attempts=1,validated_nonce_reads=1,physical_calls=0,selector_calls=0),
        independent_nonce_recomputation=False,independent_nonce_reads=0,
        seed_evidence='Derivation/commitment reader pinned to guarded author source; independent saved-input widths, within-method/within-block equality and four distinct block seeds checked. No nonce or HMAC was read/recomputed by reviewer.',
        original_primary_unchanged=True,physical_capture_slots_at_audited_source=0)
    save('source-freeze-facts.json',source_gate)
    save('input-and-axis-matrix.json',dict(source=SOURCE,worlds=world_records,contrasts=contrasts,
        independent_worlds=8,paired_contrast_blocks=4,methods=arms,physical_slots=16,
        scope='Finite designed robustness contrasts, not16 independent replications or a new confirmation primary.'))
    save('source-and-evidence-hashes.json',hashes)
    save('findings.json',dict(source=SOURCE,findings=[],unresolved=0))
    save('receipt.json',dict(status='PASS_SPEC_SAVED_INPUT_AND_EXECUTION_FREEZE',source=SOURCE,execution_source=EXEC,
        prepared_inputs=16,worlds=8,paired_blocks=4,methods=2,unresolved_findings=0,
        conclusion='No Spec blocker to the original16-slot physical execution after final independent approvals and committed exact execution-lock authorization; no retries or extra slots.',
        authorization_at_audited_revision='Execution lock PENDING_INDEPENDENT_REVIEW; this review is approval evidence, not an already-existing execution authorization.',
        original_primary='UNCHANGED_NO_PRACTICAL_GAIN',unmeasured_endpoints='Generic fault/miss/prevention and formal closure remain NOT_OPERATIONALIZED/NOT_TESTED/NOT_EVALUATED.',
        reviewer_project_calls=0,reviewer_tests=0,reviewer_admissions=0,reviewer_physical_calls=0,
        reviewer_selectors=0,reviewer_inference=0,reviewer_nonce_file_reads=0,reviewer_HMAC_recomputations=0))
    report='''Spec：PASS，固定保存源f1015316、执行源f834ea4d，无未决阻塞。

16输入/8工况/4区组逐份核对通过：方法仅policy不同；四轴仅冻结字段变化；实际动作.75与预测.75/1明确分离，八域四图和closure=None保持。保存种子宽度、组内共享和四组不同均通过；未读nonce或独立重算HMAC。

286执行源码、解释器、16输入哈希、300项作者准备守卫及授权绑定一致；旧269执行pins与61设计pins仅允许已批准闭合修正。旧失败、主要负结果及NA保持。

可在最终独立审批并提交精确执行锁授权后，执行原16槽；预算160秒/160决策，无自动重试。当前锁仍待审批，当前物理运行0。本审查零项目、测试、准入、选择器、物理或nonce调用。
'''
    assert len(report)<400
    with (OUT/'report.md').open('x',encoding='utf-8',newline='\n') as stream:stream.write(report)
except BaseException as error:
    with (OUT/'error.txt').open('x',encoding='utf-8',newline='\n') as stream:stream.write(traceback.format_exc())
    save('failure.json',dict(source=SOURCE,error_type=type(error).__name__,message=str(error),project_calls=0))
    raise
finally:
    manifest=dict(schema='aegisdc-independent-spec-robustness-execution-freeze-v1',source=SOURCE,execution_source=EXEC,
        artifacts={path.name:dict(sha256=sha(path.read_bytes()),bytes=path.stat().st_size) for path in sorted(OUT.iterdir())
            if path.is_file() and path.name!='manifest.json'},excluded=['Self-hash','Runtime caches'])
    save('manifest.json',manifest)
print(json.dumps(dict(status='PASS',source=SOURCE,artifacts=len(manifest['artifacts']),
    manifest_sha256=sha((OUT/'manifest.json').read_bytes()),project_calls=0)))
