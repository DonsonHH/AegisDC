"""Seal saved-input review, preserving the reviewer's wrong-baseline assertion."""
import hashlib
import json
from pathlib import Path
import subprocess

ROOT=Path('C:/Users/Donson/.codex/worktrees/mainline36-robustness/Renly')
OUT=Path(__file__).resolve().parent
SOURCE='f101531642f5808f1af553f4b926dda92341ab42'
EXEC='f834ea4de71a175fc4fa341cc29ed1694280ae0e'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
git=lambda *args:subprocess.check_output(['git',*args],cwd=ROOT)

def save(name,value):
    with (OUT/name).open('x',encoding='utf-8',newline='\n') as stream:
        stream.write(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n')

result=json.loads((OUT/'attempt-02/receipt.json').read_bytes())
assert result['status']=='PASS_SPEC_SAVED_INPUT_AND_EXECUTION_FREEZE' and result['unresolved_findings']==0
failed=json.loads((OUT/'failure.json').read_bytes())
assert failed['error_type']=='AssertionError'
correction=dict(classification='REVIEWER_EXPECTATION_CORRECTION_ONLY',source=SOURCE,
    original_review_failure='First saved-only script compared all entity initial locations to the generic V6 defaults.',
    actual_registered_basis='The frozen26 reference and all16 prepared inputs place worker_cooling and tool_flow_meter at loc_lake. Generic V6 defaults place them at loc_hx. The accepted reference is the required input basis; this is not a robustness contrast or candidate change.',
    corrected_check='Compare entities to the frozen26 reference and domains/graphs/site_gaps to V6. All16 saved inputs pass; original failure/script/manifest remain untouched.',
    original_script_sha256=sha((OUT/'review-inputs.py').read_bytes()),
    corrected_script_sha256=sha((OUT/'review-inputs-corrected.py').read_bytes()),
    original_manifest_sha256=sha((OUT/'manifest.json').read_bytes()),
    successful_manifest_sha256=sha((OUT/'attempt-02/manifest.json').read_bytes()),
    no_project_or_registered_retry=True,project_calls=0,physical_calls=0,nonce_file_reads=0,HMAC_recomputations=0)
save('reviewer-expectation-correction.json',correction)
metadata_candidates=[line for line in git('rev-list','--all').decode().splitlines() if line.startswith('e60')]
assert len(metadata_candidates)==1,metadata_candidates
metadata=metadata_candidates[0]
assert not git('diff','--name-only',SOURCE,metadata,'--','src','scripts','configs',
    'evidence/mainline/research/36-robustness/prepared-01',
    'docs/mainline/evidence/30-robustness-execution-lock.json',
    'docs/mainline/36-prospective-extension.json','docs/mainline/30-comparison-protocol-v1.json').strip()
report=(OUT/'attempt-02/report.md').read_bytes()
with (OUT/'report.md').open('xb') as stream:stream.write(report)
save('receipt.json',dict(**result,reviewer_expectation_failure_preserved=True,
    authoritative_report='report.md',successful_saved_review='attempt-02',metadata_only_compatible_source=metadata,
    scope='Independent saved-input/source approval evidence. Exact final authorization and current-source/input guards must still precede any physical execution.'))
manifest=dict(schema='aegisdc-independent-spec-final-robustness-execution-review-v1',source=SOURCE,execution_source=EXEC,
    authoritative_report='report.md',status='PASS',original_reviewer_failure_preserved=True,
    artifacts={path.relative_to(OUT).as_posix():dict(sha256=sha(path.read_bytes()),bytes=path.stat().st_size)
        for path in sorted(OUT.rglob('*')) if path.is_file() and path!=OUT/'final-manifest.json'},
    excluded=['Self-hash','Runtime caches'])
save('final-manifest.json',manifest)
print(json.dumps(dict(status='PASS',source=SOURCE,artifacts=len(manifest['artifacts']),
    metadata_source=metadata,final_manifest_sha256=sha((OUT/'final-manifest.json').read_bytes()),project_calls=0)))
