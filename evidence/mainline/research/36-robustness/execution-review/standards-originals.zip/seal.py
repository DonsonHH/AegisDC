"""Seal a saved execution-gate review without project calls."""
from pathlib import Path
import hashlib
import json

OUT=Path(__file__).resolve().parent
sha=lambda raw:hashlib.sha256(raw).hexdigest()
assert not (OUT/'manifest.json').exists()
result=json.loads((OUT/'result.json').read_bytes())
assert result['status']=='PASS_TO_AUTHORIZE_ORIGINAL16_PHYSICAL_SLOTS' and result['check_count']==717 and result['remaining_blockers']==[]
receipt={k:result[k] for k in ['status','source','execution_source','preparation_source','execution_lock_sha256','interpreter_sha256','executable_paths','prepared_artifacts','blocks','worlds','guarded_preparation_paths','check_count','remaining_blockers','nonce_evidence_scope','execution_condition','reviewer_activity']}
receipt['schema']='aegisdc-independent-execution-gate-standards-v1'
(OUT/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
files=[]
for path in sorted(OUT.iterdir()):
    if path.is_file() and path.name not in {'manifest.json','seal-verification.json'}:
        raw=path.read_bytes();files.append({'path':path.name,'sha256':sha(raw),'bytes':len(raw)})
manifest={'schema':'aegisdc-independent-review-manifest-v1','source':result['source'],'execution_source':result['execution_source'],'execution_lock_sha256':result['execution_lock_sha256'],'files':files,'excluded':['manifest.json (self)','seal-verification.json (post-seal proof)','runtime caches (none declared)']}
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
for row in json.loads((OUT/'manifest.json').read_bytes())['files']:
    raw=(OUT/row['path']).read_bytes();assert sha(raw)==row['sha256'] and len(raw)==row['bytes']
proof={'status':'PASS','manifest_sha256':sha((OUT/'manifest.json').read_bytes()),'fresh_read_artifacts':len(files),'reviewer_project_calls':0}
(OUT/'seal-verification.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf-8')
print(json.dumps(proof))
