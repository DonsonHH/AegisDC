"""Review saved preparation/freeze bytes; no project imports or nonce access."""
from pathlib import Path
from copy import deepcopy
import hashlib
import json
import subprocess
import sys

ROOT=Path(r"C:\Users\Donson\Documents\ChatGPT\Renly")
WORK=Path(r"C:\Users\Donson\.codex\worktrees\mainline36-robustness\Renly")
OUT=Path(__file__).resolve().parent
SOURCE="f101531642f5808f1af553f4b926dda92341ab42"
EXEC="f834ea4de71a175fc4fa341cc29ed1694280ae0e"
REVIEWED="4bc4323afe600707762b2e0e271b8327e794dc07"
PREP="evidence/mainline/research/36-robustness/prepared-01/"
LOCK="docs/mainline/evidence/30-robustness-execution-lock.json"
APPROVAL="docs/mainline/evidence/36-preparation-authorization.json"
checks=[]
def ck(ok,label):
    checks.append({'label':label,'passed':bool(ok)});assert ok,label
def sha(raw):return hashlib.sha256(raw).hexdigest()
def canonical(value):return json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
def git(*a):return subprocess.check_output(['git','-C',str(ROOT),*a])
def fetch(rev,paths):
    paths=list(dict.fromkeys(paths));raw=subprocess.check_output(['git','-C',str(ROOT),'cat-file','--batch'],input=''.join(rev+':'+p+'\n' for p in paths).encode())
    result={};offset=0
    for p in paths:
        end=raw.index(b'\n',offset);header=raw[offset:end].split();assert header[1]==b'blob',(rev,p,header)
        size=int(header[2]);offset=end+1;result[p]=raw[offset:offset+size];offset+=size+1
    assert offset==len(raw);return result
def blob(rev,p):return fetch(rev,[p])[p]
def doc(rev,p):return json.loads(blob(rev,p))
def diff(a,b,path=''):
    if type(a) is not type(b):return [(path,a,b)]
    if type(a) is dict:
        assert set(a)==set(b),'contrast object keys '+path
        return [v for k in a for v in diff(a[k],b[k],path+'.'+k if path else k)]
    if type(a) is list:
        assert len(a)==len(b),'contrast list length '+path
        return [v for i,(x,y) in enumerate(zip(a,b,strict=True)) for v in diff(x,y,path+'['+str(x.get('id',i) if type(x) is dict else i)+']')]
    return [] if a==b else [(path,a,b)]

lock_bytes=blob(SOURCE,LOCK);lock=json.loads(lock_bytes)
plan=doc(SOURCE,'docs/mainline/30-comparison-protocol-v1.json');phase=plan['phases']['robustness']
ck(lock['execution_source']==EXEC and lock['phase']=='robustness' and lock['schema']=='aegisdc-robustness-execution-lock-v1','exact new robustness source/schema')
ck(lock['budget']==phase['budget']=={'attempts':16,'simulated_charge_s':160,'scheduled_decisions':160},'only original16 slots/160seconds/160decisions')
expected_code={p for p in git('ls-tree','-r','--name-only',EXEC,'--','src','scripts','configs').decode().splitlines() if p.endswith(('.py','.json'))}
ck(set(lock['execution_pins'])==expected_code and len(expected_code)==286,'complete286 executable path roster excludes caches')
execbytes=fetch(EXEC,expected_code);deliverybytes=fetch(SOURCE,expected_code)
for p,digest in lock['execution_pins'].items():
    ck(sha(execbytes[p])==digest and deliverybytes[p]==execbytes[p] and (WORK/p).read_bytes()==execbytes[p],'frozen source/delivery/working raw bytes '+p)
ck(sha(Path(sys.executable).read_bytes())==lock['interpreter_sha256'],'actual interpreter bytes equal frozen interpreter')
for field,path in [('design_lock_sha256','docs/mainline/evidence/30-protocol-lock.json'),('extension_sha256','docs/mainline/36-prospective-extension.json')]:ck(sha(blob(SOURCE,path))==lock[field],'exact governing document '+field)
ck(not git('diff','--name-only',REVIEWED,SOURCE,'--','src','scripts','configs','tests').strip(),'implementation unchanged since independent preparation review')

paths=git('ls-tree','-r','--name-only',SOURCE,'--',PREP).decode().splitlines();saved=fetch(SOURCE,paths)
receipt=json.loads(saved[PREP+'receipt.json']);author=receipt['source'];journal=[json.loads(r) for r in saved[PREP+'attempts.jsonl'].splitlines()]
ck(receipt['status']=='PASS_INPUT_ONLY' and receipt['prepared_inputs']==16 and receipt['physical_calls']==receipt['selector_calls']==receipt['registered_research_trials']==0,'input-only passing terminal; no physical research charge')
ck(receipt['finite_admission_calls']==16 and receipt['nonce_read_attempts']==receipt['nonce_reads']==1 and receipt['nonce_read_completion']=='VALIDATED_RETURN','one private read attempt/validated return and16 finite admissions')
ck(receipt['nonce_reads_scope'].startswith('VALIDATED_READ_RETURNS_ONLY'),'validated return scope remains explicit')
ck(set(paths)=={PREP+n for n in receipt['artifacts']}|{PREP+'receipt.json'} and len(paths)==18,'complete18 durable prepared artifacts; no hidden cache evidence')
for name,digest in receipt['artifacts'].items():ck(sha(saved[PREP+name])==digest and (WORK/PREP/name).read_bytes()==saved[PREP+name],'prepared artifact original/Git/working bytes '+name)
ck((WORK/PREP/'receipt.json').read_bytes()==saved[PREP+'receipt.json'],'prepared terminal byte identity')
ck(len(journal)==10 and [r['status'] for r in journal[:2]]==['STARTED_INPUT_PREPARATION','STARTED_NONCE_READ'] and all(r['source']==author for r in journal[:2]),'single started preparation and private-read lifecycle retained')
ck([r['world_id'] for r in journal[2:]]==[w['id'] for w in phase['worlds']] and all(r['status']=='COMPLETED_INPUT_WORLD' and r['arms']==2 for r in journal[2:]),'all8 worlds completed once, no retry or dropped world')
ck([r['recorded_at_utc'] for r in journal]==sorted(r['recorded_at_utc'] for r in journal),'original journal chronological')
ck(journal[1]['expected_commitment']==doc(SOURCE,'docs/mainline/evidence/30-protocol-lock.json')['commitments_sha256']['robustness'],'logged commitment identity only; nonce not read or derived')
historical=fetch(author,receipt['pins'])
for p,digest in receipt['pins'].items():ck(sha(historical[p])==digest,'actual preparation source/input metadata pin '+p)
phase_metadata={APPROVAL,'docs/mainline/progress.json','evidence/mainline/engineering/36-public-admission/preflight-01.json','evidence/mainline/engineering/36-public-admission/preflight-01.start.json'}
ck(phase_metadata<=set(receipt['pins']),'all four actual phase metadata documents guarded at preparation source')
approval=json.loads(historical[APPROVAL]);public_path='evidence/mainline/engineering/36-public-admission/preflight-01.json'
public=json.loads(historical[public_path]);public_start=json.loads(historical['evidence/mainline/engineering/36-public-admission/preflight-01.start.json'])
ck(approval['status']=='REVIEWED_FOR_INPUT_PREPARATION' and approval['public_preflight_sha256']==sha(historical[public_path]),'governance approval binds exact successful preflight bytes')
ck(approval['source_pins']==public_start['pins'] and all(receipt['pins'][p]==h for p,h in approval['source_pins'].items()),'preparation source-pins identical to independently reviewed public source')
ck(public_start['source']==public['source'] and public['status']=='PASS_PUBLIC_ROBUSTNESS_ADMISSION' and public['finite_admission_calls']==16 and public['physical_calls']==public['selector_calls']==public['nonce_reads']==0,'original unique public16 admission receipt retained')
ck(len(public['rows'])==16 and public['source_guard']=='PASS','all public admission rows and source guard accounted')
for p in ['evidence/mainline/engineering/26-candidate/reference/online-baseline-inspect.json','evidence/mainline/engineering/23-interventions/reference/network-full.json']:
    ck(p in receipt['pins'] and sha(blob(SOURCE,p))==receipt['pins'][p],'both actual evidence templates precisely included '+p)

expected_inputs={w['id']+'/'+a+'.json' for w in phase['worlds'] for a in phase['arms']}
ck(set(receipt['input_hashes'])==set(lock['input_hashes'])==expected_inputs and receipt['input_hashes']==lock['input_hashes'],'original complete16 input roster and hashes locked')
documents={};seed_pairs={};input_records=[];graphs=set()
for world in phase['worlds']:
    arms=[]
    for arm in phase['arms']:
        name=world['id']+'/'+arm+'.json';raw=saved[PREP+'inputs/'+name];value=json.loads(raw)
        ck(sha(raw)==lock['input_hashes'][name],'exact held input '+name)
        ck(value['duration_s']==10 and value['maximum_step_s']==.01 and value['dispatch_program']['closure_program'] is None,'frozen compressed time/null closure '+name)
        ck({r['id'] for r in value['model']['domains']}=={'power','backup','facility_cooling','equipment_environment','it_service','control_monitoring','space_access','people_tools_work'} and len(value['model']['entities'])==45,'complete8-domain facility retained '+name)
        graphs.add(sha(canonical(value['model']['graphs'])))
        view=deepcopy(value);ck(view['dispatch_program']['policy_program'].pop('policy')==arm,'only named unchanged policy assignment '+name);arms.append(canonical(view))
        input_records.append({'name':name,'sha256':sha(raw),'bytes':len(raw)})
        if arm==phase['arms'][0]:documents[world['id']]=value
    ck(arms[0]==arms[1],'entire arm input differs only at declared policy field '+world['id'])
    program=documents[world['id']]['dispatch_program']
    pair=(program['inspection_program']['realizations']['lookahead-inspect']['seed'],program['sensor_program']['realization']['seed'])
    ck(type(pair[0]) is int and 0<=pair[0]<1<<128 and type(pair[1]) is int and 0<=pair[1]<1<<64,'typed128/64-bit seed interface '+world['id'])
    seed_pairs.setdefault(world['comparison'],set()).add(pair)
ck(len(graphs)==1 and len(seed_pairs)==4 and all(len(v)==1 for v in seed_pairs.values()) and len({next(iter(v)) for v in seed_pairs.values()})==4,'graphs unchanged; four distinct paired realizations, no HMAC recomputation')

contrasts=[]
for i in range(0,8,2):
    ref,pert=phase['worlds'][i:i+2];family=ref['family'];left=documents[ref['id']];right=documents[pert['id']]
    delta=diff(left,right);changed={p for p,_,_ in delta}
    if family=='load-level':
        expected={'model.parameters[service_demand].value','dispatch_program.policy_program.options.catalog.demand[0].rate','dispatch_program.policy_program.options.catalog.questions[cooling].consequence_bounds.unserved_service_unit_s.interval[1]'}
        ck(changed==expected and {(a,b) for _,a,b in delta}=={(.75,1.25),(7.5,12.5)},'R1 actual/public demand and consequence-only exact values')
    elif family=='sensor-coverage':
        expected={'dispatch_program.sensor_program.profile.measurements[rectifier-meter].enabled','dispatch_program.policy_program.evidence_projection.background_sensor_profile.measurements[rectifier-meter].enabled'}
        ck(changed==expected and all(a is True and b is False for _,a,b in delta),'R2 actual/public one-meter enabled flags only')
    elif family=='reserve-path':ck(changed=={'model.parameters[ups_in_service].value'} and [(a,b) for _,a,b in delta]==[(1,0)],'R3 effective reserve availability only')
    else:
        ck(family=='model-error' and len(delta)==10 and all(p.startswith('dispatch_program.policy_program.options.value_model.question_models[') and '.after_capacity.' in p and p.endswith('.network') and a==.75 and b==1 for p,a,b in delta),'R4 exact ten forecast-only capacity differences')
        ck(left['dispatch_program']['intervention_program']['bindings'][0]['setting']==right['dispatch_program']['intervention_program']['bindings'][0]['setting']==.75,'R4 real intervention remains .75 at both forecast levels')
    contrasts.append({'block':ref['comparison'],'family':family,'changed_paths':sorted(changed),'count':len(changed)})

progress=doc(SOURCE,'docs/mainline/progress.json');r=progress['research_trials']
ck(progress['current_ticket']=='36' and r['attempts']==164 and r['charged_s']==1640 and r['remaining_registered_attempts']==16 and r['robustness']['attempts']==0,'current cumulative164/1640 and exactly16 unstarted slots')
ck(r['robustness']['materialized'] is True and r['robustness']['inputs']==16 and r['robustness']['execution_source']==EXEC,'prepared lifecycle current metadata correct')
ck(not git('diff','--name-only',REVIEWED,SOURCE,'--','evidence/mainline/research/31-development','evidence/mainline/research/33-confirmation','evidence/mainline/research/34-paired-analysis','evidence/mainline/research/35-ablation').strip(),'all prior registered raw data/results unchanged without rereading them')
ck(not git('ls-tree','-r','--name-only',SOURCE,'--','evidence/mainline/research/36-robustness/capture-01','evidence/mainline/research/36-robustness/execution-validation-01').strip(),'no new actual capture or execution nonce validation yet at saved source')
result={'status':'PASS_TO_AUTHORIZE_ORIGINAL16_PHYSICAL_SLOTS','source':SOURCE,'execution_source':EXEC,'preparation_source':author,'execution_lock_sha256':sha(lock_bytes),'interpreter_sha256':lock['interpreter_sha256'],'executable_paths':286,'prepared_artifacts':18,'inputs':input_records,'contrasts':contrasts,'blocks':4,'worlds':8,'methods':phase['arms'],'guarded_preparation_paths':len(receipt['pins']),'check_count':len(checks),'checks':checks,'remaining_blockers':[],'nonce_evidence_scope':'Only original declared attempt/validated-return receipt and typed seed widths/equality/distinctness checked; private nonce not accessed and HMAC derivation NOT independently recomputed.','execution_condition':'Commit independent execution authorization binding the exact reviewed lock; preserve all286 executable pins/interpreter/16 input hashes, original16-slot budget and recorder failure rules. This reviewer does not execute the capture.','reviewer_activity':{'tests':0,'models':0,'plant':0,'selectors':0,'inference':0,'rng':0,'private_nonce_reads':0,'HMAC_derivations':0,'project_imports':0,'tracked_edits':0}}
(OUT/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:result[k] for k in ['status','source','execution_source','check_count','remaining_blockers','nonce_evidence_scope','execution_condition','reviewer_activity']}))
