"""Seal the saved-results review; never execute project code."""
from pathlib import Path
import hashlib,json,subprocess
ROOT=Path(r"C:\Users\Donson\Documents\ChatGPT\Renly")
OUT=Path(__file__).resolve().parent
sha=lambda raw:hashlib.sha256(raw).hexdigest()
assert not (OUT/'manifest.json').exists()
result=json.loads((OUT/'result.json').read_bytes())
assert result['status']=='PASS_SAVED36_RESULTS_STANDARDS' and result['check_count']==1384 and result['remaining_blockers']==[]
assert len(result['native_members'])==64 and result['integration_intervals']==16142
assert "KeyError: 'tool_work_tool_s'" in (OUT/'review-01.log').read_text(encoding='utf-8-sig')
assert 'AssertionError: R4 first actual selected task kinds robustness-07/inspection' in (OUT/'review-02.log').read_text(encoding='utf-8-sig')
corrections={'classification':'REVIEWER_ONLY_SCHEMA_ASSUMPTIONS','preserved':[{'source':'review-01.py','log':'review-01.log','issue':'Extra tool_work_tool_s subaccount exists in native summary, not in selected audit/readout totals.','correction':'Reconcile that independently integrated subaccount to native summary; keep every actually delivered separate readout total.'},{'source':'review-02.py','log':'review-02.log','issue':'First decision tick was assumed to contain an actual issued work intention. R4 candidate at0s waits, then inspects at1s.','correction':'Classify first actual nonempty work intention using unchanged native inspection/intervention bindings.'}],'passing_source':'review.py','passing_log':'review-03.log','new_project_calls':0,'no_physical_or_saved_analysis_export_repeated':True}
(OUT/'reviewer-corrections.json').write_text(json.dumps(corrections,indent=2)+'\n',encoding='utf-8')
visual={'status':'PASS_ACTUALLY_VIEWED_FINAL_PNG','source':result['source'],'path':'evidence/mainline/research/36-robustness/figures-v3/36-robustness-service-cost.png','sha256':next(r['artifacts']['36-robustness-service-cost.png'] for r in result['figures'] if r['version']=='figures-v3'),'observed':['8 legible condition labels','all16 numerical labels match signed service/labor values','no title/annotation collision','negative extrema fully inside axes','units seconds/person-seconds and signs consistent with README'],'original_v1_v2_failures_preserved':True,'new_render_or_project_calls':0}
(OUT/'visual-qa.json').write_text(json.dumps(visual,indent=2)+'\n',encoding='utf-8')
git=lambda *a:subprocess.check_output(['git','-C',str(ROOT),*a])
metadata=git('rev-parse','c06a37d5').decode().strip()
unchanged_paths=['src','scripts','configs','evidence/mainline/research/36-robustness/capture-01','evidence/mainline/research/36-robustness/analysis-01','evidence/mainline/research/36-robustness/README.md','evidence/mainline/research/36-robustness/figures-v3']
assert not git('diff','--name-only',result['source'],metadata,'--',*unchanged_paths).strip()
(OUT/'delivery-metadata-ack.json').write_text(json.dumps({'source':metadata,'data_review_source':result['source'],'status':'UNCHANGED_REVIEWED_EXECUTABLE_DATA_README_FINAL_FIGURE_BYTES','paths':unchanged_paths,'scope':'Later saved-verifier/format metadata does not alter the reviewed research data. No verifier or analysis was executed by reviewer.'},indent=2)+'\n',encoding='utf-8')
receipt={k:result[k] for k in ['status','source','actual_source','original_data_source','frozen_execution_source','check_count','capture_files','capture_receipt_artifacts','journal_rows','integration_intervals','maximum_independent_energy_residual_J','maximum_independent_mass_residual_kg','service_deltas','mean_over_eight_finite_worlds','original_primary','remaining_blockers','reviewer_activity']}
receipt.update(schema='aegisdc-independent-saved-results-standards-v1',actual_runs=16,native_member_count=64,execution_code_paths=286,later_unchanged_delivery_metadata=metadata)
(OUT/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
files=[]
for p in sorted(OUT.iterdir()):
    if p.is_file() and p.name not in {'manifest.json','seal-verification.json'}:
        raw=p.read_bytes();files.append({'path':p.name,'sha256':sha(raw),'bytes':len(raw)})
manifest={'schema':'aegisdc-independent-review-manifest-v1','source':result['source'],'actual_execution_source':result['actual_source'],'files':files,'excluded':['manifest.json (self)','seal-verification.json (post-seal proof)','runtime caches (none declared)']}
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
for row in json.loads((OUT/'manifest.json').read_bytes())['files']:
    raw=(OUT/row['path']).read_bytes();assert sha(raw)==row['sha256'] and len(raw)==row['bytes']
proof={'status':'PASS','manifest_sha256':sha((OUT/'manifest.json').read_bytes()),'fresh_read_artifacts':len(files),'reviewer_project_calls':0}
(OUT/'seal-verification.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf-8')
print(json.dumps(proof))
