"""Saved native schema inventory; no project imports or execution."""
from pathlib import Path
import hashlib,io,json,subprocess,zipfile
ROOT=Path(r"C:\Users\Donson\Documents\ChatGPT\Renly")
OUT=Path(__file__).resolve().parent
SOURCE='4876491c44035287e1a195e718199c318ed07432'
PACKAGE='evidence/mainline/research/36-robustness/'
git=lambda *a:subprocess.check_output(['git','-C',str(ROOT),*a])
blob=lambda p:git('cat-file','blob',SOURCE+':'+p)
batch=json.loads(blob(PACKAGE+'capture-01/batch.json'));slot=batch['slots'][0]
prefix=PACKAGE+f"capture-01/{slot['index']:02}-{slot['world_id']}-{slot['arm']}/"
with zipfile.ZipFile(io.BytesIO(blob(prefix+'originals.zip'))) as z:
    run=json.loads(z.read('run.json'))
    state=json.loads(z.read('private-state.jsonl').splitlines()[0])
    balance=json.loads(z.read('balances.jsonl').splitlines()[0])
info={'source':SOURCE,'capture_files':len(git('ls-tree','-r','--name-only',SOURCE,'--',PACKAGE+'capture-01').decode().splitlines()),'receipt_artifacts':len(json.loads(blob(PACKAGE+'capture-01/receipt.json'))['artifacts']),'native_run_keys':sorted(run),'identity':{k:(len(v) if k=='files' else v) for k,v in run['code_identity'].items()},'summary':run['summary'],'initial_people_tools_work':state['domains']['people_tools_work'],'first_balance':balance,'work_records':run['work_records'],'work_collections':{k:(v[0] if type(v) is list and v else v if type(v) is dict else len(v) if type(v) is list else v) for k,v in run.items() if 'work' in k and k!='work_records'}}
(OUT/'schema-summary.json').write_text(json.dumps(info,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(info,ensure_ascii=False))
