"""Independent saved36 arithmetic and artifact audit. No project code is imported."""
from pathlib import Path
from collections import Counter,defaultdict
import csv,hashlib,io,json,math,subprocess,sys,zipfile

ROOT=Path(r"C:\Users\Donson\Documents\ChatGPT\Renly")
WORK=Path(r"C:\Users\Donson\.codex\worktrees\mainline36-robustness\Renly")
OUT=Path(__file__).resolve().parent
SOURCE='4876491c44035287e1a195e718199c318ed07432'
ACTUAL='18679d7620385c553041e58065d6c7841faebb15'
ORIGINAL='dfd72f9e090101c60d8491e8012d95c78c1aa94c'
FROZEN='f834ea4de71a175fc4fa341cc29ed1694280ae0e'
PACKAGE='evidence/mainline/research/36-robustness/'
CAPTURE=PACKAGE+'capture-01/'
ANALYSIS=PACKAGE+'analysis-01/'
checks=[]
def ck(ok,label):
    checks.append({'label':label,'passed':bool(ok)});assert ok,label
def sha(raw):return hashlib.sha256(raw).hexdigest()
def canonical(v):return json.dumps(v,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
def same(a,b):return math.isclose(a,b,rel_tol=1e-12,abs_tol=1e-8)
def git(*a):return subprocess.check_output(['git','-C',str(ROOT),*a])
def fetch(rev,paths):
    paths=list(dict.fromkeys(paths));raw=subprocess.check_output(['git','-C',str(ROOT),'cat-file','--batch'],input=''.join(rev+':'+p+'\n' for p in paths).encode())
    result={};offset=0
    for p in paths:
        end=raw.index(b'\n',offset);header=raw[offset:end].split();assert header[1]==b'blob',(rev,p,header)
        size=int(header[2]);offset=end+1;result[p]=raw[offset:offset+size];offset+=size+1
    assert offset==len(raw);return result
def blob(rev,p):return fetch(rev,[p])[p]
def doc(p,rev=SOURCE):return json.loads(blob(rev,p))
def jsonlines(raw):return [json.loads(line) for line in raw.splitlines()]

capture_paths=git('ls-tree','-r','--name-only',SOURCE,'--',CAPTURE).decode().splitlines()
saved=fetch(SOURCE,capture_paths)
receipt=json.loads(saved[CAPTURE+'receipt.json']);batch=json.loads(saved[CAPTURE+'batch.json']);journal=jsonlines(saved[CAPTURE+'attempts.jsonl'])
ck(len(capture_paths)==83 and len(receipt['artifacts'])==82 and set(capture_paths)=={CAPTURE+n for n in receipt['artifacts']}|{CAPTURE+'receipt.json'},'exact83 capture files/82 manifest entries; no invented84th file')
for n,h in receipt['artifacts'].items():ck(sha(saved[CAPTURE+n])==h,'capture raw committed artifact '+n)
ck(not git('diff','--name-only',ORIGINAL,SOURCE,'--',CAPTURE).strip(),'original actual capture unchanged since first data delivery')
ck(receipt['status']=='PASS' and receipt['execution_commit']==batch['execution_commit']==ACTUAL and receipt['source_unchanged'] is True,'exact actual execution and successful unchanged-source receipt')
expected_total=dict(started=16,completed=16,failed=0,interrupted=0,unrun=0,charged_simulated_s=160,charged_scheduled_decisions=160,returned_decisions=160)
ck(receipt['total']==expected_total and receipt['registered_research_trials']==16 and receipt['automatic_retries']==0 and receipt['stop'] is None,'all16 original attempts charged/completed with no retry/failure masking')
ck(len(journal)==32 and [(r['index'],r['status']) for r in journal]==[(i,s) for i in range(1,17) for s in ['STARTED','COMPLETED']],'unique ordered32-row STARTED/terminal journal')
lock=doc('docs/mainline/evidence/30-robustness-execution-lock.json');codepins=lock['execution_pins'];code=fetch(ACTUAL,codepins)
ck(len(codepins)==286 and lock['execution_source']==FROZEN,'frozen286 exact execution paths')
frozen=fetch(FROZEN,codepins);current=fetch(SOURCE,codepins)
for n,h in codepins.items():ck(sha(code[n])==h and frozen[n]==code[n]==current[n] and batch['pins'][n]==h,'frozen/actual/current executable identity '+n)
ck(batch['interpreter_sha256']==lock['interpreter_sha256']==sha(Path(sys.executable).read_bytes()),'actual/frozen interpreter byte identity')
originalpins=fetch(ACTUAL,batch['pins'])
for n,h in batch['pins'].items():ck(sha(originalpins[n])==h,'actual source/complete phase input/governance pin '+n)
authorization=doc('docs/mainline/evidence/36-execution-authorization.json',ACTUAL)
ck(authorization['status']=='REVIEWED_TO_EXECUTE' and authorization['execution_lock_sha256']==sha(blob(ACTUAL,'docs/mainline/evidence/30-robustness-execution-lock.json')),'actual governance binds exact reviewed lock')
ck(b'os.fsync(stream.fileno())' in blob(ACTUAL,'scripts/development_journal.py'),'recorded source uses fsynced append/write/readback recorder')

analysis_paths=git('ls-tree','-r','--name-only',SOURCE,'--',ANALYSIS).decode().splitlines();analysis_raw=fetch(SOURCE,analysis_paths)
manifest=json.loads(analysis_raw[ANALYSIS+'manifest.json'])
ck(set(analysis_paths)=={ANALYSIS+n for n in manifest['artifacts']}|{ANALYSIS+'manifest.json'},'complete saved-analysis durable set')
for n,h in manifest['artifacts'].items():ck(sha(analysis_raw[ANALYSIS+n])==h,'saved analysis artifact hash '+n)
start=json.loads(analysis_raw[ANALYSIS+'start.json']);end=json.loads(analysis_raw[ANALYSIS+'receipt.json'])
ck(start['source']==end['source']==ORIGINAL and end['status']=='PASS_SAVED_ANALYSIS' and end['runs']==16 and end['physical_calls']==end['selector_calls']==0,'saved-only analysis unique source and terminal')
inputs=json.loads(analysis_raw[ANALYSIS+'input-manifest.json']);inputbytes=fetch(ORIGINAL,inputs)
for n,h in inputs.items():ck(sha(inputbytes[n])==h and blob(SOURCE,n)==inputbytes[n],'saved-analysis original input '+n)
rows=json.loads(analysis_raw[ANALYSIS+'run-readout.json']);timing=json.loads(analysis_raw[ANALYSIS+'inspection-timing.json']);result=json.loads(analysis_raw[ANALYSIS+'results.json'])
lookup={(r['world_id'],r['arm']):r for r in rows};ck(len(rows)==len(lookup)==16,'all16 method-run rows present exactly once')
native_members=[];run_results=[];independent={};all_decisions={};first_task_kinds={};total_intervals=0;maximum_energy=maximum_mass=0;found_statuses=set();found_stages=set();observed_timing=[]
labor_fields=['worker_travel_person_s','worker_work_person_s','worker_wait_person_s','access_check_person_s','rendezvous_wait_person_s','queue_wait_person_s','tool_occupation_tool_s','tool_work_tool_s']
for slot in batch['slots']:
    index=slot['index'];prefix=CAPTURE+f"{index:02}-{slot['world_id']}-{slot['arm']}/";key=(slot['world_id'],slot['arm'])
    began=json.loads(saved[prefix+'start.json']);terminal=json.loads(saved[prefix+'terminal.json']);audit=json.loads(saved[prefix+'audit.json']);original=json.loads(saved[prefix+'originals.json'])
    for j,row in enumerate([began,terminal]):
        ledger={k:v for k,v in journal[(index-1)*2+j].items() if k!='recorded_at_utc'}
        ck(row==ledger and all(row[k]==v for k,v in slot.items()) and row['source']==ACTUAL,'exact durable slot/journal/roster identity '+str(index)+'/'+str(j))
    ck(began['charged_simulated_s']==10 and began['charged_scheduled_decisions']==10 and terminal['physical_call_started'] is True and terminal['physical_returned'] is True and terminal['returned_decisions']==10,'charge-before-call and complete returned slot '+str(index))
    for n,h in terminal['artifacts'].items():ck(sha(saved[prefix+n])==h,'terminal declared raw artifact '+str(index)+'/'+n)
    archive=saved[prefix+'originals.zip'];ck(sha(archive)==original['archive_sha256'],'original archive identity '+str(index))
    with zipfile.ZipFile(io.BytesIO(archive)) as z:
        names=z.namelist();ck(len(names)==len(set(names))==4 and set(names)==set(original['members'])=={'scenario.json','run.json','private-state.jsonl','balances.jsonl'},'complete unique4 native members '+str(index))
        raw={n:z.read(n) for n in names}
    for n,h in original['members'].items():ck(sha(raw[n])==h,'native member hash '+str(index)+'/'+n);native_members.append({'slot':index,'member':n,'sha256':h,'bytes':len(raw[n])})
    native=json.loads(raw['run.json']);states=jsonlines(raw['private-state.jsonl']);balances=jsonlines(raw['balances.jsonl']);trace={r['time_s']:r for r in states};total_intervals+=len(balances)
    expected=doc(PACKAGE+'prepared-01/inputs/'+slot['input_member']);ck(canonical(json.loads(raw['scenario.json']))==canonical(expected['model']) and canonical(native['inputs']['dispatch_program'])==canonical(expected['dispatch_program']),'executed actual model/program exact approved held input '+str(index))
    ck(native['code_identity']['git_commit']==ACTUAL and native['code_identity']['implementation_has_changes'] is False and all(codepins[n]==h for n,h in native['code_identity']['files'].items()),'native39-runtime identity within286 outer pins '+str(index))
    ck(len(native['policy_public_decisions'])==10 and native['training_calls']==0 and native['inputs']['dispatch_program']['closure_program'] is None and not audit['hard_violations'],'actual10 decisions, no configured closure or hard violation '+str(index))
    ck(states[0]['time_s']==0 and states[-1]['time_s']==10 and len(states)==len(balances)+1 and len(trace)==len(states),'complete monotonic state/interval clock '+str(index))
    work={w['id']:w for w in native['work_records']};entities={e['id']:e for e in expected['model']['entities']};shifts=expected['dispatch_program']['policy_program']['workforce_profile']['shifts']
    computed=defaultdict(list)
    max_energy=max_mass=0
    for j,b in enumerate(balances):
        left=states[j];right=states[j+1];dt=b['end_s']-b['start_s'];assert b['start_s']==left['time_s'] and b['end_s']==right['time_s'] and 0<dt<=.01000000001
        d=left['domains'];service=d['it_service'];demand=service['demand'];delivered=service['delivered']
        assert 0<=delivered<=demand and delivered<=min(service['capacities'].values())+1e-8
        independently={'demand_service_unit_s':demand*dt,'delivered_service_unit_s':delivered*dt,'service_deficit_time_s':((demand-delivered)/demand*dt if demand else 0)}
        flat=d['people_tools_work'];workers=flat['workers'];tools=flat['tools'];active=set(flat['active_requests']);queued=set(flat['queued_requests'])
        assert not active&queued
        onsite={w for w,v in workers.items() if v['status']=='waiting'}
        waiting=onsite|{r['worker_id'] for task in queued for r in work[task]['crew'] if workers[r['worker_id']]['status']=='idle' and shifts[r['worker_id']][0]<=left['time_s']<shifts[r['worker_id']][1]}
        checking={w for w,v in workers.items() if v.get('stage')=='gate_check'}
        working_jobs={v['request_id'] for v in workers.values() if v['status']=='working'}
        labor={'worker_travel_person_s':sum(v['status']=='travelling' for v in workers.values())*dt,'worker_work_person_s':sum(v['status']=='working' for v in workers.values())*dt,'worker_wait_person_s':len(waiting)*dt,'access_check_person_s':len(checking)*dt,'rendezvous_wait_person_s':(len(onsite)-len(checking))*dt,'queue_wait_person_s':len(waiting-onsite)*dt,'tool_occupation_tool_s':sum(v['reserved_by'] is not None for v in tools.values())*dt,'tool_work_tool_s':sum(v['reserved_by'] in working_jobs for v in tools.values())*dt}
        independently.update(labor)
        for field,value in independently.items():assert same(value,b[field]),(index,j,field,value,b[field]);computed[field].append(value)
        assert same(b['worker_wait_person_s'],b['access_check_person_s']+b['rendezvous_wait_person_s']+b['queue_wait_person_s'])
        blocked=set(d['space_access']['blocked_location_ids'])
        for wid,state in workers.items():
            found_statuses.add(state['status'])
            if 'stage' in state:found_stages.add(state['stage'])
            if state['status']=='working':
                assert state['location_id'] is not None and state['location_id'] not in blocked and state['request_id'] in active
                task=work[state['request_id']];member=next(r for r in task['crew'] if r['worker_id']==wid)
                assert member['qualification_id'] in entities[wid]['qualification_ids'] and shifts[wid][0]<=left['time_s']<shifts[wid][1]
        for tid,tool in tools.items():
            if tool['reserved_by'] is not None:
                assert tool['reserved_by'] in active and tool['carried_by'] in {r['worker_id'] for r in work[tool['reserved_by']]['crew']} and tid in entities[tool['carried_by']]['tool_ids']
        assert min(b['capacity_slack_W'].values())>=-1e-7
        for component,rate in b['component_energy_rates_W'].items():
            residual=b['storage_after_J'][component]-b['storage_before_J'][component]-rate*dt
            assert abs(residual)<1e-4;max_energy=max(max_energy,abs(residual))
        facility=math.fsum(b['storage_after_J'].values())-math.fsum(b['storage_before_J'].values())-b['boundary_input_J']+b['boundary_output_J']
        assert abs(facility)<1e-4;max_energy=max(max_energy,abs(facility))
        for account in b['mass_accounts_kg'].values():
            residual=account['after_kg']-account['before_kg']-account['in_kg']+account['out_kg'];assert abs(residual)<1e-8;max_mass=max(max_mass,abs(residual))
    totals={field:math.fsum(values) for field,values in computed.items()};totals['unserved_service_unit_s']=totals['demand_service_unit_s']-totals['delivered_service_unit_s'];totals['paid_person_s']=math.fsum(totals[k] for k in labor_fields[:3])
    for field,value in totals.items():
        if field in audit['totals']:
            ck(same(value,audit['totals'][field]) and same(value,lookup[key][field]),'flat service/labor independently recomputed '+str(index)+'/'+field)
        else:
            ck(same(value,native['summary'][field]),'extra native-only work subaccount independently recomputed '+str(index)+'/'+field)
    ck(all(same(math.fsum(b[field] for b in balances),native['summary'][field]) for field in ['demand_service_unit_s','delivered_service_unit_s','service_deficit_time_s',*labor_fields]),'whole run summary agrees with saved intervals '+str(index))
    ck(all(same(v,lookup[key][k]) for k,v in audit['totals'].items()),'every separate readout total equals original audit '+str(index))
    ck(lookup[key]['verified_closure']=='NOT_EVALUATED_WITHOUT_POST_ACTION_PROTOCOL' and lookup[key]['generic_fault_confirmation']=='NOT_OPERATIONALIZED' and lookup[key]['misleading_report_rate']=='NOT_OPERATIONALIZED_NO_CUE_TRUTH_MAPPING' and lookup[key]['missed_report_rate']=='NOT_OPERATIONALIZED_NO_OPPORTUNITY_DENOMINATOR' and lookup[key]['pre_failure_prevention']=='NOT_TESTED','unmeasured endpoints remain NA, not zero '+str(index))
    reports=native['inspection_public_feedback'];records={r['id']:r for r in native['inspection_public_snapshot']['records']}
    ck(len({(f['task_id'],f['record_id']) for f in reports})==len(reports),'unique threshold report identities '+str(index))
    for f in reports:
        record=records[f['record_id']];task=work[f['task_id']]
        assert task['status']=='completed' and f['observed_at_s']==task['completed_at_s'] and f['arrived_at_s']<=10
        assert all(f[k]==record[k] for k in ['source_id','target_id','observable_id','provenance','observed_at_s','arrived_at_s','valid_until_s'])
        assert f['scope']=='NAMED_SIGNAL_THRESHOLD_ONLY_NOT_FAULT_DIAGNOSIS' and f['additional_evidence_factor'] is False
        observed_timing.append((slot['world_id'],slot['arm'],f['task_id'],f['record_id'],task['issued_at_s'],f['observed_at_s'],f['arrived_at_s']))
    independent[key]=totals;all_decisions[key]=native['policy_public_decisions']
    first=native['policy_public_decisions'][0]['choice']['work_intention']
    inspection_ids={r['task_id'] for r in native['inspection_public_models']['bindings']}
    action_ids={r['task_id'] for r in native['inputs']['dispatch_program']['intervention_program']['bindings']}
    first_task_kinds[key]=('inspection' if first['id'] in inspection_ids else 'intervention' if first['id'] in action_ids else 'other') if first else 'none'
    maximum_energy=max(maximum_energy,max_energy);maximum_mass=max(maximum_mass,max_mass)
    run_results.append({'index':index,'world_id':key[0],'arm':key[1],'states':len(states),'intervals':len(balances),'independent_totals':totals,'max_independent_energy_residual_J':max_energy,'max_independent_mass_residual_kg':max_mass})

ck(len(native_members)==64 and len(run_results)==16,'all64 native members and16 actual trajectories checked')
ck(len(timing)==len(observed_timing) and {(t['world_id'],t['arm'],t['task_id'],t['record_id'],t['issued_at_s'],t['observed_at_s'],t['arrived_at_s']) for t in timing}==set(observed_timing),'all arrived inspection timing/provenance rows reconcile')
deltas=[]
for p in result['paired']:
    b=independent[(p['world_id'],'one_observation_lookahead')];c=independent[(p['world_id'],'evidence_consistent_contingent')]
    expected={'baseline_deficit_s':b['service_deficit_time_s'],'candidate_deficit_s':c['service_deficit_time_s'],'delta_service_s':b['service_deficit_time_s']-c['service_deficit_time_s'],'extra_paid_person_s':c['paid_person_s']-b['paid_person_s'],'extra_travel_person_s':c['worker_travel_person_s']-b['worker_travel_person_s'],'extra_tool_s':c['tool_occupation_tool_s']-b['tool_occupation_tool_s']}
    ck(all(same(p[k],v) for k,v in expected.items()),'independent complete paired service and costs '+p['world_id']);deltas.append(expected['delta_service_s'])
for c in result['contrasts']:
    ck(same(c['shift_in_delta_service_s'],c['perturbed']['delta_service_s']-c['reference']['delta_service_s']) and same(c['shift_in_extra_paid_person_s'],c['perturbed']['extra_paid_person_s']-c['reference']['extra_paid_person_s']),'predeclared within-block contrasts '+c['comparison'])
ck(len(deltas)==8 and sum(x< -1e-8 for x in deltas)==2 and sum(abs(x)<=1e-8 for x in deltas)==6 and same(math.fsum(deltas)/8,-.084375) and same(math.fsum(deltas)/8,result['mean_over_eight_designed_worlds_service_delta_s']),'eight outcomes descriptive mean -.084375; two worse/six equal')
ck(result['contrast_blocks']==4 and result['worlds']==8 and result['runs']==16 and 'No population interval' in result['independence'],'four finite blocks, never16 independent statistical replications')
primary=doc('evidence/mainline/research/34-paired-analysis/results.json');ck(result['original_primary_unchanged']=={'status':primary['status'],'mean_service_delta_s':primary['mean_service_delta_s'],'worlds':16} and primary['status']=='NO_PRACTICAL_GAIN','original primary remains unchanged')
for name,data in [('run-readout.csv',rows),('paired.csv',result['paired'])]:
    savedrows=list(csv.DictReader(io.StringIO(analysis_raw[ANALYSIS+name].decode('utf-8-sig'))))
    ck(len(savedrows)==len(data),'complete CSV row count '+name)
    for a,b in zip(savedrows,data,strict=True):ck(a=={k:'' if v is None else json.dumps(v,sort_keys=True) if type(v) in (dict,list) else str(v) for k,v in b.items()},'CSV numeric/NA identity '+name+'/'+b['world_id'])
readme=blob(SOURCE,PACKAGE+'README.md').decode()
ck(all(t in readme for t in ['−0.084375','NO_PRACTICAL_GAIN','0.03515625','4个区组','closure_program=None','未操作化或未测','1秒专业工时','不替代']),'README limits/signs/timing/NA/primary explicit')
for world in ['robustness-07','robustness-08']:
    choices=[all_decisions[(world,arm)][0]['choice']['work_intention'] for arm in ['one_observation_lookahead','evidence_consistent_contingent']]
    expected_kind='inspection' if world=='robustness-07' else 'intervention'
    ck(all(c is not None for c in choices) and all(first_task_kinds[(world,arm)]==expected_kind for arm in ['one_observation_lookahead','evidence_consistent_contingent']),'R4 first actual selected task kinds '+world+'/'+expected_kind)
progress=doc('docs/mainline/progress.json')['research_trials'];ck(progress['attempts']==180 and progress['charged_s']==1800 and progress['robustness']['attempts']==16 and progress['robustness']['completed']==16,'cumulative180/1800 accounting closes original budget')

figure_results=[]
for version,toolpath in [('figures','scripts/render_robustness_figures.py'),('figures-v2',PACKAGE+'figure-revision-01/render.py'),('figures-v3',PACKAGE+'figure-revision-02/render.py')]:
    prefix=PACKAGE+version+'/';m=doc(prefix+'manifest.json')
    ck(m['input_sha256']==sha(analysis_raw[ANALYSIS+'results.json']) and m['tool_sha256']==sha(blob(SOURCE,toolpath)) and m['new_model_calls']==0,'figure exact original saved input/tool '+version)
    for n,h in m['artifacts'].items():ck(sha(blob(SOURCE,prefix+n))==h and (WORK/prefix/n).read_bytes()==blob(SOURCE,prefix+n),'figure artifact Git/actual view byte identity '+version+'/'+n)
    figure_results.append({'version':version,'input_sha256':m['input_sha256'],'tool_sha256':m['tool_sha256'],'artifacts':m['artifacts']})
ck(doc(PACKAGE+'figure-revision-01/plan-and-original-qa.json')['status']=='REQUIRES_RENDERING_REVISION' and doc(PACKAGE+'figure-revision-02/qa.json')['status']=='REVISE_OVERLAPPING_EXPLANATORY_ANNOTATION' and doc(PACKAGE+'figure-revision-02/final-visual-qa.json')['status']=='PASS_ACTUALLY_VIEWED_PNG','v1/v2 actual failed QA and separate v3 pass preserved')
audit_result={'status':'PASS_SAVED36_RESULTS_STANDARDS','source':SOURCE,'actual_source':ACTUAL,'original_data_source':ORIGINAL,'frozen_execution_source':FROZEN,'check_count':len(checks),'checks':checks,'capture_files':83,'capture_receipt_artifacts':82,'journal_rows':32,'native_members':native_members,'runs':run_results,'integration_intervals':total_intervals,'maximum_independent_energy_residual_J':maximum_energy,'maximum_independent_mass_residual_kg':maximum_mass,'flat_worker_statuses':sorted(found_statuses),'flat_worker_stages':sorted(found_stages),'service_deltas':deltas,'mean_over_eight_finite_worlds':math.fsum(deltas)/8,'original_primary':'NO_PRACTICAL_GAIN','figures':figure_results,'visual_qa':'Final v3 PNG actually viewed:8 condition labels,16 values, correct units/signs, negative extrema inside bounds and no label/title overlap. Original v1/v2 failed QA retained.','remaining_blockers':[],'reviewer_activity':{'tests':0,'models':0,'plant':0,'selectors':0,'inference':0,'nonce':0,'HMAC':0,'project_imports':0,'tracked_edits':0}}
(OUT/'result.json').write_text(json.dumps(audit_result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:audit_result[k] for k in ['status','check_count','capture_files','journal_rows','integration_intervals','maximum_independent_energy_residual_J','maximum_independent_mass_residual_kg','service_deltas','mean_over_eight_finite_worlds','remaining_blockers','reviewer_activity']}))
