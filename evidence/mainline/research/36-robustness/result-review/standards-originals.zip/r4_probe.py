"""Inspect existing R4 public choice records; do not invoke a policy."""
from pathlib import Path
import io,json,subprocess,zipfile
ROOT=Path(r"C:\Users\Donson\Documents\ChatGPT\Renly")
OUT=Path(__file__).resolve().parent
SOURCE='4876491c44035287e1a195e718199c318ed07432'
PACKAGE='evidence/mainline/research/36-robustness/'
blob=lambda p:subprocess.check_output(['git','-C',str(ROOT),'cat-file','blob',SOURCE+':'+p])
batch=json.loads(blob(PACKAGE+'capture-01/batch.json'));rows=[]
for slot in batch['slots'][12:]:
    path=PACKAGE+f"capture-01/{slot['index']:02}-{slot['world_id']}-{slot['arm']}/originals.zip"
    with zipfile.ZipFile(io.BytesIO(blob(path))) as z:run=json.loads(z.read('run.json'))
    rows.append({'index':slot['index'],'world':slot['world_id'],'arm':slot['arm'],'choices':[{'as_of_s':d.get('as_of_s'), 'keys':list(d),'chosen_candidate_id':d['choice']['chosen_candidate_id'],'intention':d['choice']['work_intention']} for d in run['policy_public_decisions'][:3]],'inspection_binding_task_ids':[r['task_id'] for r in run['inspection_public_models']['bindings']],'intervention_binding_task_ids':[r['task_id'] for r in run['inputs']['dispatch_program']['intervention_program']['bindings']],'actual_work':[{'id':r['id'],'status':r['status'],'issued_at_s':r['issued_at_s']} for r in run['work_records']]})
(OUT/'r4-choice-records.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(rows,ensure_ascii=False))
