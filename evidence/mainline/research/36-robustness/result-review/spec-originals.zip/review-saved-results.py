"""Independent saved-native arithmetic and reporting review; never run project code."""
from collections import Counter,defaultdict
import csv
from datetime import datetime,timezone
from fractions import Fraction
import hashlib
import io
import json
import math
from pathlib import Path
import subprocess
import traceback
import zipfile

ROOT=Path('C:/Users/Donson/.codex/worktrees/mainline36-robustness/Renly')
OUT=Path(__file__).resolve().parent
PIN='4876491c44035287e1a195e718199c318ed07432'
EXEC='18679d7620385c553041e58065d6c7841faebb15'
RAW='dfd72f9e090101c60d8491e8012d95c78c1aa94c'
PACKAGE='evidence/mainline/research/36-robustness/'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
git=lambda *args:subprocess.check_output(['git',*args],cwd=ROOT)
hashes={}

def blob(path,source=PIN):
    raw=git('show',source+':'+path)
    hashes[source+':'+path]=dict(sha256=sha(raw),bytes=len(raw))
    return raw

def read(path,source=PIN):return json.loads(blob(path,source))

def save(name,value):
    with (OUT/name).open('x',encoding='utf-8',newline='\n') as stream:
        stream.write(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n')

def close(a,b):assert math.isclose(a,b,rel_tol=0,abs_tol=1e-8),(a,b)

def pincheck(source,expected):
    raw=subprocess.check_output(['git','cat-file','--batch'],cwd=ROOT,input=''.join(source+':'+n+'\n' for n in expected).encode())
    offset=0
    for path,value in expected.items():
        end=raw.index(b'\n',offset);header=raw[offset:end].split()
        assert len(header)==3 and header[1]==b'blob',path
        size=int(header[2]);assert sha(raw[end+1:end+1+size])==value,(source,path)
        offset=end+size+2
    assert offset==len(raw)

def csvcheck(raw,records):
    parsed=csv.DictReader(io.StringIO(raw.decode('utf-8-sig')))
    assert parsed.fieldnames==list(records[0])
    assert list(parsed)==[{key:'' if value is None else json.dumps(value,sort_keys=True)
        if isinstance(value,(list,dict)) else str(value) for key,value in row.items()} for row in records]

save('start.json',dict(source=PIN,actual_execution=EXEC,raw_commit=RAW,
    started_utc=datetime.now(timezone.utc).isoformat(),scope='SAVED_NATIVE_TRACE_AND_ARITHMETIC_ONLY'))
try:
    receipt=read(PACKAGE+'capture-01/receipt.json');batch=read(PACKAGE+'capture-01/batch.json')
    lock=read('docs/mainline/evidence/30-robustness-execution-lock.json')
    author=read('docs/mainline/evidence/36-execution-authorization.json')
    plan=read('docs/mainline/30-comparison-protocol-v1.json');worlds=plan['phases']['robustness']['worlds']
    assert receipt['status']=='PASS' and receipt['source_unchanged'] is True
    assert receipt['execution_commit']==batch['execution_commit']==EXEC
    assert receipt['total']==dict(started=16,completed=16,failed=0,interrupted=0,unrun=0,
        charged_simulated_s=160,charged_scheduled_decisions=160,returned_decisions=160)
    assert receipt['automatic_retries']==batch['automatic_retries']==0
    assert receipt['llm_calls']==receipt['training_calls']==0
    assert len(lock['execution_pins'])==286
    pincheck(EXEC,lock['execution_pins']);pincheck(PIN,lock['execution_pins']);pincheck(EXEC,batch['pins'])
    assert author['status']=='REVIEWED_TO_EXECUTE' and author['execution_lock_sha256']==sha(blob('docs/mainline/evidence/30-robustness-execution-lock.json'))
    for path,value in receipt['artifacts'].items():assert sha(blob(PACKAGE+'capture-01/'+path))==value
    assert not git('diff','--name-only',RAW,PIN,'--',PACKAGE+'capture-01').strip()
    before=read('docs/mainline/progress.json',EXEC)['research_trials']
    assert before['attempts']==164 and before['charged_s']==1640
    analysis=read(PACKAGE+'analysis-01/results.json');rows=read(PACKAGE+'analysis-01/run-readout.json')
    timing=read(PACKAGE+'analysis-01/inspection-timing.json')
    analysis_receipt=read(PACKAGE+'analysis-01/receipt.json');analysis_manifest=read(PACKAGE+'analysis-01/manifest.json')
    assert analysis_receipt['source']==analysis['source']==RAW
    for path,value in analysis_manifest['artifacts'].items():assert sha(blob(PACKAGE+'analysis-01/'+path))==value
    inputs=read(PACKAGE+'analysis-01/input-manifest.json')
    assert len(inputs)==69
    for path,value in inputs.items():assert sha(blob(path,RAW))==value
    csvcheck(blob(PACKAGE+'analysis-01/run-readout.csv'),rows)
    csvcheck(blob(PACKAGE+'analysis-01/paired.csv'),analysis['paired'])
    row_index={(row['world_id'],row['arm']):row for row in rows}
    journal=[json.loads(line) for line in blob(PACKAGE+'capture-01/attempts.jsonl').splitlines()]
    assert len(journal)==32 and len(batch['slots'])==16 and len(row_index)==16
    independent={};native_summary=[];expected_timing=[];archive_members={}
    point_count=interval_count=0
    for ordinal,slot in enumerate(batch['slots'],1):
        assert slot['index']==ordinal and slot['duration_s']==10 and slot['scheduled_decisions']==10
        prefix=PACKAGE+f"capture-01/{ordinal:02}-{slot['world_id']}-{slot['arm']}/"
        began=read(prefix+'start.json');terminal=read(prefix+'terminal.json');audit=read(prefix+'audit.json')
        for recorded,saved,status in ((journal[(ordinal-1)*2],began,'STARTED'),(journal[(ordinal-1)*2+1],terminal,'COMPLETED')):
            assert {k:v for k,v in recorded.items() if k!='recorded_at_utc'}==saved
            assert saved['status']==status and saved['source']==EXEC
            assert all(saved[k]==v for k,v in slot.items())
        assert began['charged_simulated_s']==10 and began['charged_scheduled_decisions']==10
        assert terminal['physical_call_started'] is terminal['physical_returned'] is True
        assert terminal['returned_decisions']==10 and not audit['hard_violations']
        for path,value in terminal['artifacts'].items():assert sha(blob(prefix+path))==value
        original=read(prefix+'originals.json');raw_archive=blob(prefix+'originals.zip')
        assert sha(raw_archive)==original['archive_sha256']
        with zipfile.ZipFile(io.BytesIO(raw_archive)) as z:
            assert sorted(z.namelist())==sorted(['scenario.json','run.json','private-state.jsonl','balances.jsonl'])
            members={name:z.read(name) for name in z.namelist()}
        assert {name:sha(raw) for name,raw in members.items()}==original['members']
        archive_members[prefix+'originals.zip']={name:dict(sha256=sha(raw),bytes=len(raw)) for name,raw in members.items()}
        native=json.loads(members['run.json'])
        trace=[json.loads(line) for line in members['private-state.jsonl'].splitlines()]
        balances=[json.loads(line) for line in members['balances.jsonl'].splitlines()]
        point_count+=len(trace);interval_count+=len(balances)
        prepared=read(PACKAGE+'prepared-01/inputs/'+slot['input_member'])
        assert sha(blob(PACKAGE+'prepared-01/inputs/'+slot['input_member']))==slot['input_sha256']
        assert json.loads(members['scenario.json'])==prepared['model']
        assert native['inputs']['dispatch_program']==prepared['dispatch_program']
        assert native['inputs']['boundary_events']==prepared['boundary_events']
        assert native['code_identity']['git_commit']==EXEC and native['code_identity']['implementation_has_changes'] is False
        assert all(lock['execution_pins'][name]==value for name,value in native['code_identity']['files'].items())
        assert native['inputs']['dispatch_program']['closure_program'] is None
        assert native['model_calls']==native['training_calls']==0
        for name,entry in native['artifacts'].items():assert sha(members[name])==entry['sha256']
        assert len(trace)==len(balances)+1 and trace[0]['time_s']==0 and trace[-1]['time_s']==10
        program=native['inputs']['dispatch_program'];tasks={row['id']:row for row in native['work_records']}
        shifts=program['policy_program']['workforce_profile']['shifts']
        values=defaultdict(list)
        for left,right,balance in zip(trace,trace[1:],balances):
            at=left['time_s'];dt=right['time_s']-at
            assert balance['start_s']==at and balance['end_s']==right['time_s'] and 0<dt<=.01000001
            service=left['domains']['it_service'];demand=service['demand'];delivered=service['delivered']
            assert 0<=delivered<=demand and delivered<=min(service['capacities'].values())+1e-8
            assert demand==next(row['value'] for row in prepared['model']['parameters'] if row['id']=='service_demand')
            rates=dict(demand_service_unit_s=demand,delivered_service_unit_s=delivered,
                service_deficit_time_s=(demand-delivered)/demand if demand else 0)
            crew=left['domains']['people_tools_work'];workers=crew['workers']
            onsite_wait={name for name,row in workers.items() if row['status']=='waiting'}
            queue_wait={role['worker_id'] for task in crew['queued_requests'] for role in tasks[task]['crew']
                if workers[role['worker_id']]['status']=='idle' and shifts[role['worker_id']][0]<=at<shifts[role['worker_id']][1]}
            checking=sum(row.get('stage')=='gate_check' for row in workers.values())
            rates.update(worker_travel_person_s=sum(row['status']=='travelling' for row in workers.values()),
                worker_work_person_s=sum(row['status']=='working' for row in workers.values()),
                worker_wait_person_s=len(onsite_wait|queue_wait),access_check_person_s=checking,
                rendezvous_wait_person_s=len(onsite_wait)-checking,queue_wait_person_s=len(queue_wait-onsite_wait),
                tool_occupation_tool_s=sum(row['reserved_by'] is not None for row in crew['tools'].values()))
            assert min(rates.values())>=0
            for name,rate in rates.items():
                amount=rate*dt;close(amount,balance[name]);values[name].append(amount)
        actual={name:math.fsum(contribution) for name,contribution in values.items()}
        actual['unserved_service_unit_s']=actual['demand_service_unit_s']-actual['delivered_service_unit_s']
        actual['paid_person_s']=math.fsum(actual[name] for name in ('worker_travel_person_s','worker_work_person_s','worker_wait_person_s'))
        row=row_index[(slot['world_id'],slot['arm'])]
        for name,value in actual.items():
            close(value,audit['totals'][name]);close(value,row[name])
            if name in native['summary']:close(value,native['summary'][name])
        policy=native['policy_public_decisions']
        assert len(policy)==10 and [decision['frame']['as_of_s'] for decision in policy]==plan['decision_times_s']
        issued=[dict(time_s=decision['frame']['as_of_s'],candidate_id=decision['choice']['chosen_candidate_id']) for decision in policy if decision['choice']['chosen_candidate_id'] is not None]
        readings=native['inspection_public_feedback'];records={r['id']:r for r in native['inspection_public_snapshot']['records']}
        bindings={binding['task_id']:binding for binding in native['inspection_public_models']['bindings']}
        findings=Counter()
        for reading in readings:
            record=records[reading['record_id']];task=tasks[reading['task_id']];binding=bindings[reading['task_id']]
            assert reading['scope']=='NAMED_SIGNAL_THRESHOLD_ONLY_NOT_FAULT_DIAGNOSIS' and reading['additional_evidence_factor'] is False
            assert task['status']=='completed' and task['completed_at_s']==reading['observed_at_s']
            for name in ('source_id','target_id','observable_id','provenance','observed_at_s','arrived_at_s','valid_until_s'):
                assert reading[name]==record[name]
            assert reading['record_id']==binding['record_id'] and reading['provenance']==binding['provenance']
            expected='UNCONFIRMED'
            if record['quality']['status']=='bounded':
                value,error,threshold=map(Fraction,(record['value'],record['quality']['error_bound'],binding['confirmation_threshold']))
                if value-error>=threshold:expected='CONFIRMED_AT_OR_ABOVE_THRESHOLD'
                elif value+error<threshold:expected='CONFIRMED_BELOW_THRESHOLD'
            assert reading['confirmation']==expected
            availability='missing' if record['value'] is None else 'expired' if record['valid_until_s'] is not None and 10>=record['valid_until_s'] else 'current'
            assert reading['availability']==record['availability']==availability
            assert reading['current_confirmation'] is (availability=='current' and expected!='UNCONFIRMED')
            findings[expected]+=1
            expected_timing.append(dict(world_id=slot['world_id'],arm=slot['arm'],task_id=reading['task_id'],record_id=reading['record_id'],
                issued_at_s=task['issued_at_s'],observed_at_s=reading['observed_at_s'],arrived_at_s=reading['arrived_at_s'],
                issue_to_report_s=reading['arrived_at_s']-task['issued_at_s'],valid_until_s=reading['valid_until_s'],
                source_id=reading['source_id'],target_id=reading['target_id'],observable_id=reading['observable_id'],provenance=reading['provenance'],
                historical_threshold_finding=expected,current_confirmation=reading['current_confirmation'],scope=reading['scope']))
        assert row['issued_inspection_tasks']==len(set(tasks)&set(bindings))
        assert row['completed_inspections']==sum(task['status']=='completed' for name,task in tasks.items() if name in bindings)
        assert row['task_dispositions']==dict(Counter(task['status'] for task in tasks.values()))
        assert row['arrived_inspection_feedback']==len(readings)
        assert row['historical_named_threshold_findings']==sum(value for key,value in findings.items() if key!='UNCONFIRMED')
        assert row['current_named_threshold_findings']==sum(reading['current_confirmation'] for reading in readings)
        assert row['unconfirmed_readings']==findings['UNCONFIRMED']
        counters=Counter()
        for computation in native['policy_computation_audit']:counters.update(computation['model_evaluations'])
        assert row['selector_instants']==len(native['policy_computation_audit'])==10 and row['model_evaluations']==dict(counters)
        close(row['wall_compute_s'],math.fsum(item['elapsed_ns'] for item in native['policy_computation_audit'])/1e9)
        assert row['structural_validation_counter']=='NOT_INSTRUMENTED'
        for name,expected in [('generic_fault_confirmation','NOT_OPERATIONALIZED'),('misleading_report_rate','NOT_OPERATIONALIZED_NO_CUE_TRUTH_MAPPING'),
            ('missed_report_rate','NOT_OPERATIONALIZED_NO_OPPORTUNITY_DENOMINATOR'),('pre_failure_prevention','NOT_TESTED'),
            ('verified_closure','NOT_EVALUATED_WITHOUT_POST_ACTION_PROTOCOL')]:assert row[name]==expected
        effects=[event for event in native['intervention_private_audit']['events'] if event['outcome']=='APPLIED']
        assert row['applied_effects']==len(effects)==len(audit['applied_effects'])
        assert all(event['new_value']==.75 for event in effects)
        assert all(item['risk_closed'] is False for item in native['intervention_public_feedback'])
        independent[(slot['world_id'],slot['arm'])]=actual
        native_summary.append(dict(index=ordinal,world_id=slot['world_id'],arm=slot['arm'],trace_points=len(trace),intervals=len(balances),
            totals=actual,issued=issued,applied_effects=len(effects),actual_action_capacity=.75,
            forecast_capacities=sorted({capacity['network'] for local in program['policy_program']['options']['value_model']['question_models'] for variant in local['variants'] for capacity in variant['after_capacity'].values()})))
    assert expected_timing==timing
    paired=[]
    for world in worlds:
        baseline,candidate=(independent[(world['id'],arm)] for arm in ('one_observation_lookahead','evidence_consistent_contingent'))
        paired.append(dict(world_id=world['id'],comparison=world['comparison'],family=world['family'],level=world['level'],
            baseline_deficit_s=baseline['service_deficit_time_s'],candidate_deficit_s=candidate['service_deficit_time_s'],
            delta_service_s=baseline['service_deficit_time_s']-candidate['service_deficit_time_s'],
            extra_paid_person_s=candidate['paid_person_s']-baseline['paid_person_s'],
            extra_travel_person_s=candidate['worker_travel_person_s']-baseline['worker_travel_person_s'],
            extra_tool_s=candidate['tool_occupation_tool_s']-baseline['tool_occupation_tool_s']))
    for actual,expected in zip(paired,analysis['paired']):
        for key,value in actual.items():close(value,expected[key]) if isinstance(value,(int,float)) else None
        assert all(actual[key]==expected[key] for key in ('world_id','comparison','family','level'))
    contrasts=[]
    for i in range(0,8,2):
        reference,perturbed=paired[i:i+2]
        actual=dict(comparison=reference['comparison'],family=reference['family'],
            shift_in_delta_service_s=perturbed['delta_service_s']-reference['delta_service_s'],
            shift_in_extra_paid_person_s=perturbed['extra_paid_person_s']-reference['extra_paid_person_s'])
        contrasts.append(actual)
        close(actual['shift_in_delta_service_s'],analysis['contrasts'][i//2]['shift_in_delta_service_s'])
        close(actual['shift_in_extra_paid_person_s'],analysis['contrasts'][i//2]['shift_in_extra_paid_person_s'])
    mean=math.fsum(row['delta_service_s'] for row in paired)/8
    close(mean,-.084375);close(mean,analysis['mean_over_eight_designed_worlds_service_delta_s'])
    assert analysis['original_primary_unchanged']==dict(status='NO_PRACTICAL_GAIN',mean_service_delta_s=.03515625,worlds=16)
    assert sum(row['delta_service_s']<-.00000001 for row in paired)==2
    assert sum(abs(row['delta_service_s'])<=.00000001 for row in paired)==6
    for record in native_summary:
        if record['world_id']=='robustness-07':assert record['issued'][0]['candidate_id']=='first-inspection'
        if record['world_id']=='robustness-08':assert record['issued'][0]['candidate_id']=='first-action' and record['applied_effects']==1
    figures=[]
    for version,tool in [('figures','scripts/render_robustness_figures.py'),
        ('figures-v2',PACKAGE+'figure-revision-01/render.py'),('figures-v3',PACKAGE+'figure-revision-02/render.py')]:
        manifest=read(PACKAGE+version+'/manifest.json')
        assert manifest['input_sha256']==sha(blob(PACKAGE+'analysis-01/results.json'))
        assert manifest['tool_sha256']==sha(blob(tool))
        for name,value in manifest['artifacts'].items():assert sha(blob(PACKAGE+version+'/'+name))==value
        assert manifest['new_model_calls']==0
        figures.append(dict(version=version,input_sha256=manifest['input_sha256'],tool_sha256=manifest['tool_sha256'],artifacts=manifest['artifacts']))
    readme=blob(PACKAGE+'README.md').decode();verifier=blob(PACKAGE+'tools/verify_saved.py').decode()
    assert '−0.084375' in readme and 'NO_PRACTICAL_GAIN' in readme and '4.975 / 5.275' in readme
    assert '不是现场估计' in readme and '不能当作零' in readme and '碰巧改善' in readme
    assert "import argparse,hashlib,io,json,math,subprocess,sys,zipfile" in verifier
    assert 'simulate_scenario(' not in verifier and 'hmac.' not in verifier and '_read_nonce(' not in verifier
    assert not git('diff','--name-only',EXEC,PIN,'--','src','scripts','configs').strip()
    save('independent-native-facts.json',dict(source=PIN,execution_source=EXEC,raw_source=RAW,native_members=64,
        trace_points=point_count,balance_intervals=interval_count,runs=native_summary,paired=paired,contrasts=contrasts,
        mean_over_eight_designed_worlds_service_delta_s=mean,cumulative_registered_runs=180,cumulative_charged_s=1800,
        primary_unchanged=analysis['original_primary_unchanged'],scope='Finite descriptive contrasts; no population inference or new primary classification.'))
    save('figure-and-report-review.json',dict(source=PIN,status='PASS',figures=figures,
        viewed_by_spec_reviewer=PACKAGE+'figures-v3/36-robustness-service-cost.png',
        viewed_png_sha256='eb189e76c9ac63603d0d777d413b5252181852a0b1d138d4b6d6e8299d4f2669',
        visual_findings='8 condition labels and numeric values in both panels; signs/units match saved data; no clipping/title collision. Blue/orange condition semantics match README.',
        original_v1_v2_and_failed_QA_preserved=True,readme='Finite/no-field scope, negative results, actual-vs-forecast R4 and unmeasured endpoints accurately stated.',
        saved_verifier='Static only: standard-library saved hash/native arithmetic checks; no project simulation, selector, nonce or HMAC calls. Its proposed fresh execution was not invoked by this reviewer.'))
    save('source-and-evidence-hashes.json',dict(files=hashes,native_archives=archive_members))
    save('findings.json',dict(source=PIN,findings=[],unresolved=0))
    save('receipt.json',dict(status='PASS_SPEC_SAVED_RESULTS_AND_REPORT',source=PIN,execution_source=EXEC,
        native_archives=16,native_members=64,paired_worlds=8,contrast_blocks=4,unresolved=0,
        independent_service_and_actor_cost_integration=True,source_pins=286,journal_rows=32,
        original_primary_unchanged=True,figures_v3_actually_viewed=True,
        project_calls=0,tests=0,model_calls=0,selector_calls=0,physical_calls=0,nonce_file_reads=0,HMAC_recomputations=0,analysis_runner_calls=0))
    report='''Spec：PASS，固定保存源4876491c、实际执行18679d76，无未决阻塞。

16份原生轨迹的服务、移动/工作/等待及工具占用逐段独立积分，与审计、读出和8配对/4区组差一致。32条生命周期、286源码、16次/160秒/160决策及累计180次/1800秒正确，零失败或重试。

候选在两个工况较差、六个相同；有限均值−0.084375秒。R2节省只在表计启用时出现；R4两法首次选择由检查变处置，真实容量仍.75。原16工况主要负结果和未测NA保持。

README无越界；v3图已实际查看，数据/工具哈希及标签单位吻合，v1/v2碰撞记录保留。新增保存校验器仅静态审查。本审查未调用项目、测试、模型、选择器、nonce或分析器。
'''
    assert len(report)<400
    with (OUT/'report.md').open('x',encoding='utf-8',newline='\n') as stream:stream.write(report)
except BaseException as error:
    with (OUT/'error.txt').open('x',encoding='utf-8',newline='\n') as stream:stream.write(traceback.format_exc())
    save('failure.json',dict(source=PIN,error_type=type(error).__name__,message=str(error),project_calls=0))
    raise
finally:
    manifest=dict(schema='aegisdc-independent-spec-saved-robustness-results-v1',source=PIN,execution_source=EXEC,
        artifacts={path.name:dict(sha256=sha(path.read_bytes()),bytes=path.stat().st_size)
            for path in sorted(OUT.iterdir()) if path.is_file() and path.name!='manifest.json'},excluded=['Self-hash','Runtime caches'])
    save('manifest.json',manifest)
print(json.dumps(dict(status='PASS',source=PIN,trace_points=point_count,balance_intervals=interval_count,
    manifest_sha256=sha((OUT/'manifest.json').read_bytes()),project_calls=0)))
