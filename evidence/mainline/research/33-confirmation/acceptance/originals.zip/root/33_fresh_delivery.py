"""Verify committed confirmation originals in a distinct checkout without running models."""
import argparse,hashlib,json,subprocess
from pathlib import Path
from zipfile import ZipFile
p=argparse.ArgumentParser();p.add_argument('checkout',type=Path);p.add_argument('--delivery',required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
root=a.checkout.resolve()
def git(*args):return subprocess.check_output(['git',*args],cwd=root)
def read(path):return json.loads(path.read_bytes())
def sha(raw):return hashlib.sha256(raw).hexdigest()
assert git('rev-parse','HEAD').decode().strip()==a.delivery and not git('status','--porcelain')
base=root/'evidence/mainline/research/33-confirmation';capture=base/'capture-01'
batch=read(capture/'batch.json');receipt=read(capture/'receipt.json');source=batch['execution_commit']
subprocess.run(['git','merge-base','--is-ancestor',source,a.delivery],cwd=root,check=True)
declared={path.relative_to(root).as_posix() for path in base.rglob('*') if path.is_file()}
declared.add('docs/mainline/evidence/33.json')
names=sorted(set(batch['pins'])|declared)
raw=subprocess.check_output(['git','cat-file','--batch'],cwd=root,
    input=''.join(a.delivery+':'+n+'\n' for n in names).encode())
offset=0;blobs={}
for name in names:
    end=raw.index(b'\n',offset);header=raw[offset:end].split();assert len(header)==3 and header[1]==b'blob'
    start=end+1;size=int(header[2]);blob=raw[start:start+size];offset=start+size+1
    assert blob==(root/name).read_bytes(),name
    blobs[name]=sha(blob)
assert offset==len(raw)
assert all(blobs[n]==h for n,h in batch['pins'].items())
members=archives=0
runtime={n:h for n,h in batch['pins'].items() if n.startswith('src/aegis_dc/') and n.endswith('.py') or n=='src/patrol_rsi/contracts.py'}
for slot in batch['slots']:
    case=capture/f"{slot['index']:02}-{slot['world_id']}-{slot['arm']}"
    terminal=read(case/'terminal.json');assert terminal['status']=='COMPLETED'
    manifest=read(case/'originals.json');assert sha((case/'originals.zip').read_bytes())==manifest['archive_sha256']
    with ZipFile(case/'originals.zip') as archive:
        assert len(archive.namelist())==len(manifest['members'])==4
        data={n:archive.read(n) for n in archive.namelist()}
    assert set(data)==set(manifest['members']) and all(sha(b)==manifest['members'][n] for n,b in data.items())
    run=json.loads(data['run.json']);assert run['code_identity']['git_commit']==source
    assert run['code_identity']['files']==runtime and run['code_identity']['implementation_has_changes'] is False
    for n,value in run['artifacts'].items():assert sha(data[n])==value['sha256']
    archives+=1;members+=len(data)
actual={p.relative_to(capture).as_posix() for p in capture.rglob('*') if p.is_file()}
assert actual==set(receipt['artifacts'])|{'receipt.json'}
assert all(sha((capture/n).read_bytes())==h for n,h in receipt['artifacts'].items())
support=read(base/'support/manifest.json')
assert sha((base/'support/originals.zip').read_bytes())==support['archive_sha256']
with ZipFile(base/'support/originals.zip') as z:
    assert len(z.namelist())==len(support['members']) and set(z.namelist())==set(support['members'])
    assert all(sha(z.read(n))==h for n,h in support['members'].items())
value=dict(status='PASS_EXACT_FRESH_CONFIRMATION_DELIVERY',delivery=a.delivery,execution_source=source,
    native_archives=archives,native_members=members,declared_delivery_files=len(declared),source_and_input_pins=len(batch['pins']),
    working_tree='CLEAN',new_physical_calls=0,new_selector_calls=0,new_seed_reads=0)
with a.output.open('x',encoding='utf-8',newline='\n') as f:json.dump(value,f,indent=2);f.write('\n')
print(json.dumps(value))
