import json,hashlib,subprocess
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
root=Path(__file__).resolve().parents[1]
read=lambda p:json.loads(p.read_bytes())
sha=lambda b:hashlib.sha256(b).hexdigest()
def write(p,obj):p.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
spec=read(root/'.work/33-spec-review-01/saved-receipt.json');standards=read(root/'.work/33-standards-review-01/saved-report.json')
assert spec['findings']==standards['hard_findings']==standards['advisory_smell_findings']==[]
assert spec['delivery']==standards['delivery']=='bcc3c42cdd6842a1d7ff3fdbc4e89e756f29ffdc'
files={}
for directory in ('33-spec-review-01','33-standards-review-01'):
    folder=root/'.work'/directory
    assert (folder/'manifest.json').is_file()
    for p in folder.iterdir():
        if p.is_file():files[directory+'/'+p.name]=p.read_bytes()
for name in ('33-fresh-data-proof-01.json','33_fresh_delivery.py','33_accept.py'):
    files['root/'+name]=(root/'.work'/name).read_bytes()
out=root/'evidence/mainline/research/33-confirmation/acceptance';out.mkdir()
with ZipFile(out/'originals.zip','x',compression=ZIP_DEFLATED) as z:
    for n,b in sorted(files.items()):z.writestr(n,b)
write(out/'manifest.json',dict(schema='aegisdc-accepted-saved-confirmation-review-v1',
    archive_sha256=sha((out/'originals.zip').read_bytes()),members={n:sha(b) for n,b in sorted(files.items())},
    review_physical_calls=0,review_selector_calls=0,review_nonce_reads=0,unresolved_findings=0))
proof=read(root/'.work/33-fresh-data-proof-01.json')
write(root/'docs/mainline/evidence/33-root-delivery.json',proof)
write(root/'docs/mainline/evidence/33-root.json',dict(status='ACCEPTED',ticket='33',date='2026-11-08',milestone='M5',
    scope='REGISTERED_INDEPENDENT_CONFIRMATION_EXECUTION_AND_SAVED_EVIDENCE',actual_root_source=source,
    execution_source='fc747fb1a579e678c5e88753d110d4875b4899b2',data_delivery=spec['delivery'],
    source_freeze='81d309685529cbd01130f06048035bd457e749f1',worlds=16,arms=6,original_runs=96,
    simulated_seconds=960,scheduled_decisions=960,returned_decisions=960,failed=0,interrupted=0,unrun=0,retries=0,
    native_archives=96,native_members=384,trace_points=standards['private_trace_points'],
    balance_intervals=standards['balance_intervals'],llm_calls=0,training_calls=0,
    reviews=dict(spec='PASS_0_UNRESOLVED',standards='PASS_0_UNRESOLVED'),
    review_originals=out.relative_to(root).as_posix()+'/manifest.json',
    fresh_proof='docs/mainline/evidence/33-root-delivery.json',field_calibration='PENDING',next_ticket='34'))
p=root/'docs/mainline/progress.json';progress=read(p)
progress.update(current_ticket='34',current_milestone='M6')
progress['milestones'][5]['acceptance_evidence'].append('docs/mainline/evidence/33-root.json')
progress['milestones'][5]['progress_scope']='29–33 execution evidence accepted; paired scientific analysis34 pending before full comparison gate.'
progress['milestones'][6].update(status='in_progress',progress_scope='34 paired analysis next;35,36 and37 still pending.')
r=progress['research_trials'];r.update(status='confirmation_completed_pending_analysis',attempts=132,completed=132,failure_records=0,charged_s=1320)
r['confirmation'].update(attempts=96,completed=96,failed=0,interrupted=0,unrun=0,charged_s=960,scheduled_decisions=960)
progress['active_implementations']=[dict(ticket='34',owner='/root',worktree='integration',state='ready_after33')]
progress['liveness_refresh']='2026-11-08: unique96 confirmation returned and both independent saved reviews plus fresh-delivery passed. No rerun.'
write(p,progress)
p=root/'.scratch/full-facility-mainline/issues/33-confirmation-run.md';s=p.read_text(encoding='utf-8').replace('**Status:** ready-for-agent','**Status:** resolved').replace('- [ ]','- [x]')
s=s.replace('Pending implementation and acceptance.','Accepted: docs/mainline/evidence/33-root.json. Original sourcefc747fb1, data bcc3c42c,96/96 complete, zero failure/retry. Both saved reviews and exact fresh delivery passed; interpretation belongs to34.')
p.write_text(s,encoding='utf-8',newline='\n')
p=root/'docs/MAINLINE.md';s=p.read_text(encoding='utf-8').replace('当前主票33执行确认','第33项96次确认原件已接受，当前主票34配对分析')
s=s.replace('独立确认尚未开始','独立确认96次已完成，主要结论待第34项配对分析')
s += '\n[第33项封存确认原件](../evidence/mainline/research/33-confirmation/README.md)保存96次唯一运行、完整预算及独立复核，累计132次注册运行；没有新增重试或模型调用。\n'
p.write_text(s,encoding='utf-8',newline='\n')
s='''# 第33项：封存确认执行与完整原件

16个预定工况、6种方法，96次运行全部完成。共计960秒模拟预算、960次实际调度决策，无失败、中断、未运行或自动重试。

每个工况窗口10秒，最大步长0.01秒，保留八域实际轨迹和局部控制。物理、外生事件、人员工具和证据生成条件按第32项冻结；主配对只改变策略名。384份原始ZIP成员对应96次独立运行，统计比较的独立单位仍为16个配对工况。

[输入与执行冻结](../../../../docs/mainline/32-confirmation-freeze.md) · [批次身份](capture-01/batch.json) · [完整尝试账](capture-01/attempts.jsonl) · [终态收据](capture-01/receipt.json)

实际执行源`fc747fb1a579e678c5e88753d110d4875b4899b2`；数据原提交`bcc3c42cdd6842a1d7ff3fdbc4e89e756f29ffdc`。保存96,985个私有状态点、96,889个积分区间。这里的私有是调度权限边界，原件均来自公开合成设施。

Spec与Standards独立核对原始文件、到时证据、实际成本和服务账，均无未解决发现。新检出确认486份声明交付文件与Git原件逐字节一致，未再调用设施、策略或种子。

[独立审查与验证原件](acceptance/manifest.json) · [根验收](../../../../docs/mainline/evidence/33-root.json) · [新检出证明](../../../../docs/mainline/evidence/33-root-delivery.json)

本项接受执行、原件和记账。第34项按冻结判据分析主要结果与成本；研究设施的现场标定仍待完成。
'''
(root/'evidence/mainline/research/33-confirmation/README.md').write_text(s,encoding='utf-8',newline='\n')
print(json.dumps(dict(status='ACCEPTED33',original_runs=96,new_calls=0,current_ticket='34',review_artifacts=len(files))))
