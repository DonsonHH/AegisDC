"""Ticket33 fixed-source Spec audit; no live capture reads or project imports."""
import ast
import hashlib
import json
import subprocess
from pathlib import Path

REPO=Path('C:/Users/Donson/.codex/worktrees/mainline33-confirmation/Renly')
OUT=Path(__file__).resolve().parent
SOURCE='fc747fb1a579e678c5e88753d110d4875b4899b2'
FROZEN='81d309685529cbd01130f06048035bd457e749f1'
ACCEPTED31='ef790a2efd5a05abb83aa12de4e8a865b65c8d81'
checks=[]
def git(*a):return subprocess.check_output(['git',*a],cwd=REPO)
def blob(path,ref=SOURCE):return git('cat-file','blob',ref+':'+path)
def read(path):return json.loads(blob(path))
def digest(raw):return hashlib.sha256(raw).hexdigest()
def check(ok,message):
    if not ok:raise AssertionError(message)
    checks.append(message)
def hashes(ref,names):
    names=sorted(names)
    raw=subprocess.check_output(['git','cat-file','--batch'],cwd=REPO,
        input=''.join(ref+':'+n+'\n' for n in names).encode())
    result={};offset=0
    for name in names:
        end=raw.index(b'\n',offset);header=raw[offset:end].split()
        assert len(header)==3 and header[1]==b'blob'
        start=end+1;size=int(header[2]);result[name]=digest(raw[start:start+size]);offset=start+size+1
    assert offset==len(raw)
    return result

lock_path='docs/mainline/evidence/30-confirmation-execution-lock.json'
lock=read(lock_path);authority=read('docs/mainline/evidence/32-root.json')
plan=read('docs/mainline/30-comparison-protocol-v1.json')
design=read('docs/mainline/evidence/30-protocol-lock.json')
progress=read('docs/mainline/progress.json')
check(progress['current_ticket']=='33' and progress['research_trials']['confirmation']['attempts']==0
      and authority['ticket']=='32' and authority['status']=='ACCEPTED',
      'Execution source enters ticket33 after accepted32 with no prior registered confirmation')
check(lock['status']=='REVIEWED_FOR_EXECUTION' and lock['execution_source']==FROZEN
      and authority['execution_lock']==lock_path and authority['execution_lock_sha256']==digest(blob(lock_path))
      and lock['design_lock_sha256']==digest(blob('docs/mainline/evidence/30-protocol-lock.json')),
      'Accepted32 binds the exact reviewed prospective source/input lock')
check(lock['execution_pins']==hashes(SOURCE,lock['execution_pins'])==hashes(FROZEN,lock['execution_pins']),
      '269 executable/configuration bytes are identical at frozen source81d and actual sourcefc747')
check(git('diff','--name-only',ACCEPTED31,SOURCE,'src','docs/mainline/30-comparison-protocol-v1.json',
          'docs/mainline/evidence/30-protocol-lock.json')==b'',
      'Actual runtime, registered methods/primary/costs/budgets and nonce commitments remain unchanged after development')
check(git('diff','--name-only',FROZEN,SOURCE,'evidence/mainline/research/32-confirmation-freeze')==b'',
      'The accepted96 input originals and failed preparation evidence are unchanged')
phase=plan['phases']['confirmation']
check(len(phase['worlds'])==16 and len(phase['arms'])==6
      and lock['budget']==phase['budget']==dict(attempts=96,simulated_charge_s=960,scheduled_decisions=960),
      'Confirmation denominator is exactly16 matched worlds by6 methods with960 seconds/decisions charged')
book=read('docs/mainline/33-confirmation-execution.json')
check(book['budget']==phase['budget'] and book['automatic_retries']==0
      and book['capture']=='evidence/mainline/research/33-confirmation/capture-01'
      and book['native_staging']=='.work/33-confirmation-native-01',
      'Runbook retains unique original output/staging and zero automatic retries')
runner=blob('scripts/registered_confirmation.py').decode()
def capture_ast(raw):
    tree=ast.parse(raw)
    fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='capture')
    for n in ast.walk(fn):
        if isinstance(n,ast.keyword) and n.arg in ('held_inputs_read','held_seed_reads'):n.value=ast.Constant(value=0)
    return ast.dump(fn,include_attributes=False)
check(capture_ast(runner)==capture_ast(blob('scripts/registered_development.py',ACCEPTED31)),
      'Capture preserves accepted durable STARTED/terminal/UNRUN/recorder-ambiguity algorithm')
check("audit_release(PHASE,'execute'" in runner and "head()==source and not git('status','--porcelain')" in runner
      and "not folder.exists() and not stage.exists()" in runner and 'sys.dont_write_bytecode' in runner,
      'Capture gates accepted32 and requires clean exact HEAD, unused outputs and fresh bytecode-cache policy')
check("shift=(world['slot']-1)%len(arms)" in runner and "digest(raw)==prepared['input_hashes'][name]" in runner,
      'All methods consume immutable matched world originals in declared rotated order')
journal=blob('scripts/development_journal.py').decode()
check("with path.open('xb')" in journal and 'os.fsync(stream.fileno())' in journal
      and "path.read_bytes()==raw" in journal and "total['started']+total['unrun']==len(slots)" in journal,
      'Durable exclusive per-slot writes, fsync/readback and exact completed/failed/unrun accounting are preserved')
native=blob('scripts/registered_development.py').decode()
save=next(n for n in ast.parse(native).body if isinstance(n,ast.FunctionDef) and n.name=='_save_native')
zip_line=next(n.lineno for n in ast.walk(save) if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='ZipFile')
audit_line=next(n.lineno for n in ast.walk(save) if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='check_run')
check(zip_line<audit_line and "run['code_identity']['git_commit']==source" in native,
      'Exact native originals are archived before verifier rejection and actual execution source is checked')
analyzer=blob('scripts/analyze_registered_confirmation.py').decode()
check("require(total['failed']==total['interrupted']==0" in analyzer,
      'Saved-outcome analyzer refuses unaudited failed/interrupted lifecycle classification')
evidence=blob('scripts/development_run_evidence.py').decode()
check(all(s in evidence for s in ['Future evidence leaked','Unqualified crew or tools','Execution overrode local protection'])
      if 'Future evidence leaked' in evidence else all(s in evidence for s in ['Future evidence','Unqualified crew or tools','Execution overrode local protection']),
      'Planned saved-native audit retains public-evidence timing, crew qualification and local-protection checks')
result=dict(status='PASS_STATIC_SPEC_AWAITING_FINAL_DATA',source=SOURCE,frozen_source=FROZEN,
    findings=[],checks=checks,nonce_reads=0,seed_derivations=0,project_imports=0,test_runs=0,
    selector_calls=0,physical_calls=0,live_capture_reads=0,
    pending='Parent data-delivery SHA required before final immutable native/journal/outcome verification')
with (OUT/'static-receipt.json').open('x',encoding='utf-8') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps({k:v for k,v in result.items() if k!='checks'}))
