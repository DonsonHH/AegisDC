"""Independent saved-only ticket33 review. Accepts one immutable data-delivery commit."""
import hashlib
import io
import json
import math
import subprocess
import sys
import zipfile
from pathlib import Path

REPO=Path('C:/Users/Donson/.codex/worktrees/mainline33-confirmation/Renly')
OUT=Path(__file__).resolve().parent
SOURCE='fc747fb1a579e678c5e88753d110d4875b4899b2'
PACKAGE='evidence/mainline/research/33-confirmation/capture-01/'
INPUTS='evidence/mainline/research/32-confirmation-freeze/prepared-02/inputs/'
DOMAINS={'power','backup','facility_cooling','equipment_environment','it_service','control_monitoring','space_access','people_tools_work'}
TOL=1e-8

def digest(raw):return hashlib.sha256(raw).hexdigest()
def close(a,b):return math.isclose(a,b,rel_tol=0,abs_tol=TOL)
def canonical(value):return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False)
def git(*a):return subprocess.check_output(['git',*a],cwd=REPO)
class Blobs:
    def __init__(self):self.p=subprocess.Popen(['git','cat-file','--batch'],cwd=REPO,stdin=subprocess.PIPE,stdout=subprocess.PIPE)
    def get(self,ref,name):
        self.p.stdin.write((ref+':'+name+'\n').encode());self.p.stdin.flush()
        header=self.p.stdout.readline().split()
        assert len(header)==3 and header[1]==b'blob',(ref,name,'Missing declared blob')
        size=int(header[2]);data=self.p.stdout.read(size)
        assert len(data)==size and self.p.stdout.read(1)==b'\n'
        return data
    def read(self,ref,name):return json.loads(self.get(ref,name))
    def close(self):self.p.stdin.close();self.p.stdout.close();self.p.wait()

def verify(delivery):
    g=Blobs()
    try:
        plan=g.read(SOURCE,'docs/mainline/30-comparison-protocol-v1.json')
        batch=g.read(delivery,PACKAGE+'batch.json');receipt=g.read(delivery,PACKAGE+'receipt.json')
        assert batch['execution_commit']==receipt['execution_commit']==SOURCE
        assert receipt['source_unchanged'] and receipt['automatic_retries']==0
        assert batch['automatic_retries']==0 and batch['unused_cache_prefix']
        assert receipt['held_inputs_read']==96 and receipt['held_seed_reads']==1
        assert receipt['llm_calls']==receipt['training_calls']==0 and receipt['field_calibration']=='PENDING'
        phase=plan['phases']['confirmation']
        assert batch['budget']==phase['budget']==dict(attempts=96,simulated_charge_s=960,scheduled_decisions=960)
        assert batch['protocol_sha256']==digest(g.get(SOURCE,'docs/mainline/30-comparison-protocol-v1.json'))
        names=set(filter(None,git('ls-tree','-rz','--name-only',delivery,PACKAGE).decode().split('\0')))
        assert names=={PACKAGE+n for n in receipt['artifacts']}|{PACKAGE+'receipt.json'}
        for n,h in receipt['artifacts'].items():assert digest(g.get(delivery,PACKAGE+n))==h,('Durable SHA',n)
        for n,h in batch['pins'].items():assert digest(g.get(SOURCE,n))==h,('Execution pin',n)
        runtime={n:h for n,h in batch['pins'].items() if n.startswith('src/aegis_dc/') and n.endswith('.py') or n=='src/patrol_rsi/contracts.py'}
        expected=[]
        for world in phase['worlds']:
            shift=(world['slot']-1)%len(phase['arms'])
            for arm in phase['arms'][shift:]+phase['arms'][:shift]:expected.append((world['id'],arm))
        assert [(s['world_id'],s['arm']) for s in batch['slots']]==expected
        assert len(expected)==96
        rows=[json.loads(line) for line in g.get(delivery,PACKAGE+'attempts.jsonl').splitlines()]
        assert len(rows)==192
        totals=dict(started=0,completed=0,failed=0,interrupted=0,unrun=0,charged_simulated_s=0,charged_scheduled_decisions=0,returned_decisions=0)
        saved={};native_archives=0
        for number,slot in enumerate(batch['slots'],1):
            assert slot['index']==number and slot['duration_s']==10 and slot['scheduled_decisions']==10
            case=PACKAGE+f"{number:02}-{slot['world_id']}-{slot['arm']}/"
            start=g.read(delivery,case+'start.json');terminal=g.read(delivery,case+'terminal.json')
            a,b=rows[(number-1)*2:number*2]
            assert {k:v for k,v in a.items() if k!='recorded_at_utc'}==start
            assert {k:v for k,v in b.items() if k!='recorded_at_utc'}==terminal
            assert a['status']=='STARTED' and b['status']=='COMPLETED'
            for row in (a,b):assert row['source']==SOURCE and all(row[k]==v for k,v in slot.items())
            assert start['charged_simulated_s']==start['charged_scheduled_decisions']==10
            assert terminal['physical_call_started'] and terminal['physical_returned'] and terminal['returned_decisions']==10
            for n,h in terminal['artifacts'].items():assert digest(g.get(delivery,case+n))==h
            totals['started']+=1;totals['completed']+=1
            totals['charged_simulated_s']+=10;totals['charged_scheduled_decisions']+=10;totals['returned_decisions']+=10
            document_raw=g.get(SOURCE,INPUTS+slot['input_member']);assert digest(document_raw)==slot['input_sha256']
            document=json.loads(document_raw)
            original=g.read(delivery,case+'originals.json');raw=g.get(delivery,case+'originals.zip')
            assert digest(raw)==original['archive_sha256']
            with zipfile.ZipFile(io.BytesIO(raw)) as archive:
                assert set(archive.namelist())==set(original['members'])=={'run.json','scenario.json','private-state.jsonl','balances.jsonl'}
                assert len(archive.namelist())==4
                data={n:archive.read(n) for n in archive.namelist()}
            assert all(digest(raw)==original['members'][n] for n,raw in data.items())
            native_archives+=1
            run=json.loads(data['run.json']);audit=g.read(delivery,case+'audit.json')
            assert json.loads(data['scenario.json'])==document['model']
            assert run['code_identity']['git_commit']==SOURCE and run['code_identity']['files']==runtime
            assert not run['code_identity']['implementation_has_changes']
            assert run['inputs']['dispatch_program']==document['dispatch_program']
            assert run['inputs']['boundary_events']==document['boundary_events']
            assert run['inputs']['duration_s']==10 and run['inputs']['maximum_step_s']==.01
            assert run['model_calls']==run['training_calls']==0 and run['field_calibration']=='PENDING'
            assert run['state_visibility']=='PRIVATE_PLANT_EVALUATOR_ONLY'
            decisions=run['policy_public_decisions']
            assert [r['frame']['as_of_s'] for r in decisions]==plan['decision_times_s']
            for decision in decisions:
                assert decision['choice']['policy']==slot['arm']
                assert set(decision)=={'frame','history','choice'}
                for r in decision['frame']['evidence']['records']:assert r['observed_at_s']<=r['arrived_at_s']<=decision['frame']['as_of_s']
            trace=[json.loads(x) for x in data['private-state.jsonl'].splitlines()]
            balances=[json.loads(x) for x in data['balances.jsonl'].splitlines()]
            assert len(trace)==len(balances)+1 and trace[0]['time_s']==0 and trace[-1]['time_s']==10
            deficit=[];demand=[];delivered=[]
            for left,right,balance in zip(trace[:-1],trace[1:],balances):
                start,end=left['time_s'],right['time_s'];dt=end-start
                assert balance['start_s']==start and balance['end_s']==end and 0<dt<=.01+TOL
                domains=left['domains'];assert set(domains)==DOMAINS
                service=domains['it_service'];offered=service['demand'];actual=service['delivered']
                assert 0<=actual<=offered and actual<=min(service['capacities'].values())+TOL
                assert domains['control_monitoring']['compute_permitted'] or domains['power']['actual_powers_W']['compute']==0
                assert min(balance['capacity_slack_W'].values())>=-1e-6
                value=(offered-actual)/offered*dt if offered else 0
                assert close(value,balance['service_deficit_time_s'])
                deficit.append(value);demand.append(offered*dt);delivered.append(actual*dt)
            metrics=dict(service_deficit_time_s=math.fsum(deficit),demand_service_unit_s=math.fsum(demand),delivered_service_unit_s=math.fsum(delivered))
            for k in ['worker_travel_person_s','worker_work_person_s','worker_wait_person_s','tool_occupation_tool_s']:
                assert all(type(b[k]) in (int,float) and math.isfinite(b[k]) and b[k]>=0 for b in balances)
                metrics[k]=math.fsum(b[k] for b in balances)
            metrics['paid_person_s']=math.fsum(metrics[k] for k in ['worker_travel_person_s','worker_work_person_s','worker_wait_person_s'])
            for k,v in metrics.items():assert close(v,audit['totals'][k]),('Independent metric mismatch',number,k)
            assert audit['hard_violations']==[] and audit['verified_closure']=='NOT_EVALUATED_WITHOUT_POST_ACTION_PROTOCOL'
            saved[(slot['world_id'],slot['arm'])]=dict(metrics=metrics,decisions=decisions,opportunities=audit['opportunities'])
        assert totals==receipt['total'] and receipt['status']=='PASS' and receipt['stop'] is None
        assert receipt['registered_research_trials']==96
        pairs=[];identified=[]
        for world in phase['worlds']:
            base=saved[(world['id'],'one_observation_lookahead')];candidate=saved[(world['id'],'evidence_consistent_contingent')]
            delta=base['metrics']['service_deficit_time_s']-candidate['metrics']['service_deficit_time_s']
            extras={k:candidate['metrics'][k]-base['metrics'][k] for k in ['paid_person_s','worker_travel_person_s','tool_occupation_tool_s']}
            first=None
            for i,(a,b) in enumerate(zip(base['decisions'],candidate['decisions'])):
                same=canonical(a['frame'])==canonical(b['frame']) and canonical(a['history'])==canonical(b['history'])
                if a['choice']['chosen_candidate_id']!=b['choice']['chosen_candidate_id']:
                    aa=base['opportunities'][i]['common_preference_eligible'];bb=candidate['opportunities'][i]['common_preference_eligible']
                    first=dict(time_s=a['frame']['as_of_s'],identified=bool(same and aa==bb and len(aa)>=2));break
                assert same
            if first and first['identified']:identified.append(world['id'])
            pairs.append(dict(world_id=world['id'],family=world['family'],service_delta_s=delta,extra=extras,first_difference=first))
        gain=math.fsum(r['service_delta_s'] for r in pairs)/16
        costs={k:math.fsum(r['extra'][k] for r in pairs)/16 for k in ['paid_person_s','worker_travel_person_s','tool_occupation_tool_s']}
        families={w['id']:w['family'] for w in phase['worlds']}
        strata={family:math.fsum(r['service_delta_s'] for r in pairs if r['family']==family)/4 for family in set(families.values())}
        return dict(status='PASS_SAVED_SPEC_REVIEW',source=SOURCE,delivery=delivery,findings=[],
            totals=totals,native_archives=native_archives,raw_members=native_archives*4,
            mean_service_delta_s=gain,mean_extra_costs=costs,stratum_means=strata,identified_worlds=identified,
            identified_families=sorted({families[w] for w in identified}),pairs=pairs,
            scope='Independent journal/identity/metric check; identification eligibility uses original saved public-admission audit, with no counterfactual selector.',
            nonce_reads=0,seed_derivations=0,project_imports=0,test_runs=0,selector_calls=0,physical_calls=0)
    finally:g.close()

if __name__=='__main__':
    if len(sys.argv)!=2:raise SystemExit('Requires parent-supplied final immutable data-delivery SHA')
    result=verify(sys.argv[1])
    with (OUT/'saved-receipt.json').open('x',encoding='utf-8') as f:json.dump(result,f,indent=2);f.write('\n')
    print(json.dumps({k:v for k,v in result.items() if k!='pairs'}))
