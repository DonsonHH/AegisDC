"""Audit a complete immutable confirmation delivery; no target execution imports."""
import argparse
from hashlib import sha256
import importlib.util
from io import BytesIO
import json
from math import fsum,isclose,isfinite
from pathlib import Path
from zipfile import ZipFile

OUT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('static_standards',OUT/'static_review.py')
s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s)
r=s.r
SOURCE=s.SOURCE
CAPTURE='evidence/mainline/research/33-confirmation/capture-01'
METRICS=('demand_service_unit_s','delivered_service_unit_s','service_deficit_time_s',
         'worker_travel_person_s','worker_work_person_s','worker_wait_person_s','access_check_person_s',
         'rendezvous_wait_person_s','queue_wait_person_s','tool_occupation_tool_s')
FRAME={'schema','plan_id','facility_id','time_unit','as_of_s','nominal_knowledge','evidence','requests'}


def main(delivery):
    check=r.check
    blob=lambda p,rev=delivery:r.blob(p,rev)
    doc=lambda p,rev=delivery:r.doc(p,rev)
    check(r.git('merge-base','--is-ancestor',SOURCE,delivery)==b'','Actual execution source precedes immutable data delivery')
    paths=r.tree(delivery,CAPTURE)
    check(bool(paths),'Complete capture exists in Git delivery')
    r.fetch(delivery,paths)
    receipt=doc(CAPTURE+'/receipt.json');batch=doc(CAPTURE+'/batch.json')
    expected=json.loads((OUT/'expected-roster.json').read_bytes())
    check(receipt['status']=='PASS' and receipt['source_unchanged'] is True and receipt['stop'] is None,'Final capture succeeded without source change or partial stop')
    check(batch['execution_commit']==receipt['execution_commit']==SOURCE and batch['slots']==expected,'Actual source and all96 slot identities equal static frozen roster')
    check(batch['classification']=='REGISTERED_INDEPENDENT_CONFIRMATION' and receipt['phase']==batch['phase']=='confirmation','Independent confirmation scope retained')
    relative={p[len(CAPTURE)+1:] for p in paths}
    check(relative==set(receipt['artifacts'])|{'receipt.json'},'Exact durable capture membership matches receipt',files=len(paths))
    check(all(sha256(blob(CAPTURE+'/'+p)).hexdigest()==h for p,h in receipt['artifacts'].items()),'Every delivered capture artifact matches declared hash')
    budget=dict(attempts=96,simulated_charge_s=960,scheduled_decisions=960)
    check(batch['budget']==budget and batch['automatic_retries']==receipt['automatic_retries']==0,'Budget and zero automatic retries preserved')
    check(receipt['registered_research_trials']==96 and receipt['held_inputs_read']==96 and receipt['held_seed_reads']==1 and receipt['llm_calls']==receipt['training_calls']==0 and receipt['field_calibration']=='PENDING','Research counts and held/LLM/field scope explicit')
    frozen=s.doc(r.EXEC_LOCK)
    plan=s.doc(r.PROTOCOL)
    lock=s.doc(r.LOCK)
    prep=s.doc(r.PREP+'/receipt.json')
    check(batch['interpreter_sha256']==frozen['interpreter_sha256'] and batch['unused_cache_prefix'] is True,'Original interpreter and cache isolation retained')
    check(batch['protocol_sha256']==sha256(s.blob(r.PROTOCOL)).hexdigest() and batch['design_lock_sha256']==sha256(s.blob(r.LOCK)).hexdigest() and batch['phase_nonce_commitment']==lock['commitments_sha256']['confirmation'],'Batch binds exact protocol/design/phase commitment')
    pin_names=set(frozen['execution_pins'])|set(lock['pins'])|{'docs/mainline/33-confirmation-execution.json',r.LOCK,r.PROTOCOL,'docs/mainline/evidence/30-root.json','docs/mainline/evidence/31-root.json','docs/mainline/evidence/32-root.json',r.EXEC_LOCK}
    pin_names|={r.PREP+'/'+p for p in set(prep['artifacts'])|{'receipt.json'}}
    check(set(batch['pins'])==pin_names,'Full runtime, governance and input pin universe exact',pins=len(pin_names))
    r.pin_check(SOURCE,batch['pins'],'All execution batch pins match actual executed Git source')
    r.pin_check(delivery,batch['pins'],'Data delivery retains every executed source/input/governance blob')
    for subtree in (r.PREP,r.OLD):
        check(r.git('rev-parse',SOURCE+':'+subtree)==r.git('rev-parse',delivery+':'+subtree),'Prepared success and original failure preserved '+subtree.rsplit('/',1)[-1])
    ledger=[json.loads(line) for line in blob(CAPTURE+'/attempts.jsonl').splitlines()]
    check(len(ledger)==192 and blob(CAPTURE+'/attempts.jsonl').endswith(b'\n'),'Complete journal has192 whole immutable records')
    total=dict(started=0,completed=0,failed=0,interrupted=0,unrun=0,charged_simulated_s=0,charged_scheduled_decisions=0,returned_decisions=0)
    native_runtime={p:h for p,h in batch['pins'].items() if p.startswith('src/aegis_dc/') and p.endswith('.py') or p=='src/patrol_rsi/contracts.py'}
    native_members=0;public_decisions=0;frames=0;intervals=0
    slot_summaries=[]
    for i,slot in enumerate(expected):
        label=f"{slot['index']:02}-{slot['world_id']}-{slot['arm']}"
        prefix=CAPTURE+'/'+label
        start,terminal=doc(prefix+'/start.json'),doc(prefix+'/terminal.json')
        first,last=ledger[i*2],ledger[i*2+1]
        check({k:v for k,v in first.items() if k!='recorded_at_utc'}==start and {k:v for k,v in last.items() if k!='recorded_at_utc'}==terminal,'Exact per-slot journal and lifecycle originals '+label)
        check(all(start[k]==terminal[k]==slot[k] for k in slot) and start['source']==terminal['source']==SOURCE and start['status']=='STARTED' and terminal['status']=='COMPLETED','Unique frozen slot STARTED/COMPLETED lifecycle '+label)
        check(start['charged_simulated_s']==slot['duration_s']==10 and start['charged_scheduled_decisions']==slot['scheduled_decisions']==terminal['returned_decisions']==10 and terminal['physical_call_started'] is True and terminal['physical_returned'] is True,'Full charge and actual returned lifecycle '+label)
        slot_paths={p[len(prefix)+1:] for p in paths if p.startswith(prefix+'/')}
        check(slot_paths==set(terminal['artifacts'])|{'terminal.json'} and all(sha256(blob(prefix+'/'+p)).hexdigest()==h for p,h in terminal['artifacts'].items()),'Per-slot durable manifest exact '+label)
        original=doc(prefix+'/originals.json');raw=blob(prefix+'/originals.zip')
        check(sha256(raw).hexdigest()==original['archive_sha256'],'Raw native archive SHA '+label)
        with ZipFile(BytesIO(raw)) as archive:
            names=archive.namelist()
            check(len(names)==len(set(names))==4 and set(names)==set(original['members'])=={'scenario.json','run.json','private-state.jsonl','balances.jsonl'},'Four unique declared native members '+label)
            members={p:archive.read(p) for p in names}
        check(all(sha256(raw).hexdigest()==original['members'][p] for p,raw in members.items()),'Every original native member SHA '+label)
        native_members+=4
        run=json.loads(members['run.json']);scenario=json.loads(members['scenario.json']);audit=doc(prefix+'/audit.json')
        input_raw=s.blob(r.PREP+'/inputs/'+slot['input_member'])
        document=json.loads(input_raw)
        check(sha256(input_raw).hexdigest()==slot['input_sha256']==frozen['input_hashes'][slot['input_member']] and scenario==document['model'],'Actual native model equals exact frozen input '+label)
        check(run['code_identity']['git_commit']==SOURCE and run['code_identity']['files']==native_runtime and run['code_identity']['implementation_has_changes'] is False,'Native runtime identity exactly matches actual execution '+label)
        check(all(original['members'][p]==m['sha256'] for p,m in run['artifacts'].items()),'Native run manifest matches raw members '+label)
        inputs=run['inputs'];program=document['dispatch_program']
        check(inputs['dispatch_program']==program and inputs['duration_s']==10 and inputs['maximum_step_s']==.01 and inputs['boundary_events']==document['boundary_events'] and inputs['work_requests']==[] and 'action_commands' not in inputs,'Actual dispatch and external conditions unchanged '+label)
        decisions=run['policy_public_decisions']
        check(run['state_visibility']=='PRIVATE_PLANT_EVALUATOR_ONLY' and run['dispatch_interface']=='PUBLIC_SELECTION_WITH_PRIVATE_EXECUTION' and run['model_calls']==run['training_calls']==0 and run['field_calibration']=='PENDING','Private evaluator and non-AI scope explicit '+label)
        check([d['frame']['as_of_s'] for d in decisions]==program['decision_times_s'] and len(decisions)==10,'Ten actual frozen decision times '+label)
        check(all(set(d)=={'frame','history','choice'} and set(d['frame'])==FRAME and set(d['history'])=={'issued','work_feedback'} and d['frame']['nominal_knowledge']==program['nominal_knowledge'] and d['frame']['requests']==program['preparation_requests'] and d['choice']['policy']==slot['arm'] and d['choice']['execution_permission'] is False for d in decisions),'Closed public decision frame and declared knowledge only '+label)
        check(all(record['observed_at_s']<=record['arrived_at_s']<=d['frame']['as_of_s'] for d in decisions for record in d['frame']['evidence']['records']),'No future or undelivered record in actual decisions '+label)
        public_decisions+=len(decisions)
        trace=[json.loads(row) for row in members['private-state.jsonl'].splitlines()]
        balances=[json.loads(row) for row in members['balances.jsonl'].splitlines()]
        check(len(trace)==len(balances)+1 and trace[0]['time_s']==0 and trace[-1]['time_s']==10 and all(row['start_s']==left['time_s'] and row['end_s']==right['time_s'] and 0<right['time_s']-left['time_s']<=.01+1e-8 for left,right,row in zip(trace[:-1],trace[1:],balances)),'Private trace and balance intervals contiguous through whole horizon '+label)
        frame_domains={p['id'] for p in document['model']['domains']}
        check(len(frame_domains)==8 and all(set(row['domains'])==frame_domains for row in trace),'Complete eight-domain actual trace retained '+label)
        check(audit['status']=='PASS_RETURNED_DEVELOPMENT_EVIDENCE' and audit['arm']==slot['arm'] and audit['hard_violations']==[] and audit['trace_points']==len(trace) and audit['balance_intervals']==len(balances),'Saved contract audit complete and violation-free '+label)
        check(all(all(type(row[k]) in (int,float) and isfinite(row[k]) and row[k]>=0 for row in balances) and isclose(fsum(row[k] for row in balances),audit['totals'][k],rel_tol=0,abs_tol=1e-8) and isclose(audit['totals'][k],run['summary'][k],rel_tol=0,abs_tol=1e-8) for k in METRICS),'Audited metrics reproduce exact saved balances and native summary '+label)
        frames+=len(trace);intervals+=len(balances)
        total['started']+=1;total['completed']+=1
        total['charged_simulated_s']+=start['charged_simulated_s'];total['charged_scheduled_decisions']+=start['charged_scheduled_decisions'];total['returned_decisions']+=terminal['returned_decisions']
        slot_summaries.append(dict(index=slot['index'],world_id=slot['world_id'],arm=slot['arm'],native_archive_sha256=original['archive_sha256'],trace_points=len(trace),balance_intervals=len(balances)))
    check(total==receipt['total'],'Independent complete lifecycle and budget accounting equals terminal receipt',total=total)
    check(native_members==384 and public_decisions==960,'All96 native returns and960 decisions audited')
    report=dict(status='PASS_COMPLETE_SAVED_STANDARDS_REVIEW',axis='Standards',execution_source=SOURCE,delivery=delivery,hard_findings=[],advisory_smell_findings=[],total=total,native_archives=96,native_members=native_members,actual_public_decisions=public_decisions,private_trace_points=frames,balance_intervals=intervals,checks=r.checks,slots=slot_summaries,scope=dict(nonce_reads=0,seed_derivations=0,physical_calls=0,selector_calls=0,tests=0,tracked_edits=0),result_boundary='Complete saved execution and provenance review only; primary scientific classification belongs to ticket34.')
    (OUT/'saved-report.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:v for k,v in report.items() if k not in ('checks','slots')}))
    print('Bounded saved-delivery checks:',len(r.checks))


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--delivery',required=True)
    main(parser.parse_args().delivery)
