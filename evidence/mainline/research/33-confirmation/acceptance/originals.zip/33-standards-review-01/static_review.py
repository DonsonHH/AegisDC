"""Static ticket33 review: immutable source only, no capture outputs or project imports."""
import ast
from hashlib import sha256
import importlib.util
import json
from pathlib import Path

OUT=Path(__file__).resolve().parent
helper=OUT.parent/'32-standards-review-01'/'review.py'
spec=importlib.util.spec_from_file_location('standards_helpers',helper)
r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r)
r.ROOT=Path(r'C:\Users\Donson\.codex\worktrees\mainline33-confirmation\Renly')
SOURCE='fc747fb1a579e678c5e88753d110d4875b4899b2'
EXECUTION='81d309685529cbd01130f06048035bd457e749f1'
check=r.check
blob=lambda p,rev=SOURCE:r.blob(p,rev)
doc=lambda p,rev=SOURCE:r.doc(p,rev)
fn=lambda p,n,rev=SOURCE:r.function(p,n,rev)


def main():
    authority=doc('docs/mainline/evidence/32-root.json')
    execution=doc(r.EXEC_LOCK)
    protocol=doc(r.PROTOCOL)
    phase=protocol['phases']['confirmation']
    check(authority['ticket']=='32' and authority['status']=='ACCEPTED','Accepted32 authority precedes unique confirmation source')
    check(authority['execution_lock']==r.EXEC_LOCK and authority['execution_lock_sha256']==sha256(blob(r.EXEC_LOCK)).hexdigest(),'Accepted32 binds exact execution lock')
    check(execution['status']=='REVIEWED_FOR_EXECUTION' and execution['execution_source']==EXECUTION,'Reviewed execution source is fixed before33')
    check(r.git('merge-base','--is-ancestor',EXECUTION,SOURCE)==b'','Reviewed execution source is ancestor of actual source')
    code=execution['execution_pins']
    check(set(code)==r.code_paths(SOURCE)==r.code_paths(EXECUTION),'269-file executable membership unchanged',files=len(code))
    r.pin_check(SOURCE,code,'Actual execution source retains all reviewed executable Git blobs')
    check(all(sha256((r.ROOT/p).read_bytes()).hexdigest()==h for p,h in code.items()),'All execution working bytes still equal source pins')
    prepared=doc(r.PREP+'/receipt.json')
    check(prepared['status']=='PASS_INPUT_ONLY' and prepared['prepared_inputs']==96 and prepared['input_hashes']==execution['input_hashes'],'Exact96 frozen input manifest retained')
    check(r.git('rev-parse',r.CANDIDATE+':'+r.PREP)==r.git('rev-parse',SOURCE+':'+r.PREP),'Accepted32 prepared subtree unchanged')
    check(r.git('rev-parse',r.CANDIDATE+':'+r.OLD)==r.git('rev-parse',SOURCE+':'+r.OLD),'Original failed input preparation subtree unchanged')
    check(blob(r.PROTOCOL)==blob(r.PROTOCOL,r.BASE) and blob(r.LOCK)==blob(r.LOCK,r.BASE),'Preregistered protocol and nonce commitments unchanged')
    book=doc('docs/mainline/33-confirmation-execution.json')
    budget=dict(attempts=96,simulated_charge_s=960,scheduled_decisions=960)
    check(book['budget']==phase['budget']==execution['budget']==budget and book['automatic_retries']==0,'96 attempts960 seconds960 decisions and zero retries fixed')
    check(book['capture']=='evidence/mainline/research/33-confirmation/capture-01' and book['native_staging']=='.work/33-confirmation-native-01','Single unique capture and native-staging paths declared')
    slots=[]
    for w in phase['worlds']:
        arms=phase['arms'];shift=(w['slot']-1)%len(arms)
        for arm in arms[shift:]+arms[:shift]:
            name=w['id']+'/'+arm+'.json'
            slots.append(dict(index=len(slots)+1,world_id=w['id'],family=w['family'],arm=arm,duration_s=w['duration_s'],scheduled_decisions=len(protocol['decision_times_s']),input_member=name,input_sha256=prepared['input_hashes'][name]))
    check(len(slots)==96 and sum(s['duration_s'] for s in slots)==960 and sum(s['scheduled_decisions'] for s in slots)==960,'Deterministic rotated roster reconciles declared budget')
    (OUT/'expected-roster.json').write_text(json.dumps(slots,indent=2)+'\n',encoding='utf-8')
    current=fn('scripts/registered_confirmation.py','capture')
    prior=fn('scripts/registered_development.py','capture',r.BASE)
    for n in ast.walk(current):
        if isinstance(n,ast.keyword) and n.arg in ('held_inputs_read','held_seed_reads'): n.value=ast.Constant(value=0)
    check(ast.dump(current,include_attributes=False)==ast.dump(prior,include_attributes=False),'Capture retains accepted31 charge, failure and stop algorithm; only held counters differ')
    for p in ('scripts/development_journal.py','scripts/development_run_evidence.py','scripts/registered_development.py'):
        check(blob(p)==blob(p,r.BASE),'Accepted31 recording/native/audit tool unchanged '+p)
    begin=ast.unparse(fn('scripts/registered_confirmation.py','_begin'))
    check("not git('status', '--porcelain')" in begin and 'not folder.exists()' in begin and 'not stage.exists()' in begin,'Capture admission requires clean source and never-existing output paths')
    check("progress['current_ticket'] == '33'" in begin and "progress['research_trials']['confirmation']['attempts'] == 0" in begin,'Admission refuses wrong frontier and already attempted confirmation')
    check('sys.dont_write_bytecode' in begin and 'not Path(sys.pycache_prefix).exists()' in begin,'Admission requires no bytecode and an unused cache location')
    original_capture=ast.unparse(fn('scripts/registered_confirmation.py','capture'))
    check(original_capture.index('journal_append(ledger, start)') < original_capture.index('simulate_scenario('),'Durable STARTED charge precedes the only physical-call site')
    check(original_capture.index('decisions = _save_native(') < original_capture.index("terminal['status'] = 'COMPLETED'"),'Original native return is preserved before success classification')
    check('authoritative_totals=None' in original_capture and 'RECORDER_INCOMPLETE' in original_capture,'Recorder uncertainty is explicitly non-authoritative and preserved')
    release=ast.unparse(fn('scripts/comparison_release.py','audit_release'))
    check(release.index('_execution_receipt(') < release.index('_read_nonce('),'Accepted lock, source and input release checks precede phase nonce read')
    journal=blob('scripts/development_journal.py').decode()
    check("path.open('ab')" in journal and "path.open('xb')" in journal and 'os.fsync(stream.fileno())' in journal,'Ledger is append-only; per-slot records refuse replacement and use fsync')
    save=ast.unparse(fn('scripts/registered_development.py','_save_native'))
    check(save.index("write(folder / 'originals.json'") < save.index('audit = check_run('),'Native raw archive and hash manifest precede contract audit refusal')
    runtime={p for p in code if p.startswith('src/')}
    check(all(blob(p)==blob(p,r.BASE) for p in runtime),'Physical/decision/private-view runtime unchanged from accepted31',files=len(runtime))
    output=dict(status='PASS_STATIC_STANDARDS_WAITING_FULL_SAVED_DELIVERY',axis='Standards',source=SOURCE,frozen_execution_source=EXECUTION,hard_findings=[],advisory_smell_findings=[],checks=r.checks,scope=dict(nonce_reads=0,seed_derivations=0,physical_calls=0,selector_calls=0,tests=0,partial_capture_files_read=0,tracked_edits=0),remaining='Wait for complete immutable96-native data delivery before final evidence audit; no partial outcome classification.')
    (OUT/'static-report.json').write_text(json.dumps(output,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:v for k,v in output.items() if k!='checks'}))
    print('Bounded static checks:',len(r.checks))


if __name__=='__main__':main()
