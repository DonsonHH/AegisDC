"""Seal returned originals; no classification, simulation or selector invocation."""
import hashlib,json,subprocess,sys
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
root=Path(__file__).resolve().parents[1]
integration=Path('C:/Users/Donson/Documents/ChatGPT/Renly')
sys.path.insert(0,str(root/'scripts'))
from development_journal import reconcile
from inspection_delivery import durable,hashes
read=lambda p:json.loads(p.read_bytes())
sha=lambda b:hashlib.sha256(b).hexdigest()
capture=root/'evidence/mainline/research/33-confirmation/capture-01'
receipt=read(capture/'receipt.json');batch=read(capture/'batch.json')
launch=root/'.work/33-capture-launch-01'
assert read(launch/'terminal.json')['returncode']==0
assert receipt['status']=='PASS' and receipt['source_unchanged']
assert receipt['phase']=='confirmation' and receipt['automatic_retries']==receipt['llm_calls']==receipt['training_calls']==0
total=reconcile(capture,batch['slots'],batch['execution_commit'])
assert total==receipt['total'] and total==dict(started=96,completed=96,failed=0,interrupted=0,unrun=0,
    charged_simulated_s=960,charged_scheduled_decisions=960,returned_decisions=960)
assert durable(capture)==set(receipt['artifacts'])|{'receipt.json'}
assert all(sha((capture/n).read_bytes())==h for n,h in receipt['artifacts'].items())
assert batch['pins']==hashes(batch['execution_commit'],batch['pins'])
assert all(sha((root/n).read_bytes())==h for n,h in batch['pins'].items())
files={'author/run_33_capture.py':(root/'.work/run_33_capture.py').read_bytes(),
       'author/33_seal_capture.py':Path(__file__).read_bytes(),
       'root/33-pre-call-freeze-01.json':(integration/'.work/33-pre-call-freeze-01.json').read_bytes()}
files['root/33_fresh_delivery.py']=(integration/'.work/33_fresh_delivery.py').read_bytes()
for p in launch.iterdir():
    if p.is_file():files['author/33-capture-launch-01/'+p.name]=p.read_bytes()
out=root/'evidence/mainline/research/33-confirmation/support';out.mkdir()
with ZipFile(out/'originals.zip','x',compression=ZIP_DEFLATED) as z:
    for n,b in sorted(files.items()):z.writestr(n,b)
manifest=dict(schema='aegisdc-original-launch-artifacts-v1',archive_sha256=sha((out/'originals.zip').read_bytes()),
    members={n:sha(b) for n,b in sorted(files.items())},new_physical_calls=0,new_selector_calls=0)
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8',newline='\n')
record=dict(status='CAPTURED_PENDING_INDEPENDENT_ACCEPTANCE',ticket='33',phase='confirmation',
    execution_source=batch['execution_commit'],frozen_execution_source='81d309685529cbd01130f06048035bd457e749f1',
    totals=total,original_slots=96,original_native_members=384,
    capture='evidence/mainline/research/33-confirmation/capture-01/receipt.json',
    scope='Execution and original accounting only; paired interpretation belongs to34.',
    new_physical_calls=0,new_selector_calls=0,field_calibration='PENDING')
(root/'docs/mainline/evidence/33.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(dict(status='SAVED_ORIGINALS_RECONCILED',totals=total,durable_capture_files=len(durable(capture)))))
