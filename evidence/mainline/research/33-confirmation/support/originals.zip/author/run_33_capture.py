import json,os,subprocess,sys
from datetime import datetime,timezone
from hashlib import sha256
from pathlib import Path
root=Path(__file__).resolve().parents[1]
source='fc747fb1a579e678c5e88753d110d4875b4899b2'
launch=root/'.work/33-capture-launch-01';launch.mkdir()
cmd=[sys.executable,'-B','-X','utf8','-X','pycache_prefix='+str(root/'.work/33-confirmation-unused-cache-01'),
     'scripts/registered_confirmation.py','capture','--source',source,
     '--output',str(root/'evidence/mainline/research/33-confirmation/capture-01'),
     '--native-staging',str(root/'.work/33-confirmation-native-01')]
def write(name,value):
    with (launch/name).open('x',encoding='utf-8',newline='\n') as f:json.dump(value,f,ensure_ascii=False,indent=2);f.write('\n')
write('attempt.json',dict(started_utc=datetime.now(timezone.utc).isoformat(),source=source,command=cmd,
    launcher_sha256=sha256(Path(__file__).read_bytes()).hexdigest(),automatic_retries=0,classification='REGISTERED_CONFIRMATION_BATCH'))
env=os.environ.copy();env['PYTHONPATH']=str(root/'src')
try:
    with (launch/'stdio.log').open('xb') as out:
        run=subprocess.run(cmd,cwd=root,env=env,stdout=out,stderr=subprocess.STDOUT,check=False)
    code=run.returncode
except BaseException as exc:
    write('launcher-error.json',dict(type=type(exc).__name__,error=str(exc)))
    code=255
write('terminal.json',dict(finished_utc=datetime.now(timezone.utc).isoformat(),returncode=code,automatic_retries=0))
raise SystemExit(code)
